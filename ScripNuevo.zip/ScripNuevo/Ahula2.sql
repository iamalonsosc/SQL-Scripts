UPDATE Matricula SET Estado='N',IdRegistro=8,IdCurricula=5612
WHERE IdMatricula=611208


UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula=768170

--ANULAR REGISTRO 1,2,3
select*from Registro 
UPDATE Registro SET Estado='X'
where IdActor=1233708 and IdRegistro in(2,3)


--PROYECTO DESARROLLO SOFTWARE I
--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1233708 AND IdRegistro=4 AND IdCurso=10501 AND IdCurricula=29

--DESARROLLO AVANZADO DE APLICACIONES II
--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion=NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1233708 AND IdRegistro=4 AND IdCurso=10506 AND IdCurricula=29

--DESARROLLO DE APLICACIONES WEB
--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion=NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1233708 AND IdRegistro=4 AND IdCurso=10509 AND IdCurricula=29



SELECT*FROM AlumnoCurso 
--UPDATE AlumnoCurso SET IdRegistro=4
WHERE IdMatricula=611208--IdAlumno=1233708 and IdRegistro=8


SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=17
WHERE IdMatricula=768170 AND IdCurso=10501
--(1 fila afectada)
UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=18
WHERE IdMatricula=768170 AND IdCurso=10506
--(1 fila afectada)
UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=19
WHERE IdMatricula=768170 AND IdCurso=10509
--(1 fila afectada)


--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=8,IdAlumnoCurso=1,IdcurriculaOriginal=5612--29
WHERE IdMatricula=611208 AND IdCurso=13449

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=8,IdAlumnoCurso=2,IdcurriculaOriginal=5612
WHERE IdMatricula=611208 AND IdCurso=10506

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=8,IdAlumnoCurso=3,IdcurriculaOriginal=5612
WHERE IdMatricula=611208 AND IdCurso=10509



--SELECT*FROM AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='16.00',PromedioReal='16.04',IdAlumnoCurso=1,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1233708 AND IdRegistro=8 AND IdCurso=10501 AND IdCurricula=5612

--SELECT*FROM AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='19.00',PromedioReal='19.36',IdAlumnoCurso=2,Observacion='CONVALIDACION MALLA INTERNA'--Subsanacion=NULL
WHERE IdAlumno=1233708 AND IdRegistro=8 AND IdCurso=10506 AND IdCurricula=5612

--SELECT*FROM AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='20.00',PromedioReal='19.80',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA'--Subsanacion=NULL
WHERE IdAlumno=1233708 AND IdRegistro=8 AND IdCurso=10509 AND IdCurricula=5612




SELECT  PE.Codigo
				,AC.NumVezCurso
				
				, PG.FechaInicio --@9  
				, PG.FechaFin --@9 
				, PG.GrupoCodigo --@9      
				, AC.IdSeccion --@16    
				, M.IdMatricula --@16  
			FROM AlumnoCurso AC WITH (NOLOCK)
			INNER JOIN Promocion P WITH (NOLOCK) ON AC.IdPromocion = P.IdPromocion
			INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
			INNER JOIN Matricula M WITH (NOLOCK) ON AC.IdMatricula = M.IdMatricula
			INNER JOIN PromocionGrupo pg WITH (NOLOCK) ON pg.IdPromocion = AC.IdPromocion AND pg.IdGrupo = Ac.IdGrupo
			WHERE AC.IdAlumno = 1233708
				AND AC.IdRegistro = 8
				AND ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) = 5612 --@13      
				AND ISNULL(AC.IdCursoOriginal, AC.IdCurso) = 10501 --@13      
				AND AC.EsMatricula = 1
				AND M.Estado != 'X' --@12 --HUILLCA
				AND AC.estado = 'NO' --@12      
				--ORDER BY PE.IdPeriodo DESC      
			ORDER BY ISNULL(M.MatriculaFecha, M.InscritoFecha) DESC --@1      