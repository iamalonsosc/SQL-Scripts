SELECT*FROM Matricula 
--UPDATE Matricula SET Estado='X'
WHERE IdMatricula=589478