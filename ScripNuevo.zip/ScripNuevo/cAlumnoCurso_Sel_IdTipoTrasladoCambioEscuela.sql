/* ============================================================================
           1=Regular, 2=Egresado, 3=Reingreso

   Reglas de negocio replicadas:

   - Segun la CompaniaSocio se aplica la Rama A (00002500/00002400) o la Rama B (00002700/00002600):
        Rama A:
          - Curricula anterior NO esta en el paquete -> Regular (1)
          - Si esta en el paquete y existe en Egresados -> Egresado (2)
          - Si esta en el paquete y NO existe en Egresados -> Reingreso (3)
        Rama B:
          - Curricula anterior NO esta en el paquete -> Regular (1)
          - Si esta en el paquete y existe en Egresados -> Egresado (2)
          - Si esta en el paquete, NO existe en Egresados, y el parametro
            'TipoPrograma' esta activo, se compara UnidadAcademica.NombreCorto
            del periodo origen vs destino:
              Instituto -> Instituto : Regular (1)
              Instituto -> Escuela   : Reingreso (3)
              Escuela   -> Escuela   : Regular (1)
              Cualquier otro caso    : Regular (1)
          - Si el parametro 'TipoPrograma' NO esta activo -> Regular (1)
   - Si la CompaniaSocio no coincide con ninguna de las 4 anteriores, el
     resultado queda NULL / 'SIN REGLA APLICABLE' (mismo comportamiento
     que el SP original: las variables @Egresado/@Reingreso/@Regular no
     se setean).

   NOTA: Este script es de solo lectura (no hace ningun INSERT/UPDATE),
   por lo tanto es seguro ejecutarlo cuantas veces se quiera para
   verificar el tipo antes de generar el traslado real.
   ============================================================================ */

IF OBJECT_ID('dbo.cAlumnoCurso_Sel_IdTipoTrasladoCambioEscuela') IS NOT NULL
    DROP PROCEDURE dbo.cAlumnoCurso_Sel_IdTipoTrasladoCambioEscuela
GO

CREATE PROCEDURE dbo.cAlumnoCurso_Sel_IdTipoTrasladoCambioEscuela
    @pIdEmpresa INT,
    @pIdSede    INT,
    @pIdPeriodo INT,   -- Periodo destino (IdPeriodoTraslado)
    @pIdAlumno  INT
AS
BEGIN

    SET NOCOUNT ON

    DECLARE
        @CurIdCurriculaAnterior INT,
        @CompaniaSocio          CHAR(8),
        @IdTipoProgramaOrigen   INT,
        @IdTipoProgramaDestino  INT,
        @TipoProgramaOrigen     VARCHAR(20),
        @TipoProgramaDestino    VARCHAR(20),
        @EstadoTipoProgramaInstitutoEscuela VARCHAR(MAX),
        @TipoProgramaInstituto  VARCHAR(5000),
        @TipoProgramaEscuela    VARCHAR(5000),
        @Egresado BIT = 0,
        @Reingreso BIT = 0,
        @Regular  BIT = 0,
        @CurIdTipo INT = NULL

    --------------------------------------------------------------------------
    -- 1. Ubicar el registro del traslado programado + datos base
    --------------------------------------------------------------------------
    SELECT
        @CurIdCurriculaAnterior = CC.IdCurriculaAnterior,
        @CompaniaSocio          = E.CompaniaSocio,
        @IdTipoProgramaOrigen   = PER_ORIG.IdUnidadAcademica,
        @IdTipoProgramaDestino  = PER_DEST.IdUnidadAcademica
    FROM TrasladoSede CC WITH (NOLOCK)
    INNER JOIN Periodo PER_ORIG WITH (NOLOCK) ON CC.IdPeriodoAnterior = PER_ORIG.IdPeriodo
    INNER JOIN Periodo PER_DEST WITH (NOLOCK) ON CC.IdPeriodoTraslado = PER_DEST.IdPeriodo
    INNER JOIN Empresa E WITH (NOLOCK) ON CC.IdEmpresa = E.IdEmpresa
    WHERE CC.IdEmpresa = @pIdEmpresa
    AND CC.IdSede = @pIdSede
    AND CC.IdPeriodoTraslado = @pIdPeriodo
    AND CC.IdAlumno = @pIdAlumno
    AND CC.Estado = 1

    IF @CurIdCurriculaAnterior IS NULL
    BEGIN
        SELECT
            IdTipo = NULL,
            Descripcion = 'No se encontro traslado programado (TrasladoSede) para los parametros indicados o Estado <> 1.'
        RETURN
    END

    --------------------------------------------------------------------------
    -- 2. Parametro TipoPrograma (Instituto / Escuela) - solo se usa en Rama B
    --------------------------------------------------------------------------
    SELECT
        @EstadoTipoProgramaInstitutoEscuela = Valor,
        @TipoProgramaInstituto = Valor2,
        @TipoProgramaEscuela = Valor3
    FROM Parametro WITH (NOLOCK)
    WHERE Nombre = 'TipoPrograma'

    SELECT
        @TipoProgramaOrigen = ISNULL(NombreCorto,'')
    FROM UnidadAcademica WITH (NOLOCK)
    WHERE IdUnidadAcademica = @IdTipoProgramaOrigen

    SELECT
        @TipoProgramaDestino = ISNULL(NombreCorto,'')
    FROM UnidadAcademica WITH (NOLOCK)
    WHERE IdUnidadAcademica = @IdTipoProgramaDestino

    --------------------------------------------------------------------------
    -- 3. Curricula anterior: �pertenece al paquete de equivalencia?
    --------------------------------------------------------------------------
    DECLARE @PaqCursoEquivalenciaDet AS TABLE (IdCurricula INT)

    INSERT INTO @PaqCursoEquivalenciaDet
    SELECT DISTINCT IdCurricula
    FROM PaqCursoEquivalenciaDet WITH (NOLOCK)

    --------------------------------------------------------------------------
    -- 4. Rama A: CompaniaSocio = 00002500 / 00002400
    --------------------------------------------------------------------------
    IF @CompaniaSocio = '00002500' OR @CompaniaSocio = '00002400'
    BEGIN

        IF @CurIdCurriculaAnterior IN (SELECT IdCurricula FROM @PaqCursoEquivalenciaDet)
        BEGIN

            IF EXISTS
            (
                SELECT 1
                FROM Egresados WITH (NOLOCK)
                WHERE IdAlumno = @pIdAlumno
                AND IdCurricula = @CurIdCurriculaAnterior
            )
            BEGIN
                SELECT @Egresado = 1, @Reingreso = 0
            END
            ELSE
            BEGIN
                SELECT @Egresado = 0, @Reingreso = 1
            END

        END
        ELSE
        BEGIN
            SELECT @Egresado = 0, @Reingreso = 0, @Regular = 1
        END

    END

    --------------------------------------------------------------------------
    -- 5. Rama B: CompaniaSocio = 00002700 / 00002600
    --------------------------------------------------------------------------
    IF @CompaniaSocio IN ('00002700','00002600')
    BEGIN

        IF @CurIdCurriculaAnterior IN (SELECT IdCurricula FROM @PaqCursoEquivalenciaDet)
        BEGIN

            IF EXISTS
            (
                SELECT 1
                FROM Egresados WITH (NOLOCK)
                WHERE IdAlumno = @pIdAlumno
                AND IdCurricula = @CurIdCurriculaAnterior
            )
            BEGIN
                SELECT @Egresado = 1, @Reingreso = 0
            END
            ELSE
            BEGIN
                SELECT @Egresado = 0

                IF @EstadoTipoProgramaInstitutoEscuela = 1
                BEGIN

                    IF (@TipoProgramaOrigen = @TipoProgramaInstituto AND @TipoProgramaDestino = @TipoProgramaInstituto)
                    BEGIN
                        SELECT @Regular = 1
                    END
                    ELSE IF (@TipoProgramaOrigen = @TipoProgramaInstituto AND @TipoProgramaDestino = @TipoProgramaEscuela)
                    BEGIN
                        SELECT @Reingreso = 1
                    END
                    ELSE IF (@TipoProgramaOrigen = @TipoProgramaEscuela AND @TipoProgramaDestino = @TipoProgramaEscuela)
                    BEGIN
                        SELECT @Regular = 1
                    END
                    ELSE
                    BEGIN
                        SELECT @Regular = 1
                    END

                END
                ELSE
                BEGIN
                    SELECT @Regular = 1
                END

            END

        END
        ELSE
        BEGIN
            SELECT @Egresado = 0, @Reingreso = 0, @Regular = 1
        END

    END

    --------------------------------------------------------------------------
    -- 6. Resolver IdTipo final (misma prioridad que el SP original: si mas
    --    de una bandera quedara en 1 por algun escenario no previsto, gana
    --    la ultima evaluada: Egresado -> Reingreso -> Regular)
    --------------------------------------------------------------------------
    IF @Egresado = 1  SELECT @CurIdTipo = 2
    IF @Reingreso = 1 SELECT @CurIdTipo = 3
    IF @Regular = 1   SELECT @CurIdTipo = 1

    --------------------------------------------------------------------------
    -- 7. Resultado
    --------------------------------------------------------------------------
    SELECT
        IdTipo = @CurIdTipo,
        Descripcion =
            CASE @CurIdTipo
                WHEN 1 THEN 'Regular'
                WHEN 2 THEN 'Egresado'
                WHEN 3 THEN 'Reingreso'
                ELSE 'SIN REGLA APLICABLE (CompaniaSocio no coincide con 00002500/00002400/00002700/00002600)'
            END,
        CompaniaSocio = @CompaniaSocio,
        CurIdCurriculaAnterior = @CurIdCurriculaAnterior,
        TipoProgramaOrigen = @TipoProgramaOrigen,
        TipoProgramaDestino = @TipoProgramaDestino

END
GO

/* ============================================================================
   BLOQUE DE EJEMPLO / PRUEBA
   Reemplaza los valores por los del alumno y traslado que quieras validar.
   ============================================================================ */

EXEC dbo.cAlumnoCurso_Sel_IdTipoTrasladoCambioEscuela
    @pIdEmpresa = 1,       -- Reemplazar por el IdEmpresa real
    @pIdSede    = 34,       -- Reemplazar por el IdSede real
    @pIdPeriodo = 4259,  -- Reemplazar por el IdPeriodo destino (IdPeriodoTraslado)
    @pIdAlumno  = 123456   -- Reemplazar por el IdAlumno real