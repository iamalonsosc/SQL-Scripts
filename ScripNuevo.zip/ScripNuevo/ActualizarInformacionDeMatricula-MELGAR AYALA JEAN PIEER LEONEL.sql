--PARA ELIMINAR DE USUARIO
DELETE FROM Permiso WHERE IdUsuario=195796
--UPDATE Permiso SET IdUsuario=470120

--(1 row affected)
DELETE FROM Usuario where IdUsuario=195796
--(1 row affected)



--PARA ELIMINAR DE ALUMNO
DELETE FROM AlumnoSeguimientoInasistencia WHERE IdAlumnoSeguimiento=462779
--(6 rows affected)
DELETE  FROM AlumnoSeguimiento WHERE IdAlumno=1322806
--(1 row affected)
DELETE FROM Alumno WHERE IdAlumno=1322806
--(1 row affected)

--ACTUALIZAR ESMATRICULA EN 0

--SELECT*FROM Matricula 
UPDATE Matricula SET EsMatricula=0
WHERE IdMatricula=659514
--(1 row affected)

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET EsMatricula=0
WHERE IdMatricula=659514
--(7 row affected)