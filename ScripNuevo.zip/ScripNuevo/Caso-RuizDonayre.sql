--SELECT*FROM CO_Documento 
UPDATE CO_Documento set ClienteNumero='1228672',ClienteNombre='RUIZ DONAYRE, MATIAS',ClienteDireccion=NULL,ClienteCobrarA='1228672'
WHERE NumeroDocumento='B001-32524' AND CompaniaSocio='00002500'
--(1 row affected)