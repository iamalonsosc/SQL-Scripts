--SELECT*FROM Actor WHERE NombreCompleto like '%PEREZ PISFIL ANNY KATHERINE%'
--SELECT PromedioCurso,PromedioCondicion,PromedioPonderado,*FROM ActaConsolidada where NombreAlumno like '%PEREZ PISFIL ANNY KATHERINE%' AND IdCurso=13537
--SELECT   PromedioCurso,PromedioCondicion,PromedioPonderado,*FROM ActaConsolidada where NombreAlumno like '%PEREZ PISFIL ANNY KATHERINE%' AND PeriodoCodigo='2024-I'
--SELECT*FROM ActaConsolidada WHERE TipoCondicion='RE' AND PromedioCondicion='D'

UPDATE ActaConsolidada SET PromedioCurso='9.00',PromedioCondicion='D'
WHERE IdCurso=13537 AND IdActa=1372489 AND NombreAlumno like '%PEREZ PISFIL ANNY KATHERINE%'
--(1 row affected)

UPDATE ActaConsolidada SET CursosAprobados='5',CursosDesaprobados='1'
WHERE NombreAlumno like '%PEREZ PISFIL ANNY KATHERINE%' AND PeriodoCodigo='2024-I'
--(6 rows affected)

--SELECT*FROM AlumnoCursoActaJson where numerodocumento like '%71817454%'
----PROYECTO INTEGRADOR 1: TALLER DE DISE�O DE INTERIORES I - ESPACIO RESIDENCIAL

UPDATE AlumnoCursoActaJson SET Nota='9'
WHERE IdActa=1372489 AND IdAlumno=1658318 AND ID=39637
--(1 row affected)


