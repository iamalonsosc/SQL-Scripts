declare @Alumno_datos as table(
	id int identity(1,1),
	dni varchar(20),
	nombrecompleto varchar(255),
	Carrera varchar(255),
	sede varchar(20),
	seccionNomina varchar(50),
	curso varchar(255),
	Observaciones varchar(MAX))
 
DECLARE @CURSOS AS TABLE (
		ID INT IDENTITY(1,1),
		IDCURSO INT,
		CURSONOMBRE VARCHAR(255))

DECLARE @Nominas AS TABLE (
		ID INT IDENTITY (1,1),
		SECCION_NOMINA VARCHAR(30),
		COD_SEDE varchar(10),   
		OBSERVACION VARCHAR(255))

INSERT INTO @Alumno_datos VALUES
--Ejemplo 
--DNI,NOMBREALUMNO,CARRERA,SEDE,SECCIONNOMINA,CURSO,OBSERVACION
--CASO B
('41179966','SAIRE QUISPE LUCIO','Mecatr�nica Automotriz','Wilson','218.V.04.2024-I-V-B','INTERPRETACI�N DE INFORMACI�N T�CNICA',NULL),
('002772981','BETANCOURT CASTRO EDUARDO ALEXANDER','Mecatr�nica Industrial','Wilson','219.V.02.2024-I-V-A','CONTROL Y AUTOMATIZACI�N DE PROCESOS',NULL),
('48310046','RETAMOZO HUATUCO JEIMY JESUS','Adm. Empresas','ATE','208.VI.06.2024-I-VI-C','CONSTITUCI�N DE EMPRESAS Y NUEVOS NEGOCIOS',NULL),
('72843833','CERNA PAJUELO ANYEL NICOOL','Contabilidad','PT','N-212.IV.04.2024-I-IV-C','TALLER CONTABLE II/CONTABILIDAD DE COSTOS I',NULL)
DECLARE @MIN INT, @MAX INT, @min_Nomina INT, @max_Nomina INT, @IDSEDE INT, @IDACTOR INT, 
		@dni varchar(20),
		@nombrecompleto varchar(255),
		@Carrera varchar(255),
		@sede varchar(20),
		@seccionNomina varchar(50),
		@curso varchar(255),
		@observaciones varchar(255),
		@Seccion_Nomina VARCHAR(255)

SELECT @MIN=MIN(ID), @MAX= MAX(ID) FROM @Alumno_datos

WHILE @MIN <= @MAX
BEGIN
	
	SET @dni = NULL
	SET @nombrecompleto = NULL
	SET @Carrera = NULL
	SET @SEDE = NULL
	SET @seccionNomina = NULL
	SET @curso = NULL
	SET @observaciones = NULL

	SELECT @DNI=dni, @nombrecompleto=nombrecompleto, @Carrera=Carrera, 
		   @SEDE = CASE SEDE WHEN 'CHICLAYO' THEN 'CH' 
							 WHEN 'PIURA' THEN 'PI' 
							 WHEN 'ATE' THEN 'AT' 
							 WHEN 'SJL' THEN 'SL' 
							 WHEN 'SJM' THEN 'SM' 
							 WHEN 'PT' THEN 'PT' 
							 WHEN 'WILSON' THEN 'WI' 
							 WHEN 'T.VALLE' THEN 'LN' 
							 WHEN 'VIRTUAL' THEN 'SV'
							 
					END,
			@seccionNomina=seccionNomina,
			@curso=curso
	FROM @Alumno_datos WHERE ID=@MIN
	
	DELETE FROM @CURSOS
	
	INSERT INTO @CURSOS 
		SELECT IdCurso,CursoNombre FROM CURSO WHERE CursoNombre IN (SELECT DATA FROM SPLIT(@curso,'/') ) --AND CursoNombreOficial IS NOT NULL
	
	--select * from @CURSOS
	--RETURN
	
	SELECT @observaciones = CONCAT(@observaciones,',',CURSONOMBRE) FROM @CURSOS

	--UPDATE AlumnoCursoNomina set SeccionNomina=null
	--SELECT A.NombreCompleto,ACN.SeccionNomina,S.Codigo,C.CursoNombre,c.idcurso
	DELETE  ACN
	FROM AlumnoCursoNomina ACN
	INNER JOIN ACTOR A ON ACN.IdActor=A.IdActor
	INNER JOIN SEDE S ON ACN.IdSede=S.IdSede
	INNER JOIN CURSO C ON ACN.IdCurso=C.IdCurso
	WHERE (A.NumeroIdentidad=@dni OR A.NombreCompleto=@nombrecompleto) AND ACN.SeccionNomina=@seccionNomina --AND S.Codigo=@sede 
		  AND ACN.IdCurso IN (SELECT IDCURSO FROM @CURSOS)	
	
	DELETE  AC
	--select * 
	FROM ActaConsolidada AC
	INNER JOIN matricula  m ON ac.IdAlumno=m.IdActor and ac.IdMatricula=m.IdMatricula 
	INNER JOIN alumnocurso acu ON AC.IdAlumno=acu.IdAlumno and ac.IdMatricula=acu.IdMatricula and ac.IdCurso=acu.IdCurso
	--INNER JOIN CURSO C ON AC.IdCurso=C.IdCurso
	WHERE Ac.NombreAlumno = @nombrecompleto  --AND S.Codigo=@sede 
		  AND AC.IdCurso IN (SELECT IDCURSO FROM @CURSOS)	
		  AND AC.Seccion=@seccionNomina
	
	IF EXISTS(SELECT DISTINCT 1 FROM @CURSOS)
	BEGIN
		UPDATE @Alumno_datos set Observaciones=concat('Se elimino la SeccionNomina de los cursos:',@Observaciones) WHERE ID = @MIN
	END
	ELSE
	BEGIN
		UPDATE @Alumno_datos set Observaciones='No se encontraron cursos' WHERE ID = @MIN
	END
	
	IF NOT EXISTS (SELECT DISTINCT 1 FROM @Nominas WHERE SECCION_NOMINA = @seccionNomina) 
	BEGIN
		INSERT INTO @Nominas VALUES (@seccionNomina,@sede, NULL)
	END

	SET @MIN=@MIN+1
END

select * from @Alumno_datos
--select * from @Nominas
