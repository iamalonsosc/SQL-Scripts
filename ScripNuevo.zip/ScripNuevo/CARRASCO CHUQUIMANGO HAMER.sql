--SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
--INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
--WHERE AC.IdAlumno=1257379 
----AND AC.IdCurso=10578 
----AND AC.IdCursoOriginal=10578 
--AND AC.IdMatricula=670803 
----AND AC.EsMatricula=1
--order by ac.idregistro,ac.IdAlumnoCurso desc


--SELECT SE.*FROM Seccion SE
--INNER JOIN Promocion PRO ON SE.IdPromocion=PRO.IdPromocion
--WHERE SE.IdPeriodoAnual=2025 
--AND SE.IdCurso=10578 
--AND SE.IdCurricula=5614 
--AND PRO.IdSede=40
--AND PRO.PromocionCodigo LIKE '%2025-I%' 


--CONSTITUCI�N DE EMPRESAS Y NUEVOS NEGOCIOS
INSERT INTO AlumnoCurso VALUES (1257379,5,28,5614,10578,670803,97382,8,640995,null,null,'15.00','15.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL
,PromedioFinal='15.00'
,PromedioReal= '15.00'
,IdAlumnoCurso=28
,TipoCondicion='RE'
--select*from AlumnoCurriculaCurso 
where IdAlumno=1257379 and IdCurso=10578 AND IdRegistro=5