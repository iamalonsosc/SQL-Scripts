UPDATE Matricula SET TipoCondicion='RP',TipoServicio='P'
WHERE IdMatricula=652677
--(1 row affected)
--RP/P