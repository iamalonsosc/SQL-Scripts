--select*from SeccionHorario 
--HUALPA COTITO ERICK JOSUE
--https://outlook.office365.com/owa/?itemid=AAMkAGQxMWQwYmNjLTJjMDgtNGJjYi1hODBkLWQzYzUxOTlmNDBjOQBGAAAAAADRrbQCGi%2BVRbtH4V9%2Fak%2BTBwAKIQnDH1aNTqyliVQ4wiLlAAAAAAENAAAKIQnDH1aNTqyliVQ4wiLlAAAHN%2FhUAAA%3D&exvsurl=1&path=/calendar/item
UPDATE SeccionHorario SET UrlClaseVirtual='https://teams.microsoft.com/meet/296830488700530?p=5yFf0ssh8cZ0Z4AdJv'
WHERE IdSeccion=414342