---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--����������������������������������������������������������������������������                                                      
--Creado por      :Miguel Gargurevich (13/08/2012)                                                          
--Funcionalidad   :Obtiene las asistencia de los Alumnos seg�n los criterios  
--Utilizado por   :AlumnoCursoNota.SelListarLis                
--����������������������������������������������������������������������������           
/*      
-----------------------------------------------------------------------------      
Nro  FECHA			USUARIO				DESCRIPCION   
@1	 24/05/2019		Eloy Alva(Sigcomt)  Busqueda del HorarioSesion Fecha por CompaniaSocio
@2	 01/06/2020		Jhonny Cure			Se agregaron campos
@3   19/01/2021		Ealva				Agrego parametro para habilitar companiasocio 00002700 IDAT
@4	 26/01/2021		Ealva				Agrego campos Fecha de la Sesion y el nombre del dia de la sesion.
@5   01/02/2021		PUchuya				Agrega parametro fechainicio y fechafin
@6	 05.05.2021		EHuillca			Se modifica validaci�n por per�odo.	
@7   26.05.2021     PUchuya             Se modifica filtro por fechas y relaciona sesion con facilitador
@8   22.06.2022     JCure               Se agrega setnocount
@9	 2022.08.17		jmota				se agrega fecha de inicio y fin del periodo o programa
@10	 2022.08.24	    jmota				se agrega fecha de inicio y fin de la seccion
-----------------------------------------------------------------------------      
*/                                     
--ALTER PROCEDURE [dbo].[cNotaReporte_Rpt_NOT00023]                     
DECLARE 
@IdEmpresa INT,        
@IdSede INT,        
@IdFacultad INT,        
@IdUnidadNegocio INT,        
@IdUnidadAcademica INT,        
@IdPeriodo INT,        
@IdProducto INT,         
@IdPromocion INT,        
@IdGrupo INT,         
@IdAlumno INT,
@FechaInicio VARCHAR(10)= NULL, --@5
@FechaFin VARCHAR(10) = NULL --@5
--AS
select @IdEmpresa=1,@IdSede=-1,@IdFacultad=1,@IdUnidadNegocio=1,@IdUnidadAcademica=60,@IdPeriodo=3183,
@IdProducto=-1,@IdPromocion=-1,@IdGrupo=-1,@IdAlumno=0,@FechaInicio='20220420',@FechaFin='20220501'
BEGIN
	DECLARE @CompaniaSocio CHAR(8) -- @1
	DECLARE @Codigo VARCHAR(20)

	SET NOCOUNT ON--@8

	SELECT @CompaniaSocio=CompaniaSocio FROM Empresa WITH (NOLOCK) WHERE IdEmpresa=@IdEmpresa  -- @1 --@5
	SELECT @Codigo = Codigo FROM Periodo WITH (NOLOCK) WHERE IdPeriodo = @IdPeriodo

    IF @FechaInicio = '' SET @FechaInicio = NULL --@7
    IF @FechaFin = '' SET @FechaFin = NULL --@7

	SELECT 
	'Sede'=SE.Nombre,  
	'Division'=UN.Nombre,    
	'Programa'=UA.Nombre,  
	'Periodo'=PER.Codigo,     
	'Producto'=PR.ProductoNombre,  
	'Semestre'=ISNULL(CM.Codigo,''),  
	'Promocion'=P.PromocionCodigo,                
	'Seccion'=PG.GrupoCodigo,     
	'CursoCodigo'=SC.Codigo,--@2
	'Curso'=C.CursoNombre,                 
	'Aula'=ISNULL(AM.Nombre,''),
	'Frecuencia'=ISNULL(PG.DiaClaseTexto,'') +' '+ dbo.gHhMmStr(PG.HoraInicio) +'-' +dbo.gHhMmStr(PG.HoraFin),  
	'Turno'=ISNULL(TU.Nombre,''),               
	'Tutor'= SUBSTRING(ISNULL(TT.NombreCompleto,''),1,200),     
	'CodigoAlumno'=ISNULL(AL.CodigoAnterior,''),  
	'NombreAlumno'=A.NombreCompleto,              
	'Telefono'=dbo.cActorTelefonoStr(a.idActor),
	'EmailInstitucional'=al.EmailInstitucion,
	'EmailPersonal'=dbo.cActorEmailStr(a.idActor),
	'Direccion'=dbo.cActorDireccionStr(a.idActor),
	'Estado'=ISNULL(AC.Estado,'') ,  
	'Facilitador'=AA.NombreCompleto,               
	'SesionNumero'=HS.Numero,
	'Fecha'=dbo.Fecha(HS.Fecha),	
	'Inicio'=dbo.gHhMmStr(HS.Inicio),		
	'Fin'=dbo.gHhMmStr(HS.Fin),		
	'Asistencia'=ISNULL(ACA.Valor,''),
	'Observacion'=CASE WHEN ISNULL(ACA.Observacion,'')!='Marcado autom�tico. EnlaceWebex' THEN 'Marcaci�n Regular' ELSE ISNULL(ACA.Observacion,'') END,--@2
	'FechaSesion'=Convert(Varchar,HS.FECHA,103),--@4
	'DiaSemana'=DATENAME(dw,HS.FECHA),--@4
	'FechaInicioPeriodo'= CASE WHEN UN.TipoServicio = 'C' THEN CONVERT(VARCHAR,PER.Inicio,103) ELSE  CONVERT(VARCHAR,P.FechaInicioPeriodo,103)   END , -- @9
	'FechaFinPeriodo' = CASE WHEN UN.TipoServicio = 'C' THEN CONVERT(VARCHAR,PER.Fin,103) ELSE  CONVERT(VARCHAR,P.FechaFinPeriodo,103)   END, -- @9
    'FechaInicioSeccion'= CONVERT(VARCHAR,SC.FechaInicio ,103)  , -- @10
	'FechaFinSeccion' = CONVERT(VARCHAR,SC.FechaFin,103) -- @10
	FROM AlumnoCurso AC WITH (NOLOCK)                         
	INNER JOIN Alumno AL WITH (NOLOCK)ON AC.IdAlumno=AL.IdAlumno              
	INNER JOIN Actor A WITH (NOLOCK)ON AC.IdAlumno=A.IdActor               
	INNER JOIN Curso C WITH (NOLOCK)  ON AC.IdCurso=C.IdCurso              
	INNER JOIN Promocion P WITH (NOLOCK)  ON P.IdPromocion = AC.IdPromocion  
	INNER JOIN Sede SE WITH (NOLOCK)ON SE.IdSede = P.IdSede              
	INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON AC.IdPromocion = PG.IdPromocion AND AC.IdGrupo = PG.IdGrupo  
	LEFT OUTER JOIN Actor TT WITH (NOLOCK) ON PG.IdTutor = TT.IdActor    
	INNER JOIN Producto PR  WITH (NOLOCK) ON P.IdProducto =PR.IdProducto               
	INNER JOIN UnidadAcademica UA  WITH (NOLOCK) on p.IdUnidadAcademica =UA.IdUnidadAcademica               
	INNER JOIN UnidadNegocio  UN   WITH (NOLOCK) ON P.IdUnidadNegocio =UN.IdUnidadNegocio               
	INNER JOIN Periodo PER WITH (NOLOCK) ON  P.IdPeriodo =PER.IdPeriodo              
	INNER JOIN SeccionProfesor SP WITH (NOLOCK)ON AC.IdSeccion=SP.IdSeccion                     
	INNER JOIN Actor AA WITH (NOLOCK)ON SP.IdActor = AA.IdActor         
	LEFT JOIN CurriculaModulo CM WITH (NOLOCK)ON CM.IdModulo = P.IdModulo and CM.IdCurricula = P.IdCurricula  
	INNER JOIN HorarioSesion HS WITH (NOLOCK) ON AC.IdSeccion=HS.IdSeccion AND SP.IdActor = ISNULL(HS.IdActorReemplazo,HS.IdActorProgramado) --@7
	LEFT JOIN AlumnoCursoAsistencia ACA WITH (NOLOCK)ON HS.IdSeccion=ACA.IdSeccion AND HS.IdHorario=ACA.IdHorario AND HS.IdSesion=ACA.IdSesion AND AC.IdAlumno=ACA.IdAlumno
	INNER JOIN Seccion SC WITH (NOLOCK)ON AC.IdSeccion=SC.IdSeccion
	LEFT JOIN Ambiente AM WITH (NOLOCK)ON SC.IdAmbiente=AM.IdAmbiente
	LEFT JOIN Turno TU WITH (NOLOCK) ON SC.IdTurno=TU.Idturno    
	WHERE P.IdEmpresa=@IdEmpresa
	AND (P.IdSede=@IdSede OR @IdSede = -1)--@6
	AND P.IdFacultad=@IdFacultad
	AND (P.IdUnidadNegocio=@IdUnidadNegocio OR @IdUnidadNegocio = -1)   
	AND (P.IdUnidadAcademica=@IdUnidadAcademica OR @IdUnidadAcademica = -1)          
	AND (PER.Codigo=@Codigo OR @IdPeriodo= -1)   --@6       
	AND (P.IdProducto=@IdProducto OR @IdProducto= -1)         
	AND (P.IdPromocion=@IdPromocion OR @IdPromocion=-1)         
	AND (AC.IdGrupo=@IdGrupo OR @IdGrupo=-1)          
	AND (AC.IdAlumno=@IdAlumno OR @IdAlumno<=0)        
	AND CONVERT(VARCHAR,HS.Fecha,112)<=CONVERT(VARCHAR,GETDATE(),112) --@7
	AND ((CONVERT(VARCHAR,HS.Fecha,112) BETWEEN CONVERT(VARCHAR,CONVERT(DATE,@FechaInicio),112) AND CONVERT(VARCHAR,CONVERT(DATE,@FechaFin),112)) OR (@IdPeriodo <> -1 AND @FechaInicio IS NULL AND @FechaFin IS NULL))--@5 --@7
	AND AC.EsMatricula=1                
	AND AC.TipoCondicion IN('RE','CC')  
	--AND SP.EsResponsable=1 --@7
	ORDER BY P.PromocionCodigo,PG.GrupoCodigo,C.CursoNombre,HS.Numero,A.NombreCompleto

END

