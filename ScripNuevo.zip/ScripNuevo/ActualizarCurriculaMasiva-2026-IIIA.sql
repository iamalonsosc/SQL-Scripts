DECLARE @PERIODO VARCHAR(10) ='2026-IIIA'
--select 'VALIDAR INCOHERENCIAS DE IdCurricula ENTRE Matricula - AlumnoCurso - AlumnoCurriculaCurso'
UPDATE AC SET IdCurricula = S.IdCurricula, IdCurriculaOriginal = M.IdCurricula
--SELECT 
--	M.IdMatricula AS [IdMatricula_M], M.EsMatricula AS [EsMatricula_M], M.IdPromocion AS [IdPromocion_M], P.PromocionCodigo AS [PromocionCodigo_P], P.PromocionNombre AS [PromocionNombre_P], 
--	PG.IdGrupo AS [IdGrupo_PG], PG.GrupoCodigo AS [GrupoCodigo_PG], M.IdCurricula AS [IdCurricula_M], CM.Codigo AS [Codigo_CM], P.IdCurricula AS [IdCurricula_P], CP.Codigo AS [Codigo_CP], 
--	UN.Nombre AS [Nombre_UN], UA.Nombre AS [Nombre_UA], PR.Codigo AS [Codigo_PR], AL.CodigoAnterior AS [CodigoAnterior_AL], A.NombreCompleto AS [NombreCompleto_A], AC.IdAlumno AS [IdAlumno_AC], 
--	AC.IdRegistro AS [IdRegistro_AC], AC.IdAlumnoCurso AS [IdAlumnoCurso_AC], AC.EsMatricula AS [EsMatricula_AC], AC.IdPromocion AS [IdPromocion_AC], PAC.PromocionCodigo AS [PromocionCodigo_PAC], 
--	PAC.PromocionNombre AS [PromocionNombre_PAC], PGAC.GrupoCodigo AS [GrupoCodigo_PGAC], AC.IdCurso AS [IdCurso_AC], AC.IdCursoOriginal AS [IdCursoOriginal_AC], AC.IdCurricula AS [IdCurricula_AC], 
--	CAC.Codigo AS [Codigo_CAC], AC.IdCurriculaOriginal AS [IdCurriculaOriginal_AC], COAC.Codigo AS [Codigo_COAC], PAC.IdCurricula AS [IdCurricula_PAC], CPAC.Codigo AS [Codigo_CPAC], 
--	S.Codigo AS [Codigo_S], S.IdCurso AS [IdCurso_S], CS.CursoNombre AS [CursoNombre_CS], S.IdPromocion AS [IdPromocion_S], S.IdCurricula AS [IdCurricula_S], ACC.IdCurso AS [IdCurso_ACC], 
--	ACC.IdCurricula AS [IdCurricula_ACC], AC.EsMatricula, AC.UsuarioCreacion, AC.FechaCreacion, AC.UsuarioModificacion, AC.FechaModificacion
	------, *
FROM Matricula M
	JOIN Actor A ON M.IdActor = A.IdActor
	JOIN Promocion P ON M.IdPromocion = P.IdPromocion
	JOIN PromocionGrupo PG ON P.IdPromocion = PG.IdPromocion AND M.IdGrupo = PG.IdGrupo
	JOIN Periodo PR ON P.IdPeriodo = PR.IdPeriodo
	LEFT JOIN Alumno AL ON M.IdActor = AL.IdAlumno
	LEFT JOIN UnidadNegocio UN ON P.IdUnidadNegocio = UN.IdUnidadNegocio
	LEFT JOIN UnidadAcademica UA ON P.IdUnidadAcademica= UA.IdUnidadAcademica
	LEFT JOIN Curricula CM ON M.IdCurricula = CM.IdCurricula
	LEFT JOIN Curricula CP ON P.IdCurricula = CP.IdCurricula
	LEFT JOIN AlumnoCurso AC ON M.IdMatricula = AC.IdMatricula
	LEFT JOIN Promocion PAC ON AC.IdPromocion = PAC.IdPromocion
	LEFT JOIN PromocionGrupo PGAC ON AC.IdPromocion = PGAC.IdPromocion AND AC.IdGrupo = PGAC.IdGrupo
	LEFT JOIN Periodo PRAC ON PAC.IdPeriodo = PRAC.IdPeriodo
	LEFT JOIN Seccion S ON AC.IdSeccion = S.Idseccion
	LEFT JOIN Curricula CAC ON AC.IdCurricula = CAC.IdCurricula
	LEFT JOIN Curricula COAC ON AC.IdCurriculaOriginal = COAC.IdCurricula
	LEFT JOIN Curricula CPAC ON PAC.IdCurricula = CPAC.IdCurricula
	LEFT JOIN Curso CS ON S.IdCurso = CS.IdCurso

	LEFT JOIN AlumnoCurriculaCurso ACC ON ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) = ACC.IdCurricula AND AC.IdAlumno = ACC.IdAlumno AND ISNULL(AC.IdCursoOriginal, AC.IdCurso) = ACC.IdCurso 
		AND AC.IdRegistro = ACC.IdRegistro
WHERE
	 PR.IdPeriodoAnual > 2025
	AND
	M.EsMatricula = 1
	AND
	AC.EsMatricula = 1
	AND
	P.IdUnidadNegocio = 1
	AND
	PR.Codigo = @PERIODO
	AND
	S.Idseccion IS NOT NULL
	AND 
	( 
		AC.IdCurricula != S.IdCurricula 
		OR
		ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) != M.IdCurricula
		OR
		M.IdCurricula != P.IdCurricula
	)
	AND ACC.IdCurricula IS NULL
--ORDER BY A.NombreCompleto, P.PromocionNombre