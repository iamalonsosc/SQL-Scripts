SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=647066


SELECT TipoCondicion,*FROM AlumnoCurso 
--UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=647066 AND EsMatricula=1

--SELECT DISTINCT TipoCondicion  FROM Matricula