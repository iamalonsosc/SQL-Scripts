--SELECT*FROM Registro 
UPDATE Registro SET Estado='X'
WHERE IdRegistro=3
AND IdActor=1658245
--(1 row affected)

--SELECT*FROM TrasladoSede
UPDATE TrasladoSede SET Estado=0
WHERE IDTrasladoSede=16891
--(1 row affected)

DELETE FROM Convalidacion 
WHERE IdConvalidacion=44055
--(1 row affected)