USE AcademicoIDAT;

GO

-- ############### PARTE 01 - 2 ##################


UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 714384
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';

UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 709093
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'GESTIÓN DE PERSONAS';

UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 709074
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'GESTIÓN DE PERSONAS';



















