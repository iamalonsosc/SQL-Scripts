
INSERT INTO CO_Interfase_P09_Header(TipoDocumento, FechaVencimiento, TipoVenta, TipoFacturacion, EstablecimientoCodigo, Cliente, ClienteCobrarA, Criteria, Monedacodigo, 
	Sucursal, vendedor, FechaPreparacion, Estado, FlagActualizacion, NotaCreditoDocumento, Descuento, IdMatricula, serie, NumeroDocumento, CuotaNumero, EstadoSmart, 
	FechaRetorno, Campania, Periodo, Area, FechaCobranza, FlagCursoCargo, TipoServicio, CondicionPago, FechaModificacion, EsMatricula, NumeroInternoAnterior, CodigoAlumno, 
	CondicionMatricula, FechaProcesoImp, Grupodescuento, GrupoTipo, Interfase_Captacion, pcdescuento, NroCuotas, CompaniaSocio, fechainterfase, TipoCliente, TransGratuita, 
	pcAutomatico)
SELECT TipoDocumento, '20250717' AS 'FechaVencimiento', TipoVenta, TipoFacturacion, EstablecimientoCodigo, Cliente, ClienteCobrarA, Criteria, Monedacodigo, Sucursal, 
	vendedor, FechaPreparacion, Estado, FlagActualizacion, NotaCreditoDocumento, Descuento, IdMatricula, serie, NumeroDocumento, 6 AS 'CuotaNumero', EstadoSmart, 
	FechaRetorno, Campania, Periodo, Area, FechaCobranza, FlagCursoCargo, TipoServicio, CondicionPago, GETDATE() AS 'FechaModificacion', EsMatricula, NumeroInternoAnterior,
	CodigoAlumno, CondicionMatricula, FechaProcesoImp, Grupodescuento, GrupoTipo, Interfase_Captacion, pcdescuento, NroCuotas, CompaniaSocio, fechainterfase, TipoCliente,
	TransGratuita, pcAutomatico
FROM CO_Interfase_P09_Header
WHERE CompaniaSocio = '00002500' AND IdMatricula = 260022742 AND CuotaNumero = 5
--(1 row affected)


DECLARE @NumeroInterno INT

SELECT @NumeroInterno = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (260022742) AND CuotaNumero = 6

INSERT INTO CO_Interfase_P09_Detalle(TipoDocumento, NumeroInterno, secuencia, TipoDetalle, ItemCodigo, CantidadPedida, Descripcion, Estado, MontoOriginal, Monto, 
	CantidadOriginal, NumeroInternoAnterior, CompaniaSocio, UltimoUsuario, UltimaFechaModificacion, FormularioModificacion)
SELECT TipoDocumento, @NumeroInterno AS 'NumeroInterno', 10 AS 'secuencia', TipoDetalle, ItemCodigo, CantidadPedida, Descripcion, Estado, MontoOriginal, Monto, 
	CantidadOriginal, NumeroInternoAnterior, CompaniaSocio, 'DESIDAT' AS 'UltimoUsuario', GETDATE() AS 'UltimaFechaModificacion', '' AS 'FormularioModificacion'
FROM CO_Interfase_P09_Detalle
WHERE CompaniaSocio = '00002500' AND TipoDocumento = 'BV' 
	AND NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula = 260022742 AND CuotaNumero = 5)
ORDER BY TipoDocumento, NumeroInterno, secuencia
--(1 row affected)


SELECT *
FROM CO_Interfase_P09_Header 
WHERE CompaniaSocio = '00002500' AND IdMatricula = 260022742
ORDER BY CuotaNumero

SELECT *
FROM CO_Interfase_P09_Detalle 
WHERE CompaniaSocio = '00002500' AND TipoDocumento = 'BV' 
	AND NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE CompaniaSocio = '00002500' AND IdMatricula = 260022742)
ORDER BY secuencia
