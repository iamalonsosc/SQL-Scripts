--����������������������������������������������������������������������������  
--Creado por : Jimy Mota (06/06/2017)  
--Funcionalidad : Permite listar los descuento validos para un actor  
--Utilizado por : DescuentoAcademico.ValPoblacionAlumno  
--Proyecto  : Descuento academico    
--����������������������������������������������������������������������������  
/*  
-----------------------------------------------------------------------------  
Nro		FECHA				USUARIO				DESCRIPCION  
-----------------------------------------------------------------------------  
@1		2018.09.11			jmota				se agrega campos para colaboradores utp,idat,corriente alterna   
@2		2018.10.22			jmota				se agrega condicion para egresados de carrera y diplomado   
@3		2018.10.24			mota				se resta 45 dias a la fecha de inicio del periodo por el espacio entre periodos   
@4		2018.10.31			jmota				se agrega condicion para incluir a los egresados del a�o actual    
@5		2018.11.16			jmota				se agrega condicion para incluir a los matriculados en aulas de lima norte y ate puruchuco   
@6		2019.01.10			rpineda				se modifica los a�os en el descuento   
@7		2019.03.22			rpineda				se reversa la modificacion @6   
@8		2019.05.08			ehuaman				se configura base de consulta ALUMNOS INTERCORP, EGRESADO CARRERA, RPC    
@9		2019.09.06			yflores				se agrega condici�n para conocer si un profesor esta dictando clases actualmente    
@10		2019.09.26			yflores				se agrega para no consultar la BD de Gupta para Corriente Alterna  
@11		2019.10.29			yflores				se agrega descuento para alumnos matriculados en todas las sesiones de talleres  
@12		2019.11.13			yflores				se modifica logica de descuento para alumnos matriculados en todas las sesiones de talleres  
@13		2019.11.22			jmota				ALUMNOS DE UNIVERSIDADES NO LICENCIADAS E INSTITUTOS  
@14		2019.11.25			jmota				Leer a�o de agreso colegio desde Interesado y Actor  
@15		2019.11.25			jmota				validacion para reingresantes captacion   
@16		2019.11.28			jmota				se soluciona error de colegio   
@17		2019.11.28			jmota				se consulta red de colegio desde la tabla interesado  
@18		2020.02.26			jcure				se resta 60 en lugar de 45 dias a la fecha de inicio del periodo por el espacio entre periodos  
@19		2020.05.20			puchuya				se agrega descuento para alumnos matriculados por producto, un curso y dos cursos   
@20		2020.05.20			puchuya				se corrige descuento para alumnos matriculados por producto, un curso y dos cursos   
@21		2020.09.15			jcure				se agrega condicion para alumnos matriculados en 2020 IB   
@22		2020.09.16			puchuya				se agrega descuentos para alumnos matriculados en 2 o 3 periodos seguidos, en dos y tres productos con mismo precio  
@23		2020.09.22			puchuya				se valida solo periodos en base al descuento poblacion destino  
@24		2020.10.06			puchuya				se agrega descuento para todos los docentes vigentes, alumno matriculados en presente a�o y por contado/producto  
@25		2020.10.12			puchuya				se agrega validaciones para descuentos alumnos matriculados en el a�o actual y que sea solo por producto  
@26		2020.10.13			puchuya				se agrega validacion para descuento alumnos matriculados que sea solo carrera  
@27		2020.10.13			jmota				debe consultar primero la base academica  
@28		2020.10.20			jmota				se valida para aceptar valores nulos  
@29		2020.10.29			jnavia				se agrega en la condici�n el a�o actual  
@30		2020.11.09			jmota				Cambio temporal pedido por jcontreras por errores en zegel  
@31		2020.11.12			jmota				se corrige base de consulta reingresante modulo 1 y con 5 o mas cursos   
@32		2021.01.12			jmota				se agrega logica de descuento america tv para zegel e idat y se amplia a 2 a�os logica de egresado de colegio  
@33		2021.04.02			hmora				se agrega condicion para alumnos con descuento de reserva  
@34		2021.12.02			hmora				se agrega condicion para descuentos de alumnos egresados convalidacion Bachiller  
@35		2021.02.18			jmota				se agrega condicion para becas socioeconomicas idat  
@36		2021.02.19			hmora				se agrega usuarios para descuentos con reserva  
@37		2021.03.18			ealva				Se parametriza los usuarios para descuentos con reserva  
@38		2021.03.29			puchuya				se agrega descuento alumnos matriculados de programas libres para peac  
@39		2021.03.31			jmota				Se agrega TIPIDAT002 ALUMNOS DE CAPTACION Y SECUENCIAL I SEMESTRE MAYOR O IGUAL A 5 CURSOS  
@40		2021.04.20			hcachi				Se agrega condicion TIPZEG002 DESCUENTO ACTIVATE PERU PUBLICO/PRIVADO  
@41		2021.06.04			jmota				Se agrega condicion de captacion de tipo manual   
@42		2021.07.04			hmora				Se agrega condicion de BECA ACTIVATE SECUENCIAL PUBLICO/PRIVADO  
@43		2021.09.09			jnavia				Se agrega condicion para los alumnos de Arequipa y Cusco de carrera del periodo 2021-II  
@44		2021.09.16			jmota				se agrega logica para BECA ACTIVATE SECUENCIAL   
@45		2021.09.16			jmota				se agrega logica para BECA ACTIVATE SECUENCIAL POR BASE CONSULTA  
@46		2021.11.11			puchuya				se agrega condicion peac virtual para TIPMATPLPV  
@47		2021.12.03			RSamame				Se agrega logica para secuenciales BECA ACTIVATE   
@48		2021.12.03			RSamame				Se REFUEZA LA VALIDACION logica para secuenciales BECA ACTIVATE   
@49		2021.12.14			RSamame				Se REFUEZA LA VALIDACION logica para secuenciales BECA ACTIVATE PAGO PUNTUAL   
@50		2022.01.05			Jmota				se agrega logica para no tomar en cuenta cambios de malla oficial idat  
@51		2022.02.28			JCure				se agrega logica para alumnos matriculados en el periodo 2021-II.   
@52		2022.03.04			JCure				se agrega logica para alumnos matriculados en el periodo 2021-IIA.  
@53		2022.03.11			RSamame				Se REFUEZA LA VALIDACION logica para secuenciales BECA ACTIVATE   
@54		2022.03.11			RSamame				Se REFUEZA LA VALIDACION logica para secuenciales BECA ACTIVATE promedios pronderados  
@55		2022.03.16			JCure				se agrega logica para alumnos matriculados en el periodo 2021-IIA.  
@56		2022.04.01			PUchuya				Se corrige condicion alumnos  egresados convalidacion Bachiller  
@57		2022.04.06			RSamame				Se REFUEZA LA VALIDACION logica para secuenciales BECA ACTIVATE promedios pronderados menores que 18  
@58		2022.05.03			Jmota				Se Adecua Logica para alumnos de Primer ciclo captaci�n BECA ACTIVATE 2 Ciclos  
@59		2022.05.10			Jmota				Se agrega validacion para que no asigne descuento cuando un alumno es repitente   
@60		2022.07.12			EHuillca			Se agrega validaci�n para matricula por curso.  
@61		2022.07.21			puchuya				Se modifica idtipoconsulta para colaboradores utp,idat,corriente alterna  
@62		2022.08.08			puchuya				Se agrega logica para alumnos del 2022-I al 2022-II  
@63		2022.09.02			puchuya				Se agrega nueva condicion BECA AMERICA TV SECUENCIAL FOCALIZADA 50% A 25%  
@64		2022.09.09			jmota				se aplica nuevas validaciones de BECA AMERICA TV SECUENCIAL y para corrriente alterna  
@65		2022.09.12			puchuya				Se trae valor Tiposervicio de la matricula  
@66		2022.09.15			jmota				se agrega validacion de reingresante(dejar de estudiar por lo menos un periodo)  para beca activate  
@67		2022.09.09			puchuya				se agrega validacion cuando no valide si el alumno no es un reingresante  
@68		2022.09.27			jmota				se agrega nueva base de alumnos para IDAT  
@69		2022.10.25			illosad				se agrega validacion para turno, retiro y cambio de sede  
@70		2023.01.05			mbueno				se valida requisitos en idat  
@71		2023.01.11			fetorres			se agrega una validacion donde si la sede y la sede de origen de la tabla TrasladoSede son diferentes el alumno merece la beca.   
@72		2023.01.24			jmota				se agrega nueva base de prospectos egresados de colegio a�o actual y 5 a�os atras tk 38495  
@73		2023.01.25			puchuya				se quita de la base de intercorp el programa ZEGEL VIRTUAL  
@74		2023.04.10			puchuya				se quita de la base de sin validacion captacion y secuencial el programa ZEGEL VIRTUAL  
@75		2023.05.08			mbueno				se agrega logica cambio de turno en idat para excluir a un grupo determinado  
@76		2023.05.19			fetorres			se elimina las carrera que son de AS400  
@77		2023.05.26			MBUENO				Se agrega logica para alumnos sin descuentos que tienen cronograma alterna  
@78		2023.07.20			AlSanchez			Se agrega logica para Nuevos Tipos de Consultas Requeridos para Zegel e Idat: TIP0000022, TIP0000023, TIP0000024, TIP0000025  
@79		2023.07.31			Fetorres			Se agrega logica para Nuevos Tipos de Consultas Requeridos para Idat: TIP0000026  
@80		2023.08.09			lpariona			Se comenta filtro de id@80at  
@81		2023.08.28			EHuillca			Se agrega l�gica para excluir descuentos por cambio de sede  
@82		2023.12.20			JQuenta				Se agrega logica para Nuevo Tipo de Consulta Requerido para Zegel: DSC30DIPZG  
@83		2024.01.10			ALSANCHEZ			Se retira el NOT   
@84		2024.01.10			ALSANCHEZ			Se agrega el cambio de producto y nuevo tipo descuento en Idat:TIP0000032  
@85		2024.03.05			JQuenta				Se comenta IdSeccion IS NOT NULL de la Glosa "ALUMNOS DE C/S I SEMESTRE - REINGRESANTES NO REPITENTES >= 5 CURSOS" para Listar Descuentos en la PreMatricula sin la necesidad de Grabar  
@86		2024.03.08			LPARIONA			Se agrega la validacion de BECA para Zegel  
@87		2024.03.15			Mquiroz				Se agrega la validacion para ITS  
@88		2024.04.08			JQuenta				Se agrega logica para Nuevo Tipo de Consulta Requerido para Zegel: TIPMATSECZ  
@89		2024.05.06			ALSANCHEZ			Se agrega nueva logica para las becas Activate  
@90		2024.01.28			LParionna			Se quita tabla matricula de la validacion de descuentos, para asigancion de descuentos manuales  
@91		2025.02.19			ALSANCHEZ			Nuevo codigo de descueto beca activate para CORRIENTE ALTERNA  
@92		2025.02.19			LPariona			Se excluye temporalmente la validacion de beca activate para zegel  
@93		2025.03.06			ALSANCHEZ			Se agrega condicion OR por el TipoServicio sea producto o curso  
@94		26/09/2025			JQuenta				Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil  
@95		2025.08.26			ALSANCHEZ			Se agrega nuevos codigos de descuento para IDAT 49 y 50  
@96		2026.02.17			MTAIPE				Se agrega la compa�iasocio para poder validar CA
*/  
alter PROCEDURE [dbo].[cDescuentoAcademico_Val_PoblacionAlumno]   
@IdDescuentoAcademico INT,    
@IdTipoConsulta INT, --BASE DE CONSULTA - MAESTROTABLAREGISTRO  1905   
@IdActor INT,    
@TipoMatricula VARCHAR(MAX), --AMBOS CAPTACI�N SECUENCIAL   
@IdPeriodo INT = NULL,   
@UsuarioCreacion  INT = NULL, --Usuario que consulta el descuento   
@IdConvenio INT = NULL,   
@IdMatricula INT = NULL,    
@TipoServicio CHAR(1) = NULL,   
@Retorno INT OUTPUT, -- 0 No existe / 1 Existe   
@CompaniaSocio CHAR(8)    
AS    
BEGIN  
   declare @CompaniaSocioAcademico CHAR(8)    --@96
 --Inicio --@94  
 SET NOCOUNT ON   
   select @CompaniaSocioAcademico=CompaniaSocio from Empresa where IdEmpresa=1  --@96

 DECLARE   
 @IdCurricula INT,  
 @IdModulo INT,    
 @CantidadCursosCurricula INT,    
 @PorLlevar INT,    
 @Matriculados INT,   
 @TipoCondicion VARCHAR(10),   
 @NumeroIdentidad VARCHAR(20),   
 @CodigoMaestroRegistro VARCHAR(100),   
 @IdPeriodoAnterior INT,   
 @IdSede INT,    
 @IdUnidadNegocio INT,    
 @IdUnidadAcademica INT,   
 @NumeroCursosCurricula INT, --@11   
 @NumeroCursosAlumno INT, --@11   
 @IdPromocion INT, --@11   
 @IdGrupo INT, --@11   
 @CodigoTipoConsulta VARCHAR(30), --@19   
 @PeriodoCodigo VARCHAR(100), -- @28   
 @IdDocumentoTipo INT, -- @28   
 @IdColegio INT,  
 @ListaUsuario Varchar(100), --@37  
 @TipoMat VARCHAR(2), --@42  
 @IdRegistro INT, --@42    
 @IdModuloAnt INT, --@42  
 @IdMatriculaAnt INT, --@42  
 @PromedioReal REAL, --@42  
 @GrupoDescuentoValidar INT,   
 @GrupoDescuentoLista VARCHAR(500),  
 @IdEmpresaZV INT, --@73  
 @EsIntercorp BIT, --@74  
 @EsAutomatico BIT, --@74  
 @ServidorVinculado VARCHAR(50),  
 @BaseDatos VARCHAR(50),  
 @ParamCadSql NVARCHAR(MAX),  
 @CadSql NVARCHAR(MAX)  
  
 SET @Retorno = 0    
  
 --@37  
 DECLARE @UsuariosDescuentos AS TABLE  
 (  
  IdUsuario INT  
 )  
 --@37  
   
 --@22  
 DECLARE  
 @CantPeriodos INT,  
 @CantMatriculas INT,  
 @MontoProducto DECIMAL(5,2),  
 @IdActorPagante INT,  
 @Sucursal VARCHAR(4)  
 --@22  
  
 --@19  
 SELECT  
  @CodigoTipoConsulta = Codigo  
 FROM MaestroTablaRegistro WITH (NOLOCK)  
 WHERE IdMaestroRegistro = @IdTipoConsulta  
 --@19  
  
 DECLARE  
 @IdCurriculaOrigen INT    
   
 IF @TipoMatricula = 'SECUENCIAL'   
 BEGIN  
  
  --Validamos que el alumno sea secuencial (SI EL ALUMNO NO ES SECUENCUAL SE ELIMINA)   
  IF NOT EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula WITH (NOLOCK)  
   WHERE IdActor = @IdActor  
   AND Estado <> 'X'  
   AND IdPeriodo = @IdPeriodo  
  )  
  BEGIN  
  
   SET @Retorno = 0   
   RETURN @Retorno   
  
  END  
  
 END   
  
 IF  
 (  
  (  
   @CompaniaSocio = '00002500'  
   OR @CompaniaSocio = '00002400' --@87  
  )  
  AND @CodigoTipoConsulta = 'AMPDS21IIA'  
 )  
 BEGIN  
  
  SELECT  
   @IdRegistro = IdRegistro  
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)   
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion     
   INNER JOIN Periodo PE WITH(NOLOCK) ON P.idperiodo = PE.idperiodo       
   WHERE M.IdActor = @IdActor  
   AND M.IdRegistro = @IdRegistro    
   AND M.Estado = 'N'  
   AND EsMatricula = 1     
   AND PE.Codigo = '2021-IIA' --@55  
  )   
  BEGIN  
  
   SET @Retorno = 1  
   RETURN @Retorno    
  
  END  
  
 END  
   
  
 IF  
 (  
  (  
   @CompaniaSocio = '00002500'  
   OR @CompaniaSocio = '00002400' --@87  
  )  
  AND @CodigoTipoConsulta = 'CAMPRE21II'  
 )  
 BEGIN  
  
  SELECT  
   @IdRegistro = IdRegistro  
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula     
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)    
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion=P.IdPromocion      
   INNER JOIN Periodo PE WITH (NOLOCK) ON P.Idperiodo = PE.Idperiodo       
   WHERE M.IdActor = @IdActor  
   AND M.IdRegistro = @IdRegistro    
   AND M.Estado = 'N'  
   AND EsMatricula = 1     
   AND PE.CODIGO IN  
   (  
    '2021-II', --@51  
    '2021-IIA' --@52  
   )  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno    
  
  END  
  
 END  
  
 --@62  
 IF  
 (  
  (  
   @CompaniaSocio = '00002500'  
   OR @CompaniaSocio = '00002400' --@87  
  )  
  AND @CodigoTipoConsulta = 'CAMPRE22I'   
 )  
 BEGIN  
  
  SELECT   
   @IdRegistro = IdRegistro  
  FROM Matricula WITH(NOLOCK)  
  WHERE IdMatricula = @IdMatricula     
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)   
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion     
   INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo       
   WHERE M.IdActor = @IdActor  
   AND M.IdRegistro = @IdRegistro    
   AND M.Estado = 'N'  
   AND EsMatricula = 1     
   AND PE.Codigo IN ('2022-I')  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
 --@62  
  
 --SI EL ALUMNO DE CAPTACI�N NO EXISTE VALIDACI�N (TIPO DE SITUACION ALUMNO CAPTACI�N)   
 IF @IdTipoConsulta = 23954 -- CAPTACI�N   
 BEGIN  
  
  SET @Retorno = 1   
  RETURN @Retorno  
  
 END    
  
 --SI EL ALUMNO DE CAPTACI�N NO EXISTE VALIDACI�N (TIPO DE SITUACION ALUMNO SECUENCIAL)   
 IF @IdTipoConsulta = 23955 --SECUENCIAL   
 BEGIN  
  
  SET @Retorno = 1   
  RETURN @Retorno  
  
 END    
  
 --SI EL ALUMNO DE ES UN REINGRESANTE PRIMER SEMESTRE    
 IF @IdTipoConsulta = 23956  
 BEGIN  
  
  --REINGRESO  
  IF dbo.cAlumnoReingresante(@IdActor,@IdPeriodo) = 1    
  BEGIN  
  
   SELECT  
    @IdPeriodoAnterior = IdPeriodoAnterior  
   FROM Periodo WITH (NOLOCK)  
   WHERE IdPeriodo  = @IdPeriodo  
  
   --SI SE MATRICULO EL PERIODO ANTERIOR   
   IF EXISTS  
   (   
    SELECT  
     1  
    FROM Matricula A WITH (NOLOCK)   
    LEFT JOIN Promocion PRO WITH (NOLOCK) ON PRO.IdPromocion = A.IdPromocion    
    LEFT JOIN Periodo P WITH (NOLOCK) ON P.IdPeriodo = PRO.IdPeriodo    
    INNER JOIN Sede S WITH (NOLOCK) ON S.IdSede = PRO.IdSede    
    INNER JOIN PRODUCTO PROD WITH (NOLOCK) on PROD.IdProducto = PRO.IdProducto    
    INNER JOIN MaestroTablaRegistro MTR_PRO WITH(NOLOCK) ON PROD.IdClasificacionProducto = MTR_PRO.IdMaestroRegistro  
    WHERE IdActor = @IdActor  
    AND PRO.IdPeriodo = @IdPeriodoAnterior    
    AND PRO.IdUnidadNegocio = 1   
    AND  
    (  
     MTR_PRO.Disponible1 = 'C'  
     AND MTR_PRO.Disponible2 = 'CAR'  
    )  
   )   
   BEGIN  
  
    --SI LA CONDICION NO ES 'RT','RP','CC'   
    IF EXISTS  
    (   
     SELECT  
      1  
     FROM Matricula WITH (NOLOCK)   
     WHERE IdMatricula = @IdMatricula  
     AND Estado <> 'X'  
     AND IdPeriodo = @IdPeriodo  
     AND EsMatricula = 0    
     AND TipoCondicion NOT IN ('RT','RP', 'CC')  
     AND TipoServicio = 'p'  
    )   
    BEGIN  
  
     SET @Retorno = 1   
     RETURN @Retorno  
  
    END  
  
   END   
   ELSE   
   BEGIN   
    
    SELECT  
     @IdMatricula = IdMatricula,    
     @IdCurricula = IdCurricula,   
     @IdModulo = IdModulo    
    FROM Matricula WITH (NOLOCK)    
    WHERE IdMatricula = @IdMatricula  
    AND Estado <> 'X'  
    AND IdPeriodo = @IdPeriodo  
    AND EsMatricula = 0  
  
    --OBTENEMOS CANTIDAD DE CURSOS DE LA CURRICULA   
    SELECT  
     @CantidadCursosCurricula = COUNT(1)  
    FROM CurriculaCurso WITH (NOLOCK)  
    WHERE IdCurricula = @IdCurricula  
    AND IdModulo = @IdModulo  
  
    --LOS CURSOS MATRICULADOS   
    SELECT  
     @Matriculados = COUNT(1)  
    FROM AlumnoCurso WITH (NOLOCK)  
    WHERE IdMatricula = @IdMatricula  
    AND IdSeccion IS NOT NULL  
  
    -- SI NO LLEVA TODOS LOS CURSOS NO TIENE DESCUENTO   
    IF @CantidadCursosCurricula <= @Matriculados  
    BEGIN  
  
     SET @Retorno = 1   
     RETURN @Retorno  
  
    END   
    ELSE   
    BEGIN  
  
     SET @Retorno = 0   
     RETURN @Retorno  
       
    END   
  
   END  
    
  END  
  
 END    
   
 --I EL ALUMNO ES REINGRESANTE DEL SEGUNDO SEMESTRE PARA ARRIBA  (grupo 332 )   
 --ALUMNOS REINGRESANTES DEL I SEMESTRE CON TODOS LOS CURSOS MATRICULADOS 30%   
 IF @IdTipoConsulta = 24902   
 BEGIN  
  
  --SI ES REINGRESANTE   
  IF dbo.cAlumnoReingresante(@IdActor,@IdPeriodo) = 1    
  BEGIN  
  
   IF EXISTS  
   (  
    SELECT  
     1  
    FROM Matricula WITH (NOLOCK)  
    WHERE IdMatricula = @IdMatricula  
    AND IdModulo = 1  
   )  
   BEGIN  
  
    SELECT    
     @IdMatricula = IdMatricula,    
     @IdCurricula = IdCurricula,   
     @IdModulo = IdModulo    
    FROM Matricula WITH (NOLOCK)    
    WHERE IdMatricula = @IdMatricula   
   
    --Cantidad de cursos que tiene la curricula   
    SELECT  
     @CantidadCursosCurricula = COUNT(1)  
    FROM CurriculaCurso WITH (NOLOCK)  
    WHERE IdCurricula = @IdCurricula  
    AND IdModulo = @IdModulo  
  
    --Cursos que se matriculo el alumno   
    SELECT  
     @Matriculados = COUNT(1)  
    FROM AlumnoCurso WITH (NOLOCK)  
    WHERE IdMatricula = @IdMatricula  
    AND IdSeccion IS NOT NULL   
   
    IF @CantidadCursosCurricula <= @Matriculados  
    BEGIN  
  
     SET @Retorno = 1   
     RETURN @Retorno  
  
    END   
    ELSE   
    BEGIN  
  
     SET @Retorno = 0  
     RETURN @Retorno  
  
    END  
  
   END   
   ELSE   
   BEGIN  
  
    --Para todos los demas semestre no tiene condicion   
    SET @Retorno = 0   
    RETURN @Retorno  
  
   END  
  
  END  
  
 END  
   
 --SI EL ALUMNO ES REINGRESANTE DEL SEGUNDO SEMESTRE PARA ARRIBA  (grupo 5 )   
 --ALUMNOS REINGRESANTES A PARTIR DEL SEGUNDO SEMESTRE 50% -  TAMBIEN INCLUYE I SEM   
 IF @IdTipoConsulta = 24728   
 BEGIN  
   
  --SI ES REINGRESANTE   
  IF dbo.cAlumnoReingresante(@IdActor,@IdPeriodo) = 1    
  BEGIN    
   
   IF EXISTS  
   (  
    SELECT  
     1  
    FROM Matricula WITH (NOLOCK)  
    WHERE IdMatricula = @IdMatricula  
    AND IdModulo = 1  
   )  
   BEGIN   
   
    SELECT    
     @IdMatricula = IdMatricula,    
     @IdCurricula = IdCurricula,   
     @IdModulo = IdModulo    
    FROM Matricula WITH (NOLOCK)    
    WHERE IdMatricula = @IdMatricula   
   
    --Cantidad de cursos que tiene la curricula   
    SELECT  
     @CantidadCursosCurricula = COUNT(1)  
    FROM CurriculaCurso WITH (NOLOCK)  
    WHERE IdCurricula = @IdCurricula  
    AND IdModulo = @IdModulo  
  
    --Cursos que se matriculo el alumno   
    SELECT  
     @Matriculados = COUNT(1)  
    FROM AlumnoCurso WITH (NOLOCK)  
    WHERE IdMatricula = @IdMatricula  
    AND IdSeccion IS NOT NULL  
   
    IF @Matriculados < @CantidadCursosCurricula  
    BEGIN  
  
     SET @Retorno = 1   
     RETURN @Retorno  
  
    END   
    ELSE   
    BEGIN  
  
     SET @Retorno = 0   
     RETURN @Retorno  
  
    END  
  
   END   
   ELSE   
   BEGIN  
  
    --Para todos los demas semestre no tiene condicion   
    SET @Retorno = 1   
    RETURN @Retorno  
  
   END  
  
  END  
  
 END    
   
 --SI EL ALUMNO PERTENECE AL CLUB INTERCORP   
 IF @IdTipoConsulta = 23959    
 BEGIN   
   
  SELECT  
   @NumeroIdentidad = NumeroIdentidad   
  FROM Actor WITH (NOLOCK)    
  WHERE IdActor = @IdActor   
   
  SET @Retorno = 0  
    
  SELECT  
   @Retorno = COUNT(1)   
  FROM IntercorpActor WITH (NOLOCK)   
  WHERE NumeroIdentidad = @NumeroIdentidad    
     
  --Inicio @73  
  SELECT  
   @IdEmpresaZV  = IdEmpresaZV  
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula  
  
  IF ISNULL(@IdEmpresaZV,0) <> 0  
  BEGIN  
  
   SELECT  
    @EsIntercorp = ISNULL(Disponible1,0)  
   FROM MaestroTablaRegistro WITH (NOLOCK)  
   WHERE IdMaestroRegistro = @IdEmpresaZV  
  
   SET @Retorno = @EsIntercorp  
  
  END  
  --Fin @73  
  
  RETURN @Retorno  
  
 END    
    
 --SI EL ALUMNO PERTENECE A COLEGIOS DE TIPO A    
 --RED COLEGIO A / ALUMNOS CON TIPO DE COLEGIO A   
 IF @IdTipoConsulta = 23961    
 BEGIN   
   
  --@17 Inicio  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Interesado AA WITH (NOLOCK)   
   INNER JOIN Colegio C WITH (NOLOCK) ON C.IdColegio = AA.IdColegio    
   WHERE C.IdTipoDescuento IN  
   (  
    23961,  
    23962,  
    23963  
   )  
   AND AA.IdActor = @IdActor  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno    
  
  END    
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM ActorAcademica AA WITH (NOLOCK)   
   INNER JOIN Colegio C WITH (NOLOCK) ON C.IdColegio = AA.IdColegio    
   WHERE C.IdTipoDescuento IN  
   (  
    23961,  
    23962,  
    23963  
   )    
   AND AA.IdActor = @IdActor  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
  SET @Retorno = 0  
  RETURN @Retorno    
  --@17 Fin    
    
 END    
    
 --SI EL ALUMNO PERTENECE A COLEGIOS DE TIPO INNOVA SCHOOLS   
 --EGRESADO INNOVA SCHOOLS  / TIPO DE SITUACION ALUMNO EGRESADO INNOVA SCHOOLS   
 IF @IdTipoConsulta = 23963   
 BEGIN  
  
  SET @Retorno = 0  
  
  SELECT  
   @Retorno = COUNT(1)    
  FROM ActorAcademica AA WITH (NOLOCK)   
  INNER JOIN Colegio C WITH (NOLOCK) ON C.IdColegio = AA.IdColegio    
  WHERE C.IdTipoDescuento = 23963   
  AND AA.IdActor = @IdActor  
  
  RETURN @Retorno  
  
 END    
   
 --SI EL ALUMNO ES TITULADO Y EXISTE EN LA TABLA TITULADO   
 --TITULADO / TIPO DE SITUACION ALUMNO TITULADO   
 IF @IdTipoConsulta = 23958    
 BEGIN  
  
  SET @Retorno = 0  
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Titulado WITH (NOLOCK)  
  WHERE IdAlumno = @IdActor  
  
  RETURN @Retorno  
  
 END    
   
 --EGRESADO CARRERA Y DIPLOMADO -  1,2   
 IF @CodigoTipoConsulta = 'TIPALEGRECARR'  
 -- @IdTipoConsulta = 23965 --@56  
 BEGIN  
  
  --@34  
  SELECT  
   @IdCurricula = IdCurricula   
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula  
  AND Estado <> 'X'  
  
  SELECT  
   @IdCurriculaOrigen = IdCurriculaAnterior  
  FROM TrasladoSede WITH (NOLOCK)  
  WHERE IdAlumno = @IdActor  
  AND IdCurriculaNueva = @IdCurricula  
  AND estado = 1  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Egresados WITH (NOLOCK)  
   WHERE IdAlumno = @IdActor  
   AND IdCurricula = @IdCurriculaOrigen  
  )  
  BEGIN  
  
   SET @Retorno = 0  
   RETURN @Retorno  
  
  END  
  --@34  
   
  SET @Retorno = 0  
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Egresados WITH (NOLOCK)    
  WHERE IdAlumno = @IdActor   
  AND IdUnidadAcademica IN (1,2) --CARRERA Y DIPLOMADO   
   
  IF @Retorno = 0   
  BEGIN  
  
   SELECT  
    @NumeroIdentidad = NumeroIdentidad   
   FROM Actor WITH (NOLOCK)    
   WHERE IdActor = @IdActor   
   
   IF  
   (  
    @CompaniaSocio = '00002500'  
    OR @CompaniaSocio = '00002400' --@87  
   ) --@10    
   BEGIN --@10  
     
    SELECT   
     @Retorno =  COUNT(1)    
    FROM Gupta.dbo.Egresados E WITH (NOLOCK)  
    INNER JOIN Gupta.dbo.PERSONAS PE WITH (NOLOCK) ON  E.CD_CLTE = PE.CD_PERS    
    WHERE PE.NR_DOCUIDEN = @NumeroIdentidad  
  
   END  
     
   RETURN @Retorno  
     
  END --@10   
  ELSE --@56  
  BEGIN  
  
   SET @Retorno = 1  
   RETURN @Retorno  
  
  END  
    
 END    
   
 --SI EL ALUMNO EXISTE EN LA TABLA EGRESADO (CARRERA DIPLIMADOS)   
 --EGRESADO  /  TIPO DE SITUACION ALUMNO EGRESADO   
 IF @IdTipoConsulta = 23957    
 BEGIN  
  
  SET @Retorno = 0  
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Egresados WITH (NOLOCK)    
  WHERE IdAlumno = @IdActor  
  
  RETURN @Retorno  
  
 END    
   
 --SI EL ALUMNO EXISTE EN LA TABLA EGRESADO (CARRERA DIPLIMADOS)   
 --ALUMNO MATRICULADO EN EL PERIODO ACTUAL   
 IF @IdTipoConsulta = 24682    
 BEGIN  
  
  SET @Retorno = 0  
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Matricula M WITH (NOLOCK)   
  INNER JOIN Promocion PRO  WITH (NOLOCK) ON PRO.IdPromocion = M.IdPromocion    
  INNER JOIN Periodo PE WITH (NOLOCK) ON PE.IdPeriodo = PRO.IdPeriodo    
  INNER JOIN Producto p WITH (NOLOCK) ON p.IdProducto = pro.IdProducto    
  INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON P.IdClasificacionProducto = MTR_PRO.IdMaestroRegistro  
  WHERE M.IdActor = @IdActor   
  AND M.EsMatricula = 1   
  AND M.Estado = 'N'   
  AND  
  (  
   (  
    PRO.IdUnidadNegocio = 1 AND  MTR_PRO.Disponible1 = 'C' AND MTR_PRO.Disponible2 = 'CAR'    
    AND CONVERT(VARCHAR,GETDATE(),112) BETWEEN CONVERT(VARCHAR,DATEADD(DAY,-60,PE.Inicio),112) AND CONVERT(VARCHAR,PE.Fin,112)  
   ) --@3 --@18  
   OR (CONVERT(VARCHAR,GETDATE(),112) BETWEEN CONVERT(VARCHAR,PRO.FechaInicioPeriodo,112) AND CONVERT(VARCHAR,PRO.FechaFinPeriodo,112))    
  )  
  
  RETURN @Retorno  
  
 END   
    
 --ALUMNOS REINGRESANTES CON CURSOS REGULARES EL 100% DE LOS CURSOS   
 IF @IdTipoConsulta = 24731    
 BEGIN  
  
  SELECT    
   @IdMatricula = IdMatricula,    
   @IdCurricula = IdCurricula,   
   @IdModulo = IdModulo    
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula  
  AND Estado <> 'X'  
  AND IdPeriodo = @IdPeriodo  
  AND EsMatricula = 0   
   
  SELECT  
   @CantidadCursosCurricula = COUNT(1)  
  FROM CurriculaCurso WITH (NOLOCK)  
  WHERE IdCurricula = @IdCurricula  
  AND IdModulo = @IdModulo   
   
  SELECT  
   @Matriculados = COUNT(1)  
  FROM AlumnoCurso WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula  
  AND IdSeccion IS NOT NULL  
   
  IF @CantidadCursosCurricula <= @Matriculados   
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END   
   
 --SI EL ALUMNOS MATRICULADOS SEDE SJL   
 IF @IdTipoConsulta = 24733    
 BEGIN  
  
  SET @Retorno = 0  
  
  SELECT  
   @Retorno = COUNT(1)    
  FROM Permiso P WITH (NOLOCK)   
  INNER JOIN RolUsuario R WITH (NOLOCK) ON P.IdRol = R.IdRol  
  AND P.IdSistema = R.IdSistema --@1   
  INNER JOIN RolUsuarioItem IR WITH (NOLOCK) ON R.IdRol = IR.IdRol  
  AND R.IdSistema = IR.IdSistema --@1  
  INNER JOIN Item I WITH (NOLOCK) ON IR.IdItem = I.IdItem  
  AND IR.IdSistema = I.IdSistema --@1  
  WHERE R.IdSistema  = 3  
  AND I.IdItem = 482541 --PERMISO PARA LOS VENDEDORES DE SAN JUAN DE LURIGANCHO   
  AND p.IdUsuario = @UsuarioCreacion --USUARIO VENDEDOR  
  
  RETURN @Retorno  
  
 END    
   
 --ALUMNOS CON CONVENIOS EN EMPRESAS - MATRICULA ES CONVENIO   
 IF @IdTipoConsulta = 24734   
 BEGIN  
  
  IF ISNULL(@IdMatricula,-1) <> -1   
  BEGIN  
  
   SELECT  
    @Retorno = ISNULL(IdConvenio,0)  
   FROM Matricula WITH (NOLOCK)  
   WHERE IdMatricula = @IdMatricula  
  
  END   
  ELSE   
  BEGIN  
  
   IF ISNULL(@IdConvenio,-1) = -1   
   BEGIN  
  
    SET @Retorno = 0  
  
   END  
  
  END  
  
 END    
    
 --ALUMNOS DE CAPTACION O SECUENCIAL SIN VALIDACION ESPECIAL   
 IF @IdTipoConsulta = 24740   
 BEGIN  
  
  --@74  
  SELECT  
   @IdEmpresaZV = IdEmpresaZV   
  FROM Matricula M WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula  
  
  IF ISNULL(@IdEmpresaZV,0) <> 0  
  BEGIN  
  
   SELECT  
    @EsAutomatico = ISNULL(Disponible2,0)  
   FROM MaestroTablaRegistro WITH (NOLOCK)  
   WHERE IdMaestroRegistro = @IdEmpresaZV  
  
   SET @Retorno = @EsIntercorp  
  
  END  
  --@74  
  
  SET @Retorno = 1  
  RETURN @Retorno  
  
 END  
   
 --DESCUENTO SOLO PARA ALUMNOS NUEVOS CAPATACIO Y ALUMNOS REINTRESANTES QUE NO SEAN REPITENTES   
 IF @IdTipoConsulta = 24903   
 BEGIN  
  
  IF dbo.cAlumnoReingresante(@IdActor,@IdPeriodo) = 1  
  BEGIN   
   
   SELECT  
    @TipoCondicion = TipoCondicion    
   FROM Matricula WITH (NOLOCK)    
   WHERE IdMatricula = @IdMatricula   
   
   IF @TipoCondicion = 'RT'   
   BEGIN  
  
    SET @Retorno = 0    
    RETURN @Retorno  
  
   END  
   ELSE   
   BEGIN   
   
    SET @Retorno = 1   
    RETURN @Retorno  
  
   END  
  
  END   
  ELSE   
  BEGIN  
  
   IF NOT EXISTS  
   (  
    SELECT  
     1  
    FROM Matricula WITH (NOLOCK)  
    WHERE IdMatricula  = @IdMatricula  
    AND Estado <> 'X'  
    AND IdPeriodo = @IdPeriodo   
    AND EsMatricula = 0  
   )   
   BEGIN  
  
    SET @Retorno = 1   
    RETURN @Retorno  
  
   END  
  
  END  
  
 END    
   
 --BECA SOCIOECONOMICA 100%   
 IF  
 (  
  @IdTipoConsulta = 23960  
  AND @CompaniaSocio NOT IN  
  (  
   '00002700',  
   '00002500', --@86  
   '00002400' --@87  
  )  
 )  
 BEGIN   
   
  SELECT  
   @Retorno = COUNT(1)   
  FROM SolicitudBeca SB WITH( NOLOCK)  
  INNER JOIN BecaAcademica BA WITH (NOLOCK) ON SB.IdBecaAcademica = BA.IdBecaAcademica    
  WHERE BA.IdPeriodo = @IdPeriodo   
  AND SB.IdAlumno = @IdActor    
  AND SB.IdEstado = 22021   
  AND SB.IdPromocionBecaFinal = 21851 --MAESTRO PROMOCION BECA IDTRABLA 1863  
  
  RETURN @Retorno   
   
 END    
   
 --BECA SOCIOECONOMICA 50%   
 IF  
 (  
  @IdTipoConsulta = 24936  
  AND @CompaniaSocio NOT IN  
  (  
   '00002700',  
   '00002500', --@86  
   '00002400' --@87  
  )  
 )  
 BEGIN   
  
  SELECT  
   @Retorno = COUNT(1)   
  FROM SolicitudBeca SB WITH (NOLOCK)  
  INNER JOIN BecaAcademica BA WITH (NOLOCK) ON SB.IdBecaAcademica = BA.IdBecaAcademica    
  WHERE BA.IdPeriodo = @IdPeriodo   
  AND SB.IdAlumno = @IdActor    
  AND SB.IdEstado = 22021   
  AND SB.IdPromocionBecaFinal = 21850 --MAESTRO PROMOCION BECA IDTRABLA 1863    
    
  RETURN @Retorno   
   
 END  
   
 --BECA SOCIOECONOMICA 25%   
 IF  
 (  
  @IdTipoConsulta = 24937  
  AND @CompaniaSocio NOT IN  
  (  
   '00002700',  
   '00002500', --@86  
   '00002400' --@87  
  )  
 )  
 BEGIN   
   
  SELECT  
   @Retorno = COUNT(1)   
  FROM SolicitudBeca SB WITH (NOLOCK)  
  INNER JOIN BecaAcademica BA WITH (NOLOCK) ON SB.IdBecaAcademica = BA.IdBecaAcademica    
  WHERE BA.IdPeriodo = @IdPeriodo   
  AND SB.IdAlumno = @IdActor    
  AND SB.IdEstado = 22021   
  AND SB.IdPromocionBecaFinal = 21849 --MAESTRO PROMOCION BECA IDTRABLA 1863   
   
  RETURN @Retorno   
   
 END    
    
 ---@35 Inicio   
 --BECA SOCIOECONOMICA 100%   
 IF  
 (  
  @IdTipoConsulta = 23960  
  AND @CompaniaSocio IN  
  (  
   '00002700',  
   '00002500', --@86  
   '00002400' --@87  
  )  
 )   
 BEGIN    
   
  SELECT    
   @PeriodoCodigo = PE.Codigo  
  FROM Matricula M WITH (NOLOCK)  
  INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion   
  INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.Idperiodo   
  WHERE IdMatricula = @IdMatricula   
  
  SELECT   
   @Retorno = COUNT(1)   
  FROM SolicitudBeca SB WITH (NOLOCK)  
  INNER JOIN BecaAcademica BA WITH (NOLOCK) ON SB.IdBecaAcademica = BA.IdBecaAcademica  
  INNER JOIN Periodo PE WITH (NOLOCK) ON BA.IdPeriodo = PE.IdPeriodo  
  WHERE PE.Codigo = @PeriodoCodigo   
  AND SB.IdAlumno = @IdActor    
  AND SB.IdEstado = 22021   
  AND SB.IdPromocionBecaFinal = 21851 --MAESTRO PROMOCION BECA IDTRABLA 1863   
    
  RETURN @Retorno   
   
 END    
   
 --BECA SOCIOECONOMICA 50%   
 IF  
 (  
  @IdTipoConsulta = 24936  
  AND @CompaniaSocio IN  
  (  
   '00002700',  
   '00002500', --@86  
   '00002400' --@87  
  )  
 )    
 BEGIN   
   
  SELECT    
   @PeriodoCodigo = PE.Codigo  
  FROM Matricula M WITH (NOLOCK)  
  INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion   
  INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.Idperiodo   
  WHERE IdMatricula = @IdMatricula   
    
  SELECT @Retorno = COUNT(1)   
  FROM SolicitudBeca SB WITH (NOLOCK)  
  INNER JOIN BecaAcademica BA WITH (NOLOCK) ON SB.IdBecaAcademica = BA.IdBecaAcademica    
  INNER JOIN Periodo PE WITH (NOLOCK) ON BA.IdPeriodo = PE.IdPeriodo  
  WHERE PE.Codigo = @PeriodoCodigo    
  AND SB.IdAlumno = @IdActor    
  AND SB.IdEstado = 22021   
  AND SB.IdPromocionBecaFinal = 21850 --MAESTRO PROMOCION BECA IDTRABLA 1863    
    
  RETURN @Retorno   
   
 END    
   
 --BECA SOCIOECONOMICA 25%   
 IF  
 (  
  @IdTipoConsulta = 24937  
  AND @CompaniaSocio IN  
  (  
   '00002700',  
   '00002500', --@86  
   '00002400' --@87  
  )  
 )     
 BEGIN   
   
  SELECT    
   @PeriodoCodigo = PE.Codigo  
  FROM Matricula M WITH (NOLOCK)  
  INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion   
  INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.Idperiodo   
  WHERE IdMatricula = @IdMatricula   
  
  SELECT   
   @Retorno = COUNT(1)   
  FROM SolicitudBeca SB WITH (NOLOCK)  
  INNER JOIN BecaAcademica BA WITH (NOLOCK) ON SB.IdBecaAcademica = BA.IdBecaAcademica    
  INNER JOIN Periodo PE WITH (NOLOCK) ON BA.IdPeriodo = PE.IdPeriodo  
  WHERE PE.Codigo = @PeriodoCodigo  
  AND SB.IdAlumno = @IdActor    
  AND SB.IdEstado = 22021   
  AND SB.IdPromocionBecaFinal = 21849 --MAESTRO PROMOCION BECA IDTRABLA 1863    
      
  RETURN @Retorno   
   
 END    
 ---@35 fin   
   
 --ALUMNOS MATRICULADOS EN DIPLOMADO QUE PAGAN UN MES ANTERIOR   
 IF @IdTipoConsulta = 24958   
 BEGIN  
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Matricula M WITH (NOLOCK)   
  INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion    
  WHERE IdMatricula = @IdMatricula   
  AND YEAR(GETDATE()) = YEAR(P.FechaInicioPeriodo)   
  AND MONTH(GETDATE()) < MONTH(P.FechaInicioPeriodo)  
  
  RETURN @Retorno  
  
 END    
   
 --ALUMNOS MATRICULADOS EN DIPLOMADO QUE PAGAN EL MISMO MES   
 IF @IdTipoConsulta = 24959   
 BEGIN  
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Matricula M WITH (NOLOCK)   
  INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion    
  WHERE IdMatricula = @IdMatricula   
  AND YEAR(GETDATE()) = YEAR(P.FechaInicioPeriodo)   
  AND MONTH(GETDATE()) = MONTH(P.FechaInicioPeriodo)  
  
  RETURN @Retorno  
  
 END    
   
 --ALUMNOS DE C/S I SEMESTRE - REINGRESANTES NO REPITENTES >= 5 CURSOS   
 IF @IdTipoConsulta = 25127   
 BEGIN   
   
  IF dbo.cAlumnoReingresante(@IdActor,@IdPeriodo) = 1  
  BEGIN   
   
   SELECT  
    @TipoCondicion = TipoCondicion,   
    @IdCurricula = IdCurricula,   
    @IdModulo = IdModulo    
   FROM Matricula WITH (NOLOCK)    
   WHERE IdMatricula = @IdMatricula   
   
   --Si es repitente no tiene descuento   
   IF @TipoCondicion = 'RT'   
   BEGIN  
  
    SET @Retorno = 0    
    RETURN @Retorno  
  
   END   
   ELSE   
   BEGIN  
  
    --Si es reingresante validamos que tenga mas de 5 cursos matriculados   
    SELECT    
     @IdMatricula = IdMatricula,    
     @IdCurricula = IdCurricula,   
     @IdModulo = IdModulo    
    FROM Matricula WITH (NOLOCK)    
    WHERE IdMatricula = @IdMatricula   
  
    SELECT  
     @Matriculados = COUNT(1)  
    FROM AlumnoCurso WITH (NOLOCK)  
    WHERE IdMatricula = @IdMatricula  
    --AND IdSeccion IS NOT NULL --@85   
   
    IF  
    (  
     @Matriculados >= 5  
     AND @IdModulo = 1  
    )  
    BEGIN  
  
     SET @Retorno = 1   
     RETURN @Retorno  
  
    END   
    ELSE   
    BEGIN  
  
     --SI EL ALUMNO NO ES SECUENCIAL   
     IF NOT EXISTS  
     (  
      SELECT  
       1  
      FROM Matricula WITH (NOLOCK)  
      WHERE IdMatricula  = @IdMatricula  
      AND Estado <> 'X'  
      AND IdPeriodo = @IdPeriodo  
      AND EsMatricula = 0  
     ) --@15  
     BEGIN  
  
      SET @Retorno = 1   
      RETURN @Retorno  
  
     END  
     ELSE  
     BEGIN  
  
      SET @Retorno = 0   
      RETURN @Retorno  
  
     END  
  
    END  
  
   END  
  
  END   
  ELSE   
  BEGIN  
  
   --SI EL ALUMNO NO ES SECUENCIAL   
   IF NOT EXISTS  
   (  
    SELECT  
     1  
    FROM Matricula WITH (NOLOCK)  
    WHERE IdMatricula  = @IdMatricula  
    AND Estado <> 'X'  
    AND IdPeriodo = @IdPeriodo  
    AND EsMatricula = 0  
   )   
   BEGIN  
  
    SET @Retorno = 1   
    RETURN @Retorno  
  
   END  
      
   --@41 Validamos por camtacion si es descuento manual   
   IF  
   (  
    @TipoMatricula IN   
    (  
     'CAPTACI�N',  
     'AMBOS'  
    )  
    AND ISNULL(@IdMatricula,-1) = -1  
   )  
   BEGIN  
  
    SET @Retorno = 1   
    RETURN @Retorno  
  
   END  
     
  END  
  
 END    
   
 --PROSPECTOS EGRESADOS DE COLEGIOS MENOS UN A�O DEL A�O ACTUAL   
 IF @IdTipoConsulta = 25129   
 BEGIN  
    
  IF EXISTS  
  (  
   SELECT  
    1    
   FROM Interesado WITH (NOLOCK)   
   WHERE NombreCompleto =  
   (  
    SELECT  
     NombreCompleto  
    FROM Actor WITH (NOLOCK)    
    WHERE IdActor = @IdActor  
   )   
   AND AnnoEgreso BETWEEN YEAR(GETDATE()) -2 AND YEAR(GETDATE())  
  ) --@6 --@7 --@29 --@32  
  BEGIN  
  
   SET @Retorno = 1  
   RETURN @Retorno  
  
  END  
  
  IF EXISTS  
  (  
   SELECT   
    1 --@94  
   FROM ActorAcademica AA WITH (NOLOCK)  
   WHERE AA.IdActor = @IdActor  
   AND AnnoEgreso BETWEEN YEAR(GETDATE()) -2 AND YEAR(GETDATE())  
  ) --@14 --@29 --@32  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END   
    
 END    
   
 --PROSPECTOS EGRESADOS DE COLEGIOS DEL A�O ACTUAL   
 IF @IdTipoConsulta = 25297 --@4 --@16  
 BEGIN    
     
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Interesado WITH (NOLOCK)   
   WHERE NombreCompleto =  
   (  
    SELECT  
     NombreCompleto  
    FROM Actor WITH (NOLOCK)    
    WHERE IdActor = @IdActor  
   )   
   AND AnnoEgreso IN (YEAR(GETDATE()))  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END    
   
  IF EXISTS  
  (  
   SELECT  
    1 --@94  
   FROM ActorAcademica AA WITH (NOLOCK)  
   WHERE AA.IdActor = @IdActor  
   AND AnnoEgreso IN (YEAR(GETDATE()))  
  ) --@14  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno   
  
  END   
   
 END    
   
 --ALUMNOS REINGRESANTES PLAN VUELVE ACADEMICO 50%--@31   
 IF @IdTipoConsulta = 25140   
 BEGIN  
  
  IF dbo.cAlumnoReingresante(@IdActor,@IdPeriodo) = 1  
  BEGIN   
   
   SELECT  
    @TipoCondicion = TipoCondicion,   
    @IdCurricula = IdCurricula,   
    @IdModulo = IdModulo    
   FROM Matricula WITH (NOLOCK)    
   WHERE IdMatricula = @IdMatricula   
   
   --Si es repitente no tiene descuento   
   IF @TipoCondicion = 'CC'   
   BEGIN  
  
    SET @Retorno = 0    
    RETURN @Retorno  
  
   END   
   ELSE   
   BEGIN  
  
    --Si es reingresante validamos que tenga mas de 5 cursos matriculados   
    SELECT  
     @Matriculados = COUNT(1)  
    FROM AlumnoCurso WITH (NOLOCK)  
    WHERE IdMatricula = @IdMatricula  
    AND IdSeccion IS NOT NULL   
   
    IF  
    (  
     @Matriculados >= 5  
     AND @IdModulo = 1  
    ) --@31   
    BEGIN  
  
     SET @Retorno = 1   
     RETURN @Retorno  
       
    END   
    ELSE   
    BEGIN  
  
     SET @Retorno = 0   
     RETURN @Retorno  
  
    END   
   
   END  
  
  END  
  
 END   
   
   
 -- ALUMNOS REGISTRADOS EN COLEGIOS DENTRO DE LA RED A-AA E INNOVA   
 IF @IdTipoConsulta = 25141    
 BEGIN   
  
  --@17 Inicio  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Interesado AA WITH (NOLOCK)   
   INNER JOIN Colegio C WITH (NOLOCK) ON C.IdColegio = AA.IdColegio    
   WHERE C.IdTipoDescuento IN  
   (  
    23961,  
    23962,  
    23963  
   )  
   AND AA.IdActor = @IdActor  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
     
  END    
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM ActorAcademica AA WITH (NOLOCK)   
   INNER JOIN Colegio C WITH (NOLOCK) ON C.IdColegio = AA.IdColegio    
   WHERE C.IdTipoDescuento IN  
   (  
    23961,  
    23962,  
    23963  
   )    
   AND AA.IdActor = @IdActor  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
    
  SET @Retorno = 0   
  RETURN @Retorno    
  --@17 Fin  
    
 END    
   
 -- ALUMNO MATRICULADO EN EL PERIODO ACTUAL CARRERA   
 IF @IdTipoConsulta = 25142    
 BEGIN  
  
  SET @Retorno = 0  
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Matricula M WITH (NOLOCK)   
  INNER JOIN Promocion PRO WITH (NOLOCK) ON PRO.IdPromocion = M.IdPromocion    
  INNER JOIN Periodo PE WITH (NOLOCK) ON PE.IdPeriodo = PRO.IdPeriodo    
  INNER JOIN Producto P WITH (NOLOCK) on P.IdProducto = PRO.IdProducto    
  INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON P.IdClasificacionProducto = MTR_PRO.IdMaestroRegistro  
  WHERE M.IdActor = @IdActor   
  AND M.EsMatricula = 1   
  AND M.Estado = 'N'   
  AND PRO.IdUnidadNegocio = 1    
  AND  MTR_PRO.Disponible1 = 'C'    
  AND  MTR_PRO.Disponible2 = 'CAR'    
  AND CONVERT(VARCHAR,GETDATE(),112) BETWEEN CONVERT(VARCHAR, DATEADD(DAY ,-60,PE.Inicio),112) AND CONVERT(VARCHAR,PE.Fin ,112) --@3 --@18  
  
  RETURN @Retorno  
  
 END   
   
 --DESCUENTOS DE UTP E IDAT , CORRIENTE ALTERNA   
 IF @IdTipoConsulta = 24961 --25142 -- @1  --@61  
 BEGIN   
   
  SELECT  
   @NumeroIdentidad = NumeroIdentidad   
  FROM Actor WITH (NOLOCK)    
  WHERE IdActor = @IdActor   
   
  SELECT  
   @Retorno = COUNT(1)  
  FROM CargaUTPIdat WITH (NOLOCK)  
  WHERE NumeroDocumento = @NumeroIdentidad   
   
  RETURN @Retorno  
  
 END  
   
 --SECUENCIAL MENOS CURSO A CARGO SOLO PARA CONTADOS   
 IF @IdTipoConsulta = 25240   
 BEGIN  
   
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula WITH (NOLOCK)  
   WHERE IdActor = @IdActor  
   AND Estado <> 'X'  
   AND IdPeriodo = @IdPeriodo    
   AND TipoCondicion <> 'CC'  
   AND CondicionPago = 'C'  
  )   
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END    
   
 END    
   
 -- @2 EGRESADO SOLO CARRERA   
 IF @IdTipoConsulta = 25243   
 BEGIN  
  
  SET @Retorno = 0  
  
  SELECT  
   @Retorno =  COUNT(1)  
  FROM Egresados E WITH (NOLOCK)  
  INNER JOIN Periodo PE WITH (NOLOCK) on PE.IdPeriodo = E.IdPeriodoEgreso    
  WHERE IdAlumno = @IdActor  
  AND PE.Codigo not in ('2020-IID') --@30 Cambio teporal pedido por jcontreras por errores en zegel  
  AND E.IdUnidadAcademica = 1 -- CARRERA    
   
  IF @Retorno = 0   
  BEGIN  
  
   SELECT @NumeroIdentidad = NumeroIdentidad   
   FROM Actor WITH(NOLOCK)    
   WHERE IdActor = @IdActor   
    
   --@10  
   IF  
   (  
    @CompaniaSocio = '00002500'  
    OR @CompaniaSocio ='00002400' --@87  
   )  
   BEGIN  
  
    SELECT  
     @Retorno = COUNT(1)    
    FROM Gupta.dbo.Egresados E WITH (NOLOCK)    
    INNER JOIN Gupta.dbo.PERSONAS PE WITH (NOLOCK) ON E.CD_CLTE = PE.CD_PERS    
    WHERE PE.NR_DOCUIDEN = @NumeroIdentidad   
    AND E.CD_AREA = '01'    
    
   END    
   --@10  
  
   RETURN @Retorno  
  
  END  
  
 END    
    
 --@2 EGRESADO SOLO DIPLOMADO   
 IF @IdTipoConsulta = 25244   
 BEGIN  
  
  SET @Retorno = 0  
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Egresados WITH(NOLOCK)    
  WHERE IdAlumno = @IdActor   
  AND IdUnidadAcademica = 2 --DIPLOMADO   
   
  IF @Retorno = 0   
  BEGIN  
  
   SELECT  
    @NumeroIdentidad = NumeroIdentidad   
   FROM Actor WITH (NOLOCK)    
   WHERE IdActor = @IdActor   
    
   --@10  
   IF  
   (  
    @CompaniaSocio = '00002500'  
    OR @CompaniaSocio = '00002400' --@87  
   )   
   BEGIN  
  
    SELECT  
     @Retorno = COUNT(1)    
    FROM Gupta.dbo.Egresados E WITH (NOLOCK)    
    INNER JOIN Gupta.dbo.PERSONAS PE WITH (NOLOCK) ON E.CD_CLTE = PE.CD_PERS    
    WHERE PE.NR_DOCUIDEN = @NumeroIdentidad   
    AND E.CD_AREA = '02'    
    
   END  
   --@10  
  
   RETURN @Retorno  
  
  END  
  
 END    
   
 -- ALUMNOS MATRICULADOS EN AULAS DE LIMA NORTE Y PURUCHUCO(ATE)   
 IF @IdTipoConsulta = 25305   
 BEGIN  
  
  SET @Retorno = 0   
   
  SELECT  
   @Retorno = COUNT(1)    
  FROM Matricula M WITH (NOLOCK)   
  INNER JOIN Promocion PRO WITH (NOLOCK) ON PRO.IdPromocion = M.IdPromocion    
  INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON  PRO.IdPromocion = PG.IdPromocion  
  AND M.IdGrupo = PG.IdGrupo   
  WHERE M.IdMatricula = @IdMatricula --@6   
  AND PG.IdAmbiente IN  
  (  
   822,  
   821,  
   186,  
   187  
  )   
  
  RETURN @Retorno  
  
 END    
   
 --ALUMNOS INTERCORP, EGRESADO CARRERA, RPC @8   
 IF @IdTipoConsulta = 25577   
 BEGIN  
  
  SET @Retorno = 0   
   
  SELECT  
   @NumeroIdentidad = NumeroIdentidad   
  FROM Actor WITH (NOLOCK)    
  WHERE IdActor = @IdActor   
   
  --SI ES INTERCORP   
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM IntercorpActor A WITH (NOLOCK)   
   WHERE A.NumeroIdentidad = @NumeroIdentidad  
  )  
  BEGIN  
  
   --Inicio @73  
   SELECT  
    @IdEmpresaZV  = IdEmpresaZV  
   FROM Matricula M WITH (NOLOCK)  
   WHERE IdMatricula = @IdMatricula  
  
   IF ISNULL(@IdEmpresaZV,0) <> 0  
   BEGIN  
  
    SELECT  
     @EsIntercorp = ISNULL(Disponible1,0)  
    FROM MaestroTablaRegistro WITH (NOLOCK)  
    WHERE IdMaestroRegistro = @IdEmpresaZV  
  
    SET @Retorno = @EsIntercorp  
    RETURN @Retorno  
  
   END  
   --Fin @73  
   
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END    
   
  --SI ES EGRESADO CARRERA  
  --@10  
  IF  
  (  
   @CompaniaSocio = '00002500'  
   OR @CompaniaSocio = '00002400' --@87  
  )  
  BEGIN  
  
   IF EXISTS  
   (  
    SELECT   
     1  
    FROM Egresados WITH (NOLOCK)    
    WHERE IdAlumno = @IdActor   
    AND IdUnidadAcademica = 1 --SI EXISTE EN SMART    
   )   
   OR    
   EXISTS  
   (  
    SELECT   
     1   
    FROM Gupta.dbo.Egresados E WITH (NOLOCK)  
    INNER JOIN Gupta.dbo.PERSONAS PE WITH (NOLOCK) ON E.CD_CLTE = PE.CD_PERS    
    WHERE PE.NR_DOCUIDEN = @NumeroIdentidad   
    AND E.CD_AREA = '01' --SI EXISTE EN GUPTA    
   )  
   BEGIN   
   
    SET @Retorno = 1    
    RETURN @Retorno  
  
   END    
    
  END  
  --@10  
  
  --SI ES RPC CONVENIO   
  IF ISNULL(@IdMatricula,-1) <> -1   
  BEGIN  
  
   SELECT  
    @Retorno = ISNULL(IdConvenio,0)  
   FROM Matricula WITH (NOLOCK)  
   WHERE IdMatricula = @IdMatricula  
  
   SET @Retorno = 1    
   RETURN @Retorno  
     
  END   
  ELSE   
  BEGIN  
  
   IF ISNULL(@IdConvenio,-1) <> -1   
   BEGIN  
  
    SET @Retorno = 1   
    RETURN @Retorno  
  
   END  
  
  END    
  --@10  
  
  RETURN @Retorno  
  
 END   
 --FIN @8    
    
    
 --@9  SI EL DOCENTE ESTA DICTANDO ACTUALMENTE    
 IF @IdTipoConsulta = 25595    
 BEGIN  
  
  --SI EXISTE DOCENTE DICTANDO EN CARRERA    
  IF EXISTS    
  (  
   SELECT DISTINCT  
    SP.IdActor    
   FROM SeccionProfesor SP WITH (NOLOCK)    
   INNER JOIN Seccion S WITH (NOLOCK) ON SP.IdSeccion = S.IdSeccion    
   INNER JOIN promocion PR WITH (NOLOCK) ON PR.IdPromocion = S.IdPromocion    
   INNER JOIN periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo    
   INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON UN.IdUnidadNegocio = PR.IdUnidadNegocio    
   WHERE CONVERT(VARCHAR(19), PE.Inicio, 120) <= CONVERT(VARCHAR(19), GETDATE(), 120)  
   AND CONVERT(VARCHAR(19), PE.Fin, 120) >= CONVERT(VARCHAR(19), GETDATE(), 120)    
   AND UN.TipoServicio = 'C'    
   AND @IdActor = SP.IdActor  
  )  
  --SI EXISTE DOCENTE DICTANDO EN TALLERES    
  OR EXISTS  
  (  
   SELECT DISTINCT  
    SP.IdActor    
   FROM SeccionProfesor SP WITH (NOLOCK)    
   INNER JOIN Seccion S WITH (NOLOCK) ON SP.IdSeccion = S.IdSeccion    
   INNER JOIN promocion PR WITH (NOLOCK) ON PR.IdPromocion = S.IdPromocion    
   INNER JOIN periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo    
   INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON UN.IdUnidadNegocio = PR.IdUnidadNegocio    
   WHERE CONVERT(VARCHAR(19), PR.FechaInicioPeriodo, 120) <= CONVERT(VARCHAR(19), GETDATE(), 120)  
   AND CONVERT(VARCHAR(19), PR.FechaFinPeriodo, 120) >= CONVERT(VARCHAR(19),GETDATE(), 120)    
   AND UN.TipoServicio = 'P'    
   AND @IdActor = SP.IdActor  
  )    
    
  BEGIN  
  
   SET @Retorno = 1    
   RETURN @Retorno  
  
  END  
  
 END    
 --FIN @9    
    
 --@11 SI EL ALUMNO LLEVA TODAS LAS SESIONES DE UN TALLER    
 IF @IdTipoConsulta = 25770   
 BEGIN  
  
  SELECT  
   @IdPromocion = IdPromocion  
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula  
  
  SELECT  
   @IdGrupo = IdGrupo  
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula   
   
  SELECT  
   @NumeroCursosCurricula = COUNT(DISTINCT S.IdCurso)   
  FROM Seccion S WITH (NOLOCK)  
  INNER JOIN PROMOCION P WITH (NOLOCK) ON P.IdPromocion = S.IdPromocion   
  INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON PG.IdPromocion = P.IdPromocion --@94  
  AND PG.IdGrupo = S.IdGrupo --@12  
  WHERE S.IdPromocion = @idpromocion --@12  
  AND S.IdGrupo = @idGrupo --@12   
   
  SELECT  
   @NumeroCursosAlumno = COUNT(DISTINCT AC.IdCurso)   
  FROM AlumnoCurso AC WITH (NOLOCK)  
  WHERE IdAlumno = @IdActor   
  AND AC.IdMatricula = @IdMatricula   
  
  IF @NumeroCursosCurricula = @NumeroCursosAlumno   
  BEGIN  
  
   SET  @Retorno = 1   
   RETURN @Retorno  
  
  END  
     
 END   
 --@11 FIN  
   
  
 --@13 ALUMNOS DE UNIVERSIDADES NO LICENCIADAS E INSTITUTOS  
 IF @IdTipoConsulta = 27420   
 BEGIN  
  
  DECLARE  
  @OrigenInstitucion VARCHAR(100) --@25  
  
  --OBTENEMOS DATOS DE LA MATRICULA  
   --Inicio @25  
  SELECT  
   @OrigenInstitucion = MTR.Disponible1  
  FROM Matricula M WITH(NOLOCK)  
  LEFT JOIN ActorAcademica AA WITH (NOLOCK) ON AA.IdActor = M.IdActor  
  LEFT JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON AA.IdInstitucion = MTR.IdMaestroRegistro  
  -- Fin @25  
  WHERE M.IdMatricula = @IdMatricula  
  
  IF @OrigenInstitucion IN  
  (  
   'ALTO_LIMA',  
   'BAJO_LIMA',  
   'ALTO_PROVINCIA',  
   'BAJO_PROVINCIA'  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END   
  
 --Inicio @19   
 --Matriculados por producto  
 IF @CodigoTipoConsulta = 'TIPMATPROD'  
 BEGIN  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula WITH (NOLOCK) --@65  
   WHERE IdMatricula = @IdMatricula  
   AND TipoServicio = 'P'  
  )  
  OR @TipoServicio = 'P' --@93  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
  
 --Inicio @60  
 --Matriculados por Curso  
 IF @CodigoTipoConsulta = 'TIPMATCUR'  
 BEGIN  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula WITH (NOLOCK) --@65  
   WHERE IdMatricula = @IdMatricula  
   AND TipoServicio = 'C'  
  )  
  OR @TipoServicio = 'C' --@93  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
 --Fin @60  
  
 --Matriculados a un curso  
 IF @CodigoTipoConsulta = 'TIPMATCUR1'  
 BEGIN  
  
  DECLARE  
  @CantCursox1 INT  
  
  SELECT  
   @CantCursox1 = COUNT(IdCurso)   
  FROM AlumnoCurso WITH (NOLOCK)   
  WHERE IdMatricula = @IdMatricula  
  AND IdPromocion IS NOT NULL   
  AND IdGrupo IS NOT NULL  
  AND TipoCondicion = 'CC'  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula WITH (NOLOCK) --@65  
   WHERE IdMatricula = @IdMatricula   
   AND TipoServicio = 'C'  
  )   
  AND @CantCursox1 = 1  
  AND @TipoMatricula = 'CAPTACI�N' --@20  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
  
 --Matriculados a dos cursos  
 IF @CodigoTipoConsulta = 'TIPMATCUR2'  
 BEGIN  
  
  DECLARE  
  @CantCursox2 INT  
  
  SELECT  
   @CantCursox2 = COUNT(IdCurso)   
  FROM AlumnoCurso WITH (NOLOCK)   
  WHERE IdMatricula = @IdMatricula  
  AND IdPromocion IS NOT NULL   
  AND IdGrupo IS NOT NULL  
  AND TipoCondicion = 'CC'  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula WITH (NOLOCK) --@65  
   WHERE IdMatricula = @IdMatricula   
   AND TipoServicio = 'C'  
  )   
  AND @CantCursox1 = 2  
  AND @TipoMatricula = 'CAPTACI�N' --@20  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
 --Fin @19   
  
 --Inicio @20  
 IF @CodigoTipoConsulta = 'TIPMAT20IB'  
 BEGIN  
  
  IF EXISTS  
  (  
   SELECT   
    1  
   FROM Matricula MA WITH (NOLOCK)  
   INNER JOIN Promocion PR WITH (NOLOCK) ON MA.IdPromocion = PR.IdPromocion  
   INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo  
   WHERE MA.Estado != 'X'  
   AND PE.Codigo = '2020-IB'  
   AND MA.IdActor = @IdActor  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  ELSE  
  BEGIN  
  
   SET @Retorno = 0  
   RETURN @Retorno  
  
  END  
  
 END  
 --Fin @20  
  
 --Inicio @22  
 IF  
 (  
  @CodigoTipoConsulta = 'TIPMATPRP2'  
  OR @CodigoTipoConsulta = 'TIPMATPRP3'  
 )  
 BEGIN  
  
  --Matricula actual  
  SELECT   
   @IdActorPagante = MP.IdActor,  
   @IdUnidadAcademica = P.IdUnidadAcademica,   
   @Sucursal = S.Sucursal,  
   @MontoProducto = VP.Monto,  
   @IdPeriodo = P.IdPeriodo,  
   @IdPeriodoAnterior = PE.IdPeriodoAnterior  
  FROM Matricula M WITH (NOLOCK)  
  INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
  INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
  INNER JOIN Sede S WITH (NOLOCK) ON P.IdSede = S.IdSede  
  INNER JOIN Empresa E WITH (NOLOCK) ON P.IdEmpresa = E.IdEmpresa  
  INNER JOIN MatriculaPagante MP WITH (NOLOCK) ON M.IdMatricula = MP.IdMatricula  
  INNER JOIN vw_CO_Precio VP WITH (NOLOCK) ON VP.ItemCodigo =  
  CASE  
   WHEN @TipoServicio = 'C' THEN REPLACE(P.ServicioCodigo,'P','C')  
   ELSE P.ServicioCodigo  
  END  
  AND VP.TipoFacturacion = 'CON'   
  AND VP.CompaniaSocio = E.CompaniaSocio   
  AND VP.UnidadNegocio = S.Sucursal  
  WHERE M.IdMatricula = @IdMatricula  
  AND MP.Estado = 'R'  
  AND VP.CompaniaSocio = @CompaniaSocio  
  AND EXISTS  
  (  
   SELECT  
    1  
   FROM DescuentoAcademicoPoblacionDestino WITH (NOLOCK) --@23  
   where IdDescuentoAcademico = @IdDescuentoAcademico  
   AND IdUnidadAcademica = P.IdUnidadAcademica   
   AND IdPeriodo = PE.IdPeriodo  
  )  
  
  --Matriculas por productos con mismo precios  
  SELECT  
   @CantMatriculas = COUNT(DISTINCT M.IdMatricula)  
  FROM Matricula M WITH (NOLOCK)  
  INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
  INNER JOIN Sede S WITH (NOLOCK) ON P.IdSede = S.IdSede  
  INNER JOIN Empresa E WITH (NOLOCK) ON P.IdEmpresa = E.IdEmpresa  
  INNER JOIN MatriculaPagante MP WITH (NOLOCK) ON M.IdMatricula = MP.IdMatricula  
  INNER JOIN vw_CO_Precio VP WITH (NOLOCK) ON VP.ItemCodigo =  
  CASE  
   WHEN @TipoServicio = 'C' THEN REPLACE(P.ServicioCodigo,'P','C')  
   ELSE P.ServicioCodigo  
  END  
  AND VP.TipoFacturacion = 'CON'   
  AND VP.CompaniaSocio = E.CompaniaSocio   
  AND VP.UnidadNegocio = S.Sucursal  
  WHERE MP.IdActor = @IdActorPagante   
  AND P.IdUnidadAcademica = @IdUnidadAcademica  
  AND VP.Monto = @MontoProducto  
  AND VP.CompaniaSocio =  @CompaniaSocio  
  AND S.Sucursal = @Sucursal  
  AND M.Estado <> 'X'  
  AND MP.Estado = 'R'  
  AND EXISTS  
  (  
   SELECT  
    1  
   FROM DescuentoAcademicoPoblacionDestino WITH (NOLOCK) --@23   
   WHERE IdDescuentoAcademico = @IdDescuentoAcademico  
   AND IdUnidadAcademica = P.IdUnidadAcademica   
   AND IdPeriodo = P.IdPeriodo  
  )  
    
  --Matriculas por periodos seguidos  
  DECLARE  
   @IdPeriodoAnterior2 INT  
  
  SET @CantPeriodos = 1  
    
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)  
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo   
   INNER JOIN MatriculaPagante MP WITH (NOLOCK) ON M.IdMatricula = MP.IdMatricula  
   WHERE P.IdUnidadAcademica = @IdUnidadAcademica   
   AND MP.IdActor = @IdActorPagante  
   AND PE.IdPeriodo = @IdPeriodoAnterior  
   AND MP.Estado = 'R'  
   AND M.Estado <> 'X'  
  )  
  AND EXISTS  
  (  
   SELECT  
    1  
   FROM DescuentoAcademicoPoblacionDestino WITH (NOLOCK) --@23  
   WHERE IdDescuentoAcademico = @IdDescuentoAcademico  
   AND IdUnidadAcademica = @IdUnidadAcademica   
   AND IdPeriodo = @IdPeriodoAnterior  
  )  
  BEGIN  
  
   SET @CantPeriodos = 2  
  
   SELECT  
    @IdPeriodoAnterior2 = IdPeriodoAnterior  
   FROM Periodo WITH (NOLOCK)  
   WHERE IdPeriodo = @IdPeriodoAnterior   
  
   IF EXISTS  
   (  
    SELECT  
     1  
    FROM Matricula M WITH (NOLOCK)  
    INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
    INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo   
    INNER JOIN MatriculaPagante MP WITH (NOLOCK) ON M.IdMatricula = MP.IdMatricula  
    WHERE P.IdUnidadAcademica = @IdUnidadAcademica   
    AND MP.IdActor = @IdActorPagante  
    AND PE.IdPeriodo = @IdPeriodoAnterior2  
    AND MP.Estado = 'R'  
    AND M.Estado <> 'X'  
   )  
   AND EXISTS  
   (  
    SELECT  
     1  
    FROM DescuentoAcademicoPoblacionDestino WITH(NOLOCK) --@23  
    WHERE IdDescuentoAcademico = @IdDescuentoAcademico  
    AND IdUnidadAcademica = @IdUnidadAcademica   
    AND IdPeriodo = @IdPeriodoAnterior2  
   )  
   BEGIN  
  
    SET @CantPeriodos = 3  
  
   END  
  
  END  
  
  --Matriculados a dos productos mismo precio o dos periodos seguidos  
  IF  
  (  
   @TipoMatricula = 'CAPTACI�N' AND  
   (  
    @CantMatriculas = 2  
    OR @CantPeriodos = 2  
   )  
   AND @CodigoTipoConsulta = 'TIPMATPRP2'  
  )  
  BEGIN  
  
   SET  @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
  --Matriculados a tres productos mismo precio o tres periodos seguidos  
  IF  
  (  
   @TipoMatricula = 'CAPTACI�N'  
   AND  
   (  
    @CantMatriculas = 3  
    OR @CantPeriodos = 3  
   )  
   AND @CodigoTipoConsulta = 'TIPMATPRP3'  
  )  
  BEGIN  
  
   SET  @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
 --Fin @22  
  
 --Inicio @24  
 IF @CodigoTipoConsulta = 'TIPMATPRCO'   
 BEGIN  
  
  --Contado y Producto  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula WITH (NOLOCK)   
   WHERE IdMatricula = @IdMatricula  
   AND CondicionPago = 'C'  
   AND TipoServicio = 'P'  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
  
 IF @CodigoTipoConsulta = 'DOCDICCPA'   
 BEGIN  
  
  SELECT @TipoServicio = TipoServicio --@65  
  FROM Matricula WITH(NOLOCK)   
  WHERE IdMatricula = @IdMatricula  
  
  --Docentes vigentes  
  IF EXISTS   
  (  
   SELECT  
    1  
   FROM SeccionProfesor SP WITH (NOLOCK)    
   INNER JOIN Seccion S WITH (NOLOCK) ON SP.IdSeccion = S.IdSeccion    
   INNER JOIN promocion PR WITH (NOLOCK) ON PR.IdPromocion = S.IdPromocion    
   INNER JOIN periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo    
   INNER JOIN UnidadNegocio UN WITH(NOLOCK) ON UN.IdUnidadNegocio = PR.IdUnidadNegocio   
   WHERE SP.IdActor = @IdActor    
   AND YEAR(GETDATE()) = PE.IdPeriodoAnual  
  )  
  AND @TipoServicio = 'P' --@25  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END   
  
 END  
  
 IF @CodigoTipoConsulta = 'TIPMATQPPA'   
 BEGIN  
  
  SELECT  
   @TipoServicio = TipoServicio --@65  
  FROM Matricula WITH (NOLOCK)   
  WHERE IdMatricula = @IdMatricula  
  
  --Alumnos matriculados de carrera  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)   
   INNER JOIN AlumnoCurso AC WITH (NOLOCK) ON M.IdMatricula = AC.IdMatricula  
   INNER JOIN Promocion PR WITH (NOLOCK) ON M.IdPromocion = PR.IdPromocion  
   INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo  
   INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON UN.IdUnidadNegocio = PR.IdUnidadNegocio --@26  
   WHERE M.Estado <> 'X'  
   AND AC.IdPromocion IS NOT NULL  
   AND AC.IdGrupo IS NOT NULL  
   AND M.IdActor = @IdActor  
   AND M.EsMatricula = 1 --@25  
   AND UN.TipoServicio = 'C' --@26  
   AND YEAR(GETDATE()) = PE.IdPeriodoAnual  
  )  
  AND @TipoServicio = 'P' --@25  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END   
  
 END  
 --Fin @24  
  
 --inicio @38  
 IF @CodigoTipoConsulta = 'TIPMATPLPV'   
 BEGIN  
  
  --Alumnos matriculados de programas libres y peac virtual  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)   
   INNER JOIN AlumnoCurso AC WITH (NOLOCK) ON M.IdMatricula = AC.IdMatricula  
   INNER JOIN Promocion PR WITH (NOLOCK) ON M.IdPromocion = PR.IdPromocion  
   INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo  
   INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON UN.IdUnidadNegocio = PR.IdUnidadNegocio   
   WHERE M.IdActor = @IdActor  
   AND M.EsMatricula = 1    
   AND M.Estado <> 'X'  
   AND AC.IdPromocion IS NOT NULL  
   AND AC.IdGrupo IS NOT NULL  
   AND YEAR(GETDATE()) = PE.IdPeriodoAnual  
   AND (PR.IdUnidadAcademica = 63 OR PR.IdUnidadAcademica = 48) --@46  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END   
  
 END  
 --fin @38  
  
 --Inicio @32  
 --DESCUENTO AMERICA TV 50% COLEGIOS PUBLICOS  
 IF @CodigoTipoConsulta = 'TIP0000009'   
 BEGIN  
  
  SELECT  
   @IdColegio = IdColegio  
  FROM ActorAcademica WITH (NOLOCK)  
  WHERE IdActor = @IdActor  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Colegio WITH (NOLOCK)  
   WHERE IdColegio =  @IdColegio   
   AND CONVERT(VARCHAR,FechaModificacion,112) = CONVERT(VARCHAR,GETDATE(),112)   
   AND DATEPART(HOUR,FechaModificacion) = DATEPART(HOUR,GETDATE())  
   AND UsuarioModificacion = @UsuarioCreacion  
   AND IdTipoGestion = 788  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
  
 --DESCUENTO AMERICA TV 25% COLEGIOS PRIVADOS  
 IF @CodigoTipoConsulta = 'TIP0000010'   
 BEGIN  
  
  SELECT  
   @IdColegio = IdColegio  
  FROM ActorAcademica WITH (NOLOCK)  
  WHERE IdActor = @IdActor  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Colegio WITH (NOLOCK)  
   WHERE IdColegio =  @IdColegio   
   AND CONVERT(VARCHAR,FechaModificacion,112) = CONVERT(VARCHAR,GETDATE(),112)   
   AND DATEPART(HOUR,FechaModificacion) = DATEPART(HOUR,GETDATE())  
   AND UsuarioModificacion = @UsuarioCreacion  
   AND IdTipoGestion = 789  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
 --Fin @32  
    
 --Inicio @40  
 --DESCUENTO AMERICA TV COLEGIOS PUBLICOS/PRIVADOS    
 IF @CodigoTipoConsulta = 'TIPZEG002'   
 BEGIN  
  
  SELECT  
   @IdColegio = IdColegio  
  FROM ActorAcademica WITH (NOLOCK)  
  WHERE IdActor = @IdActor  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Colegio WITH (NOLOCK)  
   WHERE IdColegio =  @IdColegio   
   AND CONVERT(VARCHAR,FechaModificacion,112) = CONVERT(VARCHAR,GETDATE(),112)   
   AND DATEPART(HOUR,FechaModificacion) = DATEPART(HOUR,GETDATE())  
   AND UsuarioModificacion = @UsuarioCreacion  
   AND IdTipoGestion IN (788,789)  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
 --Fin @40  
  
 --@39 TIPIDAT002 ALUMNOS DE C/S I SEMESTRE - NO REPITENTES MAYOR O IGUAL A 5 CURSOS  
 IF @CodigoTipoConsulta = 'TIPIDAT002'   
 BEGIN  
  
  --SI EL ALUMNO NO ES SECUENCIAL   
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula WITH (NOLOCK)  
   WHERE IdMatricula  = @IdMatricula  
   AND Estado <> 'X'  
   AND IdPeriodo IS NULL  
   AND TIPO = 'MA'  
   AND IdModulo = 1  
   AND EsMatricula = 0  
  )   
  BEGIN   
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  ELSE  
  BEGIN  
      
   --@41 Validamos por captacion si es descuento manual   
   IF  
   (  
    @TipoMatricula IN ('CAPTACI�N','AMBOS')  
    AND ISNULL(@IdMatricula,-1) = -1  
   )  
   BEGIN  
  
    SET @Retorno = 1   
    RETURN @Retorno   
  
   END  
  
   SELECT  
    @TipoCondicion = TipoCondicion,   
    @IdCurricula = IdCurricula,    
    @IdModulo = IdModulo    
   FROM Matricula WITH (NOLOCK)    
   WHERE IdMatricula = @IdMatricula   
   
   SELECT  
    @Matriculados = COUNT(1)  
   FROM AlumnoCurso WITH (NOLOCK)  
   WHERE IdMatricula = @IdMatricula  
   AND IdSeccion IS NOT NULL   
   
   IF  
   (  
    @Matriculados >= 5  
    AND @IdModulo = 1  
   )  
   BEGIN  
  
    SET @Retorno = 1   
    RETURN @Retorno  
  
   END   
   ELSE   
   BEGIN  
  
    SET @Retorno = 0   
    RETURN @Retorno  
  
   END  
      
  END    
  
 END  
  
 -- BECA ACTIVATE SECUENCIALES   
  IF @CodigoTipoConsulta IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019','TIP0000037','TIP0000043','TIP0000049','TIP0000050') --@63 @64 @91 @95  
  BEGIN  
   IF @CompaniaSocioAcademico <> '00002500'--@92  --@96
   BEGIN  
    DECLARE @pDescripcion varchar(100)  
    EXEC cAsignacion_BecaActivate @IdMatricula=@IdMatricula,@CodigoBase=@CodigoTipoConsulta,@Retorno= @Retorno output, @pDescripcion =@pDescripcion output--@89  
    RETURN @Retorno  
   END  
  END  
 --@47 Fin  
  
 IF @CodigoTipoConsulta = 'TIP0000015'  
 BEGIN  
  
  SELECT  
   @IdModulo = IdModulo,   
   @IdRegistro = IdRegistro,  
   @TipoCondicion = TipoCondicion,  
   @TipoMat = Tipo  
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatricula     
  
  SET @IdMatriculaAnt =  
  (  
   SELECT TOP 1  
    IdMatricula  
   FROM Matricula M WITH (NOLOCK)   
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN Producto PRO WITH (NOLOCK) ON P.IdProducto = PRO.IdProducto  
   AND PRO.IdTipo = 1   
   WHERE M.IdActor = @IdActor  
   AND M.IdRegistro = @IdRegistro    
   AND M.Estado = 'N'  
   AND EsMatricula = 1     
   AND M.TipoCondicion = 'RE'   
   ORDER BY ISNULL(M.MatriculaFecha,M.InscritoFecha) DESC  
  )   
  
  SELECT  
   @IdModuloAnt = IdModulo  
  FROM Matricula WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatriculaAnt  
  
  SELECT  
   @PromedioReal = PromedioReal  
  FROM PromocionGrupoCierre WITH (NOLOCK)  
  WHERE IdMatricula = @IdMatriculaAnt  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM DescuentoAlumno DA WITH (NOLOCK)  
   INNER JOIN DescuentoAcademicoPoblacion DAP WITH (NOLOCK) ON DA.IdDescuentoAcademico = DAP.IdDescuentoAcademico  
   INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON DAP.IdTipoSituacionAlumno = MTR.IdMaestroRegistro  
   WHERE IdMatricula = @IdMatricula  
   AND MTR.Codigo IN  
   (  
    'TIPZEG002',  
    'TIP0000015'  
   )  
  )  
  BEGIN  
  
   IF  
   (  
    @TipoCondicion = 'RE'  
    AND (@IdModulo = @IdModuloAnt + 1)  
   )  
   BEGIN  
  
    IF @PromedioReal >= 18   
    BEGIN  
  
     SET @Retorno = 1   
     RETURN @Retorno  
  
    END  
    ELSE  
    BEGIN  
  
     SET @Retorno = 0  
     RETURN @Retorno  
  
    END  
      
   END  
   ELSE  
   BEGIN  
  
    SET @Retorno = 0   
    RETURN @Retorno  
  
   END  
  
  END  
  ELSE  
  BEGIN  
  
   SET @Retorno = 0   
   RETURN @Retorno  
  
  END  
  
 END  
  
 --@43 ALUMNOS DE AREQUIPA Y CUSCO MATRICULADOS EN CARRERA DEL PERIODO 2021-II  
 IF @CodigoTipoConsulta = 'TIPZEG003'  
 BEGIN  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)  
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
   WHERE PE.Codigo = '2021-II'  
   AND P.IdUnidadNegocio = 1  
   AND P.IdSede IN (2,13)  
   AND M.IdModulo = 1  
   AND M.TipoServicio = 'P'  
   AND M.Estado = 'N'  
   AND M.EsMatricula = 1  
  )  
  BEGIN  
  
   SET @Retorno = 1    
   RETURN @Retorno  
  
  END  
  ELSE  
  BEGIN  
  
   SET @Retorno = 0   
   RETURN @Retorno  
  
  END  
  
 END  
  
 --@68 ALUMNOS MATRICULADOS EN DIPLOMADO EN BRANDING Y CREACI�N DE MARCA A PARTIR DEL 2022-10   
 IF @CodigoTipoConsulta = 'TIPIDAT006'  
 BEGIN  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)  
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
   WHERE M.IdActor = @IdActor  
   AND P.IdUnidadNegocio = 2  
   AND P.IdUnidadAcademica = 48   
   AND P.IdProducto = 11437  
   AND M.Estado = 'N'  
   AND M.EsMatricula = 1  
   AND CONVERT(INT, REPLACE(PE.Codigo, '-','')) >= 202210 --Los diplomados no llevan letra en su codigo de periodo   
  )  
  BEGIN  
  
   SET @Retorno = 1    
   RETURN @Retorno  
  
  END  
  ELSE  
  BEGIN  
  
   SET @Retorno = 0   
   RETURN @Retorno  
  
  END  
  
 END  
  
 --@72 PROSPECTOS EGRESADOS DE COLEGIOS DEL A�O ACTUAL Y 5 A�OS ATRAS.   
 IF @CodigoTipoConsulta = 'TIPALCOLEG'  
 BEGIN  
    
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM ActorAcademica AA WITH (NOLOCK)  
   WHERE AA.IdActor = @IdActor  
   AND AnnoEgreso BETWEEN YEAR(GETDATE())-5 AND YEAR(GETDATE())  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END   
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Interesado WITH (NOLOCK)   
   WHERE NombreCompleto =  
   (  
    SELECT  
     NombreCompleto  
    FROM Actor WITH (NOLOCK)    
    WHERE IdActor = @IdActor  
   )    
   AND AnnoEgreso BETWEEN YEAR(GETDATE())-5 AND YEAR(GETDATE())  
  )   
  BEGIN  
  
   SET @Retorno = 1  
   RETURN @Retorno  
  
  END   
  
 END   
     
 --@77 Inicio ALUMNOS MATRICULADOS SIN DESCUENTO (CRONOGRAMA ALTERNA) -IDAT  
 IF @CodigoTipoConsulta = 'TIP0000021'  
 BEGIN  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula MA WITH (NOLOCK)  
   WHERE MA.IdMatricula = @IdMatricula  
   AND MA.IdTipoCronograma = 46364  
  )  
  BEGIN  
  
   SET @Retorno = 1   
   RETURN @Retorno  
  
  END  
  
 END  
 --@77 Fin  
  
 --Inicio --@78  
 --ALUMNOS MATRICULADOS EN EL PERIODO ACTUAL - CARRERAS ZEGEL - IDAT  
 IF @CodigoTipoConsulta = 'TIP0000022'  
 BEGIN  
  
  SET @Retorno = 0  
     
  SELECT  
   @Retorno = COUNT(1)  
  FROM Matricula M WITH (NOLOCK)   
  INNER JOIN Promocion PRO  WITH (NOLOCK) ON PRO.IdPromocion = M.IdPromocion    
  INNER JOIN Periodo PE WITH (NOLOCK) ON PE.IdPeriodo = PRO.IdPeriodo    
  WHERE M.IdActor = @IdActor   
  AND M.EsMatricula = 1   
  AND M.Estado = 'N'   
  AND PRO.IdUnidadNegocio = 1  
  AND (CONVERT(VARCHAR,GETDATE(),112) BETWEEN CONVERT(VARCHAR, PE.Inicio ,112) AND CONVERT(VARCHAR, PE.Fin ,112))  
  
  IF @Retorno = 0  
  BEGIN  
  
   SELECT  
    @ServidorVinculado = Valor,  
    @BaseDatos = Valor2  
   FROM Parametro WITH (NOLOCK)   
   WHERE Nombre =  
   CASE  
    WHEN @CompaniaSocio = '00002700' THEN 'ServidorVinculadoAcademicoZegel'   
    WHEN @CompaniaSocio = '00002500' OR @CompaniaSocio ='00002400' THEN 'ServidorVinculadoAcademicoIdat'  --@87  
    ELSE ''  
   END  
  
   SET @ParamCadSql =  
   '  
   @Retorno INT OUTPUT,  
   @IdActor INT  
   '  
  
   SET @CadSql =  
   '  
    SELECT  
     @Retorno = COUNT(1)  
    FROM ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Matricula M WITH (NOLOCK)   
    INNER JOIN '+ @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Promocion PRO WITH (NOLOCK) ON PRO.IdPromocion = M.IdPromocion    
    INNER JOIN '+ @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Periodo PE WITH (NOLOCK) ON PE.IdPeriodo = PRO.IdPeriodo    
    WHERE M.IdActor = @IdActor   
    AND M.EsMatricula = 1   
    AND M.Estado = ''N''   
    AND PRO.IdUnidadNegocio = 1  
    AND (CONVERT(VARCHAR,GETDATE(),112) BETWEEN CONVERT(VARCHAR, PE.Inicio ,112) AND CONVERT(VARCHAR, PE.Fin ,112))  
   '   
  
   EXEC sp_executesql  
   @CadSql,  
   @ParamCadSql,  
   @Retorno = @Retorno OUTPUT,  
   @IdActor = @IdActor  
  
  END   
  
  RETURN @Retorno  
  
 END  
  
 --ALUMNOS MATRICULADOS EN EL PERIODO ACTUAL O HAYAN TERMINADO UN DIPLOMADO O CURSO - ZEGEL - IDAT  
 IF @CodigoTipoConsulta = 'TIP0000023'  
 BEGIN  
  
  SET @Retorno = 0    
     
  SELECT  
   @Retorno = COUNT(1)  
  FROM Matricula M WITH (NOLOCK)   
  INNER JOIN Promocion PRO  WITH (NOLOCK) ON PRO.IdPromocion = M.IdPromocion    
  INNER JOIN Periodo PE WITH (NOLOCK) ON PE.IdPeriodo = PRO.IdPeriodo  
  INNER JOIN Producto PROD WITH (NOLOCK) ON PROD.IdProducto = PRO.IdProducto  
  INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroRegistro = PROD.IdClasificacionProducto  
  WHERE M.IdActor = @IdActor   
  AND M.EsMatricula = 1  
  AND PRO.IdUnidadNegocio = 2  
  AND  
  (  
   (  
    MTR.IdMaestroRegistro IN (23351,23356)  
    AND @CompaniaSocio = '00002700'  
   )  
   OR  
   (  
    (  
     @CompaniaSocio='00002500'  
     OR @CompaniaSocio = '00002400' --@87  
    )   
    AND PRO.IdUnidadAcademica IN (63,2)  
   )   
  )  
  AND M.Estado = 'N'   
  AND  
  (  
   (CONVERT(VARCHAR,GETDATE(),112) BETWEEN CONVERT(VARCHAR, PRO.FechaInicioPeriodo ,112) AND CONVERT(VARCHAR, PRO.FechaFinPeriodo ,112))  
   OR (CONVERT(VARCHAR, PRO.FechaFinPeriodo ,112) < CONVERT(VARCHAR,GETDATE(),112))  
  )  
  
  IF @Retorno = 0  
  BEGIN  
     
   SELECT  
    @ServidorVinculado = Valor,  
    @BaseDatos = Valor2  
   FROM Parametro WITH(NOLOCK)   
   WHERE Nombre =  
   CASE  
    WHEN @CompaniaSocio = '00002700' THEN 'ServidorVinculadoAcademicoZegel'   
    WHEN @CompaniaSocio = '00002500' OR @CompaniaSocio = '00002400' THEN 'ServidorVinculadoAcademicoIdat' --@87  
    ELSE ''  
   END  
  
   SET @ParamCadSql =  
   '  
   @Retorno INT OUTPUT,  
   @IdActor INT,  
   @CompaniaSocio CHAR(8)  
   '  
  
   SET @CadSql =  
   '  
   SELECT  
    @Retorno = COUNT(1)  
   FROM ' + @ServidorVinculado + '.' + @BaseDatos + '.' +' dbo.Matricula M WITH (NOLOCK)   
   INNER JOIN ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Promocion PRO WITH (NOLOCK) ON PRO.IdPromocion = M.IdPromocion    
   INNER JOIN ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Periodo PE WITH (NOLOCK) ON PE.IdPeriodo = PRO.IdPeriodo    
   INNER JOIN ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Producto PROD WITH (NOLOCK) ON PROD.IdProducto = PRO.IdProducto  
   INNER JOIN ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroRegistro = PROD.IdClasificacionProducto  
   WHERE M.IdActor = @IdActor   
   AND M.EsMatricula = 1  
   AND PRO.IdUnidadNegocio = 2  
   AND  
   (  
    (  
     MTR.IdMaestroRegistro IN (23351,23356)  
     AND @CompaniaSocio = ''00002700''  
    )  
    OR  
    (  
     (  
      @CompaniaSocio = ''00002500''  
      OR @CompaniaSocio = ''00002400'' --@87  
     )  
     AND PRO.IdUnidadAcademica IN (63,2)  
    )  
   )  
   AND M.Estado = ''N''   
   AND  
   (  
    (CONVERT(VARCHAR,GETDATE(),112) BETWEEN CONVERT(VARCHAR, PRO.FechaInicioPeriodo ,112) AND CONVERT(VARCHAR, PRO.FechaFinPeriodo ,112)) --@87  
    OR (CONVERT(VARCHAR, PRO.FechaFinPeriodo ,112) < CONVERT(VARCHAR,GETDATE(),112))  
   )  
   '  
  
   EXEC sp_executesql  
   @CadSql,@ParamCadSql,  
   @Retorno = @Retorno OUTPUT,  
   @IdActor = @IdActor,  
   @CompaniaSocio = @CompaniaSocio  
  
  END   
  
  RETURN @Retorno  
  
 END  
  
 --ALUMNOS CON PRE-MATRICULAS EN ALGUN CURSO DE EXTENSION PASADO ZEGEL - IDAT  
 IF @CodigoTipoConsulta = 'TIP0000024'  
 BEGIN  
  
  SET @Retorno = 0   
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Matricula M WITH (NOLOCK)  
  INNER JOIN Promocion PR WITH (NOLOCK) ON PR.IdPromocion = M.IDPROMOCION  
  INNER JOIN Producto PROD WITH (NOLOCK) ON PROD.IdProducto = PR.IdProducto  
  INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroRegistro = PROD.IdClasificacionProducto  
  WHERE M.EsMatricula = 0 AND M.Estado = 'N'  
  AND M.IdActor = @idactor  
  AND PR.IdUnidadNegocio = 2  
  AND  
  (  
   (  
    MTR.IdMaestroRegistro IN (23351,23356)  
    AND @CompaniaSocio = '00002700'  
   )  
   OR  
   (  
    (  
     @CompaniaSocio = '00002500'  
     OR @CompaniaSocio = '00002400' --@87  
    )  
    AND PR.IdUnidadAcademica IN (63,2)  
   )  
  )  
  AND  
  (  
   CONVERT(VARCHAR, PR.FechaInicioPeriodo ,112) <= CONVERT(VARCHAR,DATEADD(MONTH,-1,GETDATE()),112)    
   AND CONVERT(VARCHAR,DATEADD(YEAR,-1,GETDATE()),112) >= CONVERT(VARCHAR, PR.FechaInicioPeriodo ,112)  
  )  
  
  IF @Retorno = 0  
  BEGIN  
  
   SELECT  
    @ServidorVinculado = Valor,  
    @BaseDatos = Valor2  
   FROM Parametro WITH (NOLOCK)   
   WHERE Nombre =  
   CASE  
    WHEN @CompaniaSocio = '00002700' THEN 'ServidorVinculadoAcademicoZegel'   
    WHEN @CompaniaSocio = '00002500' OR @CompaniaSocio = '00002400' THEN 'ServidorVinculadoAcademicoIdat' --@87  
    ELSE ''  
   END  
  
   SET @ParamCadSql =  
   '  
   @Retorno INT OUTPUT,  
   @IdActor INT,  
   @CompaniaSocio CHAR(8)  
   '  
  
   SET @CadSql =  
   '  
   SELECT @Retorno = COUNT(1)  
   FROM ' + @ServidorVinculado + '.' + @BaseDatos + '.' +'dbo.Matricula M WITH (NOLOCK)   
   INNER JOIN ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Promocion PR WITH (NOLOCK) ON PR.IdPromocion = M.IdPromocion  
   INNER JOIN ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Producto PROD WITH (NOLOCK) ON PROD.IdProducto = PR.IdProducto  
   INNER JOIN ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroRegistro = PROD.IdClasificacionProducto  
   WHERE M.EsMatricula = 0  
   AND M.Estado = ''N''  
   AND M.IdActor = @idactor  
   AND PR.IdUnidadNegocio = 2  
   AND   
   (  
    (  
     MTR.IdMaestroRegistro IN (23351,23356)  
     AND @CompaniaSocio = ''00002700''  
    )  
    OR  
    (  
     (  
      @CompaniaSocio = ''00002500''  
      OR @CompaniaSocio = ''00002400'' --@87  
     )  
     AND PR.IdUnidadAcademica IN (63,2)  
    )  
   )  
   AND  
   (  
    CONVERT(VARCHAR, PR.FechaInicioPeriodo ,112) <= CONVERT(VARCHAR,DATEADD(MONTH,-1,GETDATE()),112)    
    AND CONVERT(VARCHAR,DATEADD(YEAR,-1,GETDATE()),112) >= CONVERT(VARCHAR, PR.FechaInicioPeriodo ,112)  
   )  
   '   
  
   EXEC sp_executesql  
   @CadSql,  
   @ParamCadSql,  
   @Retorno = @Retorno OUTPUT,  
   @IdActor = @IdActor,  
   @CompaniaSocio = @CompaniaSocio  
  
  END   
  
  RETURN @Retorno  
  
 END  
  
 --ALUMNOS EGRESADOS IDAT - ZEGEL  
 IF @CodigoTipoConsulta = 'TIP0000025'  
 BEGIN  
  
  SET @Retorno = 0    
  
  SELECT  
   @Retorno = COUNT(1)  
  FROM Egresados E WITH (NOLOCK)  
  INNER JOIN Periodo PE WITH (NOLOCK) ON PE.IdPeriodo =  E.IdPeriodoEgreso    
  WHERE IdAlumno = @IdActor   
  AND e.IdUnidadAcademica = 1   
  
  IF  
  (  
   @Retorno = 0  
   AND  
   (  
    @CompaniaSocio = '00002500'   
    OR @CompaniaSocio = '00002400' --@87  
   )  
  )  
  BEGIN  
  
   SELECT  
    @NumeroIdentidad = NumeroIdentidad   
   FROM Actor WITH (NOLOCK)    
   WHERE IdActor = @IdActor   
  
   SELECT  
    @Retorno = COUNT(1)    
   FROM Gupta.dbo.Egresados E WITH (NOLOCK)    
   INNER JOIN Gupta.dbo.PERSONAS PE WITH (NOLOCK) ON E.CD_CLTE = PE.CD_PERS    
   WHERE PE.NR_DOCUIDEN = @NumeroIdentidad   
   AND E.CD_AREA = '01'  
  
  END  
  
  IF @Retorno = 0  
  BEGIN  
  
   SELECT  
    @ServidorVinculado = Valor, @BaseDatos = Valor2  
   FROM Parametro WITH (NOLOCK)   
   WHERE Nombre =  
   CASE  
    WHEN @CompaniaSocio = '00002700' THEN 'ServidorVinculadoAcademicoZegel'   
    WHEN @CompaniaSocio = '00002500' OR  @CompaniaSocio = '00002400' THEN 'ServidorVinculadoAcademicoIdat' --@87  
    ELSE ''  
   END  
  
   SET @ParamCadSql =  
   '  
   @Retorno INT OUTPUT,  
   @IdActor INT  
   '  
  
   SET @CadSql =  
   '  
   SELECT  
    @Retorno = COUNT(1)  
   FROM ' + @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Egresados E WITH (NOLOCK)  
   INNER JOIN '+ @ServidorVinculado + '.' + @BaseDatos + '.' + 'dbo.Periodo PE WITH (NOLOCK) ON PE.IdPeriodo = E.IdPeriodoEgreso    
   WHERE IdAlumno = @IdActor  
   AND E.IdUnidadAcademica = 1  
   '   
  
   EXEC sp_executesql  
   @CadSql,  
   @ParamCadSql,  
   @Retorno = @Retorno OUTPUT,  
   @IdActor = @IdActor  
  
  END   
     
  RETURN @Retorno  
  
 END  
 --Fin --@78  
  
 --INICIO @79  
 IF @CodigoTipoConsulta = 'TIP0000026'   
 BEGIN  
  
  --SI TIENE MENOS O IGUAL A 18 A�OS SE LE APLICA EL DESCUENTO  
  --SE PONE LA EDAD DE 19 A LOS USUARIOS QUE TIENEN NULL COMO FECHA DE NACIMIENTO  
  SET @Retorno =  
  (  
   SELECT  
    CASE  
     WHEN(ISNULL(DATEDIFF(YEAR,FechaNacimiento,GETDATE()),19)) BETWEEN 14 AND 18 THEN 1  
     ELSE 0  
   END AS EDAD  
   FROM Actor WITH (NOLOCK)  
   WHERE IdActor = @IdActor  
  )  
  
  RETURN @Retorno  
   
 END  
 --FIN @79  
  
 --Inicio --@82  
 --Alumnos que ya estan PreMatriculados o Matriculados mas de una vez a partir en los siguientes Diplomados: Diplomado en Recursos Humanos, Diplomado en Gesti�n de Proyectos, Diplomado en Administraci�n, Diplomado en Gestion Publica, Diplomado en Marketi
 --ng Digital; obtendran un 30% de Descuento en su Segunda Cuota solo para la Marca Zegel  
 IF  
 (  
  @CodigoTipoConsulta = 'DSC30DIPZG' --Base DSC30DIPZG: DESCUENTO DEL 30% EN LA CUOTA 2 SOLO PARA DIPLOMADOS - EGRESADOS Y ALUMNOS DE ZEGEL   
  AND  
  (  
   @CompaniaSocio = '00002500'   
   OR @CompaniaSocio = '00002400'--@87  
  )  
 )  
 BEGIN  
  
  --Alumnos que Egresaron desde el 20/11/2023 hasta los 6 meses a partir de la Fecha de Inicio de Clases o la Fecha de Creacion de la Matricula  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)  
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON P.IdPromocion = PG.IdPromocion  
   AND M.IdGrupo = PG.IdGrupo  
   INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
   INNER JOIN Egresados EG WITH (NOLOCK) ON M.IdActor = EG.IdAlumno  
   AND P.IdUnidadAcademica = EG.IdUnidadAcademica  
   AND PE.IdPeriodo = EG.IdPeriodoEgreso  
   AND M.IdRegistro = EG.IdRegistro  
   AND P.IdCurricula = EG.IdCurricula  
   WHERE M.IdActor = @IdActor  
   AND P.IdUnidadNegocio = 2  
   AND P.IdUnidadAcademica = 48   
   AND P.IdProducto IN  
   (  
    10556,  
    10564,  
    11135,  
    11557,  
    14032  
   )  
   AND M.Estado = 'N'  
   AND (CONVERT(VARCHAR,EG.FechaCreacion,112) >= '20231120')  
  )  
  BEGIN  
  
   SELECT  
    @CantMatriculas = COUNT(IdMatricula)  
   FROM Matricula M WITH (NOLOCK)  
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON P.IdPromocion = PG.IdPromocion  
   AND M.IdGrupo = PG.IdGrupo  
   INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
   WHERE M.IdActor = @IdActor  
   AND P.IdUnidadNegocio = 2  
   AND P.IdUnidadAcademica = 48   
   AND P.IdProducto IN  
   (  
    10556,  
    10564,  
    11135,  
    11557,  
    14032  
   )  
   AND M.Estado = 'N'  
   AND (CONVERT(VARCHAR,M.FechaCreacion,112) BETWEEN '20231120' AND CONVERT(VARCHAR,CONVERT(DATETIME,DATEADD(MONTH, 6, ISNULL(PG.FechaInicio,M.FechaCreacion)),112)))  
  
   IF @CantMatriculas >= 2  
   BEGIN  
  
    IF EXISTS  
    (  
     SELECT  
      1  
     FROM Matricula M WITH (NOLOCK)  
     INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
     INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON P.IdPromocion = PG.IdPromocion  
     AND M.IdGrupo = PG.IdGrupo  
     INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
     WHERE M.IdActor = @IdActor  
     AND M.IdMatricula = @IdMatricula  
     AND P.IdUnidadNegocio = 2  
     AND P.IdUnidadAcademica = 48   
     AND P.IdProducto IN  
     (  
      10556,  
      10564,  
      11135,  
      11557,  
      14032  
     )  
     AND M.Estado = 'N'  
     AND (CONVERT(VARCHAR,M.FechaCreacion,112) BETWEEN '20231120' AND CONVERT(VARCHAR,CONVERT(DATETIME,DATEADD(MONTH, 6, ISNULL(PG.FechaInicio,M.FechaCreacion)),112)))  
    )  
    BEGIN  
  
     SET @Retorno = 1    
  
    END  
    ELSE  
    BEGIN  
  
     SET @Retorno = 0    
  
    END  
  
   END  
   ELSE  
   BEGIN  
  
    SET @Retorno = 0  
       
   END  
  
   RETURN @Retorno  
  
  END  
  --No Egresados que contemplen la Vigencia del Descuento desde el 20/11/2023 hasta los 6 meses a partir de la Fecha de la Matricula o la Fecha de Creacion de la Matricula  
  ELSE IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)  
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON P.IdPromocion = PG.IdPromocion  
   AND M.IdGrupo = PG.IdGrupo  
   INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
   WHERE M.IdActor = @IdActor  
   AND P.IdUnidadNegocio = 2  
   AND P.IdUnidadAcademica = 48   
   AND P.IdProducto IN  
   (  
    10556,  
    10564,  
    11135,  
    11557,  
    14032  
   )  
   AND M.Estado = 'N'  
  )  
  BEGIN  
  
   SELECT  
    @CantMatriculas = COUNT(IdMatricula)  
   FROM Matricula M WITH (NOLOCK)  
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
   WHERE M.IdActor = @IdActor  
   AND P.IdUnidadNegocio = 2  
   AND P.IdUnidadAcademica = 48   
   AND P.IdProducto IN  
   (  
    10556,  
    10564,  
    11135,  
    11557,  
    14032  
   )  
   AND M.Estado = 'N'  
   AND (CONVERT(VARCHAR,M.FechaCreacion,112) BETWEEN '20231120' AND CONVERT(VARCHAR,CONVERT(DATETIME,DATEADD(MONTH, 6, ISNULL(M.MatriculaFecha,M.FechaCreacion)),112)))  
  
   IF @CantMatriculas >= 2  
   BEGIN  
  
    IF EXISTS  
    (  
     SELECT  
      1  
     FROM Matricula M WITH (NOLOCK)  
     INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
     INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo  
     WHERE M.IdActor = @IdActor  
     AND M.IdMatricula = @IdMatricula  
     AND P.IdUnidadNegocio = 2  
     AND P.IdUnidadAcademica = 48   
     AND P.IdProducto IN  
     (  
      10556,  
      10564,  
      11135,  
      11557,  
      14032  
     )  
     AND M.Estado = 'N'  
     AND (CONVERT(VARCHAR,M.FechaCreacion,112) BETWEEN '20231120' AND CONVERT(VARCHAR,CONVERT(DATETIME,DATEADD(MONTH, 6, ISNULL(M.MatriculaFecha,M.FechaCreacion)),112)))  
    )  
    BEGIN  
  
     SET @Retorno = 1    
  
    END  
    ELSE  
    BEGIN  
  
     SET @Retorno = 0  
  
    END  
  
   END  
   ELSE  
   BEGIN  
  
    SET @Retorno = 0   
       
   END  
  
   RETURN @Retorno  
  
  END  
  ELSE  
  BEGIN  
  
   SET @Retorno = 0  
   RETURN @Retorno  
  
  END  
   
 END  
 --Fin --@82  
  
 --Inicio --@88  
 --ALUMNOS SECUENCIALES ZEGEL EXCLUYENDO ITS, CA Y CDI (No se esta tomando en consideracion la Fusion de las Marcas ZEGEL con CA)  
 IF  
 (  
  @CodigoTipoConsulta = 'TIPMATSECZ'  
  AND @CompaniaSocio = '00002500'  
 )  
 BEGIN  
  
  IF EXISTS  
  (  
   SELECT  
    1  
   FROM Matricula M WITH (NOLOCK)  
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion  
   INNER JOIN Sede S WITH (NOLOCK) ON M.IdSede = S.IdSede  
   WHERE M.IdActor = @IdActor  
   AND M.IdMatricula = @IdMatricula  
   AND P.IdUnidadNegocio = 1  
   AND M.IdModulo > 1  
   AND M.Estado = 'N'  
   AND S.Codigo NOT IN ('IT')  
  )  
  BEGIN  
  
   SET @Retorno = 1    
  
  END  
  ELSE  
  BEGIN  
  
   SET @Retorno = 0  
  
  END  
  
  RETURN @Retorno  
  
 END  
 --Fin --@88  
  
 --ESTE PROCESO SIEMPRE DEBE ESTAR AL FINAL   
 --ALUMNOS DE LA TABLA BASE (DescuentoAcademicoBase)   
 IF  
 (  
  @IdTipoConsulta IN  
  (  
   SELECT DISTINCT  
    IdMaestroRegistro  
   FROM DescuentoAcademicoBase WITH (NOLOCK)  
   WHERE Activo = 1  
   AND IdMaestroRegistro NOT IN  
   (  
    23960,  
    24936,  
    24937  
   )  
  )  
 ) --@27    
 BEGIN   
  
  -- @28  INICIO  
  --Inicio @90  
  /*  
  SELECT    
   @NumeroIdentidad = AC.NumeroIdentidad,   
   @IdDocumentoTipo = AC.IdDocumentoTipo,   
   @IdSede = P.IdSede,    
   @IdUnidadNegocio = P.IdUnidadNegocio,    
   @IdUnidadAcademica = P.IdUnidadAcademica,    
   @IdPeriodo = P.IdPeriodo,  
   @PeriodoCodigo = PE.Codigo  
  FROM Matricula M WITH (NOLOCK)  
  INNER JOIN Actor AC WITH (NOLOCK) ON M.IdActor = AC.IdActor   
  INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion   
  INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.Idperiodo   
  WHERE IdMatricula = @IdMatricula  
  */  
  --Fin @90  
     
  --Inicio @90  
  SELECT    
   @IdSede = PE.IdSede,    
   @IdUnidadNegocio = PE.IdUnidadNegocio,    
   @IdUnidadAcademica = PE.IdUnidadAcademica,    
   @IdPeriodo = PE.IdPeriodo,  
   @PeriodoCodigo = PE.Codigo  
  FROM Periodo PE WITH (NOLOCK)  
  WHERE PE.IdPeriodo = @IdPeriodo  
  
  SELECT  
   @NumeroIdentidad = NumeroIdentidad,   
   @IdDocumentoTipo = IdDocumentoTipo  
  FROM Actor A WITH (NOLOCK)  
  WHERE IdActor = @IdActor  
  --Fin @90  
   
  SELECT  
   @Retorno = COUNT(1)  
  FROM DescuentoAcademicoBase WITH (NOLOCK)    
  WHERE IdMaestroRegistro = @IdTipoConsulta   
  AND Activo = 1   
  AND NumeroIdentidad = @NumeroIdentidad   
  AND (IdActor = @IdActor OR IdActor IS NULL)    
  AND (IdSede = @IdSede OR IdSede IS NULL)  
  AND (IdUnidadNegocio = @IdUnidadNegocio OR IdUnidadNegocio IS NULL)    
  AND (IdUnidadAcademica = @IdUnidadAcademica OR IdUnidadAcademica IS NULL)   
  AND  
  (  
   (  
    IdPeriodo = @IdPeriodo  
    OR IdPeriodo IS NULL  
   )  
   AND  
   (  
    PeriodoCodigo = @PeriodoCodigo  
    OR ISNULL(PeriodoCodigo,'') = ''  
   )  
  )   
  -- @28 FIN  
  
  --Inicio @37  
  SELECT  
   @ListaUsuario = ISNULL(Valor,'')  
  FROM Parametro WITH (NOLOCK)  
  WHERE Nombre = 'DescuentosUsuariosReserva'  
  
  INSERT INTO @UsuariosDescuentos  
  --Inicio --@94  
  (  
   IdUsuario  
  )  
  --Fin --@94  
  SELECT DISTINCT  
   txt_value  
  FROM dbo.uf_Parse(@ListaUsuario,',')  
  --Fin @37  
  
  IF  
  (  
   @CodigoTipoConsulta = 'TIP0000011'  
   AND @UsuarioCreacion NOT IN  
   (  
    SELECT  
     IdUsuario  
    FROM @UsuariosDescuentos  
   ) --@37  
   AND @CompaniaSocio = '00002700' --@36  
  )  
  BEGIN  
  
   SET @Retorno = 0  
  
  END  
     
  RETURN @Retorno   
  
 END  
 --Fin --@94  
  
END  