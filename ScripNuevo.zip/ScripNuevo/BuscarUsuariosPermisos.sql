SELECT 
DISTINCT i3.Nombre Sistema ,i2.Nombre Modulo ,i1.Nombre Formulario,i.Nombre Boton ,r.Nombre Rol , u.Login, u.Nombre  --, u.LoginDeshabilitado  , u.LoginBloqueado
-- distinct r.Nombre    
--distinct u.Login, u.Nombre    
FROM permiso p WITH(NOLOCK)                    
INNER JOIN rolusuario r WITH(NOLOCK) ON p.idrol=r.idrol  and p.IdSistema = r.IdSistema    --@1              
INNER JOIN rolusuarioitem ir WITH(NOLOCK) ON r.idrol=ir.idrol and r.IdSistema = ir.IdSistema  --@1    
INNER JOIN item i WITH(NOLOCK)ON ir.iditem=i.iditem and i.Nivel = 4
INNER JOIN Item i1 WITH(NOLOCK)ON  i1.IdItem = i.IdPadre 
INNER JOIN Item i2 WITH(NOLOCK)ON  i2.IdItem = i1.IdPadre 
INNER JOIN Item i3 WITH(NOLOCK)ON  i3.IdItem = i2.IdPadre 
inner join Usuario u on u.IdUsuario = p.IdUsuario  
inner join Sistema s on s.IdSistema = p.IdSistema 
WHERE --i.Nombre like '%propi%'
--u.Login = 'JUGARTE' and 
i3.Nombre like '%RECLAMO%'		--and  -- ModuloNombre
--i2.Nombre like '%Configuraci�n%'		and -- SubModuloNombre 
--i1.Nombre in ('Estructura y tarifario del facilitador')-- like '%anu%'
--and i.Codigo like '%Anula%' -- boton
  and u.Login not in ('jmota','hmora','ealva','drosel','ilopez','gguillen','JLEOB','NROMERO','sleon','JBERNUYD','JCURE','ILLOSA','ILLOSAD','HCACHI','ELEONC','dvergara','BGARIBAY',
  'MALARCON', 'MBUENO','rpineda','KEHUAMANI','JGUTIERREZ','JQUENTA','EHUILLCA','ECALDAS','ADMINISTRADOR','AFLORESI','AHURTADOA','BGARIBAY', 'PUCHUYA','rsamame','alsanchez','fetorres','JGUILLEN'
  ,'ssilva','rotorres')
  and isnull(u.LoginDeshabilitado,0) = 0 and isnull(u.LoginBloqueado,0) = 0