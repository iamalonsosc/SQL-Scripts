Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--����������������������������������������������������������������������������      
--Creado por      : Jimy Mota(25/04/2018)      
--Funcionalidad   : Permite informacion del actor para sus descuentos       
--Utilizado por   : DescuentoAcademico.SelListarLis      
--Proyecto    : Descuento academico       
--����������������������������������������������������������������������������      
/*        
 - ----------------------------------------------------------------------------      
Nro     FECHA  USUARIO     DESCRIPCION       
 - ----------------------------------------------------------------------------      
 @1  2018.06.25  jmota     debe mostrar el nombre del programa que egreso el alumno  
 @2  2019.05.31  LeandroOrdo�ez(Sigcomt) Modificar el TipoCondici�n  
 @3  2019.09.26  YFlores     Condici�n para no consultar la BD de Gupta para Corriente Alterna  
 @4  2019.11.26  jmota     se agrega nuevas columnas de intituciones y datos spring    
 @5  2019.11.26  jmota     se agrega nuevas columnas de colegio de interesados    
 @6  2019.01.07  jmota     se agrega nuevas columnas de fechas de matricula  
 @7  2020.05.12  jmota     se agrega nuevas columnas de Id de matricula  
 @8  2020.05.26  puchuya     se agrega nueva columna de alumno_retirado   
 @9  2021.01.25  jmota     se modificas columnas para validacion de descuento america tv  
 @10 2021.03.23  jmota     se agregan campos para validacion   
 @11 2021.12.07     rsamame     Se agregan campos para visualizar si pago puntual,su promedio ponderado anterior,si tiene cambio de carrera,o traslado de programa y retiro  
 @12 2022.01.05     rsamame                 Se mejora la Busqueda para la matricula anterior  
 @13 2022.02.23  jmota     se agregan campos a solicitud del tk 25486 IDAT  
 @14 2022.08.31  jmota     se agrega campos para validacion de turno  
 @15 2022.09.09  jmota     se agrega campos por pago puntual  
 @16 2023.06.08  fetorres  se cambio "RETIRO DE CURSO" por "RETIRO DE CICLO"
 @17 2024.03.08  mquiroz   Se agrega validacion para ITS
*/       
CREATE PROCEDURE [dbo].[cDescuentoAcademico_Sel_DatosActorMatriculado]      
@IdMatricula INT,  
@CompaniaSocio CHAR(8) --@3  
AS  
BEGIN      
  
 SET NOCOUNT ON     
 -- @11  
 DECLARE @IdRegistro INT , @IdActor INT ,@IdMatriculaAnt INT,@PromedioReal REAL , @ConsultaPago INT--@15   
 --Obtenemos el Registro y el Idactor  
 SELECT @IdRegistro = IdRegistro,@IdActor=IdActor  
 FROM Matricula WITH(NOLOCK)WHERE IdMatricula = @IdMatricula   
      
 --Recuperamos la ultima matricula de la carrera donde tiene su descuento   
 -- Matricula anterior  
 SELECT TOP 1 @IdMatriculaAnt=M.IdMatricula, @ConsultaPago = CASE WHEN PR.IdModulo = 1 AND M.IdPeriodo IS NULL THEN 1 ELSE 2 END   --@15   
 FROM Matricula M WITH(NOLOCK)  
 INNER JOIN Promocion PR WITH(NOLOCK) ON M.IdPromocion=PR.IdPromocion  
 INNER JOIN Periodo PE WITH(NOLOCK) ON PE.IdPeriodo=PR.IdPeriodo  
 WHERE M.IdActor=@IdActor AND M.IdRegistro = @IdRegistro AND M.Estado = 'N' AND M.EsMatricula=1   
 AND M.Idmatricula <> @IdMatricula  
 ORDER BY ISNULL(M.MatriculaFecha,M.inscritofecha) DESC   
      
 --  nota >=18 siempre para sus ciclos secuenciales. promociongrupocierre --      
 SELECT @PromedioReal = PromedioReal FROM PromocionGrupoCierre WITH(NOLOCK) WHERE IdMatricula = @IdMatriculaAnt     
 --@11  
  
   IF  @CompaniaSocio = '00002500'  OR @CompaniaSocio = '00002400'--@3  @17
   BEGIN  
  
  SELECT    
  'IdMatricula' = m.idmatricula,   --@7  
  'IdActor' = m.IdActor,   --@8  
  'AlumnoCodigo' = ISNULL(Al.CodigoAnterior, ''), --@14  
  'Sede' = SE.Nombre ,      
  'Curricula' = '[' + C.Codigo + ']' + C.Nombre ,      
  'Promocion' = '[' + P.PromocionCodigo + ']' + P.PromocionNombre ,    
  'Servicio' =  ISNULL(p.ServicioCodigo,'')  + ' - [' + SE.Sucursal + '] ' + '[' +  [dbo].[cCo_Precio_ObtenerTipoListaPrecio]( M.IDMATRICULA,NULL,NULL, @CompaniaSocio)   + ']' , -- @13  
  'Periodo' = PE.Codigo +  ' [' + CONVERT(VARCHAR(10),PE.Inicio,103) + ' - ' +  CONVERT(VARCHAR(10),PE.Fin,103) + ']' ,      
  'Seccion' =  ISNULL(PG.GrupoCodigo ,''),      
  'Tipo_Ingreso' = CASE WHEN isnull(M.IdPeriodo, -1) = -1 THEN 'CAPTACION' ELSE 'SECUENCIAL' END,      
  'Estado_Matricula' = CASE M.Estado WHEN 'N' THEN 'NORMAL' WHEN 'R' THEN 'RETIRADO' ELSE '' END,  
  'Alumno_Retirado' = ISNULL(ISNULL(CASE WHEN MR.Tipo = 'RC' THEN 'RETIRO DE CICLO'  --@16
                                                             WHEN MR.TIPO = 'RA' THEN 'RETIRO DE ASIGNATURA'   
                   ELSE '' END,'')   
          + ' ' + ISNULL(convert(varchar, MR.DocumentoFecha, 120),'') + ' ' + ISNULL(MR.Observacion,''), ''),  --@8      
  'Condicion_Pago' = CASE  WHEN M.condicionpago = 'C' THEN 'CONTADO' ELSE 'CUOTAS' END ,      
  'Condicion_Matricula' = CASE M.TipoCondicion       
    WHEN 'RE' THEN 'PROMOVIDO'       
    WHEN 'RP' THEN 'PROMOVIDO + CURSO' --@2      
    WHEN 'RT' THEN 'REPITENTE'       
    WHEN 'CC' THEN 'CURSO REPITENCIA' END,  --@2    
  'Fecha_Matricula' = isnull(convert(varchar, M.MatriculaFecha, 120), ''),      
  'Fecha_Registro' = U.Login + ' (' + isnull(convert(varchar, M.FechaCreacion, 120), '') + ')', --  @6   @9    
  'Fecha_Inscrito' = isnull(convert(varchar, M.InscritoFecha, 120), ''), --  @6  
  'Fecha_Comision' = isnull(convert(varchar, M.FechaComision, 120), ''), --  @6      
  'EsMatriculado' = CASE m.EsMatricula WHEN 1 THEN 'SI' ELSE 'NO' END,      
  'Turno' = T.nombre ,      
  'Tipo_Turno' = TipoTurno.Nombre +  '[' + ISNULL(TipoTurno.Disponible5,'') +']',      
  'Semestre' = TipoModulo.Nombre,      
  'Cnt_Cursos' = (SELECT COUNT(1) FROM CurriculaCurso CC WITH(NOLOCK) WHERE CC.IdCurricula = P.IdCurricula AND CC.IdModulo = P.IdModulo),      
  'Cursos_PreMatriculados' = (SELECT  COUNT(1) FROM AlumnoCurso AC WITH(NOLOCK) WHERE AC.IdMatricula = M.IdMatricula AND AC.IdSeccion IS NOT NULL),      
  'Cursos_Matriculados' = (SELECT  COUNT(1) FROM AlumnoCurso AC WITH(NOLOCK) WHERE AC.IdMatricula = M.IdMatricula AND AC.EsMatricula = 1 ),      
  'Colegio_Red_Innova' = dbo.cActorAcademicaColegioProcedencia(M.IdActor,1),    
  'Colegio_Red_Inn_Admin_Cont' = dbo.cInteresadoColegioProcedencia(M.IdActor,1),   -- @5   
  'Egresado_Colegio' = ISNULL( (SELECT TOP 1 ISNULL(I.AnnoEgreso , '' ) FROM Interesado I WITH(NOLOCK) WHERE I.NombreCompleto = AC.NombreCompleto AND I.AnnoEgreso IS NOT NULL ),  
       ISNULL( (SELECT  TOP 1 ISNULL(AA.AnnoEgreso, '' ) FROM ActorAcademica AA WITH(NOLOCK) WHERE AA.IdActor =  M.IdActor  AND AnnoEgreso  IS NOT NULL ) , '')), --@4     
  'Intercorp' = CASE WHEN [dbo].[cActor_Val_ExisteClubIntercorp] (AC.NumeroIdentidad) = 0 THEN 'NO' ELSE 'SI' END ,      
  'Convenio' = CASE WHEN ISNULL(m.IdConvenio,-1) <> -1 THEN 'SI' ELSE 'NO' end  ,      
  'Reingresante' = CASE WHEN[dbo].[cAlumnoReingresante](M.IdActor,PE.IdPeriodo) = 0 THEN 'NO' ELSE 'SI' END ,      
  'Egresado' = CASE WHEN [dbo].[cEgresado_EsEgresado](M.IdActor) = 0 THEN 'NO' ELSE (SELECT ISNULL ( STUFF((        
        SELECT DISTINCT  ' [ Programa: ' + ISNULL(UA.Nombre,'')  +'] '       
        FROM Egresados E WITH(NOLOCK)       
        INNER JOIN UnidadAcademica UA WITH(NOLOCK)       
        ON E.IdUnidadAcademica = UA.IdUnidadAcademica       
        WHERE E.IdAlumno = M.IdActor       
        FOR XML PATH('')      
        ),1,1,'') , '' ))  END, -- @1      
  'Egresado_Gupta' =   CASE WHEN (SELECT   COUNT(1)   
          FROM Gupta.dbo.Egresados E    WITH(NOLOCK)  
          INNER JOIN Gupta.dbo.PERSONAS PE ON  E.CD_CLTE = PE.CD_PERS     
          WHERE PE.NR_DOCUIDEN = AC.NumeroIdentidad ) > 0       
          THEN 'SI' ELSE 'NO' END ,      
  'Titulado' = CASE WHEN [dbo].[cTitulado_EsTitulado](M.IdActor) = 0 THEN 'NO' ELSE 'SI' END,      
  'Beca_SocioEconomica' = [dbo].[cSolicitudBeca_NombreDescuento](AC.IdActor, PE.IdPeriodo),      
  'Descuento_Fijo' =  ISNULL (       
    STUFF((      
    SELECT  DISTINCT ' - ' + ISNULL(CONVERT(VARCHAR,DA.Codigo),'')  + '[' + ISNULL(DA.Nombre,'') + ']' + '[' + CONVERT(VARCHAR,ISNULL(MTRP.IdMaestroRegistro,0)) + ']' + '[' + ISNULL(MTRP.Nombre,'') + ']'  --@10 @14  
    FROM DescuentoAcademicoBase DAB WITH(NOLOCK)      
    INNER JOIN DescuentoAcademicoPoblacion DAP WITH(NOLOCK) ON DAB.IdMaestroRegistro = DAP.IdTipoSituacionAlumno      
    INNER JOIN DescuentoAcademico DA WITH(NOLOCK) ON DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico  
    INNER JOIN MaestroTablaRegistro MTRP WITH(NOLOCK) ON   DAB.IdMaestroRegistro = MTRP.IdMaestroRegistro    
    WHERE DAB.NumeroIdentidad = AC.NumeroIdentidad      
    FOR XML PATH('')),1,1,''), '' ) ,  
  'Institucion_Procedencia' = ISNULL( (SELECT ISNULL(MTR.Nombre, '') + ' [' + ISNULL(MTR.Disponible1 , '')+ '] ' + ' [' + ISNULL(MTR.Disponible2 , '')+ '] '  FROM ActorAcademica AA   
          INNER JOIN MaestroTablaRegistro MTR ON AA.IdInstitucion = MTR.IdMaestroRegistro  
          WHERE  AA.IdActor = M.IdActor )  , '') ,  
  'Nro_Doc_Identidad_Smart' = ISNULL(AC.NumeroIdentidad,''),  
  'Nro_Doc_Identidad_Spring' = ISNULL(PM.Documento,'') ,  
  'NombreCompleto_Spring' = ISNULL(PM.NombreCompleto,''),  
  'PagoPuntual_CicloAnterior'=(CASE WHEN 0=ISNULL([dbo].[cPagoPuntual](@IdActor,@CompaniaSocio,@IdMatriculaAnt,@ConsultaPago),'') THEN 'REALIZO TODOS SUS PAGOS PUNTUALES' ELSE 'POR LO MENOS UNA CUOTA FUE PAGADA FUERA DE FECHA' END), --@11  
  'PromedioCicloAtenrior'=ISNULL(@PromedioReal,0),--@11  
  'Solicitud_CambioCarrera' =     (SELECT ISNULL ( STUFF((       
                          SELECT DISTINCT  ' [ #Solicitud: ' + ISNULL(CPC.NumeroSolicitud,'')  +'] -  ' +  ISNULL(CPC.Observacion,'') --@11       
                          FROM CambioProductoCurricula CPC WITH(NOLOCK)          
                          WHERE  CPC.IdAlumno=M.IdActor and CPC.IdPeriodo=PE.IdPeriodo and CPC.IdCurriculaNueva=P.IdCurricula and CPC.Estado=1     
                          FOR XML PATH('')     
                          ),1,1,'') , '' )),  
   'Solicitud_CambioSede' =     (SELECT ISNULL ( STUFF((       
                          SELECT DISTINCT  ' [ #Solicitud: ' + ISNULL(TS.NumeroSolicitud,'')  +'] -  ' +  ISNULL(TS.Observacion ,'')     --@11       
                          FROM TrasladoSede TS WITH(NOLOCK)          
                          WHERE  TS.IdAlumno=M.IdActor and TS.IdPeriodoTraslado=PE.IdPeriodo and TS.IdCurriculaNueva=P.IdCurricula and TS.Estado=1     
                          FOR XML PATH('')     
                          ),1,1,'') , '' )),  
    'Solicitudes_RetiroCiclo' =     (SELECT ISNULL ( STUFF((       
                          SELECT DISTINCT  ' [ #Solicitud: ' + ISNULL(RC.DocumentoNumero,'')  +'] -  ' +  ISNULL(RC.Observacion ,'')  --@11          
                          FROM MatriculaRetiro RC WITH(NOLOCK)          
                          WHERE  RC.IdActor=M.IdActor and RC.IdProducto=P.IdProducto and   RC.Estado='R' and  RC.Tipo='RC'    
                          FOR XML PATH('')     
                          ),1,1,'') , '' ))   
  INTO #TEMP      
  FROM Matricula M WITH(NOLOCK)     
  INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion       
  INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo       
  INNER JOIN Sede SE WITH(NOLOCK) ON P.IdSede = SE.IdSede       
  INNER JOIN Actor AC WITH(NOLOCK) ON M.IdActor = AC.IdActor    
  INNER JOIN vw_PersonaMast PM WITH(NOLOCK) ON PM.personaant = convert(varchar,AC.IdActor)   
  LEFT JOIN PromocionGrupo PG WITH(NOLOCK) on P.IdPromocion = PG.IdPromocion AND M.IdGrupo = PG.IdGrupo      
  LEFT JOIN Turno T WITH(NOLOCK) ON PG.IdTurno = T.IdTurno      
  LEFT JOIN MaestroTablaRegistro TipoTurno WITH(NOLOCK) ON T.IdTipoTurno = TipoTurno.IdMaestroRegistro       
  LEFT JOIN Curricula C WITH(NOLOCK) ON P.IdCurricula = C.IdCurricula      
  LEFT JOIN CurriculaModulo CM WITH(NOLOCK) ON P.IdCurricula = CM.IdCurricula AND P.IdModulo = CM.IdModulo       
  LEFT JOIN MaestroTablaRegistro TipoModulo WITH(NOLOCK) ON  CM.IdTipoModulo = TipoModulo.IdMaestroRegistro      
  LEFT JOIN MatriculaRetiro MR WITH(NOLOCK) ON M.IdMatricula = MR.IdMatricula AND MR.Estado = 'R'  --@8   
  LEFT JOIN Usuario U WITH(NOLOCK) ON U.IdUsuario = M.UsuarioCreacion -- @9  
  LEFT JOIN Alumno AL WITH(NOLOCK) ON AC.IdActor = AL.Idalumno --@14  
  WHERE  M.IdMatricula = @IdMatricula      
      
      
  SELECT  Titulo , Descripcion       
  FROM (select       
  convert(varchar(500),IdMatricula) IdMatricula ,  --@7  
  convert(varchar(500),IdActor) IdActor ,  --@10  
  convert(varchar(500),AlumnoCodigo) AlumnoCodigo ,  --@14  
  convert(varchar(500),Sede) Sede ,      
  convert(varchar(500),Curricula) Curricula ,       
  convert(varchar(500),Promocion) Promocion ,     
  convert(varchar(500),Servicio) Servicio ,       
  convert(varchar(500),Periodo ) Periodo,      
  convert(varchar(500),Seccion ) Seccion ,      
  convert(varchar(500),Tipo_Ingreso ) Tipo_Ingreso,       
  convert(varchar(500),Estado_Matricula ) Estado_Matricula,    
  convert(varchar(500),Alumno_Retirado ) Alumno_Retirado,  --@8       
  convert(varchar(500),Condicion_Pago ) Condicion_Pago,      
  convert(varchar(500),Condicion_Matricula ) Condicion_Matricula,      
  convert(varchar(500),Fecha_Matricula ) Fecha_Matricula,  
  convert(varchar(500),Fecha_Registro ) Fecha_Registro, --@6  
  convert(varchar(500),Fecha_Inscrito ) Fecha_Inscrito, --@6  
  convert(varchar(500),Fecha_Comision ) Fecha_Comision, --@6  
  convert(varchar(500),EsMatriculado ) EsMatriculado,      
  convert(varchar(500),Turno ) Turno,      
  convert(varchar(500),Tipo_Turno ) Tipo_Turno,      
  convert(varchar(500),Semestre ) Semestre,      
  convert(varchar(500),Cnt_Cursos ) Cnt_Cursos,      
  convert(varchar(500),Cursos_PreMatriculados ) Cursos_PreMatriculados,      
  convert(varchar(500),Cursos_Matriculados ) Cursos_Matriculados,      
  convert(varchar(500),Colegio_Red_Innova ) Colegio_Red_Innova,   
  convert(varchar(500),Colegio_Red_Inn_Admin_Cont ) Colegio_Red_Inn_Admin_Cont,  -- @5   
  convert(varchar(500),Egresado_Colegio ) Egresado_Colegio,      
  convert(varchar(500),Intercorp ) Intercorp,      
  convert(varchar(500),Convenio ) Convenio,      
  convert(varchar(500),Reingresante ) Reingresante,      
  convert(varchar(500),Egresado ) Egresado,      
  convert(varchar(500),Egresado_Gupta ) Egresado_Gupta,      
  convert(varchar(500),Titulado ) Titulado,      
  convert(varchar(500),Beca_SocioEconomica ) Beca_SocioEconomica,      
  convert(varchar(500),Descuento_Fijo ) Descuento_Fijo ,   
  convert(varchar(500),Institucion_Procedencia ) Institucion_Procedencia  ,  
  convert(varchar(500),Nro_Doc_Identidad_Smart ) Nro_Doc_Identidad_Smart ,   
  convert(varchar(500),Nro_Doc_Identidad_Spring ) Nro_Doc_Identidad_Spring  ,  
  convert(varchar(500),NombreCompleto_Spring ) NombreCompleto_Spring,  
  convert(varchar(500),PagoPuntual_CicloAnterior ) PagoPuntual_CicloAnterior,--@11  
  convert(varchar(500),PromedioCicloAtenrior ) PromedioCicloAtenrior,--@11  
  convert(varchar(500),Solicitud_CambioCarrera ) Solicitud_CambioCarrera,--@11  
  convert(varchar(500),Solicitud_CambioSede ) Solicitud_CambioSede,--@11  
  convert(varchar(500),Solicitudes_RetiroCiclo ) Solicitudes_RetiroCiclo--@11  
  
      
  from #TEMP ) p      
  UNPIVOT ( Descripcion FOR Titulo IN (      
  [IdMatricula],--@7  
  [IdActor],  --@10  
  [AlumnoCodigo],  --@14  
  [Sede],      
  [Curricula],      
  [Promocion],  
  [Servicio],      
  [Periodo],      
  [Seccion],      
  [Tipo_Ingreso],      
  [Estado_Matricula],   
  [Alumno_Retirado], --@8     
  [Condicion_Pago],      
  [Condicion_Matricula],      
  [Fecha_Matricula],  
  [Fecha_Registro],  --@6  
  [Fecha_Inscrito], --@6   
  [Fecha_Comision],  --@6      
  [EsMatriculado],      
  [Turno],      
  [Tipo_Turno],      
  [Semestre],      
  [Cnt_Cursos],      
  [Cursos_PreMatriculados],      
  [Cursos_Matriculados],      
  [Colegio_Red_Innova],   
  [Colegio_Red_Inn_Admin_Cont],   -- @5    
  [Egresado_Colegio],      
  [Intercorp],      
  [Convenio],      
  [Reingresante],      
  [Egresado],      
  [Egresado_Gupta],      
  [Titulado],      
  [Beca_SocioEconomica],      
  [Descuento_Fijo],  
  [Institucion_Procedencia],  
  [Nro_Doc_Identidad_Smart],  
  [Nro_Doc_Identidad_Spring],  
  [NombreCompleto_Spring],  
  [PagoPuntual_CicloAnterior],--@11  
  [PromedioCicloAtenrior],--@11  
  [Solicitud_CambioCarrera],--@11  
  [Solicitud_CambioSede],--@11  
  [Solicitudes_RetiroCiclo]--@11  
  ) ) AS unpvt;      
      
   DROP TABLE #TEMP     
 --Inicio @3  
    END  
   
 ELSE   
 BEGIN  
  
  SELECT   
  'IdMatricula' = M.IdMatricula,   --@7  
  'IdActor' = m.IdActor,   --@8   
  'AlumnoCodigo' = ISNULL(Al.CodigoAnterior, ''), --@14  
  'Sede' = SE.Nombre ,      
  'Curricula' = '[' + C.Codigo + ']' + C.Nombre ,      
  'Promocion' = '[' + P.PromocionCodigo + ']' + P.PromocionNombre ,   
  'Servicio' =  ISNULL(p.ServicioCodigo,'')  + ' - [' + SE.Sucursal + '] ' + '[' +  [dbo].[cCo_Precio_ObtenerTipoListaPrecio]( M.IDMATRICULA,NULL,NULL, @CompaniaSocio)   + ']' , -- @13  
  'Periodo' = PE.Codigo +  ' [' + CONVERT(VARCHAR(10),PE.Inicio,103) + ' - ' +  CONVERT(VARCHAR(10),PE.Fin,103) + ']' ,         
  'Seccion' =  ISNULL(PG.GrupoCodigo ,''),      
  'Tipo_Ingreso' = CASE WHEN isnull(M.IdPeriodo, -1) = -1 THEN 'CAPTACION' ELSE 'SECUENCIAL' END,      
  'Estado_Matricula' = CASE M.Estado WHEN 'N' THEN 'NORMAL' WHEN 'R' THEN 'RETIRADO' ELSE '' END,    
  'Alumno_Retirado' = ISNULL(ISNULL(CASE WHEN MR.Tipo = 'RC' THEN 'RETIRO DE CICLO'  --@16
                                                             WHEN MR.TIPO = 'RA' THEN 'RETIRO DE ASIGNATURA'   
                   ELSE '' END,'')   
          + ' ' + ISNULL(convert(varchar, MR.DocumentoFecha, 120),'') + ' ' + ISNULL(MR.Observacion,''), ''),  --@8    
  'Condicion_Pago' = CASE  WHEN M.condicionpago = 'C' THEN 'CONTADO' ELSE 'CUOTAS' END ,      
  'Condicion_Matricula' = CASE M.TipoCondicion       
    WHEN 'RE' THEN 'PROMOVIDO'       
    WHEN 'RP' THEN 'PROMOVIDO + CURSO' --@2      
    WHEN 'RT' THEN 'REPITENTE'       
    WHEN 'CC' THEN 'CURSO REPITENCIA' END,  --@2    
     'Fecha_Matricula' = isnull(convert(varchar, M.MatriculaFecha, 120), ''),    
  'Fecha_Registro' = U.Login + ' (' + isnull(convert(varchar, M.FechaCreacion, 120), '') + ')',   --  @6  -- @9    
  'Fecha_Inscrito' = isnull(convert(varchar, M.InscritoFecha, 120), ''), --  @6  
  'Fecha_Comision' = isnull(convert(varchar, M.FechaComision, 120), ''), --  @6    
  'EsMatriculado' = CASE m.EsMatricula WHEN 1 THEN 'SI' ELSE 'NO' END,      
  'Turno' = T.nombre ,      
  'Tipo_Turno' = TipoTurno.Nombre +  '[' + ISNULL(TipoTurno.Disponible5,'') +']',      
  'Semestre' = TipoModulo.Nombre,      
  'Cnt_Cursos' = (SELECT COUNT(1) FROM CurriculaCurso CC WITH(NOLOCK) WHERE CC.IdCurricula = P.IdCurricula AND CC.IdModulo = P.IdModulo),      
  'Cursos_PreMatriculados' = (SELECT  COUNT(1) FROM AlumnoCurso AC WITH(NOLOCK) WHERE AC.IdMatricula = M.IdMatricula AND AC.IdSeccion IS NOT NULL),      
  'Cursos_Matriculados' = (SELECT  COUNT(1) FROM AlumnoCurso AC WITH(NOLOCK) WHERE AC.IdMatricula = M.IdMatricula AND AC.EsMatricula = 1 ),      
  'Colegio_Red_Innova' = dbo.cActorAcademicaColegioProcedencia(M.IdActor,1),   
  'Colegio_Red_Inn_Admin_Cont' = dbo.cInteresadoColegioProcedencia(M.IdActor,1),   -- @5      
  'Egresado_Colegio' = ISNULL( (SELECT TOP 1 ISNULL(I.AnnoEgreso , '' ) FROM Interesado I WITH(NOLOCK) WHERE I.NombreCompleto = AC.NombreCompleto AND I.AnnoEgreso IS NOT NULL ),''),      
  'Intercorp' = CASE WHEN [dbo].[cActor_Val_ExisteClubIntercorp] (AC.NumeroIdentidad) = 0 THEN 'NO' ELSE 'SI' END ,      
  'Convenio' = CASE WHEN ISNULL(m.IdConvenio,-1) <> -1 THEN 'SI' ELSE 'NO' end  ,      
  'Reingresante' = CASE WHEN[dbo].[cAlumnoReingresante](M.IdActor,PE.IdPeriodo) = 0 THEN 'NO' ELSE 'SI' END ,      
  'Egresado' = CASE WHEN [dbo].[cEgresado_EsEgresado](M.IdActor) = 0 THEN 'NO' ELSE (SELECT ISNULL ( STUFF((        
        SELECT DISTINCT  ' [ Programa: ' + ISNULL(UA.Nombre,'')  +'] '       
        FROM Egresados E WITH(NOLOCK)       
        INNER JOIN UnidadAcademica UA WITH(NOLOCK)       
        ON E.IdUnidadAcademica = UA.IdUnidadAcademica       
        WHERE E.IdAlumno = M.IdActor       
        FOR XML PATH('')      
        ),1,1,'') , '' ))  END, -- @1      
  'Titulado' = CASE WHEN [dbo].[cTitulado_EsTitulado](M.IdActor) = 0 THEN 'NO' ELSE 'SI' END,      
  'Beca_SocioEconomica' = [dbo].[cSolicitudBeca_NombreDescuento](AC.IdActor, PE.IdPeriodo),      
  'Descuento_Fijo' =  ISNULL (       
    STUFF((      
    SELECT  DISTINCT ' - ' + ISNULL(CONVERT(VARCHAR,DA.Codigo),'')  + '[' + ISNULL(DA.Nombre,'') + ']' + '[' + CONVERT(VARCHAR,ISNULL(MTRP.IdMaestroRegistro,0)) + ']' + '[' + ISNULL(MTRP.Nombre,'') + ']'  --@10 @14  
    FROM DescuentoAcademicoBase DAB WITH(NOLOCK)      
    INNER JOIN DescuentoAcademicoPoblacion DAP WITH(NOLOCK) ON DAB.IdMaestroRegistro = DAP.IdTipoSituacionAlumno      
    INNER JOIN DescuentoAcademico DA WITH(NOLOCK) ON DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico  
    INNER JOIN MaestroTablaRegistro MTRP WITH(NOLOCK) ON   DAB.IdMaestroRegistro = MTRP.IdMaestroRegistro    
    WHERE DAB.NumeroIdentidad = AC.NumeroIdentidad      
    FOR XML PATH('')),1,1,''), '' ) ,  
  'Institucion_Procedencia' = ISNULL( (SELECT ISNULL(MTR.Nombre, '') + ' [' + ISNULL(MTR.Disponible1 , '')+ '] ' + ' [' + ISNULL(MTR.Disponible2 , '')+ '] '  FROM ActorAcademica AA   
          INNER JOIN MaestroTablaRegistro MTR ON AA.IdInstitucion = MTR.IdMaestroRegistro  
          WHERE  AA.IdActor = M.IdActor )  , '') ,  
  'Nro_Doc_Identidad_Smart' = ISNULL(AC.NumeroIdentidad,''),  
  'Nro_Doc_Identidad_Spring' = ISNULL(PM.Documento,'') ,  
  'NombreCompleto_Spring' = ISNULL(PM.NombreCompleto,''),  
  'PagoPuntual_CicloAnterior'=(CASE WHEN 0=ISNULL([dbo].[cPagoPuntual](@IdActor,@CompaniaSocio,@IdMatriculaAnt,@ConsultaPago),'') THEN 'REALIZO TODOS SUS PAGOS PUNTUALES' ELSE 'POR LO MENOS UNA CUOTA FUE PAGADA FUERA DE FECHA' END),--@11  
  'PromedioCicloAtenrior'=ISNULL(@PromedioReal,0),--@11  
  'Solicitud_CambioCarrera' =     (SELECT ISNULL ( STUFF((       
                          SELECT DISTINCT  ' [ #Solicitud: ' + ISNULL(CPC.NumeroSolicitud,'')  +'] -  ' +  ISNULL(CPC.Observacion ,'')   --@11     
                          FROM CambioProductoCurricula CPC WITH(NOLOCK)          
                          WHERE  CPC.IdAlumno=M.IdActor and CPC.IdPeriodo=PE.IdPeriodo and CPC.IdCurriculaNueva=P.IdCurricula and CPC.Estado=1     
                          FOR XML PATH('')     
                          ),1,1,'') , '' )),  
   'Solicitud_CambioSede' =     (SELECT ISNULL ( STUFF((       
                          SELECT DISTINCT  ' [ #Solicitud: ' + ISNULL(TS.NumeroSolicitud,'')  +'] -  ' +   ISNULL(TS.Observacion ,'')  --@11       
                          FROM TrasladoSede TS WITH(NOLOCK)          
                          WHERE  TS.IdAlumno=M.IdActor and TS.IdPeriodoTraslado=PE.IdPeriodo and TS.IdCurriculaNueva=P.IdCurricula and TS.Estado=1     
                          FOR XML PATH('')     
                          ),1,1,'') , '' )),  
    'Solicitudes_RetiroCiclo' =     (SELECT ISNULL ( STUFF((       
                          SELECT DISTINCT  ' [ #Solicitud: ' + ISNULL(RC.DocumentoNumero,'')  +'] -  ' +  ISNULL(RC.Observacion,'')   --@11    
                          FROM MatriculaRetiro RC WITH(NOLOCK)          
                          WHERE  RC.IdActor=M.IdActor and RC.IdProducto=P.IdProducto  and   RC.Estado='R' and  RC.Tipo='RC'    
                          FOR XML PATH('')     
                          ),1,1,'') , '' ))   
 INTO #TEMP2      
  FROM Matricula M  WITH(NOLOCK)    
  INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion       
  INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo       
  INNER JOIN Sede SE  WITH(NOLOCK)  ON P.IdSede = SE.IdSede       
  INNER JOIN Actor AC  WITH(NOLOCK) ON M.IdActor = AC.IdActor  
  INNER JOIN vw_PersonaMast PM  WITH(NOLOCK) ON PM.personaant = convert(varchar,AC.IdActor)       
  LEFT JOIN PromocionGrupo PG  WITH(NOLOCK) on P.IdPromocion = PG.IdPromocion AND M.IdGrupo = PG.IdGrupo      
  LEFT JOIN Turno T  WITH(NOLOCK) ON PG.IdTurno = T.IdTurno      
  LEFT JOIN MaestroTablaRegistro TipoTurno  WITH(NOLOCK) ON T.IdTipoTurno = TipoTurno.IdMaestroRegistro       
  LEFT JOIN Curricula C  WITH(NOLOCK) ON P.IdCurricula = C.IdCurricula      
  LEFT JOIN CurriculaModulo CM  WITH(NOLOCK) ON P.IdCurricula = CM.IdCurricula AND P.IdModulo = CM.IdModulo       
  LEFT JOIN MaestroTablaRegistro TipoModulo  WITH(NOLOCK) ON  CM.IdTipoModulo = TipoModulo.IdMaestroRegistro    
  LEFT JOIN MatriculaRetiro MR  WITH(NOLOCK) ON M.IdMatricula = MR.IdMatricula AND MR.Estado = 'R'  --@8   
  LEFT JOIN Usuario U WITH(NOLOCK) ON U.IdUsuario = M.UsuarioCreacion -- @9    
  LEFT JOIN Alumno AL WITH(NOLOCK) ON AC.IdActor = AL.Idalumno --@14  
  WHERE  M.IdMatricula = @IdMatricula      
      
      
  SELECT  Titulo , Descripcion       
  FROM (select       
  convert(varchar(500),IdMatricula) IdMatricula ,  --@7  
  convert(varchar(500),IdActor) IdActor ,  --@10  
  convert(varchar(500),AlumnoCodigo) AlumnoCodigo ,  --@14  
  convert(varchar(500),Sede) Sede ,      
  convert(varchar(500),Curricula) Curricula ,       
  convert(varchar(500),Promocion) Promocion ,  
  convert(varchar(500),Servicio) Servicio ,           
  convert(varchar(500),Periodo ) Periodo,      
  convert(varchar(500),Seccion ) Seccion ,      
  convert(varchar(500),Tipo_Ingreso ) Tipo_Ingreso,       
  convert(varchar(500),Estado_Matricula ) Estado_Matricula,   
  convert(varchar(500),Alumno_Retirado ) Alumno_Retirado,  --@8      
  convert(varchar(500),Condicion_Pago ) Condicion_Pago,      
  convert(varchar(500),Condicion_Matricula ) Condicion_Matricula,      
  convert(varchar(500),Fecha_Matricula ) Fecha_Matricula,    
  convert(varchar(500),Fecha_Registro ) Fecha_Registro, --@6  
  convert(varchar(500),Fecha_Inscrito ) Fecha_Inscrito, --@6  
  convert(varchar(500),Fecha_Comision ) Fecha_Comision, --@6    
  convert(varchar(500),EsMatriculado ) EsMatriculado,      
  convert(varchar(500),Turno ) Turno,      
  convert(varchar(500),Tipo_Turno ) Tipo_Turno,      
  convert(varchar(500),Semestre ) Semestre,      
  convert(varchar(500),Cnt_Cursos ) Cnt_Cursos,      
  convert(varchar(500),Cursos_PreMatriculados ) Cursos_PreMatriculados,      
  convert(varchar(500),Cursos_Matriculados ) Cursos_Matriculados,      
  convert(varchar(500),Colegio_Red_Innova ) Colegio_Red_Innova,   
  convert(varchar(500),Colegio_Red_Inn_Admin_Cont ) Colegio_Red_Inn_Admin_Cont,  -- @5      
  convert(varchar(500),Egresado_Colegio ) Egresado_Colegio,      
  convert(varchar(500),Intercorp ) Intercorp,      
  convert(varchar(500),Convenio ) Convenio,      
  convert(varchar(500),Reingresante ) Reingresante,      
  convert(varchar(500),Egresado ) Egresado,      
  convert(varchar(500),Titulado ) Titulado,      
  convert(varchar(500),Beca_SocioEconomica ) Beca_SocioEconomica,      
  convert(varchar(500),Descuento_Fijo ) Descuento_Fijo ,   
  convert(varchar(500),Institucion_Procedencia ) Institucion_Procedencia  ,  
  convert(varchar(500),Nro_Doc_Identidad_Smart ) Nro_Doc_Identidad_Smart ,   
  convert(varchar(500),Nro_Doc_Identidad_Spring ) Nro_Doc_Identidad_Spring  ,  
  convert(varchar(500),NombreCompleto_Spring ) NombreCompleto_Spring,  
  convert(varchar(500),PagoPuntual_CicloAnterior ) PagoPuntual_CicloAnterior,--@11  
 convert(varchar(500),PromedioCicloAtenrior ) PromedioCicloAtenrior,--@11  
  convert(varchar(500),Solicitud_CambioCarrera ) Solicitud_CambioCarrera,--@11  
  convert(varchar(500),Solicitud_CambioSede ) Solicitud_CambioSede,--@11  
  convert(varchar(500),Solicitudes_RetiroCiclo ) Solicitudes_RetiroCiclo--@11  
  from #TEMP2 ) p      
  UNPIVOT ( Descripcion FOR Titulo IN (      
  [IdMatricula],  --@7  
  [IdActor],  --@10  
  [AlumnoCodigo],  --@14  
  [Sede],      
  [Curricula],      
  [Promocion],    
  [Servicio],      
  [Periodo],      
  [Seccion],      
  [Tipo_Ingreso],      
  [Estado_Matricula],    
  [Alumno_Retirado],  --@8    
  [Condicion_Pago],      
  [Condicion_Matricula],      
  [Fecha_Matricula],   
  [Fecha_Registro],  --@6  
  [Fecha_Inscrito], --@6   
  [Fecha_Comision],  --@6   
  [EsMatriculado],      
  [Turno],      
  [Tipo_Turno],      
  [Semestre],      
  [Cnt_Cursos],      
  [Cursos_PreMatriculados],      
  [Cursos_Matriculados],      
  [Colegio_Red_Innova],   
  [Colegio_Red_Inn_Admin_Cont],   -- @5     
  [Egresado_Colegio],      
  [Intercorp],      
  [Convenio],      
  [Reingresante],      
  [Egresado],      
  [Titulado],      
  [Beca_SocioEconomica],      
  [Descuento_Fijo],  
  [Institucion_Procedencia],  
  [Nro_Doc_Identidad_Smart],  
  [Nro_Doc_Identidad_Spring],  
  [NombreCompleto_Spring],  
  [PagoPuntual_CicloAnterior],--@11  
  [PromedioCicloAtenrior],--@11  
  [Solicitud_CambioCarrera],--@11  
  [Solicitud_CambioSede],--@11  
  [Solicitudes_RetiroCiclo]--@11  
  ) ) AS unpvt;      
  
     DROP TABLE #TEMP2    
 END   
 --Fin @3  
END       
  
  


Hora de finalizaci�n: 2025-12-01T12:18:02.6901276-05:00
