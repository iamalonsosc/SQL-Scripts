DECLARE @IdMaximo INT

SELECT @IdMaximo=MAX(IdMaestroRegistro)  FROM MaestroTablaRegistro 

INSERT INTO MaestroTablaRegistro 
SELECT @IdMaximo+1,2058,'12SEM',NULL,'12 Semanas',NULL,NULL,NULL,NULL,NULL,1,1,GETDATE(),1,GETDATE()
,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
FROM MaestroTablaRegistro WHERE IdMaestroRegistro=29331
--(1 row affected)

--SELECT*FROM MaestroTablaRegistro where IdMaestroTabla=2058