/*==============================================================
Disponible1 = PromedioBeca  SI 
Disponible2 = ValidaRetiroCiclo SI
Disponible3 = ValidaCambioModalidad NO A NINGUNO
Disponible4 = ValidaCambioSede NO A NINGUNO
Disponible5 = IdModuloBecaValidar 
Disponible6 = ValidaTipoCondicion NO A NINGUNO
Disponible7 = ValidaPagoPuntual SI
Disponible8 = ValidaSecuencialidad 
Disponible9 = ValidaCambioCarrera NO A NINGUNO
Disponible10 = Indicador de la beca ACTIVATE
==============================================================*/

UPDATE MaestroTablaRegistro
SET 
    EsPDT=1
    ,Disponible1 = 13   -- promedio m�nimo
    ,Disponible2 = 1    -- retiro
    ,Disponible3 = 1    -- cambio modalidad
    ,Disponible4 = 1    -- cambio sede
    ,Disponible5 = 1    -- evaluar desde cuota 2
    ,Disponible6 = 0    -- tipo condicion
    ,Disponible7 = 1    -- pago puntual
    ,Disponible8 = 0    -- secuencialidad
    ,Disponible9 = 0     --Cambio Carrera
    ,Disponible10= 'ACTIVATE'
    --select*from MaestroTablaRegistro
WHERE Codigo = 'TIP0000061'