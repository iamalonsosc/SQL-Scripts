UPDATE AlumnoCurso SET NumVezCurso=1
WHERE IdMatricula=648124 and IDCURSO in (10120
,10099
,10113
,9876)
--(4 row affected)