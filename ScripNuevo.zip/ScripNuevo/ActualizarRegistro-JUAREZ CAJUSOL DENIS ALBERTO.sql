--exec cAlumnoCurso_Upd_GeneracionCargaHabil @IdEmpresa=1,@IdSede=35,@IdFacultad=1,@IdUnidadNegocio=1,@IdUnidadAcademica=57,@IdPeriodoAnterior=4152,@IdPeriodoNuevo=4152,@IdProducto=13722,@IdAlumno=1795555,@Tipo=N'TE',@IdUsuario=446639,@SoloInvicto=N'0'


--SELECT*FROM Registro 
update Registro set Estado='N'
WHERE IdActor=1795555 AND IdSede=35 AND IdProducto=13722


--select*from MatriculaPagante where IdActor=1795555