---si no hay equivalencia enviar correo a Secretaria general para el registro
SELECT PE.IdEquivalencia,pe.IdPaquete,
'ProductoDestino'=PR.ProductoCodigo+'-'+PR.ProductoNombre,
CR.Codigo,
CU.IdCurso,
CU.CursoCodigo,
CU.CursoNombre,
CC.IdModulo,
PE.NombrePaquete,
'ProductoOrigen'=PR2.ProductoCodigo+'-'+PR2.ProductoNombre,CR2.Codigo,CU2.CursoCodigo,CU2.CursoNombre,CC2.IdModulo,
'Tipo' = CASE PE.IdTipo WHEN 1 THEN 'REGULAR'
WHEN 2 THEN 'EGRESADOS'
WHEN 3 THEN 'REINGRESOS'
END,
'FechaCreacion'=CONVERT(VARCHAR,CE.FechaCreacion,104)
,PE.UsuarioCreacion
--,CR2.idcurricula
,PE.Vigencia
FROM CursoEquivalencia CE
INNER JOIN Curso CU ON CE.IdCurso=CU.IdCurso
INNER JOIN Curricula CR ON CE.IdCurricula=CR.IdCurricula
INNER JOIN Producto PR ON CR.IdProducto=PR.IdProducto
INNER JOIN CurriculaCurso CC ON CE.IdCurricula=CC.IdCurricula AND CE.IdCurso=CC.IdCurso
INNER JOIN PaqCursoEquivalencia PE ON CE.IdEquivalencia=PE.IdEquivalencia
INNER JOIN PaqCursoEquivalenciaDet PED ON PE.IdPaquete=PED.IdPaquete
INNER JOIN Curso CU2 ON PED.IdCurso=CU2.IdCurso
INNER JOIN Curricula CR2 ON PED.IdCurricula=CR2.IdCurricula
INNER JOIN Producto PR2 ON CR2.IdProducto=PR2.IdProducto
INNER JOIN CurriculaCurso CC2 ON PED.IdCurricula=CC2.IdCurricula AND PED.IdCurso=CC2.IdCurso
WHERE
CR2.IdCurricula=5614		--- aqui va la malla de origen
AND CR.IdCurricula=6064		--- aqui va la malla de destino
--and pe.IdTipo = 2		--- tipo 1 para alumnos regulares / 3 reingresos
--AND CU.CursoCodigo IN ('0291') --- aqui se pone el codigo del curso de destino
--AND CU2.CursoCodigo IN ('0715') --- aqui se pone el origen
 --CU.IdCurso=10549
ORDER BY PR.IdProducto,
CR.IdCurricula,
CC2.IdModulo,
PR2.IdProducto,
CR2.IdCurricula

--Select * from Curricula where codigo = '0209.01'

--SELECT * FROM EquivalenciaCurriculas WHERE IdCurriculaDestino=5604 AND IdCurriculaOrigen=1 AND IdTipo=1 AND Activo=1
--SELECT * FROM CURRICULA WHERE Codigo ='0217.01'