--����������������������������������������������������������������������������      
--Creado por: Alonso Sanchez (10/05/2023)      
--Funcionalidad : Carga Datos para Env�o de Actas a Minedu
--Utilizado por :     a
--����������������������������������������������������������������������������    
/*    
N� FECHA  USUARIO  DESCRIPCION    
@1 15.05.2023 Alsanchez  Se a�adio el uso del nuevo campo EsUltimo
@2 15.05.2023 Alsanchez  Se a�adio el uso del producto en 0 
@3 15.05.2023 Alsanchez Se agrega el tipo de proceso
@4 24.05.2023 Alsanchez Se agrega la seccionnominacambio para traer la extension
@5 29.05.2023 Alsanchez Trae el UsuarioMinedu de la tabla parametro, en el valor2 que es la condiicon, se coloca Oficial o Prueba, dependiendo si seran actas oficiales, o de prueba
@6 31.05.2023 Alsanchez Se cambia el tipo de proceso de AE a tipo de proceso AR
@7 01.06.2023 Ehuillca Mejora para agilizar el proceso de envio
@8 21.06.2023 Alsanchez Saca la calificacion correcta
@9 28.06.2023 Alsanchez Union con Alumno Curso
@10 22.08.2023 lpariona Se a�adio las columnas PeriodoAcademico y Turno
@11 03.09.2023 lpariona Se mejora el proceso de generacion del JSON y se comenta codigo
@12 12.10.2023 Alsanchez Mejora de traer el usuario de la tabla parametro
@13	16.10.2023 EHuillca Se agrega validaci�n por sede - se excluyen alumnos de matr�cula por curso libre	
@14 18.10.2023 lpariona Se valido los usuarios minedu por compa�ia socio
@15 19.06.2024 Alsanchez Agregamos el turno tarde, en el campo TURNO
*/   
ALTER PROCEDURE [dbo].[cEnvio_Minedu_Actas]  
--declare
@IdSede INT,  
@IdEmpresa INT,                                   
@IdFacultad INT,                   
@IdUnidadAcademica INT,                   
@IdUnidadNegocio INT,                   
@IdPeriodo INT,                   
@IdProducto INT,
@TipoProceso CHAR(2)--@3
AS  
--select @IdSede=5,@IdEmpresa=1,@IdFacultad=1,@IdUnidadNegocio=1,@IdUnidadAcademica=1,@IdPeriodo=4304,@IdProducto=-1,@TipoProceso='AR'
--select @IdSede=6,@IdEmpresa=1,@IdFacultad=1,@IdUnidadNegocio=1,@IdUnidadAcademica=57,@IdPeriodo=4307,@IdProducto=13403,@TipoProceso='AR'
BEGIN  
	SET NOCOUNT ON    
	--Select*From ##TablaJson
	DECLARE  
	@usuario NVARCHAR(30),  
	@contra NVARCHAR(30),  
	@cmodular NVARCHAR(30),  
	@Min INT,   
	@Max INT,  
	@CantidadAlumnos INT,
	@SeccionNomina VARCHAR(100) , 
	@SeccionNominaCambio VARCHAR(100), 
	@SedeCambio VARCHAR(50),
	@NivelFormativo VARCHAR(50),
	@CModularCambio VARCHAR(20),
	@PeriodoAcademico VARCHAR(15),--@10
	@TurnoNombre VARCHAR(8),--@10
	@CompaniaSocio varchar(20)--@14

	select @CompaniaSocio=CompaniaSocio from Empresa WITH(NOLOCK) where Activo = 1--@14

	DECLARE @ParametroUnidadAcademica AS TABLE--@7
	(
		IdEmpresa INT
		,IdSede INT
		,IdFacultad INT
		,IdUnidadNegocio INT
		,IdUnidadAcademica INT
		,IdPeriodo INT
		,IdProducto INT
		,Nombre VARCHAR(100)
		,Titulo VARCHAR(100)
		,Descripcion VARCHAR(500)
		,Valor VARCHAR(1000)
		,Valor2 VARCHAR(1000)
		,Valor3 VARCHAR(1000)
		,Valor4 VARCHAR(1000)
		,Valor5 VARCHAR(1000)
		,Descripcion2 VARCHAR(500)
		,Valor6 VARCHAR(1000)
		,Valor7 VARCHAR(1000)
		,Valor8 VARCHAR(1000)
		,Valor9 VARCHAR(1000)
		,Valor10 VARCHAR(1000)
	)
	INSERT INTO @ParametroUnidadAcademica
	SELECT IdEmpresa,IdSede,IdFacultad,IdUnidadNegocio,IdUnidadAcademica,IdPeriodo,IdProducto,Nombre,Titulo,Descripcion,
			Valor,Valor2,Valor3,Valor4,Valor5,Descripcion2,Valor6,Valor7,Valor8,
			Valor9,Valor10
	FROM ParametroUnidadAcademica WITH(NOLOCK) WHERE Nombre = 'ParametroNomina1'
  
	DECLARE @JSON AS TABLE  
	(  
	Usuario VARCHAR(20),  
	Contra VARCHAR(100),  
	Seccion varchar(200),
	CantidadAlumnos INT,
	CodigoModular VARCHAR(20),
	NivelFormativo VARCHAR(50),
	cadenaJson VARCHAR(MAX),
	PeriodoAcademico VARCHAR(15),--@10
	Turno VARCHAR(8)--@10
	)  
  
  	--lpariona Inicio
	declare @tablaJson as table(
		tipoActa varchar(2),
		nombrePeriodoLectivo varchar(20),
		codigoModular varchar(20),
		nombreSedeInstitucion varchar(50),
		nivelFormacion varchar(1000),
		nombreCarrera varchar(200),
		nombrePlanEstudio varchar(150),
		semestreAcademico varchar(4),
		turno varchar(7),
		seccion varchar(100),
		cantidadAlumno int,
		persona varchar(max)
	)
	--lpariona Fin

	DECLARE @Table AS TABLE  
	(  
		Id INT IDENTITY,  
		SeccionNomina VARCHAR(100),
		CantidadAlumnos INt,
		SeccionNominaCambio VARCHAR(100),
		SedeCambio VARCHAR(50),
		CModularCambio VARCHAR(20),
		NivelFormativo VARCHAR(50)
		--,PeriodoAcademico VARCHAR(15),--@10
		--Turno VARCHAR(8)--@10
	)  
	INSERT INTO @Table   
	SELECT DISTINCT   
	AC.Seccion ,COUNT(DISTINCT AC.IdAlumno),AC.Seccion + '-'+ENE.CodigoSedeOrigen, S.Nombre, ENE.CodModularDestino,PUA.Valor4
	/*,CASE AC.IdModulo WHEN 1 THEN 'I Semestre'ELSE '' END+
		CASE AC.IdModulo WHEN 2 THEN 'II Semestre'ELSE '' END+
		CASE AC.IdModulo WHEN 3 THEN 'III Semestre'ELSE ''END+
		CASE AC.IdModulo WHEN 4 THEN 'IV Semestre'ELSE ''END+
		CASE AC.IdModulo WHEN 5 THEN 'V Semestre'ELSE ''END+
		CASE AC.IdModulo WHEN 6 THEN 'VI Semestre'ELSE ''END+
		CASE AC.IdModulo WHEN 7 THEN 'VII Semestre'ELSE ''END+
		CASE AC.IdModulo WHEN 8 THEN 'VIII Semestre'ELSE ''END,--@10
	CASE AC.TurnoNombre  WHEN 'MADRUGADOR' THEN 'MA�ANA'  
			WHEN 'DIURNO' THEN 'MA�ANA'  
			WHEN 'NOCTURNO' THEN 'NOCHE'  
			ELSE 'MA�ANA' END--@10*/--@11
	FROM ActaConsolidada AC WITH(NOLOCK)  
	INNER JOIN Matricula M WITH(NOLOCK) ON AC.IdMatricula = M.IdMatricula--@13
	INNER JOIN Periodo PE  WITH (NOLOCK) ON AC.IdPeriodo=PE.IdPeriodo  
	INNER JOIN PeriodoCabecera PEC WITH (NOLOCK) ON PE.IdPeriodoCabecera=PEC.IdPeriodoCabecera --@4
	LEFT JOIN EquivalenciaNominasEnvioJSON ENE WITH(NOLOCK) ON AC.IdSede = ENE.IdSedeOrigen AND AC.IdProducto = ENE.IdProducto AND PEC.Codigo = ENE.Periodo--@4
	INNER JOIN @ParametroUnidadAcademica PUA --@7
		ON  PUA.IdUnidadNegocio=PE.IdUnidadNegocio
		AND PUA.IdUnidadAcademica = PE.IdUnidadAcademica 
		AND PUA.IdSede=PE.IdSede
		AND PUA.IdProducto=AC.IdProducto
	LEFT JOIN Sede S WITH(NOLOCK) ON ENE.IdSedeDestino = S.IdSede
	WHERE    
	AC.IdFacultad = @IdFacultad  
	AND AC.IdEmpresa= @IdEmpresa   
	AND AC.IdUnidadNegocio = @IdUnidadNegocio  
	AND AC.IdUnidadAcademica = @IdUnidadAcademica  
	AND AC.IdPeriodo = @IdPeriodo  
	AND (AC.IdProducto = @IdProducto OR @IdProducto = -1)  
	AND M.NumeroMatricula IS NULL --@13
	GROUP BY AC.Seccion, ENE.CodigoSedeOrigen,S.Nombre,ENE.CodModularDestino,PUA.Valor4--,AC.IdModulo,AC.TurnoNombre--@10--@11

	DECLARE @ActaConsolidada AS TABLE--@7
	(
		IdActa INT
		,EsNuevo INT
		,ProductoCodigo varchar(100)
		,ProductoNombre varchar(100)
		,PeriodoCodigo varchar(100)
		,PeriodoNombre varchar(100)
		,Region varchar(100)
		,Departamento varchar(100)
		,Provincia varchar(100)
		,Distrito varchar(100)
		,Direccion varchar(100)
		,IdCurricula INT
		,Sexo CHAR(1)
		,CodigoAlumno varchar(100)
		,NombreAlumno varchar(150)
		,DNI varchar(100)
		,CursosAprobados INT
		,CursosDesaprobados INT
		,EstadoPromovido varchar(100)
		,EstadoMatricula varchar(100)
		,PromedioPonderado NUMERIC(5,2)
		,TurnoNombre varchar(100)
		,NumeroRD varchar(100)
		,TurnoCodigo varchar(100)
		,Nombre varchar(100)
		,PromedioCurso varchar(100)
		,Orden varchar(100)
		,IdTipo INT
		,CursoCredito REAL
		,IdCurso INT
		,GrupoCodigo varchar(100)
		,CursoTipo varchar(100)
		,ModuloNombre varchar(200)
		,NombreFacilitador varchar(150)
		,CodigoFacilitador varchar(100)
		,PromocionCodigo varchar(100)
		,FechaInicio varchar(100)
		,FechaFin varchar(100)
		,CursoNombreOficial varchar(200)
		,CursoCodigo varchar(100)
		,CondicionPago varchar(100)
		,UltimaMatricula varchar(100)
		,EstadoCurso varchar(100)
		,Seccion varchar(100)
		,SeccionCodigo varchar(100)
		,EFormativa varchar(100)
		,NFormativo varchar(100)
		,FechaFinPeriodo varchar(100)
		,IdRegistro INT
		,TipoCondicion varchar(100)
		,PromedioCondicion varchar(100)
		,PeriodoCodigoT varchar(100)
		,IdMatricula INT
		,IdAlumno INT
		,IdPromocion INT
		,IdEmpresa INT
		,IdFacultad INT
		,IdSede INT
		,IdModulo INT
		,IdProducto INT
		,IdPeriodo INT
		,IdUnidadNegocio INT
		,IdUnidadAcademica INT
		,IdGrupo INT
		,CModular varchar(100)
		,FechaReva  varchar(100)
		,FechaAutoriza varchar(100)
		,NombreIES varchar(200)
		,Direccion2 varchar(500)
		,TipoGestion varchar(200)
		,TipoSede varchar(500)
		,NombreDirectorGeneral varchar(1000)
		,NombreSecretarioAcademico varchar(1000)
		,DREGRE varchar(1000)
	)
	INSERT INTO @ActaConsolidada
	Select IdActa,EsNuevo,ProductoCodigo,ProductoNombre,PeriodoCodigo,PeriodoNombre,Region,Departamento,Provincia,Distrito,Direccion,AC.IdCurricula,Sexo,
	CodigoAlumno,NombreAlumno,DNI,CursosAprobados,CursosDesaprobados,EstadoPromovido,EstadoMatricula,PromedioPonderado,TurnoNombre,NumeroRD,TurnoCodigo,
	Nombre,PromedioCurso,Orden,IdTipo,CursoCredito,IdCurso,GrupoCodigo,CursoTipo,ModuloNombre,NombreFacilitador,CodigoFacilitador,PromocionCodigo,FechaInicio,
	FechaFin,CursoNombreOficial,CursoCodigo,AC.CondicionPago,UltimaMatricula,EstadoCurso,AC.Seccion,SeccionCodigo,EFormativa,NFormativo,FechaFinPeriodo,AC.IdRegistro,
	AC.TipoCondicion,PromedioCondicion,PeriodoCodigoT,AC.IdMatricula,IdAlumno,AC.IdPromocion,AC.IdEmpresa,IdFacultad,AC.IdSede,AC.IdModulo,IdProducto,AC.IdPeriodo,IdUnidadNegocio,
	IdUnidadAcademica,AC.IdGrupo,CModular,FechaReva,FechaAutoriza,NombreIES,Direccion2,TipoGestion,TipoSede,NombreDirectorGeneral,NombreSecretarioAcademico,
	DREGRE FROM ActaConsolidada AC WITH(NOLOCK)
	INNER JOIN Matricula M WITH(NOLOCK) ON AC.IdMatricula = M.IdMatricula--@13
	WHERE IdFacultad = @IdFacultad AND AC.IdEmpresa= @IdEmpresa AND IdUnidadNegocio = @IdUnidadNegocio  
	AND IdUnidadAcademica = @IdUnidadAcademica AND AC.IdPeriodo = @IdPeriodo AND (IdProducto=@IdProducto OR @IdProducto= -1)--@2 
	AND AC.IdSede = @IdSede AND AC.Seccion IN(SELECT T.SeccionNomina FROM @Table T)
	AND M.NumeroMatricula IS NULL --@13
	--CREATE TABLE ##TablaJson (
	--Usuario VARCHAR(20),  
	--Contra VARCHAR(100),  
	--Seccion varchar(100),
	--CantidadAlumnos INT,
	--CodigoModular VARCHAR(20),
	--NivelFormativo VARCHAR(50),
	--cadenaJson VARCHAR(MAX)  
	--)

	--SE GUARDA EL CODIGO MODULAR   
	SELECT DISTINCT @cmodular = ISNULL(Valor10 ,'')  
	FROM @ParametroUnidadAcademica --@7
	WHERE IdEmpresa= @IdEmpresa    
	AND IdUnidadNegocio = @IdUnidadNegocio  
	AND IdUnidadAcademica = @IdUnidadAcademica  
	AND IdSede = @IdSede   
	AND (IdProducto = @IdProducto OR @IdProducto = -1)     
  
	SELECT @Min = MIN(Id), @Max = MAX(Id) FROM @Table      
  
	--SET @usuario='usuario_prueba_2'   
	--SELECT @usuario= Valor FROM parametro WITH(NOLOCK) WHERE  Nombre='UsuarioMinedu' AND Valor2 = 'Prueba' --@5
  
	--SELECT @contra = Valor FROM parametro WITH(NOLOCK) WHERE Valor2 = @cmodular  
	--SELECT @contra = Valor,@usuario=Valor3 FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular--@11
	IF @CompaniaSocio = '00002500'--@14
	BEGIN
		SELECT @contra = Valor,@usuario=Valor3 FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular
	END
	ELSE IF @CompaniaSocio = '00002700'--@14
	BEGIN
		SELECT @usuario=ISNULL(Valor2,Valor) FROM parametro WITH(NOLOCK) WHERE  Nombre='UsuarioMinedu'--@12
		--CODIGO MODULAR
		SELECT @contra = Valor FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular
	END
  
	WHILE @Min <= @Max  
	BEGIN  
  
		SET @SeccionNomina = NULL  
		SET @CantidadAlumnos = NULL 
		SET @NivelFormativo=NULL
		SET @SeccionNominaCambio = NULL
		SET @SedeCambio = NULL
		SET @CModularCambio=NULL
		SET @PeriodoAcademico=NULL
		SET @TurnoNombre=NULL

		SELECT	@SeccionNomina = SeccionNomina  ,
				@CantidadAlumnos = CantidadAlumnos,
				@SeccionNominaCambio = SeccionNominaCambio,
				@SedeCambio = SedeCambio,
				@CModularCambio = CModularCambio,
				@NivelFormativo = NivelFormativo
				--,@PeriodoAcademico = PeriodoAcademico,--@10--@11
				--@TurnoNombre = Turno--@10--@11
		FROM @Table  
		WHERE Id = @Min  
	
		IF @SeccionNominaCambio = '' SET @SeccionNominaCambio = NULL		
		IF @SedeCambio = '' SET @SedeCambio= NULL
		IF @CModularCambio = '' SET @CModularCambio = NULL
		--@11 Inicio
		insert into @tablaJson
		SELECT DISTINCT top 1 'tipo_acta'='AR',  --@6
		'nombre_periodo_lectivo'= AC.PeriodoCodigo,
		'codigo_modular' =  ISNULL(@CModularCambio,ISNULL(PUA.Valor10,'')),
		'nombre_sede_institucion'= ISNULL(@SedeCambio,ISNULL(S.Nombre,'')), 
		'nivel_formacion'= ISNULL (PUA.Valor4,''),
		'nombre_carrera' =  ISNULL(AC.ProductoNombre,''),  
		'nombre_plan_estudio' = ISNULL (C.NombrePlanEstudio ,''),
		'semestre_academico'=CASE AC.IdModulo WHEN 1 THEN 'I'ELSE '' END+  
			CASE AC.IdModulo WHEN 2 THEN 'II'ELSE '' END+  
			CASE AC.IdModulo WHEN 3 THEN 'III'ELSE ''END+  
			CASE AC.IdModulo WHEN 4 THEN 'IV'ELSE ''END+  
			CASE AC.IdModulo WHEN 5 THEN 'V'ELSE ''END+  
			CASE AC.IdModulo WHEN 6 THEN 'VI'ELSE ''END+  
			CASE AC.IdModulo WHEN 7 THEN 'VII'ELSE ''END+  
			CASE AC.IdModulo WHEN 8 THEN 'VIII'ELSE ''END,  
		'turno'=CASE AC.TurnoNombre -- @13
		WHEN 'DIURNA' THEN 'MA�ANA'
		WHEN 'DIURNO' THEN 'MA�ANA'
		WHEN 'NOCTURNO' THEN 'NOCHE'
		ELSE ISNULL (AC.TurnoNombre,'') END,  

		--CASE AC.TurnoNombre  WHEN 'MADRUGADOR' THEN 'MA�ANA'  
		--	WHEN 'DIURNO' THEN 'MA�ANA'  
		--	WHEN 'NOCTURNO' THEN 'NOCHE'  
		--	ELSE 'MA�ANA' END
		'seccion' = ISNULL(@SeccionNominaCambio,ISNULL(AC.Seccion,'')),
		'cantidad_alumno'= @CantidadAlumnos,
		'persona' = JSON_QUERY((
					SELECT DISTINCT  
					'tipo_documento'= CASE A.IdDocumentoTipo   
					WHEN 25 THEN 'D.N.I.'  
					WHEN 27 THEN 'CARNET DE EXTRANJER�A'  
					WHEN 30765 THEN 'PASAPORTE'  
					ELSE 'PTP' END,  
					'numero_documento'= ISNULL(A.NumeroIdentidad,''),  
					'nombre_completo'= ISNULL(A.NombreCompleto,''),  
					'sexo'=CASE A.Genero WHEN 1 THEN 'MASCULINO'ELSE 'FEMENINO' END,  
					DATEDIFF(YEAR, a.FechaNacimiento, GETDATE()) AS edad,  
					'tiene_discapacidad'=CONVERT(bit,0),
					'unidad_didactica' = JSON_QUERY((  
										SELECT 
										C.CursoNombre AS 'nombre_unidad_didactica',
										CASE 
										WHEN ISNULL(ACC.PromedioFinal,'DPI') = 'DPI' THEN 0--@8
										ELSE
										CAST(CAST((ACC.PromedioFinal)AS decimal(10,2)) as integer)
										END AS 'nota'
										--ROUND(
										--CASE 
										--WHEN REPLACE(ISNULL(AC3.PromedioCurso, '---'), '''', '') = 'DPI' THEN 0.00
										--WHEN TRY_CONVERT(DECIMAL(10,2), REPLACE(ISNULL(AC3.PromedioCurso, '---'), '''', '')) IS NULL THEN 0.00
										--ELSE TRY_CONVERT(DECIMAL(10,2), REPLACE(ISNULL(AC3.PromedioCurso, '---'), '''', ''))
										--END, 
										--2
										--) AS 'nota'
										FROM @ActaConsolidada AC3 --@7
										--INNER JOIN AlumnoCurso ACC WITH(NOLOCK) ON  AC3.IdMatricula = ACC.IdMatricula AND AC3.IdCurso=ACC.IdCurso
										--INNER JOIN Curso C WITH(NOLOCK) ON AC3.IdCurso = C.IdCurso  
										--INNER JOIN Actor A2 WITH(NOLOCK)ON AC3.IdAlumno = A2.IdActor  
										INNER JOIN AlumnoCurso ACC WITH(NOLOCK) ON  AC3.IdMatricula = ACC.IdMatricula AND AC3.IdCurso= ISNULL(ACC.IdCursoOriginal,ACC.IdCurso)--@9
										INNER JOIN Curso C WITH(NOLOCK) ON ACC.IdCurso = C.IdCurso  --@9
										INNER JOIN Actor A2 WITH(NOLOCK)ON ACC.IdAlumno = A2.IdActor  --@9
										WHERE AC3.Seccion = AC.Seccion   
										AND A2.NumeroIdentidad =A.NumeroIdentidad  
										FOR JSON PATH))  
					FROM @ActaConsolidada AC2 --@7
					INNER JOIN Actor A WITH(NOLOCK) ON AC2.IdAlumno=A.IdActor    
					WHERE   
					AC2.IdFacultad = @IdFacultad  
					AND AC2.IdEmpresa= @IdEmpresa          
					AND AC2.IdUnidadNegocio = @IdUnidadNegocio  
					AND AC2.IdUnidadAcademica = @IdUnidadAcademica  
					AND AC2.IdSede = @IdSede  
					AND AC2.IdPeriodo = @IdPeriodo  
					--AND AC2.IdProducto = @IdProducto   
					AND (AC2.IdProducto=@IdProducto OR @IdProducto= -1)--@2 
					AND AC2.Seccion = AC.Seccion  
					GROUP BY A.NumeroIdentidad,A.NombreCompleto,A.Genero,a.FechaNacimiento,A.IdDocumentoTipo FOR JSON PATH))  
		FROM @ActaConsolidada AC--@7
		INNER JOIN Sede S WITH(NOLOCK) ON AC.IdSede = S.IdSede  
		INNER JOIN Curricula C WITH(NOLOCK) ON AC.IdCurricula = C.IdCurricula 
		INNER JOIN @ParametroUnidadAcademica PUA --@7
		ON  PUA.IdUnidadNegocio=AC.IdUnidadNegocio
		AND PUA.IdUnidadAcademica = AC.IdUnidadAcademica 
		AND PUA.IdSede=AC.IdSede
		AND PUA.IdProducto=AC.IdProducto
		WHERE    
		AC.IdFacultad = @IdFacultad  
		AND AC.IdEmpresa= @IdEmpresa    
		AND AC.IdUnidadNegocio = @IdUnidadNegocio  
		AND AC.IdUnidadAcademica = @IdUnidadAcademica   
		AND AC.IdPeriodo = @IdPeriodo  
		--AND AC.IdProducto = @IdProducto  
		AND (AC.IdProducto=@IdProducto OR @IdProducto= -1)--@2 
		AND AC.IdSede = @IdSede  
		AND AC.Seccion = @SeccionNomina  
		GROUP BY AC.PeriodoCodigo,AC.CModular,PUA.Valor10,S.Nombre,PUA.Valor4,AC.NFormativo,AC.ProductoNombre,C.Nombre, AC.IdModulo,AC.TurnoNombre, AC.Seccion  ,C.NombrePlanEstudio
		
		select @TurnoNombre= turno,@PeriodoAcademico = semestreAcademico + ' Semestre' from @tablaJson
		--@11 fin

		INSERT INTO @JSON  
		SELECT  'Usuario'=@usuario,'Contra'=isnull(@contra,''),'Seccion'=ISNULL(@SeccionNominaCambio,@SeccionNomina),'CantidadAlumnos'=@CantidadAlumnos,ISNULL(@CModularCambio,@cmodular)AS CodigoModular,@NivelFormativo AS NivelFormativo,--@4
		(SELECT DISTINCT  'tipo_acta'=tipoActa,  --@6
		'nombre_periodo_lectivo'= nombrePeriodoLectivo,
		'codigo_modular' =  codigoModular,
		'nombre_sede_institucion'= nombreSedeInstitucion, 
		'nivel_formacion'=nivelFormacion,
		'nombre_carrera' =  nombreCarrera,  
		'nombre_plan_estudio' = nombrePlanEstudio,
		'semestre_academico'=semestreAcademico,  
		'turno'=turno,  
		'seccion' = seccion,
		'cantidad_alumno'=cantidadAlumno,
		'persona' = JSON_QUERY(persona) from @tablaJson FOR JSON PATH) AS cadenaJson,
		@PeriodoAcademico,--@10--@11
		@TurnoNombre--@10--@11
		delete from @tablaJson
		SET @Min = @Min + 1  
	END  

   SET NOCOUNT OFF 
END  
UPDATE AlumnoCursoNominaLogMinedu SET EsUltimo=0 WHERE SeccionMinedu in (Select Seccion from @JSON)AND TipoProceso= @TipoProceso AND IdSede = @IdSede --@1 --@13
INSERT INTO AlumnoCursoNominaLogMinedu (TipoProceso,SeccionMinedu,CantidadAlumnos,FechaCreacion,CadenaJson,Estado,EsUltimo,PeriodoAcademico,Turno,IdSede)--@1 --@10--@13
SELECT @TipoProceso,Seccion,CantidadAlumnos,GETDATE(),cadenaJson,'PE',1,PeriodoAcademico,Turno,@IdSede FROM @JSON--@1 --@10--@13

--INSERT INTO ##TablaJson
SELECT * FROM @JSON
