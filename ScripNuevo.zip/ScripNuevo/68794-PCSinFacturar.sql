--SELECT EsMatricula ,* FROM CO_Interfase_P09_Header WHERE IdMatricula IN (644657
--,646608) AND CompaniaSocio = '00002700' AND EsMatricula <> 1 
--esmatricula 3

UPDATE CO_Interfase_P09_Header SET EsMatricula = 1 WHERE IdMatricula IN (644657,646608) AND CompaniaSocio = '00002700' AND EsMatricula <> 1
--(4 rows affected)