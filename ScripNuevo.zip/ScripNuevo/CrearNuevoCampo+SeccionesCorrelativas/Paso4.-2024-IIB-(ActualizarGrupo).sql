UPDATE Matricula SET IdGrupo=1
where IdMatricula=613751

--select*from Matricula
UPDATE Matricula SET IdGrupo=1
where IdMatricula=613848