ALTER TABLE dbo.AlumnoCursoNomina
ADD Observacion VARCHAR(255) NULL;

ALTER TABLE dbo.AlumnoCursoNominaJson
ADD Observacion VARCHAR(255) NULL;

ALTER TABLE dbo.ActaConsolidada
ADD Observacion VARCHAR(255) NULL;

ALTER TABLE dbo.AlumnoCursoActaJson
ADD Observacion VARCHAR(255) NULL;