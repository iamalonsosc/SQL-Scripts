﻿--BEGIN TRAN;
---- 3.05 min
------------------------------------------------------------
-- 1) Datos desde el Excel
------------------------------------------------------------
DECLARE @seccionescorrelativas TABLE
(
    id                  INT IDENTITY(1,1) PRIMARY KEY,
    Carrera             VARCHAR(255),
    Sede                VARCHAR(255),      -- Código o Nombre de sede (desde Excel)
    SeccionOriginal     VARCHAR(100),
    SeccionNueva        VARCHAR(100),
    Turno               VARCHAR(50)  NULL, -- Excel: MAÑANA/NOCHE/TARDE o DIURNO/NOCTURNO
    SeccionNominaMinedu VARCHAR(100) NULL, -- Excel
    Observacion         VARCHAR(255)
);

-- ==== EJEMPLOS: reemplaza/añade tus filas del Excel ====
INSERT INTO @seccionescorrelativas (Carrera, Sede, SeccionOriginal, SeccionNueva, Turno, SeccionNominaMinedu, Observacion)
VALUES
--=DERECHA(K2;1)
--="('"&D2&"','"&A2&"','"&J2&"','"&K2&"','"&I2&"','"&L2&"',NULL),"
--('ADMINISTRACIÓN DE EMPRESAS','ATE - PURUCHUCO','0500.01.V.01.2025-I-V-A','0500.01.V.01.2025-I-V-I','MAÑANA','I',null)
-- Agrega aquí todas las demás filas de tu Excel...
-- =======================================================
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS (2)','0208.01.I.01.2024-II-I-A','0208.01.I.01.2024-II-I-B','MAÑANA','B',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.I.01.2024-II-I-B','0208.01.I.01.2024-II-I-C','NOCHE','C',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.IV.04.2024-II-IV-D','0208.01.IV.04.2024-II-IV-B','MAÑANA','B',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.IV.04.2024-II-IV-E','0208.01.IV.04.2024-II-IV-F','NOCHE','F',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.IV.03.2024-II-IV-B','0208.01.IV.03.2024-II-IV-E','NOCHE','E',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS (2)','0208.01.IV.01.2024-II-IV-C','0208.01.IV.01.2024-II-IV-I','NOCHE','I',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS (2)','0208.01.IV.01.2024-II-IV-A','0208.01.IV.01.2024-II-IV-G','NOCHE','G',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS (2)','0208.01.IV.01.2024-II-IV-B','0208.01.IV.01.2024-II-IV-H','NOCHE','H',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.IV.04.2024-II-IV-F','0208.01.IV.04.2024-II-IV-D','TARDE','D',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.V.03.2024-II-V-D','0208.01.V.03.2024-II-V-B','MAÑANA','B',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.V.02.2024-II-V-B','0208.01.V.02.2024-II-V-E','NOCHE','E',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.V.03.2024-II-V-E','0208.01.V.03.2024-II-V-D','TARDE','D',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.VI.04.2024-II-VI-E','0208.01.VI.04.2024-II-VI-C','MAÑANA','C',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.VI.03.2024-II-VI-C','0208.01.VI.03.2024-II-VI-G','NOCHE','G',NULL),
('ADMINISTRACIÓN DE EMPRESAS','PETIT THOUARS','0208.01.VI.04.2024-II-VI-G','0208.01.VI.04.2024-II-VI-E','TARDE','E',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.77.II.01.2024-II-II-B','0212.77.II.01.2024-II-II-E','NOCHE','E',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.77.II.01.2024-II-II-A','0212.77.II.01.2024-II-II-D','NOCHE','D',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.77.II.01.2024-II-II-C','0212.77.II.01.2024-II-II-F','NOCHE','F',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.01.III.01.2024-II-III-A','0212.01.III.01.2024-II-III-B','MAÑANA','B',NULL),
('CONTABILIDAD','PETIT THOUARS','0212.01.III.01.2024-II-III-B','0212.01.III.01.2024-II-III-C','NOCHE','C',NULL),
('CONTABILIDAD','PETIT THOUARS','0212.77.III.01.2024-II-III-A','0212.77.III.01.2024-II-III-B','NOCHE','B',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.77.III.02.2024-II-III-D','0212.77.III.02.2024-II-III-E','NOCHE','E',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.77.III.02.2024-II-III-B','0212.77.III.02.2024-II-III-C','NOCHE','C',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.77.III.02.2024-II-III-C','0212.77.III.02.2024-II-III-D','NOCHE','D',NULL),
('CONTABILIDAD','PETIT THOUARS','0212.01.IV.02.2024-II-IV-C','0212.01.IV.02.2024-II-IV-B','MAÑANA','B',NULL),
('CONTABILIDAD','PETIT THOUARS','0212.01.IV.02.2024-II-IV-B','0212.01.IV.02.2024-II-IV-C','NOCHE','C',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.01.IV.01.2024-II-IV-B','0212.01.IV.01.2024-II-IV-F','NOCHE','F',NULL),
('CONTABILIDAD','PETIT THOUARS (2)','0212.01.IV.01.2024-II-IV-A','0212.01.IV.01.2024-II-IV-E','NOCHE','E',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.I.04.2024-II-I-H','0215.81.I.04.2024-II-I-D','MAÑANA','D',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.I.04.2024-II-I-F','0215.81.I.04.2024-II-I-J','NOCHE','J',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.I.04.2024-II-I-I','0215.81.I.04.2024-II-I-L','NOCHE','L',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.I.04.2024-II-I-G','0215.81.I.04.2024-II-I-K','NOCHE','K',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.I.03.2024-II-I-D','0215.81.I.03.2024-II-I-H','NOCHE','H',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.I.04.2024-II-I-E','0215.81.I.04.2024-II-I-I','NOCHE','I',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS','0215.01.II.01.2024-II-II-A','0215.01.II.01.2024-II-II-G','NOCHE','G',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS','0215.81.II.02.2024-II-II-C','0215.81.II.02.2024-II-II-B','MAÑANA','B',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.II.01.2024-II-II-A','0215.81.II.01.2024-II-II-C','MAÑANA','C',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS','0215.81.II.02.2024-II-II-B','0215.81.II.02.2024-II-II-E','NOCHE','E',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS','0215.81.II.02.2024-II-II-D','0215.81.II.02.2024-II-II-F','NOCHE','F',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.II.03.2024-II-II-B','0215.81.II.03.2024-II-II-H','NOCHE','H',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.II.03.2024-II-II-E','0215.81.II.03.2024-II-II-J','NOCHE','J',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.II.03.2024-II-II-C','0215.81.II.03.2024-II-II-I','NOCHE','I',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.III.01.2024-II-III-A','0215.81.III.01.2024-II-III-C','MAÑANA','C',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.III.03.2024-II-III-E','0215.81.III.03.2024-II-III-D','MAÑANA','D',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS','0215.81.III.01.2024-II-III-C','0215.81.III.01.2024-II-III-F','NOCHE','F',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.III.03.2024-II-III-F','0215.81.III.03.2024-II-III-I','NOCHE','I',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.III.02.2024-II-III-B','0215.81.III.02.2024-II-III-G','NOCHE','G',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.III.02.2024-II-III-C','0215.81.III.02.2024-II-III-H','NOCHE','H',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.81.III.03.2024-II-III-D','0215.81.III.03.2024-II-III-E','TARDE','E',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS','0215.01.IV.04.2024-II-IV-C','0215.01.IV.04.2024-II-IV-B','MAÑANA','B',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS','0215.01.IV.04.2024-II-IV-D','0215.01.IV.04.2024-II-IV-C','MAÑANA','C',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS','0215.01.IV.02.2024-II-IV-B','0215.01.IV.02.2024-II-IV-D','NOCHE','D',NULL),
('DESARROLLO DE SISTEMAS DE INFORMACIÓN','PETIT THOUARS (2)','0215.01.IV.01.2024-II-IV-A','0215.01.IV.01.2024-II-IV-F','NOCHE','F',NULL),
('DISEÑO DE INTERIORES','PETIT THOUARS (2)','0213.78.II.01.2024-II-II-B','0213.78.II.01.2024-II-II-C','NOCHE','C',NULL),
('DISEÑO DE INTERIORES','PETIT THOUARS (2)','0213.78.II.01.2024-II-II-C','0213.78.II.01.2024-II-II-D','NOCHE','D',NULL),
('DISEÑO DE INTERIORES','PETIT THOUARS (2)','0213.78.II.01.2024-II-II-A','0213.78.II.01.2024-II-II-B','NOCHE','B',NULL),
('DISEÑO DE INTERIORES','PETIT THOUARS (2)','0213.78.III.01.2024-II-III-A','0213.78.III.01.2024-II-III-D','NOCHE','D',NULL),
('DISEÑO DE INTERIORES','PETIT THOUARS (2)','0213.78.III.01.2024-II-III-B','0213.78.III.01.2024-II-III-E','NOCHE','E',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.83.I.04.2024-II-I-C','0217.83.I.04.2024-II-I-A','MAÑANA','A',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.83.I.04.2024-II-I-D','0217.83.I.04.2024-II-I-B','MAÑANA','B',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.I.04.2024-II-I-G','0217.83.I.04.2024-II-I-F','MAÑANA','F',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.I.01.2024-II-I-A','0217.83.I.01.2024-II-I-C','MAÑANA','C',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.I.02.2024-II-I-B','0217.83.I.02.2024-II-I-D','MAÑANA','D',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.I.02.2024-II-I-C','0217.83.I.02.2024-II-I-E','MAÑANA','E',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.83.I.04.2024-II-I-E','0217.83.I.04.2024-II-I-I','NOCHE','I',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.83.I.01.2024-II-I-A','0217.83.I.01.2024-II-I-G','NOCHE','G',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.83.I.02.2024-II-I-B','0217.83.I.02.2024-II-I-H','NOCHE','H',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.I.03.2024-II-I-D','0217.83.I.03.2024-II-I-J','NOCHE','J',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.I.04.2024-II-I-H','0217.83.I.04.2024-II-I-M','NOCHE','M',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.I.04.2024-II-I-E','0217.83.I.04.2024-II-I-K','NOCHE','K',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.I.04.2024-II-I-F','0217.83.I.04.2024-II-I-L','NOCHE','L',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.II.01.2024-II-II-A','0217.83.II.01.2024-II-II-D','MAÑANA','D',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.II.02.2024-II-II-C','0217.83.II.02.2024-II-II-E','MAÑANA','E',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.II.02.2024-II-II-D','0217.83.II.02.2024-II-II-G','NOCHE','G',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.II.02.2024-II-II-B','0217.83.II.02.2024-II-II-F','NOCHE','F',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.83.III.02.2024-II-III-C','0217.83.III.02.2024-II-III-B','MAÑANA','B',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.83.III.02.2024-II-III-B','0217.83.III.02.2024-II-III-C','NOCHE','C',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.III.01.2024-II-III-B','0217.83.III.01.2024-II-III-F','NOCHE','F',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.III.01.2024-II-III-A','0217.83.III.01.2024-II-III-E','NOCHE','E',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.83.III.01.2024-II-III-C','0217.83.III.01.2024-II-III-G','NOCHE','G',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.IV.04.2024-II-IV-D','0217.01.IV.04.2024-II-IV-C','MAÑANA','C',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.01.IV.01.2024-II-IV-A','0217.01.IV.01.2024-II-IV-D','MAÑANA','D',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.IV.04.2024-II-IV-C','0217.01.IV.04.2024-II-IV-E','NOCHE','E',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.IV.04.2024-II-IV-E','0217.01.IV.04.2024-II-IV-F','NOCHE','F',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.01.IV.02.2024-II-IV-C','0217.01.IV.02.2024-II-IV-H','NOCHE','H',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS (2)','0217.01.IV.02.2024-II-IV-B','0217.01.IV.02.2024-II-IV-G','NOCHE','G',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.V.04.2024-II-V-E','0217.01.V.04.2024-II-V-C','MAÑANA','C',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.V.04.2024-II-V-D','0217.01.V.04.2024-II-V-G','NOCHE','G',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.V.03.2024-II-V-C','0217.01.V.03.2024-II-V-D','TARDE','D',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.V.04.2024-II-V-G','0217.01.V.04.2024-II-V-E','TARDE','E',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.VI.03.2024-II-VI-D','0217.01.VI.03.2024-II-VI-C','MAÑANA','C',NULL),
('DISEÑO GRÁFICO','PETIT THOUARS','0217.01.VI.03.2024-II-VI-C','0217.01.VI.03.2024-II-VI-D','NOCHE','D',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.I.03.2024-II-I-C','0380.01.I.03.2024-II-I-A','MAÑANA','A',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.I.03.2024-II-I-D','0380.01.I.03.2024-II-I-B','MAÑANA','B',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.02.2024-II-I-A','0380.01.I.02.2024-II-I-C','MAÑANA','C',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.02.2024-II-I-B','0380.01.I.02.2024-II-I-D','MAÑANA','D',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.04.2024-II-I-H','0380.01.I.04.2024-II-I-E','MAÑANA','E',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.I.01.2024-II-I-A','0380.01.I.01.2024-II-I-F','NOCHE','F',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.I.02.2024-II-I-B','0380.01.I.02.2024-II-I-G','NOCHE','G',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.I.03.2024-II-I-E','0380.01.I.03.2024-II-I-H','NOCHE','H',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.03.2024-II-I-C','0380.01.I.03.2024-II-I-I','NOCHE','I',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.04.2024-II-I-G','0380.01.I.04.2024-II-I-M','NOCHE','M',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.04.2024-II-I-E','0380.01.I.04.2024-II-I-K','NOCHE','K',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.04.2024-II-I-F','0380.01.I.04.2024-II-I-L','NOCHE','L',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.04.2024-II-I-D','0380.01.I.04.2024-II-I-J','NOCHE','J',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.I.04.2024-II-I-I','0380.01.I.04.2024-II-I-N','NOCHE','N',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.II.02.2024-II-II-C','0380.01.II.02.2024-II-II-B','MAÑANA','B',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.II.01.2024-II-II-A','0380.01.II.01.2024-II-II-C','MAÑANA','C',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.II.02.2024-II-II-D','0380.01.II.02.2024-II-II-D','MAÑANA','D',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.II.02.2024-II-II-B','0380.01.II.02.2024-II-II-E','NOCHE','E',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.II.02.2024-II-II-D','0380.01.II.02.2024-II-II-F','NOCHE','F',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.II.02.2024-II-II-E','0380.01.II.02.2024-II-II-I','NOCHE','I',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.II.02.2024-II-II-C','0380.01.II.02.2024-II-II-H','NOCHE','H',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.II.02.2024-II-II-B','0380.01.II.02.2024-II-II-G','NOCHE','G',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.III.02.2024-II-III-C','0380.01.III.02.2024-II-III-A','MAÑANA','A',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.III.01.2024-II-III-B','0380.01.III.01.2024-II-III-C','MAÑANA','C',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.III.01.2024-II-III-A','0380.01.III.01.2024-II-III-B','MAÑANA','B',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.III.01.2024-II-III-B','0380.01.III.01.2024-II-III-F','NOCHE','F',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.III.02.2024-II-III-D','0380.01.III.02.2024-II-III-G','NOCHE','G',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS','0380.01.III.01.2024-II-III-A','0380.01.III.01.2024-II-III-E','NOCHE','E',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.III.02.2024-II-III-E','0380.01.III.02.2024-II-III-J','NOCHE','J',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.III.03.2024-II-III-H','0380.01.III.03.2024-II-III-L','NOCHE','L',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.III.02.2024-II-III-C','0380.01.III.02.2024-II-III-H','NOCHE','H',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.III.02.2024-II-III-D','0380.01.III.02.2024-II-III-I','NOCHE','I',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.III.02.2024-II-III-F','0380.01.III.02.2024-II-III-K','NOCHE','K',NULL),
('GESTIÓN ADMINISTRATIVA','PETIT THOUARS (2)','0380.01.III.03.2024-II-III-G','0380.01.III.03.2024-II-III-D','TARDE','D',NULL),
('MARKETING','PETIT THOUARS (2)','0210.75.I.02.2024-II-I-B','0210.75.I.02.2024-II-I-D','NOCHE','D',NULL),
('MARKETING','PETIT THOUARS (2)','0210.75.I.02.2024-II-I-C','0210.75.I.02.2024-II-I-E','NOCHE','E',NULL),
('MARKETING','PETIT THOUARS (2)','0210.75.I.02.2024-II-I-D','0210.75.I.02.2024-II-I-F','NOCHE','F',NULL),
('MARKETING','PETIT THOUARS (2)','0210.75.I.01.2024-II-I-A','0210.75.I.01.2024-II-I-C','NOCHE','C',NULL),
('MARKETING','PETIT THOUARS (2)','0210.75.II.01.2024-II-II-A','0210.75.II.01.2024-II-II-C','NOCHE','C',NULL),
('MARKETING','PETIT THOUARS (2)','0210.75.II.01.2024-II-II-B','0210.75.II.01.2024-II-II-D','NOCHE','D',NULL),
('MARKETING','PETIT THOUARS (2)','0210.75.II.01.2024-II-II-C','0210.75.II.01.2024-II-II-E','NOCHE','E',NULL),
('MARKETING','PETIT THOUARS','0210.01.IV.03.2024-II-IV-C','0210.01.IV.03.2024-II-IV-B','MAÑANA','B',NULL),
('MARKETING','PETIT THOUARS','0210.01.IV.03.2024-II-IV-B','0210.01.IV.03.2024-II-IV-C','NOCHE','C',NULL),
('MARKETING','PETIT THOUARS (2)','0210.01.IV.01.2024-II-IV-A','0210.01.IV.01.2024-II-IV-D','NOCHE','D',NULL)
------------------------------------------------------------
-- 2) Variables de trabajo
------------------------------------------------------------
------------------------------------------------------------
DECLARE
    @min INT, @max INT,
    @Carrera VARCHAR(255),
    @SedeExcel VARCHAR(255),
    @IdSedeFila INT,
    @SeccionOriginal VARCHAR(255),
    @SeccionNueva    VARCHAR(255),
    @Turno           VARCHAR(50),
    @TurnoCanon      VARCHAR(10),  -- MAÑANA / NOCHE / TARDE
    @SeccionNominaMinedu VARCHAR(100),
    @Observacion VARCHAR(255);

SELECT @min = MIN(id), @max = MAX(id) FROM @seccionescorrelativas;
------------------------------------------------------------
-- 3) Loop por cada fila del Excel
------------------------------------------------------------
WHILE @min <= @max
BEGIN
    -- Reset por iteración
    SET @Carrera = NULL; SET @SedeExcel = NULL; SET @IdSedeFila = NULL;
    SET @SeccionOriginal = NULL; SET @SeccionNueva = NULL;
    SET @Turno = NULL; SET @TurnoCanon = NULL;
    SET @SeccionNominaMinedu = NULL; SET @Observacion = NULL;

    -- Tomar fila
    SELECT
        @Carrera             = Carrera,
        @SedeExcel           = Sede,
        @SeccionOriginal     = SeccionOriginal,
        @SeccionNueva        = SeccionNueva,
        @Turno               = Turno,
        @SeccionNominaMinedu = SeccionNominaMinedu
    FROM @seccionescorrelativas
    WHERE id = @min;

    -- Normalizar Turno (DIURNO→MAÑANA, NOCTURNO→NOCHE)
    --SET @TurnoCanon =
    --    CASE
    --        WHEN UPPER(LTRIM(RTRIM(@Turno))) COLLATE Modern_Spanish_CI_AI IN ('MAÑANA','DIURNO') THEN 'MAÑANA'
    --        WHEN UPPER(LTRIM(RTRIM(@Turno))) COLLATE Modern_Spanish_CI_AI IN ('NOCHE','NOCTURNO') THEN 'NOCHE'
    --        WHEN UPPER(LTRIM(RTRIM(@Turno))) COLLATE Modern_Spanish_CI_AI =  'TARDE'              THEN 'TARDE'
    --        ELSE UPPER(LTRIM(RTRIM(@Turno))) COLLATE Modern_Spanish_CI_AI
    --    END;

    -- Resolver IdSede por Código o Nombre (ajusta NombreSede/Nombre según tu tabla)
    SELECT TOP (1) @IdSedeFila = S.IdSede
    FROM dbo.Sede S
    WHERE UPPER(LTRIM(RTRIM(S.Codigo))) = UPPER(LTRIM(RTRIM(@SedeExcel)))
       OR UPPER(LTRIM(RTRIM(ISNULL(S.Nombre, S.Nombre)))) = UPPER(LTRIM(RTRIM(@SedeExcel)));

    IF @IdSedeFila IS NULL
    BEGIN
        SET @Observacion = 'SEDE NO ENCONTRADA';
        UPDATE @seccionescorrelativas SET Observacion = @Observacion WHERE id = @min;
        PRINT CONCAT('Sede no encontrada: "', ISNULL(@SedeExcel,''), '" | ', @SeccionOriginal);
        SET @min = @min + 1;
        CONTINUE;
    END
    --SELECT @IdSedeFila,@SeccionOriginal,@Turno,'VARIABLES DE ENTRADA'
    --RETURN
    ------------------------------------------------------------
    -- 3.1) UPDATE AlumnoCursoNomina (SeccionNomina + IdSede + Turno con equivalencias)
    --      Sin fecha; solo si cambia algo (idempotente)
    ------------------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM dbo.AlumnoCursoNomina A
        WHERE A.IdSede = @IdSedeFila
          AND A.SeccionNomina = @SeccionOriginal
		  AND A.Turno = @Turno
          --AND (
          --      (@TurnoCanon = 'MAÑANA' AND UPPER(LTRIM(RTRIM(A.Turno))) COLLATE Modern_Spanish_CI_AI IN ('MAÑANA','DIURNO'))
          --   OR (@TurnoCanon = 'NOCHE'  AND UPPER(LTRIM(RTRIM(A.Turno))) COLLATE Modern_Spanish_CI_AI IN ('NOCHE','NOCTURNO'))
          --   OR (@TurnoCanon = 'TARDE'  AND UPPER(LTRIM(RTRIM(A.Turno))) COLLATE Modern_Spanish_CI_AI =  'TARDE')
          --    )
        --  AND A.SeccionNomina <> @SeccionNueva
    )
    BEGIN
        UPDATE A
           SET A.SeccionNomina = @SeccionNueva,  A.Turno = @Turno, A.Observacion='Actualizado por secciones correlativas 27.01.2026'
        FROM dbo.AlumnoCursoNomina A
        WHERE A.IdSede = @IdSedeFila
          AND A.SeccionNomina = @SeccionOriginal
		  AND A.Turno = @Turno
          AND A.Observacion IS NULL
          --AND (
          --      (@TurnoCanon = 'MAÑANA' AND UPPER(LTRIM(RTRIM(A.Turno))) COLLATE Modern_Spanish_CI_AI IN ('MAÑANA','DIURNO'))
          --   OR (@TurnoCanon = 'NOCHE'  AND UPPER(LTRIM(RTRIM(A.Turno))) COLLATE Modern_Spanish_CI_AI IN ('NOCHE','NOCTURNO'))
          --   OR (@TurnoCanon = 'TARDE'  AND UPPER(LTRIM(RTRIM(A.Turno))) COLLATE Modern_Spanish_CI_AI =  'TARDE')
          --    )
         -- AND A.SeccionNomina <> @SeccionNueva;

        IF @@ROWCOUNT > 0
            SET @Observacion = 'ACN: REGISTROS ACTUALIZADOS';
        ELSE
            SET @Observacion = 'ACN: NO SE ACTUALIZARON REGISTROS';
    END
    ELSE
    BEGIN
        SET @Observacion = 'ACN: NO SE ENCONTRARON COINCIDENCIAS';
    END

    ------------------------------------------------------------
    -- 3.2) UPDATE AlumnoCursoNominaJson (Seccion + IdSede + Turno *canónico*)
    --      Sin fecha; solo si cambia algo (idempotente)
    --      Set: Seccion, SeccionMinedu, SeccionNominaMinedu, Turno=canónico
    ------------------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM dbo.AlumnoCursoNominaJson J
        WHERE J.IdSede  = @IdSedeFila
          AND J.Seccion = @SeccionOriginal
		  AND J.Turno = @Turno
          -- AND UPPER(LTRIM(RTRIM(J.Turno))) COLLATE Modern_Spanish_CI_AI = UPPER(@TurnoCanon) COLLATE Modern_Spanish_CI_AI
          AND (
                J.Seccion <> @SeccionNueva
             OR ISNULL(J.SeccionMinedu,'')       <> ISNULL(@SeccionNominaMinedu,'')
             OR ISNULL(J.SeccionNominaMinedu,'') <> ISNULL(@SeccionNominaMinedu,'')
             OR J.Turno <> @Turno
              )
    )
    BEGIN
        UPDATE J
           SET J.Seccion             = @SeccionNueva,
               J.SeccionMinedu       = @SeccionNueva,
               J.SeccionNominaMinedu = @SeccionNominaMinedu,
               J.Turno               = @Turno,
			   J.NombreSede = 'LIMA PETIT THOUARS',
               J.Observacion='Actualizado por secciones correlativas 27.01.2026'
        FROM dbo.AlumnoCursoNominaJson J
        WHERE J.IdSede  = @IdSedeFila
          AND J.Seccion = @SeccionOriginal
		  AND J.Turno = @Turno
          AND J.Observacion IS NULL
          --AND UPPER(LTRIM(RTRIM(J.Turno))) COLLATE Modern_Spanish_CI_AI = UPPER(@TurnoCanon) COLLATE Modern_Spanish_CI_AI
          AND (
                J.Seccion <> @SeccionNueva
             OR ISNULL(J.SeccionMinedu,'')       <> ISNULL(@SeccionNominaMinedu,'')
             OR ISNULL(J.SeccionNominaMinedu,'') <> ISNULL(@SeccionNominaMinedu,'')
             OR J.Turno <> @Turno
              );

        IF @@ROWCOUNT > 0
            SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACNJSON: REGISTROS ACTUALIZADOS';
        ELSE
            SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACNJSON: NO SE ACTUALIZARON REGISTROS';
    END
    ELSE
    BEGIN
        SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACNJSON: NO SE ENCONTRARON COINCIDENCIAS';
    END

	------------------------------------------------------------
	-- 3.3) UPDATE ActaConsolidada (con sinónimos de turno)
	--     Set: SeccionNomina = @SeccionNueva
	--     Where: Seccion = @SeccionOriginal AND IdSede = @IdSedeFila
	--            AND TurnoNombre en el grupo del @TurnoCanon (MAÑANA/DIURNO, NOCHE/NOCTURNO, TARDE)
	--     Idempotente
	------------------------------------------------------------
	IF EXISTS (
		SELECT 1
		FROM dbo.ActaConsolidada AC
		WHERE AC.IdSede = @IdSedeFila
		  AND AC.Seccion = @SeccionOriginal
		  AND AC.TurnoNombre = @Turno
		  --AND (
				--(@TurnoCanon = 'MAÑANA' AND UPPER(LTRIM(RTRIM(AC.TurnoNombre))) COLLATE Modern_Spanish_CI_AI IN ('MAÑANA','DIURNO'))
			 --OR (@TurnoCanon = 'NOCHE'  AND UPPER(LTRIM(RTRIM(AC.TurnoNombre))) COLLATE Modern_Spanish_CI_AI IN ('NOCHE','NOCTURNO'))
			 --OR (@TurnoCanon = 'TARDE'  AND UPPER(LTRIM(RTRIM(AC.TurnoNombre))) COLLATE Modern_Spanish_CI_AI =  'TARDE')
			 -- )
		  --AND ISNULL(AC.Seccion,'') <> ISNULL(@SeccionNueva,'')
	)
	BEGIN
		UPDATE AC
		   SET AC.Seccion= @SeccionNueva, TurnoCodigo = @Turno , TurnoNombre = @Turno,
			   AC.Distrito  = 'PETIT THOUARS',	--COALESCE(@DistritoNuevo,  AC.Distrito),
			   AC.Direccion = 'AV.PETIT THOUARS 315',	--COALESCE(@DireccionNueva, AC.Direccion)
               AC.Observacion='Actualizado por secciones correlativas 27.01.2026'
		FROM dbo.ActaConsolidada AC
		WHERE AC.IdSede = @IdSedeFila
		  AND AC.Seccion = @SeccionOriginal
		  AND AC.TurnoNombre = @Turno
          AND AC.Observacion IS NULL
		  --AND (
				--(@TurnoCanon = 'MAÑANA' AND UPPER(LTRIM(RTRIM(AC.TurnoNombre))) COLLATE Modern_Spanish_CI_AI IN ('MAÑANA','DIURNO'))
			 --OR (@TurnoCanon = 'NOCHE'  AND UPPER(LTRIM(RTRIM(AC.TurnoNombre))) COLLATE Modern_Spanish_CI_AI IN ('NOCHE','NOCTURNO'))
			 --OR (@TurnoCanon = 'TARDE'  AND UPPER(LTRIM(RTRIM(AC.TurnoNombre))) COLLATE Modern_Spanish_CI_AI =  'TARDE')
			 -- )
		 -- AND ISNULL(AC.Seccion,'') <> ISNULL(@SeccionNueva,'');
    
		IF @@ROWCOUNT > 0
			SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACTA: REGISTROS ACTUALIZADOS';
		ELSE
			SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACTA: NO SE ACTUALIZARON REGISTROS';
	END
	ELSE
	BEGIN
		SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACTA: NO SE ENCONTRARON COINCIDENCIAS';
	END

    ------------------------------------------------------------
    -- 3.4) UPDATE AlumnoCursoActaJson
    --      Set: Seccion = @SeccionNueva,
    --           SeccionMinedu = @SeccionNueva,
    --           SeccionNominaMinedu = @SeccionNominaMinedu
    --      Where: Seccion = @SeccionOriginal AND IdSede = @IdSedeFila
    --             AND Turno = @TurnoCanon (MAÑANA/NOCHE/TARDE)
    --      Idempotente
    ------------------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM dbo.AlumnoCursoActaJson AJ
        WHERE AJ.IdSede  = @IdSedeFila
          AND AJ.Seccion = @SeccionOriginal
		  AND AJ.Turno = @Turno
          --AND UPPER(LTRIM(RTRIM(AJ.Turno))) COLLATE Modern_Spanish_CI_AI = UPPER(@TurnoCanon) COLLATE Modern_Spanish_CI_AI
		  --AND (
				--(@TurnoCanon = 'MAÑANA' AND UPPER(LTRIM(RTRIM(AJ.Turno))) COLLATE Modern_Spanish_CI_AI IN ('MAÑANA','DIURNO'))
			 --OR (@TurnoCanon = 'NOCHE'  AND UPPER(LTRIM(RTRIM(AJ.Turno))) COLLATE Modern_Spanish_CI_AI IN ('NOCHE','NOCTURNO'))
			 --OR (@TurnoCanon = 'TARDE'  AND UPPER(LTRIM(RTRIM(AJ.Turno))) COLLATE Modern_Spanish_CI_AI =  'TARDE')
			 -- )
          --AND (
          --      AJ.Seccion <> @SeccionNueva
          --   OR ISNULL(AJ.SeccionMinedu,'')       <> ISNULL(@SeccionNueva,'')
          --   OR ISNULL(AJ.SeccionNominaMinedu,'') <> ISNULL(@SeccionNominaMinedu,'')
          --    )
    )
    BEGIN
        UPDATE AJ
           SET AJ.Seccion             = @SeccionNueva,
               AJ.SeccionMinedu       = @SeccionNueva,
               AJ.SeccionNominaMinedu = @SeccionNominaMinedu,
			   aj.turno				  = @Turno,
			   AJ.NombreSede = 'LIMA PETIT THOUARS',
               AJ.Observacion='Actualizado por secciones correlativas 27.01.2026'
        FROM dbo.AlumnoCursoActaJson AJ
        WHERE AJ.IdSede  = @IdSedeFila
          AND AJ.Seccion = @SeccionOriginal
		  AND AJ.Turno = @Turno
          AND AJ.Observacion IS NULL
          --AND UPPER(LTRIM(RTRIM(AJ.Turno))) COLLATE Modern_Spanish_CI_AI = UPPER(@TurnoCanon) COLLATE Modern_Spanish_CI_AI
          --AND (
          --      AJ.Seccion <> @SeccionNueva
          --   OR ISNULL(AJ.SeccionMinedu,'')       <> ISNULL(@SeccionNueva,'')
          --   OR ISNULL(AJ.SeccionNominaMinedu,'') <> ISNULL(@SeccionNominaMinedu,'')
          --    );

        IF @@ROWCOUNT > 0
            SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACAJSON: REGISTROS ACTUALIZADOS';
        ELSE
            SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACAJSON: NO SE ACTUALIZARON REGISTROS';
    END
    ELSE
    BEGIN
        SET @Observacion = ISNULL(@Observacion + ' | ','') + 'ACAJSON: NO SE ENCONTRARON COINCIDENCIAS';
    END

    -- Log por fila
    UPDATE @seccionescorrelativas SET Observacion = @Observacion WHERE id = @min;

    PRINT CONCAT('IdSede=', @IdSedeFila,
                 ' | Sede="', @SedeExcel,
                 '" | TurnoExcel="', ISNULL(@Turno,''), '" (Canon=', @Turno, ')',
                 ' | ', @SeccionOriginal, ' -> ', @SeccionNueva,
                 ' | NominaMINEDU=', ISNULL(@SeccionNominaMinedu,'(NULL)'));

    SET @min = @min + 1;
END

-- Resultado final (para revisar qué pasó con cada fila del Excel)
SELECT id, Carrera, Sede, SeccionOriginal, SeccionNueva, Turno, SeccionNominaMinedu, Observacion
FROM @seccionescorrelativas
ORDER BY id;

--COMMIT TRAN;
--ROLLBACK TRAN;
