USE AcademicoIDAT;
GO

-- ############### PARTE 02 - 2  ##################


UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 714393
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 714380
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 714381
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 709107
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'FUNDAMENTOS DEL INGLÉS';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 709107
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'GESTIÓN DE PERSONAS';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 709079
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'FUNDAMENTOS DEL INGLÉS';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 709079
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'GESTIÓN DE PERSONAS';
















