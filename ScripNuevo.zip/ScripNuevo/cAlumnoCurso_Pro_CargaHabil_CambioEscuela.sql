-----------------------------------------------------------------------------------      
--Creado por      : Hugo Mora (07/12/2011)                            
--Funcionalidad   : Permite realizar el proceso de la carga h?bil de los alumnos                
--     cambio de unidad academica IES A EEST    
--------------------------------------------------------------------------------         
/*      
-----------------------------------------------------------------------------      
Nro		FECHA			USUARIO			DESCRIPCION      
-----------------------------------------------------------------------------      
@1		14.10.2019		Hmora			Mejoras Escuela     
@2		24.02.2020		RSamame			se agrego las curriculas antiguas para la convalidaci?n 
@3		03.02.2020		RSamame			Se agrego validacion con las curriculas de equivalencia
@4		29.09.2020		RSamame			Se agrego parametro idcurricula a la funcion 
@5		27.01.2021		Jnavia			Mejoras Convalidacion Bachiller
@6		18.02.2021		JLEO			Se agregan variables EsInlearning, IdTipoConvalidacion
@7		24.03.2023		EHuillca		Se agrega l?gica para tipo de convalidaci?n por Regularizaci?n de Malla(RM)
@8		17.10.2023		Alsanchez		Se agrega logica de diferenciacion de precios
@9										Sin bitacora
@10		01.05.2024		FETORRES		Se agrega logica para que CA tome la compania socio de ZEGEL. 
@11		15.05.2024		MBUENO			Se restringe logica de convalidacion automatica de escuela solo a ZEGEL
@12		16.06.2024		MBUENO			Se corrige registro anterior y nuevo para curriculas con el mismo producto IDAT
@13		03.07.2024		ILLOSAD			Se agrega IDAT a la logica de convalidacion automatica de escuela
@14		01/08/2024		RSamame			Se agrega logica para la progresion curricular con las nuevas reglas de segun Academico
@15		01/08/2024		JQuenta			Se agregan validaciones en la Logica de la Progresion Curricular
@16		07/08/2024		FETORRES		Se agrega logica para CA.
@17		25/09/2024		JQuenta			Se agrega la Logica para identificar el Tipo de Equivalencia segun Tipo de Programa para IDAT
*/       
      
--CREATE PROCEDURE [dbo].[cAlumnoCurso_Pro_CargaHabil_CambioEscuela]     (
DECLARE 
@pIdEmpresa INT,          
@pIdSede INT,          
@pIdPeriodo INT,          
@pIdAlumno INT,          
@pIdUsuarioCreacion INT,          
@pTipo VARCHAR(2),  
@IdPrecioSede INT,--@8
@pEstado VARCHAR(2) ,          
@pDescripcion VARCHAR(1000)          
--AS          
BEGIN          

SELECT @pIdEmpresa=1
,@pIdSede=40
,@pIdPeriodo=3805
,@pIdAlumno=1320774
,@pIdUsuarioCreacion=446639
,@pTipo='CI'
,@IdPrecioSede=NULL

	SET NOCOUNT ON        
  -- declaracion de variables          
	DECLARE          
	@CurIdAlumno INT,           
	@CurIdProductoAnterior INT,          
	@CurIdProductoNueva INT,          
	@CurIdCurriculaAnterior INT,          
	@CurIdCurriculaNueva INT,          
	--@CurEsCambioCarrera INT,          
	@IdRegistroAnterior INT,          
	@IdRegistroNuevo INT,          
	@CurIdCurso INT,          
	@Cumple INT,          
	@TipoAprobacion VARCHAR(2),          
	@Val INT,          
	@NumeroConv VARCHAR(10),          
	@IdConvalidacion INT,          
	@PromReal VARCHAR(10),          
	@PromFinal VARCHAR(10),          
	-- declaracion de variables          
	@IdMatriculaNew INT,          
	@wIdPromocion INT,      
	@CodigoPromocion VARCHAR(20),       
	@wIdModulo INT,          
	@Res INT,           
	@wNumVezCurso INT,          
	@NumeroMatricula varchar(50),          
	@CurNumeroIdentidad varchar(50),            
	@Direccion varchar(100),          
	@NombreCompleto varchar(100),          
	@Telefonos varchar(50),          
	@anno INT,          
	@fecha VARCHAR(10),          
	@Existe INT,          
	@wTipo VARCHAR(2),          
	@ValAlumnoMatriculado INT,          
	@EliCargaHabil INT,          
	@wIdModuloCurso INT,        
	@cCursosModulo INT,        
	@cCursosMat INT,        
	@TipoServicio varchar(1),        
	@Tipo  varchar(2),        
	@Deudas INT,      
	@IdSedeAnterior INT,      
	@IdDocumentoTipo INT,      
	@Ubigeo VARCHAr(10),      
	@NumeroCuota int,      
	@Descuento int = null,      
	@IdUnidadAcademica int,      
	--      
	@FinPeriodo date,      
	@ano int,      
	@Verifica bit,      
	@CompaniaSocio char(8),      
	@cTipo varchar(2),      
	@ObservacionC varchar(500),        
	@Observacion varchar(1000),             
	@pContador INT,        
	@Egresado bit,      
	@Reingreso bit,    
	@Regular bit,      
	@CurIdTipo INT,
	@EquivalenciaCertificado INT = 0,
	@CodigoCurriculaAnterior VARCHAR(20),
	@CodigoCurriculaNueva VARCHAR(20),
	@CompaniaSocioPadre char(8),
	@AnioCursado    INT, --@14 A�o donde curso el 1 semestre de manera regular.  
	@IdModuloInicio INT, --@14 Modulo de Inicio para el alumno  
	@wIdModuloReal INT, --@14 Valores de retorno Modulo real del alumno
	@wTipoCondicionNueva CHAR(2) , --@14 Valores de retorno Tipo condicion Regular o irregular
	@vAnioCursado INT, --@14
	@vIdModuloInicio INT,--@14
	@vCompaniaSocio CHAR(8), --@14
	@vIdUnidadAcademica VARCHAR(50), --@14
	@vActivo INT, --@14
	--Inicio --@17
	@IdTipoProgramaOrigen INT,
	@IdTipoProgramaDestino INT,
	@TipoProgramaOrigen VARCHAR(20),
	@TipoProgramaDestino VARCHAR(20),
	@EstadoTipoProgramaInstitutoEscuela VARCHAR(MAX),
	@TipoProgramaInstituto VARCHAR(5000),
	@TipoProgramaEscuela VARCHAR(5000)
	--Fin --@17

	--Inicio --@17
	SELECT
		@EstadoTipoProgramaInstitutoEscuela = Valor,
		@TipoProgramaInstituto = valor2,
		@TipoProgramaEscuela = Valor3
	FROM Parametro WITH (NOLOCK)
	WHERE Nombre = 'TipoPrograma'
	--Fin --@17

	--@14 Se obtiene lo parametros para la progresion curricular
	SELECT @vCompaniaSocio=Disponible1, @vAnioCursado=Disponible2,@vIdModuloInicio=Disponible3,@vIdUnidadAcademica=Disponible4,@vActivo=Activo 
	FROM MaestroTablaRegistro WITH (NOLOCK) where codigo='ProgreCurri'

	--Inicio --@15
	DECLARE
	@vNombreProceso VARCHAR(100),
	@vIdMatricula INT,
	@vIdProducto INT,
	@vIdPeriodo INT,
	@vIdModulo INT,
	@EsProcesado BIT

	SET @vNombreProceso = 'LogDisNiv'
	SET @vIdMatricula = 0
	SET @vIdProducto = 0
	SET @vIdPeriodo = 0
	SET @vIdModulo = 0
	SET @EsProcesado = 0
	--Fin --@15
			
	SELECT @CurIdAlumno = CC.IdAlumno,           
	@CurIdProductoAnterior = CC.IdProductoAnterior,          
	@CurIdProductoNueva = CC.IdProductoNueva,          
	@CurIdCurriculaAnterior = CC.IdCurriculaAnterior,          
	@CurIdCurriculaNueva = CC.IdCurriculaNueva,          
	@CurNumeroIdentidad = AC.NumeroIdentidad,      
	@Direccion = AC.DireccionCompleta,          
	@NombreCompleto = AC.NombreCompleto,          
	@Telefonos = SUBSTRING(dbo.cActorTelefonoStr(AC.IdActor),1,20),      
	@IdSedeAnterior = IdSedeOrigen,      
	@IdDocumentoTipo = ac.IdDocumentoTipo,          
	@Ubigeo = isnull(ad.IdUbigeoResidencia,''),      
	@CompaniaSocio=e.CompaniaSocio, --@3
	--Inicio --@17
	@IdTipoProgramaOrigen = PER_ORIG.IdUnidadAcademica,
	@IdTipoProgramaDestino = PER_DEST.IdUnidadAcademica
	--Fin --@17
	FROM TrasladoSede CC WITH (NOLOCK) 
	--Inicio --@17
	INNER JOIN Periodo PER_ORIG WITH (NOLOCK) ON CC.IdPeriodoAnterior = PER_ORIG.IdPeriodo
	INNER JOIN Periodo PER_DEST WITH (NOLOCK) ON CC.IdPeriodoTraslado = PER_DEST.IdPeriodo
	--Fin --@17
	INNER JOIN Actor AC  WITH (NOLOCK)          
	ON CC.IdAlumno = AC.IdActor       
	INNER JOIN Empresa e WITH (NOLOCK) ON CC.IdEmpresa=e.IdEmpresa         
	left join ActorDireccion ad WITH (NOLOCK)       
	on ac.IdActor = ad.IdActor      
	and ad.Principal = 1              
	WHERE CC.IdEmpresa = @pIdEmpresa          
	AND CC.IdSede = @pIdSede          
	AND CC.IdPeriodoTraslado = @pIdPeriodo          
	AND (CC.IdAlumno = @pIdAlumno)          
	AND CC.Estado = 1;          

	--Inicio --@17
	SELECT
		@TipoProgramaOrigen = ISNULL(NombreCorto,'')
	FROM UnidadAcademica WITH (NOLOCK)
	WHERE IdUnidadAcademica = @IdTipoProgramaOrigen
  
	SELECT
		@TipoProgramaDestino = ISNULL(NombreCorto,'')
	FROM UnidadAcademica WITH (NOLOCK)
	WHERE IdUnidadAcademica = @IdTipoProgramaDestino  
	--Fin --@17

	--Consideracion a revisar con Donald  
	--Alumno pertenciente a la curricula 022 y 023    
 
		--@3
		declare @PaqCursoEquivalenciaDet table  
	(idcurricula int)
	insert into @PaqCursoEquivalenciaDet
	select distinct idcurricula from PaqCursoEquivalenciaDet 
	--@3
	
	IF @CompaniaSocio = '00002500'
	BEGIN
		--@1  
		IF @CurIdCurriculaAnterior in   (select idcurricula from @PaqCursoEquivalenciaDet)-- (27,28,4,586,547,589)    --@2   --@3  
		BEGIN      
			IF exists(Select 1 from Egresados where IdAlumno=@pIdAlumno and IdCurricula=@CurIdCurriculaAnterior)      
			BEGIN      
				select @Verifica = 0      
				select @Egresado = 1      
				select @Reingreso = 0      
			END      
			ELSE      
			BEGIN              
				select @Verifica = 0  
				select @Egresado = 0       
				select @Reingreso = 1                 
			END      
		END      
		ELSE      
		BEGIN    
			select @Verifica = 0      
			select @Egresado = 0      
			select @Reingreso = 0         
			select @Regular = 1  
			PRINT '1'
		END    
		--@1  
	END  

	IF @CompaniaSocio IN ( '00002700', '00002600')--@16	
	BEGIN
		--@1  
		IF @CurIdCurriculaAnterior in   (select idcurricula from @PaqCursoEquivalenciaDet)-- (27,28,4,586,547,589)    --@2   --@3  
		BEGIN      
			IF exists(Select 1 from Egresados where IdAlumno=@pIdAlumno and IdCurricula=@CurIdCurriculaAnterior)      
			BEGIN  
				select @Verifica = 0      
				select @Egresado = 1      
				select @Reingreso = 0      
			END      
			ELSE      
			BEGIN              
				select @Verifica = 0  
				select @Egresado = 0    
				
				--Inicio --@17
				IF @EstadoTipoProgramaInstitutoEscuela = 1
				BEGIN
				
					IF @TipoProgramaOrigen = @TipoProgramaInstituto AND @TipoProgramaDestino = @TipoProgramaInstituto
					BEGIN

						select @Regular = 1  
						PRINT '2'
					END
					ELSE IF @TipoProgramaOrigen = @TipoProgramaInstituto AND @TipoProgramaDestino = @TipoProgramaEscuela
					BEGIN

						select @Reingreso = 1  
						
					END
					ELSE IF @TipoProgramaOrigen = @TipoProgramaEscuela AND @TipoProgramaDestino = @TipoProgramaEscuela
					BEGIN

						select @Regular = 1   
						PRINT '3'
					END
					ELSE
					BEGIN

						select @Regular = 1 
						PRINT '4'
					END

				END
				ELSE
				BEGIN

					select @Regular = 1 
					PRINT '5'
				END

			END      
		END      
		ELSE      
		BEGIN    
			select @Verifica = 0      
			select @Egresado = 0      
			select @Reingreso = 0         
			select @Regular = 1    
			PRINT '6'
		END    
		--@1  
	END
    
	IF @IdDocumentoTipo not in (25,27)      
	BEGIN              
		SELECT @pEstado = 'KO'              
		SELECT @pDescripcion = 'El alumno no tiene registrado un tipo de documento v?lido'             
	RETURN              
	END        
      
	IF ISNUMERIC(@CurNumeroIdentidad) = 0      
	BEGIN              
		SELECT @pEstado = 'KO'              
		SELECT @pDescripcion = 'El alumno no tiene registrado un n?mero de documento v?lido'             
	RETURN              
	END        
      
	IF @Ubigeo = '' or @Direccion = ''      
	BEGIN              
		SELECT @pEstado = 'KO'         
		SELECT @pDescripcion = 'El alumno no tiene direcci?n registrada. Verifique.'             
	RETURN              
	END       
               
	SET @Deudas = 0        
        
	select @Deudas = isnull(valor,0)      
	from ParametroUnidadAcademica      
	where IdEmpresa = @pIdEmpresa      
	and IdSede = @pIdSede      
	and Activo = 1      
	and Nombre = 'CargaHabilDeudas'       
        
	IF isnull(@Deudas,0) = 1       
	BEGIN         
		--verificamos si tiene deudas pendientes        
		EXEC cAlumno_Valida_Deudas @pIdAlumno,null,@Deudas OUTPUT        
            
		IF @Deudas > 0 -- tiene deudas        
		BEGIN           
			-- verificamos si tiene permiso para generar carga con deuda         
			IF dbo.cAutorizacionAlumno_Val_Existe(@pIdEmpresa,@pIdSede,1,1,1,@pIdPeriodo,@pIdAlumno,1035) = 0              
			BEGIN                
				SELECT @pEstado = 'KO'                
				SELECT @pDescripcion = 'El alumno tiene deudas pendientes con la instituci?n.'               
				RETURN                
			END            
		END        
	END      
      
	--@9 Inicio              
	-- Valida si el alumno tiene alg?n bloqueo acad?mico.              
	EXEC cAlumno_Valida_Bloqueos @pIdSede, @pIdAlumno, @pContador OUT, @Observacion OUT            
	IF @pContador > 0              
	BEGIN              
		SELECT @pEstado = 'KO'              
		SELECT @pDescripcion = @Observacion              
		RETURN            
	END              
	--@9 Fin        
      
	-- Recuperamos IDMatricula si ya esta matriculado            
	DECLARE @IDMatricula int        
	DECLARE @Retorno INT        
       
          
	SELECT @IDMatricula = dbo.cMatricula_Sel_AlumnoMatricula(@pIdEmpresa,                    
				@pIdSede,                    
				@pIdPeriodo, -- este es el nuevo periodo               
				@pIdAlumno,
				@CurIdCurriculaNueva)   -- @4     
	if  @IDMatricula>0        
    begin        
		--Si no pago entonces eliminamos cointerfase.        
  IF @CompaniaSocio='00002600'
	 BEGIN
	 SELECT @CompaniaSocioPadre=COMPANIASOCIOPADRE FROM EMPRESA--@9 
		if not exists(select 1 from vw_CO_Interfase_P09_Header with(nolock)       
					where IdMatricula=@IDMatricula       
					and Estado='CO' and CompaniaSocio=@CompaniaSocioPadre)     
	   begin
   EXEC cInterfaseDocumento_Ins_Borrar_General @idMatricula,@Retorno output  
	 END 
	 END
	 ELSE IF @CompaniaSocio<>'00002600'
	 BEGIN 
  if not exists(select * from vw_co_Interfase_p09_header with(nolock)  
       where IdMatricula=@IDMatricula   
		and Estado='CO' and CompaniaSocio=@CompaniaSocio)  --@3      
begin
			EXEC cInterfaseDocumento_Ins_Borrar_General @idMatricula,@Retorno output        
	   END
		END
		else        
		begin        
			SELECT @pEstado = 'KO'                    
			SELECT @pDescripcion = 'El alumno ya pag?.'                  
			RETURN        
		end               
	end          
         
	SELECT @IDMatricula=ISNULL((  SELECT top 1 M.IDMatricula              
			FROM Matricula M    with(nolock)            
			WHERE m.IdEmpresa = @pIdEmpresa                
			AND m.IdSede = @pIdSede                 
			AND m.IdPeriodo = @pIdPeriodo                
			AND M.IdActor = @pIdAlumno                
			AND M.Estado <> 'X'                
			AND M.EsMatricula = 1 ) ,0)        
                   
	-- verificamos si ya esta matriculado                
	SELECT @ValAlumnoMatriculado = dbo.cMatricula_Val_AlumnoMatriculado(@pIdEmpresa,                
					@pIdSede,                
					@pIdPeriodo, -- este es el nuevo periodo             
					@pIdAlumno,
					@CurIdCurriculaNueva)   -- @4          
                         
        
                                  
	IF @ValAlumnoMatriculado = 1 -- ESTA MATRICULADO                
	BEGIN                
		SELECT @pEstado = 'KO'                
		SELECT @pDescripcion = 'El alumno ya se encuentra matriculado.'               
		RETURN                
	END  --@ValAlumnoMatriculado = 1              
                
  -- el alumno no esta matriculado                
     -- prcesamos su carga habil                
     -- borramos su matricula si la tuviera                                       
	IF @ValAlumnoMatriculado = 0                
	BEGIN                
		EXEC cMatricula_Eli_CargaHabil @pIdEmpresa,                
										@pIdSede,                
										@pIdAlumno,             
										@pIdPeriodo,      
										@CurIdCurriculaNueva, --@5                  
										@EliCargaHabil OUTPUT                
                                    
		IF @EliCargaHabil = 1 -- ERROR AL ELIMINAR LAS MATRICULAS                
		BEGIN                
			SELECT @pEstado = 'KO'                
			SELECT @pDescripcion = 'Error al eliminar la carga del alumno.'                
			RETURN                
		END                
	END           
	--Inicio @12
	IF @CompaniaSocio = '00002700'
	BEGIN
		--sacamos el IdRegistro anterior            
		SELECT TOP 1 @IdRegistroAnterior = IdRegistro       
		FROM Registro WITH(NOLOCK)          
		WHERE IdEmpresa = @pIdEmpresa            
		AND IdSede = @IdSedeAnterior            
		AND IdActor = @CurIdAlumno            
		AND IdProducto = @CurIdProductoAnterior            
		AND Estado <> 'X' ORDER BY IdRegistro ASC      
             
		--sacamos el IdRegistro NUEVO            
		SELECT TOP 1 @IdRegistroNuevo = IdRegistro            
		FROM Registro WITH(NOLOCK)       
		WHERE IdEmpresa = @pIdEmpresa            
		AND IdSede = @pIdSede            
		AND IdActor = @CurIdAlumno            
		AND IdProducto = @CurIdProductoNueva            
		AND Estado <> 'X' ORDER BY IdRegistro DESC  

		--Fin @12
	END
	ELSE
	BEGIN
	-- sacamos el idregistro anterior          
	select @IdRegistroAnterior = IdRegistro          
	from Registro WITH(NOLOCK)           
	where IdEmpresa = @pIdEmpresa          
	and IdSede = @IdSedeAnterior          
	and IdActor = @CurIdAlumno          
	and IdProducto = @CurIdProductoAnterior          
	and Estado <> 'X'          
           
	-- sacamos el idregistro NUEVO          
	select @IdRegistroNuevo = IdRegistro          
	from Registro WITH(NOLOCK)           
	where IdEmpresa = @pIdEmpresa          
	and IdSede = @pIdSede          
	and IdActor = @CurIdAlumno          
	and IdProducto = @CurIdProductoNueva          
	and Estado <> 'X'          
    
END
	--@5
	IF @Egresado=1      
	BEGIN      
		PRINT 'Egresado'    
		SELECT @CurIdTipo=2
	END      
      
	IF @Reingreso=1      
	BEGIN   
		PRINT 'Reingreso'    
		SELECT @CurIdTipo=3
	END    
	--@1    
	IF @Regular=1        
	BEGIN        
		PRINT 'RegularA'      
		SELECT @CurIdTipo=1      
	END

	--JNAVIA
	IF EXISTS (SELECT 1 FROM EquivalenciaCurriculas WHERE IdCurriculaDestino=@CurIdCurriculaNueva AND IdCurriculaOrigen=@CurIdCurriculaAnterior AND IdTipo=@CurIdTipo AND Activo=1 AND @CompaniaSocio in ('00002500','00002700'))--@EquivalenciaCertificado=1 --@11 --@13
	BEGIN
		PRINT '@EquivalenciaCertificado'
		SET @EquivalenciaCertificado=1
		SELECT @pIdEmpresa,@pIdSede,@pIdPeriodo,@pTipo,@CurIdAlumno,@IdRegistroNuevo
		,@IdRegistroAnterior,@CurIdCurriculaNueva
		,@CurIdCurriculaAnterior,@CurIdTipo,@pIdUsuarioCreacion
		EXEC EquivalenciaCurriculas_Val_CumplimientoNuevoEscuela @pIdEmpresa,@pIdSede,@pIdPeriodo,@pTipo,@CurIdAlumno,@IdRegistroNuevo,@IdRegistroAnterior,@CurIdCurriculaNueva,@CurIdCurriculaAnterior,@CurIdTipo,@pIdUsuarioCreacion,@wIdModulo OUT,@wTipo OUT
	END
	--@5

	IF @Verifica = 0 AND @EquivalenciaCertificado = 0--@5
    begin      
		-- sacamos lA CURRICULACURSO DE Los cursos del nuevo producto        
		DECLARE @CurCursos TABLE(Id INT IDENTITY,         
		IdCurso INT)        
                 
		INSERT INTO @CurCursos        
		SELECT IdCurso        
		FROM AlumnoCurriculaCurso        
		WHERE IdRegistro = @IdRegistroNuevo        
		AND IdAlumno = @CurIdAlumno        
		AND IdCurricula = @CurIdCurriculaNueva        
		ORDER BY IdModulo ASC;        
           
		SET @Val = 0        
		SET @IdConvalidacion = 0        
             
		WHILE EXISTS (SELECT * FROM @CurCursos)            
		BEGIN              
		   SELECT TOP 1 @CurIdCurso=IdCurso        
		   FROM @CurCursos             
		   ORDER BY Id           
              
		   SET @Cumple = 0          
		   SET @TipoAprobacion = ''          
                  
			EXEC AlumnoCurriculaCurso_Val_CumplimientoNuevoEscuela @CurIdAlumno,           
					@IdRegistroAnterior,           
					@CurIdCurriculaNueva,          
					@CurIdCurriculaAnterior,        
					@CurIdCurso,      
					@CurIdTipo,           
					'NO',           
					@Cumple OUTPUT,           
					@TipoAprobacion OUTPUT,      
					@PromFinal OUTPUT,      
					@PromReal OUTPUT    
                            
			IF @Cumple = 1          
			BEGIN           
				-- si es la primera vez crea la convalidacion          
				SET @Val = @Val + 1          
                            
				IF @Val = 1          
				BEGIN          
					-- debemos verificar si ya se realizo una convalidacion          
					-- en el periodo     
					SET @CodigoCurriculaAnterior = (Select Codigo FROM Curricula WITH(NOLOCK) WHERE IdCurricula = @CurIdCurriculaAnterior)
					SET @CodigoCurriculaNueva = (Select Codigo FROM Curricula WITH(NOLOCK) WHERE IdCurricula = @CurIdCurriculaNueva) 
					
					IF @pTipo = 'CI'      
					BEGIN          
						set @cTipo = 'TE'        
						set @ObservacionC = 'TRASLADO EXTERNO - DE IES A EEST'        
					END      
					IF @pTipo = 'TS'          
					BEGIN      
						set @cTipo = 'CI'        
						set @ObservacionC = 'CONVALIDACION INTERNA - TRASLADO SEDE'        
					END         
					--INICIO @7
					IF PATINDEX('%[ABCDEFGHIJKLMNOPQRSTUVWXYZ]%', @CodigoCurriculaAnterior) = 1 AND PATINDEX('%[ABCDEFGHIJKLMNOPQRSTUVWXYZ]%', @CodigoCurriculaNueva) = 0 AND @CompaniaSocio = '00002700'
					BEGIN
						SET @cTipo = 'AM'
						SET @ObservacionC = 'Actualizaci?n de Malla'
					END
					
					IF @cTipo = 'AM'
					BEGIN
						SET @Existe = dbo.cConvalidacion_Val_ExisteAM(@pIdEmpresa,  
						@pIdSede,  
						@CurIdAlumno,  
						@IdRegistroNuevo,  
						@CurIdCurriculaNueva,
						@pIdPeriodo) 
					END
					
					IF @cTipo = 'CI'
					BEGIN
						SET @Existe = dbo.cConvalidacion_Val_ExisteCI(@pIdEmpresa,          
							@pIdSede,          
							@CurIdAlumno,          
							@IdRegistroNuevo,          
							@CurIdCurriculaNueva,
							@pIdPeriodo)          
					END
					IF @cTipo = 'TE'
					BEGIN
						SET @Existe = dbo.cConvalidacion_Val_ExisteTE(@pIdEmpresa,          
							@pIdSede,          
							@CurIdAlumno,          
							@IdRegistroNuevo,          
							@CurIdCurriculaNueva,
							@pIdPeriodo)          
					END
					--FIN @7
					IF @Existe = 0          
					BEGIN                     
						-- aca tenemos que hacer la convalidacion interna por cada curso aprobado          
						set @anno = YEAR(getdate())          
						set @fecha = dbo.gFechaStr(GETDATE())            
                                      
						--EXEC cConvalidacion_Gen_Codigo @anno,@NumeroConv OUTPUT      
         
						--@9                               
						EXEC cEmpresaSedeParametro_Gen_Numero 'NUMEROCONVALIDAE',@NumeroConv OUTPUT            
             
 
					 --@9          
                                 
						EXEC cConvalidacion_Ins_Grabar @pIdEmpresa,          
						@pIdSede,          
						@CurIdAlumno,          
						@IdRegistroNuevo,          
						@CurIdCurriculaNueva,          
						@CurIdCurriculaAnterior,          
						@NumeroConv,          
						@pIdPeriodo,          
						@pIdUsuarioCreacion,          
						NULL,          
						@fecha,          
						@ObservacionC,          
						@cTipo,          
						'R',        
						@pIdUsuarioCreacion,          
						'',      
						'',      
						'', 
						null,--@6
						null,--@6      
						@IdConvalidacion OUTPUT          
						END            
					ELSE          
					BEGIN          
						SET @IdConvalidacion = @Existe          
					END                   
				END -- FIN DEL VAL =1         
                 
				--SELECT @PromFinal = null,@PromReal = null      
            
				---- sacamos el promedio anterior          
				--SELECT @PromFinal = isnull(PromedioFinal,13),        
				--@PromReal = isnull(PromedioReal,13)        
				--FROM AlumnoCurriculaCurso          
				--Where IdAlumno = @CurIdAlumno         
				--and IdRegistro = @IdRegistroAnterior          
				--and IdCurricula = @CurIdCurriculaAnterior          
				--and IdCurso = @CurIdCurso         
             
				--select 'llego'      
				if convert(decimal(5,2),@PromFinal) < 13      
				begin      
					If @CurIdCurriculaNueva in (27,28)      
					begin      
						set @PromFinal = ROUND(@PromFinal,0)      
						set @PromReal = ROUND(@PromReal,0)      
					end       
					else      
					begin      
						set @PromFinal = 13      
						set @PromReal = 13      
					end       
				end       
				else      
				begin      
					set @PromFinal = ROUND(@PromFinal,0)      
					set @PromReal = ROUND(@PromReal,0)      
				end
				--   select @PromFinal              
				-- ACTUALIZAMOS EL ALUMNOCURRICULACURSO          
				UPDATE AlumnoCurriculaCurso          
				SET IdConvalidacion = @IdConvalidacion,          
				TipoCondicion = 'CO',          
				PromedioFinal = @PromFinal,          
				PromedioReal = @PromReal,          
				PromedioCondicion = 'A' ,         
				Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioEscuela',--@1      
				UsuarioModificacion=@pIdUsuarioCreacion,--@1      
				FechaModificacion=GETDATE(),--@1          
				Subsanacion = 0  --@2       
				WHERE IdAlumno = @CurIdAlumno          
				AND IdRegistro = @IdRegistroNuevo          
				AND IdCurricula = @CurIdCurriculaNueva        
				AND IdCurso = @CurIdCurso          
			END  -- FIN CUMPLE        
                     
			-- borramos la temporal        
			DELETE N FROM @CurCursos N            
			WHERE N.Id =(SELECT TOP 1 Id             
			FROM @CurCursos             
			ORDER BY Id)              
		END -- while        
               
		--sacamos el maximo modulo de los cursos convalidados para marcarlos como subsabacion      
		update AlumnoCurriculaCurso      
		set subsanacion =1      
		where idalumno = @pIdAlumno      
		and idregistro = @IdRegistroNuevo      
		and idmodulo IN (select distinct idmodulo --@7      
		from AlumnoCurriculaCurso with(nolock)        
		where idalumno = @pIdAlumno      
		and idregistro = @IdRegistroNuevo      
		and TipoCondicion = 'CO')      
		and TipoCondicion = 'RE'      
	end           
	-- sacamos el nivel que le corresponderia llevar al alumno
	IF @EquivalenciaCertificado = 0--@5
	BEGIN
		--@14 INICIO
		--Se obtiene el a�o donde curso el 1 semestre de manera regular.  
		SELECT @AnioCursado = Isnull(Min(pe.idperiodoanual), 2022),
		       @IdModuloInicio = Isnull(Min(pr.idmodulo), 1)
		FROM   matricula M
		       INNER JOIN alumnocurricula AC
		               ON AC.idalumno = M.idactor AND AC.idcurricula = M.idcurricula
		       INNER JOIN curricula C
		               ON C.idcurricula = AC.idcurricula
		       INNER JOIN registro R
		               ON R.idactor = M.idactor AND C.idproducto = R.idproducto
		       INNER JOIN promocion PR
		               ON M.idpromocion = PR.idpromocion AND R.idproducto = PR.idproducto
		       INNER JOIN periodo PE
		               ON PR.idperiodo = PE.idperiodo
		WHERE
		  M.IdRegistro = @IdRegistroNuevo            
		  AND C.IdCurricula = @CurIdCurriculaNueva
		  AND M.idactor = @pIdAlumno
		  AND M.estado <> 'X'
		  ----print '@AnioCursado - @IdModuloInicio'
		  ----print @AnioCursado
		  ----print @IdModuloInicio
		  
			----print 'Nuevas variables'
			----print @vAnioCursado	  
			----print @vIdModuloInicio	  
			----print @vIdUnidadAcademica	  
			----print @vActivo	  
			----print @vCompaniaSocio

		IF @AnioCursado >=@vAnioCursado AND @IdModuloInicio>=@vIdModuloInicio AND @CompaniaSocio=@vCompaniaSocio and @vActivo = 1		  
		BEGIN

			--Inicio --@15
			SELECT @vIdMatricula = @IDMatricula

			SELECT @EsProcesado = (dbo.fxValidadorLogicaProgresionCurricular(@vNombreProceso,@vIdMatricula,@vIdProducto,@vIdPeriodo,@vIdModulo))

			IF @EsProcesado = 1
			BEGIN

				print 'cMatricula_ProgresionCurricular CambioEscuela'
				EXEC cMatricula_ProgresionCurricular @pIdAlumno,@IdRegistroNuevo,@CurIdCurriculaNueva, @wIdModulo OUT,@wTipo OUT ,@wIdModuloReal OUT,@wTipoCondicionNueva OUT

			END
			ELSE
			BEGIN
			--Fin --@15

				print 'cMatricula_CalculoSiguienteModulo'
				exec cMatricula_CalculoSiguienteModulo @pIdAlumno,@IdRegistroNuevo,@CurIdCurriculaNueva,@IDMatricula, 0, @wIdModulo OUT,@wTipo OUT --@6   

			--Inicio --@15
			END
			--Fin --@15

		END
		ELSE 
		BEGIN

			print 'cMatricula_CalculoSiguienteModulo'
			exec cMatricula_CalculoSiguienteModulo @pIdAlumno,@IdRegistroNuevo,@CurIdCurriculaNueva,@IDMatricula, 0, @wIdModulo OUT,@wTipo OUT --@6   

		END

	END     
	--@14 FIN

	-- VERIFICAMOS SI HAY LA PROMOCION REGISTRADA QUE LE CORRESPONDE AL ALUMNO              
	SELECT @wIdPromocion = IdPromocion      
	,@CodigoPromocion = ISNULL(PromocionCodigo,'')--@8             
	FROM Promocion  with(nolock)            
	WHERE IdEmpresa = @pIdEmpresa              
	AND IdSede = @pIdSede              
	AND IdPeriodo = @pIdPeriodo              
	--AND IdProducto =               
	AND IdCurricula = @CurIdCurriculaNueva              
	AND IdModulo = @wIdModulo              
	AND Estado = 'A'              
                 
	SET @wIdPromocion = ISNULL(@wIdPromocion,-1)              
	---              
                   
	-- si no hay promocion no se registra nada en matricula ni alumno curso               
	IF  @wIdPromocion <> -1              
	BEGIN              
		select @NumeroCuota = isnull(MAX(cuotanumero),0)       
		from CronogramaPago      
		where IdPromocion=@wIdPromocion       
        
		IF @NumeroCuota = 0      
		BEGIN              
			SELECT @pEstado = 'KO'              
			SELECT @pDescripcion = 'No se ha registrado cronograma de pagos de la promocion. '+@CodigoPromocion --@14      
			RETURN      
		END           
           
		-- debemos crear la matricula            
		-- generamos el numero de matricula            
		EXEC cMatricula_Gen_Numero @NumeroMatricula OUTPUT            
           
		-- sacamos la cantidad de cursos del producto        
		select @cCursosModulo = COUNT(1)        
		from CurriculaCurso        
		where IdCurricula = @CurIdCurriculaNueva        
		and IdModulo = @wIdModulo        
    
		-- sacamos la cantidad de cursos en los que se va a matricular        
		select @cCursosMat =  COUNT(1)         
		FROM AlumnoCurriculaCurso            
		WHERE IdAlumno = @pIdAlumno            
		and IdRegistro = @IdRegistroNuevo            
		and IdCurricula = @CurIdCurriculaNueva            
		and IdModulo <= @wIdModulo           
		and TipoCondicion = 'RE'           
		and isnull(PromedioCondicion,'D') = 'D';           
          
		IF @wTipo = 'RT'        
		BEGIN        
			IF @cCursosModulo = @cCursosMat        
			SET @TipoServicio = 'P'        
		ELSE        
			SET @TipoServicio = 'C'        
		END        
          
		IF @wTipo = 'RP'         
		BEGIN        
			SET @TipoServicio = 'M'        
		END        
           
		IF  @wTipo = 'RE'        
		BEGIN        
			SET @TipoServicio = 'P'        
		END      
         
		IF  @wTipo = 'CC' --@6      
		BEGIN        
			SET @TipoServicio = 'C'        
		END        
         
			--verificamos si tiene o no descuento corporativo      
		if dbo.cActor_Val_ExisteClubIntercorp(@CurNumeroIdentidad) = 1      
		begin      
			SELECT @IdUnidadAcademica = P.IdUnidadAcademica      
			FROM  Matricula M   WITH (NOLOCK)          
			INNER JOIN Promocion P   WITH (NOLOCK)        
			ON M.IdPromocion = P.IdPromocion          
			WHERE IdMatricula = @IDMatricula        
         
			--insertar promocion beca de tipo I      
			EXEC cPromocionBeca_Ins_Grabar @pIdAlumno,@pIdUsuarioCreacion,@IdUnidadAcademica,'I'          
		end      
            
		EXEC cMatricula_Ins_Grabar_CargaHabil @pIdEmpresa,@pIdSede,-1 ,@pIdAlumno,@IdRegistroNuevo,@CurIdCurriculaNueva,        
		@wIdModulo,@wIdPromocion,-1,-1,-1,@NumeroMatricula,@pIdUsuarioCreacion,-1,        
		1,null,-1,0,0,0,@Descuento,-1,-1,-1,-1,-1,-1,-1,-1,236,NULL,'I',@wTipo,@TipoServicio,        
		@pTipo,@pTipo,'N',@pIdUsuarioCreacion,'Q',@pIdPeriodo,'',@NumeroCuota,@IdPrecioSede,@wIdModuloReal,@wTipoCondicionNueva,@IdMatriculaNew OUTPUT    --  @8 --@14
                    
		IF @wTipo= 'RT' and @pIdSede in (1,7) and @IdSedeAnterior not in (1,7)      
		begin      
			select @wTipo= 'TR'         
		end      
        
		EXEC dbo.cAlumnoCurso_Ins_DetalleCargaHabil @IdMatriculaNew,        
													@wIdPromocion,        
													@CurIdCurriculaNueva,        
													@wIdModulo,        
													@pIdAlumno,        
													@IdRegistroNuevo,        
													@wTipo,        
													@pIdUsuarioCreacion             
		--@4 Inicio PedroBarreto(Sigcomt)      
		EXEC cAlumnoCurriculaCursoOficial_Ins_Grabar @pIdAlumno, @IdRegistroNuevo, @CurIdCurriculaNueva, @wTipo      
		--EXEC cConvalidacionNotasOficial @pIdAlumno, @CurIdCurriculaNueva      
		--@4 Fin PedroBarreto(Sigcomt)       
                  
		-- registramos matricula pagante individual                
		exec cMatriculaPagante_Ins_Grabar @IdMatriculaNew,@pIdAlumno,'N',236,0,0,null,1,'R',@pIdUsuarioCreacion                
                    
		-- registramos actor facturacion individual                  
		exec cActorFacturacion_Ins_Grabar @IdMatriculaNew,@pIdAlumno,2,@CurNumeroIdentidad,            
				@NombreCompleto,@Direccion,-1,@Telefonos,0,0,0,@pIdUsuarioCreacion            
         
		IF ((@TipoServicio='P' OR  @TipoServicio='M') ) --y el alumno no Tiene deuda | AND  @MontoTotal=0        
		--actualizar campos tipopromocionbeca y grupodescuento de la tabla matricula      
		exec cMatricula_Upd_PromocionBecaMayorDescuento @IdMatriculaNew                      
		--exec cInterfaseDocumento_Ins_Grabar_Montos @IdMatriculaNew, @Res OUTPUT                
                       
		--IF @Res > 0 -- ERROR AL INSERTAR EN COINTERFASEDOCUMENTO                
		-- BEGIN                
		--   SELECT @pEstado = 'KO'                
		--   SELECT @pDescripcion = dbo.cCointerfaseDocumento_Sel_Error(@Res)             
		--   RETURN            
		-- END                
		--ELSE                
		BEGIN                
			SELECT @pEstado = 'OK'                
			SELECT @pDescripcion = 'Se gener? correctamente la carga h?bil.'                
			RETURN            
		END               
	END            
	ELSE            
	BEGIN            
		SELECT @pEstado = 'KO'                
		SELECT @pDescripcion = 'No se ha generado la promoci?n para el m?dulo '+ cast(@wIdModulo AS varchar(5)) +' de la curricula ' + cast(@CurIdCurriculaNueva AS varchar(5))          RETURN          
	END -- if promocion <> -1          
           
END -- fin procedimiento
