--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=675122


--SELECT TipoCondicion,*FROM AlumnoCurso 
--where IdMatricula=675122 AND EsMatricula=1

----RP(PROMOVIDO + CURSO)
----CC(CURSO REPITENCIA)
----RT(REPITENCIA)
----RE(PROMOVIDO)
