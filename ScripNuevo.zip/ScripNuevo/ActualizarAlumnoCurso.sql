--SELECT*FROM AlumnoCurso WHERE IdMatricula=634308

UPDATE AlumnoCurso SET NumVezCurso=1
WHERE IdMatricula=634308 AND TipoCondicion='RE'