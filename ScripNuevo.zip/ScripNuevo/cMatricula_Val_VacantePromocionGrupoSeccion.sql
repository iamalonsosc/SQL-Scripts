--Text
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--����������������������������������������������������������������������������  
/*  
-----------------------------------------------------------------------------  
Nro		FECHA			USUARIO				DESCRIPCION  
-----------------------------------------------------------------------------  
@1		27.01.2020		PUchuya				Se agrega validaci�n para cursos libres  
@2		2020.04.24		jmota				cambio provicional por error en cursos equivalentes, solo zegel  
@3		07.07.2020		PUchuya				Se quita y comenta validacion para cursos libres  
@4		19.01.2023		Ealva				Se agrega corrige error de Estado<>'No a Estado='NO'  
@5		25.01.2023		Ealva				Se comenta el store por pedido de gerencia para no validar aforo.     
											Cuando se matriculan en la sede origen tiene que validar en promoci�ngrupo VACANTES y cuando   
											se migra a la sede virtual debe realizar lo siguiente:   
											Solo se debe validar aforo de la tabla secci�n cuando el curso es presencial  
											cuando el curso es virtual no debe validar aforo  
											NUNCA SE DEBE VALIDA EL AFORO CON LA TABLA AMBIENTE SINO CONTRA LA TABLA SECCION.VACANTES  
@6		26.07.2023		EHuillca			Se descomenta lo realizado en la bit�cora @5  
@7		11.09.2025		mquiroz				se cambia la validacion de seccion por Promocion Grupo
@8		26/09/2025		JQuenta				Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil
*/   

--CREATE FUNCTION [dbo].[cMatricula_Val_VacantePromocionGrupoSeccion]   
--(  
declare
	@IdPromocion INT=101874,
	@IdGrupo INT=5,
	@IdSeccion INT=672645,
	@IdCurso INT=13743
--)
--RETURNS BIT
--AS
BEGIN

	--Inicio --@8
	DECLARE
	@Vacantes INT,
	@Inscritos INT,
	@VALOR BIT,
	@TipoServicio CHAR(1) --@1 --@3  
  
	SELECT
		@IdPromocion = IdPromocion
	FROM Seccion WITH (NOLOCK)
	WHERE idseccion = @IdSeccion --@2

	SELECT
		@Tiposervicio = Tiposervicio
	FROM Promocion WITH (NOLOCK) --@8
	WHERE IdPromocion = @IdPromocion --@1 --@3  
  
	SET @Vacantes =
	(
		SELECT
			Vacantes   
		FROM PromocionGrupo WITH (NOLOCK)
		WHERE IdPromocion = @IdPromocion  
		AND IdGrupo = @IdGrupo --@3  
	)  
  select @Vacantes
	SET @Inscritos =
	(
		SELECT
			COUNT(IdMatricula)   
		FROM AlumnoCurso WITH (NOLOCK)
		WHERE IdPromocion = @IdPromocion  
		AND IdSeccion = @IdSeccion  
		AND IdGrupo = @IdGrupo --@3  
		AND IdCurso = @IdCurso   
		AND Estado = 'NO' --@4  
		AND EsMatricula = 1  
		AND TipoCondicion IN ('RE')
	)  
   select @Inscritos
	IF @Inscritos <= @Vacantes  
	BEGIN

		SET @VALOR = 1

	END  
	ELSE  
	BEGIN

		SET @VALOR = 0

	END

	--RETURN @VALOR
	--Fin --@8

END


--Hora de finalizaci�n: 2026-08-25T18:23:38.3759057-05:00
