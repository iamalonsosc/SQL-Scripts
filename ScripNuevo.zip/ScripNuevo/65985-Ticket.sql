 SELECT*
    FROM   alumnocurriculacurso WITH(nolock)
    WHERE  --promediocondicion IS NOT NULL
           Isnull(escursoadelanto, 0) <> 1 -- 1 es curso adelanto.   
          AND idregistro = 3 --@6       
           AND idcurricula = 5688
           AND idalumno = 1574556
		   ORDER BY  IdModulo DESC 



--SELECT*
--FROM   alumnocurriculacurso WITH(nolock)
--WHERE  promediocondicion IS NOT NULL
--AND Isnull(escursoadelanto, 0) <> 1 -- 1 es curso adelanto.   
---- AND idregistro = 3 --@6       
----AND idcurricula = @pIdCurricula
--AND idalumno = 1718078
--ORDER BY  IdModulo DESC 


--		   SELECT*FROM alumnocurriculacurso
--		   WHERE idalumno = 1574556 AND promediocondicion IS NOT NULL
--		   ORDER BY  IdModulo DESC 