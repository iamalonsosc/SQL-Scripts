--SELECT TipoCondicion,*FROM Matricula 
----UPDATE Matricula SET TipoCondicion='RP'
--where IdMatricula=712661


--SELECT TipoCondicion,*FROM AlumnoCurso 
UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=712661 AND EsMatricula=1 

------RP(PROMOVIDO + CURSO)
------CC(CURSO REPITENCIA)
------RT(REPITENCIA)
------RE(PROMOVIDO)
--SELECT*FROM AlumnoCursoNomina WHERE IdMatricula=717777