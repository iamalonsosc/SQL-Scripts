 DECLARE @AlumnoCursoNomina AS TABLE (
	Id INT IDENTITY(1,1),
	Sede VARCHAR(200),
	NombreAlumno VARCHAR(200),
	Documento VARCHAR(100),
	Producto VARCHAR(200),
	Periodo VARCHAR(100),
	SeccionNomina VARCHAR(200),
	Turno VARCHAR(200),
	Observaciones VARCHAR(MAX)
 )

 DECLARE @Cursos AS TABLE (
	Id INT IDENTITY(1,1),
	IdCurricula INT,
	IdModulo INT,
	IdCurso  INT,
	CursoNombre VARCHAR(200)
 )
 
 
 ----CASO A
 --select *from  actaconsolidada where NombreAlumno='HURTADO OCHOA YASMIRA LIZBETH' and IdMatricula=530455 and IdPromocion=94056
 --EJEMPLO ('PIURA','BARCO BARRIENTOS KARLA GUADALUPE','74832253','Adm. Empresas','2023-IIIE','208.II.03.2023-IIIE-II-D','Diurno')
 --=CONCATENAR("('";E4;"','";C4;"','";B4;"','";D4;"','";"2024-I";"','";F4;"','";G4;"'),")
 INSERT INTO @AlumnoCursoNomina (Sede,NombreAlumno,Documento,Producto,Periodo,SeccionNomina,Turno) VALUES
 --('SJL','DUQUE MENDOZA ANGELES BRIGITH','76444626','Adm. Empresas','2024-I','208.IV.04.2024-I-IV-B','Nocturno'),
--('WILSON','HINOSTROZA LIMA POOL ARAMIS','72670566','ELECTRONICA INDUSTRIAL','2024-I','220.II.04.2024-I-II-C','Nocturno'),
('PT','LAVADO ADULFO JASSELY KARINA','74739098','Adm.Negoc.Bancarios y Financieros','2024-I','211.V.04.2024-I-V-B','Nocturno')

 --Cursos agregados: PENSAMIENTO CREATIVO PARA LA INNOVACI�N,BRANDING,COSTOS Y PRODUCCI�N GR�FICA,DISE�O Y PROGRAMACI�N WEB,
 --select * from @AlumnoCursoNomina 
 --RETURN

 DECLARE @Sede VARCHAR(200),
		@SedeDireccion VARCHAR(200),
		@Region VARCHAR(200),
		@Departamento VARCHAR(200),
		@Provincia VARCHAR(200),
		@Distrito VARCHAR(200),
		@NombreAlumno VARCHAR(200),
		@Documento VARCHAR(100),
		@Producto VARCHAR(200),
		@Periodo VARCHAR(100),
		@SeccionNomina VARCHAR(200),
		@Turno VARCHAR(200),
		@Observaciones VARCHAR(200),
		@Promedio VARCHAR(10),
		@idEmpresa int,
		@nformativo VARCHAR(50),      
		@codigoModular VARCHAR(50),      
		@NotaDefault CHAR(4),      
		@Id INT,      
		@IdAlumno INT,      
		@IdRegistro INT,      
		@IdCurricula INT,      
		@IdModulo INT,      
		@NroRD varchar(100),      
		@FechaAutori varchar(100),    
		@FechaReva varchar(100),  
		--Para el reporte de Registro de Matricula  
		@NombreIES varchar(200),--Valor 6 Paramentro nomina 1  --@13  
		@Direccion2 varchar (500), --Valor8 Paramentro nomina 1 --@13  
		@TipoGestion varchar(200),--Valor 6 Paramentro nomina 2 --@13  
		@TipoSede varchar (500), --Valor8 Paramentro nomina 2 --@13  
		@NombreDirectorGeneral varchar (1000),    --Valor Paramentro nomina 1 --@13  
		@NombreSecretarioAcademico varchar (1000), --Valor7 Paramentro nomina 1 --@13  
		@DREGRE varchar (1000) --Valor7 Paramentro nomina 2 --@13   

 DECLARE @min INT, @max INT, @min1 INT, @max1 INT, @IdSede INT, @IdPeriodo INT, @IdPromocion INT, @IdGrupo INT, 
		 --@Documento VARCHAR(100), @SeccionNomina VARCHAR(200), @Turno VARCHAR(200), @Periodo VARCHAR(200), 
		 @IdProducto INT, @IdMatricula INT, @IdPromocionAC INT, @IdGrupoAC INT, @IdModuloAdd INT,
		 @IdCurso INT, @CursoNombre VARCHAR(200)

 SET @idEmpresa = 1
 SELECT @min = MIN(ID), @max = MAX(ID) FROM @AlumnoCursoNomina 

 WHILE @min <= @max
 BEGIN	
	--PRINT CONCAT('ALUMNO-',@MIN)
	SET @Sede = NULL
	SET @SedeDireccion = NULL
	SET @Region = NULL
	SET @Departamento = NULL
	SET @Provincia = NULL
	SET @Distrito = NULL
	SET @NombreAlumno = NULL 
	SET @Documento = NULL 
	SET @Producto = NULL 
	SET @Periodo = NULL 
	SET @SeccionNomina = NULL
	SET @Turno = NULL 

	SET @IdSede = NULL 
	SET @IdPeriodo = NULL 
	SET @IdProducto = NULL 
	SET @IdMatricula = NULL 
	SET @IdModulo = NULL 
	SET @IdAlumno = NULL 
	SET @IdPromocion = NULL
	SET @IdGrupo = NULL
	SET @IdPromocionAC = NULL
	SET @IdGrupoAC = NULL
	SET @IdCurricula = NULL
	SET @Observaciones = NULL
	SET @IdModuloAdd = NULL 
	SET @Promedio = NULL

	SET @nformativo = NULL  
	SET @codigoModular = NULL     
	SET @NotaDefault = NULL        
	SET @Id = NULL           
	SET @IdRegistro = NULL      
	SET @NroRD = NULL
	SET @FechaAutori = NULL    
	SET @FechaReva = NULL  
	--Para el reporte de Registro de Matricula  
	SET @NombreIES = NULL--Valor 6 Paramentro nomina 1  --@13  
	SET @Direccion2 = NULL --Valor8 Paramentro nomina 1 --@13  
	SET @TipoGestion = NULL--Valor 6 Paramentro nomina 2 --@13  
	SET @TipoSede = NULL --Valor8 Paramentro nomina 2 --@13  
	SET @NombreDirectorGeneral = NULL    --Valor Paramentro nomina 1 --@13  
	SET @NombreSecretarioAcademico = NULL --Valor7 Paramentro nomina 1 --@13  
	SET @DREGRE = NULL --Valor7 Paramentro nomina 2 --@13   
	
	SELECT @Sede = Sede ,	@NombreAlumno = NombreAlumno, @Documento = Documento, @Producto = Producto,	@Periodo = Periodo,	@SeccionNomina = SeccionNomina,	@Turno = upper(Turno)
	FROM @AlumnoCursoNomina WHERE Id = @min

	SELECT @IdSede = S.IdSede,@SedeDireccion = S.Direccion, @Region = S.DireccionRegional, @Departamento = UU.Nombre, @Provincia = U.Nombre, @Distrito = D.Nombre, 
		   @IdPeriodo = PE.IdPeriodo, @IdProducto = P.IdProducto , @IdMatricula = M.IdMatricula, @IdModulo = M.IdModulo,
		   @IdAlumno = A.IdActor, @IdPromocion = M.IdPromocion, @IdGrupo = M.IdGrupo, @IdPromocionAC = AC.IdPromocion, @IdGrupoAC = AC.IdGrupo, 
		   @IdCurricula = M.IdCurricula, @Promedio = AC.PromedioFinal
	FROM Matricula M 
	INNER JOIN Actor A ON M.IdActor = A.IdActor 
	INNER JOIN Sede S ON M.IdSede = S.IdSede
	INNER JOIN Promocion P ON M.IdPromocion = P.IdPromocion
	INNER JOIN Periodo PE ON P.IdPeriodo = PE.IdPeriodo 
	INNER JOIN Producto PR ON P.IdProducto = PR.IdProducto
	LEFT JOIN AlumnoCurso AC ON M.IdActor = AC.IdAlumno AND M.IdCurricula = AC.IdCurricula 
	INNER JOIN Ubigeo D WITH (NOLOCK) ON S.IdUbigeo=D.IdUbigeo              
			INNER JOIN Ubigeo U WITH (NOLOCK) ON U.IdPais=D.IdPais AND U.IdUbigeo=D.IdDepartamento+D.IdProvincia+'00'         
			INNER JOIN Ubigeo UU WITH (NOLOCK) ON D.IdDepartamento=UU.IdDepartamento          
			AND UU.IdProvincia='00'          
			AND UU.IdDistrito='00' 
	WHERE (A.NombreCompleto = @NombreAlumno OR A.NumeroIdentidad = @Documento) AND PE.Codigo = @Periodo 
		  AND M.EsMatricula=1 AND M.Estado <>'X'
		  
	SELECT @nformativo=ISNULL(ESP.Valor4,''),              
		@codigoModular=ISNULL(ESP.Valor5,''),    
		@FechaAutori= ISNULL(ESP.Valor3,''),  
		@NombreIES = ISNULL(ESP.Valor6,''),         --@13  
		@Direccion2 =  ISNULL(ESP.Valor8,''),       --@13         
		@NombreDirectorGeneral =  ISNULL(ESP.Valor,''),       --@13  
		@NombreSecretarioAcademico =  ISNULL(ESP.Valor7,'')       --@13  
		FROM ParametroUnidadAcademica ESP WITH (NOLOCK)                
		WHERE ESP.IdEmpresa=@IdEmpresa              
		AND ESP.IdSede=@IdSede              
		AND ESP.Nombre='ParametroNomina1'        
		AND (ESP.IdProducto = @IdProducto OR @IdProducto = 0)        
      
		SELECT @FechaReva= ISNULL(ESP.Valor3,''),  
		@TipoGestion = ISNULL(ESP.Valor6,''),      --@13  
		@DREGRE = ISNULL(ESP.Valor7,''),      --@13  
		@TipoSede =  ISNULL(ESP.Valor8,'')   --@13             
		FROM ParametroUnidadAcademica ESP WITH (NOLOCK)                
		WHERE ESP.IdEmpresa=@IdEmpresa              
		AND ESP.IdSede=@IdSede              
		AND ESP.Nombre='ParametroNomina2'        
		AND (ESP.IdProducto = @IdProducto OR @IdProducto = 0)    

	--SELECT * FROM Periodo WHERE Codigo = '2023-IIE'
	--SELECT @IdSede 'SEDE', @IdPeriodo  'IdPeriodo', @IdProducto 'IdProducto' , @IdMatricula 'IdMatriculaI', @IdModulo 'IdModulo',
	--	   @IdAlumno 'IdActor', @IdPromocion 'IdPromocion', @IdPromocionAC 'IdPromocionAC', @IdGrupoAC 'IdGrupoAC', @IdCurricula 'IdCurricula',
	--	   @SeccionNomina 'SeccionNomina', @Turno 'Turno'  
	--RETURN 

	INSERT INTO @Cursos
	SELECT CC.IdCurricula, CC.IdModulo, CC.IdCurso, C.CursoNombre FROM CurriculaCurso CC
	INNER JOIN Curso C ON CC.IdCurso = C.IdCurso
	WHERE IdCurricula = @IdCurricula AND IdModulo = @IdModulo
	
	--SELECT * FROM @Cursos
	--RETURN 

	SELECT @min1 = MIN(ID), @max1 = MAX(ID) FROM @Cursos

	WHILE @min1 <= @max1
	BEGIN
		--PRINT CONCAT ('AL:',@min,' - curso:',@MIN1)

		SET @IdCurso = NULL
		SET @CursoNombre = NULL

		SELECT @IdCurso = IdCurso, @CursoNombre = CursoNombre FROM @Cursos WHERE Id = @min1
		SELECT @IdModuloAdd=IdModulo FROM CurriculaCurso WHERE IdCurricula=@IdCurricula AND IdCurso=@IdCurso

		IF NOT EXISTS (SELECT DISTINCT 1 FROM AlumnoCursoNomina WHERE IdSede = @IdSede AND IdPeriodo = @IdPeriodo AND IdProducto = @IdProducto
											  AND IdMatricula = @IdMatricula  AND IdActor = @IdAlumno 
											  AND IdCurricula = @IdCurricula AND IdCurso = @IdCurso AND IdModulo = @IdModuloAdd)--
		BEGIN 
			PRINT CONCAT('ACN',@MIN1)
			

			INSERT INTO AlumnoCursoNomina 
			VALUES (1, @IdSede, @IdPeriodo, @IdProducto, @IdMatricula, @IdModuloAdd, @IdAlumno, @IdCurso, @IdPromocion, @IdGrupo, @IdPromocionAC, @IdGrupoAC, @IdCurricula, 
					@SeccionNomina, @Turno, GETDATE(), 1)
			
			SET @Observaciones = CONCAT(ISNULL(@Observaciones,'ACN: '), @CursoNombre,',')

		END

		IF NOT EXISTS (SELECT DISTINCT 1 FROM Actaconsolidada WHERE IdCurricula = @IdCurricula AND IdMatricula = @IdMatricula AND idalumno = @IdAlumno AND IdSede = @IdSede 
																	AND IdPeriodo = @IdPeriodo AND IdProducto = @IdProducto AND IdCurso = @IdCurso)
		BEGIN  
      
			PRINT CONCAT('ACTA CONSOLIDADA',@MIN1)
			
			INSERT INTO ActaConsolidada       
			(EsNuevo,ProductoCodigo,ProductoNombre,IdPromocion,PromocionCodigo,IdGrupo,GrupoCodigo,TurnoCodigo,TurnoNombre,IdCurricula,IdCurso,                
			CursoCodigo,CursoNombreOficial,CursoCredito,IdTipo,CursoTipo,IdModulo,ModuloNombre,CodigoFacilitador,NombreFacilitador,Seccion,IdMatricula,               
			IdAlumno,UltimaMatricula,CodigoAlumno,NombreAlumno,Sexo,DNI,CondicionPago,PromedioCondicion,CursosAprobados,CursosDesaprobados,EstadoPromovido,      
			EstadoMatricula,EstadoCurso,PromedioCurso,PromedioPonderado,FechaInicio,FechaFin,Nombre,PeriodoCodigoT,Orden,TipoCondicion,NumeroRD,      
			IdRegistro,EFormativa,SeccionCodigo,PeriodoCodigo,Direccion,Region,Departamento,Provincia,Distrito,NFormativo,      
			FechaFinPeriodo,PeriodoNombre,IdProducto,IdEmpresa,IdSede,IdFacultad,IdUnidadAcademica,IdUnidadNegocio,IdPeriodo,CModular,
			FechaAutoriza,FechaReva,NombreIES,Direccion2,TipoGestion,TipoSede,NombreDirectorGeneral,NombreSecretarioAcademico,DREGRE) 
			--select * from ActaConsolidada WHERE Seccion='209.VI.01.2023-IIIE-VI-B'
			--select * from AlumnoCursoNomina WHERE SeccionNomina='209.VI.01.2023-IIIE-VI-B'
			----- buscar notas acta consolidada
			SELECT DISTINCT p.EsNuevo, p.productocodigo, p.ProductoNombre,1,'',@IdGrupo,'',@Turno,@Turno,@IdCurricula,
			@IdCurso,C.CursoCodigo,CONCAT(C.CursoCodigo,'-',REPLACE(C.CursoNombreOficial,'-',' '),'-',MTR.NOMBRE,'-',ISNULL(CC.Orden,0)),
			ISNULL(CC.CursoCredito,0),CC.IdTipo,MTR3.NOMBRE /*cursotipo */, @IdModuloAdd, ISNULL(MTR2.Codigo,'') /*modulonombre*/, NULL,NULL,
			@SeccionNomina,@IdMatricula,@IdAlumno,'',AL.CodigoAnterior,A.NombreCompleto,      
			CASE WHEN ISNULL(A.Genero,1) = 1 THEN 'M' ELSE 'F' END /*SEXO*/, A.NumeroIdentidad, CASE WHEN M.IdBeca IS NULL THEN 'P' ELSE 'G' END ,
			ISNULL(ACC.PromedioCondicion,'D'),0,0,
			CASE WHEN M.Estado='R' THEN 'RETIRADO ' ELSE 'PROMOVIDO' END ,	--EstadoPromovido      
			CASE WHEN M.Estado='R' THEN 'RETIRADO' WHEN M.Estado='X' THEN 'ANULADO' WHEN M.Estado='B' THEN 'NORMAL' WHEN M.Estado='N' THEN 'NORMAL' END ,  --EstadoMatricula          
			CASE WHEN AC.Estado='NO' THEN 'NORMAL' WHEN AC.Estado='RA' THEN 'RETIRO CURSO' WHEN AC.Estado='RC' THEN 'RETIRO CICLO' ELSE 'NORMAL' END,	--EstadoCurso
			CONVERT(varchar(200), CASE WHEN M.TipoCondicion != 'RT' OR CO.Tipo = 'AM' THEN --PromedioCurso
							CASE WHEN ACC.TipoCondicion='CO'/*@7*/ THEN ISNULL(ACC.PromedioFinal,'---')             
							ELSE       
								CASE WHEN AC.Estado='RA' THEN 'DPI'             
								ELSE ISNULL(AC.PromedioFinal,'---')
								END             
							END              
							ELSE ISNULL(AC.PromedioFinal,'---')     
						END), --PromedioCurso
			CAST(0 AS NUMERIC(5,2))/*PromedioPonderado de PGC*/,CONVERT(varchar,PE.Inicio,103),CONVERT(varchar,PE.FIN,103),pe.Nombre,@Periodo,cc.Orden,M.TipoCondicion,SPACE(100),      
			m.IdRegistro,'',REPLACE(REPLACE(@SeccionNomina,'.',''),'-',''),pe.Codigo,@SedeDireccion,@Region,@Departamento,@Provincia,@Distrito,@nformativo,
			CONVERT(varchar,PE.FIN,103),PE.Nombre,ACN.IdProducto,@idEmpresa,@IdSede,PR.IdFacultad,PR.IdUnidadAcademica,PR.IdUnidadNegocio,acn.IdPeriodo,@codigoModular,
			@FechaAutori,@FechaReva,@NombreIES,@Direccion2,@TipoGestion,@TipoSede,@NombreDirectorGeneral,@NombreSecretarioAcademico,@DREGRE		
			FROM AlumnoCursoNomina ACN
			INNER JOIN matricula M ON ACN.IDMATRICULA=M.IDMATRICULA
			INNER JOIN Actor a on a.IdActor=ACN.IdActor
			INNER JOIN Alumno AL ON ACN.IdActor=AL.IdAlumno
			INNER JOIN alumnocurriculacurso ACC ON ACN.IDACTOR = ACC.IDALUMNO AND ACN.IDCURRICULA = ACC.IDCURRICULA AND ACN.IDCURSO = ACC.IDCURSO
			LEFT JOIN  AlumnoCurso AC ON ACN.IdCurso=ISNULL(AC.IdCursoOriginal,AC.IdCurso) AND ACn.IdMatricula=ac.IdMatricula --@14         
			INNER JOIN Producto P ON ACN.IdProducto=P.IdProducto
			INNER JOIN Promocion PR ON ACN.IdPromocion=PR.IdPromocion
			INNER JOIN PERIODO PE ON PR.IDPERIODO = PE.IDPERIODO
			INNER JOIN PromocionGrupo Pg ON ACN.IdPromocion=Pg.IdPromocion and ACN.IdGrupo=PG.IdGrupo
			INNER JOIN Curso C ON ACN.IdCurso = C.IdCurso
			INNER JOIN MAESTROTABLAREGISTRO MTR ON C.IDTIPOCURSO = MTR.IDMAESTROREGISTRO AND MTR.IDMAESTROTABLA=1015
			INNER JOIN CurriculaCurso CC ON ACN.IdCurricula=CC.IdCurricula AND ACN.IdCurso=CC.IdCurso
			LEFT  JOIN CurriculaModulo CM ON ACN.IdModulo=CM.IdModulo AND ACN.IdCurricula=CM.IdCurricula           
			INNER JOIN MAESTROTABLAREGISTRO MTR2 ON CM.IdTipoModulo = MTR2.IdMaestroRegistro 
			INNER JOIN MAESTROTABLAREGISTRO MTR3 ON CC.IdTipo = MTR3.IdMaestroRegistro 
			LEFT JOIN Convalidacion CO ON ACC.IdConvalidacion = CO.IdConvalidacion 
			WHERE ACN.SeccionNomina = @SeccionNomina AND
				  a.NombreCompleto in (@NombreAlumno) AND ACN.IdCurricula = @IdCurricula AND ACN.IdMatricula = @IdMatricula AND ACN.IdActor = @IdAlumno AND 
				  ACN.IdSede = @IdSede AND ACN.IdPeriodo = @IdPeriodo AND ACN.IdProducto = @IdProducto AND ACN.IdCurso = @IdCurso

			SET @Observaciones = CONCAT(ISNULL(@Observaciones,'ACTA: '), @CursoNombre,',')

		END
		UPDATE @AlumnoCursoNomina SET Observaciones = ISNULL(@Observaciones,'No se agregaron Cursos a la nomima actual') WHERE Id = @min

		SET @min1 = @min1 + 1
	END
	
	DELETE FROM @Cursos 

	SET @min = @min + 1

 END

 SELECT * FROM @AlumnoCursoNomina
