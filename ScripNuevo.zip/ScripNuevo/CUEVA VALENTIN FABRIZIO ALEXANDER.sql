--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=670353


--SELECT TipoCondicion,*FROM AlumnoCurso 
----UPDATE Matricula SET TipoCondicion='CC'
--where IdMatricula=670353 AND EsMatricula=1

----RP(PROMOVIDO + CURSO)
----CC(CURSO REPITENCIA)
----RT(REPITENCIA)
----RE(PROMOVIDO)
