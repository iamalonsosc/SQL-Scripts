USE AcademicoIDAT;

GO

-- ############### PARTE 01 - 3 ##################


  UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 688337
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'FUNDAMENTOS DE PROGRAMACIÓN';
UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 688337
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO WEB';
UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 688337
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SOPORTE DE TI';
UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 688337
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LECTURA COMPRENSIVA Y ESCRITURA';
UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 688337
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTRAPERSONALES';
UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 688337
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'FUNDAMENTOS LÓGICO-MATEMÁTICOS PARA EL DESARROLLO DE SISTEMAS';
UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 688337
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'HERRAMIENTAS OFIMÁTICAS PARA LA INVESTIGACIÓN';
