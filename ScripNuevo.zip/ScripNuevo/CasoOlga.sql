
UPDATE Matricula SET TipoCondicion='RP'
WHERE IdMatricula=649944
--(1 row affected)

UPDATE AlumnoCurriculaCurso SET Subsanacion=1,promediocondicion=null
WHERE IdAlumno=886647
AND IdRegistro=11
AND IdCurricula=5691
AND IdCurso=14368
--(1 row affected)