
--ARAOZ FLORES STEVEN GERALD

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET PromedioFinal='DPI',PromedioReal='DPI',PromedioCondicion='D',estado='NO'
WHERE  IdCurso=10213 AND IdAlumno=1703844 AND IdMatricula=707919 


UPDATE AlumnoCurriculaCurso SET PromedioFinal='00.00',PromedioReal='00.00',PromedioCondicion='D',IdAlumnoCurso=22
WHERE IdAlumno=1703844 AND IdRegistro=1 AND IdCurso=10213