CREATE PROCEDURE [dbo].[cAlumnoCurso_Pro_CargaHabil_CambioEscuela]
@pIdEmpresa INT,
@pIdSede INT,
@pIdPeriodo INT,
@pIdAlumno INT,
@pIdUsuarioCreacion INT,
@pTipo VARCHAR(2),  
@IdPrecioSede INT, --@8
@pEstado VARCHAR(2) OUTPUT,
@pDescripcion VARCHAR(1000) OUTPUT
AS
BEGIN

	--Inicio --@23
	SET NOCOUNT ON

	--Declaracion de variables
	DECLARE
	@CurIdAlumno INT, 
	@CurIdProductoAnterior INT,
	@CurIdProductoNueva INT,
	@CurIdCurriculaAnterior INT,
	@CurIdCurriculaNueva INT,
	@IdRegistroAnterior INT,
	@IdRegistroNuevo INT,
	@CurIdCurso INT,
	@Cumple INT,
	@TipoAprobacion VARCHAR(2),
	@Val INT,
	@NumeroConv VARCHAR(10),
	@IdConvalidacion INT,
	@PromReal VARCHAR(10),
	@PromFinal VARCHAR(10),
	@IdMatriculaNew INT,
	@wIdPromocion INT,
	@CodigoPromocion VARCHAR(20), 
	@wIdModulo INT,
	@Res INT, 
	@wNumVezCurso INT,
	@NumeroMatricula VARCHAR(50),
	@CurNumeroIdentidad VARCHAR(50),  
	@Direccion VARCHAR(100),
	@NombreCompleto VARCHAR(100),
	@Telefonos VARCHAR(50), 
	@anioconva INT,
	@fecha VARCHAR(10),
	@Existe INT,
	@wTipo VARCHAR(2),
	@ValAlumnoMatriculado INT,
	@EliCargaHabil INT,
	@wIdModuloCurso INT,  
	@cCursosModulo INT,  
	@cCursosMat INT,  
	@TipoServicio VARCHAR(1),  
	@Tipo VARCHAR(2),  
	@Deudas INT,
	@IdSedeAnterior INT,
	@IdDocumentoTipo INT,
	@Ubigeo VARCHAR(10), 
	@NumeroCuota INT,
	@Descuento INT = NULL,
	@IdUnidadAcademica INT,
	@FinPeriodo DATE,
	@ano INT,
	@Verifica BIT,
	@CompaniaSocio CHAR(8),
	@cTipo VARCHAR(2),
	@ObservacionC VARCHAR(500),  
	@Observacion VARCHAR(1000),   
	@pContador INT,  
	@Egresado BIT,
	@Reingreso BIT,
	@Regular BIT,
	@CurIdTipo INT,
	@EquivalenciaCertificado INT = 0,
	@CodigoCurriculaAnterior VARCHAR(20),
	@CodigoCurriculaNueva VARCHAR(20),
	@CompaniaSocioPadre char(8),
	@AnioCursado INT, --@14 A�o donde curso el 1 semestre de manera regular.  
	@IdModuloInicio INT, --@14 Modulo de Inicio para el alumno  
	@wIdModuloReal INT, --@14 Valores de retorno Modulo real del alumno
	@wTipoCondicionNueva CHAR(2), --@14 Valores de retorno Tipo condicion Regular o irregular
	@vAnioCursado INT, --@14
	@vIdModuloInicio INT, --@14
	@vCompaniaSocio CHAR(8), --@14
	@vIdUnidadAcademica VARCHAR(50), --@14
	@vActivo INT, --@14
	--Inicio --@17
	@IdTipoProgramaOrigen INT,
	@IdTipoProgramaDestino INT,
	@TipoProgramaOrigen VARCHAR(20),
	@TipoProgramaDestino VARCHAR(20),
	@EstadoTipoProgramaInstitutoEscuela VARCHAR(MAX),
	@TipoProgramaInstituto VARCHAR(5000),
	@TipoProgramaEscuela VARCHAR(5000),
	--Fin --@17
	--Inicio --@23
	@IdAlumno INT,
	@IdUsuario INT,
	@pIdTipoTurnoOrigen INT,
	@pIdMatriculaAnterior INT,
	@vProgresionCurricular INT,
	@EsNuevasObservacionesCargaHabil BIT,
	@IdNuevasObservacionesCargaHabil INT,
	@MensajePersonalizado VARCHAR(MAX),
	@NombreAreaResponsable VARCHAR(MAX),
	@IdTipoTurno INT,
	@EsAsignacionSeccionHorariosCursosCargaHabil BIT,
	@EsCargaHabilRegular BIT,
	@EsCargaHabilBachiller BIT,
	@EsCargaHabilPorSolicitud BIT,
	@EsProgresionCurricular BIT,
	@EsSeparacionCargaHabilPago BIT,
	@IdGeneracionInterfasesPagosCH INT,
	@EsGeneracionInterfasesCargaHabil BIT,
	@EsGeneracionInterfasesCargaHabilRegular BIT,
	@EsGeneracionInterfasesCargaHabilBachiller BIT,
	@EsGeneracionInterfasesCargaHabilPorSolicitud BIT,
	@EsGeneracionInterfasesProgresionCurricular BIT,
	@EsGeneracionInterfasesSeparacionCargaHabilPago BIT,
	@ValorEsCargaHabilRegular BIT,
	@ValorEsCargaHabilBachiller BIT,
	@ValorEsCargaHabilPorSolicitud BIT,
	@ValorEsProgresionCurricular BIT,
	@ValorEsSeparacionCargaHabilPago BIT,
	@ValorEsGeneracionInterfasesCargaHabilRegular BIT,
	@ValorEsGeneracionInterfasesCargaHabilBachiller BIT,
	@ValorEsGeneracionInterfasesCargaHabilPorSolicitud BIT,
	@ValorEsGeneracionInterfasesProgresionCurricular BIT,
	@ValorEsGeneracionInterfasesSeparacionCargaHabilPago BIT,
	--Fin --@23
	--Inicio --@24
	@CodigoSede VARCHAR(20),
	@NombreSede VARCHAR(100),
	@NombreModulo VARCHAR(100),
	@CodigoCurricula VARCHAR(20),
	@NombreProducto VARCHAR(200)
	--Fin --@24

	--Inicio --@23
	SET @pIdTipoTurnoOrigen = 0
	SET @IdTipoTurno = 0
	SET @EsCargaHabilRegular = 0
	SET @EsCargaHabilBachiller = 0
	SET @EsCargaHabilPorSolicitud = 0
	SET @EsProgresionCurricular = 0
	SET @EsSeparacionCargaHabilPago = 0
	SET @EsGeneracionInterfasesCargaHabil = 0
	SET @EsGeneracionInterfasesCargaHabilRegular = 0
	SET @EsGeneracionInterfasesCargaHabilBachiller = 0
	SET @EsGeneracionInterfasesCargaHabilPorSolicitud = 0
	SET @EsGeneracionInterfasesProgresionCurricular = 0
	SET @EsGeneracionInterfasesSeparacionCargaHabilPago = 0
	SET @ValorEsCargaHabilRegular = 0
	SET @ValorEsCargaHabilBachiller = 0
	SET @ValorEsCargaHabilPorSolicitud = 0
	SET @ValorEsProgresionCurricular = 0
	SET @ValorEsSeparacionCargaHabilPago = 0
	SET @ValorEsGeneracionInterfasesCargaHabilRegular = 0
	SET @ValorEsGeneracionInterfasesCargaHabilBachiller = 0
	SET @ValorEsGeneracionInterfasesCargaHabilPorSolicitud = 0
	SET @ValorEsGeneracionInterfasesProgresionCurricular = 0
	SET @ValorEsGeneracionInterfasesSeparacionCargaHabilPago = 0
	--Fin --@23

	--Inicio --@23
	SET @IdAlumno = @pIdAlumno 
	SET @IdUsuario = @pIdUsuarioCreacion
	--Fin --@23

	--Inicio --@23
	SELECT
		@vProgresionCurricular = Valor 
	FROM Parametro (NOLOCK)
	WHERE Nombre = 'ProgresionCurricular'

	IF @vProgresionCurricular = 1
	BEGIN

		SET @ValorEsProgresionCurricular = 1

	END
	ELSE
	BEGIN

		SET @ValorEsCargaHabilPorSolicitud = 1

	END
	--Fin --@23

	--Inicio --@23
	SELECT
		@EsNuevasObservacionesCargaHabil = Valor
	FROM Parametro WITH (NOLOCK)
	WHERE Nombre = 'VisualizacionNuevasObservacionesCargaHabil'

	IF @EsNuevasObservacionesCargaHabil = 1
	BEGIN

		SELECT
			@IdNuevasObservacionesCargaHabil = IdMaestroTabla
		FROM MaestroTabla WITH (NOLOCK)
		WHERE Codigo = 'NUEOBSCH'

	END
	--Fin --@23

	--Inicio --@23
	SELECT
		@EsAsignacionSeccionHorariosCursosCargaHabil = Valor
	FROM Parametro WITH (NOLOCK)
	WHERE Nombre = 'AsignacionSeccionHorariosCursosCargaHabil'

	SELECT
		@EsGeneracionInterfasesCargaHabil = Valor
	FROM Parametro WITH (NOLOCK)
	WHERE Nombre = 'GeneracionInterfasesPagosCargaHabil'

	IF @EsAsignacionSeccionHorariosCursosCargaHabil = 1
	BEGIN

		IF @EsGeneracionInterfasesCargaHabil = 1
		BEGIN

			SELECT
				@IdGeneracionInterfasesPagosCH = IdMaestroTabla
			FROM MaestroTabla WITH (NOLOCK)
			WHERE Codigo = 'GENINTPAGCH'

			SELECT
				@ValorEsGeneracionInterfasesCargaHabilPorSolicitud = Disponible1
			FROM MaestroTablaRegistro WITH (NOLOCK)
			WHERE IdMaestroTabla = @IdGeneracionInterfasesPagosCH
			AND Codigo = 'PorSolicitud'

			SELECT
				@ValorEsGeneracionInterfasesProgresionCurricular = Disponible1
			FROM MaestroTablaRegistro WITH (NOLOCK)
			WHERE IdMaestroTabla = @IdGeneracionInterfasesPagosCH
			AND Codigo = 'ProgCurr'

		END

	END
	--Fin --@23

	--Inicio --@17
	SELECT
		@EstadoTipoProgramaInstitutoEscuela = Valor,
		@TipoProgramaInstituto = Valor2,
		@TipoProgramaEscuela = Valor3
	FROM Parametro WITH (NOLOCK)
	WHERE Nombre = 'TipoPrograma'
	--Fin --@17

	--@14
	--Se obtiene lo parametros para la progresion curricular
	SELECT
		@vCompaniaSocio = Disponible1,
		@vAnioCursado = Disponible2,
		@vIdModuloInicio = Disponible3,
		@vIdUnidadAcademica = Disponible4,
		@vActivo = Activo 
	FROM MaestroTablaRegistro WITH (NOLOCK)
	WHERE Codigo = 'ProgreCurri'
	--@14

	--Inicio --@15
	DECLARE
	@vNombreProcesoLogDisNiv VARCHAR(100), --@23
	@vIdMatricula INT,
	@vIdProducto INT,
	@vIdPeriodo INT,
	@vIdModulo INT,
	@EsProcesadoLogDisNiv BIT --@23

	SET @vNombreProcesoLogDisNiv = 'LogDisNiv' --@23
	SET @vIdMatricula = 0
	SET @vIdProducto = 0
	SET @vIdPeriodo = 0
	SET @vIdModulo = 0
	SET @EsProcesadoLogDisNiv = 0 --@23
	--Fin --@15

	SELECT
		@CurIdAlumno = CC.IdAlumno, 
		@CurIdProductoAnterior = CC.IdProductoAnterior,
		@CurIdProductoNueva = CC.IdProductoNueva,
		@CurIdCurriculaAnterior = CC.IdCurriculaAnterior,
		@CurIdCurriculaNueva = CC.IdCurriculaNueva,
		@CurNumeroIdentidad = AC.NumeroIdentidad,
		@Direccion = AC.DireccionCompleta,
		@NombreCompleto = AC.NombreCompleto,
		@Telefonos = SUBSTRING(dbo.cActorTelefonoStr(AC.IdActor),1,20),
		@IdSedeAnterior = CC.IdSedeOrigen,
		@IdDocumentoTipo = AC.IdDocumentoTipo,
		@Ubigeo = ISNULL(AD.IdUbigeoResidencia,''),
		@CompaniaSocio = E.CompaniaSocio, --@3
		--Inicio --@17
		@IdTipoProgramaOrigen = PER_ORIG.IdUnidadAcademica,
		@IdTipoProgramaDestino = PER_DEST.IdUnidadAcademica
		--Fin --@17
	FROM TrasladoSede CC WITH (NOLOCK) 
	--Inicio --@17
	INNER JOIN Periodo PER_ORIG WITH (NOLOCK) ON CC.IdPeriodoAnterior = PER_ORIG.IdPeriodo
	INNER JOIN Periodo PER_DEST WITH (NOLOCK) ON CC.IdPeriodoTraslado = PER_DEST.IdPeriodo
	--Fin --@17
	INNER JOIN Actor AC WITH (NOLOCK) ON CC.IdAlumno = AC.IdActor 
	INNER JOIN Empresa E WITH (NOLOCK) ON CC.IdEmpresa = E.IdEmpresa
	LEFT JOIN ActorDireccion AD WITH (NOLOCK) ON AC.IdActor = AD.IdActor
	AND AD.Principal = 1
	WHERE CC.IdEmpresa = @pIdEmpresa
	AND CC.IdSede = @pIdSede
	AND CC.IdPeriodoTraslado = @pIdPeriodo
	AND (CC.IdAlumno = @pIdAlumno)
	AND CC.Estado = 1

	--Inicio --@17
	SELECT
		@TipoProgramaOrigen = ISNULL(NombreCorto,'')
	FROM UnidadAcademica WITH (NOLOCK)
	WHERE IdUnidadAcademica = @IdTipoProgramaOrigen
  
	SELECT
		@TipoProgramaDestino = ISNULL(NombreCorto,'')
	FROM UnidadAcademica WITH (NOLOCK)
	WHERE IdUnidadAcademica = @IdTipoProgramaDestino  
	--Fin --@17
 
	--@3
	DECLARE @PaqCursoEquivalenciaDet AS TABLE  
	(
		IdCurricula INT
	)

	INSERT INTO @PaqCursoEquivalenciaDet
	SELECT DISTINCT
		IdCurricula
	FROM PaqCursoEquivalenciaDet WITH (NOLOCK) --@23
	--@3
 
	IF @CompaniaSocio = '00002500' OR @CompaniaSocio = '00002400'
	BEGIN

		--@1  
		IF @CurIdCurriculaAnterior IN (SELECT IdCurricula FROM @PaqCursoEquivalenciaDet) --(27,28,4,586,547,589) --@2 --@3
		BEGIN

			IF EXISTS
			(
				SELECT
					1
				FROM Egresados WITH (NOLOCK)
				WHERE IdAlumno = @pIdAlumno
				AND IdCurricula = @CurIdCurriculaAnterior
			)
			BEGIN

				SELECT @Verifica = 0
				SELECT @Egresado = 1
				SELECT @Reingreso = 0

			END
			ELSE
			BEGIN

				SELECT @Verifica = 0  
				SELECT @Egresado = 0 
				SELECT @Reingreso = 1
			
			END

		END
		ELSE
		BEGIN

			SELECT @Verifica = 0
			SELECT @Egresado = 0
			SELECT @Reingreso = 0   
			SELECT @Regular = 1

		END
		--@1

	END  

	IF @CompaniaSocio IN ('00002700','00002600') --@16 
	BEGIN

		--@1  
		IF @CurIdCurriculaAnterior IN (SELECT IdCurricula FROM @PaqCursoEquivalenciaDet) --(27,28,4,586,547,589) --@2 --@3  
		BEGIN

			IF EXISTS
			(
				SELECT
					1
				FROM Egresados WITH (NOLOCK) --@23
				WHERE IdAlumno = @pIdAlumno
				AND IdCurricula = @CurIdCurriculaAnterior
			)
			BEGIN
			
				SELECT @Verifica = 0
				SELECT @Egresado = 1
				SELECT @Reingreso = 0

			END
			ELSE
			BEGIN

				SELECT @Verifica = 0  
				SELECT @Egresado = 0

				--Inicio --@17
				IF @EstadoTipoProgramaInstitutoEscuela = 1
				BEGIN

					IF
					(
						@TipoProgramaOrigen = @TipoProgramaInstituto
						AND @TipoProgramaDestino = @TipoProgramaInstituto
					)
					BEGIN

						SELECT @Regular = 1  

					END
					ELSE IF
					(
						@TipoProgramaOrigen = @TipoProgramaInstituto
						AND @TipoProgramaDestino = @TipoProgramaEscuela
					)
					BEGIN

						SELECT @Reingreso = 1  

					END
					ELSE IF
					(
						@TipoProgramaOrigen = @TipoProgramaEscuela
						AND @TipoProgramaDestino = @TipoProgramaEscuela
					)
					BEGIN

						SELECT @Regular = 1   

					END
					ELSE
					BEGIN

						SELECT @Regular = 1 

					END

				END
				ELSE
				BEGIN

					SELECT @Regular = 1 

				END

			END

		END
		ELSE
		BEGIN

			SELECT @Verifica = 0
			SELECT @Egresado = 0
			SELECT @Reingreso = 0   
			SELECT @Regular = 1

		END
		--@1

	END

	IF @IdDocumentoTipo NOT IN (25,27,CASE @CompaniaSocio WHEN '00002700' THEN 27670 WHEN '00002600' THEN 25596 ELSE 30765 END) --@21 --@22  
	BEGIN

		--Inicio --@23
		IF @EsNuevasObservacionesCargaHabil = 1
		BEGIN

			SELECT
				@MensajePersonalizado = Disponible1,
				@NombreAreaResponsable = Disponible2
			FROM MaestroTablaRegistro WITH (NOLOCK)
			WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
			AND Codigo = 'ServicioEstudiante'

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno no tiene registrado un tipo de documento valido.' + @MensajePersonalizado + @NombreAreaResponsable --@24 --@25
			RETURN

		END
		ELSE
		BEGIN
		--Fin --@23

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno no tiene registrado un tipo de documento valido.' --@24 --@25
			RETURN

		--Inicio --@23
		END
		--Fin --@23

	END  

	IF ISNUMERIC(@CurNumeroIdentidad) = 0
	BEGIN

		--Inicio --@23
		IF @EsNuevasObservacionesCargaHabil = 1
		BEGIN

			SELECT
				@MensajePersonalizado = Disponible1,
				@NombreAreaResponsable = Disponible2
			FROM MaestroTablaRegistro WITH (NOLOCK)
			WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
			AND Codigo = 'ServicioEstudiante'

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno no tiene registrado un numero de documento valido.' + @MensajePersonalizado + @NombreAreaResponsable --@24 --@25
			RETURN

		END
		ELSE
		BEGIN
		--Fin --@23

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno no tiene registrado un numero de documento valido.' --@24 --@25
			RETURN

		--Inicio --@23
		END
		--Fin --@23

	END  

	IF @Ubigeo = '' OR @Direccion = ''
	BEGIN

		--Inicio --@23
		IF @EsNuevasObservacionesCargaHabil = 1
		BEGIN

			SELECT
				@MensajePersonalizado = Disponible1,
				@NombreAreaResponsable = Disponible2
			FROM MaestroTablaRegistro WITH (NOLOCK)
			WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
			AND Codigo = 'ServicioEstudiante'

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno no tiene direccion registrada.' + @MensajePersonalizado + @NombreAreaResponsable --@24 --@25
			RETURN

		END
		ELSE
		BEGIN
		--Fin --@23

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno no tiene direccion registrada.' --@24 --@25
			RETURN

		--Inicio --@23
		END
		--Fin --@23

	END
 
	SET @Deudas = 0  
  
	SELECT
		@Deudas = ISNULL(Valor,0)
	FROM ParametroUnidadAcademica WITH (NOLOCK)
	WHERE IdEmpresa = @pIdEmpresa
	AND IdSede = @pIdSede
	AND Activo = 1
	AND Nombre = 'CargaHabilDeudas'
  
	IF ISNULL(@Deudas,0) = 1 
	BEGIN

		--Verificamos si tiene deudas pendientes  
		EXEC cAlumno_Valida_Deudas
		@pIdAlumno,
		NULL,
		@Deudas OUTPUT  
  
		--Tiene deudas
		IF @Deudas > 0
		BEGIN

			--Verificamos si tiene permiso para generar carga con deuda   
			IF (dbo.cAutorizacionAlumno_Val_Existe(@pIdEmpresa,@pIdSede,1,1,1,@pIdPeriodo,@pIdAlumno,1035) = 0)
			BEGIN

				--Inicio --@23
				IF @EsNuevasObservacionesCargaHabil = 1
				BEGIN

					SELECT
						@MensajePersonalizado = Disponible1,
						@NombreAreaResponsable = Disponible2
					FROM MaestroTablaRegistro WITH (NOLOCK)
					WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
					AND Codigo = 'Cobranzas'

					SET @pEstado = 'KO' --@24
					SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno tiene deudas pendientes con la institucion.' + @MensajePersonalizado + @NombreAreaResponsable --@24 --@25
					RETURN

				END
				ELSE
				BEGIN
				--Fin --@23

					SET @pEstado = 'KO' --@24
					SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno tiene deudas pendientes con la institucion.' --@24 --@25
					RETURN

				--Inicio --@23
				END
				--Fin --@23

			END

		END

	END

	--@9 Inicio
	--Valida si el alumno tiene algun bloqueo acad mico.
	EXEC cAlumno_Valida_Bloqueos
	@pIdSede,
	@pIdAlumno,
	@pContador OUTPUT,
	@Observacion OUTPUT

	IF @pContador > 0
	BEGIN

		--Inicio --@23
		IF @EsNuevasObservacionesCargaHabil = 1
		BEGIN

			SELECT
				@MensajePersonalizado = Disponible1,
				@NombreAreaResponsable = Disponible2
			FROM MaestroTablaRegistro WITH (NOLOCK)
			WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
			AND Codigo = 'Cobranzas'

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: ' + @Observacion + @MensajePersonalizado + @NombreAreaResponsable --@24 --@25
			RETURN

		END
		ELSE
		BEGIN
		--Fin --@23

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: ' + @Observacion --@24 --@25
			RETURN

		--Inicio --@23
		END
		--Fin --@23

	END
	--@9 Fin

	--Recuperamos IdMatricula si ya esta matriculado  
	DECLARE
	@IdMatricula INT,  
	@Retorno INT  
 
	SELECT @IdMatricula =
	dbo.cMatricula_Sel_AlumnoMatricula
	(
		@pIdEmpresa,
		@pIdSede,
		@pIdPeriodo, --Es el nuevo periodo 
		@pIdAlumno,
		@CurIdCurriculaNueva --@4
	)   

	IF @IdMatricula > 0  
	BEGIN

		--Si no pago entonces eliminamos cointerfase.  
		IF @CompaniaSocio = '00002600' OR @CompaniaSocio = '00002400' --@18
		BEGIN

			--@10
			SELECT
				@CompaniaSocioPadre = CompaniaSocioPadre
			FROM Empresa WITH (NOLOCK) --@23
			WHERE IdEmpresa = 1
			--@10

			IF NOT EXISTS
			(
				SELECT
					1
				FROM vw_CO_Interfase_P09_Header WITH (NOLOCK) 
				WHERE IdMatricula = @IdMatricula 
				AND Estado = 'CO'
				AND CompaniaSocio = @CompaniaSocioPadre
			) 
			BEGIN

				EXEC cInterfaseDocumento_Ins_Borrar_General
				@IdMatricula,
				@Retorno OUTPUT

			END

		END
		ELSE IF @CompaniaSocio <> '00002600' OR @CompaniaSocio <> '00002400' --@18
		BEGIN

			--@3
			IF NOT EXISTS
			(
				SELECT
					1 --@23
				FROM vw_CO_Interfase_P09_Header WITH (NOLOCK)
				WHERE IdMatricula = @IdMatricula
				AND Estado = 'CO'
				AND CompaniaSocio = @CompaniaSocio
			)
			BEGIN

				EXEC cInterfaseDocumento_Ins_Borrar_General
				@IdMatricula,
				@Retorno OUTPUT

			END
			--@3

		END
		ELSE  
		BEGIN

			--Inicio --@23
			IF @EsNuevasObservacionesCargaHabil = 1
			BEGIN

				SELECT
					@MensajePersonalizado = Disponible1,
					@NombreAreaResponsable = Disponible2
				FROM MaestroTablaRegistro WITH (NOLOCK)
				WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
				AND Codigo = 'Cobranzas'

				SET @pEstado = 'KO' --@24
				SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno ya pago.' + @MensajePersonalizado + @NombreAreaResponsable --@24 --@25
				RETURN

			END
			ELSE
			BEGIN
			--Fin --@23

				SET @pEstado = 'KO' --@24
				SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno ya pago.' --@24 --@25
				RETURN

			--Inicio --@23
			END
			--Fin --@23

		END

	END
   
	SELECT @IdMatricula = ISNULL
	(
		(
			SELECT TOP 1
				M.IdMatricula
			FROM Matricula M WITH (NOLOCK)  
			WHERE M.IdEmpresa = @pIdEmpresa  
			AND M.IdSede = @pIdSede   
			AND M.IdPeriodo = @pIdPeriodo  
			AND M.IdActor = @pIdAlumno  
			AND M.Estado <> 'X'  
			AND M.EsMatricula = 1
		)
	,0)  
 
	--Verificamos si ya esta matriculado  
	SELECT @ValAlumnoMatriculado =
	dbo.cMatricula_Val_AlumnoMatriculado
	(
		@pIdEmpresa,  
		@pIdSede,  
		@pIdPeriodo, --Es el nuevo periodo   
		@pIdAlumno,
		@CurIdCurriculaNueva --@4
	) 

	--Esta matriculado
	IF @ValAlumnoMatriculado = 1  
	BEGIN

		--Inicio --@23
		IF @EsNuevasObservacionesCargaHabil = 1
		BEGIN

			SELECT
				@MensajePersonalizado = Disponible1,
				@NombreAreaResponsable = Disponible2
			FROM MaestroTablaRegistro WITH (NOLOCK)
			WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
			AND Codigo = 'ServicioEstudiante'

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno ya se encuentra matriculado.' + @MensajePersonalizado + @NombreAreaResponsable --@24 --@25
			RETURN

		END
		ELSE
		BEGIN
		--Fin --@23

			SET @pEstado = 'KO' --@24
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: El alumno ya se encuentra matriculado.' --@24 --@25
			RETURN

		--Inicio --@23
		END
		--Fin --@23

	END
  
	--El alumno no esta matriculado  
	--Prcesamos su carga habil  
	--Borramos su matricula si la tuviera   
	IF @ValAlumnoMatriculado = 0  
	BEGIN

		EXEC cMatricula_Eli_CargaHabil
		@pIdEmpresa,  
		@pIdSede,
		@pIdAlumno,   
		@pIdPeriodo,
		@CurIdCurriculaNueva, --@5
		@EliCargaHabil OUTPUT  

		--Error al eliminar las matriculas
		IF @EliCargaHabil = 1  
		BEGIN

			--Inicio --@23
			IF @EsNuevasObservacionesCargaHabil = 1
			BEGIN

				SELECT
					@MensajePersonalizado = Disponible1,
					@NombreAreaResponsable = Disponible2
				FROM MaestroTablaRegistro WITH (NOLOCK)
				WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
				AND Codigo = 'TIC'

				SET @pEstado = 'KO' --@24
				SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: No se elimino la pre-matricula o matricula del alumno.' + @MensajePersonalizado + @NombreAreaResponsable --@24 --@25
				RETURN

			END
			ELSE
			BEGIN
			--Fin --@23

				SET @pEstado = 'KO' --@24
				SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: No se elimino la pre-matricula o matricula del alumno.' --@24 --@25
				RETURN

			--Inicio --@23
			END
			--Fin --@23

		END

	END

	--Inicio @12
	IF @CompaniaSocio = '00002700'
	BEGIN

		--Obtenemos el registro anterior  
		SELECT TOP 1
			@IdRegistroAnterior = IdRegistro 
		FROM Registro WITH (NOLOCK)
		WHERE IdEmpresa = @pIdEmpresa  
		AND IdSede = @IdSedeAnterior  
		AND IdActor = @CurIdAlumno  
		AND IdProducto = @CurIdProductoAnterior  
		AND Estado <> 'X'
		ORDER BY IdRegistro ASC
   
		--Obtenemos el registro nuevo  
		SELECT TOP 1
			@IdRegistroNuevo = IdRegistro  
		FROM Registro WITH (NOLOCK) 
		WHERE IdEmpresa = @pIdEmpresa  
		AND IdSede = @pIdSede  
		AND IdActor = @CurIdAlumno  
		AND IdProducto = @CurIdProductoNueva  
		AND Estado <> 'X'
		ORDER BY IdRegistro DESC  

	--Fin @12
	END
	ELSE
	BEGIN

		--Obtenemos el registro anterior
		SELECT
			@IdRegistroAnterior = IdRegistro
		FROM Registro WITH (NOLOCK) 
		WHERE IdEmpresa = @pIdEmpresa
		AND IdSede = @IdSedeAnterior
		AND IdActor = @CurIdAlumno
		AND IdProducto = @CurIdProductoAnterior
		AND Estado <> 'X'
 
		--Obtenemos el registro nuevo
		SELECT
			@IdRegistroNuevo = IdRegistro
		FROM Registro WITH (NOLOCK) 
		WHERE IdEmpresa = @pIdEmpresa
		AND IdSede = @pIdSede
		AND IdActor = @CurIdAlumno
		AND IdProducto = @CurIdProductoNueva
		AND Estado <> 'X'

	END

	--Inicio --@23
	SELECT @pIdMatriculaAnterior =
	dbo.cMatricula_Sel_UltimaMatricula_IdMatricula
	(
		@CurIdAlumno,
		@IdRegistroAnterior
	)
	--Fin --@23

	--@5
	IF @Egresado = 1
	BEGIN

		--PRINT 'Egresado' --@23

		SELECT @CurIdTipo = 2

	END

	IF @Reingreso = 1
	BEGIN

		--PRINT 'Reingreso' --@23

		SELECT @CurIdTipo = 3

	END

	--@1
	IF @Regular = 1  
	BEGIN

		--PRINT 'Regular' @23

		SELECT @CurIdTipo = 1

	END

	IF EXISTS
	(
		SELECT
			1
		FROM EquivalenciaCurriculas WITH (NOLOCK)
		WHERE IdCurriculaDestino = @CurIdCurriculaNueva
		AND IdCurriculaOrigen = @CurIdCurriculaAnterior 
		AND IdTipo = @CurIdTipo
		AND Activo = 1 AND @CompaniaSocio IN ('00002500','00002700') --@13
		--@EquivalenciaCertificado = 1 --@11
	)
	BEGIN

		SET @EquivalenciaCertificado = 1

		EXEC EquivalenciaCurriculas_Val_CumplimientoNuevoEscuela
		@pIdEmpresa,
		@pIdSede,
		@pIdPeriodo,
		@pTipo,
		@CurIdAlumno,
		@IdRegistroNuevo,
		@IdRegistroAnterior,
		@CurIdCurriculaNueva,
		@CurIdCurriculaAnterior,
		@CurIdTipo,
		@pIdUsuarioCreacion,
		@wIdModulo OUTPUT,
		@wTipo OUTPUT

	END
	--@5

	IF @Verifica = 0 AND @EquivalenciaCertificado = 0 --@5
	BEGIN

		--Obtenemos de la curriculacurso de los cursos del nuevo producto  
		DECLARE @CurCursos AS TABLE
		(
			Id INT IDENTITY(1,1),   
			IdCurso INT
		)  
   
		INSERT INTO @CurCursos  
		SELECT
			IdCurso
		FROM AlumnoCurriculaCurso WITH (NOLOCK) --@23
		WHERE IdRegistro = @IdRegistroNuevo  
		AND IdAlumno = @CurIdAlumno  
		AND IdCurricula = @CurIdCurriculaNueva  
		ORDER BY IdModulo ASC
 
		SET @Val = 0
		SET @IdConvalidacion = 0  
   
		WHILE EXISTS (SELECT * FROM @CurCursos)  
		BEGIN

			SELECT TOP 1 
				@CurIdCurso = IdCurso  
			FROM @CurCursos   
			ORDER BY Id ASC

			SET @Cumple = 0
			SET @TipoAprobacion = ''

			EXEC AlumnoCurriculaCurso_Val_CumplimientoNuevoEscuela
			@CurIdAlumno,
			@IdRegistroAnterior, 
			@CurIdCurriculaNueva,
			@CurIdCurriculaAnterior, 
			@CurIdCurso,
			@CurIdTipo, 
			'NO',
			@Cumple OUTPUT, 
			@TipoAprobacion OUTPUT,
			@PromFinal OUTPUT,
			@PromReal OUTPUT
  
			IF @Cumple = 1
			BEGIN

				--Si es la primera vez crea la convalidacion
				SET @Val = @Val + 1
  
				IF @Val = 1
				BEGIN

					--Debemos verificar si ya se realizo una convalidacion en el periodo
					SET @CodigoCurriculaAnterior =
					(
						SELECT
							Codigo
						FROM Curricula WITH (NOLOCK)
						WHERE IdCurricula = @CurIdCurriculaAnterior
					)

					SET @CodigoCurriculaNueva =
					(
						SELECT
							Codigo
						FROM Curricula WITH (NOLOCK)
						WHERE IdCurricula = @CurIdCurriculaNueva
					) 
 
					IF @pTipo = 'CI'
					BEGIN

						SET @cTipo = 'TE'  
						SET @ObservacionC = 'TRASLADO EXTERNO - DE IES A EEST'

					END

					IF @pTipo = 'TS'
					BEGIN

						SET @cTipo = 'CI'  
						SET @ObservacionC = 'CONVALIDACION INTERNA - TRASLADO SEDE'

					END 
					
					--INICIO @7
					IF PATINDEX('%[ABCDEFGHIJKLMNOPQRSTUVWXYZ]%', @CodigoCurriculaAnterior) = 1 AND PATINDEX('%[ABCDEFGHIJKLMNOPQRSTUVWXYZ]%', @CodigoCurriculaNueva) = 0 AND @CompaniaSocio = '00002700'
					BEGIN

						SET @cTipo = 'AM'
						SET @ObservacionC = 'Actualizacion de Malla'

					END
 
					IF @cTipo = 'AM'
					BEGIN

						SET @Existe = 
						dbo.cConvalidacion_Val_ExisteAM
						(
							@pIdEmpresa,  
							@pIdSede,  
							@CurIdAlumno,  
							@IdRegistroNuevo,  
							@CurIdCurriculaNueva,
							@pIdPeriodo
						)

					END
 
					IF @cTipo = 'CI'
					BEGIN

						SET @Existe =
						dbo.cConvalidacion_Val_ExisteCI
						(
							@pIdEmpresa,
							@pIdSede,
							@CurIdAlumno,
							@IdRegistroNuevo,
							@CurIdCurriculaNueva,
							@pIdPeriodo
						)

					END

					IF @cTipo = 'TE'
					BEGIN

						SET @Existe =
						dbo.cConvalidacion_Val_ExisteTE
						(
							@pIdEmpresa,
							@pIdSede,
							@CurIdAlumno,
							@IdRegistroNuevo,
							@CurIdCurriculaNueva,
							@pIdPeriodo
						)

					END
					--FIN @7
					IF @Existe = 0
					BEGIN

						--Generamos la convalidacion interna por cada curso aprobado
						SET @anioconva = YEAR(GETDATE())
						SET @fecha = dbo.gFechaStr(GETDATE())  
   
						--@9 
						EXEC cEmpresaSedeParametro_Gen_Numero
						'NUMEROCONVALIDAE',
						@NumeroConv OUTPUT  
						--@9
 
						EXEC cConvalidacion_Ins_Grabar
						@pIdEmpresa,
						@pIdSede,
						@CurIdAlumno,
						@IdRegistroNuevo,
						@CurIdCurriculaNueva,
						@CurIdCurriculaAnterior,
						@NumeroConv,
						@pIdPeriodo,
						@pIdUsuarioCreacion,
						NULL,
						@fecha,
						@ObservacionC,
						@cTipo,
						'R',  
						@pIdUsuarioCreacion,
						'',
						'',
						'', 
						NULL,--@6
						NULL,--@6
						@IdConvalidacion OUTPUT

					END  
					ELSE
					BEGIN

						SET @IdConvalidacion = @Existe

					END
				
				END
   
				IF CONVERT(DECIMAL(5,2),@PromFinal) < 13
				BEGIN

					IF @CurIdCurriculaNueva IN (27,28)
					BEGIN

						SET @PromFinal = ROUND(@PromFinal,0)
						SET @PromReal = ROUND(@PromReal,0)

					END
					ELSE
					BEGIN

						SET @PromFinal = 13
						SET @PromReal = 13

					END

				END 
				ELSE
				BEGIN

					SET @PromFinal = ROUND(@PromFinal,0)
					SET @PromReal = ROUND(@PromReal,0)

				END

				--Actualizamos en la tabla alumnocurriculacuso
				UPDATE AlumnoCurriculaCurso SET
					IdConvalidacion = @IdConvalidacion,
					TipoCondicion = 'CO',
					PromedioFinal = @PromFinal,
					PromedioReal = @PromReal,
					PromedioCondicion = 'A',   
					Glosa = 'Desde cAlumnoCurso_Pro_CargaHabil_CambioEscuela', --@1
					UsuarioModificacion = @pIdUsuarioCreacion, --@1
					FechaModificacion = GETDATE(), --@1
					Subsanacion = 0 --@2 
				WHERE IdAlumno = @CurIdAlumno
				AND IdRegistro = @IdRegistroNuevo
				AND IdCurricula = @CurIdCurriculaNueva  
				AND IdCurso = @CurIdCurso

			END 
 
			--Borramos la tabla temporal  
			DELETE N FROM @CurCursos N  
			WHERE N.Id =
			(
				SELECT TOP 1
					Id   
				FROM @CurCursos   
				ORDER BY Id
			)

		END
 
		--Obtenemos el maximo modulo de los cursos convalidados para marcarlos como subsabacion
		UPDATE AlumnoCurriculaCurso SET
			Subsanacion = 1
		WHERE IdAlumno = @pIdAlumno
		AND IdRegistro = @IdRegistroNuevo
		AND IdModulo IN
		(
			--@7
			SELECT DISTINCT
				IdModulo 
			FROM AlumnoCurriculaCurso WITH (NOLOCK)  
			WHERE IdAlumno = @pIdAlumno
			AND IdRegistro = @IdRegistroNuevo
			AND TipoCondicion = 'CO'
			--@7
		)
		AND TipoCondicion = 'RE'

	END

	--Obtenemos el nivel que le corresponderia llevar al alumno
	IF @EquivalenciaCertificado = 0 --@5
	BEGIN

		--@14 INICIO
		--Se obtiene el a�o donde curso el 1 semestre de manera regular.  
		SELECT
			@AnioCursado = ISNULL(MIN(PE.IdPeriodoAnual), 2022),
			@IdModuloInicio = ISNULL(MIN(PR.IdModulo), 1)
		FROM Matricula M WITH (NOLOCK)
		INNER JOIN AlumnoCurricula AC WITH (NOLOCK) ON AC.IdAlumno = M.IdActor
		AND AC.IdCurricula = M.IdCurricula
		INNER JOIN Curricula C WITH (NOLOCK) ON C.IdCurricula = AC.IdCurricula
		INNER JOIN Registro R WITH (NOLOCK) ON R.IdActor = M.IdActor
		AND C.IdProducto = R.IdProducto
		INNER JOIN Promocion PR WITH (NOLOCK) ON M.IdPromocion = PR.IdPromocion
		AND R.IdProducto = PR.IdProducto
		INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo
		WHERE M.IdRegistro = @IdRegistroNuevo  
		AND C.IdCurricula = @CurIdCurriculaNueva
		AND M.idactor = @pIdAlumno
		AND M.estado <> 'X'

		IF
		(
			@AnioCursado >= @vAnioCursado
			AND @IdModuloInicio >= @vIdModuloInicio
			AND @CompaniaSocio = @vCompaniaSocio
			AND @vActivo = 1
		)
		BEGIN

			--Inicio --@15
			SELECT @vIdMatricula = @IdMatricula

			SELECT @EsProcesadoLogDisNiv = --@23
			dbo.fxValidadorLogicaProgresionCurricular
			(
				@vNombreProcesoLogDisNiv, --@23
				@vIdMatricula,
				@vIdProducto,
				@vIdPeriodo,
				@vIdModulo
			)

			IF @EsProcesadoLogDisNiv = 1 --@23
			BEGIN

				--PRINT 'cMatricula_ProgresionCurricular' --@23

				EXEC cMatricula_ProgresionCurricular
				@pIdAlumno,
				@IdRegistroNuevo,
				@CurIdCurriculaNueva,
				@wIdModulo OUTPUT,
				@wTipo OUTPUT,
				@wIdModuloReal OUTPUT,
				@wTipoCondicionNueva OUTPUT

			END
			ELSE
			BEGIN
			--Fin --@15

				--PRINT 'cMatricula_CalculoSiguienteModulo' --@23

				EXEC cMatricula_CalculoSiguienteModulo
				@pIdAlumno,
				@IdRegistroNuevo,
				@CurIdCurriculaNueva,
				@IdMatricula,
				0,
				@wIdModulo OUTPUT,
				@wTipo OUTPUT --@6   

			--Inicio --@15
			END
			--Fin --@15

		END
		ELSE 
		BEGIN

			--PRINT 'cMatricula_CalculoSiguienteModulo' --@23

			EXEC cMatricula_CalculoSiguienteModulo
			@pIdAlumno,
			@IdRegistroNuevo,
			@CurIdCurriculaNueva,
			@IdMatricula,
			0,
			@wIdModulo OUTPUT,
			@wTipo OUTPUT --@6   

		END
		--@14 FIN

	END 
	
	--Verificamos si existe la promocion registrada que le corresponda al alumno
	SELECT
		@wIdPromocion = IdPromocion,
		@CodigoPromocion = ISNULL(PromocionCodigo,'') --@8   
	FROM Promocion WITH (NOLOCK)  
	WHERE IdEmpresa = @pIdEmpresa
	AND IdSede = @pIdSede
	AND IdPeriodo = @pIdPeriodo
	AND IdCurricula = @CurIdCurriculaNueva
	AND IdModulo = @wIdModulo
	AND Estado IN ('A','X') --@20   
   
	SET @wIdPromocion = ISNULL(@wIdPromocion,-1)
 
	--En caso no exista promocion no se registra nada en matricula ni alumno curso 
	IF @wIdPromocion <> -1
	BEGIN

		SELECT
			@NumeroCuota = ISNULL(MAX(CuotaNumero),0) 
		FROM CronogramaPago WITH (NOLOCK)
		WHERE IdPromocion = @wIdPromocion 
  
		IF @NumeroCuota = 0
		BEGIN

			--Inicio --@23
			IF @EsNuevasObservacionesCargaHabil = 1
			BEGIN

				SELECT
					@MensajePersonalizado = Disponible1,
					@NombreAreaResponsable = Disponible2
				FROM MaestroTablaRegistro WITH (NOLOCK)
				WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
				AND Codigo = 'Cobranzas'

				SET @pEstado = 'KO' --@24
				SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: No se ha registrado cronograma de pagos de la promocion: ' + @CodigoPromocion + '.' + @MensajePersonalizado + @NombreAreaResponsable --@14 --@24 --@25
				RETURN

			END
			ELSE
			BEGIN
			--Fin --@23

				SET @pEstado = 'KO' --@24
				SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: No se ha registrado cronograma de pagos de la promocion: ' + @CodigoPromocion + '.' --@14 --@24 --@25
				RETURN

			--Inicio --@23
			END
			--Fin --@23

		END 
 
		--Generamos el numero de matricula  
		EXEC cMatricula_Gen_Numero
		@NumeroMatricula OUTPUT  
 
		--Obtenemos la cantidad de cursos del producto  
		SELECT
			@cCursosModulo = COUNT(1)
		FROM CurriculaCurso WITH (NOLOCK) 
		WHERE IdCurricula = @CurIdCurriculaNueva
		AND IdModulo = @wIdModulo  

		--Obtenemos la cantidad de cursos en los que se va a matricular  
		SELECT
			@cCursosMat = COUNT(1)
		FROM AlumnoCurriculaCurso WITH (NOLOCK) --@23
		WHERE IdAlumno = @pIdAlumno  
		AND IdRegistro = @IdRegistroNuevo  
		AND IdCurricula = @CurIdCurriculaNueva  
		AND IdModulo <= @wIdModulo 
		AND TipoCondicion = 'RE' 
		AND ISNULL(PromedioCondicion,'D') = 'D'

		IF @wTipo = 'RT'  
		BEGIN

			IF @cCursosModulo = @cCursosMat
			BEGIN

				SET @TipoServicio = 'P'

			END
			ELSE
			BEGIN

				SET @TipoServicio = 'C'

			END

		END

		IF @wTipo = 'RP'   
		BEGIN

			SET @TipoServicio = 'M'

		END
 
		IF  @wTipo = 'RE'  
		BEGIN

			SET @TipoServicio = 'P'

		END
   
		--@6
		IF  @wTipo = 'CC'
		BEGIN

			SET @TipoServicio = 'C'

		END  
		--@6

		--Verificamos si tiene o no descuento corporativo
		IF (dbo.cActor_Val_ExisteClubIntercorp(@CurNumeroIdentidad) = 1)
		BEGIN

			SELECT
				@IdUnidadAcademica = P.IdUnidadAcademica
			FROM Matricula M WITH (NOLOCK)
			INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion
			WHERE IdMatricula = @IdMatricula  
   
			--Insertamos en la tabla promocionbeca de tipo I
			EXEC cPromocionBeca_Ins_Grabar
			@pIdAlumno,
			@pIdUsuarioCreacion,
			@IdUnidadAcademica,
			'I'

		END
  
		EXEC cMatricula_Ins_Grabar_CargaHabil
		@pIdEmpresa,
		@pIdSede,
		-1,
		@pIdAlumno,
		@IdRegistroNuevo,
		@CurIdCurriculaNueva,  
		@wIdModulo,
		@wIdPromocion,
		-1,
		-1,
		-1,
		@NumeroMatricula,
		@pIdUsuarioCreacion,
		-1,
		1,
		NULL,
		-1,
		0,
		0,
		0,
		@Descuento,
		-1,
		-1,
		-1,
		-1,
		-1,
		-1,
		-1,
		-1,
		236,
		NULL,
		'I',
		@wTipo,
		@TipoServicio,  
		@pTipo,
		@pTipo,
		'N',
		@pIdUsuarioCreacion,
		'Q',
		@pIdPeriodo,
		'',
		@NumeroCuota,
		@IdPrecioSede, --@8
		@wIdModuloReal, --@14
		@wTipoCondicionNueva, --@14
		@IdMatriculaNew OUTPUT

		IF
		(
			@wTipo = 'RT'
			AND @pIdSede IN (1,7)
			AND @IdSedeAnterior NOT IN (1,7)
		)
		BEGIN

			SELECT @wTipo = 'TR'

		END
  
		EXEC cAlumnoCurso_Ins_DetalleCargaHabil
		@IdMatriculaNew,  
		@wIdPromocion,  
		@CurIdCurriculaNueva,  
		@wIdModulo,  
		@pIdAlumno,  
		@IdRegistroNuevo,  
		@wTipo,  
		@pIdUsuarioCreacion

		EXEC cAlumnoCurriculaCursoOficial_Ins_Grabar
		@pIdAlumno,
		@IdRegistroNuevo,
		@CurIdCurriculaNueva,
		@wTipo

		--Registramos en la tabla matriculapagante como tipo individual  
		EXEC cMatriculaPagante_Ins_Grabar
		@IdMatriculaNew,
		@pIdAlumno,
		'N',
		236,
		0,
		0,
		NULL,
		1,
		'R',
		@pIdUsuarioCreacion  

		--Registramos en la tabla actorfacturacion como tipo individual
		EXEC cActorFacturacion_Ins_Grabar
		@IdMatriculaNew,
		@pIdAlumno,
		2,
		@CurNumeroIdentidad,  
		@NombreCompleto,
		@Direccion,
		-1,
		@Telefonos,
		0,
		0,
		0,
		@pIdUsuarioCreacion  
   
		IF
		(
			@TipoServicio = 'P'
			OR @TipoServicio = 'M'
		)
		BEGIN

			--Actualizamos los campos tipopromocionbeca y grupodescuento de la tabla matricula
			EXEC cMatricula_Upd_PromocionBecaMayorDescuento
			@IdMatriculaNew

		END

		--Inicio --@23
		IF @EsAsignacionSeccionHorariosCursosCargaHabil = 1
		BEGIN		

			--Obtenemos el turno de la matricula anterior
			SELECT
				@pIdTipoTurnoOrigen = T.IdTipoTurno  
			FROM Promocion P WITH (NOLOCK)
			INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON PG.IdPromocion = P.IdPromocion   
			INNER JOIN Matricula MA WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
			AND P.IdCurricula = MA.IdCurricula
			AND MA.IdGrupo = PG.IdGrupo    
			INNER JOIN Turno T WITH (NOLOCK) ON PG.IdTurno = T.IdTurno  
			INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroRegistro = T.IdTipoTurno  
			WHERE MA.IdMatricula = @pIdMatriculaAnterior

			IF @vProgresionCurricular = 1
			BEGIN

				SET @IdTipoTurno = @pIdTipoTurnoOrigen
				SET @EsCargaHabilRegular = 0
				SET @EsCargaHabilBachiller = 0
				SET @EsCargaHabilPorSolicitud = 0
				SET @EsProgresionCurricular = @ValorEsProgresionCurricular
				SET @EsSeparacionCargaHabilPago = 0
				SET @EsGeneracionInterfasesCargaHabilRegular = 0
				SET @EsGeneracionInterfasesCargaHabilBachiller = 0
				SET @EsGeneracionInterfasesCargaHabilPorSolicitud = 0
				SET @EsGeneracionInterfasesProgresionCurricular = @ValorEsGeneracionInterfasesProgresionCurricular
				SET @EsGeneracionInterfasesSeparacionCargaHabilPago = 0

			END
			ELSE
			BEGIN

				SET @IdTipoTurno = @pIdTipoTurnoOrigen
				SET @EsCargaHabilRegular = 0
				SET @EsCargaHabilBachiller = 0
				SET @EsCargaHabilPorSolicitud = @ValorEsCargaHabilPorSolicitud
				SET @EsProgresionCurricular = 0
				SET @EsSeparacionCargaHabilPago = 0
				SET @EsGeneracionInterfasesCargaHabilRegular = 0
				SET @EsGeneracionInterfasesCargaHabilBachiller = 0
				SET @EsGeneracionInterfasesCargaHabilPorSolicitud = @ValorEsGeneracionInterfasesCargaHabilPorSolicitud
				SET @EsGeneracionInterfasesProgresionCurricular = 0
				SET @EsGeneracionInterfasesSeparacionCargaHabilPago = 0

			END

			EXEC cMat_Asig_SeccionHorariosCursos
			@IdAlumno,
			@IdMatriculaNew,
			@IdTipoTurno,
			@IdUsuario,
			@EsCargaHabilRegular,
			@EsCargaHabilBachiller,
			@EsCargaHabilPorSolicitud,
			@EsProgresionCurricular,
			@EsSeparacionCargaHabilPago,
			@EsGeneracionInterfasesCargaHabilRegular,
			@EsGeneracionInterfasesCargaHabilBachiller,
			@EsGeneracionInterfasesCargaHabilPorSolicitud,
			@EsGeneracionInterfasesProgresionCurricular,
			@EsGeneracionInterfasesSeparacionCargaHabilPago,
			@pEstado OUTPUT,
			@pDescripcion OUTPUT
			RETURN

		END
		ELSE
		BEGIN

			--Inicio --@25
			IF EXISTS
			(
				SELECT
					1
				FROM Matricula MAT WITH (NOLOCK)
				INNER JOIN AlumnoCurso AC WITH (NOLOCK) ON MAT.IdMatricula = AC.IdMatricula
				WHERE MAT.IdMatricula = @IdMatriculaNew
			)
			BEGIN

				SET @pEstado = 'OK'
				SET @pDescripcion = 'Se genero la pre-matricula desde la carga habil: Se registraron los cursos.' --@25  
				RETURN

			END
			ELSE
			BEGIN

				SET @pEstado = 'OK'
				SET @pDescripcion = 'Se genero la pre-matricula desde la carga habil: No se registraron los cursos.' --@25  
				RETURN

			END
			--Fin --@25

		END
		--Fin --@23
	
	END  
	ELSE  
	BEGIN

		--Inicio --@24
		--Obtenemos los valores asociados al producto
		SELECT
			@CodigoSede = Codigo,
			@NombreSede = Nombre
		FROM Sede WITH (NOLOCK)
		WHERE IdSede = @pIdSede

		SELECT
			@NombreModulo = CURRMOD.Nombre,
			@CodigoCurricula = CURR.Codigo,
			@NombreProducto = PROD.ProductoNombre
		FROM Curricula CURR WITH (NOLOCK)
		INNER JOIN CurriculaModulo CURRMOD WITH (NOLOCK) ON CURR.IdCurricula = CURRMOD.IdCurricula
		INNER JOIN Producto PROD WITH (NOLOCK) ON CURR.IdProducto = PROD.IdProducto
		WHERE CURR.IdCurricula = @CurIdCurriculaNueva
		AND CURRMOD.IdModulo = @wIdModulo
		--Fin --@24

		--Inicio --@23
		IF @EsNuevasObservacionesCargaHabil = 1
		BEGIN

			SELECT
				@MensajePersonalizado = Disponible1,
				@NombreAreaResponsable = Disponible2
			FROM MaestroTablaRegistro WITH (NOLOCK)
			WHERE IdMaestroTabla = @IdNuevasObservacionesCargaHabil
			AND Codigo = 'Programaciones'

			--Inicio --@24
			--Se asigna el estado y el resultado
			SET @pEstado = 'KO'
			--Inicio --@25
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: ' + --@25
			'No existe promocion creada para la '  +
			'Sede: ' + @CodigoSede + ', ' +
			'Semestre: ' + @NombreModulo + ', ' + 
			'Curricula: ' + '[' + @CodigoCurricula + ']' + ' ' + @NombreProducto + '.' + @MensajePersonalizado + @NombreAreaResponsable
			--Fin --@25
			RETURN
			--Fin --@24

		END
		ELSE
		BEGIN
		--Fin --@23

			--Inicio --@24
			--Se asigna el estado y el resultado
			SET @pEstado = 'KO'
			--Inicio --@25
			SET @pDescripcion = 'No se genero la pre-matricula desde la carga habil: ' + --@25
			'No existe promocion creada para la '  +
			'Sede: ' + @CodigoSede + ', ' +
			'Semestre: ' + @NombreModulo + ', ' + 
			'Curricula: ' + '[' + @CodigoCurricula + ']' + ' ' + @NombreProducto + '.'
			--Fin --@25
			RETURN
			--Fin --@24

		--Inicio --@23
		END
		--Fin --@23

	END
	--Fin --@23
 
END