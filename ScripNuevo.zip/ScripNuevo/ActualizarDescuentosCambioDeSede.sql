--SELECT*FROM DescuentoAcademicoBase WHERE  IdMaestroRegistro IN (46582) AND PeriodoCodigo='2024-IIA'
--SELECT*FROM DescuentoAcademicoBase WHERE  NumeroIdentidad='70622022'
UPDATE DescuentoAcademicoBase SET PeriodoCodigo='2024-III'
WHERE  IdMaestroRegistro IN (46176) AND PeriodoCodigo='2024-IIA'
--(1148 rows affected)

UPDATE DescuentoAcademicoBase SET PeriodoCodigo='2024-III'
WHERE  IdMaestroRegistro IN (46582) AND PeriodoCodigo='2024-IIA'
--(52 rows affected)
