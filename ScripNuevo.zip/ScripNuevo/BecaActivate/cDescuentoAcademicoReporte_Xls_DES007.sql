CREATE PROCEDURE cDescuentoAcademicoReporte_Xls_DES007      
@PeriodoCodigo varchar(14)
AS 
DECLARE @MIN INT , @MAX INT,@IdMatricula INT,@pDescripcion varchar(500) ,@pEstado varchar(500)

CREATE TABLE #Matricula ( Id INT IDENTITY(1,1) PRIMARY KEY ,
IdMatricula INT,
SedeNombre VARCHAR(500),
NumeroDocumento VARCHAR(100),
NombreActor  varchar(500),
CodigoAlumno  varchar(500),
PromocionCodigo  varchar(500),
PromocionNombre  varchar(500),
Seccion  varchar(500),
Turno  varchar(500),
PeriodoCodigo VARCHAR(100) , 
BaseComercial varchar(500) ,
BasePertence VARCHAR(500) ,
CondicionMatricula  VARCHAR(500),  
TipoServicio  VARCHAR(100),
CondicionPago  VARCHAR(500),
FechaMatricula  VARCHAR(500),
Estado  VARCHAR(500),  
Estado_Actual VARCHAR(500),
Oferta_Alumno VARCHAR(500),
Beca_Actual VARCHAR(500),
Observacion varchar(500))

insert into #Matricula
SELECT DISTINCT  M.IdMatricula,
s.Nombre ,
ISNULL(Ac.NumeroIdentidad,''),
Ac.NombreCompleto ,
ISNULL(AL.CodigoAnterior,''),
ISNULL(p.PromocionCodigo,''),
ISNULL(p.PromocionNombre,'')Carrera,
ISNULL(pg.GrupoCodigo,'') Seccion,
ISNULL(T.Nombre,'') Turno,
ISNULL(pe.Codigo,'') Periodo ,
'[' + s.Codigo + '] [' + b.PeriodoCodigo + '] [' + pr.ProductoNombre + ']' ,
mtr.Nombre ,
'CondicionMatricula' = case m.TipoCondicion when 'RE' then 'PROMOVIDO' when 'RP' then 'PROMOVIDO + CURSO' when 'RT' then 'REPITENTE' when 'CC' then 'CURSO REPITENCIA' end,
'TipoServicio' = CASE WHEN M.TipoServicio = 'P' THEN 'PRODUCTO' WHEN M.TipoServicio = 'C' THEN 'CURSO' WHEN M.TipoServicio = 'M' THEN 'PRODUCTO + CURSO' ELSE '' END ,
'CondicionPago' = case  when condicionpago = 'C' then 'CONTADO' ELSE 'CUOTAS' END ,   
'FechaMatricula' = convert(varchar, ISNULL(m.MatriculaFecha, M.InscritoFecha), 103),
'Estado' = case when m.EsMatricula  = 1 then 'MATRICULADO' ELSE 'PRE' END,
'Estado_Actual' = CASE M.Estado  WHEN 'N' THEN 'NORMAL'   WHEN 'X' THEN 'ANULADO' WHEN 'R' THEN 'RETIRO CICLO' END ,'','',
'' FROM MATRICULA M
INNER JOIN Actor AC WITH(NOLOCK) ON M.IdActor = Ac.IdActor
INNER JOIN Alumno AL WITH(NOLOCK) ON AC.IdActor = AL.IdAlumno
INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion
INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo 
INNER JOIN DescuentoAcademicoBase B WITH(NOLOCK) ON B.IDACTOR = M.IDACTOR 
Inner join sede s WITH(NOLOCK) on s.IdSede = b.IdSede 
inner join Producto pr WITH(NOLOCK) on pr.IdProducto = b.IdProducto 
INNER JOIN MAESTROTABLAREGISTRO MTR WITH(NOLOCK) ON MTR.IdMaestroRegistro = B.IdMaestroRegistro
LEFT JOIN PromocionGrupo pg  WITH(NOLOCK) on pg.IdPromocion = m.IdPromocion and pg.IdGrupo = m.IdGrupo   
LEFT JOIN Turno t  WITH(NOLOCK)on t.IdTurno = pg.IdTurno   
WHERE PE.CODIGO = @PeriodoCodigo AND MTR.Codigo IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019')

SELECT @MIN = MIN(ID), @MAX = MAX(ID) from #Matricula

WHILE @MIN <= @MAX
BEGIN

	SET @IdMatricula = NULL 
	
	SELECT @IdMatricula = IdMatricula  FROM #Matricula WHERE ID = @Min
	EXEC  dbo.cAsignacion_BecaActivate @IdMatricula ,@pEstado OUT,@pDescripcion OUT

	UPDATE #Matricula SET Observacion=@pDescripcion
	WHERE ID = @Min

	UPDATE #Matricula
	SET Beca_Actual = ISNULL( DAR.DescuentoNombre,''),
    Oferta_Alumno = ISNULL(DA.OfertaAlumno,'')
	FROM #Matricula M
	INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON M.IdMatricula = DAR.IdMatricula
	INNER JOIN DescuentoAcademico  DA WITH(NOLOCK) ON DA.IdDescuentoAcademico = DAR.IdDescuentoAcademico
	INNER JOIN DescuentoAcademicoPoblacion  DAP WITH(NOLOCK) ON DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico
	INNER JOIN MAESTROTABLAREGISTRO  MTR WITH(NOLOCK) ON MTR.IdMaestroRegistro = DAP.IdTipoSituacionAlumno
	WHERE M.IdMatricula = @IdMatricula AND MTR.Codigo IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019') AND ID = @Min;


	SET @Min=@Min+1
END 

SELECT*FROM #Matricula
DROP TABLE #Matricula 