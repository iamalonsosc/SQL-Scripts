CREATE PROCEDURE cAsignacion_BecaActivate   
@IdMatricula INT ,
@pEstado VARCHAR(2) OUTPUT,
@pDescripcion varchar(500) OUTPUT
AS  

BEGIN 
--@IdMatricula2 INT = 460487

	DECLARE @IdActor INT,@IDPeriodoAnterior INT,@ValidaTipoTurno BIT = 1, @ValidaTipoCondicion BIT = 1 , @ValidaRetiro BIT= 1  ,
	@ValidaCambioSede BIT= 1 , @ValidaPagoPuntualBeca BIT= 1 , @ValidaReingreso BIT= 1  ,@CodigoPeriodoAnterior VARCHAR(10),@IdSedeActual INT,@CodigoPeriodo VARCHAR(10),
	@IdUnidadAcademica INT,@IdUnidadNegocio INT,@ExcluidoPorBeca BIT = 0 ,@TipoTurnoActual VARCHAR(15),@TipoCondicionActual VARCHAR(10),@CambioCarreraBeca INT,
	@CompaniaSocio VARCHAR(10),@PromedioBeca REAl,@PeriodosAnterioresConcatenados VARCHAR(MAX),@IdMatricula_Pago  INT, @IdModulo_Pago  INT,@ConsultaCuota  INT,
	@ExcluidoPorPromedio BIT = 0 , @ExcluidoPorTurno BIT = 0 ,@ExcluidoPorCondicion BIT = 0 , @ExcluidoPorRetiro BIT = 0 , @ExcluidoPorCambioSede BIT = 0 , 
	@ExcluidoPorCambioCarrera BIT = 0 , @ExcluidoPorPagoPuntual INT = 0 , @ExcluidoPorReingresante INT = 0 ,@IdProductoCC INT,@ModuloBeca INT,
	@Retorno INT,@IdProductoActual INT,@IdMatriculaAnterior INT,@IdModuloPagoAnterior INT,@ExcluidoPorPeriodoAnterior INT = 0,@IdModuloActual INT,@IdTipoConsulta INT,
	@MantieneBeca BIT=0,@ExcluidoPorNoTenerMatricula BIT = 0 ;

	Declare @PeriodosAnteriores table    
	(CodigoPeriodoPadre varchar(20),    
	CodigoPeriodoAnterior varchar(20),     
	IdPeriodoPadre int,    
	IdPeriodoAnterior int) 

	DECLARE @MatriculaAnterior TABLE (
	IdActor INT,
	IdMatricula INT,
	PromocionCodigo VARCHAR(50),
	PromocionNombre VARCHAR(100),
	IdSede INT,
	IdPeriodo INT,
	Codigo VARCHAR(50),
	IdProducto INT,
	ProductoNombre VARCHAR(100),
	ProductoSubtipo VARCHAR(50),
	GrupoCodigo VARCHAR(50),
	IdGrupo INT,
	IdTurno INT,
	TurnoNombre VARCHAR(100),
	IdTipoTurno INT,
	TipoTurnoDispo5 VARCHAR(50),
	TipoCondicion VARCHAR(50),
	Estado VARCHAR(50),
	MatriculaTipo VARCHAR(50),
	PromedioReal REAL,
	IdModulo INT,
	NombreDescuento VARCHAR(100),
	CodigoDescuento VARCHAR(50),
	IdTipoConsulta INT,
	MantieneBeca BIT);
	
	--  CODIGO DE BASE POR CAMBIO DE TURNO
	DECLARE @IdMaestroRegistroCT INT �
���	SELECT @IdMaestroRegistroCT = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000020' 
	--  CODIGO DE BASE POR CAMBIO DE SEDE
	DECLARE @IdMaestroRegistroCS INT �
���	SELECT @IdMaestroRegistroCS = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000027'
	--  CODIGO DE BASE POR CAMBIO DE CARRERA 
	DECLARE @IdMaestroRegistroCC INT �
���	SELECT @IdMaestroRegistroCC = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000032'
			
END 


-- obtenener los datos de su ultima matricula del alumno
--Obtenemos el periodo padre anterior del alumno
SELECT @CodigoPeriodo=PE.Codigo,
@IdSedeActual=MA.IdSede,
@IdUnidadAcademica=PE.IdUnidadAcademica,
@IdUnidadNegocio=PE.IdUnidadNegocio,
@IdActor=MA.IdActor,
@TipoTurnoActual=MTR.Disponible5,
@TipoCondicionActual=MA.TipoCondicion,
@IdProductoActual= P.IdProducto,
@IdModuloActual = MA.IdModulo
FROM Matricula MA WITH (NOLOCK)
INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo 
INNER JOIN Turno TU WITH(NOLOCK) ON PG.idturno = TU.idturno 
INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.idmaestroregistro=tu.idtipoturno
INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
INNER JOIN PeriodoCabecera PC WITH(NOLOCK) ON PE.IdPeriodoCabecera=PC.IdPeriodoCabecera
WHERE MA.Estado <> 'X' AND P.IdUnidadNegocio = 1  AND MA.IdMatricula = @IdMatricula

--SELECT @CodigoPeriodo,@IdSedeActual,@IdUnidadAcademica,@IdUnidadNegocio,@TipoTurnoActual,@TipoCondicionActual,@IdActor


--obtenemos los periodos anteriores
INSERT INTO @PeriodosAnteriores (CodigoPeriodoPadre,CodigoPeriodoAnterior, IdPeriodoPadre,IdPeriodoAnterior) 
SELECT  DISTINCT PE.Codigo AS 'PADRE',PE2.Codigo AS 'ANTERIOR',PE.IdPeriodo,PE2.IdPeriodo 
FROM PeriodoEquivalencia PEE
INNER JOIN Periodo PE WITH (NOLOCK) ON PEE.IdPeriodoPadre = PE.IdPeriodo
INNER JOIN Periodo PE2 WITH (NOLOCK) ON PEE.IdPeriodoEquivalencia = PE2.IdPeriodo
WHERE PE.Codigo=@CodigoPeriodo  AND PEE.EsSiguiente=0
AND PE.IdUnidadAcademica=@IdUnidadAcademica AND PE.IdUnidadNegocio=@IdUnidadNegocio

--SELECT DISTINCT IdPeriodoAnterior,CodigoPeriodoAnterior FROM @PeriodosAnteriores

-- VALIDAMOS QUE EXISTA PERIODO ANTERIOR --  EN EQUIVALENCIA  - FALTA
	IF  NOT EXISTS(SELECT 1 FROM @PeriodosAnteriores)
	BEGIN
		SET @pEstado = 'KO'
		SET @pDescripcion= 'EL ALUMNO NO REGISTRA PERIODOS ANTERIORES' 
		SET @ExcluidoPorPeriodoAnterior=1
		RETURN
	END

--OBTENEMOS DATOS DE LA MATRICULA ANTERIOR DEL ALUMNO SEGUN EL PERIODO ANTERIOR DE SU MATRICULA ACTUAL
 INSERT INTO  @MatriculaAnterior     
(IdActor,IdMatricula,PromocionCodigo,PromocionNombre ,IdSede,IdPeriodo,Codigo,IdProducto,ProductoNombre,ProductoSubtipo,GrupoCodigo,IdGrupo,IdTurno,
TurnoNombre,IdTipoTurno,TipoTurnoDispo5,TipoCondicion,Estado,MatriculaTipo,PromedioReal,IdModulo,NombreDescuento,CodigoDescuento,IdTipoConsulta,MantieneBeca) 
SELECT DISTINCT MA.IdActor, MA.IdMatricula, P.PromocionCodigo,P.PromocionNombre, P.IdSede ,P.IdPeriodo,PE.Codigo , RE.IdProducto ,PR.ProductoNombre ,PRS.Nombre ProductoSubtipo ,
PG.GrupoCodigo,PG.IdGrupo , TU.IdTurno ,TU.Nombre, TU.IdTipoTurno ,MTR.Disponible5 TipoTurnoDispo5,
CASE WHEN MA.TipoCondicion IN ('CC','RT') THEN 'RT' ELSE 'RE' END MatriculaTipoCondicion,MA.Estado,MA.Tipo MatriculaTipo,PGC.PromedioReal,
P.IdModulo,'','',NULL,0
FROM Matricula MA WITH (NOLOCK)
INNER JOIN Registro RE WITH(NOLOCK) ON RE.IdActor=MA.IdActor AND RE.IdRegistro=MA.IdRegistro
INNER JOIN producto PR WITH(NOLOCK) ON  RE.idproducto = PR.idproducto
INNER JOIN subtipo PRS WITH(NOLOCK) ON  PR.idsubtipo = PRS.idsubtipo 
INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
INNER JOIN PeriodoCabecera PC WITH(NOLOCK) ON PE.IdPeriodoCabecera=PC.IdPeriodoCabecera
INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo 
INNER JOIN Turno TU WITH(NOLOCK) ON PG.idturno = TU.idturno 
INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.idmaestroregistro=tu.idtipoturno
LEFT JOIN PromocionGrupoCierre PGC WITH(NOLOCK) ON MA.IdMatricula = PGC.IdMatricula 
--DESCUENTO DEL ALUMNO
--LEFT JOIN DESCUENTOALUMNORESULTADO DAR WITH(NOLOCK) ON DAR.IdMatricula = MA.IDMATRICULA
--LEFT JOIN DescuentoAcademico PA WITH(NOLOCK) ON PA.IdDescuentoAcademico = DAR.IdDescuentoAcademico 
--LEFT JOIN DescuentoAcademicoPoblacion DAP ON DAP.IdDescuentoAcademico = PA.IdDescuentoAcademico 
--LEFT JOIN MaestroTablaRegistro MTR2 ON MTR2.IdMaestroRegistro = DAB.IdMaestroRegistro 
--AND MTR2.codigo  IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019')
--INNER JOIN DescuentoAcademicoBase DAB WITH(NOLOCK) ON DAB.IdActor = MA.IdActor
--INNER JOIN MaestroTablaRegistro MTR2 ON MTR2.IdMaestroRegistro = DAB.IdMaestroRegistro 
--AND MTR2.codigo  IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019')
WHERE MA.Estado <> 'X' AND P.IdUnidadNegocio = 1 AND MA.IdActor=@IdActor -- AND MTR2.codigo  IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019')
AND PE.IdPeriodo IN (SELECT IdPeriodoAnterior FROM @PeriodosAnteriores)

--SELECT*FROM @MatriculaAnterior

	--IF   EXISTS(SELECT 1 FROM @MatriculaAnterior)
	--BEGIN
	--	 SET @pDescripcion= 'EXCLUIDO POR NO TENER UNA MATRICULA ANTERIOR EN LOS PERIODOS : ' + @PeriodosAnterioresConcatenados
	--	SET @ExcluidoPorNoTenerMatricula=1
	--	RETURN
	--END

	--ACTUALIZAR MATRICULA ANTERIOR CON JOIN MATRICULA ANTERIOR 
	--SI SIGUE ARROJANDO BASIO ES PORQUE NO PERTENECE A LA BASE
	--PUEDE PERTENECER A LA BASE(APLICAR OTRA LOGICA Y VALIDAR)

	--NO EVALUAR POR BASE EN EL TERCER CICLO SINO POR DESCUENTO/BECA EN EL PERIODO ANTERIOR
	--CREAR UNA COLUMNA MAS SI MANTIENE BECA EN EL PERIODO ANTERIOR O NO / UPDATE JOIN A 
	--ALUMNORESULTADO DESCUENTO ACADEMICOBASE SOLO SI PASA DEL IDMOLU > 2 (SOLO SI ESTA EN SU TERCER CICLO)

	UPDATE MA SET MA.NombreDescuento=MTR2.Nombre,
	MA.CodigoDescuento=MTR2.Codigo,
	MA.IdTipoConsulta = MTR2.IdMaestroRegistro
	FROM @MatriculaAnterior AS MA
	INNER JOIN DescuentoAcademicoBase AS DAB WITH(NOLOCK) ON DAB.IdActor = MA.IdActor
	INNER JOIN MaestroTablaRegistro AS MTR2  WITH(NOLOCK) ON MTR2.IdMaestroRegistro = DAB.IdMaestroRegistro 
	WHERE MTR2.Codigo IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019')

	UPDATE MA SET MA.MantieneBeca= 1
	FROM @MatriculaAnterior AS MA
	--INNER JOIN DescuentoAcademicoBase AS DAB WITH(NOLOCK) ON DAB.IdActor = MA.IdActor
	INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON DAR.IdMatricula = MA.IdMatricula
	INNER JOIN DescuentoAcademico AS DA WITH(NOLOCK) ON DA.IdDescuentoAcademico = DAR.IdDescuentoAcademico
	INNER JOIN DescuentoAcademicoPoblacion DAP ON DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico AND MA.IdTipoConsulta=DAP.IdTipoSituacionAlumno
	--POR TERMINAR EL UPDATE

	--SELECT*FROM @MatriculaAnterior
	--RETURN

	SELECT @CompaniaSocio= CompaniaSocio FROM Empresa
	--Validamos Pago puntual en su carrera
	SET @IdMatriculaAnterior = NULL 
	SET @IdModuloPagoAnterior = NULL 

	SELECT @IdMatriculaAnterior = IdMatricula , @IdModuloPagoAnterior = CASE WHEN IdModulo = 1 THEN 2 ELSE 1 END FROM @MatriculaAnterior 

	SELECT TOP 1 @IdTipoConsulta=IdTipoConsulta FROM @MatriculaAnterior

	SELECT @PromedioBeca = Disponible1,@CambioCarreraBeca=Disponible3,@ModuloBeca=Disponible5,@ValidaRetiro=Disponible2,
	@ValidaCambioSede=Disponible4,@ValidaTipoCondicion=Disponible6,@ValidaPagoPuntualBeca=Disponible7,@ValidaTipoTurno= Disponible8,
	@ValidaReingreso = Disponible9 FROM MaestroTablaRegistro WITH(NOLOCK) 
	WHERE  IdmaestroRegistro = @IdTipoConsulta	
	

	-- Almacenar los resultados de la consulta en la variable @Resultados
	--convert en vez de cast
	SELECT @PeriodosAnterioresConcatenados = COALESCE(@PeriodosAnterioresConcatenados + ', ', '') + CAST(CodigoPeriodoAnterior AS VARCHAR(50))
	FROM (SELECT DISTINCT CodigoPeriodoAnterior FROM @PeriodosAnteriores) AS Temp

	--INICIAMOS LAS VALIDACIONES

BEGIN
	-- Validamos que la matricula tenga una matricula anterior
	IF  NOT EXISTS(SELECT 1 FROM @MatriculaAnterior)
	BEGIN
		SET @pEstado = 'KO'
		SET @pDescripcion= 'EXCLUIDO POR NO TENER UNA MATRICULA ANTERIOR EN LOS PERIODOS : ' + @PeriodosAnterioresConcatenados
		SET @ExcluidoPorNoTenerMatricula=1
		RETURN
	END

	-- VALIDAR SI TIENE BECA ACTIVATE EN LA MATRICULA ANTERIOR 
	IF NOT EXISTS(SELECT 1 FROM @MatriculaAnterior WHERE COALESCE(CodigoDescuento, '') != '')
	BEGIN
		DECLARE @CodigoTemporal VARCHAR(50)
		SELECT TOP 1 @CodigoTemporal = Codigo FROM @MatriculaAnterior
		SET @pEstado = 'KO'
		SET @pDescripcion='EXCLUIDO POR NO CONTAR CON LA BECA ACTIVATE EN SU MATRICULA ANTERIOR EN EL PERIODO : ' + @CodigoTemporal
		SET @ExcluidoPorBeca=1
		RETURN
	END

	-- VALIDAR SI TIENE CAMBIO DE TURNO 
	IF NOT EXISTS( SELECT 1 FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor 
	AND IdMaestroRegistro = @IdMaestroRegistroCT AND B.Activo = 1 AND PeriodoCodigo=@CodigoPeriodo)
	BEGIN
		IF EXISTS(SELECT 1 FROM @MatriculaAnterior WHERE @TipoTurnoActual <> TipoTurnoDispo5)
		BEGIN
			SET @pEstado = 'KO'
			SET @pDescripcion= 'EXCLUIDO POR TURNO' 
			SET @ExcluidoPorTurno=1
			RETURN
		END
	END

	-- VALIDAR SI TIENE CAMBIO DE CARRERA
	IF NOT EXISTS( SELECT 1 FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor 
	AND IdMaestroRegistro = @IdMaestroRegistroCC AND B.Activo = 1 AND PeriodoCodigo=@CodigoPeriodo)
	BEGIN
		IF  EXISTS(SELECT 1 FROM @MatriculaAnterior WHERE @IdProductoActual <> IdProducto )
		BEGIN
			SET @pEstado = 'KO'
			SET @pDescripcion= 'EXCLUIDO POR CAMBIO DE CARRERA' 
			SET @ExcluidoPorCambioCarrera=1
			RETURN
		END
	END

	-- VALIDAR SI TIENE CAMBIO DE TIPO CONDICION
	IF   @TipoCondicionActual <> 'RE' 
	BEGIN
		SET @pEstado = 'KO'
		SET @pDescripcion= 'EXCLUIDO POR CAMBIO DE TIPO DE CONDICION EN SUS MATRICULAS(NO REGULAR)' 
		SET @ExcluidoPorCondicion=1
		RETURN
	END

	-- Validamos que no tenga retiro de ciclo en su carrera
	IF EXISTS(SELECT 1 FROM MatriculaRetiro WITH(NOLOCK) WHERE IdActor = @IdActor AND Estado = 'R' 
	AND Tipo = 'RC' AND (IdMatricula IN (SELECT IdMatricula FROM @MatriculaAnterior)OR EXISTS(SELECT 1 FROM @MatriculaAnterior WHERE Estado = 'R')))
	BEGIN
		SET @pEstado = 'KO'
		SET @pDescripcion='EXCLUIDO POR RETIRO DE CICLO'
		SET @ExcluidoPorRetiro=1
		RETURN
	END

	-- Validamos que su promedio sea mayor a 18 en su carrera
	IF EXISTS(SELECT 1  FROM @MatriculaAnterior WHERE  PromedioReal<@PromedioBeca AND @IdModuloActual>2 AND @IdTipoConsulta=29058) -- VARIABLE OBTENER DE LA TABLA 
	BEGIN
		-- si tu beca es TIP0000013	NULL	BECA AMERICA TV SECUENCIAL 50% X 2 CICLOS 
		--  y modulo > 2  no validamos por primedio 
		SET @pEstado = 'KO'
		SET @pDescripcion= 'EXCLUIDO POR PROMEDIO'
		SET @ExcluidoPorPromedio = 1
		RETURN
	END

	IF ( @IdTipoConsulta=29058)
	BEGIN
		IF  EXISTS(SELECT 1  FROM @MatriculaAnterior WHERE  PromedioReal<@PromedioBeca AND @IdModuloActual<2)
		BEGIN
			SET @pEstado = 'KO'
			SET @pDescripcion= 'EXCLUIDO POR PROMEDIO Y MODULO MAYOR A 2'
			SET @ExcluidoPorPromedio = 1
			RETURN
		END
	END

	-- Validamos que no tenga cambio de sede en su carrera

	IF NOT EXISTS( SELECT 1 FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor 
	AND IdMaestroRegistro = @IdMaestroRegistroCS AND B.Activo = 1 AND PeriodoCodigo=@CodigoPeriodo) 
	BEGIN
		IF EXISTS(SELECT 1 FROM @MatriculaAnterior WHERE @IdSedeActual <> IdSede)
		BEGIN
			SET @pEstado = 'KO'
			SET @pDescripcion= 'EXCLUIDO POR CAMBIO DE SEDE'
			SET @ExcluidoPorCambioSede=1
			RETURN
		END
	END

	SET @ExcluidoPorPagoPuntual=ISNULL((SELECT dbo.cPagoPuntual (@IdActor,@CompaniaSocio,@IdMatriculaAnterior, @IdModuloPagoAnterior)),0)

	--SELECT @ExcluidoPorPagoPuntual
	IF @ExcluidoPorPagoPuntual = 1 
	BEGIN
		-- si tu beca es TIP0000013	NULL	BECA AMERICA TV SECUENCIAL 50% X 2 CICLOS 
		--  y modulo > 2  no validamos por promedio 
		SET @pEstado = 'KO'
		SET @pDescripcion= 'EXCLUIDO POR PAGO PUNTUAL'
		RETURN
	END


	IF ( @IdTipoConsulta=29058)
	BEGIN
		IF  @ExcluidoPorPagoPuntual = 1  AND @IdModuloActual<2
		BEGIN
			SET @pEstado = 'KO'
			SET @pDescripcion= 'EXCLUIDO POR PAGO PUNTUAL'
			RETURN
		END
	END 
	ELSE IF (@ExcluidoPorPagoPuntual = 1 )
		BEGIN
			SET @pEstado = 'KO'
			SET @pDescripcion= 'EXCLUIDO POR PAGO PUNTUAL'
			RETURN
		END

	IF @ExcluidoPorRetiro = 0 
	AND @ExcluidoPorBeca=0
	AND @ExcluidoPorTurno=0
	AND @ExcluidoPorCambioCarrera=0
	AND @ExcluidoPorCondicion=0
	AND @ExcluidoPorPromedio=0
	AND @ExcluidoPorCambioSede=0
	BEGIN	
		SET @pEstado = 'OK'
		SET @pDescripcion= 'SI LE CORRESPONDE EL DESCUENTO'
		RETURN								 		
	END
		

END