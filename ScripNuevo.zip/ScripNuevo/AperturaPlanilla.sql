UPDATE PlanillaCalendarioSede SET ESTADO='G',UsuarioModificacion=1,FechaModificacion=GETDATE() 
WHERE IDSEDE=38 AND IdPlanillaCalendario=62�AND�ESTADO='E'
--(1 row affected)


--select estado,pc.Nombre,pcs.*,u.Login from planillacalendario pc
--inner join planillacalendariosede pcs ON PCS.IdPlanillaCalendario = PC.IdPlanillaCalendario 
--inner join usuario u on pcs.UsuarioModificacion=u.IdUsuario
--where PCS.IdSede = 38  and�pc.anio=2024