--DECLARE @IdMatriculaAntigua INT=610455,@IdAlumno INT=1258368,@IdMatriculaNueva INT

UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (610455,647325,699051,751058)

UPDATE Registro SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdActor=1258368 AND IdRegistro IN (2,3,4)

--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1258368 AND IdRegistro=1 AND IdCurso=9807 AND IdCurricula=8


SELECT*FROM AlumnoCurso 
WHERE IdAlumno=1258368 AND IdCurso in (10246)--IdMatricula=612427

--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=46
WHERE IdMatricula=779025 AND IdCurso=9807
--(1 fila afectada)


--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=5,IdAlumnoCurso=1,IdcurriculaOriginal=5607
WHERE IdMatricula=610455 AND IdCurso=9807



--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='D',PromedioFinal='11.00',PromedioReal='11.44',IdAlumnoCurso=1,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1258368 AND IdRegistro=5 AND IdCurso=9807 AND IdCurricula=5607


--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=5,IdCurricula=5607
WHERE IdMatricula=610455

UPDATE Matricula SET Estado='N'
WHERE IdMatricula IN (647325,699051,751058)

UPDATE Registro SET Estado='N'--,IdRegistro=8,IdCurricula=5612
WHERE IdActor=1258368 AND IdRegistro IN (2,3,4)

-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO

UPDATE Matricula SET Estado='X'
WHERE IdMatricula=779025