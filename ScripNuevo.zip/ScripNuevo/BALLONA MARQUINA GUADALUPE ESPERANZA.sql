--SELECT TipoCondicion,*FROM Matricula 
----UPDATE Matricula SET TipoCondicion='RE'
--where IdMatricula=685291


--SELECT TipoCondicion,*FROM AlumnoCurso 
UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=685291 AND EsMatricula=1 


----RP(PROMOVIDO + CURSO)
------CC(CURSO REPITENCIA)
------RT(REPITENCIA)
------RE(PROMOVIDO)
--SELECT*FROM AlumnoCursoNomina WHERE IdMatricula=681366