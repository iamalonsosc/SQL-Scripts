--SELECT*FROM Curricula WHERE NombrePlanEstudio is not null

UPDATE Curricula SET NombrePlanEstudio='Plan 2023'
WHERE NombrePlanEstudio='PLAN 2023'
--(16 rows affected)