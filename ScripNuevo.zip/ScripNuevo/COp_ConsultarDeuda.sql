---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--CREATE Procedure dbo.COp_ConsultarDeuda
/*  
'**********************************************************************************  
'* Permite obtener las deudas pendientes que tienen el cliente con IPAE  
'* Input :  
'*          @pCodigoProducto - Corresponde al c�digo de servicio que tiene el cliente (IPAE) con el banco        
'*          @pTipoConsulta - Indica el criterio de consulta de la deuda del cliente        
'*                           1 = Documento de identidad (DNI, Carn� de Extranjer�a, Pasaporte, etc.)        
'*                           2 = N�mero de RUC del cliente        
'*          @pIdConsulta - Indica el N�mero de Documento de identidad o N�mero de RUC seg�n se haya indicado en el par�metro anterior        
'* Output : <vacio>  
'* Creado por : Joel Chaccha C.  
'* Fec Creaci�n : 01/12/2014  
'* Fec Actualizaci�n : 18/03/2015 Responsable : Joel Chaccha C�ndor  
'* Motivo : Se adiciono las areas 02 y 48 a las cuales se le aplicara un descuento.  
'*   
'* Fec Actualizaci�n : 14/04/2015 Responsable : Joel Chaccha C�ndor  
'* Motivo : Se adiciono una tabla de descuentos para las areas 02 y 48 (PC y PE)     
'*    
'* Fec Actualizaci�n : 19/06/2020 Responsable : Walter Roman       
'* Motivo : Se agrego como parametro la compa�ia.    
            Se agrego el calculo de la Mora para Idat.    
            Se optimizo los script.    
            Calculo de pago minimo 1.00 sol para Idat.    
'*  @01 06/09/2021 Walter roman cruce DNI RUC  
'*   
'* Fec Actualizaci�n : 14/01/2022 Responsable : Joel Chaccha C�ndor  
'* Motivo : Se adiciono la empresa Corriente Alterna  
'* Fec Actualizaci�n : 23/11/2022 Responsable : Jhonny Cure  
'* Motivo : Se amplio la longitud de la tabla temporal,linea 155  
'* Fec Actualizaci�n : 21/05/2024 Responsable : Joel Chaccha
'* Motivo: Mantener interes personalizado para las Sucursales SECA y SECV (de Corriente Alterna)
'**********************************************************************************  
*/    
DECLARE
--(
   @pCodigoProducto varchar(3),    
   @pTipoConsulta varchar(1),    
   @pIdConsulta varchar(14),    
   @pCompaniaSocio char(8)    
--)    
--As    
SELECT @pCodigoProducto=N'001',@pTipoConsulta=N'1',@pIdConsulta=N'73817082',@pCompaniaSocio=N'00002700'
Begin    
   Set NoCount On    
     
   --If (Select Count(*)   
   --    From sys.databases   
   --    Where Name = 'bdadmin' And state = 0) > 0  
   --   If Exists (Select *   
   --              From Bdadmin.dbo.sysobjects   
   --              Where name = 'CO_RegistroTrama' and xtype = 'U')      
   --   Begin  
   --      Insert Into Bdadmin.dbo.CO_RegistroTrama  
   --      (  
   --         TipoTrama, FechaTrama, CodigoProducto, TipoConsulta, IdConsulta  
   --      )  
   --      Select 'CD', GetDate(), @pCodigoProducto, @pTipoConsulta, @pIdConsulta  
   --   End  
  
   Declare @w_rows bigint, @k bigint, @w_count bigint       
   Declare @w_estado varchar    
   Declare @w_flag varchar    
   Declare @w_fechavencimiento datetime    
   Declare @w_mora money, @w_igv decimal, @w_totalmora money
   Declare @w_factor Decimal, @w_factorcompra Decimal, @w_factorventa Decimal, @w_factorpromedio Decimal    
   Declare @w_factorventasbs Decimal, @w_factorcomprasbs Decimal    
   Declare @w_datetime DateTime    
   Declare @w_datestring varchar    
   Declare @vNumeroDocumento varchar(14)    
   Declare @vTipoDocumento char(2)    
   declare @w_MoraAdmDia decimal    
   declare @w_MoraAdmMto decimal    
   Declare @w_NotaCreditoDocumento varchar(17)    
   Declare @vMontoPagado money    
   Declare @w_dias int    
   Declare @w_moraporce decimal    
   Declare @w_percent decimal    
   Declare @vIdPersona int    
   Declare @vCompaniaSocio char(8)    
   Declare @vMonedaDocumento char(2)    
   Declare @vMontoTotal money    
   Declare @vFechaDocumento datetime    
   Declare @vClienteNumero int    
   Declare @vInterfase_Area char(2)    
   Declare @vInterfase_Descuento char(6)    
   Declare @vMontoDescuento money    
   Declare @vPorcentageDescuento money    
Declare @vUnidadNegocio char(4)  
   Declare @vGrupoDescuento int  
   Declare @vGrupoTipo int      
   Declare @vCaptacion char(1)       
   Declare @vCampana char(10)       
   Declare @vTipoFacturacion char(3)      
   Declare @vCompania Char(6)    
   Declare @vCompaniaMora Char(6)    
   Declare @vPorcentajeNew Money    
                
   --Creaci�n de Tablas temporales          
   Create Table #tmpConsultaDeuda          
   (          
      CodigoProducto varchar(3) Collate DataBase_Default,          
      NumDocumento varchar(16) Collate DataBase_Default,          
      DescDocumento varchar(20) Collate DataBase_Default,          
      FechaVencimiento varchar(8) Collate DataBase_Default,          
      FechaEmision varchar(8) Collate DataBase_Default,          
      Deuda decimal(12,2),          
      Mora decimal(12,2),          
      GastosAdm decimal(12,2),          
      PagoMinimo decimal(12,2),          
      Periodo varchar(2) Collate DataBase_Default,          
      Anio varchar(4) Collate DataBase_Default,          
      Cuota varchar(2) Collate DataBase_Default,          
      MonedaDoc varchar(1) Collate DataBase_Default,
      UnidadNegocio char(4) Collate DataBase_Default,      
   )          
            
   Create Table #tmpDeuda          
   (          
      Id int Identity(1,1),          
      CompaniaSocio char(8) Collate DataBase_Default,           
      TipoDocumento char(2) Collate DataBase_Default,           
      NumeroDocumento char(14) Collate DataBase_Default,           
      Estado char(2) Collate DataBase_Default,           
      FechaDocumento datetime,           
      ClienteNombre char(60) Collate DataBase_Default,           
      MonedaDocumento char(2) Collate DataBase_Default,           
      MontoTotal money,           
      ImpresionPendienteFlag char(1) Collate DataBase_Default,           
      FechaVencimiento datetime,           
      MontoPagado money,           
      MontoNoAfecto money,           
      AprobadoPor int,           
      FechaAprobacion datetime,           
      ClienteCobrarA int,           
      Busqueda char(50) Collate DataBase_Default,           
      Sucursal char(4) Collate DataBase_Default,           
      Clasificacion char(2) Collate DataBase_Default,          
      ClienteNumero int,          
      FormadePago char(3) Collate DataBase_Default,          
      NotaCreditoDocumento char(17) Collate DataBase_Default,          
      MontoDescuentos money,          
      MontoAfecto money,          
      MontoImpuestoVentas money,          
      MontoImpuestos money,                        
      Comentarios char(1000) Collate DataBase_Default,   
      CampoReferencia char(12) Collate DataBase_Default,          
      NumeroInterno char(15) Collate DataBase_Default,          
      VoucherPeriodo char(6) Collate DataBase_Default,          
      Mora money,          
      Descripcion varchar(255) Collate DataBase_Default,          
      UnidadReplicacion char(4) Collate DataBase_Default,          
      Interfase_Area char(2) Collate DataBase_Default,          
      Interfase_Descuento char(6) Collate DataBase_Default,          
      MontoMinimo money,        
      UnidadNegocio char(4) Collate DataBase_Default,      
      GrupoDescuento int,      
      GrupoTipo int,      
      Captacion char(1) Collate DataBase_Default,      
      Campana char(10) Collate DataBase_Default,      
      TipoFacturacion char(3) Collate DataBase_Default      
   )          
       
   Create table #tmpDescuento    
   (    
      MontoDescuento money    
   )    
          
   Set @vIdPersona = Null          
   Set @vCompaniaSocio = @pCompaniaSocio       
       
   If @pTipoConsulta =1    
   Begin    
     Select TOP 1 @vIdPersona = Persona          
     From PersonaMast With (NoLock)       
     Where Documento LIKE LEFT(@pIdConsulta,8)+'%' And Estado = 'A' And (EsOtro = 'S' Or EsCliente = 'S') And 
          TipoDocumento<>'R'  --@01  
     Order By Busqueda      
	 
	 PRINT @vIdPersona 
   End     
   ELSE    
   BEGIN    
      Select @vIdPersona = Persona          
      From PersonaMast With (NoLock)           
      Where Case   
               When @pTipoConsulta = '1' Then Documento          
               When @pTipoConsulta = '2' Then DocumentoFiscal          
            End = @pIdConsulta And Estado = 'A' And (EsOtro = 'S' Or EsCliente = 'S') And TipoDocumento='R'  --@01  
     Order By Busqueda            
   END
    SELECT @vIdPersona,'@vIdPersona'
   If (@pCodigoProducto In ('001', '004', '005'))  
   Begin  
   PRINT 'HOLA'
      --Consultamos las deudas del cliente de SEE        
      Insert Into #tmpDeuda          
      (          
         CompaniaSocio, TipoDocumento, NumeroDocumento, Estado, FechaDocumento, ClienteNombre, MonedaDocumento, MontoTotal,           
         ImpresionPendienteFlag, FechaVencimiento, MontoPagado, MontoNoAfecto, AprobadoPor, FechaAprobacion, ClienteCobrarA,         
         Busqueda, Sucursal, Clasificacion, ClienteNumero, FormadePago, NotaCreditoDocumento, MontoDescuentos, MontoAfecto,           
         MontoImpuestoVentas, MontoImpuestos, Comentarios, CampoReferencia, NumeroInterno, VoucherPeriodo, Mora, Descripcion,           
         UnidadReplicacion, Interfase_Area, Interfase_Descuento, UnidadNegocio, GrupoDescuento, GrupoTipo, Captacion, Campana,      
         TipoFacturacion      
      )          
      Select Doc.CompaniaSocio, Doc.TipoDocumento, Doc.NumeroDocumento, Doc.Estado, Doc.FechaDocumento,           
             Doc.ClienteNombre, Doc.MonedaDocumento, Doc.MontoTotal - Doc.MontoPagado, Doc.ImpresionPendienteFlag, Doc.FechaVencimiento,           
             Doc.MontoPagado, Doc.MontoNoAfecto, Doc.AprobadoPor, Doc.FechaAprobacion, Doc.ClienteCobrarA,           
             Per.Busqueda, Doc.Sucursal, Tip.Clasificacion, Doc.ClienteNumero, Doc.FormadePago,           
             Doc.NotaCreditoDocumento, Doc.MontoDescuentos, Doc.MontoAfecto, Doc.MontoImpuestoVentas,           
             Doc.MontoImpuestos, Doc.Comentarios, Doc.CampoReferencia, Doc.NumeroInterno, Doc.VoucherPeriodo, 0.00, docdet.Descripcion, Doc.UnidadReplicacion,          
             Doc.Interfase_Area, Doc.Interfase_Descuento, Doc.UnidadNegocio, Doc.Interfase_GrupoDescuento, Doc.GrupoTipo,      
             Doc.interfase_captacion, Doc.Interfase_Campana, Doc.TipoFacturacion      
      From CO_Documento Doc With (NoLock)           
      Inner Join PersonaMast Per With (NoLock) On Doc.ClienteCobrarA = Per.Persona           
      Inner Join CO_TipoDocumento Tip With (NoLock) On Doc.TipoDocumento = Tip.TipoDocumento           
      Inner Join CO_DocumentoDetalle docdet With (NoLock) On docdet.CompaniaSocio = Doc.CompaniaSocio And docdet.TipoDocumento = Doc.TipoDocumento And docdet.NumeroDocumento = Doc.NumeroDocumento And docdet.Linea = docdet.Linea and docdet.itemcodigo <> '4010100010' And docdet.Linea = 1          
      Where ((Doc.CompaniaSocio = @vCompaniaSocio) And            
             --(Doc.MontoTotal  <> Doc.MontoPagado) And     
             --(doc.Interfase_grupodescuento <> 1905 or doc.Interfase_grupodescuento is null ) And  
            --(Doc.TipoDocumento <> '') And                    
            --(Doc.Estado In ('PR','AP')) And                    
             (Doc.ClienteNumero = @vIdPersona))-- And       --Doc.ClienteCobrarA = @vIdPersona          
             --(Doc.NumeroDocumento >= '') And                    
             --(Doc.UnidadNegocio in ('SEAQ','SECA','SECH','SECU','SEHU','SEOL','SEPI','SEPU','SESU','SETA','SETR', 'SECE')) And   --'SECE'          
             --(Tip.Clasificacion Not In ('PE','LE')))  And           
            --(Doc.TipoDocumento <> 'PE') And (Tip.Clasificacion = 'DC')          
      Union All          
      Select Doc.CompaniaSocio, Doc.TipoDocumento, Doc.NumeroDocumento, Doc.Estado, Doc.FechaDocumento,           
             Doc.ClienteNombre, Doc.MonedaDocumento, Doc.MontoTotal, Doc.ImpresionPendienteFlag, Doc.FechaVencimiento,           
             Doc.MontoPagado, Doc.MontoNoAfecto, Doc.AprobadoPor, Doc.FechaAprobacion, Doc.ClienteCobrarA,           
             Per.Busqueda, Doc.Sucursal, Tip.Clasificacion, Doc.ClienteNumero, Doc.FormadePago,           
             Doc.NotaCreditoDocumento, Doc.MontoDescuentos, Doc.MontoAfecto, Doc.MontoImpuestoVentas,           
             Doc.MontoImpuestos, Doc.Comentarios, Doc.CampoReferencia, Doc.NumeroInterno, Doc.VoucherPeriodo, 0.00, docdet.Descripcion, Doc.UnidadReplicacion,          
             Doc.Interfase_Area, Doc.Interfase_Descuento, Doc.UnidadNegocio, Doc.Interfase_GrupoDescuento, Doc.GrupoTipo,      
             Doc.interfase_captacion, Doc.Interfase_Campana, Doc.TipoFacturacion      
      From CO_Documento Doc With (NoLock)      
      Inner Join PersonaMast Per With (NoLock) On Doc.ClienteCobrarA = Per.Persona           
      Inner Join CO_TipoDocumento Tip With (NoLock) On Doc.TipoDocumento = Tip.TipoDocumento           
      Inner Join CO_DocumentoDetalle docdet With (NoLock) On docdet.CompaniaSocio = Doc.CompaniaSocio And          
                                       docdet.TipoDocumento = Doc.TipoDocumento And docdet.NumeroDocumento = Doc.NumeroDocumento And           
                                       docdet.Linea = docdet.Linea And docdet.Linea = 1          
      Where ((Doc.CompaniaSocio = @vCompaniaSocio) and           
             --(Doc.MontoTotal  <> Doc.MontoPagado) and           
             --(Doc.TipoDocumento <> '') and           
            -- (Doc.Estado = 'AP') and           
             (Doc.ClienteNumero = @vIdPersona) )--and --Doc.ClienteCobrarA = @vIdPersona or          
             --(Doc.NumeroDocumento >= ''))-- and              
             --(Doc.UnidadNegocio In ('SEAQ','SECA','SECH','SECU','SEHU','SEOL','SEPI','SEPU','SESU','SETA','SETR', 'SECE')))  AND      --'SECE'          
            --(Doc.TipoDocumento = 'PE')  AND           
            --(FormaFacturacion <> 'GF')           
      Order By Doc.FechaVencimiento asc, Doc.TipoDocumento Desc--,  Doc.NumeroDocumento Asc          
              
      Set @w_rows = @@RowCount          
   End  
  

  SELECT * FROM #tmpDeuda
  DROP TABLE #tmpDeuda
  DROP TABLE #tmpConsultaDeuda
  Drop Table #tmpDescuento  
  RETURN
    --Obteniendo IGV  
   Set @w_igv = (18.0 + 100.0) / 100.0                    
   Set @w_datetime = GetDate()          
   Set @w_datestring = Convert(varchar(8), @w_datetime, 112)          
             
   Select @w_factor = tc.Factor,           
          @w_factorcompra = tc.FactorCompra,           
          @w_factorventa = tc.FactorVenta,           
          @w_factorpromedio = tc.FactorPromedio,           
          @w_factorventasbs = tc.FactorCompraSBS,           
          @w_factorcomprasbs =tc.FactorVentaSBS,           
          @w_estado = tc.Estado                    
   From TipoCambioMast tc With (NoLock)          
   Where ( tc.MonedaCodigo = 'EX' ) and                    
         ( tc.MonedaCambioCodigo = 'LO' ) and                    
         ( tc.FechaCambioString = @w_datestring )             
                
   If (@w_estado <> 'A')          
   Begin          
      -- Messagebox('Tipo de Cambio No Activo ' + par_rate_type,"Dia " + string(par_date,"dd-mm-yyyy"))          
      --No Retornar nada          
      Set @w_estado = 'I'          
   End          
            
   Set @vNumeroDocumento = ''          
   Set @vTipoDocumento = ''          
   Set @k = 1          
   Set @w_totalmora = 0                     
   Set @vInterfase_Area = ''          
   Set @vInterfase_Descuento = ''      
   Set @vTipoFacturacion = ''      
             
   While (@k <= @w_rows)          
   Begin          
      --Extra el monto de la deuda          
      Select @vNumeroDocumento = RTrim(NumeroDocumento),          
             @vTipoDocumento = TipoDocumento,          
             @w_NotaCreditoDocumento = TipoDocumento + '-' + RTrim(NumeroDocumento),          
             @w_fechavencimiento = FechaVencimiento,          
             @vMontoPagado = MontoPagado,                       
             @vClienteNumero = ClienteNumero,          
             @vFechaDocumento = FechaDocumento,           
             @vMontoTotal = MontoTotal,          
             @vMonedaDocumento = MonedaDocumento,          
             @vInterfase_Area = Interfase_Area,          
             @vInterfase_Descuento = Interfase_Descuento,        
             @vUnidadNegocio = UnidadNegocio,      
             @vGrupoDescuento = GrupoDescuento,      
             @vGrupoTipo = GrupoTipo,      
             @vCaptacion = Captacion,      
             @vCampana = Campana,      
             @vTipoFacturacion = TipoFacturacion      
      From #tmpDeuda          
      Where Id = @k       
          
      --Set @w_totalmoraadm = 0          
      Set @w_totalmora = 0        
                
      --Validar si el tipo de documento es PE o PC          
      If (@vTipoDocumento = 'PE' Or @vTipoDocumento = 'PC')          
      Begin    
         --Verificamos si aplica un descuento          
         Set @vMontoDescuento = 0          
         Set @vPorcentageDescuento = 0           
    
         Insert Into #tmpDescuento    
         (    
            MontoDescuento    
         )    
         Exec dbo.COp_CalcularDescuentoSpring @vUnidadNegocio, @vInterfase_Area, @vCaptacion, @vTipoDocumento, @vTipoFacturacion, @vGrupoDescuento, @vCampana, @vMontoTotal,@pCompaniaSocio, @vMontoDescuento OutPut    
                     
         --Actualizamos el monto a cobrar          
         If (@vMontoDescuento > 0.00)          
         Begin          
            Update #tmpDeuda          
            Set MontoTotal = Round(MontoTotal - @vMontoDescuento, 0)          
            Where Id = @k              
         End          
                   
         --Actualizamos el Monto Minimo          
         Update #tmpDeuda          
         Set MontoMinimo = MontoTotal          
         Where Id = @k          
                           
         --Registramos en Tabla Log de Pagos en Linea          
         If Exists(Select * From CO_RegistroPagoLinea With (NoLock) Where CompaniaSocio = @vCompaniaSocio And TipoDocumento = @vTipoDocumento And NumeroDocumento  = @vNumeroDocumento)          
         Begin          
            --Se actualiza los datos de consulta en el log          
            Update CO_RegistroPagoLinea          
            Set ClienteNumero = @vClienteNumero,          
                FechaEmision = @vFechaDocumento,           
                FechaVencimiento = @w_fechavencimiento,          
                MontoTotal = @vMontoTotal,          
                MontoMora = 0,          
                MontoDescuento = @vMontoDescuento,          
                Moneda = @vMonedaDocumento,          
                FlagConsultado = 1,          
                FechaConsulta = GetDate(),          
                TipoConsulta = @pTipoConsulta,          
                IdConsulta = @pIdConsulta          
            Where CompaniaSocio = @vCompaniaSocio And TipoDocumento = @vTipoDocumento And NumeroDocumento  = @vNumeroDocumento          
         End          
         Else          
         Begin          
            --Se Inserta un nuevo registro log          
            Insert Into CO_RegistroPagoLinea          
            (          
               CompaniaSocio, TipoDocumento, NumeroDocumento, ClienteNumero, FechaEmision, FechaVencimiento, MontoTotal, MontoMora, Moneda,           
               FlagConsultado, FechaConsulta, FlagNotificacionPago, FlagPagoAnulado, TipoConsulta, IdConsulta, UnidadReplicacion,          
               MontoDescuento          
            )  
            Select CompaniaSocio, TipoDocumento, RTrim(NumeroDocumento), ClienteNumero, FechaDocumento, FechaVencimiento, @vMontoTotal, 0, MonedaDocumento,          
                   1, GetDate(), 0, 0, @pTipoConsulta, @pIdConsulta, UnidadReplicacion, @vMontoDescuento          
            From #tmpDeuda          
            Where Id = @k          
         End          
      End          
      Else          
      Begin          
         --Se verifica si es documento MORA          
         If (@vNumeroDocumento <> 'MORA')          
         Begin          
            --Se verifica si el tipo de documento es donaci�n          
            If (@vTipoDocumento <> 'DO')          
            Begin          
               Set @w_mora = 0.00          
               Set @w_count = 0          
               Set @w_flag = ''          
               --Set @w_totalmoraadm = 0          
               Set @w_totalmora = 0          
               Set @w_moraporce = 0.00          
               Set @w_percent = 0.00          
               
               --Calculo de la 1ra Mora          
               Set @w_dias = DateDiff(day, @w_fechavencimiento, @w_datetime)          

               If (@w_dias > 0) --Ya vencio          
               Begin        
                  --Porcentaje Mensual de Mora      
                  set @vCompania =Left(@pCompaniaSocio,6)                                
                        
                  Select @w_moraporce = Numero           
                  From ParametrosMast With (NoLock)            
                  Where CompaniaCodigo = '999999' AND AplicacionCodigo ='CO' AND ParametroClave ='MORA%'
         
                  Set @w_percent = Power(((@w_moraporce / 100.00) + 1.00), (1.00/30.00)) - 1.00 --Tasa diaria          
                  Set @w_percent = Power((@w_percent + 1.00), @w_dias) - 1.00                                    
                  Set @w_mora = round(@vMontoPagado * @w_percent, 2)          
                               
                  If (@w_mora < 0.00)          
                  Begin          
                     Set @w_mora = 0.00        
                  End     
          
                  --Solo aplica para IDAT  
                  If (@pCompaniaSocio In ('00002700', '00002600') Or (@pCompaniaSocio = '00002500' And @vUnidadNegocio In ('SECA', 'SECV')))
                  Begin                     
                     Set @vCompania =Left(@pCompaniaSocio,6)         
                     
                     If (@pCompaniaSocio <> '00002500')
                     Begin
                        Select @vPorcentajeNew = Numero           
                        From ParametrosMast With (NoLock)         
                        Where CompaniaCodigo = @vCompania AND AplicacionCodigo ='CO' AND ParametroClave ='MORAXDIA'
                     End
                     Else
                     Begin
                        Select @vCompaniaMora = Left('00002600',6)         

                        Select @vPorcentajeNew = Numero           
                        From ParametrosMast With (NoLock)         
                        Where CompaniaCodigo = @vCompaniaMora AND AplicacionCodigo ='CO' AND ParametroClave ='MORAXDIA'                        
                     End
                       
                     If (@pCompaniaSocio = '00002700')  
                     Begin  
                        Set @vPorcentajeNew = @vPorcentajeNew /100                
                        Set @w_mora = Round(@vMontoTotal * @w_dias * @vPorcentajeNew / 100,2)    
         
                        If (@w_mora < 0.00)          
                        Begin          
                           Set @w_mora = 0.00     
                        End     
                     End  
                     Else  
                     Begin  
                        Set @w_mora = @vPorcentajeNew * @w_dias                          
                     End  
                  End     
               End          
                         
               Set @w_totalmora = @w_totalmora + @w_mora                   
              
               If (@pCompaniaSocio = '00002500' And Not @vUnidadNegocio In ('SECA', 'SECV'))      --Zegel  
               Begin         
                  --Nro de dias para cobrar 2da mora          
                  Select @w_MoraAdmDia = ParametrosMast.Numero          
                  From ParametrosMast With (NoLock)           
                  Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND ( ParametrosMast.AplicacionCodigo ='CO' ) AND ( ParametrosMast.ParametroClave ='MORAADMDIA' )           
                         
                  --Monto para cobrar 2da Mora          
                  Select @w_MoraAdmMto = ParametrosMast.Numero         
                  From ParametrosMast With (NoLock)         
                  Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND ( ParametrosMast.AplicacionCodigo ='CO' ) AND ( ParametrosMast.ParametroClave ='MORAADMMTO' )           
                                  
                  --Valida ND generada por P61          
                  Select @w_count = count ( *)           
                  From CO_Documento With (NoLock)            
                  Where ( CO_Documento.CompaniaSocio =@vCompaniaSocio ) AND           
                        ( CO_Documento.TipoDocumento = 'ND' ) AND           
                        ( CO_Documento.Estado <> 'AN' ) AND           
                        ( CO_Documento.NotaCreditoDocumento = @w_NotaCreditoDocumento)           
                                        
                  If (@w_count > 0)          
                  Begin          
                     set @w_MoraAdmMto = 0          
                  End          
                                  
                  --Verificar S/. 50          
                  Select @w_flag = CO_Documento.LetraDescuentoCanjeFlag           
                  From CO_Documento With (NoLock)          
                  Where ( CO_Documento.CompaniaSocio = @vCompaniaSocio ) AND           
                        ( CO_Documento.TipoDocumento =@vTipoDocumento ) AND           
                        ( CO_Documento.NumeroDocumento = @vNumeroDocumento )           
                                  
                  If (@w_flag = 'S')          
                  Begin          
                     Set @w_MoraAdmMto = 0          
                  End          
                                  
                  If (DateDiff(day, @w_fechavencimiento, @w_datetime) >= @w_MoraAdmDia)          
                  Begin          
                     --Set @w_totalmoraadm = @w_totalmoraadm + @w_MoraAdmMto          
                     Set @w_totalmora = @w_totalmora + @w_MoraAdmMto          
                  End                   
               End    
               Else If (@pCompaniaSocio In ('00002700', '00002600') Or (@pCompaniaSocio = '00002500' And @vUnidadNegocio In ('SECA', 'SECV')))  --IDAT    
               Begin
                  ----Monto para cobrar 2da Mora
                  If (@pCompaniaSocio <> '00002500')
                     Select @w_MoraAdmDia = Numero          
                     From ParametrosMast With (NoLock)         
                     Where CompaniaCodigo = @vCompania AND AplicacionCodigo = 'CO' AND ParametroClave ='MORADIAMIN'    
                  Else
                     Select @w_MoraAdmDia = Numero          
                     From ParametrosMast With (NoLock)         
                     Where CompaniaCodigo = @vCompaniaMora AND AplicacionCodigo = 'CO' AND ParametroClave ='MORADIAMIN'    
      
                  Set @w_MoraAdmMto=0  
                         
                  --Valida ND generada por P61          
                  Select @w_count = Count(*)           
                  From CO_Documento With (NoLock)          
                  Where CompaniaSocio = @vCompaniaSocio AND           
                        TipoDocumento = 'ND' AND           
                        Estado <> 'AN' AND           
                        NotaCreditoDocumento = @w_NotaCreditoDocumento    
                               
                  If (@w_count > 0)          
                  Begin          
                     set @w_MoraAdmMto = 0            
                  End          
                    
                  --Verificar S/. 50          
                  Select @w_flag = LetraProtestoNDFlag           
                  From CO_Documento With (NoLock)          
                  Where CompaniaSocio = @vCompaniaSocio AND                       
                        TipoDocumento =@vTipoDocumento AND                       
                        NumeroDocumento = @vNumeroDocumento    
                         
                  If (@w_flag = 'S')          
                  Begin                               
                     Set @w_MoraAdmMto = 0      
                     Set @w_totalmora=0    
                  End          
            
                  If (DateDiff(day, @w_fechavencimiento, @w_datetime) >= @w_MoraAdmDia)          
                  Begin                           
                     Set @w_totalmora = @w_totalmora + @w_MoraAdmMto          
                  End     
              Else  
              Begin  
                 Set  @w_totalmora=0    
              End  
            End  
                 
               --Ultima Verificaci�n de Aplicaci�n de Mora          
               If (@vTipoDocumento <> 'PE')          
                  --Actualizamos la mora al registro          
                  Update #tmpDeuda          
                  Set Mora = @w_totalmora          
                  Where Id = @k          
               Else          
                  --Actualizamos la mora al registro          
                  Update #tmpDeuda          
                  Set Mora = 0          
                  Where Id = @k          
                         
               --Registramos en Tabla Log de Pagos en Linea          
               If Exists(Select * From CO_RegistroPagoLinea With (NoLock) Where CompaniaSocio = @vCompaniaSocio And TipoDocumento = @vTipoDocumento And NumeroDocumento  = @vNumeroDocumento)          
               Begin          
                  --Se actualiza los datos de consulta en el log          
                  Update CO_RegistroPagoLinea          
                  Set ClienteNumero = @vClienteNumero,          
                      FechaEmision = @vFechaDocumento,           
                      FechaVencimiento = @w_fechavencimiento,          
                      MontoTotal = @vMontoTotal,          
                      MontoMora = @w_totalmora,          
                      MontoDescuento = 0,          
                      Moneda = @vMonedaDocumento,          
                      FlagConsultado = 1,          
                      FechaConsulta = GetDate(),          
                      TipoConsulta = @pTipoConsulta,        
                      IdConsulta = @pIdConsulta          
                  Where CompaniaSocio = @vCompaniaSocio And TipoDocumento = @vTipoDocumento And NumeroDocumento  = @vNumeroDocumento          
               End          
               Else          
               Begin          
                  --Se Inserta un nuevo registro log          
                  Insert Into CO_RegistroPagoLinea          
                  (          
                     CompaniaSocio, TipoDocumento, NumeroDocumento, ClienteNumero, FechaEmision, FechaVencimiento, MontoTotal, MontoMora, Moneda,           
                     FlagConsultado, FechaConsulta, FlagNotificacionPago, FlagPagoAnulado, TipoConsulta, IdConsulta, UnidadReplicacion, MontoDescuento          
                  )          
                  Select CompaniaSocio, TipoDocumento, RTrim(NumeroDocumento), ClienteNumero, FechaDocumento, FechaVencimiento, MontoTotal, @w_totalmora, MonedaDocumento,          
                         1, GetDate(), 0, 0, @pTipoConsulta, @pIdConsulta, UnidadReplicacion, 0          
                  From #tmpDeuda          
                  Where Id = @k          
               End          
            End          
         End          
      End          
          
      Set @vInterfase_Area = ''          
      Set @vInterfase_Descuento = ''          
      Set @vNumeroDocumento = ''          
      Set @vTipoDocumento = ''          
      Set @w_totalmora = 0          
      Set @w_mora = 0          
      Set @vMontoDescuento = 0          
      Set @k = @k + 1          
   End          
             
   Insert Into #tmpConsultaDeuda          
   (     
      CodigoProducto, NumDocumento, DescDocumento, FechaVencimiento, FechaEmision, Deuda, Mora, GastosAdm,           
      PagoMinimo, Periodo, Anio, Cuota, MonedaDoc, UnidadNegocio
   )          
   Select @pCodigoProducto, TipoDocumento + RTrim(NumeroDocumento), SubString(Descripcion, 1, 20), Replace(Convert(varchar(10), FechaVencimiento, 103), '/', ''),           
          Replace(Convert(varchar(10), FechaDocumento, 103), '/', ''), MontoTotal, Mora, 0,     
          case CompaniaSocio     
            when '00002700' then Case   
                                    When TipoDocumento In ('PE','PC') Then MontoMinimo   
                                    Else Case   
                                             When Mora>=1.00 Then mora   
                                             else 1.00   
                                         End      
                                    End    
            when '00002600' then Case   
                                    When TipoDocumento In ('PE','PC') Then MontoMinimo   
                                    Else Case   
                                             When Mora>=1.00 Then mora   
                                             else 1.00   
                                         End      
                                    End  
            else Case   
                     When TipoDocumento In ('PE','PC') Then MontoMinimo   
                     Else Mora   
                 End     
          End As PagoMinimo,    
          SubString(VoucherPeriodo, 5, 2),  SubString(VoucherPeriodo, 1, 4), '00',           
          Case MonedaDocumento          
              When 'LO' Then '1'          
              When 'EX' Then '2'          
          End, UnidadNegocio
   From #tmpDeuda        
   Order By FechaVencimiento Asc        
  
   Select *  
   From #tmpConsultaDeuda        
        
   Drop Table #tmpConsultaDeuda  
   Drop Table #tmpDeuda  
   Drop Table #tmpDescuento  
  
   Set NoCount Off        
End
