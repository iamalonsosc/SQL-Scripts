UPDATE Log_Lead_Web_Origen SET Disponible15='N'
WHERE Id=2452238