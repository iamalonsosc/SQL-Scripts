--SELECT*FROM Curricula
UPDATE Curricula SET NombrePlanEstudio='PLAN 2023'
WHERE IdCurricula in (5800,5804,5807,5808,5809,5810,5811,5812)
--(8 rows affected)
