--ALTER PROCEDURE [dbo].[cFichaProgramacionResumen_Ins_Grabar]
DECLARE
@IdProgramacion INT = 6153,
@UsuarioCreacion INT = 1 ,
@RetVal INT 

BEGIN
	PRINT 'INCIO: ' +  CONVERT(VARCHAR, GETDATE(),113)
	SET NOCOUNT ON;
	SET DATEFORMAT DMY

	SET @RetVal=0
	
	CREATE TABLE #EncuestaResumen (	
	IdProgramacionDetalle INT,
	IdProgramacion  INT,
	IdFicha  INT,
	IdEmpresa  INT,
	IdSede  INT,
	IdFacultad  INT,
	IdUnidadNegocio  INT,
	IdUnidadAcademica  INT,
	IdPeriodo  INT,
	IdProducto  INT,
	IdSemestre  INT,
	IdPromocion  INT,
	IdGrupo  INT,
	IdSeccion  INT,
	IdCurso  INT,
	IdActor  INT,
	IdDocente  INT,
	IdPregunta  INT,
	IdTipoPregunta  INT,
	IdAlternativa  INT,
	IdArea  INT,
	IdSubArea  INT,
	IdTipoEncuesta INT,
	IdEstado  INT,
	IdSistema  INT,
	FechaInicio DATETIME,
	FechaFin DATETIME,
	Respondio BIT, -- PUEDE SERT INT?
	FechaRespuesta VARCHAR(100),-- PUEDE SER FECHA?
	CodigoSede   VARCHAR(20),
	NombreSede   VARCHAR(100),
	CodigoPeriodo   VARCHAR(20),
	NombrePeriodo   VARCHAR(100),
	CodigoDivicion   VARCHAR(20),
	NombreDivicion   VARCHAR(100),
	CodigoPrograma   VARCHAR(20),
	NombrePrograma   VARCHAR(100),
	CodigoProducto   VARCHAR(20),
	NombreProducto   VARCHAR(150),
	CodigoSemestre   VARCHAR(20),
	NombreSemestre   VARCHAR(100),
	CodigoCurso   VARCHAR(20),
	NombreCurso   VARCHAR(200),
	CodigoSeccion   VARCHAR(20),
	CodigoDocente   VARCHAR(20),
	NombreDocente   VARCHAR(150),
	CodigoArea   VARCHAR(20),
	NombreArea   VARCHAR(1000),
	CodigoSubArea   VARCHAR(20),
	NombreSubArea   VARCHAR(1000),
	DesEncuesta VARCHAR(200),
	Valor	INT,
	Promediable BIT,
	TipoEncuesta   VARCHAR(500),
	Dsp1TipoEncuesta   VARCHAR(100),
	Dsp2TipoEncuesta   VARCHAR(100),
	Dsp3TipoEncuesta   VARCHAR(100),
	Dsp4TipoEncuesta   VARCHAR(100),
	Dsp5TipoEncuesta   VARCHAR(100),
	OrdenPregunta INT,
	OrdenAlternativa INT,
	DescPregunta	VARCHAR(1000),
	Opcion	VARCHAR(3),
	DescAlternativa	VARCHAR(8000),
	TipoPregunta	VARCHAR(1000),
	TipoControl		VARCHAR(10),
	PtjeMinimo	DECIMAL(18,8), 
	TotAlumnosMat INT,
	TotAlumnosEnc INT,
	TotAlumnosPrg INT,
	PtjePregunta	DECIMAL(18,8) , 
	PromPregunta	DECIMAL(18,8) , 
	PromSubArea		DECIMAL(18,8) , 
	PromArea		DECIMAL(18,8) , 
	PromEncuesta	DECIMAL(18,8) , 
	PromGeneral		DECIMAL(18,8) , 
	Respuesta		VARCHAR(500),
	Vigente			BIT,
	TipoCodSistema  VARCHAR(10),
	CabEstado	INT, -- PUEDE SER VARCHAR
	DetEstado	INT,-- PUEDE SER VARCHAR
	EncEstado	INT,-- PUEDE SER VARCHAR
	UsuarioCreacion	INT,
	FechaCreacion DATETIME,
	UsuarioModIFicacion	INT,
	FechaModIFicacion DATETIME,
	ValorPregunta	INT,
	PromediablePregunta INT)
	DECLARE @TotalAlumnoNPS910 INT --@20  
	DECLARE @TotalAlumnoNPS06 INT --@20  
	CREATE TABLE #EncuestaDetalleEAA (ID int identity(1,1) primary key , IdSeccion INT,  TotAlumnosEnc INT)
		
	DECLARE @MIN INT , @MAX INT

	DECLARE 
	@PtjeMinimo DECIMAL(18,8) , 
	@TotAlumnosMat INT , 
	@TotAlumnosEnc INT ,
	@TotAlumnosEncReal INT , 
	@TotAlumnosPrg INT , 
	@PtjePregunta DECIMAL(18,8) , 
	@PromPregunta DECIMAL(18,8) , 
	@PromSubArea DECIMAL(18,8) , 
	@PromArea DECIMAL(18,8) ,
	@PromEncuesta DECIMAL(18,8) ,
	@PromGeneral DECIMAL(18,8) ,
	@SumPromPregunta DECIMAL(18,8) ,
	@SumPromSubArea DECIMAL(18,8) ,
	@CtaPromSubArea INT ,
	@SumPromArea DECIMAL(18,8) ,
	@CtaPromArea INT ,
	@SumPromEncuesta DECIMAL(18,8) ,
	@CtaPromEncuesta INT ,
	@SumPromGeneral DECIMAL(18,8) ,
	@CtaPromGeneral INT ,
	@Concatenar VARCHAR(max),
	@EsAbierta BIT,
	@Disponible1 VARCHAR(10),
	@IdSeccion INT, --Bucle1 EAA
	@IdPromocion INT, --Bucle1 ESA
	@IdGrupo INT, --Bucle1 ESA
	@IdArea INT,--Bucle2
	@IdSubArea INT,--Bucle3 
	@IdPregunta INT,--Bucle4 
	@IdAlternativa INT,--Bucle5
	@IdDocente INT, --Bucle1 ESA
	@Valor DECIMAL(18,8), 
	@Promediable INT,
	@IdTipoPregunta INT,
	@ValorPregunta DECIMAL(18,8), --@13
	@PromediablePregunta INT,--@13
	@PcjeRptaEncAca DECIMAL(5,2),--@15,
	@IdSede INT --@16
	
	SELECT @PtjeMinimo=0,@TotAlumnosMat=0,@TotAlumnosEnc=0,@TotAlumnosPrg=0,@PtjePregunta=NULL,@PromPregunta=NULL,
	@PromSubArea=NULL,@PromArea=NULL,@PromEncuesta=NULL,@PromGeneral=NULL

	--@2
	--se sincroniza la tabla FichaRespuestaActor y FichaProgramacionDetalle.Respondio para que coincidan los alumnos que respondieron en ambas tablas
	UPDATE fpd 
	SET fpd.Respondio=CASE WHEN fra.IdActor IS NULL THEN 0 ELSE 1 END,
	FechaRespuesta=CASE WHEN fra.IdActor IS NULL THEN null ELSE fra.Fecha END  --@6
	FROM FichaProgramacionDetalle fpd WITH (NOLOCK) 
	LEFT JOIN FichaRespuestaActor fra WITH (NOLOCK) ON fpd.IdProgramacion=fra.IdProgramacion and fpd.IdProgramacionDetalle=fra.IdProgramacionDetalle
	WHERE fpd.IdProgramacion=@IdProgramacion
   
	--se borran todos los resultados consolidados previamente
	DELETE FROM FichaProgramacionResumen
	WHERE IdProgramacion=@IdProgramacion

	--se recupera el tipo de ficha
	SELECT TOP 1 @Disponible1=MTR.Disponible1
	FROM FichaProgramacion FP WITH (NOLOCK) --@19
	INNER JOIN Ficha f WITH (NOLOCK) ON f.IdFicha=FP.IdFicha
	INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON F.IdTipo=MTR.IdMaestroRegistro
	WHERE IdProgramacion=@IdProgramacion
	
	--INICIO @16
	SELECT  @IdSede = (Select distinct IdSede From FichaProgramacionDetalle WITH (NOLOCK) where IdProgramacion = @IdProgramacion) --@17

	Select @PcjeRptaEncAca=CAST(Valor AS DECIMAL(5,2)) FROM EmpresaSedeParametro WITH (NOLOCK) WHERE Nombre= 'PcjeRptaEncAca' and IdSede = @IdSede
	--FIN @16

	--Creamos la tabla temporal con todos los datos Basicos	
	INSERT INTO #EncuestaResumen
	SELECT DISTINCT 
	IdProgramacionDetalle=0,
	fd.IdProgramacion,
	fp.IdFicha,
	fd.IdEmpresa,
	fd.IdSede,
	fd.IdFacultad,
	fd.IdUnidadNegocio,
	fd.IdUnidadAcademica,
	fd.IdPeriodo,
	fd.IdProducto,
	fd.IdSemestre,
	fd.IdPromocion,
	fd.IdGrupo,
	fd.IdSeccion,
	fd.IdCurso,
	IdActor=0,
	fd.IdDocente,
	fp.IdPregunta,
	IdTipoPregunta=fp.IdTipo,
	pa.IdAlternativa,
	fp.IdArea,
	fp.IdSubArea,
	IdTipoEncuesta=f.IdTipo,
	pg.IdEstado,
	IdSistema=f.IdSistema,
	'FechaInicio'=GETDATE(),
	'FechaFin'=GETDATE(),
	Respondio=0,
	FechaRespuesta='',
	CodigoSede='',
	NombreSede='',
	CodigoPeriodo='',
	NombrePeriodo='',
	CodigoDivicion='',
	NombreDivicion='',
	CodigoPrograma='',
	NombrePrograma='',
	CodigoProducto='',
	NombreProducto='',
	CodigoSemestre=CM.Codigo,
	NombreSemestre=CM.Nombre,
	CodigoCurso='',
	NombreCurso='',
	CodigoSeccion='',
	CodigoDocente='',
	NombreDocente='',
	CodigoArea='',
	NombreArea='',
	CodigoSubArea='',
	NombreSubArea='',
	DesEncuesta=f.Nombre,
	pa.Valor,
	pa.Promediable,
	TipoEncuesta='',
	Dsp1TipoEncuesta='',
	Dsp2TipoEncuesta='',
	Dsp3TipoEncuesta='',
	Dsp4TipoEncuesta='',
	Dsp5TipoEncuesta='',
	OrdenPregunta=fp.Orden,
	OrdenAlternativa=pa.Orden,
	DescPregunta='',
	pa.Opcion,
	DescAlternativa='',
	TipoPregunta='',
	TipoControl='',
	PtjeMinimo=@PtjeMinimo,
	TotAlumnosMat=@TotAlumnosMat,
	TotAlumnosEnc=@TotAlumnosEnc,
	TotAlumnosPrg=@TotAlumnosPrg,
	PtjePregunta=@PtjePregunta,
	PromPregunta=@PromPregunta,
	PromSubArea=@PromSubArea,
	PromArea=@PromArea,
	PromEncuesta=@PromEncuesta,
	PromGeneral=@PromGeneral,
	Respuesta='',
	Vigente=fp.Vigente,
	TipoCodSistema='',
	CabEstado='',
	DetEstado='',
	EncEstado='',
	UsuarioCreacion=@UsuarioCreacion,
	FechaCreacion=GETDATE(),
	UsuarioModIFicacion=@UsuarioCreacion,
	FechaModIFicacion=GETDATE(),
	fp.Valor As ValorPregunta,
	fp.Promediable As PromediablePregunta--@13	  		  
	FROM FichaProgramacionDetalle fd WITH (NOLOCK) --@19
	INNER JOIN FichaProgramacion pg WITH (NOLOCK) ON fd.IdProgramacion=pg.IdProgramacion
	INNER JOIN Ficha f WITH (NOLOCK) ON f.IdFicha=pg.IdFicha
	INNER JOIN FichaPregunta fp WITH (NOLOCK) ON f.IdFicha=fp.IdFicha
	LEFT JOIN PreguntaAlternativa pa WITH (NOLOCK) ON pa.IdFicha=f.IdFicha AND pa.IdPregunta=fp.IdPregunta
	LEFT JOIN Promocion P WITH (NOLOCK) ON FD.IdPromocion = P.IdPromocion 
	LEFT JOIN CurriculaModulo CM WITH (NOLOCK) ON P.IdModulo=CM.IdModulo AND P.IdCurricula=CM.IdCurricula
	WHERE fd.IdProgramacion=@IdProgramacion
	AND fd.Respondio=1 --@2
	AND fd.IdEstado = 1

	PRINT 'PRIMER SELECT INSET: ' +  CONVERT(VARCHAR, GETDATE(),113)

	DECLARE @TB_Consulta TABLE (IdMaestroRegistro INT)
	DECLARE @MaestroTablaRegistro TABLE (IdMaestroRegistro INT, Codigo Varchar(100), Nombre VARCHAR(1000))
	
	INSERT INTO @TB_Consulta
	SELECT DISTINCT IdPregunta FROM #EncuestaResumen

	INSERT INTO @TB_Consulta
	SELECT DISTINCT IdAlternativa FROM #EncuestaResumen

	INSERT INTO @TB_Consulta
	SELECT DISTINCT IdTipoPregunta FROM #EncuestaResumen

	INSERT INTO @TB_Consulta
	SELECT DISTINCT IdArea FROM #EncuestaResumen

	INSERT INTO @TB_Consulta
	SELECT DISTINCT IdSubArea FROM #EncuestaResumen

	INSERT INTO @TB_Consulta
	SELECT DISTINCT IdTipoEncuesta FROM #EncuestaResumen


	INSERT INTO @MaestroTablaRegistro
	SELECT DISTINCT IdMaestroRegistro , Codigo , Nombre  FROM MaestroTablaRegistro WITH(NOLOCK) WHERE IdMaestroRegistro IN (SELECT IdMaestroRegistro FROM @TB_Consulta)

	--Actualizamos Actualiza Pregunta
	UPDATE t
	SET t.DescPregunta = dp.Nombre
	FROM #EncuestaResumen t 
	INNER JOIN @MaestroTablaRegistro dp on (t.IdPregunta=dp.IdMaestroRegistro)
		
	--Actualiza Alternativa
	UPDATE t
	SET t.DescAlternativa = da.Nombre
	FROM #EncuestaResumen t 
	INNER JOIN @MaestroTablaRegistro da on (t.IdAlternativa=da.IdMaestroRegistro)		
											
	--Actualizamos Tipo Pregunta
	UPDATE t
	SET t.TipoPregunta = tp.Nombre
	FROM #EncuestaResumen t 
	INNER JOIN @MaestroTablaRegistro tp on (t.IdTipoPregunta=tp.IdMaestroRegistro)
		
	--Actualizamos Area
	UPDATE t
	SET t.CodigoArea =a.Codigo,t.NombreArea=a.Nombre
	FROM #EncuestaResumen t 
	INNER JOIN @MaestroTablaRegistro A on (t.IdArea=a.IdMaestroRegistro)

	--Actualizamos Sub Area
	UPDATE t
	SET t.CodigoSubArea = sa.Codigo,t.NombreSubArea=sa.Nombre
	FROM #EncuestaResumen t 
	INNER JOIN @MaestroTablaRegistro sa on (t.IdSubArea=sa.IdMaestroRegistro)
  
	--Actualizamos Tipo Encuesta
	UPDATE t
	SET t.TipoEncuesta= left(te.Nombre,100)
	FROM #EncuestaResumen t 
	INNER JOIN @MaestroTablaRegistro te ON (t.IdTipoEncuesta=te.IdMaestroRegistro)
    

	--Actualizamos Datos Generales  
	UPDATE t
	SET t.CodigoSede=s.Codigo,t.NombreSede=s.Nombre,
	t.CodigoDivicion=un.Codigo,t.NombreDivicion=un.Nombre,
	t.CodigoPrograma=ua.Codigo,t.NombrePrograma=ua.Nombre,
	t.CodigoPeriodo=p.Codigo,t.NombrePeriodo=p.Nombre,
	t.CodigoProducto=pr.ProductoCodigo,t.NombreProducto=pr.ProductoNombre,
	t.CodigoCurso=c.CursoCodigo,t.NombreCurso=c.CursoNombre		     
	FROM #EncuestaResumen t 
	INNER JOIN Sede s WITH (NOLOCK) ON s.IdSede=t.IdSede
	LEFT JOIN UnidadNegocio un WITH (NOLOCK) ON un.IdUnidadNegocio=t.IdUnidadNegocio
	LEFT JOIN UnidadAcademica ua WITH (NOLOCK) ON ua.IdUnidadAcademica=t.IdUnidadAcademica
	LEFT JOIN Periodo p WITH (NOLOCK) ON p.IdPeriodo=t.IdPeriodo
	LEFT JOIN Producto pr WITH (NOLOCK) ON pr.IdProducto=t.IdProducto
	LEFT JOIN Curso c WITH (NOLOCK) ON c.IdCurso=t.IdCurso
	
	--se actualiza el curso y seccion 
	UPDATE t
	SET t.CodigoSeccion=PG.GrupoCodigo,t.CodigoCurso=s.Codigo
	FROM #EncuestaResumen t 
	INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON T.IdPromocion=PG.IdPromocion AND T.IdGrupo=PG.IdGrupo
	LEFT JOIN Seccion S WITH (NOLOCK) ON S.IdSeccion=T.IdSeccion
	
	--SI ES UNA ENCUESTA ACADEMICA EL RESUMEN ES POR SECCION, AREA, SUBAREA, PREGUNTA Y ALTERNATIVA
	IF @Disponible1='EAA'--ENCUESTA ACADEMICA
	BEGIN		
		
		--TEMP
		DECLARE @EncuestaAreaEAA TABLE (ID INT IDENTITY(1,1) PRIMARY KEY, IdArea INT) 						 	        
		DECLARE @EncuestaSubAreaEAA TABLE (ID INT IDENTITY(1,1) PRIMARY KEY , IdSubArea INT )
		DECLARE @EncuestaPreguntaEAA TABLE (ID INT IDENTITY(1,1) PRIMARY KEY , IdPregunta INT, ValorPregunta INT ,PromediablePregunta INT )
		DECLARE @AlternativaEAA TABLE (ID INT IDENTITY(1,1) PRIMARY KEY , IdAlternativa INT, Valor INT ,Promediable BIT,IdTipoPregunta INT )

		DECLARE @MIN_Area INT , @MAX_Area INT 
		DECLARE @MIN_SubArea INT , @MAX_SubArea INT 
		DECLARE @MIN_Pregunta INT , @MAX_Pregunta INT 
		DECLARE @MIN_Alternativa INT , @MAX_Alternativa INT 


		--Docente
		UPDATE t
		SET t.NombreDocente = a.NombreCompleto,t.CodigoDocente=F.CodigoAnterior
		FROM #EncuestaResumen t 
		INNER JOIN Actor a WITH (NOLOCK) on (t.IdDocente=a.IdActor)
		INNER JOIN Facilitador F WITH (NOLOCK) on (t.IdDocente=F.IdFacilitador)

		UPDATE t
		SET t.TotAlumnosMat=(	SELECT COUNT(DISTINCT IdActor)
								FROM FichaProgramacionDetalle fd WITH (NOLOCK)
								WHERE FD.IdProgramacion=T.IdProgramacion--@3		
								AND FD.IdEmpresa=T.IdEmpresa 					
								AND FD.IdSede=T.IdSede 
								AND FD.IdFacultad=T.IdFacultad  	
								AND	FD.IdUnidadNegocio=T.IdUnidadNegocio  
								AND	FD.IdUnidadAcademica=T.IdUnidadAcademica  
								AND	FD.IdPeriodo=T.IdPeriodo  
								AND	FD.IdProducto=T.IdProducto  
								AND	FD.IdPromocion=T.IdPromocion  
								AND	FD.IdGrupo=T.IdGrupo  
								AND	FD.IdCurso=T.IdCurso  
								AND	FD.IdSeccion=T.IdSeccion			
								) FROM #EncuestaResumen t    
		--@18

		--total de alumnos encuestados 		
		UPDATE t
		SET t.TotAlumnosEnc=(	SELECT COUNT(DISTINCT IdActor)
								FROM FichaProgramacionDetalle fd WITH (NOLOCK)
								WHERE FD.IdProgramacion=T.IdProgramacion--@3		
								AND FD.IdEmpresa=T.IdEmpresa 					
								AND FD.IdSede=T.IdSede 
								AND FD.IdFacultad=T.IdFacultad  	
								AND	FD.IdUnidadNegocio=T.IdUnidadNegocio  
								AND	FD.IdUnidadAcademica=T.IdUnidadAcademica  
								AND	FD.IdPeriodo=T.IdPeriodo  
								AND	FD.IdProducto=T.IdProducto  
								AND	FD.IdPromocion=T.IdPromocion  
								AND	FD.IdGrupo=T.IdGrupo  
								AND	FD.IdCurso=T.IdCurso  
								AND	FD.IdSeccion=T.IdSeccion  
								AND FD.Respondio=1					
								) FROM #EncuestaResumen t		
								
		--@15 se borra todos los alumnos que llegan al 30%
		DELETE FROM #EncuestaResumen
		WHERE (CASE WHEN TotAlumnosMat>0 THEN ROUND(CAST(TotAlumnosEnc AS DECIMAL)/CAST(TotAlumnosMat AS DECIMAL),2) ELSE 0.0 END) < @PcjeRptaEncAca						 	

		SET @MIN = 0 
		SET @MAX = 0 

		INSERT INTO #EncuestaDetalleEAA
		SELECT DISTINCT IdSeccion,TotAlumnosEnc 
		FROM #EncuestaResumen

		SELECT @MIN = MIN(ID), @MAX = MAX(id) FROM #EncuestaDetalleEAA

		PRINT 'INICIO DEL BLUCLE:  TOTAL: ' +  CONVERT(VARCHAR,@MAX)+  ' TIEMPO: ' +  CONVERT(VARCHAR, GETDATE(),113)
		--INICIO DETALLE
		WHILE @MIN <= @MAX                                              
		BEGIN  
			
			PRINT 'Registro: ' + CONVERT(VARCHAR,@MIN) +  ' TIEMPO: ' + CONVERT(VARCHAR, GETDATE(),113)

			SET @IdSeccion = NULL 
			SET @TotAlumnosEnc = NULL

			SELECT @IdSeccion=IdSeccion,@TotAlumnosEnc=TotAlumnosEnc 
			FROM #EncuestaDetalleEAA 
			WHERE ID = @MIN 
								                
			IF @TotAlumnosEnc >0 
			BEGIN 

				SET @PromEncuesta = NULL
				SET @SumPromEncuesta = NULL
				SET @CtaPromEncuesta = NULL
				SET @TotalAlumnoNPS910=NULL --@20  
				SET @TotalAlumnoNPS06    =NULL       --@20       
				 	
				DELETE FROM @EncuestaAreaEAA
				SET @MIN_Area = 0 
				SET @MAX_Area = 0

				INSERT INTO @EncuestaAreaEAA
				SELECT DISTINCT IdArea 
				FROM #EncuestaResumen
				WHERE IdProgramacion=@IdProgramacion 
				AND IdSeccion=@IdSeccion    

				SELECT @MIN_Area = MIN(ID) , @MAX_Area = MAX(ID) FROM @EncuestaAreaEAA
				
				WHILE @MIN_Area <= @MAX_Area                                                 
				BEGIN           
				
					SET @IdArea = NULL
					           
					SELECT @IdArea=IdArea 
					FROM @EncuestaAreaEAA WHERE ID = @MIN_Area  

					SET @PromArea = NULL
					SET @SumPromArea = NULL
					SET @CtaPromArea = NULL
						                                               
					--INICIO SUB AREA
					DELETE FROM @EncuestaSubAreaEAA
					SET @MIN_SubArea = 0 
					SET @MAX_SubArea = 0

					INSERT INTO @EncuestaSubAreaEAA
					SELECT DISTINCT IdSubArea 
					FROM #EncuestaResumen
					WHERE IdProgramacion=@IdProgramacion 
					AND IdSeccion=@IdSeccion 
					AND IdArea=@IdArea             

					SELECT @MIN_SubArea = MIN(ID) , @MAX_SubArea = MAX(ID) FROM @EncuestaSubAreaEAA
				
					WHILE @MIN_SubArea <= @MAX_SubArea                                               
					BEGIN 
						
						SET @IdSubArea = NULL

						SELECT @IdSubArea=IdSubArea 
						FROM @EncuestaSubAreaEAA WHERE ID = @MIN_SubArea 

						SET @PromSubArea = NULL
						SET @SumPromSubArea = NULL
						SET @CtaPromSubArea = NULL
						SET @EsAbierta = 0
				                 
						--INICIO PREGUNTA
						DELETE FROM @EncuestaPreguntaEAA
						SET @MIN_Pregunta = 0 
						SET @MAX_Pregunta = 0 

						INSERT INTO @EncuestaPreguntaEAA
						SELECT DISTINCT IdPregunta,ValorPregunta,PromediablePregunta
						FROM #EncuestaResumen
						WHERE IdProgramacion=@IdProgramacion 
						AND IdSeccion=@IdSeccion 
						AND IdArea=@IdArea
						AND IdSubArea=@IdSubArea

						SELECT @MIN_Pregunta = MIN(ID) , @MAX_Pregunta = MAX(ID) FROM @EncuestaPreguntaEAA

						WHILE @MIN_Pregunta <=  @MAX_Pregunta                                              
						BEGIN   
						                            
							SET @IdPregunta = NULL 
							SET @ValorPregunta = NULL
							SET @PromediablePregunta = NULL 
							               
							SELECT @IdPregunta=IdPregunta,@ValorPregunta=ValorPregunta,@PromediablePregunta=PromediablePregunta--@13
							FROM @EncuestaPreguntaEAA WHERE Id = @MIN_Pregunta  
								             
							SET @TotAlumnosEncReal=(SELECT COUNT(DISTINCT fd.IdActor)
												FROM FichaProgramacionDetalle fd WITH (NOLOCK)
												INNER JOIN FichaRespuestaActor fr WITH (NOLOCK) ON fr.IdProgramacion=fd.IdProgramacion AND fd.IdProgramacionDetalle=fr.IdProgramacionDetalle
												INNER JOIN PreguntaAlternativa pa WITH (NOLOCK) ON pa.IdFicha=fr.IdFicha AND pa.IdPregunta=fr.IdPregunta AND pa.IdAlternativa=fr.IdAlternativa
												WHERE fd.Respondio=1
												AND fd.IdProgramacion=@IdProgramacion
												AND	fd.IdSeccion=@IdSeccion  
												AND	pa.IdPregunta=@IdPregunta)

							SET @PromPregunta = NULL
							SET @SumPromPregunta = NULL
							SET @Valor=0
							SET @Promediable=1
							SET @IdTipoPregunta=0													                   
							
							--INICIO ALTERNATIVA 
							DELETE FROM @AlternativaEAA
							SET @MIN_Alternativa = 0 
							SET @MAX_Alternativa = 0 

							INSERT INTO	@AlternativaEAA											 
							SELECT DISTINCT IdAlternativa,'Valor'=ISNULL(Valor,0),'Promediable'=ISNULL(Promediable,1),IdTipoPregunta 
							FROM #EncuestaResumen
							WHERE IdProgramacion=@IdProgramacion 
							AND IdSeccion=@IdSeccion 
							AND IdArea=@IdArea
							AND IdSubArea=@IdSubArea 
							AND IdPregunta=@IdPregunta 
									
							SELECT @MIN_Alternativa = MIN(ID) , @MAX_Alternativa = MAX(ID) FROM @AlternativaEAA
											
							WHILE @MIN_Alternativa <=   @MAX_Alternativa                                         
							BEGIN  
							                         
								SET @IdAlternativa = NULL
								SET @Valor = NULL
								SET @Promediable = NULL
								SET @IdTipoPregunta = NULL
														                     
								SELECT @IdAlternativa=IdAlternativa,@Valor=Valor,@Promediable=Promediable,@IdTipoPregunta=IdTipoPregunta 
								FROM @AlternativaEAA WHERE ID = @MIN_Alternativa
			
								IF @IdTipoPregunta=1426--ABIERTA					           
								BEGIN

									SET @EsAbierta=1
									--SE CONCATENA LAS RESPUESTAS DE LOS ALUMNOS	
									SET @Concatenar = ''
									SELECT @Concatenar=@Concatenar+TMP.Respuesta+' / '--@10
									FROM (	SELECT DISTINCT fa.Respuesta
											FROM FichaRespuestaActor fa WITH (NOLOCK)
											INNER JOIN FichaPregunta fp WITH (NOLOCK) ON fp.IdFicha=fa.IdFicha AND fa.IdPregunta=fp.IdPregunta
											INNER JOIN FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle
											WHERE fa.IdProgramacion=@IdProgramacion
											AND	fd.IdSeccion=@IdSeccion
											AND fp.IdArea=@IdArea
											AND fp.IdSubArea=@IdSubArea
											AND	fa.IdPregunta=@IdPregunta
											AND fd.Respondio=1
											AND ISNULL(fa.Respuesta,'')!='')TMP

									IF LEN(@Concatenar)>0 SET @Concatenar=SUBSTRING(@Concatenar,1,LEN(@Concatenar)-2)
									UPDATE #EncuestaResumen
									SET DescAlternativa=@Concatenar
									WHERE IdProgramacion=@IdProgramacion 
									AND IdSeccion=@IdSeccion 
									AND IdArea=@IdArea
									AND IdSubArea=@IdSubArea 
									AND IdPregunta=@IdPregunta

								END
								ELSE
								BEGIN

									Set @EsAbierta = 0; --@14

									SET @TotAlumnosPrg=(SELECT COUNT(DISTINCT fa.IdActor) 
														FROM FichaRespuestaActor fa WITH (NOLOCK)
														INNER JOIN FichaPregunta fp  WITH (NOLOCK) ON fp.IdFicha=fa.IdFicha AND fa.IdPregunta=fp.IdPregunta
														INNER JOIN PreguntaAlternativa pa  WITH (NOLOCK) ON pa.IdFicha=fp.IdFicha AND pa.IdPregunta=fp.IdPregunta AND pa.IdAlternativa=fa.IdAlternativa
														INNER JOIN FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle
														WHERE fa.IdProgramacion=@IdProgramacion
														AND	fd.IdSeccion=@IdSeccion
														AND fp.IdArea=@IdArea
														AND fp.IdSubArea=@IdSubArea
														AND	pa.IdPregunta=@IdPregunta
														AND pa.IdAlternativa=@IdAlternativa
														AND fd.Respondio=1
														--AND ISNULL(PA.Promediable,1)=1 --CON ESTO SI MUESTRA LA CANTIDAD
														)
											             
									--se asignan variables--@6
									IF @TotAlumnosEncReal>0 
									BEGIN
										IF @Promediable=1 SET @PtjePregunta = (@Valor * @TotAlumnosPrg) / @TotAlumnosEncReal
										ELSE SET @PtjePregunta = NULL
									END
									ELSE SET @PtjePregunta = NULL

									IF @PtjePregunta IS NOT NULL SET @SumPromPregunta = ISNULL(@SumPromPregunta,0) + @PtjePregunta

									--se actualiza el total de alumnos y el puntaje por pregunta
									UPDATE #EncuestaResumen 
									SET TotAlumnosPrg=@TotAlumnosPrg, PtjePregunta=@PtjePregunta
									WHERE IdProgramacion=@IdProgramacion
									AND IdSeccion=@IdSeccion
									AND IdArea=@IdArea
									AND IdSubArea=@IdSubArea
									AND IdPregunta=@IdPregunta
									AND IdAlternativa=@IdAlternativa
								END

								SET @MIN_Alternativa = @MIN_Alternativa + 1
							END 		
							-- FIN ALTERNATIVA

							IF @EsAbierta = 0 AND @Promediable	 = 1 --@13
							BEGIN

								--FIN ALTERNATIVA
								--se asignan variables
								SET @PromPregunta = @SumPromPregunta
								IF @PromPregunta IS NOT NULL 
								BEGIN

									SET @SumPromSubArea = ISNULL(@SumPromSubArea,0) + @PromPregunta
									SET @CtaPromSubArea = ISNULL(@CtaPromSubArea,0) + 1

									SET @SumPromArea = ISNULL(@SumPromArea,0) + @SumPromPregunta
									SET @CtaPromArea = ISNULL(@CtaPromArea,0) + 1
								
									--SET @SumPromEncuesta = ISNULL(@SumPromEncuesta,0) + @SumPromPregunta
									SET @SumPromEncuesta = (ISNULL(@SumPromPregunta,0) * (@ValorPregunta/100)) + ISNULL(@SumPromEncuesta,0)
									SET @CtaPromEncuesta = ISNULL(@CtaPromEncuesta,0) + 1
									
									SET @SumPromGeneral = ISNULL(@SumPromGeneral,0) + @SumPromPregunta
									SET @CtaPromGeneral = @CtaPromGeneral + 1
								
								END

							END

							--se actualiza el promedio de las preguntas del subarea
							UPDATE #EncuestaResumen 
							SET PromPregunta=@PromPregunta--,
							WHERE IdProgramacion=@IdProgramacion
							AND IdSeccion=@IdSeccion
							AND IdArea=@IdArea
							AND IdSubArea=@IdSubArea
							AND IdPregunta=@IdPregunta
								
							SET @MIN_Pregunta = @MIN_Pregunta + 1 
						END 							  
						--FIN PREGUNTA

						--se asignan variables
						IF @SumPromSubArea IS NOT NULL AND @CtaPromSubArea IS NOT NULL
							SET @PromSubArea = @SumPromSubArea / @CtaPromSubArea						

						--se actualiza el promedio del subarea
						UPDATE #EncuestaResumen 
						SET PromSubArea=@PromSubArea
						WHERE IdProgramacion=@IdProgramacion
						AND IdSeccion=@IdSeccion
						AND IdArea=@IdArea
						AND IdSubArea=@IdSubArea
					
						SET @MIN_SubArea = @MIN_SubArea + 1
					END 
					--FIN SUBAREA

					--se asignan variables                         
					IF @SumPromArea IS NOT NULL AND @CtaPromArea IS NOT NULL
						SET @PromArea = @SumPromArea / @CtaPromArea

					      IF (SELECT Nombre FROM MaestroTablaRegistro WITH(NOLOCK) WHERE IdMaestroRegistro=@IdArea)='NPS' -- Inicio @20  
						   BEGIN  
						   SELECT @TotalAlumnoNPS910=COUNT(DISTINCT fa.IdActor)     
							 --select distinct  mtr.nombre  
									  FROM FichaRespuestaActor fa WITH (NOLOCK)    
									  INNER JOIN FichaPregunta fp  WITH (NOLOCK) ON fp.IdFicha=fa.IdFicha AND fa.IdPregunta=fp.IdPregunta    
									  INNER JOIN PreguntaAlternativa pa  WITH (NOLOCK) ON pa.IdFicha=fp.IdFicha AND pa.IdPregunta=fp.IdPregunta AND pa.IdAlternativa=fa.IdAlternativa    
									  INNER JOIN FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle  
							 INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.IdMaestroRegistro=PA.IdAlternativa    
									  WHERE fa.IdProgramacion=@IdProgramacion    
									  AND fd.IdSeccion=@IdSeccion    
									  AND fp.IdArea=@IdArea    
									 AND fp.IdSubArea=@IdSubArea    
									  AND pa.IdPregunta=@IdPregunta    
									--  AND pa.IdAlternativa=@IdAlternativa    
									  AND fd.Respondio=1  AND MTR.Nombre in ('9','10')  
  
							 SELECT @TotalAlumnoNPS06=COUNT(DISTINCT fa.IdActor)     
							 --select distinct  mtr.nombre  
									  FROM FichaRespuestaActor fa WITH (NOLOCK)    
									  INNER JOIN FichaPregunta fp  WITH (NOLOCK) ON fp.IdFicha=fa.IdFicha AND fa.IdPregunta=fp.IdPregunta    
									  INNER JOIN PreguntaAlternativa pa  WITH (NOLOCK) ON pa.IdFicha=fp.IdFicha AND pa.IdPregunta=fp.IdPregunta AND pa.IdAlternativa=fa.IdAlternativa    
									  INNER JOIN FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle  
							 INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.IdMaestroRegistro=PA.IdAlternativa    
									  WHERE fa.IdProgramacion=@IdProgramacion    
									  AND fd.IdSeccion=@IdSeccion    
									  AND fp.IdArea=@IdArea    
									  AND fp.IdSubArea=@IdSubArea    
									  AND pa.IdPregunta=@IdPregunta    
									  --AND pa.IdAlternativa=@IdAlternativa    
									  AND fd.Respondio=1  AND MTR.Nombre in ('0','1','2','3','4','5','6')  
     
						   IF @TotalAlumnoNPS910>0    
						   BEGIN  
							IF @TotalAlumnoNPS06>0  
							BEGIN  
							 SET @PromArea= (@TotalAlumnoNPS910*100/@TotAlumnosEncReal)-(@TotalAlumnoNPS06*100/@TotAlumnosEncReal)  
							END  
							ELSE  
							BEGIN  
							 SET @PromArea= (@TotalAlumnoNPS910*100/@TotAlumnosEncReal)  
							END  
  
							--select (2*100/2)-(1*100/2)  
						   END  
						   ELSE  
						   BEGIN  
							IF @TotalAlumnoNPS06>0  
							BEGIN  
							 SET @PromArea= 0-(@TotalAlumnoNPS06*100/@TotAlumnosEncReal)  
							END  
							ELSE  
							BEGIN  
							 SET @PromArea= 0  
							END  
						   END  

							 UPDATE #EncuestaResumen      --@21
							 SET PromPregunta=@PromArea    
							 WHERE IdProgramacion=@IdProgramacion    
							 AND IdSeccion=@IdSeccion    
							 AND IdArea=@IdArea  

							  UPDATE #EncuestaResumen      --@21
							 SET PromSubArea=@PromArea    
							 WHERE IdProgramacion=@IdProgramacion    
							 AND IdSeccion=@IdSeccion    
							 AND IdArea=@IdArea  
						   END  -- Fin @20  
    
     --se actualiza el promedio del area    
     UPDATE #EncuestaResumen     
     SET PromArea=@PromArea    
     WHERE IdProgramacion=@IdProgramacion    
     AND IdSeccion=@IdSeccion    
     AND IdArea=@IdArea  

			

					SET @MIN_Area = @MIN_Area + 1
				END 				      
				--FIN AREA			     

				--se asignan variables
				--@13
				IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL
					SET @PromEncuesta = @SumPromEncuesta
				--@13

				--se actualiza el promedio de la encuesta
				UPDATE #EncuestaResumen 
				SET PromEncuesta=@PromEncuesta
				WHERE IdProgramacion=@IdProgramacion
				AND IdSeccion=@IdSeccion
					
			END 

			SET  @MIN = @MIN + 1 
		END  

	END
	PRINT 'FIN BLUCLE: ' + CONVERT(VARCHAR, GETDATE(),113)
	--se asignan variables
	IF @SumPromGeneral IS NOT NULL AND @CtaPromGeneral IS NOT NULL
		SET @PromGeneral = @SumPromGeneral / @CtaPromGeneral

	--se actualiza el promedio general de toda la programacion
	UPDATE #EncuestaResumen 
	SET PromGeneral=@PromGeneral
	WHERE IdProgramacion=@IdProgramacion       
	--FIN DETALLE 
   
	INSERT INTO FichaProgramacionResumen
	(IdProgramacionDetalle,IdProgramacion,IdFicha,IdEmpresa,IdSede,IdFacultad,IdUnidadNegocio,IdUnidadAcademica,IdPeriodo,IdProducto
	,IdSemestre,IdPromocion,IdGrupo,IdSeccion,IdCurso,IdActor,IdDocente,IdPregunta,IdTipoPregunta,IdAlternativa,IdArea
	,IdSubArea,IdTipoEncuesta,IdEstado,IdSistema,FechaInicio,FechaFin,Respondio,FechaRespuesta,CodigoSede,NombreSede
	,CodigoPeriodo,NombrePeriodo,CodigoDivicion,NombreDivicion,CodigoPrograma,NombrePrograma,CodigoProducto,NombreProducto,CodigoSemestre,NombreSemestre
	,CodigoCurso,NombreCurso,CodigoSeccion,CodigoDocente,NombreDocente,CodigoArea,NombreArea,CodigoSubArea,NombreSubArea,DesEncuesta
	,Valor,TipoEncuesta,Dsp1TipoEncuesta,Dsp2TipoEncuesta,Dsp3TipoEncuesta,Dsp4TipoEncuesta,Dsp5TipoEncuesta,OrdenPregunta,OrdenAlternativa,DescPregunta
	,Opcion,DescAlternativa,TipoPregunta,TipoControl,PtjeMinimo,TotAlumnosMat,TotAlumnosEnc,TotAlumnosPrg,PtjePregunta,PromPregunta
	,PromSubArea,PromArea,PromEncuesta,PromGeneral,Respuesta,Vigente,TipoCodSistema,CabEstado,DetEstado,EncEstado
	,UsuarioCreacion,FechaCreacion,UsuarioModIFicacion,FechaModIFicacion
	)
   
	SELECT IdProgramacionDetalle,IdProgramacion,IdFicha,IdEmpresa,IdSede,IdFacultad,IdUnidadNegocio,IdUnidadAcademica,IdPeriodo,IdProducto
	,IdSemestre,IdPromocion,ISNULL(IdGrupo,0),ISNULL(IdSeccion,0),ISNULL(IdCurso,0),IdActor,ISNULL(IdDocente,0),IdPregunta,IdTipoPregunta,IdAlternativa,IdArea
	,ISNULL(IdSubArea,0),IdTipoEncuesta,IdEstado,IdSistema,FechaInicio,FechaFin,Respondio,FechaRespuesta,CodigoSede,NombreSede
	,CodigoPeriodo,NombrePeriodo,CodigoDivicion,NombreDivicion,CodigoPrograma,NombrePrograma,CodigoProducto,NombreProducto,CodigoSemestre,NombreSemestre
	,CodigoCurso,NombreCurso,LEFT(REPLACE(CodigoSeccion,' ',''),15)/*@5*/,CodigoDocente,LTRIM(NombreDocente),CodigoArea,NombreArea,CodigoSubArea,NombreSubArea,DesEncuesta
	,Valor,TipoEncuesta,Dsp1TipoEncuesta,Dsp2TipoEncuesta,Dsp3TipoEncuesta,Dsp4TipoEncuesta,Dsp5TipoEncuesta,OrdenPregunta,OrdenAlternativa,DescPregunta
	,Opcion,DescAlternativa,TipoPregunta,TipoControl,PtjeMinimo,TotAlumnosMat,TotAlumnosEnc,TotAlumnosPrg,PtjePregunta,PromPregunta
	,PromSubArea,PromArea,PromEncuesta,PromGeneral,Respuesta,Vigente,TipoCodSistema,CabEstado,DetEstado,EncEstado
	,UsuarioCreacion,FechaCreacion,UsuarioModIFicacion,FechaModIFicacion
	FROM #EncuestaResumen

	--SELECT TOP 1 * FROM #EncuestaResumen
    
	DROP TABLE #EncuestaResumen 						  			
    DROP TABLE #EncuestaDetalleEAA

	PRINT 'FIN: ' + CONVERT(VARCHAR, GETDATE(),113)
	 
	SET @RetVal=1


END

