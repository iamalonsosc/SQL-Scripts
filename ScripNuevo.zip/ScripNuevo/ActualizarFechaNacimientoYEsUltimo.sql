UPDATE AlumnoCursoNominaLogMinedu SET EsUltimo=0
WHERE ID=3439

UPDATE Actor SET FechaNacimiento='20000529'
WHERE IdActor=1615836