--SELECT*FROM Registro 
UPDATE Registro SET Estado='X'
WHERE IdRegistro=3
AND IdActor=1487299