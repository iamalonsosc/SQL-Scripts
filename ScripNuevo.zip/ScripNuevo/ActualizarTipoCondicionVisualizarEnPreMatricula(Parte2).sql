UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672220
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672222
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672249
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672283
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672254
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672243
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672236
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672226
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672244
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672232
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672234
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672240
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672250
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672266
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672280
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672261
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672253
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672238
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672257
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672252
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672228
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672262
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672241
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 679488
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672216
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 679491
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672264
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672270
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672221
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672259
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672235
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672268
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672277
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672218
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672245
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672224
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
UPDATE ACC SET ACC.Subsanacion = 1
FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
INNER JOIN AlumnoCurriculaCurso ACC 
ON ACC.IdAlumno = AC.IdAlumno 
AND ACC.IdCurso = AC.IdCurso 
AND ACC.IdCurricula = AC.IdCurricula
WHERE AC.IdMatricula = 672247
AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE TECNOLOG�A E INTELIGENCIA ARTIFICIAL';
