UPDATE S SET
Estado = 'A'
from Seccion S 
INNER JOIN Promocion P ON P.IdPromocion = S.IdPromocion
INNER JOIN Periodo PE ON PE.IdPeriodo = P.IdPeriodo
WHERE PE.Codigo = '2023-IIK' AND S.Estado <>'A'--(957 rows affected)

Select * from Seccion S 
INNER JOIN Promocion P ON P.IdPromocion = S.IdPromocion
INNER JOIN Periodo PE ON PE.IdPeriodo = P.IdPeriodo
WHERE PE.Codigo = '2023-IIK' AND S.Estado <>'A'

--(957 rows affected)