UPDATE Registro SET IdSede=40
WHERE IdActor=1553008 AND IdRegistro=1