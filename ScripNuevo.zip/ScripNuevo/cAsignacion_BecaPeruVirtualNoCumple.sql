----------------------------------------------------------------------------      
--Creado por      :Alonso Sanchez (05/05/2024)            
--Funcionalidad   :
--Utilizado por   :
--------------------------------------------------------------         
/*      
-----------------------------------------------------------------------------      
Nro		FECHA			USUARIO					DESCRIPCION      
-----------------------------------------------------------------------------      
*/   
CREATE PROCEDURE cAsignacion_BecaPeruVirtualNoCumple
@IdMatricula INT ,
@CodigoBase VARCHAR(100),
@Retorno BIT OUTPUT,
@pDescripcion varchar(500) OUTPUT
AS  
BEGIN 
--@IdMatricula2 INT = 460487
/*
GLOSARIO:
	RE -> Promovido
	RP -> Promovido + Curso
	RT -> Repitencia
	CC -> Curso�Repitencia
*/
	DECLARE @IdActor INT,
	@IdSedeActual INT,
	@IdSedeAnterior INT,
	@CodigoPeriodo VARCHAR(10),
	@IdUnidadAcademica INT,
	@IdUnidadNegocio INT,
	@TipoTurnoActual VARCHAR(15),
	@TipoCondicionActual VARCHAR(10),
	@CambioCarreraBeca INT,
	@CompaniaSocio VARCHAR(10),
	@PromedioBeca REAl,
	@PeriodosAnterioresConcatenados VARCHAR(MAX),
	@IdModuloBecaValidar INT,
	@IdProductoActual INT,
	@IdProductoAnterior INT,
	@IdMatriculaAnterior INT,
	@IdModuloPagoAnterior INT,
	@IdModuloActual INT,
	@IdTipoConsulta INT,
	@PeriodoCodigoBase VARCHAR(20),
	@TurnoAnterior varchar(50),
	@ProductoAnterior varchar(100),
	@ProductoActual varchar(100),
	@SedeActual VARCHAR(50),
	@SedeNombreAnterior VARCHAR(50),
	@PeriodoCodigoMatriculaAnterior VARCHAR(50),
	@PromedioReal real,
	@IdDescuentoAcademicoBase INT,
	@CodigoDescuento VARCHAR(50),
	@BaseActivo BIT,
	@ExcluidoPorPagoPuntual INT = 0 ;

	DECLARE 
	@ExcluidoPorPromedio BIT = 0

	--DECLARAMOS LA TABLA DE LOS PERIODOS ANTERIORES
	DECLARE @PeriodosAnteriores table    
	(CodigoPeriodoPadre varchar(20),    
	CodigoPeriodoAnterior varchar(20),     
	IdPeriodoPadre int,    
	IdPeriodoAnterior int)

	--DECLARAMOS LA TABLA EN DONDE GUARDAREMOS LA MATRICULA ANTERIOR
	DECLARE @MatriculaAnterior TABLE (
	IdActor INT,
	IdMatricula INT,
	PromocionCodigo VARCHAR(50),
	PromocionNombre VARCHAR(100),
	IdSede INT,
	SedeNombreAnterior varchar(50),
	IdPeriodo INT,
	Codigo VARCHAR(50),
	IdProducto INT,
	ProductoNombre VARCHAR(100),
	GrupoCodigo VARCHAR(50),
	IdGrupo INT,
	IdTurno INT,
	TurnoNombre VARCHAR(100),
	IdTipoTurno INT,
	TipoTurnoDispo5 VARCHAR(50),
	TipoCondicion VARCHAR(50),
	Estado VARCHAR(50),
	MatriculaTipo VARCHAR(50),
	PromedioReal REAL,
	IdModulo INT,
	PeriodoCodigoBase VARCHAR(20),
	NombreDescuento VARCHAR(100),
	CodigoDescuento VARCHAR(50),
	IdTipoConsulta INT,
	MantieneBeca BIT,
	IdDescuentoAcademicoBase INT, BaseActivo BIT);

	--Selecionamos la empresa a la que pertenece 
	SELECT @CompaniaSocio= CompaniaSocio FROM Empresa WITH(NOLOCK)

	SET @IdMatriculaAnterior = NULL 
	SET @IdModuloPagoAnterior = NULL 
		
	--TIP0000031
	END 

		--TIP0000033 BECA PERU VIRTUAL PROVINCIAS NSE C (NO CUMPLE)
	--TIP0000034 BECA PERU VIRTUAL PROVINCIAS NSE D/E (NO CUMPLE)

	SET @CodigoBase = CASE WHEN @CodigoBase = 'TIP0000033' THEN  'TIP0000029'
							WHEN @CodigoBase = 'TIP0000034' THEN  'TIP0000030'
							END 

	SELECT @CodigoPeriodo=PE.Codigo,
	@IdUnidadAcademica=PE.IdUnidadAcademica,
	@IdUnidadNegocio=PE.IdUnidadNegocio,
	@IdActor=MA.IdActor
	FROM Matricula MA WITH (NOLOCK)
	INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
	INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
	INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON P.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo -- PARA VALIDAR QUE LA MATRICULA SE ENCUENTRE COMPLETA
	WHERE MA.IdMatricula = @IdMatricula AND P.IdUnidadNegocio = 1   AND  MA.Estado <> 'X'

	IF  @CodigoPeriodo is null
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'ERROR - NO OBTIENE MATRICULA O PRE , EN EL PERIODO A PROCESAR ' 
		RETURN
	END

	--obtenemos los periodos anteriores
	INSERT INTO @PeriodosAnteriores (CodigoPeriodoPadre,CodigoPeriodoAnterior, IdPeriodoPadre,IdPeriodoAnterior) 
	SELECT  DISTINCT PE.Codigo AS 'PADRE',PE2.Codigo AS 'ANTERIOR',PE.IdPeriodo,PE2.IdPeriodo 
	FROM PeriodoEquivalencia PEE WITH (NOLOCK)
	INNER JOIN Periodo PE WITH (NOLOCK) ON PEE.IdPeriodoPadre = PE.IdPeriodo
	INNER JOIN Periodo PE2 WITH (NOLOCK) ON PEE.IdPeriodoEquivalencia = PE2.IdPeriodo
	WHERE PE.Codigo=@CodigoPeriodo  
	AND PEE.EsSiguiente=0
	AND PE.IdUnidadAcademica=@IdUnidadAcademica 
	AND PE.IdUnidadNegocio=@IdUnidadNegocio

	-- VALIDAMOS QUE EXISTA PERIODO ANTERIOR --  EN EQUIVALENCIA  - FALTA
	IF NOT EXISTS(SELECT 1 FROM @PeriodosAnteriores)
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'ERROR - NO SE OBTIENE INFOMRACI�N SOBRE EL PERIODO ANTERIOR DEL ALUMNO (VALIDAR CONFIGURACI�N DE PERIODO)' 
		RETURN
	END

	--OBTENEMOS DATOS DE LA MATRICULA ANTERIOR DEL ALUMNO
	INSERT INTO  @MatriculaAnterior     
	(IdActor,IdMatricula,PromedioReal) 
	SELECT DISTINCT MA.IdActor, MA.IdMatricula, PGC.PromedioReal
	FROM Matricula MA WITH (NOLOCK)
	INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
	INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
	INNER JOIN PeriodoCabecera PC WITH(NOLOCK) ON PE.IdPeriodoCabecera=PC.IdPeriodoCabecera
	LEFT JOIN PromocionGrupoCierre PGC WITH(NOLOCK) ON MA.IdMatricula = PGC.IdMatricula 
	WHERE MA.IdActor=@IdActor  
	AND P.IdUnidadNegocio =@IdUnidadNegocio 
	AND P.IdUnidadAcademica=@IdUnidadAcademica
	AND MA.Estado <> 'X'
	AND PE.IdPeriodo IN (SELECT IdPeriodoAnterior FROM @PeriodosAnteriores)

	UPDATE MA SET 
	MA.IdDescuentoAcademicoBase=DAB.IdDescuentoAcademicoBase,
	MA.BaseActivo = ISNULL( DAB.Activo , 0) 
	FROM @MatriculaAnterior AS MA
	INNER JOIN DescuentoAcademicoBase AS DAB WITH(NOLOCK) ON DAB.IdActor = MA.IdActor
	INNER JOIN MaestroTablaRegistro AS MTR2  WITH(NOLOCK) ON MTR2.IdMaestroRegistro = DAB.IdMaestroRegistro 
	WHERE IdMaestroTabla =1905 AND MTR2.Codigo = @CodigoBase
	
	--Validamos Pago puntual en su carrera
	-- Cuando es primer ciclo, se valida apartir de la segunda cuota
	SELECT TOP 1 @IdMatriculaAnterior = IdMatricula , 
	@IdModuloPagoAnterior = CASE WHEN IdModulo = 1 THEN 2 ELSE 1 END,
	@PromedioReal= ISNULL(PromedioReal,0),
	@IdDescuentoAcademicoBase = IdDescuentoAcademicoBase,
	@BaseActivo = BaseActivo
	FROM @MatriculaAnterior 

	--  FALTA AGREGAR EN LA TABLA
	SELECT @PromedioBeca = Disponible1,
	@IdModuloBecaValidar=Disponible5
	FROM MaestroTablaRegistro WITH(NOLOCK) 
	WHERE IdMaestroTabla =1905 AND IdmaestroRegistro = @IdTipoConsulta
	
	SELECT @PeriodosAnterioresConcatenados = COALESCE(@PeriodosAnterioresConcatenados + ', ', '') + CAST(CodigoPeriodoAnterior AS VARCHAR(50))
	FROM (SELECT DISTINCT CodigoPeriodoAnterior FROM @PeriodosAnteriores) AS Temp
	
	--INICIAMOS LAS VALIDACIONES
	BEGIN
	
		IF @BaseActivo = 0 
		BEGIN
			SET @Retorno = 1
			SET @pDescripcion = 'SI LE CORRESPONDE LA BECA'
			RETURN	
		END 

		-- Validamos que la matricula actual tenga una matricula anterior
		IF  NOT EXISTS(SELECT 1 FROM @MatriculaAnterior)
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion= 'ERROR - NO TIENE MATRICULA ANTERIOR PARA EVALUAR : ' + @PeriodosAnterioresConcatenados
			RETURN
		END

		IF  @PromedioReal<@PromedioBeca
		BEGIN
			SET @Retorno = 1
			SET @pDescripcion= 'SI LE CORRESPONDE LA BECA POR PROMEDIO: '+ convert(varchar,@PromedioReal) --EXLUCIDO POR PROMEDIO INCLUIR EL PROMEDIO ACTUAL QUE TIENE
		
			UPDATE DescuentoAcademicoBase SET Motivo=@pDescripcion,Activo=0,FechaModificacion=GETDATE() , UsuarioModificacion=1 
			WHERE IdDescuentoAcademicoBase  =  @IdDescuentoAcademicoBase 
		 
			SET @ExcluidoPorPromedio = 1

			RETURN
		END
	
		SET @ExcluidoPorPagoPuntual=ISNULL((SELECT dbo.cPagoPuntual (@IdActor,@CompaniaSocio,@IdMatriculaAnterior, @IdModuloPagoAnterior)),0)
		IF @ExcluidoPorPagoPuntual = 1 
		BEGIN
			SET @Retorno = 1
			SET @pDescripcion= 'SI LE CORRESPONDE LA BECA POR PAGO PUNTUAL: ' + @PeriodoCodigoMatriculaAnterior

			UPDATE DescuentoAcademicoBase SET Motivo=@pDescripcion,Activo=0,FechaModificacion=GETDATE() , UsuarioModificacion=1 
			WHERE IdDescuentoAcademicoBase  =  @IdDescuentoAcademicoBase 

			RETURN
		END

		IF @ExcluidoPorPagoPuntual = 1 AND @ExcluidoPorPromedio = 1
		BEGIN
			SET @Retorno = 1
			SET @pDescripcion = 'SI LE CORRESPONDE LA BECA POR NO CUMPLIR ALGUN REQUISITO'
			UPDATE DescuentoAcademicoBase SET Motivo=@pDescripcion,Activo=0,FechaModificacion=GETDATE() , UsuarioModificacion=1 
			WHERE IdDescuentoAcademicoBase  =  @IdDescuentoAcademicoBase 
			RETURN	
		END 
		ELSE
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion = 'ERROR AL REALIZAR EVALUACION'
			RETURN
		END 

	END