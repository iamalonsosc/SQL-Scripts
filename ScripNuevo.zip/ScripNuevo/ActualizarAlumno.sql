 -----------------
 ---- ALUMNOS ----
 -----------------

DECLARE @matricula TABLE
(Division VARCHAR(200),
Programa VARCHAR(200),
ProductoNombre VARCHAR(200),
AlumnoId INT,
AlumnoCodigo VARCHAR(20),
NombreCompleto VARCHAR(200),
EmailInstitucion VARCHAR(200),
InscritoFecha DATETIME,
Estado VARCHAR(20))

INSERT INTO @matricula
select 
UN.Nombre,
UA.Nombre,
pr.ProductoNombre,
m.IdActor,
AL.CodigoAnterior,
a.NombreCompleto,
AL.EmailInstitucion,
'InscritoFecha'=MAX(M.InscritoFecha),
'Matriculado'
from matricula m WITH(NOLOCK)
INNER JOIN promocion p WITH(NOLOCK)on m.idpromocion = p.idpromocion 
INNER JOIN UnidadNegocio UN WITH(NOLOCK)on P.IdUnidadNegocio=UN.IdUnidadNegocio
INNER JOIN UnidadAcademica UA WITH(NOLOCK)on P.IdUnidadAcademica=UA.IdUnidadAcademica
INNER JOIN periodo pe WITH(NOLOCK)on p.idperiodo = pe.idperiodo
INNER JOIN Actor a WITH(NOLOCK)on m.IdActor = a.IdActor 
INNER JOIN Alumno AL WITH(NOLOCK)on m.IdActor = AL.IdAlumno 
INNER JOIN Producto pr WITH(NOLOCK) on p.IdProducto = pr.IdProducto
INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON pr.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro  --@1
where p.IdEmpresa = 1
--AND p.IdFacultad = 1
--AND p.IdUnidadNegocio = 1
--AND P.IdPeriodoAnual IN (2024)
AND M.EsMatricula = 1
AND m.Estado!='X'
--AND CONVERT(VARCHAR,M.InscritoFecha,112)='20240514'
GROUP BY  
UN.Nombre,
UA.Nombre,
pr.ProductoNombre,
m.IdActor,
AL.CodigoAnterior,
a.NombreCompleto,
AL.EmailInstitucion

INSERT INTO @matricula
select UN.Nombre,
UA.Nombre,
pr.ProductoNombre,
m.IdActor,
AL.CodigoAnterior,
a.NombreCompleto,
AL.EmailInstitucion,
'InscritoFecha'=MAX(M.InscritoFecha),
'PreMatriculado'
from matricula m WITH(NOLOCK)
INNER JOIN promocion p WITH(NOLOCK)on m.idpromocion = p.idpromocion 
INNER JOIN UnidadNegocio UN WITH(NOLOCK)on P.IdUnidadNegocio=UN.IdUnidadNegocio
INNER JOIN UnidadAcademica UA WITH(NOLOCK)on P.IdUnidadAcademica=UA.IdUnidadAcademica
INNER JOIN periodo pe WITH(NOLOCK)on p.idperiodo = pe.idperiodo
INNER JOIN Actor a WITH(NOLOCK)on m.IdActor = a.IdActor 
INNER JOIN Alumno AL WITH(NOLOCK)on m.IdActor = AL.IdAlumno 
INNER JOIN Producto pr WITH(NOLOCK) on p.IdProducto = pr.IdProducto
INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON pr.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro  --@1
where p.IdEmpresa = 1
--AND p.IdFacultad = 1
--AND p.IdUnidadNegocio = 1
--AND P.IdPeriodoAnual IN (2024)
AND M.EsMatricula = 0
AND m.Estado!='X'
--AND CONVERT(VARCHAR,M.InscritoFecha,112)='20240514'
AND NOT EXISTS (SELECT 1 FROM @matricula M2 
				WHERE M.IdActor=M2.AlumnoId)
GROUP BY 
UN.Nombre,
UA.Nombre,
pr.ProductoNombre,
m.IdActor,
AL.CodigoAnterior,
a.NombreCompleto,
AL.EmailInstitucion

SELECT Division,
Programa,
ProductoNombre ,
AlumnoId ,
AlumnoCodigo ,
NombreCompleto ,
EmailInstitucion,
'InscritoFecha' =CONVERT(VARCHAR,InscritoFecha,103),
Estado  
FROM @matricula
ORDER BY  Division,
Programa, productonombre,NombreCompleto

-- SELECT*
----UPDATE AL SET AL.EmailInstitucion=replace(AL.EmailInstitucion,'idat.edu','idat')
-- FROM Alumno AL
-- INNER JOIN @matricula MA on MA.AlumnoId = AL.IdAlumno 


--SELECT*
----UPDATE us SET us.EMAIL=replace(us.EMAIL,'idat.edu','idat')
--FROM Usuario us
--INNER JOIN @matricula MA on MA.AlumnoId = us.IdActor 
--where us.IdTipoUsuario=1 


--SELECT*FROM Usuario WHERE Login='SV70508580'