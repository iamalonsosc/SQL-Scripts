UPDATE Curricula SET NombrePlanEstudio='PLAN 2023'
--SELECT*FROM Curricula
WHERE NombrePlanEstudio IS NULL  AND 
IdCurricula IN (5799,5801,5803,5805,5806,5815)
--(6 rows affected)