--ZAVALA GUEVARA PEDRO RAUL
declare @p7_1 int
set @p7_1=0
exec cMatricula_Pro_Anular @IdActor=1621074,@IdMatricula=453448,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_1 output 
select @p7_1

--ALFARO GARCIA EDSON AARON
declare @p7_2 int
set @p7_2=0
exec cMatricula_Pro_Anular @IdActor=1635954,@IdMatricula=481870,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_2 output 
select @p7_2

--HERNANDEZ RODRIGUEZ LUZMILA ESMERALDA
declare @p7_3 int
set @p7_3=0
exec cMatricula_Pro_Anular @IdActor=1299298,@IdMatricula=456319,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_3 output 
select @p7_3

--TORRES MAGUI�O LUCERO ALEXIA
declare @p7_4 int
set @p7_4=0
exec cMatricula_Pro_Anular @IdActor=1510381,@IdMatricula=465291,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_4 output 
select @p7_4

--GUTIERREZ RODRIGUEZ EMILY KATHERINE
declare @p7_5 int
set @p7_5=0
exec cMatricula_Pro_Anular @IdActor=1616708,@IdMatricula=473198,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_5 output 
select @p7_5

--ORME�O MORALES MICHAEL JORDAN
declare @p7_6 int
set @p7_6=0
exec cMatricula_Pro_Anular @IdActor=843145,@IdMatricula=456377,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_6 output 
select @p7_6

--GOICOCHEA RABINES HENRY STIWAR
declare @p7_7 int
set @p7_7=0
exec cMatricula_Pro_Anular @IdActor=1643341,@IdMatricula=486313,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_7 output 
select @p7_7

--MIJA AVILA YOVELY
declare @p7_8 int
set @p7_8=0
exec cMatricula_Pro_Anular @IdActor=1511492,@IdMatricula=473054,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_8 output 
select @p7_8

--MAMANI LARICO LISBETH
declare @p7_9 int
set @p7_9=0
exec cMatricula_Pro_Anular @IdActor=1622194,@IdMatricula=456330,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_9 output 
select @p7_9

--MIL SANCHEZ JEFFERSON JEAN POOL
declare @p7_10 int
set @p7_10=0
exec cMatricula_Pro_Anular @IdActor=1634879,@IdMatricula=479894,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_10 output 
select @p7_10

--SERNAQUE CORTEZ ARABIA ODILIA
declare @p7_11 int
set @p7_11=0
exec cMatricula_Pro_Anular @IdActor=1622063,@IdMatricula=456165,@Observacion=N'Anulaci�n de la matricula por el ticket #57627 aprobado por Judith',@UsuarioCreacion=1,@TipoAnulacion=25347,@IdRegistro=NULL,@RetVal=@p7_11 output 
select @p7_11