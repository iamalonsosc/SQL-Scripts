--SELECT*FROM Curricula WHERE IdCurricula=5802

UPDATE Curricula SET NombrePlanEstudio='PLAN 2023'
WHERE IdCurricula=5802
--(1 row affected)