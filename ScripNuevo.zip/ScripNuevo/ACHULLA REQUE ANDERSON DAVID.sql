SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1431894 
--AND AC.IdCurso=10160 
--AND AC.IdMatricula=640258 
--AND AC.EsMatricula=1
order by ac.idregistro,ac.IdAlumnoCurso desc

SELECT*FROM Seccion WHERE IdPromocion=96872 AND IdCurso=9934

INSERT INTO AlumnoCurso VALUES (1431894,4,37,5604,9934,640258,96872,2,633015,null,null,'17.00','17.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL,PromedioFinal='17.00',PromedioReal= '17.00',IdAlumnoCurso=37,TipoCondicion='RE'
--select*from AlumnoCurriculaCurso 
where IdAlumno=1431894 and IdCurso=9934 AND IdRegistro=4