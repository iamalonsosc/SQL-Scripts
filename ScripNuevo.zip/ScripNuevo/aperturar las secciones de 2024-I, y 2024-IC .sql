select* from periodo where codigo in('2024-I','2024-IC');
select*from UnidadNegocio where idunidadnegocio=26


UPDATE SE set SE.Estado='A'
		FROM Periodo PE WITH(NOLOCK)
		INNER JOIN Promocion PR WITH(NOLOCK) ON PE.IdPeriodo=pr.IdPeriodo
		INNER JOIN	Seccion SE WITH(NOLOCK) ON PR.IdPromocion=se.IdPromocion
		WHERE PE.Codigo in('2024-I','2024-IC')
		AND SE.Estado='F'

--(2451 rows affected)

