 -----------------------------------------------------------------------------
--Creado por: Alonso Sanchez (01/04/2025)
--Funcionalidad : 
--Utilizado por :
--����������������������������������������������������������������������������
/*
-----------------------------------------------------------------------------
NroFECHAUSUARIO DESCRIPCION
-----------------------------------------------------------------------------

*/
CREATE PROCEDURE [dbo].[cMatricula_DetalleAlumno] 
@IdEmpresa INT,
@IdSede INT,
@IdFacultad INT,
@IdUnidadNegocio INT,
@IdUnidadAcademica INT,
@IdPeriodo INT,
@IdProducto INT,
@PeriodoCodigo varchar(20),
@IdAlumno INT,
@IdMatricula INT
AS
BEGIN

SET NOCOUNT ON


   SELECT DISTINCT 
   'PeriodoCodigo'=PE.Codigo
   ,'IdMatricula'=M.IdMatricula
   ,'AlumnoNombreCompleto'=ACT.NombreCompleto
   ,'CursoCodigo'=C.CursoCodigo
   ,'CursoNombre'=C.CursoNombre
   ,'CursoPromocionCodigo'=P.PromocionCodigo
   ,'CursoGrupoCodigo'=PG.GrupoCodigo
   ,'CodigoHorario' = S.Codigo
   ,'CodigoCursoMoodle' = ISNULL(MO.ShortName,'')
   ,'MaterialesMoodle' = ISNULL(MO.Material,'')
   ,'Estado' = M.Estado
   ,'EsAsincrono' = S.EsAsincronico
   ,'CorreoEnviado'=EC.Enviado
   ,'EstadoDelEnvio'= case when EC.Estado=1 THEN 'ENVIADO'ELSE 'NO ENVIADO' END 
	FROM Promocion P WITH(NOLOCK)
	INNER JOIN PromocionGrupo PG WITH(NOLOCK)ON PG.IdPromocion=P.IdPromocion
	INNER JOIN CurriculaModulo CM WITH(NOLOCK)ON CM.IdCurricula=P.IdCurricula AND CM.IdModulo=isnull(P.IdModulo,1)
	INNER JOIN Seccion S WITH(NOLOCK)ON S.IdPromocion = PG.IdPromocion AND S.IdGrupo = PG.IdGrupo
	INNER JOIN AlumnoCurso AC WITH(NOLOCK) ON S.IdCurso = AC.IdCurso AND S.IdSeccion = AC.IdSeccion AND S.IdPromocion = AC.IdPromocion AND S.IdGrupo = AC.IdGrupo
	INNER JOIN Matricula M WITH(NOLOCK)ON ac.idmatricula = m.idmatricula
	LEFT JOIN BDSMTP.dbo.EnvioCorreo EC ON EC.IdMatricula=M.IdMatricula
	INNER JOIN Periodo PE WITH(NOLOCK) On PE.IdPeriodo = P.IdPeriodo
	INNER JOIN Promocion PR_M WITH(NOLOCK) ON PR_M.IdPromocion=M.IdPromocion
	INNER JOIN PromocionGrupo PG_M WITH(NOLOCK) ON PG_m.IdPromocion=M.IdPromocion and PG_M.IdGrupo=M.IdGrupo
	INNER JOIN Curso C WITH(NOLOCK)ON C.IdCurso = AC.IdCurso
	INNER JOIN Actor ACT WITH(NOLOCK) ON ACT.IdActor = M.IdActor
	LEFT JOIN BI.CursoMoodle MO WITH(NOLOCK) ON S.IdSeccion=MO.IdCurso
	WHERE
	 P.IdEmpresa=@IdEmpresa                                
	AND P.IdFacultad=@IdFacultad                                
	AND P.IdUnidadNegocio=@IdUnidadNegocio                 
	AND P.IdUnidadAcademica=@IdUnidadAcademica                            
	AND(P.IdProducto = @IdProducto OR  @IdProducto = -1)                        
	AND PE.Codigo =@PeriodoCodigo        
	AND M.IdMatricula=@IdMatricula 
	AND EC.Asunto='Bienvenido a IDAT'


SET NOCOUNT OFF 
END 
