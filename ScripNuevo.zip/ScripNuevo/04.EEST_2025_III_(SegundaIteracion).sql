USE AcademicoIDAT;

GO



--- III TipoCondicionMatricula

UPDATE Matricula SET TIPOCONDICION = 'RT' WHERE IdMatricula = 717695;
UPDATE Matricula SET TIPOCONDICION = 'RT' WHERE IdMatricula = 729813;
UPDATE Matricula SET TIPOCONDICION = 'RT' WHERE IdMatricula = 743688;


--- III	TipoCondicionVisual

UPDATE AC
  SET AC.TipoCondicion = 'RE'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 725600
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LECTURA COMPRENSIVA Y ESCRITURA';
UPDATE AC
  SET AC.TipoCondicion = 'RE'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 725600
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SOPORTE DE TI';
UPDATE AC
  SET AC.TipoCondicion = 'RE'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 725600
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTRAPERSONALES';
UPDATE AC
  SET AC.TipoCondicion = 'RE'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 725600
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO WEB';
UPDATE AC
  SET AC.TipoCondicion = 'RE'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 725600
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'FUNDAMENTOS DE PROGRAMACIÓN';
UPDATE AC
  SET AC.TipoCondicion = 'RE'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 725600
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'FUNDAMENTOS LÓGICO-MATEMÁTICOS PARA EL DESARROLLO DE SISTEMAS';
UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 747705
 AND 
 (
  UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DISEÑO DE PLANOS 2D' OR
  UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DISEÑO DE PLANOS  2D'
 )
  
UPDATE AC
  SET AC.TipoCondicion = 'CC'
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  WHERE AC.IdMatricula = 747698
 AND 
 (
  UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DISEÑO DE PLANOS 2D' OR
  UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DISEÑO DE PLANOS  2D'
 )



--- IIID
UPDATE Matricula SET TIPOCONDICION = 'RP' WHERE IdMatricula = 756037;

