EXEC cDescuentoAcademicoReporte_Xls_DES007 @PeriodoCodigo='2024-III'
	