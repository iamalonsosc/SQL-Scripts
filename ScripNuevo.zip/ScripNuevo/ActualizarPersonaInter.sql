UPDATE persona_inter SET procesado='XX',tiporegistro='X'
WHERE id=1132578

UPDATE persona_inter SET tiporegistro='I'
WHERE id=1146383