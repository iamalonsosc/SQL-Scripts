--# Cat�logo de motivos de exclusi�n � `cAsignacion_BecaActivate`

--Este documento enumera **todos** los puntos del SP donde un alumno puede quedar
--excluido de la beca (`@Retorno = 0`). Est�n agrupados por la secci�n del
--procedimiento que los eval�a, en el mismo orden en que se ejecutan.

--Recuerda: el SP corta con `RETURN` en el **primer** motivo que encuentra, as�
--que si un alumno falla por dos razones a la vez, el `@pDescripcion` solo te
--va a mostrar la primera. Por eso el script de pruebas (`test_cAsignacion_BecaActivate.sql`)
--incluye casos independientes por motivo � para poder verificar cada regla por separado.

-----

--## A. Validaciones comunes (aplican a CUALQUIER alumno, sin importar compa��a o TIP)

--Se eval�an siempre, antes de entrar a cualquier l�gica espec�fica.

--| # | Variable bandera | Mensaje (`@pDescripcion`) | Cu�ndo ocurre |
--|---|---|---|---|
--| A1 | `@ExcluidoPorNoTenerMatriculaAProcesar` | `NO OBTIENE MATRICULA O PRE, EN EL PERIODO A PROCESAR.` | El alumno no tiene matr�cula (ni PRE) activa en el per�odo que se est� procesando. |
--| A2 | `@ExcluidoPorPeriodoAnterior` | `NO SE OBTIENE INFORMACION SOBRE EL PERIODO ANTERIOR DEL ALUMNO (VALIDAR CONFIGURACION DE PERIODO)` | No existe configuraci�n de `PeriodoEquivalencia` para encontrar el per�odo anterior al actual. Es un problema de configuraci�n de per�odos, no del alumno. |
--| A3 | `@ExcluidoPorBase` | `ALUMNO NO SE ENCUENTRA REGISTRADO EN LA BASE <CodigoBase>` | El alumno no tiene un registro de `DescuentoAcademicoBase` activo para el `@CodigoBase` (TIP) que se est� evaluando. |
--| A4 | `@ExcluidoPorNoTenerMatricula` | `EXCLUIDO POR NO TENER UNA MATRICULA ANTERIOR - EN LOS PERIODOS: <lista>` | No se encontr� ninguna matr�cula del alumno en los per�odos anteriores equivalentes. |
--| A5 | `@ExcluidoPorBeca` | `EXCLUIDO POR NO CONTAR CON LA BECA ACTIVATE EN SU MATRICULA ANTERIOR - EN EL PERIODO: <periodo>` | El alumno no ten�a la beca (ni en `DescuentoAlumnoResultado` ni en `DescuentoAlumno`) en su matr�cula del per�odo anterior. |

--## B. Solo Corriente Alterna (`CompaniaSocio = 00002600`)

--Se eval�a despu�s de las validaciones comunes, �nicamente para esta compa��a. Si entra aqu�, siempre termina con `RETURN` (aprueba o rechaza, no sigue de largo).

--| # | Variable bandera | Mensaje | Cu�ndo ocurre |
--|---|---|---|---|
--| B1 | `@ExcluidoPorBeca` | `EXCLUIDO POR NO CONTAR CON LA BECA ACTIVATE EN SU MATRICULA ANTERIOR...` | Repetici�n de A5, espec�fica para CA (`@18`). |
--| B2 | `@ExcluidoPorPromedio37` | `EXCLUIDO POR PROMEDIO, EL PROMEDIO DEL ALUMNO ES: <promedio>` | El promedio real del alumno es menor al promedio m�nimo exigido por la beca. |
--| B3 | `@ExcluidoPorPagoPuntual` | `EXCLUIDO POR PAGO PUNTUAL EN SU MATRICULA ANTERIOR, EL PERIODO DE LA MATRICULA ES: <periodo>` | El alumno no pag� puntualmente en su matr�cula anterior (funci�n `dbo.cPagoPuntual`). |

--## C. L�gica unificada por TIP (aplica a cualquier compa��a � Zegel, IDAT, etc.)

--TIP: `TIP0000014,017,037,047,049,050,051,052,053,056,058,059,060`. Cada regla solo se eval�a si el switch correspondiente (`Disponible1-9` en `MaestroTablaRegistro`) est� activo para ese TIP.

--| # | Variable bandera | Mensaje | Cu�ndo ocurre | Switch que la activa |
--|---|---|---|---|---|
--| C1 | `@ExcluidoPorPromedio37` | `EXCLUIDO POR PROMEDIO (LOGICA <TIP>)...` | Promedio real < promedio m�nimo de la beca. | `Disponible1` |
--| C2 | `@ExcluidoPorSecuencialidad` | `EXCLUIDO POR SECUENCIALIDAD MAYOR AL CUARTO CICLO (LOGICA TIP0000052)` | **Solo TIP0000052**: el alumno ya us� la beca en 4 o m�s ciclos distintos. | `Disponible8` (regla especial hardcodeada para este TIP) |
--| C3 | `@ExcluidoPorSecuencialidad` | `EXCLUIDO POR SECUENCIALIDAD MAYOR AL SEGUNDO CICLO (LOGICA <TIP>)` | Para el resto de TIP de este grupo: el per�odo de la matr�cula anterior no es consecutivo al per�odo base de la beca (o sea, ya pas� de su segundo ciclo). | `Disponible8` |
--| C4 | `@ExcluidoPorCambioDeModalidad` | `EXCLUIDO POR TENER UN CAMBIO DE MODALIDAD (LOGICA <TIP>)...` | Cambi� de sede **y** esa sede est� marcada como modalidad virtual (par�metro `SEDEMODVIRTUAL`). | `Disponible3` |
--| C5 | `@ExcluidoPorCambioSede` | `EXCLUIDO POR CAMBIO DE SEDE (LOGICA <TIP>)...` | Cambi� de sede entre su matr�cula anterior y la actual (y no fue un traslado de programa reconocido). | `Disponible4` |
--| C6 | `@ExcluidoPorRetiro` | `EXCLUIDO POR RETIRO DE CICLO EN SU MATRICULA ANTERIOR (LOGICA <TIP>)` | Tuvo un retiro de ciclo (`MatriculaRetiro`, Tipo='RC') en su matr�cula anterior. | `Disponible2` |
--| C7 | `@ExcluidoPorCondicion` | `EXCLUIDO POR TIPO DE CONDICION (NO REGULAR), ACTUAL : <tipo>` | Su condici�n actual no es "RE" (Regular/Promovido). | `Disponible6` |
--| C8 | `@ExcluidoPorCambioCarrera` | `EXCLUIDO POR CAMBIO DE CARRERA, ANTERIOR: <x> y ACTUAL: <y>` | Cambi� de producto/carrera entre la matr�cula anterior y la actual. | `Disponible9` **(reci�n corregido � antes nunca se activaba, ver bit�cora @22)** |
--| C9 | `@ExcluidoPorTurno` | `EXCLUIDO POR CAMBIO DE TURNO: ANTERIOR (<x>) y ACTUAL (<y>)` | **Solo TIP0000014**: cambi� de turno entre la matr�cula anterior y la actual. | Hardcodeado (no usa switch) |
--| C10 | `@ExcluidoPorPagoPuntual` | `EXCLUIDO POR PAGO PUNTUAL EN SU MATRICULA ANTERIOR (LOGICA <TIP>)...` | No pag� puntualmente en su matr�cula anterior. | `Disponible7` |

--## D. L�gica "legacy" (fallback � cualquier compa��a/TIP que no calz� en A, B o C)

--Estas reglas se eval�an siempre que el alumno llegue hasta aqu� sin haber sido capturado antes. A diferencia del bloque C, **la mayor�a no usa switches** � son incondicionales.

--| # | Variable bandera | Mensaje | Cu�ndo ocurre | �Condicional? |
--|---|---|---|---|---|
--| D1 | `@ExcluidoPorTurno` | `EXCLUIDO POR CAMBIO DE TURNO: ANTERIOR (<x>) y ACTUAL (<y>)` | Cambi� de turno. | Solo si `@Validacion2024 = 0` (per�odo base anterior a 2024) |
--| D2 | `@ExcluidoPorCambioCarrera` | `EXCLUIDO POR CAMBIO DE CARRERA, ANTERIOR: <x> y ACTUAL: <y>` | Cambi� de carrera/producto. | Solo si `@Validacion2024 = 0` |
--| D3 | `@ExcluidoPorCondicion` | `EXCLUIDO POR TIPO DE CONDICION (NO REGULAR), ACTUAL: <tipo>` | Su condici�n actual no es "RE". | **Incondicional** |
--| D4 | `@ExcluidoPorRetiro` | `EXCLUIDO POR RETIRO DE CICLO EN SU MATRICULA ANTERIOR` | Tuvo un retiro de ciclo en su matr�cula anterior. | **Incondicional** |
--| D5 | `@ExcluidoPorCambioDeModalidad` | `EXCLUIDO POR TENER UN CAMBIO DE MODALIDAD EN SU MATRICULA EN EL PERIODO: <periodo>` | Cambi� de sede y modalidad virtual (seg�n `SEDEMODVIRTUAL`). | Solo si `@ValidaCambioDeModalidad = 1` (par�metro por sede) |
--| D6 | `@ExcluidoPorCambioSede` | `EXCLUIDO POR CAMBIO DE SEDE, ANTERIOR: <x> y ACTUAL ES: <y>` | Cambi� de sede. | **Incondicional** |
--| D7 | `@ExcluidoPorPromedio` | `EXCLUIDO POR PROMEDIO, EL PROMEDIO DEL ALUMNO ES: <promedio>` | Promedio real menor al m�nimo exigido. | Solo si `@IdModuloActual > @IdModuloBecaValidar` |
--| D8 | `@ExcluidoPorPagoPuntual` | `EXCLUIDO POR PAGO PUNTUAL EN SU MATRICULA ANTERIOR, EL PERIODO DE LA MATRICULA ES: <periodo>` | No pag� puntualmente. | Solo si `@IdModuloActual > @IdModuloBecaValidar` |
--| D9 | *(gen�rico)* | `NO LE CORRESPONDE LA BECA.` | Catch-all: si al llegar al final ALGUNA de las banderas `@ExcluidoPor...` qued� en 1 (evaluadas todas juntas en el `IF` final), pero ninguna hizo `RETURN` antes (caso te�ricamente raro, red de seguridad). | Combina todas las banderas D1-D8 + A1-A5 |

-----

--## Resumen ejecutivo: �por qu� puede perder la beca un alumno?

--En t�rminos de negocio, sin importar la secci�n del c�digo, las causas ra�z son:

--1. **No tiene matr�cula vigente** en el per�odo a procesar.
--2. **Problema de configuraci�n de per�odos** (no es culpa del alumno � hay que revisar `PeriodoEquivalencia`).
--3. **No est� registrado** en la base de la beca que se est� evaluando.
--4. **No tiene matr�cula anterior** en un per�odo equivalente.
--5. **No ten�a la beca en su matr�cula anterior** (no es continuidad, sino un alumno nuevo entrando a la beca).
--6. **Promedio insuficiente.**
--7. **Ya us� la beca m�s ciclos de los permitidos** (secuencialidad � 2 ciclos en general, 4 para TIP0000052).
--8. **Cambio de modalidad** (de presencial a virtual o viceversa, en sede marcada como tal).
--9. **Cambio de sede.**
--10. **Retiro de ciclo** en su matr�cula anterior.
--11. **Condici�n no regular** (repitencia / curso, no promovido).
--12. **Cambio de carrera.**
--13. **Cambio de turno** (solo aplica a la beca TIP0000014).
--14. **No pag� puntualmente** su matr�cula anterior.

--Todas estas, salvo la 1 y la 2 (que son de datos/configuraci�n, no de la conducta del alumno), son las 12 causas "de negocio" reales por las que un alumno pierde la beca.
