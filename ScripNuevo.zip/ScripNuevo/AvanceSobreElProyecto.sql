SELECT DISTINCT  Ma.IdMatricula
,ec.IdMatricula
,AC.NombreCompleto
,'CorreoEnviado'=EC.Enviado
,'EstadoDelEnvio'= case when EC.Estado=1 THEN 'ENVIADO'ELSE 'NO ENVIADO' END 
,'Sincronico'= case when SEC.EsAsincronico=1 THEN 'SI'ELSE 'NO' END 
,cu.CursoNombre
FROM Matricula MA
LEFT JOIN BDSMTP.dbo.EnvioCorreo EC ON EC.IdMatricula=MA.IdMatricula
INNER JOIN Promocion PRO ON PRO.IdPromocion=Ma.IdPromocion
INNER JOIN Periodo PE ON PE.IdPeriodo=PRO.IdPeriodo
INNER JOIN Actor AC ON AC.IdActor=MA.IdActor
INNER JOIN AlumnoCurso ACU ON ACU.IdAlumno=AC.IdActor
INNER JOIN Seccion SEC ON SEC.Idseccion=ACU.IdSeccion
INNER JOIN Curso cu ON cu.IdCurso=SEC.IdCurso
WHERE PE.Codigo='2025-I' 
AND MA.Estado <> 'X'
AND MA.EsMatricula=1
AND EC.Asunto='Bienvenido a IDAT'
AND AC.NombreCompleto='PAICO PAICO ALDO DAVID'

--SELECT*FROM Seccion WHERE EsAsincronico=1


--SELECT *FROM [AcademicoIDAT].[BI].[CursoMoodle]
--SELECT TOP 10 *FROM Seccion where Idseccion=643962 