declare @p8 int
set @p8=-2
exec EVA_AlumnoCursoAsistencia_Grabar @IdSeccion=649166,@IdHorario=3,@IdSesion=1,@IdAlumno=1777200,@Valor=N'A',@IdMarca=1,@IdUsuarioLog=461702,@RetVal=@p8 output
select @p8
go
declare @p8 int
set @p8=-2
exec EVA_AlumnoCursoAsistencia_Grabar @IdSeccion=649166,@IdHorario=3,@IdSesion=1,@IdAlumno=1777200,@Valor=N'F',@IdMarca=1,@IdUsuarioLog=461702,@RetVal=@p8 output
select @p8
go
exec EVA_Asistencia_ListarNotificacion @IdSeccion=649166,@IdHorario=3,@IdSesion=1,@IdActor=1777200,@ValorAsistencia=N'A',@IdMarca=1
go
exec EVA_Asistencia_ListarNotificacion @IdSeccion=649166,@IdHorario=3,@IdSesion=1,@IdActor=1777200,@ValorAsistencia=N'F',@IdMarca=1
go

select*from AlumnoCursoAsistencia where IdSeccion=649166 and IdAlumno=1777200
select top 10 *from DescuentoAcademicoCombinacion