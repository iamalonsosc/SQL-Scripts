--SELECT  *
--FROM   alumnocurriculacurso WITH(nolock)
update alumnocurriculacurso set IdAlumnoCurso = null,PromedioFinal= null,PromedioReal= null,PromedioCondicion= null,FechaModificacion= null,UsuarioModificacion= null
WHERE  IdModulo=6
and idregistro = 2 --@6       
AND idcurricula = 5617
AND idalumno = 1244708
--(7 rows affected)