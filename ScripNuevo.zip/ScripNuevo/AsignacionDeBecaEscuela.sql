DECLARE
@PeriodoCodigo varchar(14) ='2024-III'
,@IdUnidadNegocio INT =1
,@IdUnidadAcademica INT=57
--AS 
DECLARE @MIN INT , @MAX INT,@IdMatricula INT,@pDescripcion varchar(500) ,@pEstado varchar(500)

CREATE TABLE #Matricula ( Id INT IDENTITY(1,1) PRIMARY KEY ,
IdMatricula INT
,SedeNombre			VARCHAR(500)
,NumeroDocumento	VARCHAR(100)
,NombreActor		VARCHAR(500)
,CodigoAlumno		VARCHAR(500)
,PromocionCodigo	VARCHAR(500)
,PromocionNombre	VARCHAR(500)
,Seccion			VARCHAR(500)
,Turno				VARCHAR(500)
,PeriodoCodigo		VARCHAR(100) 
,BaseComercial		VARCHAR(500) 
,BasePertence		VARCHAR(500) 
,CondicionMatricula VARCHAR(500)
,TipoServicio		VARCHAR(100)
,CondicionPago		VARCHAR(500)
,FechaMatricula		VARCHAR(500)
,Estado				VARCHAR(500)  
,Estado_Actual		VARCHAR(500)
,Oferta_Alumno		VARCHAR(500)
,Beca_Actual		VARCHAR(500)
,Observacion		VARCHAR(500))


DECLARE @MAESTROTABLAREGISTRO TABLE (Id INT IDENTITY(1,1) PRIMARY KEY,
IdMaestroRegistro INT,
Codigo VARCHAR(500),
Nombre VARCHAR(500),
Activo INT);

INSERT INTO @MAESTROTABLAREGISTRO
SELECT IdMaestroRegistro,Codigo,Nombre,Activo FROM  MaestroTablaRegistro
WHERE IdMaestroTabla =1905 and Codigo IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019','TIP0000037')

insert into #Matricula
SELECT DISTINCT  M.IdMatricula,
s.Nombre ,
ISNULL(Ac.NumeroIdentidad,''),
Ac.NombreCompleto ,
ISNULL(AL.CodigoAnterior,''),
ISNULL(p.PromocionCodigo,''),
ISNULL(p.PromocionNombre,'')Carrera,
ISNULL(pg.GrupoCodigo,'') Seccion,
ISNULL(T.Nombre,'') Turno,
ISNULL(pe.Codigo,'') Periodo ,
'[' + s.Codigo + '] [' + b.PeriodoCodigo + '] [' + pr.ProductoNombre + ']' ,
mtr.Nombre ,
'CondicionMatricula' = case m.TipoCondicion when 'RE' then 'PROMOVIDO' when 'RP' then 'PROMOVIDO + CURSO' when 'RT' then 'REPITENTE' when 'CC' then 'CURSO REPITENCIA' end,
'TipoServicio' = CASE WHEN M.TipoServicio = 'P' THEN 'PRODUCTO' WHEN M.TipoServicio = 'C' THEN 'CURSO' WHEN M.TipoServicio = 'M' THEN 'PRODUCTO + CURSO' ELSE '' END ,
'CondicionPago' = case  when condicionpago = 'C' then 'CONTADO' ELSE 'CUOTAS' END ,   
'FechaMatricula' = convert(varchar, ISNULL(m.MatriculaFecha, M.InscritoFecha), 103),
'Estado' = case when m.EsMatricula  = 1 then 'MATRICULADO' ELSE 'PRE' END,
'Estado_Actual' = CASE M.Estado  WHEN 'N' THEN 'NORMAL'   WHEN 'X' THEN 'ANULADO' WHEN 'R' THEN 'RETIRO CICLO' END ,'','',
'' FROM MATRICULA M
INNER JOIN Actor AC WITH(NOLOCK) ON M.IdActor = Ac.IdActor
INNER JOIN Alumno AL WITH(NOLOCK) ON AC.IdActor = AL.IdAlumno
INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion
INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo 
INNER JOIN DescuentoAcademicoBase B WITH(NOLOCK) ON B.IDACTOR = M.IDACTOR AND B.Activo=1
INNER JOIN @MAESTROTABLAREGISTRO MTR  ON MTR.IdMaestroRegistro = B.IdMaestroRegistro --AND MTR.Codigo IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019')
INNER JOIN sede s WITH(NOLOCK) on s.IdSede = b.IdSede --Todo beca activate debe tener sede
INNER JOIN Producto pr WITH(NOLOCK) on pr.IdProducto = b.IdProducto --Todo beca activate debe tener producto
--INNER JOIN DescuentoAlumnoEvidencia DAE WITH(NOLOCK) ON DAE.IdMatricula=M.IdMatricula --VALIDAR DESCUENTOS MANUALES
LEFT JOIN PromocionGrupo pg  WITH(NOLOCK) on pg.IdPromocion = m.IdPromocion and pg.IdGrupo = m.IdGrupo   
LEFT JOIN Turno t  WITH(NOLOCK)on t.IdTurno = pg.IdTurno   
WHERE PE.CODIGO = @PeriodoCodigo
AND (P.IdUnidadNegocio= @IdUnidadNegocio OR ISNULL(@IdUnidadNegocio,-1)=-1 )--@4
AND (P.IdUnidadAcademica= @IdUnidadAcademica OR ISNULL(@IdUnidadAcademica,-1)=-1 )--@4
AND M.Estado <>'X'

--SELECT*FROM #Matricula
--RETURN
SELECT @MIN = MIN(ID), @MAX = MAX(ID) from #Matricula

WHILE @MIN <= @MAX
BEGIN

	SET @IdMatricula = NULL 
	
	SELECT @IdMatricula = IdMatricula  FROM #Matricula WHERE ID = @Min
	EXEC cDescuentoAlumno_Upd_AutoAsignarXmatricula @IdMatricula=@IdMatricula,@FechaConsulta='20240923'
	SET @Min=@Min+1
	PRINT @Min
END 

SELECT*FROM #Matricula
ORDER BY ID
DROP TABLE #Matricula 