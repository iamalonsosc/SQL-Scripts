--SELECT*FROM AlumnoCursoNomina 

----UPDATE AlumnoCursoNomina SET IdCurricula=5803
--WHERE IdMatricula=669188


--select idcurriculaoriginal,idcursooriginal, *from alumnocurso 

update alumnocurso set idcurriculaoriginal=5803
where idmatricula=669188 and esmatricula=1
--5614
--(2 filas afectadas)
--SELECT*FROM PRODUCTO WHERE IdProducto=11352

UPDATE AlumnoCurriculaCurso SET IdCurricula=5803--5614
WHERE IdAlumno=1576704 AND IdRegistro=1 AND IdCurso=10570
--select*from AlumnoCurriculaCurso 
UPDATE AlumnoCurriculaCurso SET IdCurricula=5803--5614
WHERE IdAlumno=1576704 AND IdRegistro=1 AND IdCurso=10562