--ACTUALIZAR TELEFONO SMART
UPDATE ActorTelefono SET Descripcion='938149552'
WHERE IdActor=1644048
--(1 row affected)