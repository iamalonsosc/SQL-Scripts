SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1254944 
--AND AC.IdMatricula=787809
--AND AC.IdCurso=9839
order by ac.idregistro,ac.IdAlumnoCurso desc

--DELETE FROM AlumnoCurso WHERE IdAlumno=1254944  AND IdAlumnoCurso=53
--select*from  AlumnoCurso WHERE IdAlumno=1254944  AND IdAlumnoCurso=2
--select*from  AlumnoCurso WHERE IdAlumno=1254944  AND IdAlumnoCurso=7




/*
PRIMER CICLO I
--Herramientas inform�ticas de productividad	13
--Matem�tica 	13
--Comunicaci�n comprensiva	13
--Introducci�n a la carrera	15
--Administraci�n General	14
--Fundamentos de contabilidad	14
--Plan contable general empresarial	14
--Documentaci�n empresarial	16
--Introducci�n a la carrera	13
*/ 
SELECT 'Situacion Academica',CU.CursoNombre,CU.CursoCodigo, ACC.*fROM AlumnoCurriculaCurso ACC-- WITH(NOLOCK)
INNER JOIN Curso CU WITH(NOLOCK) ON ACC.IdCurso=CU.IdCurso
WHERE IdAlumno=1254944 
AND CU.CursoNombre LIKE '%General%'
--AND CU.CursoCodigo IN ('0436') 
--and ACC.IdCurso in (10061)
ORDER BY IdRegistro,IdModulo

SELECT SE.*FROM Seccion SE
INNER JOIN Promocion PRO ON SE.IdPromocion=PRO.IdPromocion
WHERE SE.IdPeriodoAnual=2016 
AND SE.IdCurso=9941 
AND SE.IdCurricula=126 
AND PRO.IdSede=40
AND PRO.PromocionCodigo LIKE '%2016-IIC%' 

--HERRAMIENTAS INFORMATICAS DE PRODUCTIVIDAD

INSERT INTO AlumnoCurso VALUES (1254944,1,22,126,9940,144489,68733,1,420075,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=22,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9940

--MATEM�TICA

INSERT INTO AlumnoCurso VALUES (1254944,1,23,126,9790,144489,68733,1,420077,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=23,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9790

--Comunicaci�n comprensiva
INSERT INTO AlumnoCurso VALUES (1254944,1,24,126,9939,144489,68733,1,420076,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=24,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9939
--INTRODUCCI�N A LA CARRERA

INSERT INTO AlumnoCurso VALUES (1254944,1,25,126,9941,144489,68733,1,407761,null,null,'15.00','15.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='15.00',PromedioFinal='15.00',PromedioCondicion='A',IdAlumnoCurso=25,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9941
--ADMINISTRACI�N GENERAL

INSERT INTO AlumnoCurso VALUES (1254944,1,26,126,9938,144489,68733,1,420074,null,null,'14.00','14.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='14.00',PromedioFinal='14.00',PromedioCondicion='A',IdAlumnoCurso=26,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9938
--FUNDAMENTOS DE CONTABILIDAD

INSERT INTO AlumnoCurso VALUES (1254944,1,27,126,9818,144489,68733,1,420073,null,null,'14.00','14.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='14.00',PromedioFinal='14.00',PromedioCondicion='A',IdAlumnoCurso=27,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9818
--PLAN CONTABLE GENERAL EMPRESARIAL

INSERT INTO AlumnoCurso VALUES (1254944,1,28,126,10040,144489,68733,1,420072,null,null,'14.00','14.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='14.00',PromedioFinal='14.00',PromedioCondicion='A',IdAlumnoCurso=28,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10040
--DOCUMENTACI�N EMPRESARIAL

INSERT INTO AlumnoCurso VALUES (1254944,1,29,126,9917,144489,68733,1,420071,null,null,'16.00','16.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='16.00',PromedioFinal='16.00',PromedioCondicion='A',IdAlumnoCurso=29,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9917
--INTRODUCCI�N A LA CARRERA

--INSERT INTO AlumnoCurso VALUES (1254944,1,30,126,9941,144489,68733,1,407761,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

--UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=30,Observacion='Actualizado por falta de nota'
--WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9941



/*
SEGUNDO CICLO II

Comunicaci�n escrita	13
L�gica y Funciones	13
Inform�tica aplicada a los negocios	13
Comunicaci�n efectiva 	13
Comunicaci�n efectiva 	14
Contabilidad I	13
Legislaci�n Laboral	14
Proyecto de Procesos Contables	15
*/ 

SELECT 'Situacion Academica',CU.CursoNombre,CU.CursoCodigo, ACC.*fROM AlumnoCurriculaCurso ACC WITH(NOLOCK)
INNER JOIN Curso CU WITH(NOLOCK) ON ACC.IdCurso=CU.IdCurso
WHERE IdAlumno=1254944 
AND CU.CursoNombre LIKE '%Proyecto de Procesos Contables%'
--AND CU.CursoCodigo IN ('0436') 
--and ACC.IdCurso in (10061)
ORDER BY IdRegistro,IdModulo

SELECT SE.*FROM Seccion SE WITH(NOLOCK)
INNER JOIN Promocion PRO  WITH(NOLOCK)  ON SE.IdPromocion=PRO.IdPromocion
WHERE SE.IdPeriodoAnual=2016 
AND SE.IdCurso=10042 
AND SE.IdCurricula=126 
AND PRO.IdSede=40
AND PRO.PromocionCodigo LIKE '%2016-IIC%' 

--COMUNICACI�N ESCRITA

INSERT INTO AlumnoCurso VALUES (1254944,1,30,126,9944,144489,66339,1,66339,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=30,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9944


--L�GICA Y FUNCIONES

INSERT INTO AlumnoCurso VALUES (1254944,1,31,126,9945,144489,66339,1,377590,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=31,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9945

--INFORM�TICA APLICADA A LOS NEGOCIOS

INSERT INTO AlumnoCurso VALUES (1254944,1,32,126,9856,144489,66339,1,377594,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=32,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9856

--COMUNICACI�N EFECTIVA

INSERT INTO AlumnoCurso VALUES (1254944,1,33,126,9943,144489,66339,1,377595,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=33,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9943

--CONTABILIDAD I

INSERT INTO AlumnoCurso VALUES (1254944,1,34,126,10041,144489,66339,1,377596,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=34,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10041

--PROYECTO DE PROCESOS CONTABLES

INSERT INTO AlumnoCurso VALUES (1254944,1,35,126,10042,144489,66339,1,377589,null,null,'14.00','14.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='14.00',PromedioFinal='14.00',PromedioCondicion='A',IdAlumnoCurso=35,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10042

/*
TERCER CICLO III

Estad�stica para los Negocios	13
Ingl�s para la Comunicaci�n	15
Liderazgo y Trabajo en Equipo	13
Contabilidad de Empresas Financieras	13
Legislaci�n Tributaria I	13
Contabilidad Gubernamental I 	13
Contabilidad II	13
*/ 

SELECT 'Situacion Academica',CU.CursoNombre,CU.CursoCodigo, ACC.*fROM AlumnoCurriculaCurso ACC WITH(NOLOCK)
INNER JOIN Curso CU WITH(NOLOCK) ON ACC.IdCurso=CU.IdCurso
WHERE IdAlumno=1254944 
AND CU.CursoNombre LIKE '%Contabilidad II%'
--AND CU.CursoCodigo IN ('0436') 
--and ACC.IdCurso in (10061)
ORDER BY IdRegistro,IdModulo

SELECT SE.*FROM Seccion SE WITH(NOLOCK)
INNER JOIN Promocion PRO  WITH(NOLOCK)  ON SE.IdPromocion=PRO.IdPromocion
WHERE SE.IdPeriodoAnual=2016 
AND SE.IdCurso=10045 
AND SE.IdCurricula=126 
AND PRO.IdSede=40
AND PRO.PromocionCodigo LIKE '%2016-IIC%' 

--ESTAD�STICA PARA LOS NEGOCIOS

INSERT INTO AlumnoCurso VALUES (1254944,1,36,126,9864,144489,67845,1,397068,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=36,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9864

--INGL�S PARA LA COMUNICACI�N

INSERT INTO AlumnoCurso VALUES (1254944,1,37,126,9857,144489,67845,1,397067,null,null,'15.00','15.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='15.00',PromedioFinal='15.00',PromedioCondicion='A',IdAlumnoCurso=37,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9857

--LIDERAZGO Y TRABAJO EN EQUIPO

INSERT INTO AlumnoCurso VALUES (1254944,1,42,126,9787,144489,67845,1,397065,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=42,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9787


--CONTABILIDAD DE EMPRESAS FINANCIERAS

INSERT INTO AlumnoCurso VALUES (1254944,1,38,126,10043,144489,67845,1,397069,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=38,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10043

--LEGISLACI�N TRIBUTARIA I

INSERT INTO AlumnoCurso VALUES (1254944,1,39,126,10046,144489,67845,1,397066,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=39,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10046

--CONTABILIDAD GUBERNAMENTAL I

INSERT INTO AlumnoCurso VALUES (1254944,1,40,126,10044,144489,67845,1,397064,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=40,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10044

--CONTABILIDAD II

INSERT INTO AlumnoCurso VALUES (1254944,1,41,126,10045,144489,67845,1,397063,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=41,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10045


/*
CUARTO CICLO IV

Ingl�s para el Trabajo	13
Proyecto de contabilidad p�blica y privada	13
Contabilidad Gubernamental II	15
Contabilidad de Sociedades I	13
Formulaci�n de Estados Financieros	19
*/ 

SELECT 'Situacion Academica',CU.CursoNombre,CU.CursoCodigo, ACC.*fROM AlumnoCurriculaCurso ACC WITH(NOLOCK)
INNER JOIN Curso CU WITH(NOLOCK) ON ACC.IdCurso=CU.IdCurso
WHERE IdAlumno=1254944 
AND CU.CursoNombre LIKE '%Formulaci�n de Estados Financieros%'
--AND CU.CursoCodigo IN ('0436') 
--and ACC.IdCurso in (10061)
ORDER BY IdRegistro,IdModulo

SELECT SE.*FROM Seccion SE WITH(NOLOCK)
INNER JOIN Promocion PRO  WITH(NOLOCK)  ON SE.IdPromocion=PRO.IdPromocion
WHERE SE.IdPeriodoAnual=2016 
AND SE.IdCurso=10047 
AND SE.IdCurricula=126 
AND PRO.IdSede=40
AND PRO.PromocionCodigo LIKE '%2016-IIC%' 

--INGL�S PARA EL TRABAJO

INSERT INTO AlumnoCurso VALUES (1254944,1,43,126,9795,144489,67346,1,390370,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=43,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=9795

--PROYECTO DE CONTABILIDAD PUBLICA Y PRIVADA

INSERT INTO AlumnoCurso VALUES (1254944,1,44,126,10051,144489,67346,1,390374,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=44,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10051

--CONTABILIDAD GUBERNAMENTAL II

INSERT INTO AlumnoCurso VALUES (1254944,1,45,126,10049,144489,67346,1,390372,null,null,'15.00','15.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='15.00',PromedioFinal='15.00',PromedioCondicion='A',IdAlumnoCurso=45,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10049

--CONTABILIDAD DE SOCIEDADES I

INSERT INTO AlumnoCurso VALUES (1254944,1,46,126,10048,144489,67346,1,390375,null,null,'13.00','13.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='13.00',PromedioFinal='13.00',PromedioCondicion='A',IdAlumnoCurso=46,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10048

--FORMULACI�N DE ESTADOS FINANCIEROS

INSERT INTO AlumnoCurso VALUES (1254944,1,47,126,10047,144489,67346,1,390373,null,null,'19.00','19.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET PromedioReal='19.00',PromedioFinal='19.00',PromedioCondicion='A',IdAlumnoCurso=47,Observacion='Actualizado por falta de nota'
WHERE IdAlumno=1254944 AND IdCurricula=126 AND IdCurso=10047


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


--SELECT*FROM Matricula 

UPDATE Matricula SET Estado='X'
WHERE IdMatricula IN (577423
,648024
,703396)-- VOLVER HA ESTADO R


UPDATE Registro SET Estado='X'
WHERE IdActor=1254944 AND IdRegistro=2



SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1254944 
AND AC.IdMatricula=577423
AND AC.IdCurso=10072
order by ac.idregistro,ac.IdAlumnoCurso desc



--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=48
WHERE IdMatricula=788385 AND IdCurso=10064
--(1 fila afectada)

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=49
WHERE IdMatricula=788385 AND IdCurso=10061
--(1 fila afectada)

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=50
WHERE IdMatricula=788385 AND IdCurso=10046
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=51
WHERE IdMatricula=788385 AND IdCurso=9870
--(1 fila afectada)



--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=3,IdAlumnoCurso=1,IdcurriculaOriginal=NULL,IdCursoOriginal=null--10056
WHERE IdMatricula=577423 AND IdCurso=10072
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=3,IdAlumnoCurso=2,IdcurriculaOriginal=NULL
WHERE IdMatricula=577423 AND IdCurso=9839
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=3,IdAlumnoCurso=3,IdcurriculaOriginal=NULL
WHERE IdMatricula=577423 AND IdCurso=9921
--(1 fila afectada)




--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='D',PromedioFinal='0.00',PromedioReal='0.00',IdAlumnoCurso=1,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=NULL,TipoCondicion='RE'--,Subsanacion=NULL
WHERE IdAlumno=1254944 AND IdRegistro=3 AND IdCurso=10072 AND IdCurricula=5608

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='D',PromedioFinal='10.00',PromedioReal='10.40',IdAlumnoCurso=2,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=NULL,TipoCondicion='RE'--,Subsanacion=NULL
WHERE IdAlumno=1254944 AND IdRegistro=3 AND IdCurso=9839 AND IdCurricula=5608

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='16.00',PromedioReal='15.76',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=NULL,TipoCondicion='RE'--,Subsanacion=NULL
WHERE IdAlumno=1254944 AND IdRegistro=3 AND IdCurso=9921 AND IdCurricula=5608
--CONVALIDADOS
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='13',PromedioReal='13',Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51437,TipoCondicion='CO'--,Subsanacion=NULL
WHERE IdAlumno=1254944 AND IdRegistro=3 AND IdCurso=9870 AND IdCurricula=5608

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='13',PromedioReal='13',Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51437,TipoCondicion='CO'--,Subsanacion=NULL
WHERE IdAlumno=1254944 AND IdRegistro=3 AND IdCurso=10061 AND IdCurricula=5608


--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=3,IdCurricula=5608
WHERE IdMatricula=577423

UPDATE Matricula SET Estado='N'
WHERE IdMatricula IN (648024)

UPDATE Matricula SET Estado='R'
WHERE IdMatricula IN (703396)

UPDATE Registro SET Estado='N'
WHERE IdActor=1254944 AND IdRegistro=2


-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO
UPDATE Matricula SET Estado='X'
WHERE IdMatricula=788385


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Ahora vamos al periodo 2024-III


UPDATE Matricula SET Estado='X'
WHERE IdMatricula IN (648024)

UPDATE Matricula SET Estado='X'--REGRESAR A R
WHERE IdMatricula IN (703396)

UPDATE Registro SET Estado='X'
WHERE IdActor=1254944 AND IdRegistro=2



SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1254944 
AND AC.IdMatricula=648024
--AND AC.IdCurso=9839
order by ac.idregistro,ac.IdAlumnoCurso desc



--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=52
WHERE IdMatricula=788386 AND IdCurso=10072
--(1 fila afectada)

--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=53
WHERE IdMatricula=788386 AND IdCurso=9839
--(1 fila afectada)


UPDATE AlumnoCurso SET IdRegistro=3,IdAlumnoCurso=7,IdcurriculaOriginal=NULL,IdCursoOriginal=null--10056
WHERE IdMatricula=648024 AND IdCurso=10072
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=3,IdAlumnoCurso=8,IdcurriculaOriginal=5608,IdCursoOriginal=null
WHERE IdMatricula=648024 AND IdCurso=9839


--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='18.00',PromedioReal='18.36',IdAlumnoCurso=7,Observacion='CONVALIDACION MALLA INTERNA'--,IdConvalidacion=NULL,TipoCondicion='RE'--,Subsanacion=NULL
WHERE IdAlumno=1254944 AND IdRegistro=3 AND IdCurso=10072 AND IdCurricula=5608

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='16.00',PromedioReal='15.72',IdAlumnoCurso=8,Observacion='CONVALIDACION MALLA INTERNA'--,IdConvalidacion=NULL,TipoCondicion='RE'--,Subsanacion=NULL
WHERE IdAlumno=1254944 AND IdRegistro=3 AND IdCurso=9839 AND IdCurricula=5608

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='16',PromedioReal='16',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51437,TipoCondicion='CO'--,Subsanacion=NULL
WHERE IdAlumno=1254944 AND IdRegistro=3 AND IdCurso=9921 AND IdCurricula=5608

UPDATE Matricula SET IdGrupo=1,Estado='N',IdRegistro=3,IdCurricula=5608,IdPromocion=96617
WHERE IdMatricula=648024

UPDATE Matricula SET Estado='R'
WHERE IdMatricula IN (703396)

UPDATE Registro SET Estado='N'
WHERE IdActor=1254944 AND IdRegistro=2


select*from AlumnoCursoNomina 

--delete from AlumnoCursoNomina
where IdMatricula=
648024 and IdCurso=9839 and IdModulo=5


-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO
UPDATE Matricula SET Estado='X'
WHERE IdMatricula=788386