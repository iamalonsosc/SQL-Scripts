UPDATE CO_DOCUMENTO SET ClienteNumero=1528501
,ClienteRUC='62673883'
,ClienteCobrarA=1528501
WHERE Interfase_Matricula=652193
--(4 rows affected)