--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=735729


--SELECT TipoCondicion,*FROM AlumnoCurso 
----UPDATE AlumnoCurso SET TipoCondicion='RE'
--where IdMatricula=735729 AND EsMatricula=1 


----RP(PROMOVIDO + CURSO)
------CC(CURSO REPITENCIA)
------RT(REPITENCIA)
------RE(PROMOVIDO)
--SELECT*FROM AlumnoCursoNomina WHERE IdMatricula=713661