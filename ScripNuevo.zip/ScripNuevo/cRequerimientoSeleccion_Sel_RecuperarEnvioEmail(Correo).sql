--����������������������������������������������������������������������������                  
--Creado por      : Hugo Mora(6/02/2019)                  
--Funcionalidad   : Permite recuperar un registro de la tabla requerimientoseleccion                  
--Utilizado por   : RequerimientoSeleccion.SelRecuperarLis                  
--����������������������������������������������������������������������������  
/*       
-----------------------------------------------------------------------------              
Nro		FECHA			USUARIO		DESCRIPCION              
-----------------------------------------------------------------------------              
@1		2019.05.02		Hmora		Se Agrega opciones de envio de correo  
@2		2019.05.08		Hmora		Se Agrega opciones de envio de correo Aprobadores en Estado Relevo  
@3		2019.12.16		JLEO		Se adiciona columna Presupuestado
@4		2021.07.06		JBERNUY		Sincronizar SP
@5		2021.11.20		Hmora		Se adiciona columna NumeroSolicitud
@6		2022.08.25		JQuenta		Cambio de flujo del Organigrama GTH Spring a Organigrama Planilla
@7		2023.01.30		JQuenta		Se agrego parametro en el WHERE para Envio de Correo al Interesado flujo Organigrama Planilla
@8		2023.09.06		JQuenta		Se Quita la "APROBACION GERENCIA GENERAL" en el Proceso de Aprobacion en el Flujo de Seleccion Zoom por Solicitud de GDH para Todas las Marcas
									Se Quitan Espacios en Blanco de los Campos en el Resultado y se Mejora el Valor del Nombre del Aprobador e Interesado para los Envios de Correos
									Se Modifica la "APROBACION GDH" en el Proceso de Aprobacion en el Flujo de Seleccion Zoom por Solicitud de GDH para Todas las Marcas
@9		2023.12.05		JQuenta		Se agrega Parametro de Entrada @IdUsuarioAprobador para Obtener los Datos de Aprobador cuando se Rechaza la Solicitud desde el Correo enviado al Aprobador
@10		2024.03.15		Mquiroz		Se agrega validacion para ITS		
@11		2024.04.30		JQuenta		Se agrega comentario con los Nuevos Puestos para el Proceso de Seleccion
@12		15/08/2024		JQuenta		Se agrega columna Marca para visualizacion en los correos para los aprobadores
*/    
                
ALTER PROCEDURE [dbo].[cRequerimientoSeleccion_Sel_RecuperarEnvioEmail]                 
--declare                 
@IdRequerimientoSeleccion INT,  
@Opcion CHAR(2),  --@1  
@IdUsuarioAprobador INT --@9
AS                  
BEGIN   

	DECLARE
		@TempAprobadores TABLE (IdUsuarioAprobador INT)  

	DECLARE
		@TempPuestoAprobadores TABLE (IdPuestoAprobador INT) --@6

	DECLARE
		@Disponible1 VARCHAR(100)                
		,@Estado INT                
		,@NombreEstado VARCHAR(100)               
		,@UsuarioSolicitante INT                
		,@NombreSolicitante VARCHAR(200)                
		,@NombreAprobador VARCHAR(200)                 
		,@CorreoAprobador VARCHAR(200)              
		,@IdCorreo INT                
		,@IdAprobador INT                
		,@IdSolicitante INT                
		,@IdGerencia INT    
		,@IdArea INT --@6
		,@IdPuesto INT --@6
		,@Organigrama_RequerimientoSeleccion VARCHAR(20) --@6
		,@Codigo VARCHAR(100)    
		,@IdSede INT  
		,@IdPresupuestado INT           
		,@CodigoGerencia VARCHAR(40) --@6
		,@CodigoCargo INT --@6    
		,@CompanyOwner VARCHAR(8) --@6
		,@Disponible4 VARCHAR(100) --@6
		,@Disponible5 VARCHAR(100) --@6
		,@IdPuestoSolicitante INT
		,@PuestoJefe INT

	--Obtenemos el Estado Inicial                
	SELECT DISTINCT
		@Estado = IdEstado
		,@IdGerencia = IdGerencia
		,@IdArea = IdArea
		,@IdPuesto = IdPuesto
		,@IdSolicitante = UsuarioCreacion
		,@IdSede = IdSede
		,@IdPresupuestado = IdPresupuestado
	FROM RequerimientoSeleccion WITH (NOLOCK)
	WHERE IdRequerimientoSeleccion = @IdRequerimientoSeleccion                
                   
	SELECT DISTINCT
		@Disponible1 = Disponible1
		,@Disponible4 = Disponible4
		,@Disponible5 = Disponible5
		,@NombreEstado = Nombre
		,@IdCorreo = Disponible3
		,@Codigo = Codigo
	FROM MaestroTablaRegistro WITH (NOLOCK)
	WHERE IdMaestroRegistro = @Estado                
              
	SELECT @NombreSolicitante = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno
	FROM Usuario U WITH (NOLOCK)
	WHERE U.IdUsuario = @IdSolicitante        

	--Inicio @6
	IF EXISTS (
		SELECT DISTINCT
			IdGerenciaSeleccion
		FROM GerenciaSeleccion GS WITH (NOLOCK)
		WHERE GS.IdGerenciaSeleccion = @IdGerencia
	)
	BEGIN
		
		SET @Organigrama_RequerimientoSeleccion = 'Planilla'

		SELECT DISTINCT 
			@CompanyOwner = PAS.CompanyOwner
		FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
		LEFT JOIN Empresa E WITH (NOLOCK) ON PAS.CompanyOwner = E.CompaniaSocio
		WHERE PAS.IdPuesto = @IdPuesto

		--Obtenemos los Puestos Correspondiente al Estado
		IF @Codigo = 'APGDH'
		BEGIN    

			INSERT INTO @TempPuestoAprobadores(IdPuestoAprobador)      
			SELECT DISTINCT
				DATA
			FROM dbo.Split( (SELECT DISTINCT DATA FROM dbo.Split( @Disponible5 , '-') WHERE DATA NOT LIKE '%*%') ,'|' ) 

		END
		ELSE
		BEGIN        
		
			INSERT INTO @TempPuestoAprobadores(IdPuestoAprobador)                    
			SELECT DISTINCT
				DATA
			FROM dbo.Split(@Disponible5 ,'|')  

		END

	END
	ELSE
	BEGIN

		SET @Organigrama_RequerimientoSeleccion = 'Spring'

		SELECT 
			@CompanyOwner = E.CompaniaSocio
		FROM EmpresaSedeParametro ESP WITH (NOLOCK)
		INNER JOIN Empresa E WITH (NOLOCK) ON ESP.IdEmpresa = E.IdEmpresa
		WHERE Nombre = 'NUMEROREQSELECCION' 

		--Obtenemos los Aprobadores Correspondiente al Estado               
		INSERT INTO @TempAprobadores(IdUsuarioAprobador)                    
		SELECT DISTINCT DATA FROM dbo.Split( @Disponible1, '|' )   

	END
	--Fin @6
                
	--APROBACION JEFE AREA  
	IF @Codigo = 'APJAR'  
	BEGIN    
	
		--Inicio @6
		IF @Organigrama_RequerimientoSeleccion = 'Planilla'
		BEGIN

			SELECT DISTINCT
				@IdPuestoSolicitante = PSL.IdPuesto
			FROM EmpleadoMast EM WITH (NOLOCK)
			LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
			LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
			LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
			LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor
			LEFT JOIN PuestoAreaSeleccion PSL WITH (NOLOCK) ON CAST(EM.CodigoCargo AS VARCHAR) = PSL.Codigo
			LEFT JOIN AreaSeleccion ASL WITH (NOLOCK) ON PSL.IdArea = ASL.IdAreaSeleccion  
			LEFT JOIN GerenciaSeleccion GS WITH (NOLOCK) ON ASL.IdGerencia = GS.IdGerenciaSeleccion
			LEFT JOIN PuestoSedeAprobadorSeleccion PSAS WITH (NOLOCK) ON PSL.IdPuesto = PSAS.IdPuestoJefe
			LEFT JOIN PuestoAreaSeleccion PSL2 WITH (NOLOCK) ON PSAS.IdPuesto = PSL2.IdPuesto
			LEFT JOIN AreaSeleccion ASL2 WITH (NOLOCK) ON PSL2.IdArea = ASL2.IdAreaSeleccion  
			LEFT JOIN GerenciaSeleccion GS2 WITH (NOLOCK) ON ASL2.IdGerencia = GS2.IdGerenciaSeleccion
			LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.Empleado = EMPJ.JefeResponsable AND PSL2.Codigo = CAST(EMPJ.CodigoCargo AS VARCHAR)
			WHERE ASL.Activo = 1
			AND U.IdUsuario = @IdSolicitante
			AND
			(
				(
					GS.CompanyOwner = EM.CompaniaSocio
					AND GS2.CompanyOwner = EM.CompaniaSocio
					AND PSAS.CompanyOwner = EM.CompaniaSocio
				)
				OR
				(
					GS2.CompanyOwner <> EM.CompaniaSocio
					AND GS2.CompanyOwner = PSAS.CompanyOwner
				)
			)
			AND PSAS.IdPuesto = @IdPuesto
			AND PSL2.IdPuesto = @IdPuesto
			AND ASL2.IdAreaSeleccion = @IdArea
			AND GS2.IdGerenciaSeleccion = @IdGerencia
			AND EM.FlagEsLider = 'S'
			AND EMPJ.Estado = 'A'

			IF EXISTS (
				SELECT DISTINCT
					PSAS.IdPuestoJefe 
				FROM PuestoSedeAprobadorSeleccion PSAS WITH (NOLOCK)
				INNER JOIN PuestoAreaSeleccion PAS WITH (NOLOCK) ON PSAS.IdPuestoJefe = PAS.IdPuesto
				WHERE PSAS.IdPuesto = @IdPuestoSolicitante
				AND PSAS.IdSede = @IdSede
				AND PSAS.CompanyOwner = @CompanyOwner
				AND PSAS.Activo = 1
				AND PAS.IdArea IN (
					SELECT DISTINCT 
						IdAreaSeleccion
					FROM AreaSeleccion ASE WITH (NOLOCK)
					WHERE ASE.IdGerencia IN (
						SELECT DISTINCT
							IdGerenciaSeleccion
						FROM GerenciaSeleccion GS WITH (NOLOCK)
						WHERE GS.Codigo <> '0000'
					)
					AND ASE.Codigo <> '0000'
				)
			)  
			BEGIN      

				SELECT DISTINCT
					@PuestoJefe = IdPuestoJefe 
				FROM PuestoSedeAprobadorSeleccion PSAS WITH (NOLOCK)
				INNER JOIN PuestoAreaSeleccion PAS WITH (NOLOCK) ON PSAS.IdPuestoJefe = PAS.IdPuesto
				WHERE PSAS.IdPuesto = @IdPuestoSolicitante
				AND PSAS.IdSede = @IdSede
				AND PSAS.CompanyOwner = @CompanyOwner
				AND PSAS.Activo = 1
				AND PAS.IdArea IN (SELECT DISTINCT
						IdAreaSeleccion
					FROM AreaSeleccion ASE WITH (NOLOCK)
					WHERE ASE.IdGerencia IN (SELECT DISTINCT
							IdGerenciaSeleccion
						FROM GerenciaSeleccion GS WITH (NOLOCK)
						WHERE GS.Codigo <> '0000')
					AND ASE.Codigo <> '0000')

				SELECT DISTINCT
					@CodigoCargo = Codigo
				FROM PuestoAreaSeleccion WITH (NOLOCK)
				WHERE IdPuesto = @PuestoJefe

				IF EXISTS (SELECT DISTINCT
						U.IdUsuario   
					FROM EmpleadoMast EM WITH (NOLOCK)
					LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
					LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
					LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
					LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
					LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
					WHERE EM.CodigoCargo = @CodigoCargo
					AND EM.FlagEsLider = 'S'
					AND EM.Estado = 'A'
					AND U.IdUsuario IS NOT NULL
				)
				BEGIN

					SELECT DISTINCT  
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario   
					FROM EmpleadoMast EM WITH (NOLOCK)
					LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
					LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
					LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
					LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
					LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
					WHERE EM.CodigoCargo = @CodigoCargo
					AND EM.FlagEsLider = 'S'
					AND EM.Estado = 'A'
					AND U.IdUsuario IS NOT NULL

				END
				ELSE
				BEGIN

					SELECT DISTINCT  
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail               
						,@IdAprobador = U.IdUsuario   
					FROM EmpleadoMast EM WITH (NOLOCK)
					LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
					LEFT JOIN PersonaMast PM WITH(NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
					LEFT JOIN Actor A WITH(NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
					LEFT JOIN Usuario U WITH(NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
					LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
					WHERE EM.CodigoCargo = @CodigoCargo
					AND EM.FlagEsLider = 'S'
					AND EM.Estado = 'A' 

				END
			END    
			ELSE    
			BEGIN    
				--En el Caso de Central
				IF (
					(@IdSede = 24 AND @CompanyOwner = '00002500')
						OR (@IdSede = 39 AND @CompanyOwner = '00002700')
							OR (@IdSede = 44 AND @CompanyOwner = '00002600')
				)
				BEGIN    
				
					SELECT DISTINCT 
						@CodigoGerencia = Codigo
					FROM GerenciaSeleccion WITH (NOLOCK)
					WHERE IdGerenciaSeleccion = @IdGerencia

					SELECT DISTINCT 
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario  
					FROM EmpleadoMast EM WITH (NOLOCK)
					INNER JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
					INNER JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
					INNER JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
					INNER JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login) AND EM.CodigoUsuario = U.Login
					INNER JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
					WHERE EM.CodigoCargo IN (
						SELECT DISTINCT
							PAS.Codigo
						FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
						WHERE PAS.IdPuesto IN (
							--Academico
								--Puesto: 473 (JEFE CENTRAL DE VENTAS)
								--Puesto: 478 (JEFE NACIONAL DE DESARROLLO ESTUDIANTIL)
								--Puesto: 477 (JEFE DE TESORER�A Y COBRANZAS)
								--Puesto: 663 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								--Puesto: 464 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
								--Puesto: 465 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
								--Puesto: 480 (SUB GERENTE DE DESARROLLO DE SOFTWARE)
							--AcademicoIDAT
								--Puesto: 381 (JEFE CENTRAL DE VENTAS)
								--Puesto: 386 (JEFE NACIONAL DE DESARROLLO ESTUDIANTIL)
								--Puesto: 385 (JEFE DE TESORER�A Y COBRANZAS)
								--Puesto: 571 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								--Puesto: 372 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
								--Puesto: 373 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
								--Puesto: 388 (SUB GERENTE DE DESARROLLO DE SOFTWARE)
							--AcademicoCA
								--Puesto: 94 (JEFE CENTRAL DE VENTAS)
								--Puesto: 99 (JEFE NACIONAL DE DESARROLLO ESTUDIANTIL)
								--Puesto: 98 (JEFE DE TESORER�A Y COBRANZAS)
								--Puesto: 284 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								--Puesto: 85 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
								--Puesto: 86 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
								--Puesto: 101 (SUB GERENTE DE DESARROLLO DE SOFTWARE)
							SELECT DISTINCT
								IdPuestoAprobador
							FROM @TempPuestoAprobadores
						)
						AND PAS.CompanyOwner = @CompanyOwner
						AND PAS.CodigoPuesto IS NULL
					)
					AND EM.CodGerencia = @CodigoGerencia
					AND EM.FlagEsLider = 'S'
					AND EM.Estado = 'A'
					AND U.IdSede = @IdSede

				END    
				--En el Caso de Sedes 
				ELSE        
				BEGIN   

					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario   
					FROM EmpleadoMast EM WITH (NOLOCK)
					LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
					LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
					LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
					LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
					LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
					WHERE EM.CodigoCargo IN (
						SELECT DISTINCT
							PAS.Codigo
						FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
						WHERE PAS.IdPuesto IN (
							--Academico
								--Puesto: 464 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
								--Puesto: 465 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
							SELECT DISTINCT
								IdPuestoAprobador
							FROM @TempPuestoAprobadores
							WHERE IdPuestoAprobador IN (464,465)
							AND (@CompanyOwner = '00002500' or @CompanyOwner = '00002400')--@10
							UNION
							--AcademicoIDAT
								--Puesto: 372 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
								--Puesto: 373 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
							SELECT DISTINCT
								IdPuestoAprobador
							FROM @TempPuestoAprobadores
							WHERE IdPuestoAprobador IN (372,373)
							AND @CompanyOwner = '00002700'
							UNION
							--AcademicoCA
								--Puesto: 85 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
								--Puesto: 86 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
							SELECT DISTINCT
								IdPuestoAprobador
							FROM @TempPuestoAprobadores
							WHERE IdPuestoAprobador IN (85,86)
							AND @CompanyOwner = '00002600'
						)
						AND PAS.CompanyOwner = @CompanyOwner
						AND PAS.CodigoPuesto IS NULL
					)
					AND EM.FlagEsLider = 'S'
					AND EM.Estado = 'A'
					AND EM.CompaniaSocio = @CompanyOwner

				END    
			END

		END
		ELSE
		BEGIN
		--Fin @6

			SELECT DISTINCT
				@IdPuestoSolicitante = U.IdPuesto
			FROM Usuario U WITH (NOLOCK)
			WHERE U.IdUsuario = @IdSolicitante
			AND U.IdSede = @IdSede 

			IF EXISTS (
				SELECT DISTINCT
					IdPuestoJefe
				FROM PuestoSedeAprobador WITH (NOLOCK) 
				WHERE IdPuesto = @IdPuestoSolicitante
			)  
			BEGIN     

				SELECT DISTINCT
					@PuestoJefe = IdPuestoJefe
				FROM PuestoSedeAprobador WITH (NOLOCK) 
				WHERE IdPuesto = @IdPuestoSolicitante
				AND IdSede = @IdSede    

				SELECT DISTINCT 
					@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8             
					,@CorreoAprobador = U.EMail                
					,@IdAprobador = U.IdUsuario    
				FROM Usuario U WITH (NOLOCK) 
				WHERE IdPuesto = @PuestoJefe
				AND IdSede = @IdSede
				
			END    
			ELSE    
			BEGIN    

				--En el Caso de Central
				IF (
					(@IdSede = 24 AND @CompanyOwner = '00002500')
						OR (@IdSede = 39 AND @CompanyOwner = '00002700')
							OR (@IdSede = 44 AND @CompanyOwner = '00002600')
				)      
				BEGIN      
				
					SELECT DISTINCT
						@IdAprobador = Disponible1
					FROM MaestroTablaRegistro WITH (NOLOCK)
					WHERE IdMaestroTabla = 2023 
					AND IdMaestroRegistro = @IdGerencia  
					
					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario                
					FROM Usuario U WITH (NOLOCK) 
					WHERE U.IdUsuario = @IdAprobador 
					
				END    
				-- En el Caso de Sedes
				ELSE         
				BEGIN    

					SELECT DISTINCT
						@IdAprobador = Disponible1
					FROM MaestroTablaRegistro WITH (NOLOCK) 
					WHERE IdMaestroTabla = 2023
					AND Codigo = 'OPR'   
					
					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8            
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario                 
					FROM Usuario U WITH (NOLOCK) 
					WHERE U.IdUsuario = @IdAprobador 
					
				END    
			END 
		--Inicio @6
		END  
		--Fin @6
	END    
                
  --Si el estado es el inicial verificamos a que gerencia pertenece y obtenemos los datos del Aprobador 
  --Aprobador Gerencia Central y Sedes
  --APROBACION GERENTE AREA
	IF @Codigo = 'APGAR' 
	BEGIN 

		--Inicio @6
		IF @Organigrama_RequerimientoSeleccion = 'Planilla'
		BEGIN
			
			--GDH
			IF @Opcion = '01'     
			BEGIN   
				IF (
					(@IdSede = 24 AND @CompanyOwner = '00002500') 
						OR (@IdSede = 39 AND @CompanyOwner = '00002700')
							OR (@IdSede = 44 AND @CompanyOwner = '00002600')
				)  
				--En el Caso de Central   
				BEGIN    

					SELECT DISTINCT
						@CodigoGerencia = Codigo
					FROM GerenciaSeleccion WITH (NOLOCK)
					WHERE IdGerenciaSeleccion = @IdGerencia

					--GERENTE DE SISTEMAS
					IF @CodigoGerencia = '0018'
					BEGIN

						SELECT DISTINCT
							@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8        
							,@CorreoAprobador = U.EMail               
							,@IdAprobador = U.IdUsuario   
						FROM EmpleadoMast EM WITH (NOLOCK)
						LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
						LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
						LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
						LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
						LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
						WHERE EM.CodigoCargo IN (
							SELECT DISTINCT
								PAS.Codigo
							FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
							WHERE PAS.IdPuesto IN (
								SELECT DISTINCT
									IdPuestoAprobador
								FROM @TempPuestoAprobadores
								WHERE IdPuestoAprobador IN (
									--Academico
										--Puesto: 578 (GERENTE DE SISTEMAS)
									SELECT DISTINCT
										IdPuestoAprobador
									FROM @TempPuestoAprobadores
									WHERE IdPuestoAprobador IN (578)
									AND (@CompanyOwner = '00002500' or @CompanyOwner = '00002400') --@10
									UNION
									--AcademicoIDAT
										--Puesto: 486 (GERENTE DE SISTEMAS)
									SELECT DISTINCT
										IdPuestoAprobador
									FROM @TempPuestoAprobadores
									WHERE IdPuestoAprobador IN (486)
									AND @CompanyOwner = '00002700'
									UNION
									--AcademicoCA
										--Puesto: 199 (GERENTE DE SISTEMAS)
									SELECT DISTINCT
										IdPuestoAprobador
									FROM @TempPuestoAprobadores
									WHERE IdPuestoAprobador IN (199)
									AND @CompanyOwner = '00002600'
								)
							)
							AND PAS.IdArea IN (
								SELECT DISTINCT
									ASE.IdAreaSeleccion 
								FROM AreaSeleccion ASE WITH(NOLOCK)
								WHERE ASE.IdGerencia IN (
									SELECT DISTINCT
										GS.IdGerenciaSeleccion
									FROM GerenciaSeleccion GS WITH(NOLOCK)
									WHERE GS.Codigo <> '0000'
									AND Codigo = @CodigoGerencia
								)
								AND ASE.Codigo <> '0000'
							)
							AND PAS.CodigoPuesto IS NULL
						)
						AND EM.FlagEsLider = 'S'
						AND EM.Estado = 'A'
					
					END
					--GERENTE CENTRAL DE COMERCIAL Y MARKETING
					--GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL
					--GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS
					--GERENTE DE SEDE >> OPERACIONES - IDAT - CAMPUS
					--GERENTE DE SEDE >> OPERACIONES - ZEGEL - CENTRAL
					--GERENTE GENERAL
					--GERENTE DE GESTI�N Y DESARROLLO HUMANO
					--GERENTE DE RELACION CON EL MEDIO Y EMPLEABILIDAD
					--GERENTE DE COMUNICACIONES E IMAGEN INSTITUCI
					ELSE
					BEGIN

						SELECT DISTINCT
							@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
							,@CorreoAprobador = U.EMail               
							,@IdAprobador = U.IdUsuario   
						FROM EmpleadoMast EM WITH (NOLOCK)
						LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
						LEFT JOIN PersonaMast PM WITH(NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
						LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
						LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login) AND EM.CodigoUsuario = U.LOGIN
						LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
						WHERE EM.CodigoCargo IN (SELECT DISTINCT
								PAS.Codigo
							FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
							WHERE PAS.IdPuesto IN (
								--Academico
									--Puesto: 463 (GERENTE CENTRAL DE COMERCIAL Y MARKETING)
									--Puesto: 464 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
									--Puesto: 465 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
									--Puesto: 466 (GERENTE DE SEDE >> OPERACIONES - IDAT - CAMPUS)
									--Puesto: 467 (GERENTE DE SEDE >> OPERACIONES - ZEGEL - CENTRAL)
									--Puesto: 468 (GERENTE GENERAL)
									--Puesto: 592 (GERENTE DE GESTI�N Y DESARROLLO HUMANO)
									--Puesto: 610 (GERENTE DE RELACION CON EL MEDIO Y EMPLEABILIDAD)
									--Puesto: 699 (GERENTE DE COMUNICACIONES E IMAGEN INSTITUCI)
								--AcademicoIDAT
									--Puesto: 371 (GERENTE CENTRAL DE COMERCIAL Y MARKETING)
									--Puesto: 372 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
									--Puesto: 373 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
									--Puesto: 374 (GERENTE DE SEDE >> OPERACIONES - IDAT - CAMPUS)
									--Puesto: 375 (GERENTE DE SEDE >> OPERACIONES - ZEGEL - CENTRAL)
									--Puesto: 376 (GERENTE GENERAL)
									--Puesto: 500 (GERENTE DE GESTI�N Y DESARROLLO HUMANO)
									--Puesto: 518 (GERENTE DE RELACION CON EL MEDIO Y EMPLEABILIDAD)
									--Puesto: 607 (GERENTE DE COMUNICACIONES E IMAGEN INSTITUCI)
								--AcademicoCA
									--Puesto: 84 (GERENTE CENTRAL DE COMERCIAL Y MARKETING)
									--Puesto: 85 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
									--Puesto: 86 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
									--Puesto: 87 (GERENTE DE SEDE >> OPERACIONES - IDAT - CAMPUS)
									--Puesto: 88 (GERENTE DE SEDE >> OPERACIONES - ZEGEL - CENTRAL)
									--Puesto: 89 (GERENTE GENERAL)
									--Puesto: 213 (GERENTE DE GESTI�N Y DESARROLLO HUMANO)
									--Puesto: 231 (GERENTE DE RELACION CON EL MEDIO Y EMPLEABILIDAD)
									--Puesto: 320 (GERENTE DE COMUNICACIONES E IMAGEN INSTITUCI)
								SELECT DISTINCT
									IdPuestoAprobador
								FROM @TempPuestoAprobadores
							)
							AND PAS.IdArea IN (
								SELECT DISTINCT
									ASE.IdAreaSeleccion 
								FROM AreaSeleccion ASE WITH(NOLOCK)
								WHERE ASE.IdGerencia IN (
									SELECT DISTINCT
										GS.IdGerenciaSeleccion
									FROM GerenciaSeleccion GS WITH(NOLOCK)
									WHERE GS.Codigo <> '0000'
									AND Codigo = @CodigoGerencia
								)
								AND ASE.Codigo <> '0000'
							)
							AND PAS.CodigoPuesto IS NULL
						)
						AND EM.FlagEsLider = 'S'
						AND EM.Estado = 'A'
						AND U.IdUsuario IS NOT NULL

					END

				END    
				--En el Caso de Sedes 
				ELSE        
				BEGIN    

					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail               
						,@IdAprobador = U.IdUsuario   
					FROM EmpleadoMast EM WITH (NOLOCK)
					LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
					LEFT JOIN PersonaMast PM WITH(NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
					LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
					LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
					LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
					WHERE EM.CodigoCargo IN (SELECT DISTINCT
							PAS.Codigo
						FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
						WHERE PAS.IdPuesto IN (
							SELECT DISTINCT
								IdPuestoAprobador
							FROM @TempPuestoAprobadores
							WHERE IdPuestoAprobador IN (
								--Academico
									--Puesto: 464 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
									--Puesto: 465 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
								SELECT DISTINCT
									IdPuestoAprobador
								FROM @TempPuestoAprobadores
								WHERE IdPuestoAprobador IN (464,465)
								AND (@CompanyOwner = '00002500' or @CompanyOwner = '00002400')--@10
								UNION
								--AcademicoIDAT
									--Puesto: 372 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
									--Puesto: 373 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
								SELECT DISTINCT
									IdPuestoAprobador
								FROM @TempPuestoAprobadores
								WHERE IdPuestoAprobador IN (372,373)
								AND @CompanyOwner = '00002700'
								UNION
								--AcademicoCA
									--Puesto: 85 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - IDAT - CENTRAL)
									--Puesto: 86 (GERENTE CENTRAL DE OPERACIONES >> OPERACIONES - ZEGEL - CAMPUS)
								SELECT DISTINCT
									IdPuestoAprobador
								FROM @TempPuestoAprobadores
								WHERE IdPuestoAprobador IN (85,86)
								AND @CompanyOwner = '00002600'
							)
						)
						AND PAS.CompanyOwner = @CompanyOwner
						AND PAS.CodigoPuesto IS NULL
					)
					AND EM.FlagEsLider = 'S'
					AND EM.Estado = 'A'
					AND EM.CompaniaSocio = @CompanyOwner

				END   
			END   

			--Coordinador de Seleccion
			IF @Opcion = '02'    
			BEGIN  

				DELETE FROM @TempPuestoAprobadores

				SELECT DISTINCT
					@Disponible5=Disponible5
				FROM MaestroTablaRegistro WITH (NOLOCK)
				WHERE IdMaestroTabla = 2030
				AND Codigo = 'RLVGDH'

				--Obtenemos los Puestos Correspondiente al Estado                
				INSERT INTO @TempPuestoAprobadores(IdPuestoAprobador)                    
				SELECT DISTINCT DATA FROM dbo.Split(@Disponible5 ,'|')  

				SELECT DISTINCT
					@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
					,@CorreoAprobador = U.EMail                
					,@IdAprobador = U.IdUsuario   
				FROM EmpleadoMast EM WITH (NOLOCK)
				LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
				LEFT JOIN PersonaMast PM WITH(NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
				LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
				LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
				LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
				WHERE EM.CodigoCargo IN (
					SELECT DISTINCT
						PAS.Codigo
					FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
					WHERE PAS.IdPuesto IN (
						--Academico
							--Puesto: 663 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
						--AcademicoIDAT
							--Puesto: 571 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
						--AcademicoCA
							--Puesto: 284 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
						SELECT DISTINCT
							IdPuestoAprobador
						FROM @TempPuestoAprobadores
					)
					AND PAS.CompanyOwner = @CompanyOwner
					AND PAS.CodigoPuesto IS NULL
				)
				AND EM.FlagEsLider = 'S'
				AND EM.Estado = 'A'

				SELECT @IdCorreo = 145  

			END   

			--Solicitante
			IF @Opcion = '03'     
			BEGIN       
			
				SELECT DISTINCT
					@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
					,@CorreoAprobador = U.EMail              
					,@IdAprobador = U.IdUsuario                
				FROM Usuario U WITH (NOLOCK)
				WHERE U.IdUsuario = @IdSolicitante   

				SELECT @IdCorreo = 146  

			END  
		END
		ELSE
		BEGIN
		--Fin @6

			--GDH
			IF @Opcion = '01'     
			BEGIN   
				IF (
					(@IdSede =24 AND @CompanyOwner = '00002500')
						OR (@IdSede =39 AND @CompanyOwner = '00002700')
							OR (@IdSede =44 AND @CompanyOwner = '00002600')
				)   
				--En el Caso de Central
				BEGIN     
				
					SELECT DISTINCT
						@IdAprobador = Disponible1
					FROM MaestroTablaRegistro WITH (NOLOCK)
					WHERE IdMaestroTabla = 2023
					AND IdMaestroRegistro = @IdGerencia    
					
					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = EMail                
						,@IdAprobador = U.IdUsuario                
					FROM Usuario U WITH (NOLOCK)
					WHERE U.IdUsuario = @IdAprobador  
					
				END  
				--En el Caso de Sedes
				ELSE         
				BEGIN   
				
					SELECT DISTINCT
						@IdAprobador = Disponible1
					FROM MaestroTablaRegistro WITH (NOLOCK)
					WHERE IdMaestroTabla = 2023
					AND Codigo = 'OPR'  
					
					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8            
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario                
					FROM Usuario U WITH (NOLOCK)
					WHERE U.IdUsuario = @IdAprobador   
					
				END    
			END   

			--Coordinador de Seleccion   
			IF @Opcion = '02'  
			BEGIN  

				SELECT DISTINCT
					@IdAprobador = Disponible1
				FROM MaestroTablaRegistro WITH (NOLOCK)
				WHERE IdMaestroTabla = 2030 AND Codigo = 'RLVGDH'  
				
				SELECT DISTINCT
					@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8              
					,@CorreoAprobador = U.EMail                
					,@IdAprobador = U.IdUsuario                 
				FROM Usuario U WITH (NOLOCK)
				WHERE U.IdUsuario = @IdAprobador  
				
				SELECT @IdCorreo = 145  

			END   

			--Solicitante 
			IF @Opcion='03'    
			BEGIN      
			
				SELECT DISTINCT
					@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8              
					,@CorreoAprobador = U.EMail                
					,@IdAprobador = U.IdUsuario                
				FROM Usuario U WITH (NOLOCK)
				WHERE U.IdUsuario = @IdSolicitante   

				SELECT @IdCorreo = 146  

			END 
			
		--Inicio @6
		END   
		--Fin @6
	END   
	ELSE 
	BEGIN

		--APROBACION COMPENSACIONES
		IF @Codigo = 'APCMP' 
		BEGIN

			--Inicio @6
			IF @Organigrama_RequerimientoSeleccion = 'Planilla'
			BEGIN

				--GDH
				IF @Opcion = '01'    
				BEGIN 
				
					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario 
					FROM EmpleadoMast EM WITH (NOLOCK)
					LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
					LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
					LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
					LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
					LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
					WHERE EM.CodigoCargo IN (
						SELECT DISTINCT
							PAS.Codigo
						FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
						WHERE PAS.IdPuesto IN (
							--Academico
								--Puesto: 613 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
							--AcademicoIDAT
								--Puesto: 521 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
							--AcademicoCA
								--Puesto: 234 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
							--Inicio --@11
							--Academico
								--Puesto: 1983 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
							--AcademicoIDAT
								--Puesto: 1855 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
							--AcademicoCA
								--Puesto: 1520 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
							--Fin --@11
							SELECT DISTINCT
								IdPuestoAprobador
							FROM @TempPuestoAprobadores
						)
						AND PAS.CompanyOwner = @CompanyOwner
						AND PAS.CodigoPuesto IS NULL
					)
					AND EM.FlagEsLider = 'S'
					AND EM.Estado = 'A' 

				END  

				--Coordinador de Seleccion
				IF @Opcion = '02'     
				BEGIN  

					DELETE FROM @TempPuestoAprobadores

					SELECT DISTINCT
						@Disponible5=Disponible5
					FROM MaestroTablaRegistro WITH (NOLOCK)
					WHERE IdMaestroTabla = 2030
					AND Codigo = 'RLVGDH'

					--Obtenemos los Puestos Correspondiente al Estado                
					INSERT INTO @TempPuestoAprobadores(IdPuestoAprobador)                    
					SELECT DISTINCT DATA FROM dbo.Split(@Disponible5 ,'|')  

					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario   
					FROM EmpleadoMast EM WITH (NOLOCK)
					LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
					LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
					LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
					LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
					LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
					WHERE EM.CodigoCargo IN (
						SELECT DISTINCT
							PAS.Codigo
						FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
						WHERE PAS.IdPuesto IN (
							--Academico
								--Puesto: 663 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
							--AcademicoIDAT
								--Puesto: 571 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
							--AcademicoCA
								--Puesto: 284 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
							SELECT DISTINCT
								IdPuestoAprobador
							FROM @TempPuestoAprobadores
						)
						AND PAS.CompanyOwner = @CompanyOwner
						AND PAS.CodigoPuesto IS NULL
					)
					AND EM.FlagEsLider = 'S'
					AND EM.Estado = 'A'

					SELECT @IdCorreo = 145  

				END   

				--Solicitante
				IF @Opcion = '03'     
				BEGIN             

					SELECT DISTINCT
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8      
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario                
					FROM Usuario U WITH (NOLOCK)
					WHERE U.IdUsuario = @IdSolicitante 
					
					SELECT @IdCorreo=146  

				END 
				
			END
			ELSE
			BEGIN
			--Fin @6

				--GDH
				IF @Opcion = '01'     
				BEGIN   

					SELECT DISTINCT 
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8             
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario                
					FROM Usuario U WITH (NOLOCK)
					WHERE U.IdUsuario IN (
						SELECT DISTINCT
							IdUsuarioAprobador
						FROM @TempAprobadores
					) 
					
				END   

				--Coordinador de Seleccion
				IF @Opcion = '02'     
				BEGIN  

					SELECT DISTINCT  
						@IdAprobador=Disponible1
					FROM MaestroTablaRegistro WITH (NOLOCK)
					WHERE IdMaestroTabla = 2030
					AND Codigo = 'RLVGDH'  
					
					SELECT DISTINCT 
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario                
					FROM Usuario U WITH (NOLOCK)
					WHERE U.IdUsuario = @IdAprobador  
					
					SELECT @IdCorreo = 145
					
				END   

				--Solicitante
				IF @Opcion = '03'     
				BEGIN             

					SELECT DISTINCT 
						@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8            
						,@CorreoAprobador = U.EMail                
						,@IdAprobador = U.IdUsuario                
					FROM Usuario U WITH (NOLOCK)
					WHERE U.IdUsuario = @IdSolicitante   

					SELECT @IdCorreo = 146 
					
				END  

			--Inicio @6
			END
			--Fin @6
		END	             
		ELSE 
		BEGIN

			--RELEVO
			IF @Codigo = 'RLVGDH' --@2  
			BEGIN  

				--Inicio @6
				IF @Organigrama_RequerimientoSeleccion = 'Planilla'
				BEGIN

					--GDH
					IF @Opcion='01'      
					BEGIN  

						SELECT DISTINCT
							@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
							,@CorreoAprobador=U.EMail                
							,@IdAprobador=U.IdUsuario   
						FROM EmpleadoMast EM WITH (NOLOCK)
						LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
						LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
						LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
						LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
						LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
						WHERE EM.CodigoCargo IN (
							SELECT DISTINCT
								PAS.Codigo
							FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
							WHERE PAS.IdPuesto IN (
								--Academico
									--Puesto: 663 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								--AcademicoIDAT
									--Puesto: 571 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								--AcademicoCA
									--Puesto: 284 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								SELECT DISTINCT
									IdPuestoAprobador
								FROM @TempPuestoAprobadores
							)
							AND PAS.CompanyOwner = @CompanyOwner
							AND PAS.CodigoPuesto IS NULL
						)
						AND EM.FlagEsLider = 'S'
						AND EM.Estado = 'A'
						
					END  

					--Interesado
					IF @Opcion = '02'   
					BEGIN  

						SELECT DISTINCT
							@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
							,@CorreoAprobador = U.EMail                
							,@IdAprobador = U.IdUsuario                
						FROM Usuario U WITH (NOLOCK)
						WHERE U.IdUsuario = @IdSolicitante 
						
					END 

				END
				ELSE
				BEGIN
				--Fin @6

					--GDH 
					IF @Opcion = '01'     
					BEGIN  

						SELECT DISTINCT
							@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8      
							,@CorreoAprobador = U.EMail                
							,@IdAprobador = U.IdUsuario                 
						FROM Usuario U WITH (NOLOCK)
						WHERE U.IdUsuario IN (
							SELECT DISTINCT
								Disponible4
							FROM MaestroTablaRegistro WITH (NOLOCK)
							WHERE Codigo = @Codigo
						)
						
					END  

					--Interesado
					IF @Opcion = '02'   
					BEGIN  

						SELECT DISTINCT
							@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
							,@CorreoAprobador = U.EMail                
							,@IdAprobador = U.IdUsuario               
						FROM Usuario U WITH (NOLOCK)
						WHERE U.IdUsuario = @IdSolicitante  

					END 

				--Inicio @6
				END
				--Fin @6

			END  
			ELSE  
			--Cuando se Cancela el Proceso (CANCELGDH)
			--Cuando se Cierra el Proceso (CRRDOGDH)
			--APROBACION COMPENSACIONES (APCMP)
			--APROBACION FINANZAS (APFNZ)
			--APROBACION GDH (APGDH)
			--APROBACION GERENCIA GENERAL (APGGR)
			--B�SQUEDA (BUSQGDH)
			BEGIN 

				--Inicio @6
				IF @Organigrama_RequerimientoSeleccion = 'Planilla'
				BEGIN

					--Cuando se Cancela el Proceso
					IF @Codigo = 'CANCELGDH'                
					BEGIN     
					
						--Inicio --@9
						SELECT DISTINCT
							@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
							,@CorreoAprobador=U.EMail                
							,@IdAprobador=U.IdUsuario   
						FROM EmpleadoMast EM WITH (NOLOCK)
						LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
						LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
						LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
						LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
						LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
						WHERE EM.CodigoCargo IN (
							SELECT DISTINCT
								PAS.Codigo
							FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
							WHERE PAS.IdPuesto IN (
								--Academico
									--Puesto: 663 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								--AcademicoIDAT
									--Puesto: 571 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								--AcademicoCA
									--Puesto: 284 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
								--Academico
									--Puesto: 613 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
								--AcademicoIDAT
									--Puesto: 521 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
								--AcademicoCA
									--Puesto: 234 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
								--Inicio --@11
								--Academico
									--Puesto: 1983 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
								--AcademicoIDAT
									--Puesto: 1855 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
								--AcademicoCA
									--Puesto: 1520 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
								--Fin --@11
								SELECT DISTINCT
									IdPuestoAprobador
								FROM @TempPuestoAprobadores
							)
							AND PAS.CompanyOwner = @CompanyOwner
							AND PAS.CodigoPuesto IS NULL
						)
						AND EM.FlagEsLider = 'S'
						AND EM.Estado = 'A'
						AND U.IdUsuario = @IdUsuarioAprobador

						IF @NombreAprobador = '' AND @CorreoAprobador = '' AND @IdAprobador = 0
						BEGIN

							SELECT DISTINCT
								@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
								,@CorreoAprobador = U.EMail                
								,@IdAprobador = U.IdUsuario                
							FROM Usuario U
							WHERE U.IdUsuario = @IdUsuarioAprobador

						END

						--Fin --@9

					END               
					ELSE        
					BEGIN      
					
						--Cuando se Cierra el Proceso
						IF @Codigo ='CRRDOGDH'           
						BEGIN   
						
							--GDH
							IF @Opcion = '02'      
							BEGIN  

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8         
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario 
								FROM EmpleadoMast EM WITH (NOLOCK)
								LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
								LEFT JOIN PersonaMast PM WITH(NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
								LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
								LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
								LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
								WHERE EM.CodigoCargo IN (
									SELECT DISTINCT
										PAS.Codigo
									FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
									WHERE PAS.IdPuesto IN (
										SELECT DISTINCT
											IdPuestoAprobador
										FROM @TempPuestoAprobadores
										WHERE IdPuestoAprobador IN (
											--Academico
												--Puesto: 613 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
											--Inicio --@11
											--Academico
												--Puesto: 1983 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
											--Fin --@11
											SELECT DISTINCT
												IdPuestoAprobador
											FROM @TempPuestoAprobadores
											WHERE IdPuestoAprobador IN (1983) --@11
											AND (@CompanyOwner = '00002500' or @CompanyOwner = '00002400')--@10
											UNION
											--AcademicoIDAT
												--Puesto: 521 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
											--Inicio --@11
											--AcademicoIDAT
												--Puesto: 1855 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
											--Fin --@11
											SELECT DISTINCT
												IdPuestoAprobador
											FROM @TempPuestoAprobadores
											WHERE IdPuestoAprobador IN (1855) --@11
											AND @CompanyOwner = '00002700'
											UNION
											--AcademicoCA
												--Puesto: 234 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
											--Inicio --@11
											--AcademicoCA
												--Puesto: 1520 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
											--Fin --@11
											SELECT DISTINCT
												IdPuestoAprobador
											FROM @TempPuestoAprobadores
											WHERE IdPuestoAprobador IN (1520) --@11
											AND @CompanyOwner = '00002600'
										)
									)
									AND PAS.CompanyOwner = @CompanyOwner
									AND PAS.CodigoPuesto IS NULL
								)
								AND EM.FlagEsLider = 'S'
								AND EM.Estado = 'A' 
								
							END  

							--Interesado
							IF @Opcion = '01'   
							BEGIN  

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario              
								FROM Usuario U WITH (NOLOCK)
								WHERE U.IdUsuario = @IdSolicitante 
								
							END  

							--Interesado
							IF @Opcion = '03'   
							BEGIN  

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(A.Nombres, 1 , CHARINDEX(' ', A.Nombres + ' ' ) -1) + ' ' + A.Paterno --@8
									,@CorreoAprobador = AE.Descripcion                
									,@IdAprobador = A.IdActor                
								FROM Actor A WITH (NOLOCK)  
								INNER JOIN ActorEmail AE WITH (NOLOCK) ON A.IdActor = AE.IdActor  
								INNER JOIN RequerimientoSeleccion RS WITH (NOLOCK) ON RS.IdCandidato = A.IdActor  
								WHERE RS.IdRequerimientoSeleccion=@IdRequerimientoSeleccion
								AND AE.Principal = 1 --@7

							END 
							
						END        
						ELSE                      
						BEGIN    

							--APROBACION COMPENSACIONES
							IF @Codigo = 'APCMP' 
							BEGIN

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario 
								FROM EmpleadoMast EM WITH (NOLOCK)
								LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
								LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
								LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
								LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
								LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
								WHERE EM.CodigoCargo IN (
									SELECT DISTINCT
										PAS.Codigo
									FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
									WHERE PAS.IdPuesto IN (
										--Academico
											--Puesto: 613 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--AcademicoIDAT
											--Puesto: 521 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--AcademicoCA
											--Puesto: 234 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--Inicio --@11
										--Academico
											--Puesto: 1983 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--AcademicoIDAT
											--Puesto: 1855 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--AcademicoCA
											--Puesto: 1520 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--Fin --@11
										SELECT DISTINCT
											IdPuestoAprobador
										FROM @TempPuestoAprobadores
									)
									AND PAS.CompanyOwner = @CompanyOwner
									AND PAS.CodigoPuesto IS NULL
								)
								AND EM.FlagEsLider = 'S'
								AND EM.Estado = 'A' 

							END
							
							--APROBACION FINANZAS
							IF @Codigo = 'APFNZ' 
							BEGIN

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario 
								FROM EmpleadoMast EM WITH (NOLOCK)
								LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
								LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
								LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
								LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login) AND EM.CodigoUsuario = U.Login
								LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
								WHERE EM.CodigoCargo IN (
									SELECT DISTINCT
										PAS.Codigo
									FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
									WHERE PAS.IdPuesto IN (
										--Academico
											--Puesto: 477 (JEFE DE TESORER�A Y COBRANZAS)
										--AcademicoIDAT
											--Puesto: 385 (JEFE DE TESORER�A Y COBRANZAS)
										--AcademicoCA
											--Puesto: 98 (JEFE DE TESORER�A Y COBRANZAS)
										SELECT DISTINCT
											IdPuestoAprobador
										FROM @TempPuestoAprobadores
									)
									AND PAS.CompanyOwner = @CompanyOwner
									AND PAS.CodigoPuesto IS NULL
								)
								AND EM.FlagEsLider = 'S'
								AND EM.Estado = 'A' 

							END

							--APROBACION GDH
							IF @Codigo = 'APGDH' 
							BEGIN

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario 
								FROM EmpleadoMast EM WITH (NOLOCK)
								LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
								LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
								LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
								LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login)
								LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
								WHERE EM.CodigoCargo IN (
									SELECT DISTINCT
										PAS.Codigo
									FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
									WHERE PAS.IdPuesto IN (
										--Inicio @8
										--Antes la Aprobacion lo realizaba (GERENTE DE GESTI�N Y DESARROLLO HUMANO)
										--Academico
											--Puesto: 592 (GERENTE DE GESTI�N Y DESARROLLO HUMANO)
										--AcademicoIDAT
											--Puesto: 500 (GERENTE DE GESTI�N Y DESARROLLO HUMANO)
										--AcademicoCA
											--Puesto: 213 (GERENTE DE GESTI�N Y DESARROLLO HUMANO)
										--Fin --@8
										--Inicio --@8
										--Ahora la Aprobacion lo realizara (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--Academico
											--Puesto: 613 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--AcademicoIDAT
											--Puesto: 521 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--AcademicoCA
											--Puesto: 234 (COORDINADORA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--Fin --@11
										--Inicio --@11
										--Ahora la Aprobacion lo realizara (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--Academico
											--Puesto: 1983 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--AcademicoIDAT
											--Puesto: 1855 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--AcademicoCA
											--Puesto: 1520 (JEFA DE ADMINISTRACI�N DE PERSONAL Y COMPENSACIONES)
										--Fin --@11
										SELECT DISTINCT
											IdPuestoAprobador
										FROM @TempPuestoAprobadores
									)
									AND PAS.CompanyOwner = @CompanyOwner
									AND PAS.CodigoPuesto IS NULL
								)
								AND EM.FlagEsLider = 'S'
								AND EM.Estado = 'A' 

							END

							--APROBACION GERENCIA GENERAL
							--Inicio --@8
							/*
							IF @Codigo = 'APGGR' 
							BEGIN

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8  
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario 
								FROM EmpleadoMast EM WITH (NOLOCK)
								LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
								LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
								LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
								LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login) AND EM.CodigoUsuario = U.Login
								LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
								WHERE EM.CodigoCargo IN (
									SELECT DISTINCT
										PAS.Codigo
									FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
									WHERE PAS.IdPuesto IN (
										--Academico
											--Puesto: 468 (GERENTE GENERAL)
										--AcademicoIDAT
											--Puesto: 376 (GERENTE GENERAL)
										--AcademicoCA
											--Puesto: 89 (GERENTE GENERAL)
										SELECT DISTINCT
											IdPuestoAprobador
										FROM @TempPuestoAprobadores
									) 
									AND PAS.CompanyOwner = @CompanyOwner
									AND PAS.CodigoPuesto IS NULL
								)
								AND EM.FlagEsLider = 'S'
								AND EM.Estado = 'A' 
								AND U.IdUsuario IS NOT NULL

							END
							*/
							--Fin --@8

							--B�SQUEDA
							IF @Codigo = 'BUSQGDH' 
							BEGIN

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario 
								FROM EmpleadoMast EM WITH (NOLOCK)
								LEFT JOIN Sede S WITH (NOLOCK) ON EM.Sucursal = S.Sucursal
								LEFT JOIN PersonaMast PM WITH (NOLOCK) ON EM.Empleado = PM.Persona AND PM.EsEmpleado = 'S'
								LEFT JOIN Actor A WITH (NOLOCK) ON PM.DocumentoIdentidad = A.NumeroIdentidad
								LEFT JOIN Usuario U WITH (NOLOCK) ON A.IdActor = U.IdActor AND (EM.CorreoInterno = U.EMail OR EM.CodigoUsuario = U.Login) AND EM.CodigoUsuario = U.Login
								LEFT JOIN EmpleadoMast EMPJ WITH (NOLOCK) ON EM.JefeResPonsable = EMPJ.Empleado
								WHERE EM.CodigoCargo IN (
									SELECT DISTINCT
										PAS.Codigo
									FROM PuestoAreaSeleccion PAS WITH (NOLOCK)
									WHERE PAS.IdPuesto IN (
										--Academico
											--Puesto: 663 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
										--AcademicoIDAT
											--Puesto: 571 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
										--AcademicoCA
											--Puesto: 284 (JEFA DE TALENTO, CAPACITACI�N Y DESARROLLO)
										SELECT DISTINCT
											IdPuestoAprobador
										FROM @TempPuestoAprobadores
									)
									AND PAS.CompanyOwner = @CompanyOwner
									AND PAS.CodigoPuesto IS NULL
								)
								AND EM.FlagEsLider = 'S'
								AND EM.Estado = 'A' 

							END
							
						END  
						
					END  

				END
				ELSE
				BEGIN
				--Fin @6

					--Cuando se Cancela el Proceso
					IF @Codigo = 'CANCELGDH'                
					BEGIN   
					
						SELECT DISTINCT
							@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
							,@CorreoAprobador = U.EMail                
							,@IdAprobador = U.IdUsuario                
						FROM Usuario U WITH (NOLOCK)
						WHERE U.IdUsuario = @IdSolicitante 
						
					END               
					ELSE        
					BEGIN  
					
						--Cuando se Cierra el Proceso
						IF @Codigo = 'CRRDOGDH'           
						BEGIN    
						
							--GDH
							IF @Opcion = '02'      
							BEGIN  

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario                
								FROM Usuario U WITH (NOLOCK)
								WHERE U.IdUsuario IN (
									SELECT DISTINCT
										Disponible4
									FROM MaestroTablaRegistro WITH (NOLOCK)
									WHERE Codigo = @Codigo
								)     

							END  

							--Interesado
							IF @Opcion = '01'   
							BEGIN  

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
									,@CorreoAprobador = U.EMail                
									,@IdAprobador = U.IdUsuario            
								FROM Usuario U WITH (NOLOCK)
								WHERE U.IdUsuario = @IdSolicitante  

							END  

							--Interesado
							IF @Opcion = '03'   
							BEGIN  

								SELECT DISTINCT
									@NombreAprobador = SUBSTRING(A.Nombres, 1 , CHARINDEX(' ', A.Nombres + ' ' ) -1) + ' ' + A.Paterno --@8
									,@CorreoAprobador = AE.Descripcion                
									,@IdAprobador = A.IdActor                
								FROM Actor A WITH (NOLOCK)  
								INNER JOIN ActorEmail AE WITH (NOLOCK) on A.IdActor = AE.IdActor  
								INNER JOIN RequerimientoSeleccion RS WITH (NOLOCK) ON RS.IdCandidato = A.IdActor  
								WHERE RS.IdRequerimientoSeleccion = @IdRequerimientoSeleccion  
								AND AE.Principal = 1 --@7

							END  
							
						END        
						ELSE                      
						BEGIN  
						
							SELECT DISTINCT
								@NombreAprobador = SUBSTRING(U.Nombres, 1 , CHARINDEX(' ', U.Nombres + ' ' ) -1) + ' ' + U.ApellidoPaterno --@8
								,@CorreoAprobador = U.EMail                
								,@IdAprobador = U.IdUsuario                 
							FROM Usuario U WITH (NOLOCK)
							WHERE U.IdUsuario IN (
								SELECT DISTINCT
									IdUsuarioAprobador
								FROM @TempAprobadores
							)  
							
						END 
						
					END  
					
				--Inicio @6
				END
				--Fin @6

			END 
			
		END

	END

	--Inicio @6	
	IF @Organigrama_RequerimientoSeleccion = 'Planilla'
	BEGIN

		SELECT DISTINCT
			IdrequerimientoSeleccion                 
			,'NombreArea' = TRIM(UPPER(ASE.Nombre)) --@8                 
			,'NombreGerencia' = TRIM(UPPER(MTR1.Nombre)) --@8                 
			,'NombrePuesto' = TRIM(UPPER(PAS.Nombre)) --@8                
			,'NombreSede' = TRIM(UPPER(S.Nombre)) --@8                 
			,'NombreModalidad' = TRIM(MTR2.Nombre) --@8                 
			,'NombreConvocatoria' = TRIM(MTR3.Nombre) --@8                 
			,'NombrePosicion' = TRIM(ISNULL(MTR4.Nombre,'')) --@8     
			,'NombrePosicionTipo' = TRIM(ISNULL(MTR4.Disponible1,'')) --@8                
			,'NombrePeriodoPrueba' = TRIM(ISNULL(MTR5.Nombre,'')) --@8               
			,'IdPeriodoPrueba' = ISNULL(RS.IdPeriodoPrueba,'')       
			,'IdTipoPosicion' = ISNULL(RS.IdTipoPosicion,'')              
			,'FechaInicio' = ISNULL(dbo.gFechaStr(RS.FechaInicio),'')              
			,'FechaFin' = ISNULL(RS.FechaFin,'')          
			,'NombreEstado' = TRIM(ISNULL(@NombreEstado,'')) --@8               
			,'NombreSolicitante' = TRIM(ISNULL(@NombreSolicitante,'')) --@8             
			,'IdSolicitante' = ISNULL(@IdSolicitante,'')               
			,'NombreAprobador' = TRIM(ISNULL(@NombreAprobador,'')) --@8               
			,'IdAprobador' = ISNULL(@IdAprobador,'')             
			,'CorreoAprobador' = TRIM(ISNULL('alsanchez@inlearning.pe','')) --@8              
			,'IdCorreo' = ISNULL(@IdCorreo,'')                 
			,'IdEstado' = RS.IdEstado              
			,'Estado' = TRIM(ISNULL(@Codigo,'')) --@8               
			,'Activo' = RS.Activo                  
			,'Comentario' = TRIM(ISNULL(RS.Comentario,'')) --@8                 
			,'HorarioPropuesto' = TRIM(ISNULL(RS.HorarioPropuesto,'')) --@8                 
			,'RangoSalario' = TRIM(ISNULL(RS.RangoSalario,'')) --@8     
			,'SalarioFin' = ISNULL(RS.SalarioFin,'')             
			,'FechaIngreso' = TRIM(ISNULL(dbo.gFechaStr(RS.FechaIngreso),'')) --@8                 
			,'IdCandidato' = ISNULL(RS.IdCandidato,'')    
			,'NombreCandidato' = TRIM(ISNULL(AC.Nombres + ' ' + AC.Paterno + ' ' + Ac.Materno,'')) --@8                 
			,'UsuarioCreacionFecha' = TRIM(U.Nombre+' ('+dbo.FechaHora(RS.FechaCreacion)+')') --@8                  
			,'UsuarioModificacionFecha' = TRIM(UU.Nombre+' ('+dbo.FechaHora(RS.FechaModificacion)+')') --@8              
			,'Presupuestado' = TRIM(ISNULL(MTR6.Nombre,'')) --@3 --@8
			,'NumeroSolicitud' = TRIM(ISNULL(RS.NumeroSolicitud,'')) --@5 --@8
			,'Marca' = TRIM(ISNULL(E.NombreComercial,'')) --@12
		FROM RequerimientoSeleccion RS WITH (NOLOCK)                  
		LEFT JOIN Usuario U WITH (NOLOCK) ON RS.UsuarioCreacion = U.IdUsuario                  
		LEFT JOIN Usuario UU WITH (NOLOCK) ON RS.UsuarioModificacion = UU.IdUsuario                
		LEFT JOIN GerenciaSeleccion MTR1 WITH (NOLOCK) ON RS.IdGerencia = MTR1.IdGerenciaSeleccion                
		LEFT JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON RS.IdTipoModalidad = MTR2.IdMaestroRegistro                
		LEFT JOIN MaestroTablaRegistro MTR3 WITH (NOLOCK) ON RS.IdTipoConvocatoria = MTR3.IdMaestroRegistro                
		LEFT JOIN MaestroTablaRegistro MTR4 WITH (NOLOCK) ON RS.IdTipoPosicion = MTR4.IdMaestroRegistro                
		LEFT JOIN MaestroTablaRegistro MTR5 WITH (NOLOCK) ON RS.IdPeriodoPrueba = MTR5.IdMaestroRegistro                
		LEFT JOIN Areaseleccion ASE WITH (NOLOCK) ON RS.IdArea = ASE.IdAreaSeleccion                
		LEFT JOIN PuestoAreaSeleccion PAS WITH (NOLOCK) ON RS.IdPuesto = PAS.IdPuesto                
		LEFT JOIN Sede S WITH (NOLOCK) ON RS.IdSede = S.IdSede        
		LEFT JOIN Actor AC WITH (NOLOCK) ON RS.IdCandidato = AC.IdActor    
		LEFT JOIN MaestroTablaRegistro MTR6 WITH(NOLOCK) ON MTR6.IdMaestroRegistro = RS.IdPresupuestado --@3           
		LEFT JOIN Empresa E WITH (NOLOCK) ON S.Empresa = E.IdEmpresa --@12
		WHERE RS.IdRequerimientoSeleccion = @IdRequerimientoSeleccion  
	END
	ELSE
	BEGIN

	--Fin @6	
		SELECT DISTINCT              
			IdrequerimientoSeleccion                 
			,'NombreArea' = TRIM(UPPER(ASE.Nombre)) --@8                  
			,'NombreGerencia' = TRIM(UPPER(MTR1.Nombre)) --@8                  
			,'NombrePuesto' = TRIM(UPPER(PAS.Nombre)) --@8                  
			,'NombreSede' = TRIM(UPPER(S.Nombre)) --@8                  
			,'NombreModalidad' = TRIM(MTR2.Nombre) --@8                  
			,'NombreConvocatoria' = TRIM(MTR3.Nombre) --@8                  
			,'NombrePosicion' = TRIM(ISNULL(MTR4.Nombre,'')) --@8      
			,'NombrePosicionTipo' = TRIM(ISNULL(MTR4.Disponible1,'')) --@8                 
			,'NombrePeriodoPrueba' = TRIM(ISNULL(MTR5.Nombre,'')) --@8                
			,'IdPeriodoPrueba' = ISNULL(RS.IdPeriodoPrueba,'')  
			,'IdTipoPosicion' = ISNULL(RS.IdTipoPosicion,'')                  
			,'FechaInicio' = ISNULL(dbo.gFechaStr(RS.FechaInicio),'')               
			,'FechaFin' = ISNULL(RS.FechaFin,'')              
			,'NombreEstado' = TRIM(ISNULL(@NombreEstado,'')) --@8                
			,'NombreSolicitante' = TRIM(ISNULL(@NombreSolicitante,'')) --@8              
			,'IdSolicitante' = ISNULL(@IdSolicitante,'')                
			,'NombreAprobador' = TRIM(ISNULL(@NombreAprobador,'')) --@8                
			,'IdAprobador' = ISNULL(@IdAprobador,'')             
			,'CorreoAprobador' = TRIM(ISNULL('alsanchez@inlearning.pe','')) --@8               
			,'IdCorreo' = ISNULL(@IdCorreo,'')                 
			,'IdEstado' = RS.IdEstado              
			,'Estado' = TRIM(ISNULL(@Codigo,'')) --@8                
			,'Activo'= RS.Activo                  
			,'Comentario' = TRIM(ISNULL(RS.Comentario,'')) --@8                  
			,'HorarioPropuesto' = TRIM(ISNULL(RS.HorarioPropuesto,'')) --@8                  
			,'RangoSalario' = TRIM(ISNULL(RS.RangoSalario,'')) --@8      
			,'SalarioFin' = ISNULL(RS.SalarioFin,'')              
			,'FechaIngreso' = TRIM(ISNULL(dbo.gFechaStr(RS.FechaIngreso),'')) --@8                  
			,'IdCandidato' = ISNULL(RS.IdCandidato,'')      
			,'NombreCandidato' = TRIM(ISNULL(AC.Nombres + ' ' + AC.Paterno + ' ' + Ac.Materno,'')) --@8                  
			,'UsuarioCreacionFecha' = TRIM(U.Nombre+' ('+dbo.FechaHora(RS.FechaCreacion)+')') --@8                  
			,'UsuarioModificacionFecha' = TRIM(UU.Nombre+' ('+dbo.FechaHora(RS.FechaModificacion)+')') --@8              
			,'Presupuestado' = TRIM(ISNULL(MTR6.Nombre,'')) --@3 --@8
			,'NumeroSolicitud' = TRIM(ISNULL(RS.NumeroSolicitud,'')) --@5 --@8
			,'Marca' = TRIM(ISNULL(E.NombreComercial,'')) --@12
		FROM RequerimientoSeleccion RS WITH (NOLOCK)                  
		INNER JOIN Usuario U WITH (NOLOCK) ON RS.UsuarioCreacion = U.IdUsuario                  
		INNER JOIN Usuario UU WITH (NOLOCK) ON RS.UsuarioModificacion = UU.IdUsuario                
		INNER JOIN MaestroTablaRegistro MTR1 WITH (NOLOCK) ON RS.IdGerencia = MTR1.IdMaestroRegistro                
		LEFT JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON RS.IdTipoModalidad = MTR2.IdMaestroRegistro                
		INNER JOIN MaestroTablaRegistro MTR3 WITH (NOLOCK) ON RS.IdTipoConvocatoria = MTR3.IdMaestroRegistro                
		LEFT JOIN MaestroTablaRegistro MTR4 WITH (NOLOCK) ON RS.IdTipoPosicion = MTR4.IdMaestroRegistro                
		LEFT JOIN MaestroTablaRegistro MTR5 WITH (NOLOCK) ON RS.IdPeriodoPrueba = MTR5.IdMaestroRegistro                
		INNER JOIN Areaseleccion ASE WITH (NOLOCK) ON RS.IdArea = ASE.IdAreaSeleccion                
		INNER JOIN PuestoAreaSeleccion PAS WITH (NOLOCK) ON RS.IdPuesto = PAS.IdPuesto                
		INNER JOIN Sede S WITH (NOLOCK) ON RS.IdSede = S.IdSede        
		LEFT JOIN Actor AC WITH (NOLOCK) ON RS.IdCandidato = AC.IdActor    
		LEFT JOIN MaestroTablaRegistro MTR6 WITH(NOLOCK) ON MTR6.IdMaestroRegistro = RS.IdPresupuestado --@3   
		LEFT JOIN Empresa E WITH (NOLOCK) ON S.Empresa = E.IdEmpresa --@12
		WHERE RS.IdRequerimientoSeleccion = @IdRequerimientoSeleccion   
	--Inicio @6	

	END
	--Fin @6	
                           
END
