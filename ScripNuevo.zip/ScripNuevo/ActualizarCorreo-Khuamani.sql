UPDATE Usuario SET EMail='khuamani@inlearning.edu.pe'
WHERE IdUsuario=365333
--(1 rows affected)