--����������������������������������������������������������������������������
--Creado por	: Jimy Mota (2018.03.08)
--Funcionalidad : Permite registrar descuentos autom�ticos a una matricula
--Utilizado por : DescuentoAcademico.UpdProcesar
--Proyecto		: Descuento academico 
--����������������������������������������������������������������������������
/*
-----------------------------------------------------------------------------
Nro		FECHA			USUARIO				DESCRIPCION
-----------------------------------------------------------------------------
@1		2018.12.05		jmota				cuando la matricula por fecha de matricula o pre 
@2		2018.12.18		jmota				se agrega campo para consultar por fecha actual cuando es necesario dependiendo del proceso 
@3		11.01.2019		Eloy Alva			Agregar parametro CompaniaSocio. 
@4		2020.11.18		jmota				si es pre matricula consulta fecha actual
@5		2022.10.18		EHuillca			Se agrega validaci�n al eliminar e insertar descuentoalumnoresultado
@6		2022.11.03		EHuillca			Se agrega tabla temporal para cuotas que no se deben eliminar en los maestros de descuentos. 
@7		2024.03.01		rotorres			Se agrega WITH(NOLOCK)  
@8		2024.05.01		FETORRES			Se agrega logica para que CA tome la compania socio de ZEGEL.
@9		2024.10.24		MQUIROZ				SE AGREGA VALIDACION PARA ITS
@10		26/09/2025		JQuenta				Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil
*/

--CREATE PROCEDURE [dbo].[cDescuentoAlumno_Upd_AutoAsignarXmatricula]
DECLARE
@IdMatricula INT,
@FechaConsulta DATE = NULL --@2
--AS  
BEGIN  
select @FechaConsulta='20260430',@IdMatricula=810270
	--Inicio --@10
	SET NOCOUNT ON 

	DECLARE
	@Min INT, 
	@Max INT,  
	@IdActor INT,
	@IdEmpresa INT,
	@IdSede INT,
	@IdFacultad INT,
	@IdUnidadNegocio INT,
	@IdUnidadAcademica INT,
	@IdPeriodo INT,
	@IdCurricula INT,
	@IdProducto INT,
	@IdModulo INT,
	@IdTipoTurno INT,
	@IdPromocion INT,
	@IdGrupo INT,
	@IdSeccion INT,
	@IdTipo INT,
	@EsContado BIT,
	@Disponible1 VARCHAR(100),
	@UsuarioCreacion INT = NULL, 
	@IdConvenio INT = NULL,
	@TipoServicio CHAR(1) = NULL,
	@RetVal INT,
	@IdDescuentoAcademico INT,
	@IdPrecioSede INT,
	@PrecioSedeSucursal VARCHAR(20)

	DECLARE @DescuentoAcademico AS TABLE
	(
		Id INT IDENTITY(1,1),
		IdDescuentoAcademico INT,
		IdTipoSituacionAlumno INT,
		Codigo VARCHAR(10),
		Nombre VARCHAR(500),
		Porcentaje DECIMAL(7,4),
		FechaInicio VARCHAR(20),
		FechaFin VARCHAR(20),
		NroPeriodo INT,
		EsAcumulativo BIT,
		DiasVigentes INT,
		IdTipo INT,
		TipoNombre VARCHAR(500), 
		CuotaNombre VARCHAR(MAX),
		Campana VARCHAR(100),
		Area VARCHAR(200),
		TipoMatricula VARCHAR(200)
	)

	--Obtenemos los Datos de la Matricula
	SELECT
		@IdActor = M.IdActor,
		@IdEmpresa = P.IdEmpresa,
		@IdSede = P.IdSede,
		@IdFacultad = P.IdFacultad,
		@IdUnidadNegocio = P.IdUnidadNegocio,
		@IdUnidadAcademica = P.IdUnidadAcademica,
		@IdPeriodo = P.IdPeriodo,
		@IdCurricula = P.IdCurricula,
		@IdProducto = P.IdProducto,
		@IdModulo = P.IdModulo,
		@IdTipoTurno = T.IdTipoTurno,
		@IdPromocion = P.IdPromocion,
		@IdGrupo = PG.IdGrupo,
		@IdSeccion = M.IdSeccion,
		@IdTipo = 23952, --Descuento Automatico
		@EsContado =
		CASE
			WHEN M.CondicionPago = 'C' THEN 1
			ELSE 0
		END,
		@Disponible1 = 'SECUENCIAL',
		@UsuarioCreacion = M.UsuarioCreacion, 
		@IdConvenio = M.IdConvenio,
		@IdMatricula =  M.IdMatricula,
		@TipoServicio =  M.TipoServicio,
		@FechaConsulta = ISNULL(@FechaConsulta,ISNULL(m.MatriculaFecha, GETDATE())), --@1 --@2 --@4   
		@IdPrecioSede = ISNULL(M.IdPrecioSede,-1)
	FROM Matricula M WITH (NOLOCK) --@10
	INNER JOIN Promocion P WITH (NOLOCK) ON P.IdPromocion = M.IdPromocion --@7  
	LEFT JOIN PromocionGrupo PG WITH (NOLOCK) ON PG.IdPromocion = P.IdPromocion
	AND PG.IdGrupo = M.IdGrupo --@7
	LEFT JOIN Turno T WITH (NOLOCK) ON T.IdTurno = PG.IdTurno --@7  
	LEFT JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroRegistro = T.IdTipoTurno --@7  
	WHERE IdMatricula = @IdMatricula



	
	DECLARE
	@CompaniaSocio CHAR(8) --@3

	--@5
	--@3
	SELECT
		@CompaniaSocio = CompaniaSocio
	FROM Empresa E WITH (NOLOCK)
	WHERE IdEmpresa = @IdEmpresa
	AND Activo = 1
	--@3
	--@5

 	IF
	(
		@CompaniaSocio = '00002600' --@8
		OR @CompaniaSocio = '00002400' --@9
	)
	BEGIN

		SELECT
			@CompaniaSocio = CompaniaSocioPadre
		FROM Empresa WITH (NOLOCK) --@10
		WHERE IdEmpresa = 1 --@10

	END   

	--Buscamos los Descuentos Automaticos para el Alumno
	select @IdActor,
	1,
	@IdSede,
	1,
	@IdUnidadNegocio,
	@IdUnidadAcademica,
	@IdPeriodo,
	@IdCurricula,
	@IdProducto,
	@IdModulo,
	@IdTipoTurno,
	@IdPromocion,
	@IdGrupo,
	@IdSeccion,
	@IdTipo,
	@EsContado,
	@Disponible1,
	@UsuarioCreacion, 
	@IdConvenio,
	@IdMatricula,
	@TipoServicio,
	@FechaConsulta,
	@IdPrecioSede
	INSERT INTO @DescuentoAcademico
	--Inicio --@10
	(
		IdDescuentoAcademico,
		IdTipoSituacionAlumno,
		Codigo,
		Nombre,
		Porcentaje,
		FechaInicio,
		FechaFin,
		NroPeriodo,
		EsAcumulativo,
		DiasVigentes,
		IdTipo,
		TipoNombre, 
		CuotaNombre,
		Campana,
		Area,
		TipoMatricula
	)
	--Fin --@10
	 
	EXEC cDescuentoAcademico_Sel_DescuentosActor
	@IdActor,
	1,
	@IdSede,
	1,
	@IdUnidadNegocio,
	@IdUnidadAcademica,
	@IdPeriodo,
	@IdCurricula,
	@IdProducto,
	@IdModulo,
	@IdTipoTurno,
	@IdPromocion,
	@IdGrupo,
	@IdSeccion,
	@IdTipo,
	@EsContado,
	@Disponible1,
	@UsuarioCreacion, 
	@IdConvenio,
	@IdMatricula,
	@TipoServicio,
	@FechaConsulta,
	@IdPrecioSede


	select * from @DescuentoAcademico
	SELECT @MIN = MIN(Id), @Max = MAX(Id) FROM @DescuentoAcademico

	--Eliminamos los descuento del alumno
	--Inicio @5
	--@6
	DECLARE @CuotaNumerosNoEliminar AS TABLE
	(
		CuotaNumero INT
	)
	--@6

	INSERT INTO @CuotaNumerosNoEliminar
	(
		CuotaNumero
	)
	SELECT
		CuotaNumero
	FROM vw_CO_Interfase_P09_Header CIH WITH (NOLOCK)
	WHERE CIH.IdMatricula = @IdMatricula
	AND
	(
		CIH.Estado = 'CO'
		OR LEFT(ISNULL(CIH.NumeroDocumento,''),2) IN ('FC','BV')
	)
	AND CIH.CompaniaSocio = @CompaniaSocio
  
	DELETE DAR
	FROM DescuentoAlumnoResultado DAR WITH (NOLOCK)
	WHERE DAR.IdMatricula = @IdMatricula
	AND DAR.Cuota NOT IN
	(
		SELECT
			CuotaNumero
		FROM @CuotaNumerosNoEliminar
	)
 
	DELETE DA
	FROM DescuentoAlumno DA WITH (NOLOCK) --@10
	WHERE DA.IdMatricula = @IdMatricula
	AND DA.Cuota NOT IN
	(
		SELECT
			CuotaNumero
		FROM @CuotaNumerosNoEliminar
	)
	--Fin @5 

	--Insertamos los Descuentos
	WHILE @MIN <= @Max 
	BEGIN
 
		SET @IdDescuentoAcademico = NULL

		SELECT
			@IdDescuentoAcademico  = IdDescuentoAcademico  
		FROM @DescuentoAcademico
		WHERE Id = @Min 

		--Insertamos en la Tabla DescuentoAlumno
		SET @RetVal = null

		EXEC cDescuentoAlumno_Ins_Grabar
		@IdActor,
		@IdMatricula,
		@IdEmpresa,
		@IdSede,
		@IdFacultad,
		@IdUnidadNegocio,
		@IdUnidadAcademica,
		@IdPeriodo,
		'',
		@IdCurricula,
		@IdProducto,
		@IdModulo,
		@IdDescuentoAcademico, 
		1, 
		@RetVal OUTPUT 

		SET @Min = @Min + 1

	END 
 
	--Reprocesamos y eliminamos en la Tabla DescuentoAlumnoResultado
	SET @RetVal = NULL

	EXEC cDescuentoAlumno_Ins_Resultado
	@IdMatricula,  
	@IdActor, 
	@RetVal OUTPUT  

	--Actualizamos Interfases
	SET @RetVal = NULL

	EXEC cDescuentoAlumno_Upd_InterfaseHeader
	@IdMatricula,  
	@IdActor, 
	@CompaniaSocio, --@3
	@RetVal OUTPUT
	--Fin --@10

END