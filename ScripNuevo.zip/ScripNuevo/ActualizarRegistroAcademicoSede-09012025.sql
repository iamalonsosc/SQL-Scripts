--SELECT*FROM Registro
UPDATE Registro SET IdSede=37
WHERE IdRegistro=1 AND IdActor=1664199