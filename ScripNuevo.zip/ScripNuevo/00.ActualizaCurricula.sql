USE AcademicoIDAT;
GO

UPDATE AC 
SET AC.IdCurriculaOriginal = M.IdCurricula
FROM Matricula M
	LEFT JOIN Actor A ON M.IdActor = A.IdActor
	LEFT JOIN Alumno AL ON M.IdActor = AL.IdAlumno
	LEFT JOIN Promocion P ON M.IdPromocion = P.IdPromocion
	LEFT JOIN PromocionGrupo PG ON P.IdPromocion = PG.IdPromocion AND M.IdGrupo = PG.IdGrupo
	LEFT JOIN Periodo PR ON P.IdPeriodo = PR.IdPeriodo
	LEFT JOIN UnidadNegocio UN ON P.IdUnidadNegocio = UN.IdUnidadNegocio
	LEFT JOIN UnidadAcademica UA ON P.IdUnidadAcademica= UA.IdUnidadAcademica
	LEFT JOIN Curricula CM ON M.IdCurricula = CM.IdCurricula
	LEFT JOIN Curricula CP ON P.IdCurricula = CP.IdCurricula
	LEFT JOIN AlumnoCurso AC ON M.IdMatricula = AC.IdMatricula
	LEFT JOIN Promocion PAC ON AC.IdPromocion = PAC.IdPromocion
	LEFT JOIN PromocionGrupo PGAC ON AC.IdPromocion = PGAC.IdPromocion AND AC.IdGrupo = PGAC.IdGrupo
	LEFT JOIN Periodo PRAC ON PAC.IdPeriodo = PRAC.IdPeriodo
	LEFT JOIN Seccion S ON AC.IdSeccion = S.Idseccion
	LEFT JOIN Curricula CAC ON AC.IdCurricula = CAC.IdCurricula
	LEFT JOIN Curricula COAC ON AC.IdCurriculaOriginal = COAC.IdCurricula
	LEFT JOIN Curricula CPAC ON PAC.IdCurricula = CPAC.IdCurricula
	LEFT JOIN Curso CS ON S.IdCurso = CS.IdCurso
	LEFT JOIN CURRICULA CSEC ON S.IdCurricula = CSEC.IdCurricula
	LEFT JOIN AlumnoCurriculaCurso ACC ON ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) = ACC.IdCurricula 
				AND AC.IdAlumno = ACC.IdAlumno AND ISNULL(AC.IdCursoOriginal, AC.IdCurso) = ACC.IdCurso 
				AND AC.IdRegistro = ACC.IdRegistro
	LEFT JOIN SEDE SE ON M.IdSede = SE.IDSEDE
	LEFT JOIN AlumnoCursoNomina ACN ON M.IdMatricula = ACN.IdMatricula AND ISNULL(AC.IDCURSOORIGINAL,AC.IdCurso) = ACN.IdCurso AND M.IdSede = SE.IDSEDE
WHERE M.EsMatricula = 1 
	  AND AC.EsMatricula = 1 
	  AND (PR.CodigoMinedu LIKE '2025-3%' OR PRAC.CodigoMinedu LIKE '2025-3%') 
	  AND S.Idseccion IS NOT NULL 
	  AND P.IdUnidadAcademica=57
	  AND m.Estado <>'X'
	  AND M.IdCurricula<>AC.IdCurricula 


