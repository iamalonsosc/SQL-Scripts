--SELECT*FROM Registro
UPDATE Registro SET Estado='N'
WHERE IdActor=1479666 AND IdRegistro=5
--(1 row affected)