--SELECT*FROM AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET IdConvalidacion=42111,PromedioFinal='16',PromedioReal='16'
,PromedioCondicion='A',Subsanacion=NULL,Observacion='APROBADO POR SECRETARIA GENERAL TICKET #67779',FechaModificacion=GETDATE()
WHERE IdAlumno=1436101
AND IdCurso=13538
AND IdCurricula=5815
--(1 row affected)