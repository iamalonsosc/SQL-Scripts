--����������������������������������������������������������������������������      
--Creado por: Edgard Huillca (10/05/2023)      
--Funcionalidad : Carga Datos para Env�o de N�minas a Minedu
--Utilizado por : Envio a la MINEDU
--����������������������������������������������������������������������������   
/*    
N� FECHA  USUARIO  DESCRIPCION    
@1 15.05.2023 Alsanchez Se a�adio el uso del nuevo campo EsUltimo
@2 15.05.2023 Alsanchez Se a�adio el uso del producto en 0 
@3 15.05.2023 Alsanchez Se agrega el tipo de proceso
@4 26.05.2023 Alsanchez Se agrega PeriodoCabecera para poder usar todos los periodos adicionales
@5 29.05.2023 Alsanchez Trae el UsuarioMinedu de la tabla parametro, en el valor2 que es la condiicon, se coloca Oficial o Prueba, dependiendo si seran actas oficiales, o de prueba
@6 23.06.2023 Alsanchez Saca la calificacion en Null por la especificacion del Minedu
@7 22.08.2023 lpariona Se a�adio las columnas PeriodoAcademico y Turno
@8 03.09.2023 lpariona Se mejora el proceso de generacion del JSON y se comenta codigo
@9 12.10.2023 Alsanchez Mejora de traer el usuario de la tabla parametro
@10	16.10.2023 EHuillca Se agrega validaci�n por sede - se excluyen alumnos de matr�cula por curso libre
@11 18.10.2023 lpariona Se valido los usuarios minedu por compa�ia socio
@12 08.03.2024 mquiroz	Se agrega validacion para ITS
@13 17.06.2024 Alsanchez Agregamos el turno tarde, en el campo TURNO
*/  
ALTER PROCEDURE [dbo].[cEnvio_Minedu_Nominas]
--declare
@IdEmpresa INT,
@IdSede INT,
@IdFacultad INT,
@IdUnidadNegocio INT,
@IdPeriodo INT,
@IdProducto INT,
@TipoProceso CHAR(2)--@3
AS
BEGIN
	--select @IdEmpresa=1,
	--@IdSede=6,
	--@IdFacultad=1,
	--@idUnidadNegocio =1,
	--@IdPeriodo = 4307,
	--@IdProducto= 0,
	--@TipoProceso='MA'

	SET NOCOUNT ON     
	DECLARE 
	@usuario NVARCHAR(30),
	@contra NVARCHAR(30),
	@cmodular NVARCHAR(30),
	@NivelFormativo VARCHAR(50),
	@CantidadAlumnos INT,
	@IdUnidadAcademica INT,
	@CompaniaSocio varchar(20)--@11

	select @CompaniaSocio=CompaniaSocio from Empresa WITH(NOLOCK) where Activo = 1--@11

	SET @IdUnidadAcademica = (SELECT IdUnidadAcademica FROM Periodo WITH(NOLOCK) WHERE IdPeriodo = @IdPeriodo)

	--SE GUARDA EL CODIGO MODULAR   
	SELECT DISTINCT @cmodular = ISNULL(Valor10 ,'')  
	FROM ParametroUnidadAcademica WITH(NOLOCK)  
	WHERE IdEmpresa= @IdEmpresa    
	AND IdUnidadNegocio = @IdUnidadNegocio  
	AND IdUnidadAcademica = @IdUnidadAcademica  
	AND IdSede = @IdSede   
	AND (IdProducto = @IdProducto OR @IdProducto = 0)  
	AND Nombre='ParametroNomina1'   
	
	DECLARE @Min INT, @Max INT, @SeccionNomina VARCHAR(100),@SeccionNominaCambio VARCHAR(100), @SedeCambio VARCHAR(50), @CModularCambio VARCHAR(20),
	@PeriodoAcademico VARCHAR(15),@TurnoNombre VARCHAR(8)--@7

	DECLARE @JSON AS TABLE
	(
		Usuario VARCHAR(20),
		Contra VARCHAR(100),
		Seccion varchar(100),
		CantidadAlumnos INT,
		CodigoModular VARCHAR(20),
		NivelFormativo VARCHAR(50),
		cadenaJson VARCHAR(MAX),
		PeriodoAcademico VARCHAR(15),--@7
		Turno VARCHAR(8)--@7
	)
	--@8 Inicio
	declare @tablaJson as table(
		tipoActa varchar(2),
		nombrePeriodoLectivo varchar(20),
		codigoModular varchar(20),
		nombreSedeInstitucion varchar(50),
		nivelFormacion varchar(1000),
		nombreCarrera varchar(200),
		nombrePlanEstudio varchar(150),
		semestreAcademico varchar(4),
		turno varchar(7),
		seccion varchar(100),
		cantidadAlumno int,
		persona varchar(max)
	)
	--@8 Fin
	DECLARE @Table AS TABLE
	(
	Id INT IDENTITY,
	SeccionNomina VARCHAR(100),
	CantidadAlumnos INT,
	SeccionNominaCambio VARCHAR(100),
	SedeCambio VARCHAR(50),
	CModularCambio VARCHAR(20),
	NivelFormativo VARCHAR(50)
	--,PeriodoAcademico VARCHAR(15),--@7--@8
	--Turno VARCHAR(8)--@7--@8
	)
	INSERT INTO @Table 
	SELECT DISTINCT
	ACN.SeccionNomina,COUNT(DISTINCT ACN.IdActor), ACN.SeccionNomina + '-'+ENE.CodigoSedeOrigen, S.Nombre, ENE.CodModularDestino,PUA.Valor4
	--,CASE ACN.IdModulo WHEN 1 THEN 'I Semestre'ELSE '' END+
	--	CASE ACN.IdModulo WHEN 2 THEN 'II Semestre'ELSE '' END+
	--	CASE ACN.IdModulo WHEN 3 THEN 'III Semestre'ELSE ''END+
	--	CASE ACN.IdModulo WHEN 4 THEN 'IV Semestre'ELSE ''END+
	--	CASE ACN.IdModulo WHEN 5 THEN 'V Semestre'ELSE ''END+
	--	CASE ACN.IdModulo WHEN 6 THEN 'VI Semestre'ELSE ''END+
	--	CASE ACN.IdModulo WHEN 7 THEN 'VII Semestre'ELSE ''END+
	--	CASE ACN.IdModulo WHEN 8 THEN 'VIII Semestre'ELSE ''END,--@7--@8
	--CASE ACN.Turno  WHEN 'MADRUGADOR' THEN 'MA�ANA'
	--	WHEN 'DIURNO' THEN 'MA�ANA'
	--	WHEN 'NOCTURNO' THEN 'NOCHE'
	--	ELSE 'MA�ANA' END--@7--@8
	FROM AlumnoCursoNomina ACN WITH (NOLOCK)
	INNER JOIN Producto PRO WITH (NOLOCK) ON ACN.IdProducto=PRO.IdProducto  
	INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON pro.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro  
	INNER JOIN Periodo PE  WITH (NOLOCK) ON ACN.IdPeriodo=PE.IdPeriodo
	INNER JOIN PeriodoCabecera PEC WITH (NOLOCK) ON PE.IdPeriodoCabecera=PEC.IdPeriodoCabecera --@4
	INNER JOIN Matricula M WITH(NOLOCK)
		ON ACN.IdMatricula = M.IdMatricula 
	INNER JOIN Promocion P WITH (NOLOCK)ON M.IdPromocion = P.IdPromocion
	INNER JOIN ParametroUnidadAcademica PUA WITH(NOLOCK)
		ON  PUA.IdUnidadNegocio=P.IdUnidadNegocio
		AND PUA.IdUnidadAcademica = P.IdUnidadAcademica 
		AND PUA.IdSede=P.IdSede
		AND PUA.Nombre='ParametroNomina1' 
		AND PUA.IdProducto=P.IdProducto
	LEFT JOIN EquivalenciaNominasEnvioJSON ENE WITH (NOLOCK)ON ACN.IdSede = ENE.IdSedeOrigen AND ACN.IdProducto = ENE.IdProducto AND PEC.Codigo = ENE.Periodo--@4
	LEFT JOIN Sede S WITH (NOLOCK)ON ENE.IdSedeDestino = S.IdSede
	WHERE ACN.IdEmpresa=@IdEmpresa          
	AND ACN.IdSede=@IdSede                
	AND ACN.IdPeriodo=@IdPeriodo          
	AND (ACN.IdProducto=@IdProducto OR @IdProducto = 0)          	
	AND (( MTR_PRO.Disponible1='C' AND  MTR_PRO.Disponible2='CAR' ) OR MTR_PRO.Disponible1='P' ) 
	AND PE.IdUnidadNegocio IN (@IdUnidadNegocio)
	AND M.NumeroMatricula IS NULL--@10
	GROUP BY ACN.SeccionNomina,ENE.CodigoSedeOrigen,S.Nombre,ENE.CodModularDestino,PUA.Valor4--,ACN.IdModulo,ACN.Turno--@7--@8

	SELECT @Min = MIN(Id), @Max = MAX(Id) FROM @Table    
	
	--SET @usuario='usuario_prueba_2'
	--SELECT @usuario= Valor FROM parametro WITH(NOLOCK) WHERE  Nombre='UsuarioMinedu' AND Valor2 = 'Prueba' --@5
	--CODIGO MODULAR
	IF @CompaniaSocio = '00002500' or @CompaniaSocio = '00002400'--@11 --@12
	BEGIN
		SELECT @contra = Valor,@usuario=Valor3 FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular
	END
	ELSE IF @CompaniaSocio = '00002700'--@11
	BEGIN
		SELECT @usuario=ISNULL(Valor2,Valor) FROM parametro WITH(NOLOCK) WHERE  Nombre='UsuarioMinedu'--@9
		--CODIGO MODULAR
		SELECT @contra = Valor FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular
	END

	WHILE @Min <= @Max
	BEGIN

		SET @SeccionNomina = NULL
		SET @CantidadAlumnos = NULL
		SET @NivelFormativo=NULL
		SET @SeccionNominaCambio = NULL
		SET @SedeCambio = NULL
		SET @CModularCambio=NULL
		SET @PeriodoAcademico=NULL--@7
		SET @TurnoNombre=null--@7

		SELECT	@SeccionNomina = SeccionNomina,
				@CantidadAlumnos = CantidadAlumnos,
				@SeccionNominaCambio = SeccionNominaCambio,
				@SedeCambio = SedeCambio,
				@CModularCambio = CModularCambio,
				@NivelFormativo = NivelFormativo
				--,@PeriodoAcademico = PeriodoAcademico,--@7--@8
				--@TurnoNombre = Turno--@7--@8
		FROM @Table
		WHERE Id = @Min
		
		IF @SeccionNominaCambio = '' SET @SeccionNominaCambio = NULL		
		IF @SedeCambio = '' SET @SedeCambio= NULL
		IF @CModularCambio = '' SET @CModularCambio = NULL
		
		--@8 Inicio
		insert into @tablaJson
		SELECT DISTINCT top 1 'MA',
		ISNULL( PE.Codigo,''),
		 ISNULL(@CModularCambio,ISNULL(PUA.Valor10,'')),
		 ISNULL(@SedeCambio,ISNULL(S.Nombre,'')),
		 ISNULL (PUA.Valor4,''),
		 ISNULL ( PRO.ProductoNombreCorto,'') ,
		ISNULL (C.NombrePlanEstudio ,''),
		CASE ACN.IdModulo WHEN 1 THEN 'I'ELSE '' END+
		CASE ACN.IdModulo WHEN 2 THEN 'II'ELSE '' END+
		CASE ACN.IdModulo WHEN 3 THEN 'III'ELSE ''END+
		CASE ACN.IdModulo WHEN 4 THEN 'IV'ELSE ''END+
		CASE ACN.IdModulo WHEN 5 THEN 'V'ELSE ''END+
		CASE ACN.IdModulo WHEN 6 THEN 'VI'ELSE ''END+
		CASE ACN.IdModulo WHEN 7 THEN 'VII'ELSE ''END+
		CASE ACN.IdModulo WHEN 8 THEN 'VIII'ELSE ''END
		,CASE ACN.Turno -- @13
		WHEN 'DIURNA' THEN 'MA�ANA'
		WHEN 'DIURNO' THEN 'MA�ANA'
		WHEN 'NOCTURNO' THEN 'NOCHE'
		ELSE ISNULL (ACN.Turno,'') END
		--CASE ACN.Turno  WHEN 'MADRUGADOR' THEN 'MA�ANA'
		--WHEN 'DIURNO' THEN 'MA�ANA'
		--WHEN 'NOCTURNO' THEN 'NOCHE'
		--ELSE 'MA�ANA' END
		, ISNULL(@SeccionNominaCambio,ISNULL(ACN.SeccionNomina,''))
		--,'cantidad_alumno'= COUNT(DISTINCT ACN.IdActor)
		, @CantidadAlumnos
		,JSON_QUERY((SELECT DISTINCT
				'tipo_documento'= CASE A.IdDocumentoTipo  WHEN 25 THEN 'D.N.I.'
				WHEN 27 THEN 'CARNET DE EXTRANJER�A'
				WHEN 30765 THEN 'PASAPORTE'
				ELSE 'PTP' END,
				'numero_documento'= ISNULL (A.NumeroIdentidad,''),
				'nombre_completo'= ISNULL (A.NombreCompleto,''),
				'sexo'=CASE A.Genero WHEN 1 THEN 'MASCULINO'ELSE 'FEMENINO' END,
				DATEDIFF(YEAR, a.FechaNacimiento, GETDATE()) AS edad,
				'tiene_discapacidad'= CONVERT(bit,0),
				'unidad_didactica' = JSON_QUERY((
����������������������������������� SELECT 'nombre_unidad_didactica'=
									CASE 
									when ISNULL(AC.IdCursoOriginal,'') = '' then C.CursoNombre
									else
									CO.CursoNombre
									END,
									--CONVERT(DECIMAL(10,2),CONVERT(money,REPLACE(ISNULL(AC.PromedioFinal,0.00),'DPI',0.00))) as  'nota'�
									NULL as  'nota'--@6
������������						FROM AlumnoCursoNomina ACN3 WITH (NOLOCK)
									INNER JOIN AlumnoCurso AC WITH (NOLOCK)ON ACN3.IdMatricula = AC.IdMatricula AND ACN3.IdCurso = ISNULL(AC.IdCursoOriginal,AC.IdCurso)
									INNER JOIN Curso C WITH (NOLOCK)ON AC.IdCurso = C.IdcURSO
									left join Curso CO WITH(NOLOCK) ON AC.IdCursoOriginal = CO.IdCurso
									INNER JOIN Actor A2 WITH (NOLOCK)ON AC.IdAlumno = A2.IdActor
									WHERE ACN3.SeccionNomina = ACN.SeccionNomina AND A2.NumeroIdentidad =A.NumeroIdentidad							
����������������������������������� FOR JSON PATH,INCLUDE_NULL_VALUES))
				FROM CurriculaCurso CC WITH(NOLOCK)     
				INNER join AlumnoCursoNomina ACN2 WITH(NOLOCK)     
				ON ACN2.IdCurso = cc.IdCurso  
				AND ACN2.IdCurricula=cc.IdCurricula AND ACN.SeccionNomina = ACN2.SeccionNomina
				INNER JOIN Actor A WITH(NOLOCK)       
				ON ACN2.IdActor=A.IdActor   
				INNER JOIN Alumno AL WITH(NOLOCK)  
				ON A.IdActor=AL.IdAlumno
				INNER JOIN Producto PRO WITH (NOLOCK) 
				ON ACN2.IdProducto=PRO.IdProducto  
				INNER JOIN Periodo PE  WITH (NOLOCK) 
				ON ACN2.IdPeriodo=PE.IdPeriodo 
				INNER JOIN Matricula M WITH(NOLOCK)
				ON ACN2.IdMatricula = M.IdMatricula 
				INNER JOIN Promocion P WITH (NOLOCK)ON M.IdPromocion = P.IdPromocion
				INNER JOIN ParametroUnidadAcademica PUA WITH(NOLOCK)
				ON  PUA.IdUnidadNegocio= P.IdUnidadNegocio
				AND PUA.IdUnidadAcademica = P.IdUnidadAcademica
				AND	PUA.IdSede=P.IdSede
				AND PUA.Nombre='ParametroNomina1' 					
				AND PUA.IdProducto=P.IdProducto
				WHERE ACN2.IdSede = @IdSede
				AND PUA.IdEmpresa= @IdEmpresa
				AND PUA.IdFacultad = @IdFacultad
				AND ACN2.IdPeriodo = @IdPeriodo
				--AND ACN2.IdProducto = @IdProducto
				AND (ACN2.IdProducto=@IdProducto OR @IdProducto= 0)--@2 
				AND PUA.IdUnidadNegocio = @IdUnidadNegocio
				AND M.NumeroMatricula IS NULL--@10
				GROUP BY A.NumeroIdentidad,A.NombreCompleto,A.Genero,a.FechaNacimiento,A.IdDocumentoTipo FOR JSON PATH)) as persona
		FROM AlumnoCursoNomina ACN WITH (NOLOCK)
		INNER JOIN Producto PRO WITH (NOLOCK) 
		ON ACN.IdProducto=PRO.IdProducto  
		INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) 
		ON pro.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro
		INNER JOIN Actor A WITH(NOLOCK)       
		ON ACN.IdActor=A.IdActor
		INNER JOIN Periodo PE  WITH (NOLOCK) 
		ON ACN.IdPeriodo=PE.IdPeriodo  
		INNER JOIN Curricula C WITH(NOLOCK)
		ON ACN.IdCurricula = C.IdCurricula
		INNER JOIN Matricula M WITH(NOLOCK)
		ON ACN.IdMatricula = M.IdMatricula 
		INNER JOIN Promocion P WITH (NOLOCK)ON M.IdPromocion = P.IdPromocion
		INNER JOIN Sede S WITH(NOLOCK)
		ON ACN.IdSede = S.IdSede
		INNER JOIN ParametroUnidadAcademica PUA WITH(NOLOCK)
		ON  PUA.IdUnidadNegocio=P.IdUnidadNegocio
		AND PUA.IdUnidadAcademica = P.IdUnidadAcademica 
		AND PUA.IdSede=P.IdSede
		AND PUA.Nombre='ParametroNomina1' 
		AND PUA.IdProducto=P.IdProducto
		WHERE ACN.IdEmpresa=@IdEmpresa
		AND ACN.IdSede=@IdSede
		AND ACN.IdPeriodo=@IdPeriodo          
		AND (ACN.IdProducto=@IdProducto OR @IdProducto= 0)   --@2        
		AND (( MTR_PRO.Disponible1='C' AND  MTR_PRO.Disponible2='CAR' ) OR MTR_PRO.Disponible1='P' )
		AND PE.IdUnidadNegocio IN (@IdUnidadNegocio) AND ACN.SeccionNomina = @SeccionNomina
		AND M.NumeroMatricula IS NULL--@10
		GROUP BY  PE.Codigo,PUA.Valor10,S.Nombre,PUA.Valor4, PRO.ProductoNombreCorto,C.Nombre,ACN.IdModulo,ACN.Turno,ACN.SeccionNomina,C.NombrePlanEstudio

		select @TurnoNombre= turno,@PeriodoAcademico = semestreAcademico + ' Semestre' from @tablaJson
		--@8 Fin

		INSERT INTO @JSON
		SELECT @usuario AS Usuario,ISNULL(@contra,'') AS Contra,ISNULL(@SeccionNominaCambio,@SeccionNomina) AS Seccion,@CantidadAlumnos AS CantidadAlumnos,ISNULL(@CModularCambio,@cmodular)AS CodigoModular,@NivelFormativo AS NivelFormativo,--alsanchez
		(select 'tipo_acta'=tipoActa,
		'nombre_periodo_lectivo'=nombrePeriodoLectivo,
		'codigo_modular' =codigoModular,
		'nombre_sede_institucion'= nombreSedeInstitucion,
		'nivel_formacion'= nivelFormacion,
		'nombre_carrera' =nombreCarrera,
		'nombre_plan_estudio' = nombrePlanEstudio,
		'semestre_academico'= semestreAcademico ,
		'turno'=turno,
		'seccion' = seccion ,
		'cantidad_alumno'= cantidadAlumno,
		'persona'=JSON_QUERY(persona) from @tablaJson FOR JSON PATH ) AS cadenaJson,--@8
		@PeriodoAcademico,--@7
		@TurnoNombre--@7

		delete from @tablaJson

		SET @Min = @Min + 1
	END
	
END
UPDATE AlumnoCursoNominaLogMinedu SET EsUltimo=0 WHERE SeccionMinedu in (Select Seccion from @JSON) AND TipoProceso=@TipoProceso AND IdSede = @IdSede--@1 --@10
INSERT INTO AlumnoCursoNominaLogMinedu (TipoProceso,SeccionMinedu,CantidadAlumnos,FechaCreacion,CadenaJson,Estado,EsUltimo,PeriodoAcademico,Turno,IdSede)--@1 --@7--@10
SELECT @TipoProceso,Seccion,CantidadAlumnos,GETDATE(),cadenaJson,'PE',1,PeriodoAcademico,Turno,@IdSede FROM @JSON--@1 --@7--@10

SELECT * FROM @JSON J
SET NOCOUNT OFF 
