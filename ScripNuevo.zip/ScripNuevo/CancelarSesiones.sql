DECLARE @Sesiones_Feriado TABLE(
	id int identity(1,1),
	idseccion int,
	idhorario int,
	idsesion int,
	fecha date,
	Version_ int, ---buscar de donde sale
	idfacilitador int,
	Observacion varchar(255)
)

DECLARE @IdMotivo int,
		@Observacion_hs varchar(255),
		@Usuario int,
		@min int,
		@max int,
		@idseccion int,
		@idhorario int,
		@idsesion int,
		@fecha date,
		@Version_ int,
		@Observacion varchar(255),
		@estado int,
		@asistencia int,
		@docente varchar(50),
		@IdPostergado int

SET @IdMotivo=784 --- RECUPERACION
SET @Observacion_hs = 'CANCELACION DE SESIONES 2024-IIIB - mtoledoq tkt 69116'
SET @Usuario = 1

INSERT INTO @Sesiones_Feriado
select distinct hs.Idseccion, hs.IdHorario,hs.idsesion,hs.fecha,CONVERT(BIGINT, HS.Version),ISNULL(hs.IdActorProgramado,hs.IdActorReemplazo),null
from horariosesion hs
inner join feriado f on hs.Fecha = f.Fecha
inner join seccion s on hs.IdSeccion=s.Idseccion
inner join promocion p on s.IdPromocion=p.IdPromocion --and f.IdUnidadNegocio=p.IdUnidadNegocio and f.IdUnidadAcademica =p.IdUnidadAcademica
inner join periodo pe on p.IdPeriodo=pe.IdPeriodo
--inner join facilitador fa on hs.IdActorProgramado = fa.IdFacilitador
where	convert(varchar,hs.fecha,112) in ('20241209') 
and pe.Codigo in ('2024-IIIB')	--p.PromocionCodigo like in ('%2024-IIA') 
and hs.Estado='P'	-- P = PROGRAMADO / A = ANULADO / X = CANCELADO		--order by hs.fecha,hs.idseccion

--select * from @Sesiones_Feriado  ----141
--return

select @min=min(id), @max = max(id) from @Sesiones_Feriado
--select @min, @max
WHILE @min <= @max
BEGIN

	SET @idseccion = NULL
	SET @idhorario = NULL
	SET @idsesion = NULL
	SET @fecha = NULL
	SET @Version_ = NULL
	SET @Observacion = NULL
	SET @estado = NULL
	SET @asistencia = 0
	SET @IdPostergado = NULL
	
	SELECT @Version_ = CONVERT(BIGINT, HS.Version) FROM @Sesiones_Feriado SF 
	INNER JOIN HORARIOSESION HS ON  SF.IDSECCION = HS.IdSeccion AND SF.idhorario =HS.IdHorario AND SF.idsesion =HS.IdSesion 
									AND CONVERT(VARCHAR,SF.fecha,112) = CONVERT(VARCHAR,HS.Fecha,112)
	WHERE SF.id=@min

	select @idseccion = idseccion, @idhorario = idhorario, @idsesion = idsesion, @fecha = fecha
	from @Sesiones_Feriado 
	where id = @min

	-- Valida el estado del registro
	exec cHorarioSesion_Val_Registro @IdSeccion=@idseccion, @IdHorario=@idhorario, @IdSesion=@idsesion, @Version=@Version_, @RetVal=@estado output
	--select @estado
	
	IF @estado=0
	BEGIN
		---- Valida el estado de la sesion (ASISTI� DOCENTE, ALUMNOS MARCARON ASISTENCIA )
		exec cHorarioSesion_Val_IdSesion @IdSeccion=@idseccion, @IdHorario=@idhorario, @IdSesion=@idsesion, @RetVal=@asistencia output
		--select @asistencia
		
		IF @asistencia =  0
		BEGIN
			---- Crea Registro en la tabla HorarioPostergado
			exec cHorarioPostergado_Ins_Grabar @IdSeccion=@idseccion, @IdHorario=@idhorario, @IdSesion=@idsesion, @IdMotivo=@IdMotivo,
											   @Observacion=@Observacion_hs, @Estado=N'P', @UsuarioCreacion=@Usuario,
											   @RetVal=@IdPostergado output
			--select @IdPostergado
			
			IF @IdPostergado != NULL
			BEGIN
				SET @Observacion='Se agreg� a HorarioPostergado'
			END
			ELSE
			BEGIN
				SET @Observacion='No se puede cancelar Sesion - HorarioPostergado NULL'
			END
			---- Actualiza el estado de la Sesion a cancelar
			exec cHorarioSesion_Upd_Actualizar @IdSeccion=@idseccion,@IdHorario=@idhorario,@IdSesion=@idsesion,@IdActividad=NULL,@IdActividadFacilitador=NULL,@IdMovimiento=NULL,
			@IdPostergado=NULL,@Numero=NULL,@Dia=NULL,@Fecha=NULL,@Tema=NULL,@Cantidad=NULL,@Inicio=NULL,@Fin=NULL,@IdActorProgramado=NULL,@InicioReal=NULL,@FinReal=NULL,
			@IdActorReemplazo=NULL,@IdSeparacion=NULL,@EsSeparacion=NULL,@IdDuracion=NULL,@IdAmbiente=NULL,@EsExamen=NULL,@EsRemunerado=NULL,@EsPostergado=1,@EsMovimiento=NULL,
			@EsWeb=NULL,@Observacion=@Observacion_hs,@EstadoDiario=NULL,@Estado='X',@UsuarioModificacion=@Usuario,@UsuarioAsistencia=NULL,@UsuarioAsistenciaModificacion=NULL,
			@TipoAsistencia=NULL,@IpAsistencia=NULL,@UsuarioJustificaCreacion=NULL,@UsuarioJustificaModificacion=NULL,@JustificacionObservacion=NULL,@IdJustificacion=NULL
			
			---- Actualiza el numero de Sesiones de la Seccion
			exec cHorarioSesion_Upd_SesionNumero @IdSeccion=@idseccion
			
			SET @Observacion='Sesion Cancelada correctamente'

		END
		ELSE
		BEGIN
			SET @Observacion=concat('No se puede cancelar Sesion - cHorarioSesion_Val_IdSesion:',CASE @asistencia 
																								 WHEN 1 THEN 'Es movimiento' 
																								 WHEN 2 THEN 'La sesi�n tiene asistencia marcada del docente'
																								 WHEN 4 THEN 'La sesi�n tiene asistencia marcada de algun alumno'
																								 ELSE 'No hay restriccion-validar'
																								 END)
		END
	END
	ELSE
	BEGIN
		SET @Observacion=concat('No se puede cancelar Sesion - cHorarioSesion_Val_IdSesion: ',CASE @estado 
																							  WHEN 1 THEN 'Registro ya no existe' 
																							  WHEN 2 THEN 'Registro ya fue modificado'
																							  WHEN 3 THEN 'Registro ya fue postergado'
																							  WHEN 4 THEN 'Registro ya fue anulado'
																							  WHEN 5 THEN 'Registro ya fue ejecutado'
																							  ELSE 'No hay restriccion-validar'
																							  END)
	END
	
	UPDATE @Sesiones_Feriado SET Observacion= @Observacion WHERE ID=@min
	
	SET @min = @min + 1
END

select S. Nombre 'SEDE', UN.Nombre 'DIVISION', UA.Nombre 'PROGRAMA', P.PromocionNombre 'PROMOCION', 
	   P.PromocionCodigo'PROMO_CODIGO', PG.GrupoCodigo 'GRUPO', SE.Codigo 'SECCION', isnull(f.CodigoAnterior,'') 'FACILITADOR',
	   SF.fecha 'FECHA_SESION',SF.Observacion 'OBSERVACION'
FROM @Sesiones_Feriado SF
INNER JOIN SECCION SE ON SF.idseccion = SE.idseccion
INNER JOIN PromocionGrupo PG ON SE.IdPromocion = PG.IdPromocion AND SE.IdGrupo = PG.IdGrupo
INNER JOIN PROMOCION P ON SE.IdPromocion = P.IdPromocion
INNER JOIN Sede S ON S.IdSede = P.IdSede
INNER JOIN UnidadNegocio UN ON P.IdUnidadNegocio = UN.IdUnidadNegocio
INNER JOIN UnidadAcademica UA ON P.IdUnidadAcademica = UA.IdUnidadAcademica
INNER JOIN Facilitador F ON sf.idfacilitador = f.IdFacilitador
ORDER BY S.Nombre,UN.Nombre,UA.Nombre,P.PromocionNombre
-------