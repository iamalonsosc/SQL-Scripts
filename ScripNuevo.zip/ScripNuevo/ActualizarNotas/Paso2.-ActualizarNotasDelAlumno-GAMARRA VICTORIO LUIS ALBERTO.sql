---GAMARRA VICTORIO LUIS ALBERTO

--MARKETING ESTRAT�GICO II CICLO 
--MARKETING DE SERVICIOS II CICLO 
UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40094,Promediofinal=18, PromedioReal=18, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51944', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1447718 and  idcurricula=5606 and idcurso in (10077,10081)
--(1 row affected)

--INGLES PARA LA COMUNICACION II CICLO 
UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40094,Promediofinal=13, PromedioReal=13, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51944', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1447718 and  idcurricula=5606 and idcurso in (9857)
--(1 row affected)

--INFORM�TICA APLICADA A LOS NEGOCIOS II CICLO 
UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40094,Promediofinal=17, PromedioReal=17, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51944', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1447718 and  idcurricula=5606 and idcurso in (9856)
--(1 row affected)

---FUNDAMENTOS DE CONTABILIDAD I CICLO 

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40094,Promediofinal=17, PromedioReal=17, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51944', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1447718 and  idcurricula=5606 and idcurso in (9818)
--(1 row affected)



DELETE FROM AlumnoCurso where IdAlumno = 1447718 and IdCurricula=5606 
AND IdCurso IN (10077,10081,9857)
--(3 row affected)
