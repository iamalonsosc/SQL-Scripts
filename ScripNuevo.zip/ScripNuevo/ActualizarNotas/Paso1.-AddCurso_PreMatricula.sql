DECLARE @AlumnoCurso AS TABLE (
	id int identity(1,1),
	nombreAlumno varchar(255),
	Curricula varchar(50),
	modulo varchar(6),
	periodo varchar(255),
	idmatricula int,
	observacion varchar(255)
)

DECLARE @Cursos AS TABLE (
	Id INT IDENTITY(1,1),
	IdCurso INT
)
DECLARE @MIN INT, @MAX INT, @ALUMNO VARCHAR(255),@CURRICULA VARCHAR(50), @MODULO VARCHAR(6), @IDMODULO INT, @MIN_CURSO INT, @MAX_CURSO INT, @PERIODO VARCHAR(10),
		@IDACTOR INT, @IDCURRICULA INT, @IDMATRICULA INT, @IDREGISTRO INT, @IDPROMOCION INT, @IDCURSO INT, @IDALUMNOCURSO INT, @IDUSUARIO INT
		

INSERT INTO @AlumnoCurso VALUES('GAMARRA VICTORIO LUIS ALBERTO','0210.01','III','2024-I',null,null)--

SELECT @MIN = MIN(ID),@MAX = MAX(ID) from @AlumnoCurso 

WHILE @MIN<=@MAX
BEGIN
	SET @ALUMNO = NULL
	SET @CURRICULA = NULL
	SET @MODULO = NULL
	SET @IDACTOR = NULL
	SET @IDCURRICULA = NULL
	SET @IDMODULO = NULL
	SET @IDMATRICULA = NULL

	SELECT @ALUMNO = nombreAlumno, @CURRICULA = Curricula, @MODULO = modulo, @PERIODO = periodo FROM @AlumnoCurso WHERE ID=@MIN
	
	SELECT @IDMODULO = Disponible1 FROM MaestroTablaRegistro WHERE Codigo = @MODULO

	SELECT @IDACTOR = M.IdActor, @IDCURRICULA = M.IdCurricula, @IDMATRICULA = M.IdMatricula, @IDREGISTRO = M.IdRegistro, @IDPROMOCION = M.IdPromocion,
		   @IDUSUARIO = M.UsuarioCreacion
	FROM Matricula M
	INNER JOIN Curricula C ON M.IdCurricula = C.IdCurricula 
	INNER JOIN Actor A ON M.IdActor = A.IdActor 
	INNER JOIN PROMOCION P ON M.IdPromocion = P.IdPromocion
	INNER JOIN PERIODO PE ON P.IdPeriodo = PE.IdPeriodo
	WHERE A.NombreCompleto = @ALUMNO AND C.Codigo = @CURRICULA AND M.Estado = 'N' AND PE.Codigo = @PERIODO
	
	UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL,Promediofinal=NULL, PromedioReal=NULL, PromedioCondicion=NULL,TipoCondicion='RE', 
									Glosa='Desde cAlumnoCurriculaCurso_Ins_Grabar', UsuarioModificacion=1,FechaModificacion=NULL, Subsanacion=0
	WHERE idalumno=@IDACTOR and  idcurricula=@IDCURRICULA and IdModulo >= @IDMODULO

	INSERT INTO @CURSOS  
	SELECT DISTINCT ACC.IdCurso FROM Matricula M
	INNER JOIN AlumnoCurriculaCurso ACC ON M.IdActor = ACC.IdAlumno AND M.IdCurricula = ACC.IdCurricula --AND ACC.IdModulo = @IDMODULO
	LEFT JOIN AlumnoCurso AC ON M.IdMatricula = AC.IdMatricula AND M.IdCurricula = AC.IdCurricula AND ACC.IdCurso = AC.IdCurso
	WHERE M.IdActor = @IDACTOR AND ACC.IdCurricula = @IDCURRICULA AND ACC.IdModulo = @IDMODULO  AND AC.IdCurso IS NULL 

	SELECT @MIN_CURSO = MIN(ID), @MAX_CURSO = MAX(ID) FROM @CURSOS

	WHILE @MIN_CURSO <= @MAX_CURSO
	BEGIN
		print @min_curso
		SET @IDCURSO = NULL
		SET @IDALUMNOCURSO = NULL

		SELECT @IDCURSO = IdCurso FROM @Cursos WHERE ID=@MIN_CURSO

		SELECT @IDALUMNOCURSO = MAX(IDALUMNOCURSO+1) FROM AlumnoCurso WHERE IdAlumno = @IDACTOR AND IdCurricula = @IDCURRICULA 

		IF NOT EXISTS (	SELECT DISTINCT 1 FROM AlumnoCurso WHERE IdAlumno = @IDACTOR AND IdCurricula = @IDCURRICULA AND IdCurso = @IDCURSO)
		BEGIN
			INSERT INTO AlumnoCurso (IdAlumno,IdRegistro,IdAlumnoCurso,IdCurricula,IdCurso,IdMatricula,IdPromocion,EsMatricula,TipoCondicion,UsuarioCreacion,
								 FechaCreacion,UsuarioModificacion, FechaModificacion,estado,NumVezCurso) 
			VALUES(@IDACTOR,@IDREGISTRO,@IDALUMNOCURSO,@IDCURRICULA,@IDCURSO,@IDMATRICULA,@IDPROMOCION,0,'CC',@IDUSUARIO,GETDATE(),@IDUSUARIO,GETDATE(),'NO',1)
		END
		
		SET @MIN_CURSO = @MIN_CURSO + 1

	END

	SET @MIN = @MIN+1
END