--����������������������������������������������������������������������������  
--Creado por	 : 
--Funcionalidad  : 
--Utilizado por  : 
--���������������������������������������������������������������������������� 
/*
-----------------------------------------------------------------------------
Nro		FECHA			USUARIO					DESCRIPCION
-----------------------------------------------------------------------------
@1		22/06/2018		KROJASR					Matr�cula por Empresa    
@2		25/06/2018		HMORA   Validacion		Matr�cula por Empresa
@3		11.01.2018		Eloy Alva (Sigcomt)		Agregar parametro CompaniaSocio.   
@4		7/09/2020		HMORA					Validaci�n para cuando el producto no tenga matricula  
@5		01/05/2024		FETORRES				Se agrega logica para que CA tome la compania socio de ZEGEL. 
@6		23/10/2024		MQUIROZ					Se agrega validacion por companiasocio	
@7		26/09/2025		JQuenta					Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil
*/

ALTER FUNCTION [dbo].[cMatricula_Val_Pago_Cuota]
(
	@IdMatricula INT,    
	@CompaniaSocio CHAR(8) --@3
)
RETURNS INT
AS --@7
BEGIN

	--Inicio --@7
	DECLARE @IdPagante INT,
	@RetVal INT,
	@IdProcedencia INT,
	@Cont INT,
	@IdMatriculaEmpresa INT,
	@Mixto INT,  
	@TieneMatricula INT --@4     

	SET @Cont = 0

	SELECT
		@IdPagante = IdActor
	FROM MatriculaPagante WITH (NOLOCK)
	WHERE IdMatricula = @IdMatricula     
   
	--@4  
	SELECT
		@TieneMatricula = ISNULL(PR.TieneMatricula,1)
	FROM Matricula M WITH (NOLOCK) --@7
	INNER JOIN Promocion P WITH (NOLOCK) ON P.IdPromocion = M.IdPromocion --@7
	INNER join Producto PR WITH (NOLOCK) ON PR.IdProducto = P.IdProducto --@7
	WHERE M.IdMatricula = @IdMatricula     
	--@4  

	IF @CompaniaSocio = '00002600' OR @CompaniaSocio = '00002400' --@5 --@6
	BEGIN

		SELECT
			@CompaniaSocio = COMPANIASOCIOPADRE
		FROM Empresa WITH (NOLOCK) --@7
		WHERE IdEmpresa = 1 --@7

	END    
	BEGIN

		--Validamos por cada uno si pago la primera cuota
		SELECT
			@Cont = COUNT(1)
		FROM PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header WITH (NOLOCK)
		WHERE IdMatricula = @IdMatricula
		AND @IdPagante =
		(
			CASE
				WHEN ClienteCobrarA = '' THEN Cliente
				WHEN ClienteCobrarA IS NULL THEN Cliente
				ELSE ClienteCobrarA
			END
		)
		AND Estado IN ('CO','FA') 
		AND FlagActualizacion =
		(
			CASE
				WHEN @TieneMatricula = 1 THEN 'N'   
				WHEN @TieneMatricula = 0 AND CondicionPago = 'C' THEN 'N'   
				ELSE 'M'
			END
		)     
		AND CompaniaSocio = @CompaniaSocio --@3    

		IF @Cont = 0
		BEGIN

			SET @RetVal = 0

		END
		ELSE
		BEGIN

			SET @RetVal = 1

		END

	END
    
	--@1 Inicio
	--@2
	IF EXISTS
	(
		SELECT
			IdMatriculaEmpresa
		FROM Matricula WITH (NOLOCK) --@7
		WHERE IdMatricula = @IdMatricula
		AND IdMatriculaEmpresa IS NOT NULL
	)
	--@2
	BEGIN

		SELECT
			@IdMatriculaEmpresa = IdMatriculaEmpresa
		FROM Matricula WITH (NOLOCK) --@7
		WHERE IdMatricula =  @IdMatricula

		SELECT
			@IdPagante = IdEntidad
		FROM MatriculaEmpresa WITH (NOLOCK)
		WHERE IdMatriculaEmpresa = @IdMatriculaEmpresa

		SELECT
			@Cont = COUNT(1)
		FROM PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header WITH (NOLOCK)
		WHERE IdMatricula = @IdMatriculaEmpresa
		AND @IdPagante =
		(
			CASE
				WHEN ClienteCobrarA = '' THEN Cliente
				WHEN ClienteCobrarA IS NULL THEN Cliente
				ELSE ClienteCobrarA
			END
		)
		AND Estado IN ('CO','FA')
		AND FlagActualizacion = 'N'
		AND CompaniaSocio = @CompaniaSocio --@3

		IF @Cont = 0    
		BEGIN

			SET @RetVal = 0

		END    
		ELSE
		BEGIN

			SET @RetVal = 1

		END

	END
	--@1 Fin
    
	IF @RetVal = 0
	BEGIN

		SELECT
			@IdProcedencia = ISNULL(IdProcedencia, 0)
		FROM Matricula WITH (NOLOCK)
		WHERE IdMatricula = @IdMatricula
     
		IF @IdProcedencia = 1
		BEGIN

			SET @RetVal = 1

		END
		ELSE
		BEGIN

			SET @RetVal = 0

		END

	END   
     
	RETURN  @RetVal
	--Fin --@7

END

