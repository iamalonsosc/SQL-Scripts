--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET NumVezCurso=1
WHERE NumVezCurso=2 AND IdCurricula=313 AND IdMatricula=260022677 AND IdCurso IN (1607)
--(1 row affected)