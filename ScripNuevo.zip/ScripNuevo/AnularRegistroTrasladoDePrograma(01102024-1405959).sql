--SELECT*FROM Registro
UPDATE Registro SET Estado='X'
WHERE IdActor=1405959
AND IdRegistro=4
--(1 row affected)