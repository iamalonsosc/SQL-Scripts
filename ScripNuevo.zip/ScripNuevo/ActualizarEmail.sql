SELECT   
    --AC.IdActor,
    --AC.NombreCompleto,
    --ACE.Descripcion,
    EC.*
FROM EnvioCorreo EC
INNER JOIN AcademicoIDAT..Matricula MA ON MA.IdMatricula = EC.IdMatricula
INNER JOIN AcademicoIDAT..Promocion PRO ON MA.IdPromocion = PRO.IdPromocion
INNER JOIN AcademicoIDAT..periodo PE ON PE.IDPERIODO = PRO.IDPERIODO
INNER JOIN AcademicoIDAT..PromocionGrupo PG ON PRO.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo
INNER JOIN AcademicoIDAT..Actor AC ON MA.IdActor = AC.IdActor
---INNER JOIN AcademicoIDAT..ActorEmail ACE ON AC.IdActor = ACE.IdActor
WHERE Asunto LIKE 'BIENVENIDO%' 
AND EC.IdMatricula IN (691676
,690971
,690504
,689378
,689065
,688911
,688613
,686699
,688006
,687724
,687694
,687010
,687151
,686938
,686572
,685138
,683850
,683241
,683244
,682103
,681678
,681303
,680316
,675931
,659853
,657181
)
--AND EC.Estado IN (-1) 
--AND EC.IdMatricula=691676
AND PE.Codigo IN ('2025-02','2025-03','2025-IIA')

ORDER BY FechaEnvio DESC;

--UPDATE EC
--SET EC.Enviado = ACE.Descripcion
--FROM EnvioCorreo EC
--INNER JOIN AcademicoIDAT..Matricula MA ON MA.IdMatricula = EC.IdMatricula
--INNER JOIN AcademicoIDAT..Promocion PRO ON MA.IdPromocion = PRO.IdPromocion
--INNER JOIN AcademicoIDAT..periodo PE ON PE.IDPERIODO = PRO.IDPERIODO
--INNER JOIN AcademicoIDAT..PromocionGrupo PG ON PRO.IdPromocion = PG.IdPromocion 
--    AND MA.IdGrupo = PG.IdGrupo
--INNER JOIN AcademicoIDAT..Actor AC ON MA.IdActor = AC.IdActor
--INNER JOIN AcademicoIDAT..ActorEmail ACE ON AC.IdActor = ACE.IdActor
--WHERE Asunto LIKE 'BIENVENIDO%' 
--AND EC.Estado IN (-1) 
--AND PE.Codigo IN ('2025-02','2025-03','2025-IIA')
--AND ACE.IdEmail = (
--    SELECT TOP 1 IdEmail
--    FROM AcademicoIDAT..ActorEmail 
--    WHERE IdActor = ACE.IdActor 
--    AND Descripcion <> '' 
--	ORDER BY IdEmail DESC);
----(26 rows affected)