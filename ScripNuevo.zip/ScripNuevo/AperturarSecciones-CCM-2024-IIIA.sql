update a set a.Estado='A',a.FechaModificacion=GETDATE() 
--SELECT B.IdUnidadAcademica,B.PromocionCodigo, *
from Seccion a 
inner join Promocion b on a.IdPromocion=b.IdPromocion 
inner join Periodo c on b.IdPeriodo=c.IdPeriodo
where c.Codigo IN ('2024-IIIA')  
AND a.Estado='F' 
AND B.IdUnidadAcademica=60
--(149 rows affected)