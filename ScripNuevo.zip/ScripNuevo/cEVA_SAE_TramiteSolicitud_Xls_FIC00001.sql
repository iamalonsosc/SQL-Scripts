--����������������������������������������������������������������������������                                                      
--Creado por      :Israel L�pez (25/05/2022)                                              
--Funcionalidad   :Recupera informaci�n de la EVA_SAE_TramiteSolicitud                                              
--Utilizado por   :           
--����������������������������������������������������������������������������             
/*                        
-----------------------------------------------------------------------------                        
Nro	FECHA		USUARIO	DESCRIPCION                        
-----------------------------------------------------------------------------     
@1	29.02.24	scaycho	Se cambia la forma de obtener el SLA del tramite
@2  13.03.24	MQUIROZ Se agrega nuevo campo SEDE y join al Reporte
@3  15.04.24	Alsanchez Se cambia la cantidad de datos en la variable
Ejemplo:

EXEC [cEVA_SAE_TramiteSolicitud_Xls_FIC00001] -1, '', '', '20240101', '20240229'
*/
ALTER PROCEDURE [dbo].[cEVA_SAE_TramiteSolicitud_Xls_FIC00001]
    @IdAlumno INT,                        -- TODOS=-1  
    @CodigoPublico VARCHAR(20),           -- TODOS=''  
    @Estado VARCHAR(20),                  ---- TODOS=''  
    @FechaCreacionTramiteIni VARCHAR(20), --formato YYYYMMDD / TODOS=''  
    @FechaCreacionTramiteFin VARCHAR(20)  --formato YYYYMMDD / TODOS=''  
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CurID INT,
            @MaxID INT,
            @SLA VARCHAR(20),
            @EsAutomatico BIT,
            @DetalleEstado VARCHAR(60),--@3
            @DiasAtencionTramite VARCHAR(20),
            @FechaCreacionTramite DATETIME,
            @FechaUltimaAtencion DATETIME

    DECLARE @TramiteSolicitud AS TABLE
    (
        Id INT IDENTITY,
        IdTramiteSolicitud INT,
        AlumnoCodigo VARCHAR(200),
        AlumnoNombreCompleto VARCHAR(200),
        SolicitudCodigo VARCHAR(20),
        SolicitudNombre VARCHAR(200),
        TieneCosto BIT,
        EsAutomatico BIT,
        EsAnulado BIT,
        EstadoSolicitud VARCHAR(20),
        DetalleEstado VARCHAR(60),--@3
        UltimoEstadoRespuesta VARCHAR(200),
        FechaCreacionTramite DATETIME,
        UsuarioCreacionTramite VARCHAR(200),
        UsuarioAtencionTramite VARCHAR(200),
        FechaUltimaAtencion DATETIME,
        DiasAtencionTramite VARCHAR(20),
        SLA VARCHAR(200),
        CodigoPublico VARCHAR(200),
		Sede Varchar(200)--@2
    )

    INSERT INTO @TramiteSolicitud
    SELECT DISTINCT
        TS.IdTramiteSolicitud,
        AL.CodigoAnterior,
        'Alumno' = A.NombreCompleto,
        T.CodigoPublico,
        T.Nombre,
        T.TieneCosto,
        T.EsAutomatico,
        TS.EsAnulado,
        'EstadoSolicitud' = ISNULL(TS.EstadoSolicitud, ''),             --(PGA = En Proceso Gestion Administrativa, FIN = FIN)  
        'DetalleEstado' = TES.NombreEstado,
        'UltimoEstadoRespuesta' = ISNULL(TS.UltimoEstadoRespuesta, ''), -- (REC = Rechazado, APR = Aprobado, OBS = Observado, RES= Respuesta del Solicitante )   
        'FechaCreacionTramite' = TS.FechaCreacion,
        'UsuarioCreacionTramite' = ISNULL(US.Nombre, ''),
        'UsuarioAtencionTramite' = ISNULL(AT2.NombreCompleto, ''),
        'FechaUltimaAtencion' = TSHE.FechaCreacion,
        'DiasAtencionTramite' = ISNULL(dbo.[EVA_FN_SlaTramite](TS.IdTramite, TS.IdMarca), ''), --@1
        'SLA' = '',
        'CodigoPublico' = ISNULL(C.CodigoPublico, ''),
		'Sede' = S.Nombre--@2
    FROM EVA_SAE_TramiteSolicitud TS WITH (NOLOCK)
		inner join Sede S WITH (NOLOCK)--@2
			ON TS.IdSede = S.IdSede --@2
        INNER JOIN Actor A WITH (NOLOCK)
            ON A.IdActor = TS.IdActorSolicitante
        INNER JOIN Alumno AL WITH (NOLOCK)
            ON A.IdActor = AL.IdAlumno
        INNER JOIN EVA_SAE_Tramite T WITH (NOLOCK)
            ON T.IdTramite = TS.IdTramite
        INNER JOIN EVA_SAE_TramiteSolicitudHistorialEstados TSHE WITH (NOLOCK)
            ON TSHE.IdTramiteSolicitud = TS.IdTramiteSolicitud
               and TSHE.IdEstado = TS.IdEstado
        INNER JOIN EVA_SAE_TramiteEstados TES WITH (NOLOCK)
            ON TSHE.IdEstado = TES.IdEstado
        LEFT JOIN EVA_SAE_Constancias C WITH (NOLOCK)
            ON C.IdTramiteSolicitud = TS.IdTramiteSolicitud
        LEFT JOIN Usuario US WITH (NOLOCK)
            ON TS.UsuarioCreacion = US.IdUsuario
        LEFT JOIN EVA_SAE_TramiteSolicitudRespuesta TSR WITH (NOLOCK)
            ON TS.IdTramiteSolicitud = TSR.IdTramiteSolicitud
               AND TSR.TipoParticipante = 'ENC'
        LEFT JOIN Actor AT2 WITH (NOLOCK)
            ON TSR.IdActor = AT2.IdActor
    WHERE (
              TS.IdActorSolicitante = @IdAlumno
              OR @IdAlumno = -1
          )
          AND (
                  T.CodigoPublico = @CodigoPublico
                  OR ISNULL(@CodigoPublico, '') = ''
              )
          AND (
                  TES.NombreEstado = @Estado
                  OR ISNULL(@Estado, '') = ''
              )
          AND (
                  CONVERT(VARCHAR, TS.FechaCreacion, 112)
          BETWEEN @FechaCreacionTramiteIni AND @FechaCreacionTramiteFin
                  OR ISNULL(@FechaCreacionTramiteIni, '') = ''
              )
    ORDER BY ts.IdTramiteSolicitud

    SELECT @CurID = Min(Id),
           @MaxID = Max(Id)
    FROM @TramiteSolicitud
    WHILE @MaxID >= @CurID
    BEGIN
        SELECT @EsAutomatico = EsAutomatico,
               @DetalleEstado = DetalleEstado,
               @FechaUltimaAtencion = FechaUltimaAtencion,
               @FechaCreacionTramite = FechaCreacionTramite
        FROM @TramiteSolicitud
        WHERE Id = @CurID

        SELECT @SLA
            = CASE @EsAutomatico
                  WHEN 0 THEN
                      CASE
                          WHEN @DetalleEstado IN ( 'En proceso', 'Resuelto' ) THEN
                              ISNULL(CONVERT(VARCHAR, DATEDIFF(DAY, @FechaCreacionTramite, @FechaUltimaAtencion)), '')
                          ELSE
                              @DetalleEstado
                      END
                  ELSE
                      'No Aplica'
              END

        UPDATE @TramiteSolicitud
        SET SLA = @SLA
        WHERE Id = @CurID

        SET @CurID = @CurID + 1
    END

    SELECT IdTramiteSolicitud,
           AlumnoCodigo,
           AlumnoNombreCompleto,
           SolicitudCodigo,
           SolicitudNombre,
           CASE TieneCosto
               WHEN 1 THEN
                   'SI'
               ELSE
                   'NO'
           END As TieneCosto,
           CASE EsAutomatico
               WHEN 1 THEN
                   'SI'
               ELSE
                   'NO'
           END As EsAutomatico,
           CASE EsAnulado
               WHEN 1 THEN
                   'SI'
               ELSE
                   'NO'
           END As EsAnulado,
           EstadoSolicitud,
           DetalleEstado,
           UltimoEstadoRespuesta,
           'FechaCreacionTramite' = ISNULL(CONVERT(VARCHAR, FechaCreacionTramite, 103), ''),
           'HoraCreacionTramite' = ISNULL(SUBSTRING(CONVERT(VARCHAR, FechaCreacionTramite, 108), 1, 5), ''),
           UsuarioCreacionTramite,
           UsuarioAtencionTramite,
           'FechaUltimaAtencion' = ISNULL(CONVERT(VARCHAR, FechaUltimaAtencion, 103), ''),
           'HoraUltimaAtencion' = ISNULL(SUBSTRING(CONVERT(VARCHAR, FechaUltimaAtencion, 108), 1, 5), ''),
           DiasAtencionTramite,
           SLA,
           CodigoPublico,
		   Sede--@2
    FROM @TramiteSolicitud

    SET NOCOUNT OFF;
END
