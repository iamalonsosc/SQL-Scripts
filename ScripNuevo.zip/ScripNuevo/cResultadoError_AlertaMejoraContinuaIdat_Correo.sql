--����������������������������������������������������������������������������                              
--Creado por      :Alsanchez(30/06/2023)                              
--Funcionalidad   : 
--Utilizado por   : 
--����������������������������������������������������������������������������                              
/*                          
-----------------------------------------------------------------------------                          
Nro  FECHA  USUARIO  DESCRIPCION                          
-----------------------------------------------------------------------------                          

*/        
--EXEC cResultadoError_AlertaMejoraContinuaIdat_Correo
ALTER PROCEDURE [dbo].[cResultadoError_AlertaMejoraContinuaIdat_Correo]         
--declare  
as    
BEGIN
		IF EXISTS (SELECT CONVERT(VARCHAR, DATEADD (DAY,-15,Inicio) ,112) FROM Periodo WHERE YEAR(Inicio) = YEAR(GETDATE())
		AND CONVERT(VARCHAR, DATEADD (DAY,-15,Inicio), 112)  = CONVERT(VARCHAR, GETDATE(), 112))
		BEGIN
			Declare @vBodyEmail varchar(max)='',
			@vFilasConsultadas int,
			@vFila int,
			@DestinatarioTipoSeccion Varchar(200),
			@CopiaDestinatarioTipoSeccion Varchar(200) 
		
		  
			DECLARE @ResultadoMatricula TABLE
			(Id Int Identity,
			NombreCompleto Varchar(200), 
			PromocionNombre Varchar(200),
			Descripcion Varchar(200))

			INSERT INTO @ResultadoMatricula
			SELECT  NombreCompleto,PromocionNombre,Observacion FROM ResultadoMatricula WITH(NOLOCK) where Observacion like '%seccion%'
			
			SELECT @DestinatarioTipoSeccion=ISNULL(Valor2,''),@CopiaDestinatarioTipoSeccion=ISNULL(Valor3,'')
			FROM Parametro  WITH(NOLOCK) WHERE Nombre='MatriculaTipoSeccion'

			SELECT @vFilasConsultadas= COUNT(*) FROM @ResultadoMatricula

			 select @vFilasConsultadas
			  If (@vFilasConsultadas > 0)
				  Begin 
					 --Se devuelve todos los registros con errores
					 Set @vFila = 1

					 Set @vBodyEmail = @vBodyEmail + '<html>'
	
						Set @vBodyEmail = @vBodyEmail + '<head>'            
						   Set @vBodyEmail = @vBodyEmail + '<style type="text/css">'
						   Set @vBodyEmail = @vBodyEmail + '.headGrid {'
						   Set @vBodyEmail = @vBodyEmail + '	font-weight: bold;'
						   Set @vBodyEmail = @vBodyEmail + '	font-size: 11px; '
						   Set @vBodyEmail = @vBodyEmail + '	color: #FFFFFF; '
						   Set @vBodyEmail = @vBodyEmail + '	font-family: Tahoma, Microsoft Sans Serif; '    
						   Set @vBodyEmail = @vBodyEmail + '	background-color: #539AC8;         '            
						   Set @vBodyEmail = @vBodyEmail + '}'
						   Set @vBodyEmail = @vBodyEmail + '.itemGrid {'
						   Set @vBodyEmail = @vBodyEmail + '	background-color: #F8F8F8;'
						   Set @vBodyEmail = @vBodyEmail + '	font-size: 8pt; color: #000000; font-family: Arial, Microsoft Sans Serif;'
						   Set @vBodyEmail = @vBodyEmail + '}'
						   Set @vBodyEmail = @vBodyEmail + '.titulo {'
						   Set @vBodyEmail = @vBodyEmail + '	font-weight: bold;'
						   Set @vBodyEmail = @vBodyEmail + '	font-size: 12pt; color: #000000; font-family: Arial, Microsoft Sans Serif;'
						   Set @vBodyEmail = @vBodyEmail + '}'
						   Set @vBodyEmail = @vBodyEmail + '</style>'
						Set @vBodyEmail = @vBodyEmail + '</head>'
						Set @vBodyEmail = @vBodyEmail + '<body>'
						   Set @vBodyEmail = @vBodyEmail + '<table style="width: 100%">'
								 Set @vBodyEmail = @vBodyEmail + '<tr style="height: 20pt">'
									Set @vBodyEmail = @vBodyEmail + '<td class="titulo">&nbsp;'
									   Set @vBodyEmail = @vBodyEmail + 'Lista de errores TipoSeccion'                
									Set @vBodyEmail = @vBodyEmail + '</td>'
								 Set @vBodyEmail = @vBodyEmail + '</tr>'
						   Set @vBodyEmail = @vBodyEmail + '</table>'
						   Set @vBodyEmail = @vBodyEmail + '<br>'
						   Set @vBodyEmail = @vBodyEmail + '<table border="1" style="width: 100%;" cellpadding="0" cellspacing="0">'
						   Set @vBodyEmail = @vBodyEmail + '<tr>'
						   Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Id</td>'
						   Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">NombreCompleto</td>'
						   Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Promoci�n</td>'
						   Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Descripci�n</td>'
						   Set @vBodyEmail = @vBodyEmail + '</tr>'
            
						select @vBodyEmail
						select @vFila,@vFilasConsultadas
						   While (@vFila <= @vFilasConsultadas)
						   Begin
							  Set @vBodyEmail = @vBodyEmail + '<tr>'
          
							  Select @vBodyEmail = @vBodyEmail + 
									 '<td align="center" class="itemGrid">' + Convert(varchar(7), Id) + '</td>' + 
									 '<td class="itemGrid">' + IsNull(NombreCompleto, '') + '</td>' + 
									 '<td align="center" class="itemGrid">' + Convert(varchar(200), PromocionNombre) + '</td>' + 
									 '<td class="itemGrid">' + IsNull(Descripcion, '') + '</td>'
							  From @ResultadoMatricula
							  Where Id = @vFila

							  select @vBodyEmail

							  Set @vBodyEmail = @vBodyEmail + '</tr>'

							  Set @vFila = @vFila + 1
						   End              

					 Set @vBodyEmail = @vBodyEmail + '</table>'
						   Set @vBodyEmail = @vBodyEmail + '<br>'
						   Set @vBodyEmail = @vBodyEmail + '<table style="width: 100%">'
								 Set @vBodyEmail = @vBodyEmail + '<tr style="height: 20pt">'
									Set @vBodyEmail = @vBodyEmail + '<td style="font-size:  9pt;font-family: Tahoma, Microsoft Sans Serif; color: red;">&nbsp;'
									   Set @vBodyEmail = @vBodyEmail + 'SEE'                
									Set @vBodyEmail = @vBodyEmail + '</td>'
								 Set @vBodyEmail = @vBodyEmail + '</tr>'
						   Set @vBodyEmail = @vBodyEmail + '</table>'
						Set @vBodyEmail = @vBodyEmail + '</body>'
					 Set @vBodyEmail = @vBodyEmail + '</html>'

					 EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar    
					   @profile_name = 'Smart',   
					   @recipients = @DestinatarioTipoSeccion,    
					   @blind_copy_recipients = @CopiaDestinatarioTipoSeccion,
					   @body = @vBodyEmail,    
					   @body_format = 'HTML',    
					   @subject = 'Errores Proceso';
				  End
		END
END