SELECT 
COUNT(CASE WHEN Ac.Genero = 1 THEN 1 END) AS 'Cantidad de Masculinos',
COUNT(CASE WHEN Ac.Genero = 0 THEN 1 END) AS 'Cantidad de Femeninos',
ISNULL(p.PromocionNombre,'')Carrera FROM MATRICULA M
INNER JOIN Actor AC WITH(NOLOCK) ON M.IdActor = Ac.IdActor
INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion
INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo 
INNER JOIN PeriodoCabecera PEC WITH(NOLOCK) ON PE.IdPeriodoCabecera = PEC.IdPeriodoCabecera 
WHERE PEC.Codigo LIKE '%2024%'  AND M.Estado <>'X' AND P.IdUnidadNegocio=1
GROUP BY 
ISNULL(p.PromocionNombre, '')