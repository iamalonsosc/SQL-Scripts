--DECLARE @IdMatriculaAntigua INT=612321,@IdAlumno INT=1231062,@IdMatriculaNueva INT

UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (612321,653832,682894)

UPDATE Registro SET Estado='X'
WHERE IdActor=1231062 AND IdRegistro IN (4,5)

UPDATE AlumnoCurricula SET Activo=0
WHERE IdAlumno=1231062 AND IdRegistro IN (4,5)


--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1231062 AND IdRegistro=2 AND IdCurso=9870 AND IdCurricula=28

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1231062 AND IdRegistro=2 AND IdCurso=10440 AND IdCurricula=28


SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1231062  --AND AC.IdCurso=13523
order by ac.idregistro,ac.IdAlumnoCurso desc


--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=30
WHERE IdMatricula=783450 AND IdCurso=9870
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=31
WHERE IdMatricula=783450 AND IdCurso=13523

--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=6,IdAlumnoCurso=2,IdcurriculaOriginal=5805
WHERE IdMatricula=612321 AND IdCurso=9870

UPDATE AlumnoCurso SET IdRegistro=6,IdAlumnoCurso=8,IdcurriculaOriginal=5805,IdCursoOriginal=NULL,PromedioFinal='14.00',PromedioReal='14.00'
WHERE IdMatricula=612321 AND IdCurso=13523



--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='17.00',PromedioReal='17.00',IdAlumnoCurso=2,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1231062 AND IdRegistro=6 AND IdCurso=9870 AND IdCurricula=5805

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='14.00',PromedioReal='14.00',IdAlumnoCurso=8,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1231062 AND IdRegistro=6 AND IdCurso=13523 AND IdCurricula=5805

--agregar cursos no convalidados por equivalencias

--UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='18',PromedioReal='17.62',IdAlumnoCurso=4,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51203
--WHERE IdAlumno=1231062 AND IdRegistro=6 AND IdCurso=13449 AND IdCurricula=5805

--UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='20',PromedioReal='20.00',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51203
--WHERE IdAlumno=1231062 AND IdRegistro=6 AND IdCurso=10442 AND IdCurricula=5805

--UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='17',PromedioReal='17.00',IdAlumnoCurso=7,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51203
--WHERE IdAlumno=1231062 AND IdRegistro=6 AND IdCurso=13519 AND IdCurricula=5805

--UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='17',PromedioReal='17.00',IdAlumnoCurso=7,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51203
--WHERE IdAlumno=1231062 AND IdRegistro=6 AND IdCurso=13514 AND IdCurricula=5805


--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET  IdGrupo=1,Estado='N',IdRegistro=6,IdCurricula=5805,IdPromocion=101511
WHERE IdMatricula=612321

UPDATE Matricula SET Estado='N'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (653832,682894)

UPDATE Registro SET Estado='N'
WHERE IdActor=1231062 AND IdRegistro IN (4,5)

UPDATE AlumnoCurricula SET Activo=1
WHERE IdAlumno=1231062 AND IdRegistro IN (4,5)

-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO
UPDATE Matricula SET Estado='X'
WHERE IdMatricula=783450