SELECT top 200 *FROM AlumnoCursoNominaLogMinedu --where Programa='CGT'
ORDER BY FECHACREACION DESC


SELECT top 200 *FROM alumnocursoa --where Programa='CGT'
ORDER BY FECHACREACION DESC


SELECT*FROM AlumnoCursoNominaLogMinedu where Mensaje='[401] Unauthorized'
ORDER BY FECHACREACION DESC