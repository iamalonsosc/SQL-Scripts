UPDATE Item SET Nombre='DESCUENTOS OP2'
--Descuento Mat 250
--SELECT*FROM Item
where IdItem=483187
--(1 row affected)


--select*from MaestroTablaRegistro 
UPDATE MaestroTablaRegistro set Nombre='CAPTACI�N 2025 OPCION 02',Descripcion='CAPTACI�N 2025 OPCION 02'
--CAPTACI�N 2025 OPCI�N 02 MAT 250
WHERE IdMaestroRegistro=32507
--(1 row affected)