--����������������������������������������������������������������������������                                                      
--Creado por      :Carlos Huallpa(23/01/2009)                                                      
--Funcionalidad   :Busca y lista los periodos activos e inactivos          
--Utilizado por   :Periodo.BusBuscarLis.       
--����������������������������������������������������������������������������           
/*      
-----------------------------------------------------------------------------      
Nro	FECHA		USUARIO		DESCRIPCION      
-----------------------------------------------------------------------------      
@1 09.01.2012	plozada		Considerar la Unidad de Negocio "Todos"(0)     
@2 09.01.2012	gguillen	Agregado filtro para cuando sede viene como 0  
@3 2018.09.25	jmota		se cambia por error en consulta periodo  
@4 30.01.2019	Eloy Alva (Sigcomt) Multiples Periodos
@4 30.01.2019	Eloy Alva (Sigcomt) Multiples Periodos
@5 18.07.2019	Nicolas Huanca (Sigcomt)  Mostrar registros con matricula abierta EsCierre = 0
@6 2020.04.02	hcachi		Se agrega parametro @Nombre para nuevo formulario de Programas y Periodos Multiples
@7 2021.02.10	hcachi		Se agrega campo Sede para selecion en SV	
*/                                               
--CREATE PROCEDURE [dbo].[cPeriodo_Bus_Buscar]          
declare
@IdEmpresa INT                
,@IdSede INT
,@IdFacultad INT
,@IdUnidadNegocio INT
,@IdUnidadAcademica  INT --@4  
,@Codigo VARCHAR(20)
,@Nombre VARCHAR(500) = NULL --@6
,@Activo BIT
,@PaginaTamano INT
,@PaginaNumero INT
,@EsCierre BIT = NULL   
--AS    
BEGIN     
  select @IdEmpresa=1,@IdSede=50,@IdFacultad=1,
@IdUnidadNegocio=1,@Codigo=N'',@Nombre=NULL,@Activo=1,
@PaginaTamano=20,@PaginaNumero=-1,@IdUnidadAcademica=60,@EsCierre=NULL
 SET NOCOUNT ON  

SELECT IdPeriodo
		,PE.Codigo
		,IdPeriodoAnual
		,PE.Nombre
		,Inicio
		,Fin
		,ROW_NUMBER() OVER (ORDER BY PE.Codigo DESC) AS RowNumber
		,'IdPeriodoAnterior' = ISNULL(IdPeriodoAnterior, - 1)
		,'IdPeriodoSiguiente' = ISNULL(IdPeriodoSiguiente, - 1)
		,'IdUnidadAcademica' = ISNULL(PE.IdUnidadAcademica, 0) --@4
		,'IdUnidadNegocio' = ISNULL(PE.IdUnidadNegocio, 0) --@4
		,'IdTipo' = ISNULL(IdTipo, 0) --@4  
		,'NombreUnidadAcademica' = ISNULL(UA.Nombre, '') --@4
		,'NombreUnidadNegocio' = ISNULL(UN.Nombre, '') --@4
		,'TipoPeriodoNombre' = MTR.Nombre --@4
		,'CodigoSede' = S.Codigo --@7     
	FROM Periodo PE WITH (NOLOCK)
	INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON PE.IdUnidadNegocio = UN.IdUnidadNegocio --@4
	INNER JOIN UnidadAcademica UA WITH (NOLOCK) ON PE.IdUnidadAcademica = UA.IdUnidadAcademica --@4
	INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON PE.IdTipo = MTR.IdMaestroRegistro --@4
	INNER JOIN Sede S WITH (NOLOCK) ON PE.IdSede = S.IdSede --@7
	WHERE IdEmpresa = @IdEmpresa
		AND (@IdSede = - 1 OR PE.IdSede = @IdSede) --@2  
		--AND IdSede=@IdSede      
		AND IdFacultad = @IdFacultad
		--AND IdUnidadNegocio=@IdUnidadNegocio --@1    
		AND (ISNULL(@IdUnidadNegocio, - 1) < 0 OR PE.IdUnidadNegocio = @IdUnidadNegocio) --@1  @3  
		AND (ISNULL(@IdUnidadAcademica, - 1) <= 0 OR PE.IdUnidadAcademica = @IdUnidadAcademica) --@4  
		AND PE.Codigo LIKE '%' + ISNULL(@Codigo, '') + '%'
		AND (ISNULL(PE.Nombre, '') LIKE '%' + ISNULL(@Nombre, '') + '%') --@6        
		AND PE.Activo = ISNULL(@Activo, PE.Activo)
		AND EsCierre = ISNULL(@EsCierre, EsCierre)

END