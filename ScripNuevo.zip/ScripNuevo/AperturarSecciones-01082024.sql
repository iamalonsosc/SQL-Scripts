--select* from periodo where codigo in('2024-IIA');
--select*from UnidadNegocio where idunidadnegocio=1
UPDATE SE set SE.Estado='A'
		FROM Periodo PE WITH(NOLOCK)
		INNER JOIN Promocion PR WITH(NOLOCK) ON PE.IdPeriodo=pr.IdPeriodo
		INNER JOIN	Seccion SE WITH(NOLOCK) ON PR.IdPromocion=se.IdPromocion
		WHERE PE.Codigo in('2024-IIA')
		AND SE.Estado='F'
--(1243 rows affected)