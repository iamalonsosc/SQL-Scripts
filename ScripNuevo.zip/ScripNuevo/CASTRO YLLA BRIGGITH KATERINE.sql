SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=640131


SELECT TipoCondicion,*FROM AlumnoCurso 
--UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=640131 AND EsMatricula=1

--SELECT DISTINCT TipoCondicion  FROM Matricula