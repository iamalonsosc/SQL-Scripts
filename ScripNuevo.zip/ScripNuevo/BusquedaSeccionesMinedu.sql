SELECT  'TipoProceso'='MA',
		'Periodo'=ISNULL( PE.Codigo,''),
		'Codigo Modular'= ISNULL(PUA.Valor10,''),
		'Sede'= ISNULL(S.Nombre,''),
		'Nivel Formativo'= ISNULL (PUA.Valor4,''),
		'Nombre Carrera'= ISNULL ( PRO.ProductoNombreCorto,'') ,
		'Plan De Estudio'= ISNULL (C.NombrePlanEstudio ,''),
		'Semestre Academico'=CASE ACN.IdModulo WHEN 1 THEN 'I'ELSE '' END+
		CASE ACN.IdModulo WHEN 2 THEN 'II'ELSE '' END+
		CASE ACN.IdModulo WHEN 3 THEN 'III'ELSE ''END+
		CASE ACN.IdModulo WHEN 4 THEN 'IV'ELSE ''END+
		CASE ACN.IdModulo WHEN 5 THEN 'V'ELSE ''END+
		CASE ACN.IdModulo WHEN 6 THEN 'VI'ELSE ''END+
		CASE ACN.IdModulo WHEN 7 THEN 'VII'ELSE ''END+
		CASE ACN.IdModulo WHEN 8 THEN 'VIII'ELSE ''END
		,'Turno'= CASE ACN.Turno  WHEN 'MADRUGADOR' THEN 'MA�ANA'
		WHEN 'DIURNO' THEN 'MA�ANA'
		WHEN 'NOCTURNO' THEN 'NOCHE'
		ELSE 'MA�ANA' END
		,'Secci�n'= ISNULL(ACN.SeccionNomina,'')
		FROM AlumnoCursoNomina ACN WITH (NOLOCK)
		INNER JOIN Producto PRO WITH (NOLOCK) 
		ON ACN.IdProducto=PRO.IdProducto  
		INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) 
		ON pro.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro
		INNER JOIN Actor A WITH(NOLOCK)       
		ON ACN.IdActor=A.IdActor
		INNER JOIN Periodo PE  WITH (NOLOCK) 
		ON ACN.IdPeriodo=PE.IdPeriodo  
		INNER JOIN Curricula C WITH(NOLOCK)
		ON ACN.IdCurricula = C.IdCurricula
		INNER JOIN Matricula M WITH(NOLOCK)
		ON ACN.IdMatricula = M.IdMatricula 
		INNER JOIN Promocion P WITH (NOLOCK)ON M.IdPromocion = P.IdPromocion
		INNER JOIN Sede S WITH(NOLOCK)
		ON ACN.IdSede = S.IdSede
		INNER JOIN ParametroUnidadAcademica PUA WITH(NOLOCK)
		ON  PUA.IdUnidadNegocio=P.IdUnidadNegocio
		AND PUA.IdUnidadAcademica = P.IdUnidadAcademica 
		AND PUA.IdSede=P.IdSede
		AND PUA.Nombre='ParametroNomina1' 
		AND PUA.IdProducto=P.IdProducto
		WHERE 
		 ACN.IdEmpresa=1
		--AND ACN.IdSede=36
		--AND ACN.IdPeriodo=3712       
		--AND (ACN.IdProducto=11362 OR 11362= 0)
		AND PE.Codigo='2024-II'
		AND (( MTR_PRO.Disponible1='C' AND  MTR_PRO.Disponible2='CAR' ) OR MTR_PRO.Disponible1='P' )
		AND PE.IdUnidadNegocio IN (1) 
		 AND ACN.SeccionNomina IN( 
'215.III.01.2024-II-III-D'
,'217.II.01.2024-II-II-C'
,'217.III.01.2024-II-III-C'
,'215.I.02.2024-II-I-D'
,'215.II.02.2024-II-II-E'
,'217.I.04.2024-II-I-E'
,'217.II.02.2024-II-II-E'
,'217.III.02.2024-II-III-E'
,'210.I.01.2024-II-I-C'
,'210.II.01.2024-II-II-D'
,'213.II.01.2024-II-II-B'
,'213.III.01.2024-II-III-D'
,'215.I.02.2024-II-I-C'
,'215.I.02.2024-II-I-E'
,'215.II.02.2024-II-II-F'
,'216.II.01.2024-II-II-C'
,'217.I.04.2024-II-I-F'
,'217.II.02.2024-II-II-D'
,'217.III.02.2024-II-III-F'
,'217.III.01.2024-II-III-D'
,'217.III.01.2024-II-III-E'
,'215.II.01.2024-II-II-C'
,'215.III.01.2024-II-III-C'
,'217.I.04.2024-II-I-C'
,'217.III.01.2024-II-III-F'
,'218.III.02.2024-II-III-E'
,'220.III.01.2024-II-III-D'
)
--AND M.NumeroMatricula IS NULL
GROUP BY  PE.Codigo,PUA.Valor10,S.Nombre,PUA.Valor4, PRO.ProductoNombreCorto,C.Nombre,ACN.IdModulo,ACN.Turno,ACN.SeccionNomina,C.NombrePlanEstudio


--SELECt NumeroMatricula,*FROM MATRICULA WHErE IDMATRICULA=614310
select*from AlumnoCursoNominaJson
where periodoCodigo LIKE '%2024-II%'
--select*from AlumnoCursoNomina where SeccionNomina='215.II.02.2024-II-II-E'
--SELECT*FROM sede WHERE Codigo='0215.01'
--SELECT*FROM Periodo
--WHERE Codigo='2024-II'

SELECT*FROM Periodo
where Codigo='2024-IIA'
AND IdUnidadAcademica=60

SELECT*FROM Sede

SELECT    distinct    
ACN.IdMatricula,
ACN.IdProducto,         
'Producto'= PRO.ProductoNombreCorto,          
1 EsNuevo,       
'Seccion' = ACN.SeccionNomina,
'SeccionMinedu' = CASE WHEN ISNULL(ENE.CodigoSedeOrigen,'') =''
THEN ACN.SeccionNomina
ELSE  ACN.SeccionNomina + '-' + ENE.CodigoSedeOrigen
END
,
'IdSede'=ACN.idsede,  
'IdPeriodo'=ACN.IdPeriodo,  
'FechaInicio'=CONVERT(VARCHAR,PE.Inicio,103),  
--'TurnoNombre'=MTR.Nombre,
'TurnoNombre'=ACN.Turno,
'FechaFin'=CONVERT(VARCHAR,PE.Fin,103),
'periodoCodigo' = PE.Codigo,
'periodoCodigoMinedu' = PE.CodigoMinedu,--falta cambiar por el nuevo campo de mgarriazo
'nombreSede' = ISNULL(SE.Nombre,SE2.Nombre),
'nivelFormativo' = PUA.Valor4,
'codigoModular' = ISNULL(ENE.CodModularDestino,PUA.Valor10),
'planEstudio' = Cu.NombrePlanEstudio
FROM AlumnoCursoNomina ACN WITH (NOLOCK)
INNER JOIN Producto PRO WITH (NOLOCK) ON ACN.IdProducto=PRO.IdProducto  
INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON pro.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro  
INNER JOIN Periodo PE  WITH (NOLOCK) ON ACN.IdPeriodo=PE.IdPeriodo      
INNER JOIN PeriodoCabecera PEC WITH (NOLOCK) ON PE.IdPeriodoCabecera=PEC.IdPeriodoCabecera 
INNER JOIN Promocion PROM WITH (NOLOCK) ON PROM.idpromocion = ACN.idpromocion
INNER JOIN Curricula Cu  WITH (NOLOCK) on PROM.IdCurricula = Cu.IdCurricula
LEFT JOIN EquivalenciaNominasEnvioJSON ENE WITH (NOLOCK)ON ACN.IdSede = ENE.IdSedeOrigen AND ACN.IdProducto = ENE.IdProducto AND PEC.Codigo = ENE.Periodo--@4
LEFT JOIN Sede SE WITH (NOLOCK)ON ENE.IdSedeDestino = SE.IdSede
LEFT JOIN Sede SE2 WITH (NOLOCK)ON ACN.IdSede = SE2.IdSede
LEFT JOIN ParametroUnidadAcademica PUA WITH (NOLOCK) 
		ON  PUA.IdUnidadNegocio=PE.IdUnidadNegocio
		AND PUA.IdUnidadAcademica = PE.IdUnidadAcademica 
		AND PUA.IdSede=PE.IdSede
		AND PUA.IdProducto=PRO.IdProducto
		and PUA.Nombre = 'ParametroNomina1'

WHERE ACN.IdEmpresa=1 
AND (( MTR_PRO.Disponible1='C' AND  MTR_PRO.Disponible2='CAR' ) OR MTR_PRO.Disponible1='P' )
AND PE.IdUnidadNegocio =1
--AND PE.idunidadacademica =@idunidadacademicanomina
--AND ACN.IdPeriodo = @idperiodo
--AND ACN.IdSede = @idsedenomina
--AND (ACN.IdProducto=@idproductonomina or @idproductonomina=0)
AND PE.Codigo='2024-II'
AND ACN.SeccionNomina IN( 
'215.III.01.2024-II-III-D'
,'217.II.01.2024-II-II-C'
,'217.III.01.2024-II-III-C'
,'215.I.02.2024-II-I-D'
,'215.II.02.2024-II-II-E'
,'217.I.04.2024-II-I-E'
,'217.II.02.2024-II-II-E'
,'217.III.02.2024-II-III-E'
,'210.I.01.2024-II-I-C'
,'210.II.01.2024-II-II-D'
,'213.II.01.2024-II-II-B'
,'213.III.01.2024-II-III-D'
,'215.I.02.2024-II-I-C'
,'215.I.02.2024-II-I-E'
,'215.II.02.2024-II-II-F'
,'216.II.01.2024-II-II-C'
,'217.I.04.2024-II-I-F'
,'217.II.02.2024-II-II-D'
,'217.III.02.2024-II-III-F'
,'217.III.01.2024-II-III-D'
,'217.III.01.2024-II-III-E'
,'215.II.01.2024-II-II-C'
,'215.III.01.2024-II-III-C'
,'217.I.04.2024-II-I-C'
,'217.III.01.2024-II-III-F'
,'218.III.02.2024-II-III-E'
,'220.III.01.2024-II-III-D'
)
