--SELECT  *FROM ParametroUnidadAcademica WHERE IdEmpresa=1  AND Nombre='ParametroNomina1'AND IdProducto=13481
--NOMINAS
UPDATE ParametroUnidadAcademica SET Valor4='PROFESIONAL T�CNICO'
WHERE IdEmpresa=1  AND Nombre='ParametroNomina1'AND IdProducto=13481
--(8 rows affected)



--SELECT  *FROM ParametroUnidadAcademica WHERE IdEmpresa=1  AND Nombre='ParametroNomina2'AND IdProducto=13481
--ACTAS
UPDATE ParametroUnidadAcademica SET Valor4='PROFESIONAL T�CNICO'
WHERE IdEmpresa=1  AND Nombre='ParametroNomina2'AND IdProducto=13481
--(8 rows affected)