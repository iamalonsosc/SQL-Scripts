SET NOCOUNT ON;

DECLARE @Simulacion     BIT       = 1;            -- 1 = solo muestra / 0 = aplica
DECLARE @SoloPendientes BIT       = 1;            -- 1 = solo GE/PR sin BV/FC
DECLARE @CompaniaSocio  CHAR(8)   = '00002700';
DECLARE @Usuario        CHAR(20)  = 'MASIVO-MONTO';
DECLARE @Formulario     CHAR(100) = 'Script-ActualizarMontoMasivo';


IF OBJECT_ID('tempdb..#Matriculas') IS NOT NULL DROP TABLE #Matriculas;
CREATE TABLE #Matriculas (IdMatricula INT PRIMARY KEY);

INSERT INTO #Matriculas (IdMatricula) VALUES
(850270)
,(850145)
,(850002)
,(850032)
,(849990)
,(850010)
,(850042)
,(850067)
,(851520)
,(850126)
,(851706)
,(850234)
,(850288)
,(850300)
,(850274)
,(850281)
,(850326)
,(849986)
,(850176)
,(850235)
,(850320)
,(849985)
,(851479)
,(850200)
,(850114)
,(850094)
,(850146)
,(849989)
,(849981)
,(850137)
,(850226)
,(849987)
,(850285)
,(850078)
,(850671)
,(850100)
,(850249)
,(850175)
,(851391)
,(850049)
,(851422)
,(850250)
,(851483)
,(851481)
,(850080)
,(851423)
,(850107)
,(850096)
,(851421)
,(851480)
,(850313)
,(850133)
,(850180)
,(850265)
,(851420)
,(850160)
,(850020)
,(849984)
,(850088)
,(849993)
,(850158)
,(849992)
,(851493)
,(850054)
,(850212)
,(850284)
,(851498)
,(850257)
,(850229)
,(850275)
,(850123)
,(850028)
,(850297)
,(850111)
,(850185)
,(850317)
,(850187)
,(850276)
,(850670)
,(850262)
,(850205)
,(850298)
,(850688)
,(850266)
,(850174)
,(850129)
,(850681)
,(850138)
,(626176)
,(850269)
,(851502)
,(851497)
,(851490)
,(850008)
,(850221)
,(851494)
,(851492)
,(851491)
,(849982)
,(850087)
,(850121)
,(850170)
,(849999)
,(850291)
,(850678)
,(850201)
,(850211)
,(850177)
,(851501)
,(850676)
,(850045)
,(850327)
,(850254)
,(850289)
,(850159)
,(850277)
,(850079)
,(850021)
,(851453)
,(850153)
,(850202)
,(850191)
,(850110)
,(850314)
,(850259)
,(850280)
,(850033)
,(851499)
,(850143)
,(850222)
,(850085)
,(850196)
,(850308)
,(850037)
,(850083)
,(851496)
,(850109)
,(850223)
,(850213)
,(850099)
,(850116)
,(850075)
,(850077)
,(850325)
,(850247)
,(850113)
,(850001)
,(850122)
,(850237)
,(850056)
,(850130)
,(850152)
,(850184)
,(850225)
,(850157)
,(851495)
,(850043)
,(850219)
,(850258)
,(850165)
,(850014)
,(850025)
,(850192)
,(850131)
,(850193)
,(850166)
,(850039)
,(850207)
,(850127)
,(850064)
,(850149)
,(850097)
,(850263)
,(850070)
,(850244)
,(850004)
,(850005)
,(850148)
,(850179)
,(850315)
,(850233)
,(851500)
,(850197)
,(850272)
,(850246)
,(850038)
,(850282)
,(850321)
,(850031)
,(850214)
,(850000)
,(850302)
,(850164)
,(850044)
,(849980)
,(850167)
,(850267)
,(850316)
,(850194)
,(849983)
,(850307)
,(850161)
,(850311)
,(850231)
,(850144)
,(850186)
,(850003)
,(850151)
,(850098)
,(849979)
,(850072)
,(850324)
,(850124)
,(849998)
,(850252)
,(850255)
,(850030)
,(850163)
,(850019)
,(850134)
,(850057)
,(850227)
,(850318)
,(850082)
,(850290)
,(850012)
,(850108)
,(850190)
,(850305)
,(850135)
,(850181)
,(850216)
,(850294)
,(850055)
,(850292)
,(850312)
,(851356)
,(850242)
,(850286)
,(850287)
,(850248)
,(850206)
,(850007)
,(850304)
,(850154)
,(850136)
,(850195)
,(850296)
,(850293)
,(850058)
,(850220)
,(850081)
,(850140)
,(850173)
,(850271)
,(850189)
,(850051)
,(850095)
,(850006)
,(850241)
,(849997)
,(850322)
,(850224)
,(850076)
,(850155)
,(850251)
,(850029)
,(850047)
,(850256)
,(850104)
,(850303)
,(850210)
,(850017)
,(850172)
,(850120)
,(850112)
,(850218)
,(850261)
,(850319)
,(850060)
,(849991)
,(850026)
,(850232)
,(850299)
,(850215)
,(850217)
,(850023)
,(850066)
,(850203)
,(849988)
,(850022)
,(849994)
,(850053)
,(850036)
,(850024)
,(850240)
,(850283)
,(850680)
,(850117)
,(850068)
,(850074)
,(849996)
,(850245)
,(850309)
,(851417)
,(850059)
,(850198)
,(850183)
,(850013)
,(850046)
,(850238)
,(850168)
,(850264)
,(850073)
,(850065)
,(850230)
,(850306)
,(850128)
,(850208)
,(850243)
,(850169)
,(850103)
,(850188)
,(850027)
,(851355)
,(850011)
,(850273)
,(850228)
,(849995)
,(850279)
,(850119)
,(850084)
;


IF OBJECT_ID('tempdb..#Base') IS NOT NULL DROP TABLE #Base;

SELECT     MT.IdMatricula,
           M.IdActor,
           P.ServicioCodigo,
           APD.IdAlumnoPrecioDiferenciado,
           CONVERT(MONEY, APD.PrecioMatricula) AS PrecioMatricula,
           CONVERT(MONEY, APD.PrecioCuotas)    AS PrecioCuotas,
           (SELECT COUNT(1) FROM dbo.AlumnoPrecioDiferenciado X WITH (NOLOCK)
            WHERE X.IdActor = M.IdActor AND X.Estado = 1) AS FilasAPD
INTO       #Base
FROM       #Matriculas   MT
INNER JOIN dbo.Matricula M WITH (NOLOCK) ON M.IdMatricula = MT.IdMatricula AND M.TipoServicio='P'
INNER JOIN dbo.Promocion P WITH (NOLOCK) ON P.IdPromocion = M.IdPromocion
OUTER APPLY (
    SELECT TOP 1 A.IdAlumnoPrecioDiferenciado, A.PrecioMatricula, A.PrecioCuotas
    FROM   dbo.AlumnoPrecioDiferenciado A WITH (NOLOCK)
    WHERE  A.IdActor = M.IdActor
       AND A.Estado  = 1
    ORDER BY A.IdAlumnoPrecioDiferenciado DESC
) APD;
SELECT*FROM #Base
-- Matr�culas sin precio diferenciado vigente: NO se tocan
SELECT 'SIN PRECIO DIFERENCIADO' AS Observacion, *
FROM   #Base
WHERE  IdAlumnoPrecioDiferenciado IS NULL;

-- Actores con m�s de una fila activa (revisa si el TOP 1 eligi� lo correcto)
SELECT 'APD DUPLICADO' AS Observacion, *
FROM   #Base
WHERE  FilasAPD > 1;

DELETE FROM #Base WHERE IdAlumnoPrecioDiferenciado IS NULL;

/* ---------- 3. CUOTAS A ACTUALIZAR ---------- */
IF OBJECT_ID('tempdb..#Cuotas') IS NOT NULL DROP TABLE #Cuotas;

SELECT     B.IdMatricula,
           B.IdActor,
           B.ServicioCodigo,
           H.NumeroInterno,
           H.CuotaNumero,
           H.TipoFacturacion,
           H.Estado,
           ISNULL(H.NumeroDocumento,'') AS NumeroDocumentoCompleto,
           SUBSTRING(ISNULL(H.NumeroDocumento,''),1,2) AS DocTipo,
           SUBSTRING(ISNULL(H.NumeroDocumento,''),
                     CHARINDEX('-', ISNULL(H.NumeroDocumento,'-')) + 1, 100) AS DocNumero,
           D.Monto AS MontoActual,
           CASE WHEN H.TipoFacturacion = 'MAT' AND B.PrecioMatricula > 0
                THEN B.PrecioMatricula ELSE B.PrecioCuotas END AS MontoNuevo
INTO       #Cuotas
FROM       #Base B
INNER JOIN vw_CO_Interfase_P09_Header  H WITH (NOLOCK) ON H.IdMatricula   = B.IdMatricula
                                                       AND H.CompaniaSocio = @CompaniaSocio
INNER JOIN vw_CO_Interfase_P09_Detalle D WITH (NOLOCK) ON D.NumeroInterno = H.NumeroInterno
                                                       AND D.ItemCodigo    = B.ServicioCodigo
                                                       AND D.CompaniaSocio = @CompaniaSocio
WHERE  (@SoloPendientes = 0
        OR (H.Estado IN ('GE','PR')
            AND ISNULL(H.NumeroDocumento,'') NOT LIKE '%BV%'
            AND ISNULL(H.NumeroDocumento,'') NOT LIKE '%FC%'));

CREATE INDEX IX_Cuotas ON #Cuotas (NumeroInterno, ServicioCodigo);

/* ---------- 4. PREVIA / APLICACI�N ---------- */
IF @Simulacion = 1
BEGIN
    SELECT IdMatricula, IdActor, ServicioCodigo, NumeroInterno, CuotaNumero,
           TipoFacturacion, Estado, NumeroDocumentoCompleto,
           MontoActual, MontoNuevo, MontoNuevo - MontoActual AS Diferencia
    FROM   #Cuotas
    ORDER BY IdMatricula, CuotaNumero;

    SELECT COUNT(DISTINCT IdMatricula) AS Matriculas,
           COUNT(1)                    AS Cuotas,
           SUM(MontoActual)            AS TotalActual,
           SUM(MontoNuevo)             AS TotalNuevo
    FROM   #Cuotas;

    /* ============================================================
   PREVIA 1 � CO_Interfase_P09_Detalle  (espejo del UPDATE 4.1)
   ============================================================ */
SELECT     D.NumeroInterno,
           D.ItemCodigo,
           D.CompaniaSocio,
           C.IdMatricula,
           D.Monto                    AS Monto_Actual,
           C.MontoNuevo                AS Monto_Nuevo,
           C.MontoNuevo - D.Monto      AS Diferencia,
           D.UltimoUsuario             AS UltimoUsuario_Actual,
           D.FormularioModificacion    AS Formulario_Actual,
           D.UltimaFechaModificacion   AS FechaModif_Actual
FROM       dbo.CO_Interfase_P09_Detalle D WITH (NOLOCK)
INNER JOIN #Cuotas C ON C.NumeroInterno  = D.NumeroInterno
                    AND C.ServicioCodigo = D.ItemCodigo
WHERE      D.CompaniaSocio = @CompaniaSocio
ORDER BY   C.IdMatricula, D.NumeroInterno;


/* ============================================================
   PREVIA 2 � CO_DocumentoDetalle  (espejo del UPDATE 4.3)
   ============================================================ */
SELECT     DD.TipoDocumento,
           DD.NumeroDocumento,
           DD.ItemCodigo,
           DD.CompaniaSocio,
           C.IdMatricula,
           DD.PrecioUnitario          AS PrecioUnitario_Actual,
           C.MontoNuevo                AS PrecioUnitario_Nuevo,
           DD.Monto                   AS Monto_Actual,
           C.MontoNuevo                AS Monto_Nuevo,
           C.MontoNuevo - DD.Monto     AS Diferencia
FROM       dbo.CO_DocumentoDetalle DD WITH (NOLOCK)
INNER JOIN #Cuotas C ON C.DocTipo       = DD.TipoDocumento
                    AND C.DocNumero     = DD.NumeroDocumento
                    AND C.ServicioCodigo = DD.ItemCodigo
WHERE      DD.CompaniaSocio = @CompaniaSocio
       AND C.NumeroDocumentoCompleto <> ''
ORDER BY   C.IdMatricula, DD.TipoDocumento, DD.NumeroDocumento;


/* ============================================================
   PREVIA 3 � CO_Documento  (espejo del UPDATE 4.4, con el mismo CROSS APPLY)
   ============================================================ */
SELECT     DOC.TipoDocumento,
           DOC.NumeroDocumento,
           C.IdMatricula,
           X.MontoOtrosItems,
           DOC.MontoNoAfecto          AS MontoNoAfecto_Actual,
           X.MontoOtrosItems + C.MontoNuevo AS MontoNoAfecto_Nuevo,
           DOC.MontoTotal             AS MontoTotal_Actual,
           X.MontoOtrosItems + C.MontoNuevo AS MontoTotal_Nuevo,
           (X.MontoOtrosItems + C.MontoNuevo) - DOC.MontoTotal AS Diferencia
FROM       dbo.CO_Documento DOC WITH (NOLOCK)
INNER JOIN #Cuotas C ON C.DocTipo   = DOC.TipoDocumento
                    AND C.DocNumero = DOC.NumeroDocumento
CROSS APPLY (
    SELECT ISNULL(SUM(DD2.Monto),0) AS MontoOtrosItems
    FROM   dbo.CO_DocumentoDetalle DD2 WITH (NOLOCK)
    WHERE  DD2.TipoDocumento   = C.DocTipo
       AND DD2.NumeroDocumento = C.DocNumero
       AND DD2.ItemCodigo     <> C.ServicioCodigo
       AND DD2.CompaniaSocio   = @CompaniaSocio
) X
WHERE      DOC.CompaniaSocio = @CompaniaSocio
       AND C.NumeroDocumentoCompleto <> ''
ORDER BY   C.IdMatricula, DOC.TipoDocumento, DOC.NumeroDocumento;
END
ELSE
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        /* 4.1 Detalle de la interfase */
        UPDATE     D
        SET        D.Monto                   = C.MontoNuevo,
                   D.UltimoUsuario           = @Usuario,
                   D.FormularioModificacion  = @Formulario,
                   D.UltimaFechaModificacion = GETDATE()
        FROM       PLDB01.SpringUnido.dbo.CO_Interfase_P09_Detalle D
        INNER JOIN #Cuotas C ON C.NumeroInterno = D.NumeroInterno
                            AND C.ServicioCodigo = D.ItemCodigo
        WHERE      D.CompaniaSocio = @CompaniaSocio;

        /* 4.3 Detalle del documento contable */
        UPDATE     DD
        SET        DD.PrecioUnitario  = C.MontoNuevo,
                   DD.Monto           = C.MontoNuevo,
                   DD.UltimoUsuario   = @Usuario,
                   DD.UltimaFechaModif = GETDATE()
        FROM       PLDB01.SpringUnido.dbo.CO_DocumentoDetalle DD
        INNER JOIN #Cuotas C ON C.DocTipo   = DD.TipoDocumento
                            AND C.DocNumero = DD.NumeroDocumento
                            AND C.ServicioCodigo = DD.ItemCodigo
        WHERE      DD.CompaniaSocio = @CompaniaSocio
               AND C.NumeroDocumentoCompleto <> '';

        /* 4.4 Cabecera del documento: otros �tems + monto nuevo */
        UPDATE     DOC
        SET        DOC.MontoNoAfecto   = X.MontoOtrosItems + C.MontoNuevo,
                   DOC.MontoTotal      = X.MontoOtrosItems + C.MontoNuevo,
                   DOC.UltimoUsuario   = @Usuario,
                   DOC.UltimaFechaModif = GETDATE()
        FROM       PLDB01.SpringUnido.dbo.CO_Documento DOC
        INNER JOIN #Cuotas C ON C.DocTipo   = DOC.TipoDocumento
                            AND C.DocNumero = DOC.NumeroDocumento
        CROSS APPLY (
            SELECT ISNULL(SUM(DD2.Monto),0) AS MontoOtrosItems
            FROM   dbo.CO_DocumentoDetalle DD2 WITH (NOLOCK)
            WHERE  DD2.TipoDocumento   = C.DocTipo
               AND DD2.NumeroDocumento = C.DocNumero
               AND DD2.ItemCodigo     <> C.ServicioCodigo
               AND DD2.CompaniaSocio   = @CompaniaSocio
        ) X
        WHERE      DOC.CompaniaSocio = @CompaniaSocio
               AND C.NumeroDocumentoCompleto <> '';

        COMMIT TRANSACTION;
        PRINT 'Proceso completado.';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        PRINT 'ERROR: ' + ERROR_MESSAGE();
    END CATCH
END