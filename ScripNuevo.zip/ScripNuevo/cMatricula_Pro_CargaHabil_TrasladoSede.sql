--����������������������������������������������������������������������������          
--Creado por      : Luis Perales Tenorio (07/12/2011)                      
--Funcionalidad   : Permite realizar el proceso de la carga h�bil de los alumnos          
--     con cambio de sede              
--����������������������������������������������������������������������������          
/*          
-----------------------------------------------------------------------------          
Nro  FECHA  USUARIO  DESCRIPCION          
-----------------------------------------------------------------------------          
@1	10.09.2019 Hmora	Se agrega configuraci�n Escuela
@2	25.09.2019 Hmora	Se agrega configuraci�n Escuela nuevo sp
@3  20.03.2020 Rsamame  Se quito del where  IdSubTipo   
@4	17.10.2023 Alsanchez Se agrega logica de diferenciacion de precio
@5	14.11.2023	MBUENO	Se pone en null IdPrecioSede
*/    
--CREATE procedure [dbo].[cMatricula_Pro_CargaHabil_TrasladoSede](
declare
@pIdEmpresa INT,  
																@pIdSede INT,  
																@pIdPeriodo INT,  
																@pIdAlumno INT,  
																@pIdUsuarioCreacion INT,
																@SoloInvicto VARCHAR(1), --indica si solo se procesar�n solo alumnos que no desaprobaron cursos   
																@IdPrecioSede INT = NULL,--@4 --@5
																@pEstado VARCHAR(2) ,  
																@pDescripcion VARCHAR(1000) 
--AS  
BEGIN  

select @pIdEmpresa=1,@pIdSede=40,@pIdPeriodo=3805,@pIdAlumno=1320774,@pIdUsuarioCreacion=446639,
@SoloInvicto=0,@IdPrecioSede=null
 DECLARE  
   @IdProductoAnterior INT,   
   @IdProductoNueva INT,   
   @IdCurriculaAnterior INT,   
   @IdCurriculaNueva INT,  
   @IdMatricula INT,  
   @IdRegistro INT,  
   @IdModuloOrigen INT,  
   @IdCurricula INT,  
   @TipoCurricula INT, 
   @IdSedeAnterior INT,
   @EstadoMatricula varchar(1),
   @IdUnidadAcademicaNueva INT, --@1
   @IdUnidadAcademicaAnterior INT  --@1
  
 -- comparamos los productos y curriculas para ver si son iguales  
 select @IdProductoAnterior =TS.IdProductoAnterior,     
 @IdProductoNueva = TS.IdProductoNueva,    
 @IdCurriculaAnterior = TS.IdCurriculaAnterior,    
 @IdCurriculaNueva = TS.IdCurriculaNueva,  
 @IdSedeAnterior =  TS.IdSedeOrigen, 
 @IdUnidadAcademicaAnterior=P.IdUnidadAcademica,  --@1
 @IdUnidadAcademicaNueva=TS.IdUnidadAcademica --@1
 from TrasladoSede TS WITH(NOLOCK)
 inner join Periodo P WITH(NOLOCK) ON TS.IdPeriodoAnterior=P.IdPeriodo  --@1
 where TS.IdEmpresa = @pIdEmpresa    
 and TS.IdSede = @pIdSede  
 and TS.IdPeriodoTraslado = @pIdPeriodo    
 and TS.IdAlumno = @pIdAlumno    
 and TS.Estado = 1 
   


 IF @IdProductoAnterior = @IdProductoNueva AND  
    @IdCurriculaAnterior = @IdCurriculaNueva   
    BEGIN  
		  select TOP 1 @IdMatricula= ma.IdMatricula,   
		  @IdRegistro = ma.IdRegistro,  
		  @IdModuloOrigen = ma.IdModulo,  
		  @IdCurricula = ma.IdCurricula,  
		  @TipoCurricula = PR.EsNuevo  
		  from Matricula MA WITH(NOLOCK) 
		  INNER JOIN Registro RE  WITH(NOLOCK)
		  ON MA.IdRegistro = RE.IdRegistro  
		  AND MA.IdActor = RE.IdActor  
		  INNER JOIN PRODUCTO PR  
		  ON PR.IdProducto = RE.IdProducto  
		  where MA.IdEmpresa = @pIdEmpresa  
		  AND MA.IdSede = @IdSedeAnterior  
		  AND MA.IdActor = @pIdAlumno  
		  AND MA.Estado ='N'
		  and MA.EsMatricula = 1  
		  --AND PR.IdSubTipo = 1 @3  
		  AND PR.IdProducto = @IdProductoNueva  
		  ORDER BY ma.idmodulo desc ,ma.IdMatricula DESC  
		  
		  -- CASO DE ALUMNO DE PRIMER CICLO RETIRADO DE PRIMER CICLO
		  if @IdMatricula is null   
			BEGIN
				  select TOP 1 @IdMatricula= ma.IdMatricula,   
				  @IdRegistro = ma.IdRegistro,  
				  @IdModuloOrigen = ma.IdModulo,  
				  @IdCurricula = ma.IdCurricula,  
				  @TipoCurricula = PR.EsNuevo,
				  @EstadoMatricula = ma.Estado  
				  from Matricula MA  WITH(NOLOCK)
				  INNER JOIN Registro RE  WITH(NOLOCK)
				  ON MA.IdRegistro = RE.IdRegistro  
				  AND MA.IdActor = RE.IdActor  
				  INNER JOIN PRODUCTO PR  WITH(NOLOCK)
				  ON PR.IdProducto = RE.IdProducto  
				  where MA.IdEmpresa = @pIdEmpresa  
				  AND MA.IdSede = @IdSedeAnterior  
				  AND MA.IdActor = @pIdAlumno  
				  --AND MA.Estado = 'N'  
				  and MA.EsMatricula = 1  
				  --AND PR.IdSubTipo = 1  @3
				  AND PR.IdProducto = @IdProductoNueva  
				   and ma.IdCurricula = @IdCurriculaNueva --@1 lperales
				  ORDER BY ma.idmodulo desc ,ma.IdMatricula DESC
				  
				  
				  if @EstadoMatricula ='R'
							  PRINT 'cMatricula_Pro_CargaHabil_ReingresoEspecial'
							  select @pIdEmpresa,  
															  @pIdSede,  
															  @pIdPeriodo,  
															  @pIdAlumno,  
															  @IdMatricula,       
															  @IdCurricula, -- curricula actual        
															  @IdRegistro,         
															  @IdModuloOrigen, -- modulo origen        
															  @TipoCurricula, -- si es curricula antigua 1 nueva 1 o 0 dependiendo el valor de la tabla producto esnuevo        
															  @pIdUsuarioCreacion, -- usuario que ejecuta el proceso  
															  @IdPrecioSede,--@4
															  @pEstado OUT,        
															  @pDescripcion  OUT   
			END
		 else     
				-- buscamos su ultima matricula y hacemos lo mismo que un regular  
			   PRINT 'cMatricula_Pro_CargaHabil'
			   select @pIdEmpresa,  
											  @pIdSede,  
											  @pIdPeriodo,  
											  @pIdAlumno,        
											  @IdMatricula, -- matricula anterior        
											  @IdCurricula, -- curricula actual        
											  @IdRegistro,         
											  @IdModuloOrigen, -- modulo origen        
											  @TipoCurricula, -- si es curricula antigua 1 nueva 1 o 0 dependiendo el valor de la tabla producto esnuevo        
											  @pIdUsuarioCreacion, -- usuario que ejecuta el proceso  
											  'TS',
											  @SoloInvicto,
											  @IdPrecioSede,--@4 --@5
											  @pEstado OUT,        
											  @pDescripcion  OUT     
    END  
 ELSE  
	BEGIN
		IF @IdUnidadAcademicaNueva=@IdUnidadAcademicaAnterior  --@1
		-- hacemos lo que hace el cambio de carrera    
			BEGIN    
			  PRINT 'cAlumnoCurso_Pro_CargaHabil_CambioSedeCurricula'
			  select @pIdEmpresa,    
					   @pIdSede,    
					   @pIdPeriodo,    
					   @pIdAlumno,    
					   @pIdUsuarioCreacion,    
					   'TS',   
					   --@IdPrecioSede,--@4
					   @pEstado OUTPUT,    
					   @pDescripcion OUTPUT    
			END
		ELSE
		-- Cambios Escuela		   
			BEGIN    
			  PRINT 'cAlumnoCurso_Pro_CargaHabil_CambioEscuela'
			  select @pIdEmpresa,   --@2 
					   @pIdSede,    
					   @pIdPeriodo,    
					   @pIdAlumno,    
					   @pIdUsuarioCreacion,    
					   'CI',  
					   @IdPrecioSede,--@4
					   @pEstado OUTPUT,    
					   @pDescripcion OUTPUT    
			END			
	END  
END 
