SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=643903


SELECT TipoCondicion,*FROM AlumnoCurso 
--UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=643903 AND EsMatricula=1

--SELECT DISTINCT TipoCondicion  FROM Matricula