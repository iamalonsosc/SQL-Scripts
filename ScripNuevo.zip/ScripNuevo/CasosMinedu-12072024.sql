--RUIZ ORTEGA RITA GABRIELA

UPDATE AlumnoCursoNomina SET SeccionNomina= NULL
WHERE SeccionNomina='216.IV.01.2024-I-IV-B' AND IdActor=1361804
--(3 rows affected)

--HUAMANI PONCE RICKSON NEIDER

UPDATE AlumnoCursoNomina SET SeccionNomina= NULL
WHERE SeccionNomina='208.VI.08.2024-I-VI-F' AND IdActor=1299937
--(1 row affected)

--DIONICIO REMENTERIA GLADYS ESTEFANY

UPDATE AlumnoCursoNomina SET SeccionNomina= NULL
WHERE SeccionNomina='212.IV.04.2024-I-IV-E' AND IdActor=1281387
--(1 row affected)

--ARROYO CHUAN KEVIN ALONSO

UPDATE AlumnoCursoNomina SET SeccionNomina= NULL
WHERE SeccionNomina='219.IV.02.2024-I-IV-B' AND IdActor=1240963
--(1 row affected)

UPDATE AlumnoCursoNomina SET SeccionNomina= NULL
WHERE SeccionNomina='219.VI.02.2024-I-VI-B' AND IdActor=1240963
--(1 row affected)