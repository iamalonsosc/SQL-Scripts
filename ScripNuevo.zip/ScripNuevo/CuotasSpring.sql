DECLARE
@IdMatricula int= 499802,  
@CompaniaSocio CHAR(8)= '00002700'                       
                                       
BEGIN  
	--INICIO @4
	DECLARE @Valor varchar(800), @Valor2 varchar(800) ,@valor3 varchar(800)
	
	SELECT	@Valor = Valor, @valor2 = Valor2 , @Valor3 = Valor3  
	FROM ParametroEmpresa PE WITH (NOLOCK)
	INNER JOIN Empresa E WITH (NOLOCK)
	ON E.IdEmpresa = PE.IdEmpresa
	WHERE CompaniaSocio=@CompaniaSocio
	AND nombre='DESCUENTOSCUOTASPAGO'
	--FIN @4   
                       
	SELECT   
		C.CuotaNumero,                        
		'CuotaNumeroNombre' = CASE WHEN C.CuotaNumero = 1 THEN 'MATR�CULA'   
		WHEN C.CuotaNumero = 2 THEN 'CUOTA 1'  
		WHEN C.CuotaNumero = 3 THEN 'CUOTA 2'  
		WHEN C.CuotaNumero = 4 THEN 'CUOTA 3'  
		WHEN C.CuotaNumero = 5 THEN 'CUOTA 4'  
		WHEN C.CuotaNumero = 6 THEN 'CUOTA 5'  
		WHEN C.CuotaNumero = 7 THEN 'CUOTA 6'  
		WHEN C.CuotaNumero = 8 THEN 'CUOTA 7'
		WHEN C.CuotaNumero = 9 THEN 'CUOTA 8' --@5
		WHEN C.CuotaNumero = 10 THEN 'CUOTA 9' --@5
		WHEN C.CuotaNumero = 11 THEN 'CUOTA 10' --@5
		WHEN C.CuotaNumero = 12 THEN 'CUOTA 11' --@5
		ELSE '' END   ,                    
		'FechaVencimiento'=dbo.fecha(c.FechaVencimiento),                        
		'Estado'= CASE C.Estado           
		WHEN 'PF' THEN 'POR FACTURAR'           
		WHEN 'AN' THEN 'ANULADO'         
		WHEN 'GE' THEN 'GENERADO'         
		WHEN 'PR' THEN 'FACT-SPRING'         
		WHEN 'CO' THEN  'COBRADO' --'COBRADO EN SPRING'         
		ELSE '' END,        
		'Monto'= ISNULL(SUM(CD.monto),''), --@6    
		'MontoPagado'=ISNULL(CO.MontoPagado,'') , --@10
		-- INICIO @1  
		'InterfaseGrupodescuento' = ISNULL(C.Grupodescuento,-1),  
		'InterfaseEstado' = ISNULL(C.Estado,''),  
		'NumeroDocumento' = ISNULL(C.NumeroDocumento,''),  
		'IdDescuentoAcademico' = ISNULL(DAR.IdDescuentoAcademico,-1) ,  
		'GrupoDescuento' = ISNULL(DAR.GrupoDescuento,-1),  
		'DescuentoPorcentaje' = CASE WHEN CAST ( ISNULL(DAR.Porcentaje,0.00) AS DECIMAL(5,2) ) = 0.00    
		--THEN 10.00   
		THEN @Valor --@4
		ELSE  CASE WHEN ISNULL(DAC.Porcentaje,0.00) = 0   
		THEN CAST( ISNULL(DA.Disponible2,ISNULL(DA.Porcentaje,0.00)) AS DECIMAL(5,2))   
		ELSE DAC.Porcentaje   
		END    
		END ,  
		'DescuentoPorcentajeTexto' =  CASE WHEN ISNULL(CAST (DAR.Porcentaje as VARCHAR(8)),'') = ''    
		--THEN '10.00 %'   
		THEN @Valor2  --@4
		ELSE CASE WHEN ISNULL(DAC.Porcentaje,0.00) = 0   
		THEN ISNULL(DA.Disponible2,ISNULL(CAST (DA.Porcentaje AS VARCHAR(8)),''))  + ' %'   
		ELSE CAST (DAC.Porcentaje AS VARCHAR(8))   
		END   
		END,  
		'DescuentoNombre' =  CASE WHEN ISNULL(cast (DAR.Porcentaje as VARCHAR(8)),'') = ''    
		--THEN 'DESCUENTO POR PPPM'  
		THEN @Valor3  --@4
		ELSE CASE WHEN ISNULL(DAC.Porcentaje,0.00) = 0.0000   
		THEN ISNULL(DAR.DescuentoNombre,'')   
		ELSE DAC.Nombre   
		END   
		END   ,
		-- FIN @1  
		'NumeroInterno' = CD.NumeroInterno, --@3
		'MontoHomologado'= ISNULL(SUM(ISNULL(P.MontoHomologado,CD.monto)),''), --@6--@7--@8
		'DescuentoPorcentajeLista'=ISNULL(DAR.PorcentajeRegular,0.00) --@6
	FROM  PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header C WITH(NOLOCK)          
	INNER JOIN CO_Interfase_P09_Detalle CD WITH(NOLOCK) ON C.TipoDocumento = CD.TipoDocumento AND C.NumeroInterno = CD.NumeroInterno       
	LEFT JOIN  CO_Documento AS CO WITH (NOLOCK) ON C.IdMatricula=co.Interfase_Matricula AND c.CuotaNumero = co.Interfase_Cuota AND CO.TIPODOCUMENTO IN ('BV','FC') AND co.estado <>'AN' AND CO.CompaniaSocio=CD.CompaniaSocio --@2  
	--INICIO @1   
	LEFT JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON DAR.IdMatricula = C.IdMatricula  AND DAR.Cuota = C.CuotaNumero  AND ISNULL(C.Grupodescuento,-1) = DAR.GrupoDescuento --@9  
	LEFT JOIN DescuentoAcademico DA WITH(NOLOCK) ON  DA.IdDescuentoAcademico = DAR.IdDescuentoAcademico   
	LEFT JOIN DescuentoAcademicoCuota DAC WITH(NOLOCK) ON DAC.IdDescuentoAcademico = DA.IdDescuentoAcademico  AND DAC.Cuota = DAR.Cuota                              
	--FIN @1
	LEFT JOIN PLDB01.SpringUnido.dbo.CO_Precio P WITH(NOLOCK) ON P.ItemCodigo=CD.ItemCodigo AND P.UnidadNegocio=C.Sucursal AND P.TipoFacturacion=CASE WHEN CD.ItemCodigo LIKE '%C%' THEN 'CON' ELSE C.TipoFacturacion END AND P.TipoCliente=C.TipoCliente AND P.CompaniaSocio = C.CompaniaSocio --@6
	WHERE C.IdMatricula=@IdMatricula            
	AND C.Estado not in ('EL','TR')      
	AND C.TIPODOCUMENTO IN ('BV','FC')     
	AND C.CompaniaSocio=@CompaniaSocio  --@2  
	AND CD.CompaniaSocio=@CompaniaSocio --@2  
	GROUP BY  CuotaNumero,                        
	dbo.fecha(c.FechaVencimiento),                        
	C.Estado , DAR.Porcentaje,DA.Porcentaje,DA.Disponible2, DAR.DescuentoNombre , DAC.Porcentaje,DAC.Nombre,  
	C.Grupodescuento,C.Estado,C.NumeroDocumento,DAR.IdDescuentoAcademico ,DAR.GrupoDescuento, CD.NumeroInterno,
	DAR.EsHomologado,DAR.PorcentajeRegular,CO.MontoPagado --@6 --@10
	ORDER BY C.CuotaNumero
END