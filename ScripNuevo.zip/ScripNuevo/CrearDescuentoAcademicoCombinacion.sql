DECLARE @MAX INT
,@MIN INT
,@Grupospring VARCHAR(500)
,@TNombre VARCHAR(500)
,@TPorcentaje VARCHAR(500)
,@TCuota VARCHAR(500)
,@TDisponible2 VARCHAR(500)
,@TDisponible3 VARCHAR(500)
,@TIdDescuentoAcademico INT
,@CompaniaSocio VARCHAR(8)
,@NombreArea VARCHAR(500)
,@RetVal INT
,@TPrecio INT
,@GrupoSmart VARCHAR(500)
,@IdTipo INT
,@UnidadAcademica INT
,@IdUnidadNegocio INT

DECLARE @TABLE TABLE (ID INT IDENTITY(1,1)
,Grupospring VARCHAR(500)
,Nombre VARCHAR(500)
,Porcentaje DECIMAL(6,4)
,Cuota INT
,Disponible2 VARCHAR(100)
,Disponible3 VARCHAR(500)
,Precio VARCHAR(500)
,UnidadAcademica INT
,UnidadNegocio INT
,GrupoSmart VARCHAR(500))

--cuota 1
--=CONCATENAR("INSERT INTO @TABLE VALUES("; I2; ",'"; G2; "',"; L2; ","; SI(J2="CUOTA 1";2;SI(J2="CUOTA 2";3;J2)); ",'"; L2; "','"; G2 & "-" & K2; "','"; E2; "',60,1,"; SI(J2="CUOTA 1";A2;SI(J2="CUOTA 2";C2;"")); ")")

BEGIN
--INSERT INTO @TABLE VALUES(3827,'30% C2 + 50 SOLES CAMPA�A',39.1700,3,'39.1700','30% C2 + 50 SOLES CAMPA�A-190538195453827CUOTA 2','545',60,1,3819)
INSERT INTO @TABLE VALUES(3833,'20% C1 + 50 SOLES CAMPA�A',28.8500,2,'28.8500','20% C1 + 50 SOLES CAMPA�A-335653833CUOTA 1','565',60,1,3)
INSERT INTO @TABLE VALUES(3834,'25% C1 + 50 SOLES CAMPA�A',36.1400,2,'36.1400','25% C1 + 50 SOLES CAMPA�A-383238324493834CUOTA 1','449',60,1,3832)
INSERT INTO @TABLE VALUES(3801,'25% C2 + 50 SOLES CAMPA�A',36.1400,3,'36.1400','25% C2 + 50 SOLES CAMPA�A-190538314493801CUOTA 2','449',60,1,3831)
INSERT INTO @TABLE VALUES(3766,'50% C2 + 50 SOLES CAMPA�A',58.5500,3,'58.5500','50% C2 + 50 SOLES CAMPA�A-190538295853766CUOTA 2','585',60,1,3829)
INSERT INTO @TABLE VALUES(3768,'50% C2 + 50 SOLES CAMPA�A',58.8500,3,'58.8500','50% C2 + 50 SOLES CAMPA�A-190538295653768CUOTA 2','565',60,1,3829)
INSERT INTO @TABLE VALUES(3775,'50% C2 + 50 SOLES CAMPA�A',62.0500,3,'62.0500','50% C2 + 50 SOLES CAMPA�A-190538294153775CUOTA 2','415',60,1,3829)
INSERT INTO @TABLE VALUES(3767,'50% C2 + 50 SOLES CAMPA�A',58.7000,3,'58.7000','50% C2 + 50 SOLES CAMPA�A-190538295753767CUOTA 2','575',60,1,3829)
INSERT INTO @TABLE VALUES(3771,'50% C2 + 50 SOLES CAMPA�A',60.3100,3,'60.3100','50% C2 + 50 SOLES CAMPA�A-190538294853771CUOTA 2','485',60,1,3829)
INSERT INTO @TABLE VALUES(3772,'50% C2 + 50 SOLES CAMPA�A',60.5300,3,'60.5300','50% C2 + 50 SOLES CAMPA�A-190538294753772CUOTA 2','475',60,1,3829)
INSERT INTO @TABLE VALUES(3770,'50% C2 + 50 SOLES CAMPA�A',59.1700,3,'59.1700','50% C2 + 50 SOLES CAMPA�A-190538295453770CUOTA 2','545',60,1,3829)

END
--SELECT*FROM @TABLE
--RETURN

SELECT @CompaniaSocio=CompaniaSocio FROM Empresa
SELECT @IdTipo = IdMaestroRegistro FROM MaestroTablaRegistro WHERE Codigo='DESVALENCIA'


SELECT @MIN = MIN(ID), @MAX = MAX(ID) from @TABLE

WHILE @MIN <= @MAX
BEGIN

	SET @Grupospring = NULL 
	SET @TNombre=NULL
	SET @TPorcentaje=NULL
	SET @TCuota=NULL
	SET @TDisponible2 = NULL
	SET @TDisponible3= NULL
	SET @TIdDescuentoAcademico = NULL
	SET @TPrecio=NULL
	SET @GrupoSmart=NULL
	SET @UnidadAcademica =NULL
	SET @IdUnidadNegocio =NULL

	SELECT 
	@Grupospring=Grupospring
	,@TNombre=Nombre
	,@TPorcentaje=Porcentaje
	,@TCuota=Cuota
	,@TDisponible2=Disponible2
	,@TDisponible3=Disponible3
	,@TPrecio=Precio
	,@GrupoSmart=GrupoSmart
	,@UnidadAcademica=UnidadAcademica
	,@IdUnidadNegocio=UnidadNegocio
	FROM @TABLE WHERE ID = @Min
	

	SELECT TOP 1 @NombreArea=MA_M.DescripcionLocal 
	FROM X_CO_Descuento CO_D WITH (NOLOCK)  
	INNER JOIN PLDB01.SpringUnido.dbo.MA_MaestroMiscelaneoDetalle MA_M WITH (NOLOCK)ON MA_M.MaestroCodigo = 'P203AREA  ' AND  MA_M.ValorCodigo = CO_D.Area    
	WHERE CompaniaSocio = @CompaniaSocio  --@1  
	AND CO_D.Estado = 'A'   
	AND ( CO_D.Descripcion LIKE '%' + @Grupospring + '%'  OR  GrupoDescuento LIKE '%' + @Grupospring + '%' )  


--PERIODO ESCUELA 2025-III
EXECUTE cDescuentoAcademicoCombinacion_Ins_Grabar
@Porcentaje = @TPorcentaje,
@Monto = @TPrecio,
@GrupoDescuento = @GrupoSmart,
@CantidadReferidos = 1,
@GrupoCombinacion = @Grupospring,
@Area = 57,
@TipoDocumento = '',
@Campana ='2025-III',
@IdTipo=@IdTipo,
@IdUnidadNegocio=@IdUnidadNegocio,
@CuotaNumero=@TCuota

--PERIODO CCM 2025-III
EXECUTE cDescuentoAcademicoCombinacion_Ins_Grabar
@Porcentaje = @TPorcentaje,
@Monto = @TPrecio,
@GrupoDescuento = @GrupoSmart,
@CantidadReferidos = 1,
@GrupoCombinacion = @Grupospring,
@Area = @UnidadAcademica,
@TipoDocumento = '',
@Campana ='2025-III',
@IdTipo=@IdTipo,
@IdUnidadNegocio=@IdUnidadNegocio,
@CuotaNumero=@TCuota

--PERIODO ESCUELA 2025-IIIA
EXECUTE cDescuentoAcademicoCombinacion_Ins_Grabar
@Porcentaje = @TPorcentaje,
@Monto = @TPrecio,
@GrupoDescuento = @GrupoSmart,
@CantidadReferidos = 1,
@GrupoCombinacion = @Grupospring,
@Area = 57,
@TipoDocumento = '',
@Campana ='2025-IIIA',
@IdTipo=@IdTipo,
@IdUnidadNegocio=@IdUnidadNegocio,
@CuotaNumero=@TCuota

--PERIODO CCM 2025-IIIA
EXECUTE cDescuentoAcademicoCombinacion_Ins_Grabar
@Porcentaje = @TPorcentaje,
@Monto = @TPrecio,
@GrupoDescuento = @GrupoSmart,
@CantidadReferidos = 1,
@GrupoCombinacion = @Grupospring,
@Area = @UnidadAcademica,
@TipoDocumento = '',
@Campana ='2025-IIIA',
@IdTipo=@IdTipo,
@IdUnidadNegocio=@IdUnidadNegocio,
@CuotaNumero=@TCuota


--exec cDescuentoAcademico_Ins_Grabar 
--@Codigo=@Grupospring
--,@Nombre=@TNombre
--,@Porcentaje=@TPorcentaje
--,@FechaInicio=N'30/04/2025 10:26:49'
--,@FechaFin=N'01/05/2026 10:26:49'
--,@NroPeriodo=1
--,@EsAcumulativo=0
--,@DiasVigentes=0
--,@EsProntoPago=0
--,@EsContado=0
--,@IdTipo=24965--D) AUTOGENERADO
--,@Campana=N'2025'
--,@Area=@NombreArea
--,@Disponible1=N'AMBOS'
--,@Disponible2=@TDisponible2
--,@Disponible3=@TDisponible3
--,@Disponible4=N''
--,@Disponible5=N''
--,@Activo=1
--,@UsuarioCreacion=446639
--,@ExcluirTodo=0
--,@ExcluirCuota=0
--,@EsForzado=0
--,@EsSinVencimiento=0
--,@EsTransGratuita=0
--,@EsGratuita=0
--,@OfertaAlumno=N''
--,@RetVal=@TIdDescuentoAcademico OUTPUT

--exec cDescuentoAcademicoCuota_Ins_Grabar @IdDescuentoAcademico=@TIdDescuentoAcademico
--,@Cuota=@TCuota
--,@Codigo=0
--,@Nombre=N''
--,@Porcentaje=0.0000
--,@Area=N''
--,@Activo=1
--,@UsuarioCreacion=446639
--,@RetVal=@RetVal 

	SET @Min=@Min+1
END