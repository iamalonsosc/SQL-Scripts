exec cRequisitoPrecio_InsGrabar @IdMatricula=599955,@CompaniaSocio=N'00002700',@Monto=N'600',
@Matricula=N'500',@TipoFacturacion=N'Q',@NumeroCuotas=5,@Estado=N'PR',@UsuarioCreacion=446639,@Observacion=N'PRUEBA TI'
--
 