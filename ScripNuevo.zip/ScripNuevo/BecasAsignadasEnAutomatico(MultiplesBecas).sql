--23960	1905	BECAEC_100	NULL	BECA SOCIOEN�MICA 100%
--24936	1905	BECAEC_50	NULL	BECA SOCIOEN�MICA 50%
--24937	1905	BECAEC_25	NULL	BECA SOCIOEN�MICA 25%
--24938	1905	MERITO25	NULL	BECA AL MERITO 25%
--24939	1905	MERITO50	NULL	BECA AL MERITO 50%
--24940	1905	EXCELENCIA	NULL	BECA A LA EXCELENCIA 50%
--27641	1905	PRONAB100	NULL	BECA PRONABEC TOTAL 100%
--27642	1905	PRONAB80	NULL	BECA PRONABEC 80%
--27666	1905	EXCELE15	NULL	BECA A LA EXCELENCIA 15%
--27667	1905	EXECELE25	NULL	BECA A LA EXCELENCIA 25%
--24734	1905	TIPALRPC	NULL	ALUMNOS CON CONVENIOS EN EMPRESAS - MATRICULA ES CONVENIO
--ENVIAR A PDF Y XML

--BECA AL MERITO Y EXCELENCIA
SELECT AL.CodigoAnterior,A.NombreCompleto,A.NumeroIdentidad,MTR.Codigo,MTR.Nombre,PRO.PromocionNombre,PE.Codigo FROM DescuentoAcademicoBase DAB
INNER JOIN Actor A ON A.IdActor=DAB.IdActor
INNER JOIN Alumno AL ON AL.IdAlumno=A.IdActor
INNER JOIN Matricula MA ON MA.IdActor=A.IdActor
INNER JOIN Promocion PRO ON PRO.IdPromocion=MA.IdPromocion
INNER JOIN Periodo PE ON PE.IdPeriodo=PRO.IdPeriodo
INNER JOIN MaestroTablaRegistro MTR ON MTR.IdMaestroRegistro=DAB.IdMaestroRegistro
WHERE DAB.IdMaestroRegistro IN (24938,24939,24940,27666,27667)
AND DAB.PeriodoCodigo='2026-III'
AND PE.IdUnidadNegocio=1
AND PE.IdUnidadAcademica IN(57)
AND MA.Estado <> 'X'
--AND MA.EsMatricula=1

--BECAS POR CONVENIO
select AL.CodigoAnterior,AC.NombreCompleto,ac.NumeroIdentidad,p.PromocionNombre,PE.Codigo   from Matricula m
inner join Promocion p on p.IdPromocion = m.IdPromocion 
inner join Periodo pe on pe.IdPeriodo = p.IdPeriodo 
INNER JOIN Actor AC ON AC.IdActor = M.IdActor 
INNER JOIN Alumno AL ON AL.IdAlumno = AC.IdActor 
where pe.Codigo = '2024-III' and pe.IdUnidadAcademica = 57 and m.Estado <> 'X'
AND M.IdConvenio IS NOT NULL



--BECA INTERCORP
SELECT  DISTINCT  AL.CodigoAnterior,AC.NombreCompleto,ac.NumeroIdentidad,d.Nombre,p.PromocionNombre,PE.Codigo    FROM 
Matricula M  
INNER JOIN Promocion P ON P.IdPromocion = M.IdPromocion 
INNER JOIN Periodo PE ON PE.IdPeriodo = P.IdPeriodo 
INNER JOIN Actor AC ON AC.IdActor = M.IdActor 
INNER JOIN Alumno AL ON AL.IdAlumno = AC.IdActor  
INNER JOIN DescuentoAlumnoResultado R ON R.IdMatricula = M.IdMatricula 
INNER JOIN DescuentoAcademico  D ON D.IdDescuentoAcademico = R.IdDescuentoAcademico 
INNER JOIN intercorpactor  ia ON ia.NumeroIdentidad = ac.NumeroIdentidad
 WHERE AL.IdAlumno IN (
select IdActor  from Matricula m
inner join Promocion p on p.IdPromocion = m.IdPromocion 
inner join Periodo pe on pe.IdPeriodo = p.IdPeriodo 
where pe.Codigo = '2024-III' and pe.IdUnidadAcademica = 57 and m.Estado <> 'X')
AND PE.Codigo IN ('2024-II','2024-IIA','2024-IIB','2024-IIC')
AND D.Nombre LIKE '%INTER%'


--BECA Socio Economica
SELECT AL.CodigoAnterior,AC.NombreCompleto,ac.NumeroIdentidad,MTR.Nombre,p.PromocionNombre,PE.Codigo FROM SolicitudBeca SB
INNER JOIN Matricula M ON M.IdMatricula = SB.IdMatricula 
INNER JOIN Promocion P ON P.IdPromocion = M.IdPromocion 
INNER JOIN Periodo PE ON PE.IdPeriodo = P.IdPeriodo 
INNER JOIN Actor AC ON AC.IdActor = M.IdActor 
INNER JOIN Alumno AL ON AL.IdAlumno = AC.IdActor 
INNER JOIN MaestroTablaRegistro MTR ON MTR.IdMaestroRegistro =  SB.IdEstado 
 WHERE AL.IdAlumno IN (
select IdActor  from Matricula m
inner join Promocion p on p.IdPromocion = m.IdPromocion 
inner join Periodo pe on pe.IdPeriodo = p.IdPeriodo 
where pe.Codigo = '2024-III' and pe.IdUnidadAcademica = 57 and m.Estado <> 'X')
AND PE.Codigo IN ('2024-II','2024-IIA','2024-IIB','2024-IIC')
AND MTR.Nombre NOT IN ('CANCELADO','RECHAZADO FINAL', 'RECHAZADO')
