--����������������������������������������������������������������������������            
--Creado por      : Fabrizzio Martinez Campos (14/05/2024)            
--Funcionalidad   :   
--Utilizado por   :  
--����������������������������������������������������������������������������       
/*                            
-----------------------------------------------------------------------------                            
Nro	FECHA		USUARIO		DESCRIPCION                  
@1	30/01/2025	RAlcantara	Se agregan nuevos campos para el proceso de nominas de JSON minedu
@2	03/10/2025	Illosad		Se agrega turno MA�ANA/NOCHE en case de turnos 
@3	20/10/2025	Illosad		Se agrega SeccionNomina en las validaciones
@4	27/01/2026	Alsanchez	Se agrega los campos necesarios a usar en el insert
@5	10/03/2026		Alsanchez		Se modifica el id del PASAPORTE
-----------------------------------------------------------------------------   

*/ 
ALTER PROCEDURE [dbo].[cProcesa_Acta_JSON_Minedu]
@IdPeriodoNomina int,
@IdEmpresa int,
@IdSedeNomina int,
@IdUnidadAcademicaNomina INT,
@IdUnidadNegocioNomina INT,
@IdProductoNomina INT,
@IdUsuario INT	--@3
AS
BEGIN
SET NOCOUNT ON
	
declare @cmodular NVARCHAR(30),
@usuarioMinedu NVARCHAR(100) ,
@claveMinedu NVARCHAR(100),
@CompaniaSocio varchar(20)

select @CompaniaSocio=CompaniaSocio from Empresa WITH(NOLOCK) where Activo = 1

SELECT DISTINCT @cmodular = ISNULL(Valor10 ,'')  
	FROM ParametroUnidadAcademica WITH(NOLOCK)  
	WHERE IdEmpresa= @IdEmpresa    
	AND IdUnidadNegocio = @IdUnidadNegocioNomina  
	AND IdUnidadAcademica = @IdUnidadAcademicaNomina  
	AND IdSede = @IdSedeNomina   
	AND (IdProducto = @IdProductoNomina OR @IdProductoNomina = 0)  
	AND Nombre='ParametroNomina1' 

IF @CompaniaSocio = '00002500' or @CompaniaSocio = '00002400'
BEGIN
	SELECT @claveMinedu = Valor,@usuarioMinedu=Valor3 FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular
END
ELSE IF @CompaniaSocio = '00002700'
BEGIN
	SELECT @usuarioMinedu=ISNULL(Valor2,Valor) FROM parametro WITH(NOLOCK) WHERE  Nombre='UsuarioMinedu'
	SELECT @claveMinedu = Valor FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular
END

--@4 INICIO
insert into AlumnoCursoActaJson
(
UsuarioMinedu,
ClaveMinedu,
PeriodoCodigo,
PeriodoCodigoMinedu,
CModular,
NombreSede,
NivelFormativo,
ProductoNombre,
NombrePlanEstudio,
ModuloNombre,
Turno,
Seccion,
SeccionMinedu,
TipoDocumento,
NumeroDocumento,
NombreAlumno,
Genero,
ActorEdad,
Discapacidad,
CursoNombre,
CursoNombreOficial,
Nota,
EstadoCurso,
EstadoPromovido,
EstadoMatricula,
IdActa,
IdSede,
IdCurso,
IdProducto,
IdCurricula,
IdAlumno,
IdMatricula,
IdPeriodo,
IdPromocion,
IdUnidadAcademica,
IdUnidadNegocio,
IdUsuario,
FechaCreacion,
Observaciones,
apellido_paterno,
apellido_materno,
Nombres,
fecha_nacimiento,
fecha_ingreso,
SeccionNominaMinedu
)
--@4 FIN
select 
'UsuarioMinedu'=@usuarioMinedu
,'ClaveMinedu'=@claveMinedu
,PeriodoCodigo
,'PeriodoCodigoMinedu' = PE.CodigoMinedu--falta agregar el nuevo campo de mgarriazo
,ISNULL(ENE.CodModularDestino,PUA.Valor10)
,'nombreSede' = CASE @CompaniaSocio 
					WHEN '00002500' THEN CASE ISNULL(SE.IdSede,S.IdSede) WHEN 49 THEN 'VIRTUAL' ELSE ISNULL(SE.SedeNombreMinedu,ISNULL(S.SedeNombreMinedu,'')) END
					ELSE ISNULL(SE.SedeNombreMinedu,ISNULL(S.SedeNombreMinedu,'')) END --@1
--,'nombreSede' = ISNULL(SE.Nombre,S.Nombre)
,'NivelFormativo'=PUA.Valor4
,ProductoNombre
,CU.NombrePlanEstudio
,ModuloNombre
,turno=CASE AC.TurnoNombre  WHEN 'MADRUGADOR' THEN 'MA�ANA'
		WHEN 'DIURNO' THEN 'MA�ANA'
		WHEN 'DIURNA' THEN 'MA�ANA'
		WHEN 'NOCTURNO' THEN 'NOCHE'
		WHEN 'MA�ANA' THEN 'MA�ANA'		--@2
		WHEN 'NOCHE' THEN 'NOCHE'		--@2
		ELSE 'TARDE' END
,AC.Seccion
,'SeccionMinedu' = CASE WHEN ISNULL(ENE.CodigoSedeOrigen,'') =''
					THEN AC.Seccion
					ELSE  AC.Seccion + '-' + ENE.CodigoSedeOrigen
					END
,tipo_documento =CASE --@5
									WHEN idDocumentoTipo = 25 THEN 'D.N.I.'
									WHEN idDocumentoTipo = 27 THEN 'CARNET DE EXTRANJER�A'
									WHEN idDocumentoTipo = 30765 AND @CompaniaSocio = '00002500' THEN 'PASAPORTE' -- Zegel
									WHEN idDocumentoTipo = 27670 AND @CompaniaSocio = '00002700' THEN 'PASAPORTE' -- Idat
									ELSE 'PTP' END--@5
--CASE A.idDocumentoTipo  WHEN 25 THEN 'D.N.I.'
--				  WHEN 27 THEN 'CARNET DE EXTRANJER�A'
--				  WHEN 30765 THEN 'PASAPORTE'
--				  ELSE 'PTP' END
,'NumeroDocumento'=REPLACE(DNI,'''','')
,NombreAlumno
,Genero=CASE Sexo WHEN 'M' THEN 'MASCULINO' ELSE 'FEMENINO' END
,'ActorEdad'=ISNULL( DATEDIFF(day,A.FechaNacimiento, GETDATE()) / 365,0)
,'Discapacidad'=0
,C.CursoNombre
,AC.CursoNombreOficial
,'Nota'=CASE WHEN (select top 1 * from string_split(promediocurso,',')) not in ('''---','','DPI','---')
					THEN CAST(CAST(((select top 1 * from string_split(promediocurso,',')))AS decimal(10,2)) as integer)
					ELSE CAST(CAST(('0')AS decimal(10,2)) as integer)
					END
,EstadoCurso
,EstadoPromovido
,EstadoMatricula
,AC.IdActa
,AC.IdSede
,AC.IdCurso
,AC.IdProducto
,AC.IdCurricula
,AC.IdAlumno
,AC.IdMatricula
,AC.IdPeriodo
,AC.IdPromocion
,AC.IdUnidadAcademica
,AC.IdUnidadNegocio
,@IdUsuario	--@3
,GETDATE()
,dbo.cObtenerValidacionesMineduStr(ISNULL( DATEDIFF(day,A.FechaNacimiento, GETDATE()) / 365,0)
				,CASE AC.Sexo WHEN 'M' THEN 'MASCULINO' ELSE 'FEMENINO' END
				,A.numeroidentidad
				,CASE --@5
									WHEN idDocumentoTipo = 25 THEN 'D.N.I.'
									WHEN idDocumentoTipo = 27 THEN 'CARNET DE EXTRANJER�A'
									WHEN idDocumentoTipo = 30765 AND @CompaniaSocio = '00002500' THEN 'PASAPORTE' -- Zegel
									WHEN idDocumentoTipo = 27670 AND @CompaniaSocio = '00002700' THEN 'PASAPORTE' -- Idat
									ELSE 'PTP' END--@5
				--,CASE A.idDocumentoTipo  WHEN 25 THEN 'D.N.I.'
				--WHEN 27 THEN 'CARNET DE EXTRANJER�A'
				--WHEN 30765 THEN 'PASAPORTE'
				--ELSE 'PTP' END
				,CASE AC.TurnoNombre  WHEN 'MADRUGADOR' THEN 'MA�ANA'
				WHEN 'DIURNO' THEN 'MA�ANA'
				WHEN 'DIURNA' THEN 'MA�ANA'
				WHEN 'NOCTURNO' THEN 'NOCHE'
				WHEN 'MA�ANA' THEN 'MA�ANA'  --@2
				WHEN 'NOCHE' THEN 'NOCHE'	--@2
				ELSE 'TARDE' END
				,PUA.Valor4
				,ISNULL(SE.SedeNombreMinedu,iSNULL(S.SedeNombreMinedu,'')) --@1
				,CASE WHEN (select top 1 * from string_split(promediocurso,',')) not in ('''---','','DPI','---')
					THEN CAST(CAST(((select top 1 * from string_split(promediocurso,',')))AS decimal(10,2)) as integer)
					ELSE CAST(CAST(('0')AS decimal(10,2)) as integer)
					END
				,CModular
				,CU.NombrePlanEstudio
							--01 Inicio
				,PE.CodigoMinedu
				,A.nombres
				,A.Materno
				,A.Paterno
				,A.FechaNacimiento
				,dbo.cFechaIngresoActorProducto(A.IdActor,AC.IdProducto)
				,REVERSE(LEFT(REVERSE(AC.Seccion), CHARINDEX('-', REVERSE(AC.Seccion)) -1))
				--01 Fin
				,ac.Seccion --@3
				),
-- Inicio @1
A.Paterno,
A.Materno,
A.nombres,
A.FechaNacimiento,
dbo.cFechaIngresoActorProducto(A.IdActor,AC.IdProducto),
REVERSE(LEFT(REVERSE(AC.Seccion), CHARINDEX('-', REVERSE(AC.Seccion)) -1))
-- Fin @1
from Actaconsolidada AC WITH(NOLOCK) left join Sede S WITH(NOLOCK) on AC.IdSede = S.IdSede
--INNER JOIN Matricula M WITH (NOLOCK) on M.IdMatricula = AC.IdMatricula
--INNER JOIN PromocionGrupo PG WITH (NOLOCK) on PG.IdPromocion = M.IdPromocion and  PG.IdGrupo = M.IdGrupo
--INNER JOIN Turno T WITH (NOLOCK) ON PG.IdTurno = T.IdTurno    
--INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON T.IdTipoTurno = MTR.IdMaestroRegistro   
INNER JOIN Periodo PE  WITH (NOLOCK) ON AC.IdPeriodo=PE.IdPeriodo      
INNER JOIN PeriodoCabecera PEC WITH (NOLOCK) ON PE.IdPeriodoCabecera=PEC.IdPeriodoCabecera 
INNER join Curso C WITH(NOLOCK) on AC.IdCurso = C.IdCurso	--@3
INNER join Actor A WITH(NOLOCK) on AC.IdAlumno = A.IdActor	--@3
--INNER JOIN Matricula M WITH (NOLOCK) on M.IdMatricula = AC.IdMatricula And AC.IdAlumno = M.IdActor -- @1
INNER join Curricula CU WITH(NOLOCK) on AC.IdCurricula = CU.IdCurricula
LEFT JOIN EquivalenciaNominasEnvioJSON ENE WITH (NOLOCK)ON AC.IdSede = ENE.IdSedeOrigen AND AC.IdProducto = ENE.IdProducto AND PEC.Codigo = ENE.Periodo
LEFT JOIN Sede SE WITH (NOLOCK)ON ENE.IdSedeDestino = SE.IdSede
INNER JOIN ParametroUnidadAcademica PUA WITH (NOLOCK)	--@3
		ON  PUA.IdUnidadNegocio=AC.IdUnidadNegocio
		AND PUA.IdUnidadAcademica = AC.IdUnidadAcademica 
		AND PUA.IdSede=AC.IdSede
		AND PUA.IdProducto=AC.IdProducto
		and PUA.Nombre = 'ParametroNomina1'
where AC.IdEmpresa=@IdEmpresa          
AND AC.IdUnidadNegocio =@IdUnidadNegocioNomina 
AND AC.idunidadacademica =@IdUnidadAcademicaNomina
AND AC.IdPeriodo = @IdPeriodoNomina
AND AC.IdSede = @IdSedeNomina
AND (AC.IdProducto=@IdProductoNomina or @IdProductoNomina=0)

	SET NOCOUNT OFF
END
