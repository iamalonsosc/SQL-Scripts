SELECT AC.NombreCompleto FROM Matricula MA
INNER JOIN Promocion PRO ON PRO.IdPromocion=MA.IdPromocion
INNER JOIN Periodo PE ON PE.IdPeriodo=PRO.IdPeriodo
INNER JOIN Actor AC ON AC.IdActor=MA.IdActor
WHERE PE.Codigo='2025-I' 
AND PRO.IdUnidadAcademica=57
--AND MA.EsMatricula=1
AND MA.TipoCondicion='RT'
--RT -> REPITENCIA