--Parametros para la Asignacion de Horarios a los Cursos diferentes al Modulo Actual en la Carga Habil

SET NOCOUNT ON

DECLARE
@CompaniaSocio VARCHAR(8),
@IdMaestroTabla INT,
@IdMaestroRegistro INT

SET @CompaniaSocio =
(
	SELECT
		CompaniaSocio
	FROM Empresa WITH (NOLOCK)
	WHERE IdEmpresa = 1
)

IF NOT EXISTS (SELECT 1 FROM MaestroTabla WITH (NOLOCK) WHERE Codigo = 'ASIHORCURDIFMODACTCH')
BEGIN

	SELECT @IdMaestroTabla = MAX(IdMaestroTabla) + 1 FROM MaestroTabla WITH (NOLOCK)

	INSERT INTO MaestroTabla (IdMaestroTabla, Codigo, Nombre, Activo, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion)
	VALUES (@IdMaestroTabla, 'ASIHORCURDIFMODACTCH', 'Maestro para Asignacion de los Horarios a los Cursos diferentes al Modulo Actual en la Carga Habil', 1, 1, GETDATE(), 1, GETDATE())

END

IF NOT EXISTS (SELECT 1 FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActZEGEL')
BEGIN

	SELECT @IdMaestroTabla = IdMaestroTabla FROM MaestroTabla WITH (NOLOCK) WHERE Codigo = 'ASIHORCURDIFMODACTCH'

	SELECT @IdMaestroRegistro = MAX(IdMaestroRegistro) + 1 FROM MaestroTablaRegistro WITH (NOLOCK)

	INSERT INTO MaestroTablaRegistro (IdMaestroRegistro, IdMaestroTabla, Codigo, Nombre, Descripcion, Activo, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion, Disponible1, Disponible2)
	VALUES (@IdMaestroRegistro, @IdMaestroTabla, 'ValCurDifModActZEGEL', 'Compa�iaSocio asociada a la Empresa Zegel', 'Variable para Identificar la Compa�iaSocio asociada a la Empresa Zegel en la Carga Habil',1,1,GETDATE(),1,GETDATE(),0,'00002500')

END

IF NOT EXISTS (SELECT 1 FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActIDAT')
BEGIN

	SELECT @IdMaestroTabla = IdMaestroTabla FROM MaestroTabla WITH (NOLOCK) WHERE Codigo = 'ASIHORCURDIFMODACTCH'

	SELECT @IdMaestroRegistro = MAX(IdMaestroRegistro) + 1 FROM MaestroTablaRegistro WITH (NOLOCK)

	INSERT INTO MaestroTablaRegistro (IdMaestroRegistro, IdMaestroTabla, Codigo, Nombre, Descripcion, Activo, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion, Disponible1, Disponible2)
	VALUES (@IdMaestroRegistro, @IdMaestroTabla, 'ValCurDifModActIDAT', 'Compa�iaSocio asociada a la Empresa Idat', 'Variable para Identificar la Compa�iaSocio asociada a la Empresa Idat en la Carga Habil',1,1,GETDATE(),1,GETDATE(),0,'00002700')

END

IF NOT EXISTS (SELECT 1 FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActCA')
BEGIN

	SELECT @IdMaestroTabla = IdMaestroTabla FROM MaestroTabla WITH (NOLOCK) WHERE Codigo = 'ASIHORCURDIFMODACTCH'

	SELECT @IdMaestroRegistro = MAX(IdMaestroRegistro) + 1 FROM MaestroTablaRegistro WITH (NOLOCK)

	INSERT INTO MaestroTablaRegistro (IdMaestroRegistro, IdMaestroTabla, Codigo, Nombre, Descripcion, Activo, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion, Disponible1, Disponible2)
	VALUES (@IdMaestroRegistro, @IdMaestroTabla, 'ValCurDifModActCA', 'Compa�iaSocio asociada a la Empresa Corriente Alterna', 'Variable para Identificar la Compa�iaSocio asociada a la Empresa Corriente Alterna en la Carga Habil',1,1,GETDATE(),1,GETDATE(),0,'00002600')

END

IF NOT EXISTS (SELECT 1 FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActCDI')
BEGIN

	SELECT @IdMaestroTabla = IdMaestroTabla FROM MaestroTabla WITH (NOLOCK) WHERE Codigo = 'ASIHORCURDIFMODACTCH'

	SELECT @IdMaestroRegistro = MAX(IdMaestroRegistro) + 1 FROM MaestroTablaRegistro WITH (NOLOCK)

	INSERT INTO MaestroTablaRegistro (IdMaestroRegistro, IdMaestroTabla, Codigo, Nombre, Descripcion, Activo, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion, Disponible1, Disponible2)
	VALUES (@IdMaestroRegistro, @IdMaestroTabla, 'ValCurDifModActCDI', 'Compa�iaSocio asociada a la Empresa Centro de la Imagen', 'Variable para Identificar la Compa�iaSocio asociada a la Empresa Centro de la Imagen en la Carga Habil',1,1,GETDATE(),1,GETDATE(),0,'00002600')

END

IF NOT EXISTS (SELECT 1 FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActITS')
BEGIN

	SELECT @IdMaestroTabla = IdMaestroTabla FROM MaestroTabla WITH (NOLOCK) WHERE Codigo = 'ASIHORCURDIFMODACTCH'

	SELECT @IdMaestroRegistro = MAX(IdMaestroRegistro) + 1 FROM MaestroTablaRegistro WITH (NOLOCK)

	INSERT INTO MaestroTablaRegistro (IdMaestroRegistro, IdMaestroTabla, Codigo, Nombre, Descripcion, Activo, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion, Disponible1, Disponible2)
	VALUES (@IdMaestroRegistro, @IdMaestroTabla, 'ValCurDifModActITS', 'Compa�iaSocio asociada a la Empresa Innova Teaching School', 'Variable para Identificar la Compa�iaSocio asociada a la Empresa Innova Teaching School en la Carga Habil',1,1,GETDATE(),1,GETDATE(),0,'00002400')

END

/*
SELECT Activo, * FROM MaestroTabla WITH (NOLOCK) WHERE Codigo = 'ASIHORCURDIFMODACTCH'
SELECT Activo, Disponible1, Disponible2, * FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActZEGEL'
SELECT Activo, Disponible1, Disponible2, * FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActIDAT'
SELECT Activo, Disponible1, Disponible2, * FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActCA'
SELECT Activo, Disponible1, Disponible2, * FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActCDI'
SELECT Activo, Disponible1, Disponible2, * FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo = 'ValCurDifModActITS'
*/