----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Activacion de Parametros

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--SET NOCOUNT ON

--1. Creacion de Parametros para la Visualizacion de las Nuevas Observaciones en la Carga Habil

SELECT Valor, *  FROM Parametro 
--UPDATE Parametro SET
--	Valor = 1
WHERE Nombre = 'VisualizacionNuevasObservacionesCargaHabil'
--(1 fila afectada)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--2. Creacion de Parametros para la Asignacion de Seccion de Cabecera y Horarios a los Cursos en la Carga Habil

SELECT Valor, * FROM Parametro
--UPDATE Parametro SET
--	Valor = 1
WHERE Nombre = 'AsignacionSeccionHorariosCursosCargaHabil'
--(1 fila afectada)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--3. Creacion de Parametros para la Generacion de Interfases de los Pagos en la Carga Habil

SELECT Valor, * FROM Parametro
--UPDATE Parametro SET
--	Valor = 1
WHERE Nombre = 'GeneracionInterfasesPagosCargaHabil'
--(1 fila afectada)

SELECT Disponible1, * FROM MaestroTablaRegistro WITH (NOLOCK)
--UPDATE MaestroTablaRegistro SET
--	Disponible1 = 1
WHERE IdMaestroTabla IN
(
	SELECT
		IdMaestroTabla
	FROM MaestroTabla WITH (NOLOCK)
	WHERE Codigo = 'GENINTPAGCH'
)
AND Codigo = 'Regular'
--(1 fila afectada)

SELECT Disponible1, * FROM MaestroTablaRegistro WITH (NOLOCK)
--UPDATE MaestroTablaRegistro SET
--	Disponible1 = 1
WHERE IdMaestroTabla IN
(
	SELECT
		IdMaestroTabla
	FROM MaestroTabla WITH (NOLOCK)
	WHERE Codigo = 'GENINTPAGCH'
)
AND Codigo = 'PorSolicitud'
--(1 fila afectada)

SELECT Disponible1, * FROM MaestroTablaRegistro WITH (NOLOCK)
--UPDATE MaestroTablaRegistro SET
--	Disponible1 = 1
WHERE IdMaestroTabla IN
(
	SELECT
		IdMaestroTabla
	FROM MaestroTabla WITH (NOLOCK)
	WHERE Codigo = 'ASIHORCURDIFMODACTCH'
)
AND Codigo = 'ValCurDifModActIDAT'
--(1 fila afectada)

SELECT Disponible1, * FROM MaestroTablaRegistro WITH (NOLOCK)
--UPDATE MaestroTablaRegistro SET
--	Disponible1 = 1
WHERE IdMaestroTabla IN
(
	SELECT
		IdMaestroTabla
	FROM MaestroTabla WITH (NOLOCK)
	WHERE Codigo = 'ASIHORCURDIFMODACTCH'
)
AND Codigo = 'ValCurDifModActCA'
--(1 fila afectada)

SELECT Disponible1, * FROM MaestroTablaRegistro WITH (NOLOCK)
--UPDATE MaestroTablaRegistro SET
--	Disponible1 = 1
WHERE IdMaestroTabla IN
(
	SELECT
		IdMaestroTabla
	FROM MaestroTabla WITH (NOLOCK)
	WHERE Codigo = 'ASIHORCURDIFMODACTCH'
)
AND Codigo = 'ValCurDifModActCDI'
--(1 fila afectada)