UPDATE alumnocurriculacurso SET Subsanacion=NULL
WHERE  idalumno = 1556842
AND idregistro = 2
AND idmodulo = 4
AND idcurricula = 5803
AND Isnull(promediocondicion, 'D') = 'D'
--(4 rows affected)