--SELECT*FROM Parametro WHERE Titulo='UsuarioOficial'
--SELECT*FROM Parametro WHERE Titulo='Credenciales Minedu'
UPDATE Parametro SET Valor= 'JPALOMINO',Valor2=NULL WHERE IdParametro=1459
--(1 row affected)
UPDATE Parametro SET Valor= 'EffD*eeaRrRKADl' WHERE IdParametro=1455
--(1 row affected)