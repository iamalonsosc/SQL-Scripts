--DECLARE @IdMatriculaAntigua INT=611210,@IdAlumno INT=1265723,@IdMatriculaNueva INT

UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (611210)

--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1265723 AND IdRegistro=1 AND IdCurso=9870 AND IdCurricula=23

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1265723 AND IdRegistro=1 AND IdCurso=9799 AND IdCurricula=23

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1265723 AND IdRegistro=1 AND IdCurso=10044 AND IdCurricula=23

SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1265723 AND AC.IdCurso=9870
order by ac.idregistro,ac.IdAlumnoCurso desc


--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=47
WHERE IdMatricula=779862 AND IdCurso=9799
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=48
WHERE IdMatricula=779862 AND IdCurso=10072

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=49
WHERE IdMatricula=779862 AND IdCurso=11358


UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=50
WHERE IdMatricula=779862 AND IdCurso=9870


--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=2,IdAlumnoCurso=1,IdcurriculaOriginal=5608
WHERE IdMatricula=611210 AND IdCurso=9799

UPDATE AlumnoCurso SET IdRegistro=2,IdAlumnoCurso=4,IdcurriculaOriginal=5608--,IdCursoOriginal=null
WHERE IdMatricula=611210 AND IdCurso=10072

UPDATE AlumnoCurso SET IdRegistro=2,IdAlumnoCurso=3,IdcurriculaOriginal=5608,IdCursoOriginal=null
WHERE IdMatricula=611210 AND IdCurso=11358

UPDATE AlumnoCurso SET IdRegistro=2,IdAlumnoCurso=2,IdcurriculaOriginal=5608--,IdCursoOriginal=null
WHERE IdMatricula=12927 AND IdCurso=9870



--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='D',PromedioFinal='00.00',PromedioReal='00.00',IdAlumnoCurso=1,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1265723 AND IdRegistro=2 AND IdCurso=9799 AND IdCurricula=5608


UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='D',PromedioFinal='00.00',PromedioReal='00.16',IdAlumnoCurso=4,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1265723 AND IdRegistro=2 AND IdCurso=10072 AND IdCurricula=5608


UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='D',PromedioFinal='00.00',PromedioReal='00.00',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1265723 AND IdRegistro=2 AND IdCurso=11358 AND IdCurricula=5608


UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='18',PromedioReal='18.00',IdAlumnoCurso=2,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51163
WHERE IdAlumno=1265723 AND IdRegistro=2 AND IdCurso=9870 AND IdCurricula=5608


--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=2,IdCurricula=5608
WHERE IdMatricula=611210

-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO

UPDATE Matricula SET Estado='X'
WHERE IdMatricula=779862