--declare @p3 int
--set @p3=9
--exec cInterfaseDocumento_Validacion_General @idMatricula=625226,@CompaniaSocio=N'00002700',@parmreturn =@p3 output
--select @p3

DECLARE                                                                                      
@idMatricula INT,    
@CompaniaSocio CHAR(8),    
@parmReturn INT --OUTPUT        
--AS


BEGIN    
--@6      
 SET NOCOUNT ON;            
        SELECT @idMatricula=625226,@CompaniaSocio=N'00002700'
 SET @parmReturn=0        
 DECLARE @TransAcction INT=1       
      
 --Recuperamos Datos Basicos de la Matricula        
 declare  @Idsede int        
 ,@idPromocion int         
 ,@Tiposervicio char(1)        
 ,@CondicionPago char(1)          
 ,@IdActorVta int        
 ,@idActor int        
 ,@IdMoneda int        
 ,@IdPeriodo int        
 ,@Campania VARCHAR(20)        
 ,@PeriodoFinanciero varchar(50)        
 ,@NumeroCuota int    
    ,@IdTipoCronograma INT --@8           
    ,@EsPrincipalCronograma INT = 1 --@8    
 ,@Prepago int    
 ,@IdEmpresa INT --Inicio @5    
 ,@IdUnidadNegocio INT    
 ,@IdUnidadAcademica INT    --Fin @5        
    ,@Sucursal char(4)        
 ,@Serie char(3)        
 ,@CodigoEstablecimiento char(4)        
 ,@ItemCodigo char(20)        
 ,@Area  char(4)        
 ,@Moneda char(2)          
 ,@PermisoMatporCursoCaptacion BIT = 0 --@5    
 ,@TipoCliente char(3)      
 ,@Monto decimal(10,2)      
 ,@IdModuloMatricula INT  --@9    
     
 ,@IdPrecioSede INT --@MOTA    
 ,@PrecioSedeSucursal VARCHAR(20)--@MOTA    
    
 --Creamos e Insertamos en la tabla Temporal #cronogramapago        
 declare  @cronogramapago table(        
 id int identity(1,1) not null,        
 CuotaNumero int null,        
 FechaVencimiento date,        
 Estado char(1),        
 IdPromocion int)      
    
  --@9    
  DECLARE @AlumnoTraslado INT,@pIdAlumno INT,@pIdCurricula INT    
    
  DECLARE @ConvalidacionEspecial AS TABLE(    
  IdCurriculaOrigen INT,    
  IdCurriculaDestino INT     
  )    
   DECLARE @CursoMatricula AS TABLE(      
  IdCurso INT,    
  IdCurricula INT,    
  IdModulo INT)    
  --@9    
     
 -- Datos Matricula    
 select  @IdSede=M.IdSede        
 ,@idPromocion=M.IdPromocion        
 ,@Tiposervicio=M.TipoServicio        
 ,@CondicionPago=M.CondicionPago        
 ,@IdActorVta=M.idActor        
 ,@idActor=M.idActor        
 ,@IdMoneda=M.IdMoneda    
 ,@Moneda=case when M.IdMoneda=236 then 'LO' when M.IdMoneda=237 then 'EX' END        
 ,@IdPeriodo=M.IdPeriodo        
 ,@NumeroCuota=isnull(M.NumeroCuota,0)        
 ,@Prepago=M.IdProcedencia     
 ,@IdPeriodo=P.IdPeriodo    
 ,@PeriodoFinanciero=P.PeriodoFinanciero    
 ,@Campania=PE.Codigo    
 ,@Sucursal=S.Sucursal        
 ,@Serie=S.Serie        
 ,@CodigoEstablecimiento=S.CodigoEstablecimiento    
 ,@ItemCodigo=P.ServicioCodigo    
 ,@Area=substring(P.ServicioCodigo,2,2)    
    ,@IdTipoCronograma = ISNULL(M.IdTipoCronograma,0) --@8       
 ,@IdModuloMatricula = p.IdModulo --@9    
 ,@pIdAlumno=m.IdActor--@9    
 ,@pIdCurricula=m.IdCurricula --@9    
 ,@IdPrecioSede = ISNULL( M.IdPrecioSede , -1)--@MOTA    
 ,@PrecioSedeSucursal =  ISNULL(S2.Sucursal , '') --@MOTA    
 from Matricula M WITH (NOLOCK)     
 INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion    
 INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo     
 INNER JOIN Sede S WITH(NOLOCK) ON  M.IdSede = S.IdSede    
 LEFT JOIN Sede S2 WITH(NOLOCK) ON S2.IdSede = M.IdPrecioSede--@MOTA      
 where IdMatricula=@idMatricula      
        
    --inicio @8    
    SET @EsPrincipalCronograma = 1    
    IF @IdTipoCronograma = -1 SET @IdTipoCronograma = 0    
    SELECT @EsPrincipalCronograma = CAST(Disponible1 AS INT) FROM MaestroTablaRegistro WITH(NOLOCK) WHERE IdMaestroRegistro = @IdTipoCronograma    
    IF @IdTipoCronograma = 0 SET @EsPrincipalCronograma = 1    
        
    
    
 --Inicio @9    
  INSERT INTO @CursoMatricula(IdCurricula,IdCurso,IdModulo)    
  SELECT Disponible1,Disponible2,Disponible3 FROM MaestroTablaRegistro  WITH (NOLOCK) WHERE IdMaestroTabla in (    
  SELECT IdMaestroTabla FROM MaestroTabla WITH(NOLOCK) WHERE codigo='CurrCurModIesEest') and disponible1=@pIdCurricula and Disponible3=@IdModuloMatricula    
      
  INSERT INTO @ConvalidacionEspecial(IdCurriculaOrigen,IdCurriculaDestino)    
  SELECT Disponible1,Disponible2    
  FROM MaestroTablaRegistro MTR WITH(NOLOCK)    
  INNER JOIN MaestroTabla MT WITH(NOLOCK) ON MTR.IdMaestroTabla=MT.IdMaestroTabla    
  WHERE MT.Codigo='CurriculaConvEspTras'    
    
  SET @AlumnoTraslado =0    
  IF EXISTS(select 1 from TrasladoSede WITH(NOLOCK) where IdAlumno=@pIdAlumno and Estado=1 and IdCurriculaNueva=@pIdCurricula     
  and Observacion='MIGRACION MASIVA DEL 2020-II AL 2021-I DE IES A EEST'    
  and IdCurriculaAnterior in (SELECT IdCurriculaOrigen FROM @ConvalidacionEspecial WHERE IdCurriculaDestino=@pIdCurricula)    
  and @CompaniaSocio = '00002500')    
  BEGIN    
   SET @AlumnoTraslado =1    
  END    
    
 --@9Fin    
    
 --Cronograma    
    IF @EsPrincipalCronograma = 0    
    BEGIN    
        insert into @cronogramapago(CuotaNumero,FechaVencimiento,Estado,IdPromocion )     
        select CuotaNumero, FechaVencimiento,Estado,IdPromocion     
     from CronogramaPagoAlterna WITH (NOLOCK)     
     where IdPromocion =@idPromocion and IdTipoCronograma = @IdTipoCronograma    
    END    
    ELSE    
    BEGIN    
        insert into @cronogramapago(CuotaNumero,FechaVencimiento,Estado,IdPromocion )        
     select CuotaNumero, FechaVencimiento,Estado,IdPromocion     
     from CronogramaPago WITH (NOLOCK)     
     where IdPromocion =@idPromocion    
    END    
    --fin @8    
      
 ---- Verificar si es prepago.        
 if @Prepago=1        
 begin        
  set @TransAcction=0        
  set @parmReturn = 7 --'es Prepago no genera interface      
  print 'es Prepago no genera interface : @parmReturn= ' + cast( @parmReturn as varchar)      
  return        
 end        
         
 ---- Verificar si hay datos en Cronograma de pagos        
 if (not exists(select 1 from @cronogramapago))        
 begin        
  set @TransAcction=0        
  set @parmReturn = 1 --'Faltan datos de cronograma de pagos'       
  print 'Faltan datos de cronograma de pagos : @parmReturn= ' + cast( @parmReturn as varchar)       
  return        
 end         
         
 --Validaciones Basicas        
 if @CondicionPago='Q'        
 begin        
  if (not exists(select 1 from @cronogramapago))        
  begin        
   set @parmReturn = 1 --'Faltan datos de cronograma de pagos'        
   set @TransAcction=0    
   print 'Faltan datos de cronograma de pagos : @parmReturn= ' + cast( @parmReturn as varchar)         
   return        
  end        
          
  if ISNULL(@NumeroCuota,0)=0        
  begin        
   set @parmReturn = 5  --Numero de cuotas no es Valido        
   set @TransAcction=0     
   print 'Numero de cuotas no es Valido : @parmReturn= ' + cast( @parmReturn as varchar)          
   return        
  end        
          
  if @NumeroCuota >(select MAX(cuotanumero) from @cronogramapago)        
  begin        
   set @parmReturn = 6  --Numero de cutas de la matricula debe de ser menor o igual al numero de cuotas del cronograma de pagos de la promocion.        
   set @TransAcction=0      
   print 'Numero de cutas de la matricula debe de ser menor o igual al numero de cuotas del cronograma de pagos de la promocion. : @parmReturn= ' + cast( @parmReturn as varchar)        
   return        
  end        
 end        
	--@11 inicio
 	 if @CompaniaSocio = '00002400'
	 begin
		Select @CompaniaSocio = CompaniaSocioPadre from Empresa WITH(NOLOCK) where IdEmpresa = 1
	 end
	 --@11 fin
         
 --  Obtenemos Tipo de cliente para los precios    
   IF @CompaniaSocio='00002600'  
 BEGIN  
 SELECT @CompaniaSocio=CompaniaSocio FROM EMPRESA WITH(NOLOCK) -- 
  select @TipoCliente = dbo.cCo_Precio_ObtenerTipoListaPrecio(@idMatricula, NULL, NULL, @CompaniaSocio)      
 END  
   ELSE  
   BEGIN  
     select @TipoCliente = dbo.cCo_Precio_ObtenerTipoListaPrecio(@idMatricula, NULL, NULL, @CompaniaSocio)      
  
   END  
 --Inicio @5    
 -- VALIDAMOS SI TIENE PERMISOS PARA MATRICULAR POR CURSO CAPTACION      
 SELECT  @PermisoMatporCursoCaptacion = CASE WHEN Valor = '' THEN 0 ELSE ISNULL(Valor,0) END    
 FROM ParametroUnidadAcademica WITH(NOLOCK)         
 WHERE IdEmpresa = @IdEmpresa         
 AND IdSede = @Idsede          
 AND IdUnidadNegocio = @IdUnidadNegocio         
 AND IdUnidadAcademica = @IdUnidadAcademica        
 AND Nombre = 'MatriculaCursoPorCaptacion'    
 --Fin @5     
  
 IF @CompaniaSocio='00002600'--@10  
 BEGIN  
 SELECT @CompaniaSocio=COMPANIASOCIOPADRE FROM EMPRESA  
 END  
    
 if (@Tiposervicio='P' or @Tiposervicio='M')        
 begin     
  --Validamos que el servicio exista       
  if ISNULL(@ItemCodigo,'') = ''       
  begin        
   set @parmReturn = 4  --Servicio no es Valido        
   set @TransAcction=0       
   print 'Servicio no es Valido : @parmReturn= ' + cast( @parmReturn as varchar)         
   return        
  end        
  -- Validamos que el servicio tenga cabecera CO_ServicioClasificacion    
  if not exists(select 1 from CO_ServicioClasificacion WITH(NOLOCK) where ServicioClasificacion = @ItemCodigo and CompaniaSocio = @CompaniaSocio)    
  begin    
   set @parmReturn = 4  --Servicio no es Valido        
   set @TransAcction=0       
   print 'Servicio no es Valido : @parmReturn= ' + cast( @parmReturn as varchar)         
   return      
  end     
       
   SELECT @ItemCodigo,@CompaniaSocio,@PrecioSedeSucursal,@Sucursal,@PermisoMatporCursoCaptacion,@TipoCliente
  --  Validamos que exista servicio en la lista de cliente por producto    
  IF NOT EXISTS(SELECT 1 FROM vw_CO_Precio  WITH(NOLOCK)       
  WHERE ItemCodigo = @ItemCodigo         
  AND UnidadNegocio = CASE WHEN @PrecioSedeSucursal = '' THEN @Sucursal  ELSE @PrecioSedeSucursal END   --@MOTA     
  AND CompaniaSocio = @CompaniaSocio          
  AND TipoCliente = @TipoCliente    
  AND CompaniaSocio=@CompaniaSocio ) --@5    
  BEGIN        
   set @parmReturn = 9 --'No existe o no est? asignado el monto al tipo de servicio'        
   set @TransAcction=0      
   print 'No existe o no est? asignado el monto al tipo de servicio : @parmReturn= ' + cast( @parmReturn as varchar)         
    
   return        
  END    
  ELSE    
  BEGIN    
   --  validamos que exista precio en matricula de     
   IF (SELECT ISNULL(Monto,0)     
   FROM vw_CO_Precio WITH (NOLOCK)     
   WHERE ItemCodigo=@ItemCodigo     
   and TipoFacturacion = 'MAT'    
   and UnidadNegocio= CASE WHEN @PrecioSedeSucursal = '' THEN @Sucursal  ELSE @PrecioSedeSucursal END   --@MOTA     
   AND CompaniaSocio=@CompaniaSocio --@1    
   AND TipoCliente = @TipoCliente) = 0          
   begin        
    set @parmReturn = 2  --Monto del servicio no es Valido        
    set @TransAcction=0    
    print 'Monto del servicio no es Valido : @parmReturn= ' + cast( @parmReturn as varchar)          
    return        
   end     
    
   --  validamos que exista precio en cuotas    
   IF (SELECT ISNULL(Monto,0)     
   FROM vw_CO_Precio WITH (NOLOCK)     
   WHERE ItemCodigo=@ItemCodigo     
   and TipoFacturacion = 'NOR'    
   and UnidadNegocio=CASE WHEN @PrecioSedeSucursal = '' THEN @Sucursal  ELSE @PrecioSedeSucursal END   --@MOTA     
   AND CompaniaSocio=@CompaniaSocio --@1    
   AND TipoCliente = @TipoCliente) = 0          
   begin        
    set @parmReturn = 2  --Monto del servicio no es Valido        
    set @TransAcction=0    
    print 'Monto del servicio no es Valido : @parmReturn= ' + cast( @parmReturn as varchar)          
    return        
   end     
      
  END      
 end        
         
 --Fin Validaciones Basicas        
 if (@Tiposervicio='C' or @Tiposervicio='M')        
 begin     
        
  --recuperamos las promociones de del detalle de la matricula y lo guardamos en la tabla temporal #AlumnoCurso        
  declare @AlumnoCurso table (        
  id int identity(1,1) not null,        
  IdPromocion int,        
  TipoCondicion char(2),        
  Cantida int,    
  ServicioCodigo VARCHAR(100),    
  IdModulo int,--@9    
  Paga int,--@9    
  idcurso int--@9    
  )      
  --@9       
  IF @AlumnoTraslado =1    
  BEGIN    
   INSERT INTO @AlumnoCurso(IdPromocion,TipoCondicion,ServicioCodigo,Cantida,IdModulo,Paga,idcurso)    --@9    
   SELECT AC.IdPromocion,AC.TipoCondicion, REPLACE(ISNULL(P.ServicioCodigo, ''),'P','C')   ,Count(*),cc.IdModulo,1,AC.IdCurso--@9    
   from AlumnoCurso AC  WITH(NOLOCK)    
   INNER JOIN CurriculaCurso CC WITH (NOLOCK) ON ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) = CC.IdCurricula  AND ISNULL(AC.IdCursoOriginal,AC.IdCurso) = CC.IdCurso--@31    
   LEFT JOIN Promocion P WITH(NOLOCK) ON AC.IdPromocion = P.IdPromocion        
   where IdMatricula =@idMatricula     
   and (IdSeccion<>0 and IdSeccion is not null)        
   and (TipoCondicion='CC' or TipoCondicion='RP')     
   and (CC.IdModulo<>@IdModuloMatricula)    
   group by AC.IdPromocion,AC.TipoCondicion,P.ServicioCodigo,cc.IdModulo,AC.IdCurso--@9      
       
    
   UPDATE AC     
    SET AC.Paga=0    
    FROM  @AlumnoCurso AC     
    INNER JOIN PROMOCION P WITH(NOLOCK) ON AC.IdPromocion = P.IdPromocion      
    INNER JOIN @CursoMatricula CM ON CM.IdCurricula=P.IdCurricula AND AC.IdCurso = CM.IdCurso     
  END    
  ELSE    
  BEGIN    
   INSERT INTO @AlumnoCurso(IdPromocion,TipoCondicion,ServicioCodigo,Cantida,Paga)        
   SELECT AC.IdPromocion,AC.TipoCondicion, REPLACE(ISNULL(P.ServicioCodigo, ''),'P','C')   ,Count(*),1     
   from AlumnoCurso AC  WITH(NOLOCK)    
   INNER JOIN CurriculaCurso CC WITH (NOLOCK) ON ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) = CC.IdCurricula  AND ISNULL(AC.IdCursoOriginal,AC.IdCurso) = CC.IdCurso    
   LEFT JOIN Promocion P WITH(NOLOCK) ON AC.IdPromocion = P.IdPromocion      
   where IdMatricula =@idMatricula     
   and (IdSeccion<>0 and IdSeccion is not null)        
   and (TipoCondicion='CC' or TipoCondicion='RP')     
   and (CC.IdModulo<>@IdModuloMatricula)    
   group by AC.IdPromocion,AC.TipoCondicion,P.ServicioCodigo       
  END    
  --@9    
             
  DECLARE @MIN_CC INT, @MAX_CC INT     
      
  SELECT @MIN_CC = MIN(ID) , @MAX_CC = MAX(ID) FROM @AlumnoCurso where Paga=1--@9    
        
  --Inicio de validaciones de cursos a cargo (mas de una promoci?n)        
  WHILE @MIN_CC <= @MAX_CC    
  BEGIN    
      SET @ItemCodigo = ''    
   SELECT @ItemCodigo = ServicioCodigo FROM @AlumnoCurso WHERE id = @MIN_CC     
    
   if ISNULL(@ItemCodigo, '') = ''      
   begin        
    set @parmReturn = 4  --Sevicio es Nulo y no es V?lido, Transacci?n cancelada        
    set @TransAcction=0      
    print 'Sevicio es Nulo y no es Valido, Transaccion cancelada  : @parmReturn= ' + cast( @parmReturn as varchar)               
    break        
   end     
    
   -- Validamos que el servicio tenga cabecera CO_ServicioClasificacion    
   if not exists(select 1 from CO_ServicioClasificacion WITH(NOLOCK)  where ServicioClasificacion = @ItemCodigo and CompaniaSocio = @CompaniaSocio)    
   begin    
    set @parmReturn = 4  --Servicio no es Valido        
    set @TransAcction=0       
    print 'Servicio no es Valido : @parmReturn= ' + cast( @parmReturn as varchar)         
    return      
   end     
    
   ----VALIDA EL NUMERO DE CURSOS        
   --if @CountCurso=0        
   --begin        
   -- set @parmReturn = 3 --N?mero de cursos no es V?lido, Transacci?n cancelada        
   -- set @TransAcction=0        
   -- break        
   --end        
    
	
   --  Validamos que exista servicio en la lista de cliente por producto    
   IF NOT EXISTS(SELECT 1 FROM vw_CO_Precio WITH(NOLOCK)         
   WHERE ItemCodigo = @ItemCodigo         
   AND UnidadNegocio = CASE WHEN @PrecioSedeSucursal = '' THEN @Sucursal  ELSE @PrecioSedeSucursal END   --@MOTA          
   AND CompaniaSocio = @CompaniaSocio          
   AND TipoCliente =  (CASE WHEN CHARINDEX('C',@ItemCodigo,0)> 0 AND ISNULL(@PermisoMatporCursoCaptacion,0) = 0 THEN '01' ELSE  @TipoCliente END)    
   AND CompaniaSocio=@CompaniaSocio ) --@5    
   BEGIN        
    SELECT @ItemCodigo,@CompaniaSocio,@PrecioSedeSucursal,@PermisoMatporCursoCaptacion,@TipoCliente
    set @parmReturn = 9 --'No existe o no est? asignado el monto al tipo de servicio'        
    set @TransAcction=0      
    --print 'No existe o no est? asignado el monto al tipo de servicio : @parmReturn= ' + cast( @parmReturn as varchar)         
    return        
   END    
   ELSE    
   BEGIN    
    
       
    --  validamos que exista precio en matricula de     
    IF (SELECT ISNULL(Monto,0)     
    FROM vw_CO_Precio WITH (NOLOCK)     
    WHERE ItemCodigo=@ItemCodigo     
    and TipoFacturacion = 'CON'    
    and UnidadNegocio=CASE WHEN @PrecioSedeSucursal = '' THEN @Sucursal  ELSE @PrecioSedeSucursal END   --@MOTA      
    AND CompaniaSocio=@CompaniaSocio --@1    
    AND TipoCliente = (CASE WHEN CHARINDEX('C',@ItemCodigo,0)> 0 AND ISNULL(@PermisoMatporCursoCaptacion,0) = 0 THEN '01' ELSE  @TipoCliente END)) = 0          
    begin        
     set @parmReturn = 2  --Monto del servicio no es Valido        
     set @TransAcction=0    
     print 'Monto del servicio no es Valido : @parmReturn= ' + cast( @parmReturn as varchar)     
     return        
    end     
    
   END      
           
   SET @MIN_CC = @MIN_CC + 1       
    
  end        
 --fin Validaciones de cursos a Cargo        
 end         
 SET @parmReturn = @parmReturn      
--@6      
END    
    


--Completion time: 2024-07-24T10:59:02.9748406-05:00
