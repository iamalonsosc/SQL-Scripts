--SELECT*FROM PersonaMast WHERE Persona='1314045'
--SELECT*FROM PersonaMast WHERE Documento='73039106'
--SELECT Interfase_Matricula, *FROM CO_Documento 
UPDATE CO_Documento set ClienteNumero='1213387',ClienteCobrarA='1213387'
WHERE NumeroDocumento='B001-34905'
--(1 row affected)