--����������������������������������������������������������������������������                        
--Creado por      : Luis Perales Tenorio (26/03/2012)                        
--Funcionalidad   : Permite ejecutar el proceso de matricula para los alumnos secuenciales                        
--Utilizado por   :                     
--����������������������������������������������������������������������������                        
/*                    
-----------------------------------------------------------------------------                    
Nro  FECHA  USUARIO  DESCRIPCION  
-----------------------------------------------------------------------------                    
@1  11.01.2019  Eloy Alva (Sigcomt) Agregar parametro CompaniaSocio. 
@2	23/05/2025 APORRAS  Se agrega tipo de documento Pasaporte como documento valido. IdDocumentoTipo 27670 (IDAT), 25596 (CA), 30765 (ZEGEL E ITS)
*/                         
ALTER PROCEDURE [dbo].[cAlumnoCurso_UpdProcesoMatriculaSecuenciales]              
@IdEmpresa INT,                  
@IdSede INT,                  
@IdFacultad INT,                  
@IdUnidadNegocio INT,                  
@IdUnidadAcademica INT,                 
@IdPeriodo INT,                  
@IdProducto INT,                  
@IdPromocion INT,                  
@IdGrupo INT,                  
@IdAlumno INT,                  
@IdUsuario INT                
AS                  
BEGIN                
 SET NOCOUNT ON   
 
	-- @1 inicio 
	DECLARE @CompaniaSocio CHAR(8)
	SELECT @CompaniaSocio = CompaniaSocio  FROM Empresa e WITH(NOLOCK)
	WHERE E.IdEmpresa=@IdEmpresa 
	-- @1 fin              
                
 CREATE TABLE #Matricula (                
						 Id INT IDENTITY,                
						 IdMatricula int,                
						 PromocionIdEmpresa INT,                  
						 PromocionIdSede INT,                  
						 PromocionIdFacultad INT,                  
						 PromocionIdUnidadNegocio INT,                  
						 PromocionIdUnidadAcademica INT,                 
						 PromocionIdPeriodo INT,                  
						 PromocionIdProducto INT,                  
						 ProductoNombre VARCHAR(250),                  
						 IdPromocion INT,                  
						 IdRegistro INT,                  
						 PromocionNombre VARCHAR(250),                  
						 IdGrupo INT,                  
						 GrupoCodigo VARCHAR(250),             
						 CodigoAlumno VARCHAR(20),                     
						 ActorIdActor INT,                
						 ActorNombreCompleto VARCHAR(250),                
						 IdDocumentoTipo INT,              
						 NumeroIdentidad VARCHAR(20),              
						 Observacion VARCHAR(8000),              
						 InscritoFecha date,             
						 IdProcedencia INT,             
						 Estado VARCHAR(100),            
						 Orden INT)                
               
 --SE CARGA TODA LA POBLACI�N DE ALUMNOS MATRICULADOS SEGUN LOS CRITERIOS                
 --si el proceso no es por secci�n, se va a la cabecera de matricula                
 BEGIN                
		INSERT INTO #Matricula(InscritoFecha,PromocionIdEmpresa,PromocionIdSede,PromocionIdFacultad,
		PromocionIdUnidadNegocio,PromocionIdUnidadAcademica,PromocionIdPeriodo,PromocionIdProducto,
		IdPromocion,IdGrupo,ActorIdActor,IdMatricula,IdRegistro,IdProcedencia,Orden)                
		SELECT M.InscritoFecha,P.IdEmpresa,P.IdSede,P.IdFacultad,P.IdUnidadNegocio,P.IdUnidadAcademica,P.IdPeriodo,              
		P.IdProducto,M.IdPromocion,M.IdGrupo,M.IdActor,M.IdMatricula, M.IdRegistro, ISNULL(M.IdProcedencia,0),CM.Orden            
		FROM Matricula M with(nolock)                
		INNER JOIN Promocion P with(nolock)           
		ON M.IdPromocion=P.IdPromocion                
		INNER JOIN CurriculaModulo CM with(nolock)           
		ON M.IdCurricula = CM.IdCurricula            
		AND M.IdModulo = CM.IdModulo            
		WHERE P.IdEmpresa=@IdEmpresa                 
		AND P.IdSede=@IdSede                 
		AND P.IdFacultad=@IdFacultad                  
		AND P.IdUnidadNegocio=@IdUnidadNegocio    
		AND P.IdUnidadAcademica=@IdUnidadAcademica                 
		AND P.IdPeriodo=@IdPeriodo                
		AND (P.IdProducto=@IdProducto OR @IdProducto=0)                 
		AND (M.IdPromocion=@IdPromocion OR @IdPromocion=0)                 
		AND (M.IdGrupo=@IdGrupo OR @IdGrupo=0)                
		AND (M.IdActor=@IdAlumno OR @IdAlumno=0)                
		AND M.Estado<>'X'                
		AND M.IdPeriodo =@IdPeriodo            
		--AND M.EsMatricula=0               
		ORDER BY M.InscritoFecha ASC              
 END                
                
 --SE CARGAN LAS DESCRIPCIONES DE CADA ALUMNO-CURSO                
 UPDATE M                
 SET M.ProductoNombre= RTRIM(P.ProductoCodigo)+'-'+ RTRIM(P.ProductoNombre) ,                  
 M.PromocionNombre = RTRIM(PR.PromocionCodigo)+'-'+ RTRIM(PR.PromocionNombre) ,                    
 M.GrupoCodigo =RTRIM(PG.GrupoCodigo),                 
 M.ActorNombreCompleto =RTRIM(A.NombreCompleto),              
 M.IdDocumentoTipo=isnull(A.IdDocumentoTipo,''),              
 M.NumeroIdentidad=isnull(A.NumeroIdentidad,''),             
 M.CodigoAlumno = isnull(AL.CodigoAnterior,'')            
 FROM #Matricula M                
 LEFT OUTER JOIN Producto P with(nolock) ON M.PromocionIdProducto=P.IdProducto                
 LEFT OUTER JOIN Promocion PR with(nolock) ON M.IdPromocion=PR.IdPromocion                
 LEFT OUTER JOIN PromocionGrupo PG with(nolock) ON  M.IdPromocion=PG.IdPromocion AND M.IdGrupo=PG.IdGrupo                
 LEFT OUTER JOIN Actor A with(nolock) ON M.ActorIdActor=A.IdActor                
 LEFT OUTER JOIN Alumno AL with(nolock) ON AL.IdAlumno=A.IdActor  
              
 --se carga el parametro que Define lo que se va a validar por unidad acad�mica              
 -- valor = 1 valida pago, en caso contrario no se valida pago              
 -- valor2 = 1 valida documentos, en caso contrario no se valida documentos              
 DECLARE @ValidaPago INT,  
		 @ValidaDocumentos INT              
               
 SELECT @ValidaPago=isnull(PUA.Valor,0), 
		@ValidaDocumentos=isnull(PUA.Valor2,0)              
 FROM ParametroUnidadAcademica PUA WITH (NOLOCK)                  
 WHERE PUA.IdEmpresa=@IdEmpresa                  
 AND PUA.IdSede=@IdSede                  
 AND PUA.IdFacultad=@IdFacultad              
 AND PUA.IdUnidadNegocio=@IdUnidadNegocio                  
 AND PUA.IdUnidadAcademica=@IdUnidadAcademica                  
 AND PUA.Nombre='ProcesoMatricula'                  
                 
 DECLARE               
     @ERRORCODIGO INT,              
     @DESCRIPCIONERROR VARCHAR(8000),              
     @CurIdGrupo INT,               
     @CurIdAlumno INT,               
     @CurIdPromocion INT,              
     @CurIdMatricula INT,              
     @CurIdRegistro INT,              
     @CurCodigoAlumno VARCHAR(20),            
     @EstadoMatricula VARCHAR(100) ,             
     @CurNumeroDocumento VARCHAR(20),            
     @CurID INT,               
     @MaxID INT,            
     @pLogin VARCHAR(20),            
     @CodigoAlumno VARCHAR(20),            
     @CurIdProcedencia INT,            
     @CurOrden INT  ,    
     @IdDocumentoTipo INT,
     @Deudas INT     
                 
     SELECT @CurID=1, @MaxID=Max(Id) FROM #Matricula                
             
 WHILE  @CurID <= @MaxID              
   BEGIN                
		set @CodigoAlumno=''            
		--sacamos los datos por cada alumno            
		SELECT @CurIdGrupo=IdGrupo,@CurIdAlumno=ActorIdActor,             
		@CurIdPromocion=IdPromocion, @CurIdMatricula = IdMatricula,              
		@CurIdRegistro = idRegistro , @CurCodigoAlumno = CodigoAlumno ,             
		@CurNumeroDocumento = NumeroIdentidad,     
		@IdDocumentoTipo = IdDocumentoTipo,            
		@CurIdProcedencia = IdProcedencia, @CurOrden = Orden            
		FROM #Matricula                
		WHERE Id=@CurID                

		--SE REINICIA LA VARIABLE ERROR                 
		SET @EstadoMatricula='Matricula Completa'                
		SET @ERRORCODIGO=0              
		SET @DESCRIPCIONERROR = 'Ok'            
              
            
		IF ( (@IdDocumentoTipo IN (27, CASE @CompaniaSocio WHEN '00002700' THEN 27670 WHEN '00002600' THEN 25596 ELSE 30765 END))	--@2   
				AND (@CurNumeroDocumento = '' OR @CurNumeroDocumento IS NULL))      
			BEGIN        
				SET @DESCRIPCIONERROR='La Persona '+ convert(varchar(50),@CurIdAlumno)+' no tiene registrado n�mero de documento v�lido o debe actualizar el documento (' + @CurNumeroDocumento + ')'                
				SET @EstadoMatricula = 'No Matriculado'  
				SET @ERRORCODIGO = 1                   
			END        
		ELSE IF  ( (@IdDocumentoTipo NOT IN (27, CASE @CompaniaSocio WHEN '00002700' THEN 27670 WHEN '00002600' THEN 25596 ELSE 30765 END))	--@2   
					AND (isnull(@CurNumeroDocumento,'') = '' OR  ISNUMERIC(SUBSTRING(@CurNumeroDocumento,1,2))=0 OR len(@CurNumeroDocumento)<>8))        
			BEGIN            
				SET @DESCRIPCIONERROR='La Persona '+ convert(varchar(50),@CurIdAlumno)+' no tiene registrado n�mero de documento o debe actualizar el documento (' + @CurNumeroDocumento + ')'                
				SET @EstadoMatricula = 'No Matriculado' 
				SET @ERRORCODIGO = 1              
			END             
		ELSE IF  (@IdDocumentoTipo=357 AND (isnull(@CurNumeroDocumento,'') = '' OR  ISNUMERIC(SUBSTRING(@CurNumeroDocumento,1,2))=0 OR len(@CurNumeroDocumento)<>8))        
			BEGIN            
				SET @DESCRIPCIONERROR='La Persona '+ convert(varchar(50),@CurIdAlumno)+' no tiene registrado n�mero de documento o debe actualizar el documento (' + @CurNumeroDocumento + ')'                
				SET @EstadoMatricula = 'No Matriculado'
				SET @ERRORCODIGO = 1               
			END      

   -- -- validamos que tenga numero de documento              
   -- IF (@CurNumeroDocumento = '' OR  ISNUMERIC(SUBSTRING(@CurNumeroDocumento,1,2))=0 OR LEN(@CurNumeroDocumento)<>8)            
   --BEGIN            
   --  SET @DESCRIPCIONERROR='La Persona '+ convert(varchar(50),@CurIdAlumno)+' no tiene registrado n�mero de documento o debe actualizar el documento (' + @CurNumeroDocumento + ')'                
   --  SET @EstadoMatricula = 'No Matriculado'            
   --END            
    ELSE            
    BEGIN            
    -- NO DEBE VALIDAR DEUDAS DE ESTE ALUMNO LA PROCEDENCIA = 1            
    IF @CurIdProcedencia = 0   -- se pone en la matricula de ingresantes          
		BEGIN            
			 ----SE VALIDA QUE EL ALUMNO NO TENGA DEUDAS 
			 --verificamos si tiene deudas pendientes
		  EXEC cAlumno_Valida_Deudas @CurIdAlumno,null,@Deudas OUTPUT
		  
		  IF @Deudas > 0 -- tiene deudas
			BEGIN     
					IF dbo.cAutorizacionAlumno_Val_Existe(@IdEmpresa,@IdSede,@IdFacultad,@IdUnidadNegocio,@IdUnidadAcademica,                 
							   @IdPeriodo,@CurIdAlumno,1035) = 0            
						BEGIN  
							SET @ERRORCODIGO = 1        
							SET @EstadoMatricula = 'El alumno tiene deudas pendientes con la instituci�n.'        
							SET @DESCRIPCIONERROR = 'No Matriculado'       
							--RETURN     
						END   
			END
        
     IF  @ERRORCODIGO = 0
      BEGIN      			                
			 IF @ValidaPago=1             
			   BEGIN                
					-- PERMISO DE MATRICULA PARA PODER MATRICULARSE CON DEUDAS            
					 IF dbo.cAutorizacionAlumno_Val_Existe(@IdEmpresa,@IdSede,@IdFacultad,@IdUnidadNegocio,@IdUnidadAcademica,                 
					   @IdPeriodo,@CurIdAlumno,1035) = 0            
						BEGIN            
								-- Llamar a la funci�n que valida si el alumno tiene deudas con la instituci�n de spring            
							  IF dbo.cMatricula_Val_Pago_Cuota(@CurIdMatricula,@CompaniaSocio) = 0       --@1     
								  BEGIN            
									   SET @ERRORCODIGO = 1               
									   SET @EstadoMatricula = 'No ha cancelado su cuota de Matricula'              
									   SET @DESCRIPCIONERROR = 'No Matriculado'             
								  END             
							  ELSE            
								  BEGIN            
								   SET @ERRORCODIGO=0              
								  END     
						END               
			   END   
		end	 --@ERRORCODIGO            
   END       --@CurIdProcedencia         
   
           
                     
  IF @ERRORCODIGO=0                
	BEGIN           
		  -- aca debeos actualizar el campo esmatricula de la cabecera y detalle             
	   -- procesa cada alumno              
	   --EXEC cMatricula_ProcesoxAlumno @CurIdMatricula,@CurIdPromocion,@CurIdGrupo,@IdUsuario,@ERRORCODIGO OUT, @DESCRIPCIONERROR OUT              
	   exec cMatricula_Upd_MatriculaSecuencial @CurIdMatricula, @IdUsuario,@CompaniaSocio,@EstadoMatricula OUT,@DESCRIPCIONERROR OUT    --@1   
	       
	   IF @EstadoMatricula is null     
		  BEGIN    
			SET @DESCRIPCIONERROR = 'Ok'          
			SET @EstadoMatricula =  'Matricula Completa'      
			--llamamos al procedure de biblioteca
			--exec SP_SincronizacionBiblioteca  @CurIdAlumno,@CurCodigoAlumno,1,@IdUnidadAcademica
		 END                     
	END              
   END            
            
  UPDATE #Matricula                
  SET Observacion=@DESCRIPCIONERROR,              
  Estado =  @EstadoMatricula,            
  CodigoAlumno = @CurCodigoAlumno            
  WHERE Id=@CurID                
              
    set @CurID = @CurID +1                
 END -- while                 
              
  --SE DEVUELVEN LOS RESULTADOS                
  SELECT --Id,            
  IdMatricula ,                  
  PromocionIdEmpresa ,                  
  PromocionIdSede ,                  
  PromocionIdFacultad ,                  
  PromocionIdUnidadNegocio ,                  
  PromocionIdUnidadAcademica ,                 
  PromocionIdPeriodo ,                  
  PromocionIdProducto ,                  
  ProductoNombre ,                  
  IdPromocion ,                  
  PromocionNombre ,                
  'IdGrupo'=ISNULL(IdGrupo,'') ,                  
  'GrupoCodigo'=ISNULL(GrupoCodigo,'') ,                
  ActorIdActor ,                
  'ActorNombreCompleto'=ISNULL(CodigoAlumno,'')+'-'+ActorNombreCompleto ,                
  Observacion ,               
  Estado--,  IdRegistro            
  FROM #Matricula                
       
  insert into ResultadoMatricula(IdMatricula,IdSede,IdUnidadNegocio,IdUnidadAcademica,IdPeriodo,IdProducto,ProductoNombre,                  
						         IdPromocion,PromocionNombre,IdGrupo,GrupoCodigo,IdActor,NombreCompleto,Observacion,Estado)
  SELECT IdMatricula,PromocionIdSede,PromocionIdUnidadNegocio,PromocionIdUnidadAcademica,
  PromocionIdPeriodo,PromocionIdProducto,ProductoNombre,IdPromocion,PromocionNombre,IdGrupo,
  GrupoCodigo,ActorIdActor,ISNULL(CodigoAlumno,'')+'-'+ActorNombreCompleto,Observacion,Estado--,  IdRegistro          
  FROM #Matricula 
           
  DROP TABLE #Matricula                
                 
  SET NOCOUNT OFF                
END  -- FIN DEL PROCEDIMIENTO
