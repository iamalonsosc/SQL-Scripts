--SELECT*FROM Registro
UPDATE Registro SET Estado='X'
WHERE IdActor=1620027
AND IdRegistro=4
--(1 row affected)