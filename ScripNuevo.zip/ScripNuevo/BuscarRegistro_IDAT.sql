select * from actor where NombreCompleto like 'CHIARA TRUJILLO EDUARDO DANIEL%' ---77379395
--numeroidentidad='77379395'

---BUSCAR REGISTROS DEL ALUMNO 
SELECT a.NombreCompleto, C.Codigo, S.Nombre, UN.Nombre, P.ProductoNombre,U.Login,AC.IdCurricula, R.* FROM REGISTRO R 
INNER JOIN ACTOR A ON R.IdActor = A.IdActor
INNER JOIN SEDE S ON R.IdSede=S.IdSede
INNER JOIN UnidadNegocio UN ON R.IdUnidadNegocio = UN.IdUnidadNegocio
INNER JOIN PRODUCTO P ON R.IdProducto=P.IdProducto 
INNER JOIN Usuario U ON R.UsuarioCreacion = U.IdUsuario
INNER JOIN AlumnoCurricula AC ON R.IdActor = AC.IdAlumno AND R.IdRegistro = AC.IdRegistro
INNER JOIN CURRICULA C ON AC.IdCurricula=C.IdCurricula
WHERE R.IdActor=1413648 AND R.Estado='N'

----BUSCAR POR MALLA Y CURSO
select c.nombre,c.Codigo,CU.CursoNombre,cu.CursoCodigo ,c.Codigo,ac.* from AlumnoCurriculaCurso ac 
inner join curricula c on ac.idcurricula =c.idcurricula
INNER JOIN CURSO CU ON AC.IdCurso=CU.IDCURSO
where IdAlumno = 1413648 and ac.IdCurricula=5612--c.Codigo='0217.01' --
--and  promediofinal is null -- 
 AND ac.idcurso=10500 
--and IdModulo in (1) 
--AND CU.CursoCodigo='0453'
order by IdModulo

select * from alumnocurriculacurso where IdAlumno = 1413648 and IdCurricula=5612 order by IdModulo