--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=726782


--SELECT TipoCondicion,*FROM AlumnoCurso 
----UPDATE AlumnoCurso SET TipoCondicion='RE'
--where IdMatricula=726782 AND EsMatricula=1 
--select*from curso where IdCurso=10560

----RP(PROMOVIDO + CURSO)
------CC(CURSO REPITENCIA)
------RT(REPITENCIA)
------RE(PROMOVIDO)
--SELECT*FROM AlumnoCursoNomina WHERE IdMatricula=713661




--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET PromedioFinal='DPI',PromedioReal='DPI',PromedioCondicion='D',estado='NO'
WHERE  IdCurso in (9870) AND IdAlumno=1751928 AND IdMatricula=726782 


UPDATE AlumnoCurriculaCurso SET PromedioFinal='00.00',PromedioReal='00.00',PromedioCondicion='D',IdAlumnoCurso=9
WHERE IdAlumno=1751928 AND IdRegistro=1 AND IdCurso in (9870)
