--����������������������������������������������������������������������������                                    
--Creado por      : Luis Perales                                     
--Funcionalidad   : Permite procesar la matricula de los cursos de un nuevo alumno                                  
--Utilizado por   :                                   
--����������������������������������������������������������������������������                                    
/*                                
-----------------------------------------------------------------------------                                
Nro FECHA  USUARIO  DESCRIPCION                                
-----------------------------------------------------------------------------                  
@1 03/09/2013 lperales  No debe actualizar siempre la fecha de matricula solo cuando no este matriculado                                                        
@1  05.03.2012  plozada   Creacion de atenci�n a partir de un contacto matriculado                    
@2  03.10.2018  rvera    Actualiza FechaComision Planilla Comercial    
@3  11.01.2019  Eloy Alva (Sigcomt) Agregar parametro CompaniaSocio.    
@4  17.04.2019  Giancarlos Cuba(Sigcomt) Se retira la sede de ica y chincha de la validaci�n ASOC.    
@5  18.12.2020  JLEO  Cambio de S I D B 0 1\S Q L 2 0 1 7 --> [ E C 2 A M A Z - C P P A Q I Q \ S Q L 2 0 1 7]    
@6 2020.02.05 hcachi  Se cambia tama�o del campo de la tabla variable @CCursos (como esta en la tabla Curso)    
@7 2021.05.01 JBERNUY  parametrizar ServidorVinculado    
@8 11.10.2022 MBUENO  Se cambia actualizacion UsuarioReferido por un store    
@9  06.12.2022 ALSANCHEZ Se agrega logica para insertar data en la tabla matricula producto, zegel virtual.    
@10 14.10.2023  LPARIONA    Se agrega campos para la migracion de zv al servicio del proveedor    
@11 12.01.2024  LPARIONA    Se mejora el proceso para obtener el ultimo correo/telefono registrado del contacto    
@12 22.02.2024  LPARIONA    Se comenta @IdTipoMembresia para las matriculas de membresias por cambio en el servicio    
@13 02.04.2024  JGuillen    Se realizo mejora en el order by para que tome la fechacreacion en caso no haya fechamodificacion   
@14 18.09.2024  FETORRES    Se agrega la logica de la fusion CA/ZEGEL     
@15 30.09.2024  MQUIROZ     Se agrega la logica ITS  
@16 21.01.2025  Mquiroz		Se agrega correcion
@17 14.08.2025  Alsanchez	Se agrega el sp para actualizar su EsUsuarioAD
*/    
--sp_helptext [cMatricula_ProcesoxAlumno]     
--CREATE PROCEDURE [dbo].[cMatricula_ProcesoxAlumno]
DECLARE
@pIdMatricula INT=840984,                        
@pIdPromocion INT=101881,                        
@pIdGrupo INT,                        
@pIdUsuario INT,     
@pEstadoMatricula INT ,                        
@pMensaje VARCHAR(4000)                         
--AS                                
BEGIN                        
 SET NOCOUNT ON                        
 DECLARE                         
    @CurIdCurso INT,                        
    @CurCursoNombre VARCHAR(100),                        
    @CurCursoCodigo VARCHAR(100),                        
    @pTotalCursos INT,                        
    @pTotalCursosMatriculados INT,                        
    @pMensajeCursos VARCHAR(8000),                        
    @pMatriculado INT ,                      
    @ExisteCursos INT,                   
    @EsMatricula INT ,              
    @xEsMatricula  INT,              
    @xIdSede INT  ,    
 @CompaniaSocio CHAR(8), --@3         
 --inicio @12    
 @NumeroDocumento VARCHAR(20)    
 ,@NombreCompleto VARCHAR(300)    
 ,@IdTipoDocumento INT    
 ,@CorreoPersonal VARCHAR(300)    
 ,@CodProductoZV VARCHAR(300)     
 ,@ClasificacionProducto VARCHAR(300)    
 ,@ProductoNombre VARCHAR(500)    
 ,@EsMembresiaZV BIT    
 ,@FechaMatricula datetime    
 ,@GrupoDescuento VARCHAR(200)    
 ,@CodEmpresaZV VARCHAR(50)    
 ,@IdEmpresaZV INT    
 ,@TipoMigracionZV varchar(3)--@10    
 --fin @12    
                  
 select @TipoMigracionZV = Valor from Parametro with (nolock) where Nombre = 'MIGRARMATRICULAZV'--lpariona    
 SET XACT_ABORT ON       
     
    --@7 Inicio    
 DECLARE @ServidorVinculadoAcad varchar(50)    
 ,@ServidorVinculadoAcadASOC varchar(50)    
 ,@BaseDatos varchar(50)    
 ,@BaseDatosASOC varchar(50)    
     
 ,@Tsql1 nvarchar(max)    
 ,@CadSql1 nvarchar(max)    
 ,@ParamCadSql1 nvarchar(max)    
 ,@CadSql2 nvarchar(max)    
    ,@ParamCadSql2 nvarchar(max)    
     
 SELECT @ServidorVinculadoAcad=Valor,@BaseDatos=valor2  FROM Parametro (NOLOCK) WHERE Nombre='ServidorVinculadoSpring'    
 SELECT @ServidorVinculadoAcadASOC=Valor,@BaseDatosASOC=valor2 FROM Parametro (NOLOCK) WHERE Nombre='ServidorVinculadoSpringASOC'    
 --@7 Fin    
     
 SELECT @CompaniaSocio = CompaniaSocio      
 FROM Promocion p WITH(NOLOCK)    
 INNER JOIN Empresa e WITH(NOLOCK) ON  e.IdEmpresa = P.IdEmpresa     
 WHERE p.IdPromocion=@pIdPromocion      
  
  
  IF @CompaniaSocio ='00002600' or @CompaniaSocio = '00002400'--@14 --@15  --@16
 BEGIN    
 SELECT @CompaniaSocio = CompaniaSocioPadre from Empresa  
 END    
                 
                        
 SET @pTotalCursosMatriculados = 0                        
 SET @pTotalCursos = 0                        
 SET @pMensajeCursos = ''                      
 SET @ExisteCursos = 0                      
             
  DECLARE @CCursos TABLE (Id INT IDENTITY,              
        IdCurso INT,              
        CursoCodigo VARCHAR(10),              
        CursoNombre VARCHAR(200), --@6              
        EsMatricula INT)              
    
  INSERT INTO @CCursos               
  SELECT A.IdCurso, B.CursoCodigo, B.CursoNombre , c.EsMatricula                   
  FROM AlumnoCurso A WITH (NOLOCK)               
  inner join Curso B WITH (NOLOCK)                       
  on A.IdCurso = B.IdCurso              
  inner join matricula c WITH (NOLOCK)               
  on a.idmatricula = c.idmatricula              
  WHERE A.IdMatricula = @pIdMatricula                                
    AND A.EsMatricula = 0                 
                           
                     
 WHILE EXISTS (SELECT * FROM @CCursos)              
  BEGIN -- Cursor de Cursos matriculados                  
                
   SELECT TOP 1 @CurIdCurso = IdCurso,                    
   @CurCursoCodigo = CursoCodigo,                    
   @CurCursoNombre = CursoNombre,                    
   @EsMatricula = EsMatricula              
   FROM @CCursos                         
   ORDER BY Id                  
                 
   SET @ExisteCursos = 1                      
   SET @pTotalCursos = @pTotalCursos + 1                        
   --SET @pMatriculado = 0                        
   --select 'entro'                      
   EXEC cMatricula_ProcesaxCurso @pIdMatricula, @pIdPromocion,@pIdGrupo,@CurIdCurso,@pIdUsuario,@pMatriculado OUT             
   --select '@pMatriculado' = @pMatriculado                      
                       
   IF @pMatriculado = 1                        
    BEGIN           
     SET @pTotalCursosMatriculados = @pTotalCursosMatriculados +1                 
                   
     IF @pMensajeCursos = ''                        
      SET @pMensajeCursos = 'Curso ' + @CurCursoCodigo+'-'+@CurCursoNombre + ' matriculado'                        
     ELSE                        
      SET @pMensajeCursos = @pMensajeCursos + ', Curso ' + @CurCursoCodigo+'-'+@CurCursoNombre + ' matriculado'                        
   END              
      
   IF @pMatriculado = -1 -- no hay horarios                        
    BEGIN                      
     IF @pMensajeCursos = ''                        
      SET @pMensajeCursos = 'Curso ' + @CurCursoCodigo+'-'+@CurCursoNombre + ' no tiene horarios'                        
     ELSE      
      SET @pMensajeCursos = @pMensajeCursos + ', Curso ' + @CurCursoCodigo+'-'+@CurCursoNombre + ' no tiene horarios'                        
    END                
           
   IF @pMatriculado = 0 -- no hay vacantes                           
    BEGIN                      
     IF @pMensajeCursos = ''                        
      SET @pMensajeCursos = 'Curso ' + @CurCursoCodigo+'-'+@CurCursoNombre + ' no tiene vacantes'                        
     ELSE                        
      SET @pMensajeCursos = @pMensajeCursos + ', Curso ' + @CurCursoCodigo+'-'+@CurCursoNombre + ' no tiene vacantes'                       
    END                      
 -- FETCH NEXT FROM CCursos INTO @CurIdCurso,@CurCursoCodigo,@CurCursoNombre  ,@EsMatricula               
                      
  -- eliminamos el registro procesado                      
  DELETE N FROM @CCursos N                        
  WHERE N.Id = (SELECT TOP 1 Id                         
  FROM @CCursos                         
  ORDER BY Id)                        
              
 END -- Cursor de Cursos matriculados                        
                      
           
                       
 IF @pTotalCursosMatriculados = 0  AND @ExisteCursos=0                     
  BEGIN                        
  IF  isnull(@EsMatricula,1) <> 1              
    BEGIN              
      SET @pMensaje = 'No Matriculado, No tiene cursos matriculados en el detalle de su matricula'                      
      SET @pEstadoMatricula = 0                        
    END              
  ELSE               
    BEGIN              
      --SET @pMensaje = 'Matricula Completa'                      
      SET @pEstadoMatricula =5                        
    END              
  END                         
 ELSE                      
   BEGIN                      
    IF @pTotalCursosMatriculados = 0  AND @ExisteCursos=1                      
   BEGIN                        
     --select 'entro1'                      
   SET @pMensaje = @pMensajeCursos                        
   SET @pEstadoMatricula = 0                        
   END                         
                          
    IF @pTotalCursos = @pTotalCursosMatriculados -- and @pMensaje = ''                      
   BEGIN                        
    --select 'entro2'                      
    SET @pMensaje = @pMensajeCursos                      
    SET @pEstadoMatricula = 1                        
   END        
                           
    IF  @pTotalCursosMatriculados >0 and @pTotalCursosMatriculados < @pTotalCursos -- and @pMensaje = ''                      
    BEGIN                        
     --select 'entro3'                      
    SET @pMensaje =  @pMensajeCursos         
    SET @pEstadoMatricula = 2                        
    END                        
  END  --else                    
                        
  --select @pEstadoMatricula                      
  IF @pEstadoMatricula <> 0 or @pEstadoMatricula <> 5                  
     BEGIN                    
   --@1 lperales              
   select @xEsMatricula = EsMatricula,      
   @xIdSede = IdSede               
   from Matricula WITH (NOLOCK)              
   where IdMatricula =    @pIdMatricula      
                 
   --@1 lperales      
   IF @xEsMatricula = 0  --@1 lperales              
    BEGIN --@1 lperales              
     UPDATE Matricula                        
     SET EsMatricula = 1,                        
     MatriculaFecha = GETDATE(),          
  FechaComision= GETDATE(), --@2    
     UsuarioModificacion = @pIdUsuario,                        
     FechaModificacion = GETDATE(),                      
     MatriculaIdUsuario =  @pIdUsuario                       
     WHERE IdMatricula = @pIdMatricula    
      
 --@8    
 EXEC cUsuarioReferido_Upd_Matricula @pIdUsuario, @pIdMatricula    
 --@8

 EXECUTE cUsuario_Upd_UsuarioAD @pIdUsuario --@17
            
     if @xIdSede in (4) --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
  BEGIN    
     --Actualizamos si a Matriculado el campo EsMatricula en la interface                
      --UPDATE S I D B 0 1.S p r i n g U n i d o.dbo.co_Interfase_p09_header               
      --SET EsMatricula=1               
      --where IdMatricula = @pIdMatricula    
    
      --exec [ E C 2 A M A Z - C P P A Q I Q \ S Q L 2 0 1 7].S p r i n g U n i d o.dbo.cco_Interfase_p09_header_Upd_EsMatricula_SIDB01 @pIdMatricula,1,@CompaniaSocio --@3 --@5    
      --@7 Inicio    
   SET @CadSql1 = N''+@ServidorVinculadoAcadASOC+'.'+@BaseDatosASOC+'.dbo.cco_Interfase_p09_header_Upd_EsMatricula_SIDB01 @pIdMatricula,1,@CompaniaSocio'    
   SET @ParamCadSql1 = N'@pIdMatricula INT,@CompaniaSocio CHAR(8)'    
   EXEC sp_executesql @CadSql1, @ParamCadSql1, @pIdMatricula = @pIdMatricula,@CompaniaSocio = @CompaniaSocio;    
   --@7 Fin    
    
   --begin            
      -- DECLARE @TSQL varchar(500)            
      -- SET @TSQL = 'UPDATE OPENQUERY (SIBDTEST01, ''SELECT EsMatricula FROM SpringUnidoGE.dbo.co_Interfase_p09_header WHERE IdMatricula = '+cast(@pIdMatricula as varchar)  +''') SET EsMatricula = 1'            
      -- EXEC (@TSQL)                 
      END            
     else      
  BEGIN    
      --Actualizamos si a Matriculado el campo EsMatricula en la interface      
    
      --exec P L D  B 0 1.S p r i n g U n i d o.dbo.cco_Interfase_p09_header_Upd_EsMatricula_PLDB01 @pIdMatricula,1 ,@CompaniaSocio --@3    
      --@7 Inicio    
   SET @CadSql2 = N''+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.cco_Interfase_p09_header_Upd_EsMatricula_PLDB01 @pIdMatricula,1 ,@CompaniaSocio'    
    
   SET @ParamCadSql2 = N'@pIdMatricula INT, @CompaniaSocio CHAR(8)'    
    
   EXEC sp_executesql @CadSql2, @ParamCadSql2, @pIdMatricula = @pIdMatricula, @CompaniaSocio = @CompaniaSocio;    
   --@7 Fin    
    
   --UPDATE PLDB01.S p r i n g U n i d o.dbo.co_Interfase_p09_header               
      --SET EsMatricula=1               
      --where IdMatricula = @pIdMatricula                
     --begin            
     --DECLARE @TSQL1 varchar(500)            
     --SET @TSQL1 = 'UPDATE OPENQUERY (PLDBTEST02, ''SELECT EsMatricula FROM SpringUnidoGE.dbo.co_Interfase_p09_header WHERE IdMatricula = '+cast(@pIdMatricula as varchar)  +''') SET EsMatricula = 1'            
     --EXEC (@TSQL1)            
     END                   
    END   --@1 lperales               
  END                        
   --SET NOCOUNT OFF                            
                       
                         
  /*@1 Inicio */                             
  Declare @IdContacto int,                   
   @IdSede int,                    
   @IdEmpresa int,                    
   @IdCounter int ,                   
   @IdUsuarioCreacion int,                     
   @IdProducto int ,                   
   @RetVal int                    
   --@10    
 ,@Telefono varchar(20)    
 ,@Nombres varchar(100)    
 ,@ApellidoPaterno varchar(200)    
 ,@ApellidoMaterno varchar(200)    
 ,@IdTipoMembresia int = 0    
 ,@IdDocumentoTipo int    
 ,@IdTipoEmpresaZV int    
 --fin @10                
  --establecemos los valores a las variables                    
  select @IdContacto=ma.IdActor,      
  @IdSede=ma.IdSede,       
  @IdEmpresa=ma.IdEmpresa,      
  @IdCounter=ma.UsuarioCreacion,      
  @IdProducto = pr.IdProducto,    
  @FechaMatricula= ma.MatriculaFecha, --@9    
  @IdEmpresaZV= ISNULL(ma.IdEmpresaZV,-1), --@9    
  @ProductoNombre= pro.ProductoNombre, --@9    
  @CodProductoZV= ISNULL(pro.CodProductoZV,''), --@9    
  @EsMembresiaZV= ISNULL(pro.EsMembresiaZV,0) --@9                  
  from matricula ma WITH (NOLOCK)                  
  INNER join Promocion pr WITH (NOLOCK)on (ma.IdPromocion = pr.IdPromocion)                    
  INNER JOIN Producto pro WITH (NOLOCK) ON (pr.idproducto = pro.IdProducto)    
  where ma.IdMatricula= @pIdMatricula      
     
    --inicio @9    
 IF @IdEmpresaZV <> -1    
 BEGIN    
  SELECT TOP 1     
  @NombreCompleto=ISNULL(a.NombreCompleto,'')    
  ,@NumeroDocumento=ISNULL(a.NumeroIdentidad,'')    
  ,@IdTipoDocumento=ISNULL(a.IdDocumentoTipo,-1)    
  ,@CorreoPersonal= AC.Descripcion     
  ,@Telefono = ISNULL(AT.Descripcion,'')--@10--@11    
  ,@Nombres = A.Nombres--@10    
  ,@ApellidoMaterno = A.Materno--@10    
  ,@ApellidoPaterno = A.Paterno--@10    
  ,@IdDocumentoTipo =CASE --@10    
   WHEN mtr.codigo = 'DNI' then 1    
   WHEN mtr.codigo = 'C.E.' then 2    
   WHEN mtr.codigo = 'PAS' then 3    
  END    
  FROM Actor A WITH(NOLOCK)    
  --LEFT JOIN ActorEmail AC WITH(NOLOCK) ON A.IdActor = AC.IdActor AND AC.IdTipoEmail=739--@10--@11    
  LEFT JOIN (SELECT    
      AE1.Descripcion,    
      AE1.IdActor,    
      AE1.FechaCreacion,    
      ROW_NUMBER() OVER(PARTITION BY AE1.idactor ORDER BY ISNULL(AE1.FechaModificacion,AE1.FechaCreacion) DESC) AS RowNum -- @13    
     FROM ActorEmail AE1 WITH (NOLOCK)     
     WHERE AE1.IdTipoEmail = 739    
    ) AC on A.IdActor = AC.IdActor and AC.RowNum = 1--@11    
  --LEFT JOIN ActorTelefono AT WITH(NOLOCK) ON A.IdActor = AT.IdActor and AT.IdTipoTelefono = 287--@10--@11    
  LEFT JOIN (SELECT    
      AT1.Descripcion,    
      AT1.IdActor,    
      AT1.FechaCreacion,    
      ROW_NUMBER() OVER(PARTITION BY AT1.idactor ORDER BY ISNULL(AT1.FechaModificacion,AT1.FechaCreacion)desc )as RowNum -- @13    
     FROM ActorTelefono AT1 WITH (NOLOCK)     
     WHERE AT1.IdTipoTelefono = 287    
    ) AT on AT.RowNum = 1 and A.IdActor = AT.IdActor and ISNULL(AT.Descripcion,'') <> '' --@11    
  INNER JOIN Maestrotablaregistro MTR WITH(NOLOCK) ON A.IdDocumentoTipo = mtr.idmaestroregistro --@10    
  WHERE AC.IdActor=@IdContacto     
  --AND AC.IdTipoEmail=739--@11    
  AND ISNULL(AC.Descripcion,'') <> ''     
  --AND ISNULL(AT.Descripcion,'') <> '' --@10--@11     
    
  SELECT TOP 1 @GrupoDescuento=GrupoDescuento     
  FROM DescuentoAlumnoResultado WITH(NOLOCK)    
  WHERE IdMatricula=@pIdMatricula     
  AND IdTipo=23951    
    
  SELECT @CodEmpresaZV=Codigo     
  ,@IdTipoEmpresaZV = Disponible4--@10    
  FROM MaestroTablaRegistro WITH(NOLOCK)     
  WHERE IdMaestroRegistro=@IdEmpresaZV    
    
  IF CHARINDEX('CURSO',@ProductoNombre)>0    
   BEGIN    
    SET @ClasificacionProducto = 'CURSO'    
   END    
  IF CHARINDEX('PROGRAMA',@ProductoNombre)>0    
   BEGIN    
    SET @ClasificacionProducto = 'PROGRAMA'    
   END    
  IF CHARINDEX('MEMBRES�A',@ProductoNombre)>0    
   BEGIN    
    SET @ClasificacionProducto = 'MEMBRESIA'    
    --SET @IdTipoMembresia = @CodProductoZV--@10--@12    
   END    
    
  IF NOT EXISTS (SELECT 1 FROM Log_MatriculaProductoZegelVirtual WITH(NOLOCK) WHERE IdMatricula = @pIdMatricula)    
  BEGIN    
   INSERT INTO Log_MatriculaProductoZegelVirtual    
   (CodEmpresa,IdMatricula,CodProductoZV,ClasificacionProducto,EsMembresia,NumeroDocumento,NombreCompleto,IdTipoDocumento,    
   CorreoPersonal,ContrasenaZV,FechaMatricula,GrupoDescuento,UsuarioCreacion,FechaCreacion,Estado,Nombres,ApellidoPaterno,ApellidoMaterno,Telefono,IdTipoMembresia,IdEmpresa,IdDocumentoTipo,Tipo)--@10    
   VALUES (@CodEmpresaZV,@pIdMatricula,@CodProductoZV,@ClasificacionProducto,@EsMembresiaZV,@NumeroDocumento,    
   @NombreCompleto,@IdTipoDocumento,@CorreoPersonal,@NumeroDocumento,@FechaMatricula,@GrupoDescuento,1,GETDATE(),'N',@Nombres,@ApellidoPaterno,@ApellidoMaterno,@Telefono,@IdTipoMembresia,@IdTipoEmpresaZV,@IdDocumentoTipo,CAST(@TipoMigracionZV as int))--@
1

    
    
  END    
 END    
 --fin @9    
                   
  --    
 --comentado por gguillen 26/06/2018 para que no se inserten atenciones en el proceso de VRA    
  --if not exists ( select * from InteresadoContactoAtencion  WITH (NOLOCK)           
  --    where idcontacto = @IdContacto                    
  --    and idempresa = @IdEmpresa                
  --    and idsede = @IdSede                    
  --    and IdTipoAtencion = 319                    
  --    and IdMatricula = @pIdMatricula )                    
  --  begin    
  --  exec cContactoAtencion_Ins_Grabar                    
  --  @IdContacto ,NULL ,@IdEmpresa ,@IdSede ,NULL ,@IdCounter ,NULL ,                             
  --  319 ,NULL ,NULL ,325 , 39 ,NULL ,NULL ,NULL ,                                              
  --  NULL ,NULL ,NULL , NULL , NULL ,NULL ,NULL ,NULL ,NULL ,@pIdMatricula ,                                            
  --  NULL ,NULL ,NULL ,NULL ,NULL ,@pIdUsuario ,@RetVal OUTPUT                      
                           
  --  exec cContactoInteresado_Ins_Grabar   @IdContacto , @RetVal,@IdProducto,@pIdUsuario                    
 --  end    
    /*@1 Fin */                    
    SET XACT_ABORT OFF                        
 END -- fin del procedimiento
