UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula=610638

--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1247549 AND IdRegistro=1 AND IdCurso=10141 AND IdCurricula=51



SELECT*FROM AlumnoCurso 
WHERE IdAlumno=1247549 AND IdCurso in (9795)--IdMatricula=612427

--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=45
WHERE IdMatricula=777584 AND IdCurso=10141
--(1 fila afectada)



--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=5,IdAlumnoCurso=2,IdcurriculaOriginal=5615
WHERE IdMatricula=610638 AND IdCurso=10141




--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='16.00',PromedioReal='16.48',IdAlumnoCurso=1,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1247549 AND IdRegistro=5 AND IdCurso=10141 AND IdCurricula=5615



--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=5,IdCurricula=5615
WHERE IdMatricula=610638

-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO

UPDATE Matricula SET Estado='X'
WHERE IdMatricula=777584