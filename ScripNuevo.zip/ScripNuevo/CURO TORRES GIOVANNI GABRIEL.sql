--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=676451


--SELECT TipoCondicion,*FROM AlumnoCurso 
----UPDATE Matricula SET TipoCondicion='CC'
--where IdMatricula=676451 AND EsMatricula=1

----RP(PROMOVIDO + CURSO)
----CC(CURSO REPITENCIA)
----RT(REPITENCIA)
----RE(PROMOVIDO)
