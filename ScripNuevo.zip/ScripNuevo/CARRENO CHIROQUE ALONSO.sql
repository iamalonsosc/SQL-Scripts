--SELECT*FROM AlumnoCurricula 
UPDATE AlumnoCurricula SET Activo=0
where IdAlumno=1427482 and IdRegistro=1

UPDATE Registro SET Estado='X'
WHERE IdActor=1427482 AND IdRegistro=1

--SELECT*FROM  AlumnoCurriculaCurso
--ESTRUCTURA DE DATOS Y PROGRAMACION ORIENTADA A OBJETOS
UPDATE AlumnoCurriculaCurso SET PromedioFinal='10.00',PromedioCondicion='D',PromedioReal='10'
WHERE IdAlumno=1427482 AND IdRegistro=2 AND IdCurso=10439 AND IdCurricula=29

--PROYECTO DESARROLLO SOFTWARE I
UPDATE AlumnoCurriculaCurso SET PromedioFinal='11.00',PromedioCondicion='D',PromedioReal='11'
WHERE IdAlumno=1427482 AND IdRegistro=2 AND IdCurso=10501 AND IdCurricula=29


--ADMINISTRACI�N DE BASE DE DATOS
UPDATE AlumnoCurriculaCurso SET PromedioFinal='13.00',PromedioCondicion='A',PromedioReal='13'
WHERE IdAlumno=1427482 AND IdRegistro=3 AND IdCurso=9794 AND IdCurricula=28


--HERRAMIENTAS DE PROGRAMACI�N I
UPDATE AlumnoCurriculaCurso SET PromedioFinal='11.00',PromedioCondicion='D',PromedioReal='11'
WHERE IdAlumno=1427482 AND IdRegistro=3 AND IdCurso=10447 AND IdCurricula=28


--AN�LISIS Y DISE�O DE SISTEMAS ORIENTADAS A OBJETOS
UPDATE AlumnoCurriculaCurso SET PromedioFinal='15.00',PromedioCondicion='A',PromedioReal='15'
WHERE IdAlumno=1427482 AND IdRegistro=3 AND IdCurso=10442 AND IdCurricula=28

--PASO 2 TRASLADO DE PROGRAMA

UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (614313,700439)
--
UPDATE Registro SET Estado='X'
WHERE IdActor=1427482 AND IdRegistro=4

UPDATE Registro SET Estado='X'
WHERE IdActor=1427482 AND IdRegistro=2

UPDATE AlumnoCurricula SET Activo=0
where IdAlumno=1427482 and IdRegistro=4


--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1427482 AND IdRegistro=3 AND IdCurso=10438 AND IdCurricula=28



UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1427482 AND IdRegistro=3 AND IdCurso=10442 AND IdCurricula=28



SELECT*FROM AlumnoCurso 
--DELETE FROM AlumnoCurso
WHERE IdAlumno=1427482 AND IdCurso in (13520) AND IdCurricula=193


--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=8
WHERE IdMatricula=778245 AND IdCurso=10438
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=9
WHERE IdMatricula=778245 AND IdCurso=10442


--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=5,IdAlumnoCurso=1,IdcurriculaOriginal=5805
WHERE IdMatricula=614313 AND IdCurso=10438

UPDATE AlumnoCurso SET IdRegistro=5,IdAlumnoCurso=2,IdcurriculaOriginal=5805
WHERE IdMatricula=614313 AND IdCurso=10442




--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='15.00',PromedioReal='15.24',IdAlumnoCurso=8,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1427482 AND IdRegistro=5 AND IdCurso=10438 AND IdCurricula=5805


UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='17.00',PromedioReal='17.40',IdAlumnoCurso=9,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1427482 AND IdRegistro=5 AND IdCurso=10442 AND IdCurricula=5805



UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='14',PromedioReal='14.00',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA',IdConvalidacion=51128
WHERE IdAlumno=1427482 AND IdRegistro=5 AND IdCurso=13520 AND IdCurricula=5805



--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdGrupo=1,IdRegistro=5,IdCurricula=5805,IdPromocion=101375
WHERE IdMatricula=614313

-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO

UPDATE Matricula SET Estado='X'
WHERE IdMatricula=778245



UPDATE Matricula SET Estado='N'
WHERE IdMatricula IN (700439)

UPDATE Registro SET Estado='N'
WHERE IdActor=1427482 AND IdRegistro=4

--UPDATE Registro SET Estado='N'
--WHERE IdActor=1427482 AND IdRegistro=2

UPDATE AlumnoCurricula SET Activo=1
where IdAlumno=1427482 and IdRegistro=4



--LUEGO DE LA CARGA DE MIGRACION ELIMINAMOS SUS CURSOS REPETIDOS
DELETE FROM AlumnoCurso
WHERE IdAlumno=1427482 AND IdCurricula=193 and IdRegistro=1 AND IdMatricula=305618 AND IdPromocion=80562