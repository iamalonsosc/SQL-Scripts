DECLARE
@IdMin INT
,@IdMax INT
,@IdProgramacion_ListaEncuestasProgramadas INT
,@RetVal_ListaEncuestasProgramadas INT

DECLARE @ListaEncuestasProgramadas AS TABLE (Id INT IDENTITY (1,1)
,IdProgramacion INT
)


BEGIN
INSERT INTO @ListaEncuestasProgramadas values(31454)

END

SELECT @IdMin = MIN(Id), @IdMax = MAX(Id) FROM @ListaEncuestasProgramadas       

WHILE @IdMin <= @IdMax            
BEGIN   

	SET @IdProgramacion_ListaEncuestasProgramadas = NULL
	SET @RetVal_ListaEncuestasProgramadas = 0

	SELECT @IdProgramacion_ListaEncuestasProgramadas = IdProgramacion
	FROM @ListaEncuestasProgramadas
	WHERE Id = @IdMin

	exec cFichaProgramacionResumen_Ins_Grabar @IdProgramacion=@IdProgramacion_ListaEncuestasProgramadas,@UsuarioCreacion=1,@RetVal=@RetVal_ListaEncuestasProgramadas output

	PRINT 'Proceso Terminado'
	select�@RetVal_ListaEncuestasProgramadas

	SET @IdMin = @IdMin + 1
END