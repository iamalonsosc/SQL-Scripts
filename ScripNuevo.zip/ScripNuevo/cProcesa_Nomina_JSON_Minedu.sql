--����������������������������������������������������������������������������            
--Creado por      : Fabrizzio Martinez Campos (14/05/2024)            
--Funcionalidad   :   
--Utilizado por   :  
--����������������������������������������������������������������������������       
/*                            
-----------------------------------------------------------------------------                            
Nro		FECHA			USUARIO			DESCRIPCION     
@1		30/01/2025		RAlcantara		Se agregan nuevos campos para el proceso de nominas de JSON minedu
@2		15/10/2025		Illosad			Se modifica nombre plan de estudios 
@3		20/10/2025		Illosad			Se agrega SeccionMinedu a las validaciones para observacion 
@4		27/10/2025		Illosad			Se cambia left por inner join para reducir tiempo de consulta
@5		27/01/2026		Alsanchez		Se agrega nueco campo OBSERVACION
@6		10/03/2026		Alsanchez		Se modifica el id del PASAPORTE
-----------------------------------------------------------------------------   

*/ 
ALTER PROCEDURE cProcesa_Nomina_JSON_Minedu
@IdPeriodo int,
@IdEmpresa int,
@IdSedeNomina int ,
@IdUnidadAcademicaNomina int,
@IdUnidadNegocioNomina int,
@IdProductoNomina int,
@IdUsuario int -- = 1
AS
BEGIN 
SET NOCOUNT ON
DECLARE @cmodular NVARCHAR(30),
@usuarioMinedu NVARCHAR(100) ,
@claveMinedu NVARCHAR(100),
@CompaniaSocio VARCHAR(20)

select @CompaniaSocio=CompaniaSocio from Empresa WITH(NOLOCK) WHERE Activo = 1

SELECT DISTINCT @cmodular = ISNULL(Valor10 ,'')  
FROM ParametroUnidadAcademica WITH(NOLOCK)  
WHERE IdEmpresa= @IdEmpresa AND   
	  IdUnidadNegocio = @idunidadnegocionomina  AND
	  IdUnidadAcademica = @idunidadacademicanomina  AND
	  IdSede = @idsedenomina   AND
	  (IdProducto = @idproductonomina OR @idproductonomina = 0)  AND
	  Nombre='ParametroNomina1' 

IF @CompaniaSocio = '00002500' or @CompaniaSocio = '00002400'
BEGIN
	SELECT @claveMinedu = Valor,@usuarioMinedu=Valor3 FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular
END
ELSE IF @CompaniaSocio = '00002700'
BEGIN
	SELECT @usuarioMinedu=ISNULL(Valor2,Valor) FROM parametro WITH(NOLOCK) WHERE  Nombre='UsuarioMinedu'
	SELECT @claveMinedu = Valor FROM parametro WITH (NOLOCK) WHERE Valor2 = @cmodular
END

DECLARE @tableSecciones table(
id int identity,
idProducto int,
nombreProducto VARCHAR(250),
esNuevo int,
seccion VARCHAR(200),
seccionMinedu VARCHAR(250),
idSede int,
fechaInicio VARCHAR(200),
turnoNombre VARCHAR(200),
fechaFin VARCHAR(200),
periodoCodigo VARCHAR(100),
periodoCodigoMinedu VARCHAR(100),
nombreSede VARCHAR(max),
nivelFormativo VARCHAR(250),
codigoModular VARCHAR(200),
planEstudio VARCHAR(250)
)

DECLARE @tableAlumnosSecciones table (
id int identity,
usuarioMinedu NVARCHAR(100) ,
claveMinedu NVARCHAR(100),
numeroDocumento VARCHAR(15),
nombreAlumno VARCHAR(max),
actorGenero VARCHAR(2),
actorEdad int,
discapacidad VARCHAR(5),
nombre VARCHAR(50),
periodoReingreso VARCHAR(max),
cursoNombreOficial VARCHAR(max),
orden int,
matriculado VARCHAR(5),
pagante VARCHAR(5),
dia int,
mes int,
anioEdad int,
fechaNac VARCHAR(250),
numero int,
periodoCodigo VARCHAR(100),
periodoCodigoMinedu VARCHAR(100),
nombreSede VARCHAR(max),
nivelFormativo VARCHAR(250),
codigoModular VARCHAR(200),
turno VARCHAR(100),
nombreProducto VARCHAR(max),
seccion VARCHAR(250),
seccionMinedu VARCHAR(250),
planEstudio VARCHAR(250),
idDocumentoTipo int
---
,IdEmpresa int
,IdActor int
,IdCurricula int
,IdCurso int
,IdSede int
,IdMatricula int
,IdPeriodo int
,IdProducto int
,IdPromocionCurso int
,idUnidadNegocio int
,idUnidadAcademica int
--Inicio --@1
,nombres VARCHAR(150)
,apellido_paterno VARCHAR(150)
,apellido_materno VARCHAR(150)
,fecha_nacimiento DATETIME
,fecha_ingreso DATETIME
,SeccionNominaMinedu varchar(10)
--Fin --@1
)

insert into @tableSecciones
SELECT    distinct        
ACN.IdProducto,         
'Producto'= PRO.ProductoNombreCorto,          
1 EsNuevo,       
'Seccion' = ACN.SeccionNomina,
'SeccionMinedu' = CASE WHEN ISNULL(ENE.CodigoSedeOrigen,'') =''
					THEN ACN.SeccionNomina
					ELSE ACN.SeccionNomina + '-' + ENE.CodigoSedeOrigen
					END,
'IdSede'=ACN.idsede,  
'FechaInicio'=CONVERT(VARCHAR,PE.Inicio,103),  
--'TurnoNombre'=MTR.Nombre,
'TurnoNombre'=ACN.Turno,
'FechaFin'=CONVERT(VARCHAR,PE.Fin,103),
'periodoCodigo' = PE.Codigo,
'periodoCodigoMinedu' = PE.CodigoMinedu,--falta cambiar por el nuevo campo de mgarriazo
'nombreSede' = ISNULL(SE.SedeNombreMinedu,SE2.SedeNombreMinedu), --@1	
'nivelFormativo' = PUA.Valor4,
'codigoModular' = ISNULL(ENE.CodModularDestino,PUA.Valor10),
'planEstudio' = Cu.NombrePlanEstudio	--@2
FROM AlumnoCursoNomina ACN WITH (NOLOCK)
INNER JOIN Producto PRO WITH (NOLOCK) ON ACN.IdProducto=PRO.IdProducto  
INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON pro.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro  
INNER JOIN Periodo PE  WITH (NOLOCK) ON ACN.IdPeriodo=PE.IdPeriodo      
INNER JOIN PeriodoCabecera PEC WITH (NOLOCK) ON PE.IdPeriodoCabecera=PEC.IdPeriodoCabecera 
INNER JOIN Promocion PROM WITH (NOLOCK) ON PROM.idpromocion = ACN.idpromocion
INNER JOIN Curricula Cu  WITH (NOLOCK) on PROM.IdCurricula = Cu.IdCurricula
--INNER JOIN Matricula M WITH (NOLOCK) on M.IdMatricula = ACN.IdMatricula
--INNER JOIN PromocionGrupo PG WITH (NOLOCK) on PG.IdPromocion = M.IdPromocion and  PG.IdGrupo = M.IdGrupo
--INNER JOIN Turno T WITH (NOLOCK) ON PG.IdTurno = T.IdTurno    
--INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON T.IdTipoTurno = MTR.IdMaestroRegistro    
LEFT JOIN EquivalenciaNominasEnvioJSON ENE WITH (NOLOCK)ON ACN.IdSede = ENE.IdSedeOrigen AND ACN.IdProducto = ENE.IdProducto AND PEC.Codigo = ENE.Periodo--@4
LEFT JOIN Sede SE WITH (NOLOCK)ON ENE.IdSedeDestino = SE.IdSede
INNER JOIN Sede SE2 WITH (NOLOCK)ON ACN.IdSede = SE2.IdSede	--@4
INNER JOIN ParametroUnidadAcademica PUA WITH (NOLOCK) --@4
		ON  PUA.IdUnidadNegocio=PE.IdUnidadNegocio
		AND PUA.IdUnidadAcademica = PE.IdUnidadAcademica 
		AND PUA.IdSede=PE.IdSede
		AND PUA.IdProducto=PRO.IdProducto
		and PUA.Nombre = 'ParametroNomina1'
WHERE ACN.IdEmpresa=@idempresa 
AND (( MTR_PRO.Disponible1='C' AND  MTR_PRO.Disponible2='CAR' ) OR MTR_PRO.Disponible1='P' )
AND PE.IdUnidadNegocio =@idunidadnegocionomina 
AND PE.idunidadacademica =@idunidadacademicanomina
AND ACN.IdPeriodo = @idperiodo
AND ACN.IdSede = @idsedenomina
AND (ACN.IdProducto=@idproductonomina or @idproductonomina=0)

DECLARE @MIN INT 
, @MAX INT
, @idSede INT 
, @seccion VARCHAR(200)
, @turno VARCHAR(200)
, @codigoModular VARCHAR(100)
, @nivelFormativo VARCHAR(250)
, @nombreSede VARCHAR(250)
, @nombrePrograma VARCHAR(max)
, @periodoCodigo VARCHAR(100)
, @planEstudio VARCHAR(250)
, @seccionMinedu VARCHAR(250)
, @periodoCodigoMinedu VARCHAR(250)

SELECT @MIN = MIN(ID), @MAX  = MAX(ID) FROM @tableSecciones
--print @MAX
WHILE @MIN <= @MAX
BEGIN
	SET @idSede = NULL
	SET @seccion = NULL 

	SET @turno= NULL
	SET @codigoModular = NULL
	SET @nivelFormativo = NULL
	SET @nombreSede = NULL
	SET @nombrePrograma = NULL
	SET @periodoCodigo = null
	SET @planEstudio = null
	SET @seccionMinedu = null
	SET @periodoCodigoMinedu = null

	SELECT @idSede = idSede, 
		   @seccion = seccion,  
		   @turno= turnoNombre,
		   @codigoModular = codigoModular,
		   @nivelFormativo = nivelFormativo,
		   @nombreSede = nombreSede,
		   @nombrePrograma = nombreProducto,
		   @periodoCodigo = periodoCodigo,
		   @planEstudio = planEstudio,
		   @seccionMinedu = seccionMinedu,
		   @periodoCodigoMinedu = periodoCodigoMinedu
	FROM @tableSecciones WHERE ID = @MIN

	insert into @tableAlumnosSecciones
	SELECT  'usuarioMinedu'=@usuarioMinedu ,
			'claveMinedu'=@claveMinedu,
			'NumeroDocumento'=A.NumeroIdentidad,               
			'ActorNombreCompleto'=A.NombreCompleto,              
			'ActorGenero'= CASE A.Genero WHEN 0 THEN 'F' WHEN 1 THEN 'M' END,              
			'ActorEdad'=ISNULL( DATEDIFF(day,a.FechaNacimiento, GETDATE()) / 365,0),        
			'Discapacidad'='NO',                
			dbo.gEnteroARomano(ACN.idmodulo) Nombre,       
			'PeriodoReingreso'=  '',   
			cc.CursoNombreOficial,    
			'Orden'=ISNULL(cc.Orden,'')  
			,'Matriculado' = CASE WHEN ISNULL(ACN.IdMatricula,0) <> 0 THEN 'SI' ELSE 'NO' END  
			,'Pagante'='P'   
			,'Dia'=ISNULL(DAY(A.FechaNacimiento),'') 
			,'Mes'=ISNULL(MONTH(A.FechaNacimiento),'') 
			,'AnioEdad'=ISNULL(YEAR(A.FechaNacimiento),'')
			,'FechaNac'=ISNULL(CONVERT(VARCHAR,A.FechaNacimiento,112),'') 
			,'Numero'=ISNULL(Al.Numero,'') 
			,@periodoCodigo
			,@periodoCodigoMinedu
			,@nombreSede
			,@nivelFormativo
			,@codigoModular
			,@turno
			,@nombrePrograma
			,@seccion
			,@seccionMinedu
			,@planEstudio
			,A.IdDocumentoTipo
			---
			,ACN.IdEmpresa
			,ACN.IdActor
			,ACN.IdCurricula
			,ACN.IdCurso
			,ACN.IdSede
			,ACN.IdMatricula
			,ACN.IdPeriodo
			,ACN.IdProducto
			,ACN.IdPromocionCurso
			,@idunidadnegocionomina
			,@idunidadacademicanomina
			--Inicio --@1
			,A.Paterno
			,A.Nombres
			,A.Materno
			,A.FechaNacimiento
			, dbo.cFechaIngresoActorProducto(ACN.IdActor,ACN.IdProducto)
			,REVERSE(LEFT(REVERSE(ACN.SeccionNomina), CHARINDEX('-', REVERSE(ACN.SeccionNomina)) -1))
			--Fin --@1
	FROM CurriculaCurso CC WITH(NOLOCK)   
	INNER join AlumnoCursoNomina ACN WITH(NOLOCK) ON ACN.IdCurso = cc.IdCurso AND ACN.IdCurricula=cc.IdCurricula      
	INNER JOIN Actor A WITH(NOLOCK) ON ACN.IdActor=A.IdActor 
	INNER JOIN Alumno AL WITH(NOLOCK) ON A.IdActor=AL.IdAlumno 
	INNER JOIN Periodo PE  WITH (NOLOCK) ON ACN.IdPeriodo=PE.IdPeriodo      -- @1
	--INNER JOIN Matricula M WITH (NOLOCK) on M.IdMatricula = ACN.IdMatricula And ACN.IdActor = M.IdActor -- @1
	--INNER JOIN PromocionGrupo PG WITH (NOLOCK) on PG.IdPromocion = M.IdPromocion and  PG.IdGrupo = M.IdGrupo
	--INNER JOIN Turno T WITH (NOLOCK) ON PG.IdTurno = T.IdTurno    
	--INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON T.IdTipoTurno = MTR.IdMaestroRegistro    
	WHERE ACN.seccionNomina = @Seccion     
		  AND ACN.IdSede = @IdSede 
		  AND ACN.Turno = @turno
	SET @MIN = @MIN + 1  
END

--@4 INICIO
insert into AlumnoCursoNominaJson (
usuarioMinedu,
claveMinedu,
numeroDocumento,
nombreAlumno,
actorGenero,
actorEdad,
discapacIdad,
Modulo,
cursoNombreOficial,
matriculado,
periodoCodigo,
periodoCodigoMinedu,
nombreSede,
nivelFormativo,
codigoModular,
turno,
nombreProducto,
seccion,
seccionMinedu,
planEstudio,
tipo_documento,
IdEmpresa,
IdActor,
IdCurricula,
IdCurso,
IdSede,
IdMatricula,
IdPeriodo,
IdProducto,
IdPromocionCurso,
idUnidadNegocio,
idUnidadAcademica,
IdUsuario,
FechaCreacion,
Observaciones,
apellido_paterno,
apellido_materno,
nombres,
fecha_nacimiento,
fecha_ingreso,
SeccionNominaMinedu
)
--@4 FIN
select distinct -- @1
usuarioMinedu
,claveMinedu
,numeroDocumento 
,nombreAlumno 
,actorGenero=CASE actorGenero WHEN 'M' THEN 'MASCULINO' ELSE 'FEMENINO' END
,actorEdad
,Tiene_Discapacidad=CASE discapacidad WHEN 'NO' THEN 0 ELSE 1 END
,nombre 
,cursoNombreOficial
--,orden
,matriculado
,periodoCodigo
,periodoCodigoMinedu
,'nombreSede' = CASE @CompaniaSocio WHEN '00002500' THEN CASE IdSede WHEN 49 THEN 'VIRTUAL' 
														 ELSE nombreSede END
									ELSE nombreSede END
,nivelFormativo
,codigoModular
,turno= turno	--@2
--CASE turno  WHEN 'MADRUGADOR' THEN 'MA�ANA'   -- ACTUALIZAR AL TURNO QUE TIENE ACN
--				   WHEN 'DIURNO' THEN 'MA�ANA'
--				   WHEN 'DIURNA' THEN 'MA�ANA'
--				   WHEN 'NOCTURNO' THEN 'NOCHE'
--				   ELSE 'TARDE' END
,nombreProducto
,seccion
,seccionMinedu
,planEstudio
,tipo_documento =CASE --@6
									WHEN idDocumentoTipo = 25 THEN 'D.N.I.'
									WHEN idDocumentoTipo = 27 THEN 'CARNET DE EXTRANJER�A'
									WHEN idDocumentoTipo = 30765 AND @CompaniaSocio = '00002500' THEN 'PASAPORTE' -- Zegel
									WHEN idDocumentoTipo = 27670 AND @CompaniaSocio = '00002700' THEN 'PASAPORTE' -- Idat
									ELSE 'PTP' END --@6 --CASE idDocumentoTipo  WHEN 25 THEN 'D.N.I.'
--										WHEN 27 THEN 'CARNET DE EXTRANJER�A'
--										WHEN 30765 THEN 'PASAPORTE'
--										ELSE 'PTP' END
---
,IdEmpresa
,IdActor
,IdCurricula
,IdCurso
,IdSede
,IdMatricula
,IdPeriodo
,IdProducto
,IdPromocionCurso
,idUnidadNegocio
,idUnidadAcademica
--
,@IdUsuario
,GETDATE()
,dbo.cObtenerValidacionesMineduStr(actorEdad
									,CASE actorGenero WHEN 'M' THEN 'MASCULINO' ELSE 'FEMENINO' END
									,numeroDocumento
									--,CASE idDocumentoTipo  WHEN 25 THEN 'D.N.I.'
									--					   WHEN 27 THEN 'CARNET DE EXTRANJER�A'
									--					   WHEN 30765 THEN 'PASAPORTE'
									--					   ELSE 'PTP' END
									,CASE 
									WHEN idDocumentoTipo = 25 THEN 'D.N.I.'
									WHEN idDocumentoTipo = 27 THEN 'CARNET DE EXTRANJER�A'
									WHEN idDocumentoTipo = 30765 AND @CompaniaSocio = '00002500' THEN 'PASAPORTE' -- Zegel
									WHEN idDocumentoTipo = 27670 AND @CompaniaSocio = '00002700' THEN 'PASAPORTE' -- Idat
									ELSE 'PTP'
								END
									,CASE turno  WHEN 'MADRUGADOR' THEN 'MA�ANA'
												 WHEN 'DIURNO' THEN 'MA�ANA'
												 WHEN 'DIURNA' THEN 'MA�ANA'
												 WHEN 'NOCTURNO' THEN 'NOCHE'
												 ELSE 'TARDE' END
									,nivelFormativo
									,nombreSede
									,null
									,codigoModular
									,planEstudio
									--01 Inicio
									,periodoCodigoMinedu
									,nombres
									,apellido_materno
									,apellido_paterno
									,fecha_nacimiento
									,fecha_ingreso
									,SeccionNominaMinedu
									,seccionMinedu --@3
									--01 Fin
								)
--Inicio @1
,nombres
,apellido_materno
,apellido_paterno
,fecha_nacimiento
,fecha_ingreso
,SeccionNominaMinedu
--Fin @1
from @tableAlumnosSecciones
order by nombreAlumno 

SET NOCOUNT OFF
END
