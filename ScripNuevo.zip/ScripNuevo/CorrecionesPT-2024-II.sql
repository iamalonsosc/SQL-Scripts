SELECT AC.EsMatricula,CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE 
--AC.IdAlumno=1303015 
--AND AC.IdCurso=9934 
--AND AC.IdCursoOriginal=9934 
--AND AC.EsMatricula=1
 AC.IdMatricula=602797 
order by ac.idregistro,ac.IdAlumnoCurso desc


--TORRES YUPANQUI JEAN MARCO
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=602797 
AND IdCurso IN (9839)

--NU�EZ ARANIBAR SAYURI ELIZABETH
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=610402 
AND IdCurso IN (9925,9924)


--QUISPE OCHOA LUIGGIE ROYER
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=606811 
AND IdCurso IN (10120
,9876)


--RAM�REZ GONZALES SEBASTIAN ANDREW GABRIEL
UPDATE AlumnoCurso SET EsMatricula=1
WHERE IdAlumno=1440342
AND IdMatricula=610556 
AND IdCurso=9818
--FERNANDEZ PEREZ THALIA MILAGROS
UPDATE AlumnoCurso SET EsMatricula=1
WHERE IdAlumno=1286202
AND IdMatricula=607963 
AND IdCurso=9857
--TORRES ESCOBAR MELANY NICOL
UPDATE AlumnoCurso SET EsMatricula=1
WHERE IdAlumno=1408698
AND IdMatricula=598900 
AND IdCurso=9818
--LAZO FLORES JHONN OSWALDO
UPDATE AlumnoCurso SET EsMatricula=1
WHERE IdAlumno=1303015
AND IdMatricula=612182 
AND IdCurso=9930

--LEVANO CARLIN VANESSA ROSMERY
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=614763 
AND IdCurso=10411

--VIERA SANCHEZ PIERO ALDAIR
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=614728 
AND IdCurso=10411

--RAMOS EVARISTO ROSA ANGELICA
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=608354 
AND IdCurso IN (9801,9839)


--CHOCCA HUAMAN MIGUEL ANGEL
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=596151 
AND IdCurso=9801



--ANCAJIMA PALOMINO JHOSEP DAVID
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=608319 
AND IdCurso=9801


--ESTEBAN MARTINEZ ARIANA CASANDRA
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=608380 
AND IdCurso=9839


--CHUNGA VILCHEZ BRYAN
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=612312 
AND IdCurso IN (9857,9800)



--VILLENA GASPAR KEVIN
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=613831 
AND IdCurso IN (10575,10542,9795)

--BONZANO CASTILLO DAJHANA KIMBERLY
UPDATE AlumnoCurso SET EsMatricula=1
WHERE  IdMatricula=611300 
AND IdCurso IN (10575)