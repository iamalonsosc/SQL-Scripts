exec COp_ValidarCliente @pTipoConsulta=N'1',@pIdConsulta=N'72549833'
exec COp_ConsultarDeuda @pCodigoProducto=N'001',@pTipoConsulta=N'1',@pIdConsulta=N'76258264',@pCompaniaSocio=N'00002700'