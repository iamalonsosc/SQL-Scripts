-------------------------------------------------------------------------   
--Creado por : Ren�n Galvez(17/08/2012)      
--Modificado Por : Pedro Zapata(17/07/2015)      
--Funcionalidad: Permite Mostra data detallada de avance de Ventas      
--Utilizado por: coIntefaseDocumento.cVentasReporte_Xls_VEN00026         
-------------------------------------------------------------------------    
/*       
-------------------------------------------------------------------------      
      
Nro  FECHA USUARIO DESCRIPCION       
-----------------------------------------------------------------------------      
@1 01.02.2014 ilopez Proyecto SEE      
@2 26.09.2017 ilopez se muestran las matriculas anuladas       
@3 12.12.2017 ilopez Cambios para homogemizar la consulta base de los reportes de ventas       
@4 16.01.2018 krojasr Agrego estado de sede CAMPO : ''Seccion''=ISNULL(PG.GrupoCodigo,'''')       
@5 18.10.2018 rvera Ticket 1980      
@6 20.11.2018 hcachi se agrega la columna IdInteresado dentro de la tabla temporal #TemporalMatricula       
@7 27.11.2018 hcachi Se agrega las columnas MedioDifusion y TipoMedioDifusion y se las coloca al final de reporte       
@8 06.12.2018 rvera Se omite la vista CO_Precio       
@9 20.12.2018 rvera Reconocer reporte 25       
@10 10.01.2018 rvera Mejoras planillaComercial       
@11 11.01.2019 Eloy Alva (Sigcomt) Agregar parametro CompaniaSocio.       
@12 04.03.2019 hcachi Se agregan cambios (LEFT x INNER)       
@13 03.03.2019 RAYRA Se agrego el campo TipoAnulacion      
@14 03.03.2019 RAYRA Se cambia la descripci�n del campo Estado       
@15 08.05.2019 Jnavia Se cambia la validaci�n de duplicados       
@16 24.05.2019 Eloy Alva(Sigcomt) Busqueda de TipoCondicion por CompaniaSocio       
@17 24.05.2019 Eloy Alva(Sigcomt) Correccion de Error por COLLATE SQL_Latin1_General_CP1_CI_AS       
@18 31.05.2019 LeandroOrdo�ez(Sigcomt) Modificar el TipoCondici�n      
@19 20.06.2019 Hmora Se agrego el campo Precio de Lista      
@20 24.06.2019 Hmora Se implemento funcion de Precio de Lista      
@21 27.06.2019 Jleo Se actualiza tabla temporal global a tabla temporal para el listdo de precios en cuotas      
@22 28.06.2019 jmota se modifica precio de lista segun co_precio      
@23 24.10.2019 Jnavia Se agrega la vw_CO_Interfase_P09_Header para obtener el Tipo Cliente      
@24 20.04.2020 Gonzalo Sanchez Se agrega el campo telefonos      
@25 08.06.2020 Gonzalo Sanchez Se agrega el campo promocion      
@26 06.01.2021 JCure Se pusieron nolock      
@27 01.02.2021 rpineda Agregar Pre Automatica      
@28 08.02.2021 Hmora Se agrega IDAT con logica Zegel para el reporte de liquidacion    
@29 09.02.2021 JCure Se agrega condicion para que muestre 0 para las cuotas cobradas    
@30 2022.04.09 jmota se corrige error de descuento y se agrega ubigeo y direccion     
@31 2022.04.09 jmota se agrega campos solicitados por jrea    
@32 2022.03.30 aromerob se agrega columna EsReingreso usando la funci�n [dbo].[cAlumnoReingresante]    
@33 2022.10.18 jcure se agrega with (nolock)    
@34 25.10.2022 MBUENO Se agrega campos distrito, provincia y departamento    
@35 26.01.2023 jcure Se agrega campos entidad y convenio    
@36 26.01.2023 FETORRES Se agrego a columna SepararVacante  
@37 26.01.2023 MBUENO Se filtra duplicado direccion y agrega montocancelado
@38 02.02.2023 FETORRES Se agrega la columna para saber si se le envio correo al alumno  
@39 30.06.2023 ALSANCHEZ Se agrega columna DocumentoFacturacion
*/      
ALTER PROCEDURE [dbo].[cVentasReporte_Xls_VEN00032]      
--declare      
@IdEmpresa INT,      
@ParamSede VARCHAR(max),      
@ParamFact VARCHAR(max),      
@ParamUnidadA VARCHAR(max),      
@ParamUnidadN VARCHAR(max),      
@ParamPeriodo VARCHAR(max),      
@ParamProducto VARCHAR(max),       
@ParamModulo VARCHAR(max),--ACA SE CARGA LOS SEMESTRES      
@FechaInicio varchar(10),      
@FechaFin varchar(10),      
@Opcion int,      
@lSoloNuevos int      
AS      
BEGIN       
    
 SET DATEFORMAT DMY      
 SET NOCOUNT ON      
       
 DECLARE @CompaniaSocio CHAR(8)      
 SELECT @CompaniaSocio = CompaniaSocio FROM Empresa e WITH(NOLOCK) WHERE E.IdEmpresa=@IdEmpresa --@11      
      
 -- VARIABLES      
    BEGIN   
    
        DECLARE @columns VARCHAR(MAX),    
        @query VARCHAR(MAX),    
        @query1 VARCHAR(MAX),    
        @columasFijas VARCHAR(MAX),    
        @Max INT,    
        @Conta INT,    
        @Existe INT,    
        @CurIdEmpresa INT,    
        @CurIdFacultad INT,    
        @CurIdUnidadNegocio INT,    
        @CurIdPeriodo INT,    
        @CurIdAlumno INT,    
        @EstadoInicial VARCHAR(100),    
        @UltimaSede VARCHAR(50),    
        @UltimoPeriodo VARCHAR(50),    
        @Proceso VARCHAR(50),    
        @CurID INT,    
        @MaxID INT,    
        @IdActor INT,    
        @IdMatricula INT,    
        @GrupoDescuento VARCHAR(20),    
        @NombreDescuento VARCHAR(500),    
        --@30     
        @PorcentajeDescuento VARCHAR(20),    
        --@30     
        @IdPromocion INT,    
        @NumeroCuota VARCHAR(20),    
        @PrecioLista MONEY     
            
        DECLARE @Cuotas TABLE (    
            Id int identity(1, 1),    
            --@21      
            CuotaNumero VARCHAR(10)    
        )     
            
        DECLARE @TemporalInterface AS TABLE (    
            Id INT IDENTITY,    
            IdMatricula INT,    
            IdPromocion INT,    
            NumeroCuota VARCHAR(20),    
            GrupoDescuento VARCHAR(20)    
        )     
            
        DECLARE @ActorRepetido AS TABLE (Id INT IDENTITY, IdActor INT)    
            
        --Temporal Sede       
        DECLARE @TempSede TABLE (IdSede INT)     
        --Temporal Facultad       
        DECLARE @TempFacultad TABLE (IdFacultad INT)     
        --Temporal Unidad de Negocio      
        DECLARE @TempUnidadN TABLE (IdUnidadNegocio INT)     
        ----Temporal Unidad de Academica      
        DECLARE @TempUnidadA TABLE (IdUnidadAcademica INT)     
        --Temporal Periodo       
        DECLARE @TempPeriodo TABLE (IdPeriodo INT)     
        -- --Temporal Producto      
        DECLARE @TempProducto TABLE (IdProducto INT)     
        ---- --Temporal Modulo      
        DECLARE @TempModulo TABLE (IdModulo INT)     
            
        CREATE TABLE #TemporalInterface      
        (    
            IdMatricula int,    
            IdPromocion int,    
            NumeroCuota char(10),    
            MontoCuota decimal(12, 2),    
            Importe decimal(12, 2),    
            TipoCondicion char(2),    
            EstadoMatricula char(1),    
            EstadoInterface char(2),    
            TipoFacturacion char(3),    
            MontoPosibleFac decimal(12, 2),    
            GrupoDescuento varchar(20),    
            PorcentajeDescuento varchar(20),    
            --@30    
            NombreDescuento varchar(200)    
        )     
            
        CREATE TABLE #TemporalMatricula(      
        idEmpresa int,    
        idSede int,    
        idUnidadNegocio int,    
        idUnidadAcademica int,    
        idPeriodo int,    
        IdProducto int,    
        IdPromocion int,    
        idGrupo int,    
        idModulo int,    
        IdMatricula int,    
        InscritoFecha datetime,    
        MatriculaFecha datetime,    
        IdDescuento int,    
        TipoServicio char(2),    
        CondicionPago char(2),    
        idActor int,    
        EsMatricula bit,    
        TipoCondicion char(2),    
        EstadoMatricula char(1),    
        NumeroCursos int,    
        IdProcedencia int,    
        EstadoInicial varchar(50),    
        UltimaSede varchar(50),    
        UltimoPeriodo varchar(50),    
        Proceso varchar(50),    
        DiaClaseTexto varchar(100),    
        HoraInicio int,    
        HoraFin int,    
        PromocionNombre varchar(150),    
        TipoInscripcion CHAR(1),    
        FechaComision datetime,    
        InscritoIdUsuario int,    
        TipoAnulacion varchar(1000),    
        --@13      
        --@22      
        ItemCodigo varchar(100),    
        TipoCliente varchar(10),    
        CuotasCronograma INT,    
        Sucursal VARCHAR(10),    
        PrecioLista decimal(12, 2),    
        PrecioNOR decimal(12, 2),    
        PrecioMAT decimal(12, 2),    
        PrecioCON decimal(12, 2),    
        --@22      
        Telefono varchar(1000),    
        --@24      
        Promocion varchar (200), --@25      
        Disponible1 varchar(200), --@32    
        Disponible2 varchar(200), --@32    
  Entidad varchar(200),--@35    
  Convenio  varchar(200),--@35    
  IdPlanPago  int --@36  
        )    
    END    
    
    INSERT INTO @TempSede(IdSede)    
    SELECT distinct txt_value FROM dbo.uf_Parse(@ParamSede, ',')    
    
    INSERT INTO @TempFacultad(IdFacultad)     
    SELECT distinct txt_value FROM dbo.uf_Parse(@ParamFact, ',')    
    
    INSERT INTO @TempUnidadN(IdUnidadNegocio)    
    SELECT distinct txt_value FROM dbo.uf_Parse(@ParamUnidadN, ',')    
    
    INSERT INTO @TempUnidadA(IdUnidadAcademica)    
    SELECT distinct txt_value FROM dbo.uf_Parse(@ParamUnidadA, ',')    
    
    INSERT INTO @TempPeriodo(IdPeriodo)     
    SELECT distinct txt_value FROM dbo.uf_Parse(@ParamPeriodo, ',')    
    
    INSERT INTO @TempProducto(IdProducto)    
    SELECT distinct txt_value FROM dbo.uf_Parse(@ParamProducto, ',')    
    WHERE txt_value <> '-1'    
    
    INSERT INTO @TempModulo(IdModulo)    
    SELECT distinct txt_value FROM dbo.uf_Parse(@ParamModulo, ',')    
    WHERE txt_value <> '0'    
    
    set @Opcion = REPLACE(@Opcion, 25, 0) --@9      
    
    --@15       
    INSERT INTO #TemporalMatricula(idEmpresa,idSede,idUnidadNegocio,idUnidadAcademica,idPeriodo,IdProducto,      
        IdPromocion,idGrupo,idModulo,IdMatricula,InscritoFecha,MatriculaFecha,IdDescuento,TipoServicio,    
        CondicionPago,idActor,EsMatricula,TipoCondicion,EstadoMatricula,IdProcedencia,DiaClaseTexto,    
        HoraInicio,HoraFin,PromocionNombre,TipoInscripcion,    
        FechaComision,InscritoIdUsuario,TipoAnulacion,--@10--@13      
        ItemCodigo,TipoCliente,CuotasCronograma,Sucursal,PrecioNOR,PrecioMAT,PrecioCON,--@22      
        Telefono,--@24      
        Promocion, --@25      
        Disponible1, --@32    
        Disponible2, --@32    
  Convenio,--@35    
  Entidad,--@35   
  IdPlanPago --@36   
    )    
    SELECT    
        idEmpresa,idSede,idUnidadNegocio,idUnidadAcademica,idPeriodo,IdProducto,    
        IdPromocion,idGrupo,idModulo,IdMatricula,InscritoFecha,MatriculaFecha,IdDescuento,TipoServicio,CondicionPago,    
        idActor,EsMatricula,TipoCondicion,Estado,IdProcedencia,DiaClaseTexto,HoraInicio,HoraFin,PromocionNombre,TipoInscripcion,    
        FechaComision,InscritoIdUsuario,TipoAnulacion,    
        --@22      
        ItemCodigo,    
        TipoCliente,    
        CuotasCronograma,    
        Sucursal,    
        ISNULL(PrecioNOR, 0),    
        ISNULL(PrecioMAT, 0),    
        'PrecioCON' = CASE    
            WHEN ISNULL(CuotasCronograma, 0) = 0 THEN 0    
            ELSE (ISNULL(PrecioMAT, 0) + (ISNULL(PrecioNOR, 0) * CuotasCronograma))    
        END,    
        --@22      
        Telefono,--@24      
        Promocion, --@25    
        Disponible1, --@32    
        Disponible2, --@32    
  Convenio,--@35    
  Entidad,--@34   
  IdPlanPago --@36   
    FROM    
        (    
            SELECT    
                p.idEmpresa,p.idSede,p.idUnidadNegocio,p.idUnidadAcademica,p.idPeriodo,p.IdProducto,    
                p.IdPromocion,m.idGrupo,p.idModulo,M.IdMatricula,InscritoFecha,MatriculaFecha,m.IdDescuento,m.TipoServicio,M.CondicionPago,--@35    
                m.idActor,M.EsMatricula,TipoCondicion,m.Estado,IdProcedencia,pg.DiaClaseTexto,pg.HoraInicio,pg.HoraFin,ISNULL(CM.Nombre, P.PromocionNombre) AS PromocionNombre,m.TipoInscripcion,    
                m.FechaComision,m.InscritoIdUsuario,m.TipoAnulacion,--@10 --@13      
                'ItemCodigo' = p.ServicioCodigo,    
                'TipoCliente' = PNOR.TipoCliente,    
                'CuotasCronograma' = ( SELECT MAX(CP.CuotaNumero) FROM CronogramaPago CP WITH(NOLOCK) WHERE CP.IdPromocion = p.IdPromocion ),    
                'Sucursal' = SED.Sucursal,    
                'PrecioNOR' = PNOR.Monto,    
                'PrecioMAT' = PMAT.Monto,    
                ROW_NUMBER() over ( partition by M.IdActor, PR.IdPeriodo, PDT.idProducto order by M.IdMatricula desc) AS Ordenamiento,    
                'Telefono' = actf1.telefonos,--@24      
                'Promocion' = P.PromocionCodigo, --@25      
                MTR.Disponible1, --@32    
                MTR.Disponible2, --@32    
    Convenio=isnull(co.Nombre,''), --@35    
    Entidad=isnull(En.NombreComercial,''), --@35   
    IdPlanPago --@36   
            FROM    
                Matricula m WITH(NOLOCK) --@@@      
                INNER JOIN Sede SED WITH(NOLOCK) ON SED.IdSede = M.IdSede --@22 --@@@      
                INNER JOIN Promocion p WITH(NOLOCK) ON p.IdPromocion = m.IdPromocion    
                INNER JOIN Producto PO WITH (NOLOCK) ON P.IdProducto = PO.IdProducto    
                INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON PO.IdClasificacionProducto = MTR.IdMaestroRegistro    
                INNER JOIN @TempSede s ON s.IdSede = p.IdSede    
                INNER JOIN @TempPeriodo pr ON pr.IdPeriodo = p.IdPeriodo    
                INNER JOIN @TempFacultad f ON f.IdFacultad = p.IdFacultad    
                INNER JOIN @TempUnidadN un ON un.IdUnidadNegocio = p.IdUnidadNegocio    
                INNER JOIN @TempUnidadA ua ON ua.IdUnidadAcademica = p.IdUnidadAcademica    
                INNER JOIN @TempProducto PDt ON PDt.IdProducto = p.IdProducto    
                LEFT JOIN PromocionGrupo pg WITH(NOLOCK) ON m.IdPromocion = pg.IdPromocion    
                AND m.IdGrupo = pg.IdGrupo    
                LEFT JOIN CurriculaModulo CM WITH(NOLOCK) ON CM.IdCurricula = P.IdCurricula    
                AND CM.IdModulo = isnull(P.IdModulo, 1) --@22      
                LEFT JOIN vw_CO_Interfase_P09_Header IH WITH(NOLOCK) ON M.IdMatricula = IH.IdMatricula --@23      
                LEFT JOIN vw_CO_Precio PNOR WITH(NOLOCK) ON PNOR.ItemCodigo = p.ServicioCodigo    
                AND PNOR.UnidadNegocio = SED.Sucursal    
                AND PNOR.TipoCliente =  IH.TipoCliente--[dbo].[cCo_Precio_ObtenerTipoListaPrecio](m.IdMatricula , NULL , NULL , @CompaniaSocio)--@23      
                AND PNOR.TipoFacturacion = 'NOR'    
                LEFT JOIN vw_CO_Precio PMAT WITH(NOLOCK) ON PMAT.ItemCodigo = p.ServicioCodigo    
                AND PMAT.UnidadNegocio = SED.Sucursal    
                AND PMAT.TipoCliente = IH.TipoCliente--[dbo].[cCo_Precio_ObtenerTipoListaPrecio](m.IdMatricula , NULL , NULL , @CompaniaSocio)--@23      
                AND PMAT.TipoFacturacion = 'MAT' --@22      
                INNER JOIN (    
                    SELECT    
                        x.idactor,    
                        telefonos = STUFF(    
                            (    
                                SELECT N', ' + x1.descripcion    
                                FROM actortelefono x1 WITH(NOLOCK)    
                                WHERE x1.idactor = x.idactor FOR XML PATH(''),    
                                TYPE    
                            ).value(N'.[1]', N'nvarchar(max)'),    
                            1,2,N''    
                        )    
                    FROM actortelefono x WITH(NOLOCK)    
            GROUP BY x.idactor    
                ) actf1 ON actf1.IdActor = m.IdActor --@24      
    LEFT JOIN Convenio CO WITH(NOLOCK) ON M.IdConvenio=CO.IdConvenio --@35    
    LEFT JOIN Entidad EN WITH(NOLOCK) ON M.IdEntidad=EN.IdEntidad--@35    
            WHERE    
                (m.IdEmpresa = CONVERT(VARCHAR, @IdEmpresa))    
                AND M.EsMatricula = 1    
                AND (    
                    (( @CompaniaSocio = '00002500' OR @CompaniaSocio = '00002700') and M.TipoCondicion not in ('CC'))     
                    OR @CompaniaSocio = '00002600'    
                ) --@16  --@28    
                AND m.IdGrupo is not null    
                AND (( MTR.Disponible1 = 'C' AND MTR.Disponible2 = 'CAR') OR MTR.Disponible1 = 'P')    
                AND ( CONVERT(VARCHAR, @lSoloNuevos) = 0 Or m.IdPeriodo is NULL)    
                AND (    
                    ( MTR.Disponible1 = 'C' AND EXISTS ( SELECT 1 FROM @TempModulo md WHERE md.IdModulo = CM.IdTipoModulo) )    
                    OR MTR.Disponible1 = 'P'    
                )    
        ) M    
    WHERE    
        M.Ordenamiento = 1    
    
    
    UPDATE #TemporalMatricula       
    SET NumeroCursos =(    
            SELECT COUNT(1) FROM AlumnoCurso AC WITH(NOLOCK)    
            WHERE AC.IdMatricula = #TemporalMatricula.IdMatricula      
            AND AC.EsMatricula = 1 AND AC.TipoCondicion IN ('RE', 'CC')    
        ),    
        PrecioLista = CASE WHEN #TemporalMatricula.CondicionPago = 'Q' THEN PrecioNOR WHEN #TemporalMatricula.CondicionPago = 'C' THEN PrecioCON ELSE 0.00 END       
            
    
    INSERT INTO #TemporalInterface      
        (    
            IdMatricula,IdPromocion,NumeroCuota,MontoCuota,    
            TipoCondicion,EstadoMatricula,EstadoInterface,TipoFacturacion,    
            GrupoDescuento,PorcentajeDescuento,NombreDescuento    
        )    
    SELECT    
        DISTINCT     
        m.IdMatricula,m.IdPromocion,'C' + CONVERT(VARCHAR, CO.CuotaNumero),    
        sum(Monto),m.TipoCondicion,m.EstadoMatricula,co.Estado,    
        co.TipoFacturacion,'','',''    
    FROM    
        #TemporalMatricula m      
        LEFT JOIN dbo.vw_CO_Interfase_P09_Header co WITH(NOLOCK) ON co.IdMatricula = m.IdMatricula    
        LEFT JOIN dbo.vw_CO_Interfase_P09_Detalle de WITH(NOLOCK) ON de.NumeroInterno = co.NumeroInterno    
    WHERE    
        ( M.IdProcedencia = 0 or M.IdProcedencia is null )    
        AND co.CompaniaSocio = @CompaniaSocio --@11      
        AND de.CompaniaSocio = @CompaniaSocio --@11      
        AND CO.Estado not in ('AN')    
        AND CO.TipoDocumento not in('NC')    
        AND CO.TIPODOCUMENTO IN('BV', 'FC')    
        AND ( ( @Opcion = 1 AND CO.FechaVencimiento Between @FechaInicio AND @FechaFin) or @Opcion = 0 )    
        AND (( @ParamProducto <> '-1' AND m.IdProducto in( SELECT IdProducto FROM @TempProducto ) )    
            or @ParamProducto = '-1' )    
    GROUP BY    
        m.IdMatricula,m.IdPromocion,co.CuotaNumero,m.TipoCondicion,    
        m.EstadoMatricula,co.Estado,co.TipoFacturacion    
    UNION    
    SELECT    
        DISTINCT     
        m.IdMatricula,m.IdPromocion,'C0',    
        0,m.TipoCondicion,m.EstadoMatricula,'CO',    
        'CON','','',    
        '' --@30     
    FROM #TemporalMatricula m      
    WHERE    
        M.IdProcedencia = 1    
        AND M.EstadoMatricula != 'X' --@2      
    UNION--@2      
    SELECT    
        m.IdMatricula,m.IdPromocion,'C0',    
        0,m.TipoCondicion,m.EstadoMatricula,'CO',    
        'CON','','',    
        '' --@30       
    FROM #TemporalMatricula m      
    WHERE M.EstadoMatricula = 'X'    
    
    
    UPDATE #TemporalInterface       
    SET MontoPosibleFac = (    
                    SELECT SUM(MontoCuota) FROM #TemporalInterface i      
                    WHERE i.IdMatricula = #TemporalInterface.IdMatricula      
                    group by IdMatricula    
                ),    
        Importe =(    
                    SELECT SUM(MontoCuota)    
                    FROM #TemporalInterface ID WITH(NOLOCK)      
                    WHERE    
                        id.IdMatricula = #TemporalInterface.IdMatricula      
                        AND id.TipoFacturacion in('MAT', 'CON')    
                        AND id.EstadoInterface IN('CO')    
                )     
                    
    --SE ASIGNA EL GRUPO DE DESCUENTO DE LA CUTOA 1 A TODOS LAS CUOTAS       
    UPDATE m    
    SET m.GrupoDescuento = co.Grupodescuento    
    FROM #TemporalInterface m WITH(NOLOCK)      
    LEFT JOIN dbo.vw_CO_Interfase_P09_Header co WITH(NOLOCK) ON co.IdMatricula = m.IdMatricula    
    WHERE CO.CuotaNumero = 1    
    AND co.CompaniaSocio = @CompaniaSocio --@11      
    
    
    --SE CALCULA LA DESCRIPCION DEL GRUPO DE DESCUENTO      
    INSERT INTO @TemporalInterface    
    SELECT    
        IdMatricula,IdPromocion,NumeroCuota,TMP.GrupoDescuento    
    FROM #TemporalInterface TMP      
    WHERE ISNULL(TMP.NombreDescuento, '') = '' AND NumeroCuota = 'C1'    
    
    SELECT @CurID = 1, @MaxID = Max(Id)     
    FROM @TemporalInterface     
    
    WHILE @MaxID >= @CurID         
    BEGIN    
        SELECT    
            @IdMatricula = IdMatricula,    
            @IdPromocion = IdPromocion,    
            @NumeroCuota = NumeroCuota,    
            @GrupoDescuento = GrupoDescuento    
        FROM @TemporalInterface    
        WHERE Id = @CurID    
    
        SET @NombreDescuento = ''     
            
        --NUEVA TABLA DE TRABAJO DEL 2018-I HACIA ADELANTE       
        SELECT TOP 1 @NombreDescuento = DescuentoNombre, @PorcentajeDescuento = Porcentaje --@30      
        FROM DescuentoAlumnoResultado DA WITH(NOLOCK)    
        WHERE DA.IdMatricula = @IdMatricula    
        AND DA.Cuota = 1     
            
        --HISTORICO DE NOMBRE DE GRUPO DESCUENTO         
        IF ISNULL(@NombreDescuento, '') = ''     
        BEGIN    
            SELECT TOP 1 @NombreDescuento = Nombre, @PorcentajeDescuento = Porcentaje --@30      
    FROM DescuentoAcademico WITH(NOLOCK)    
            WHERE Codigo = @GrupoDescuento    
            ORDER BY Activo DESC    
        END    
    
        UPDATE #TemporalInterface      
        SET NombreDescuento = @NombreDescuento,    
            PorcentajeDescuento = @PorcentajeDescuento --@30     
        WHERE IdMatricula = @IdMatricula    
        AND IdPromocion = @IdPromocion     
        --AND NumeroCuota=@NumeroCuota      
        --AND GrupoDescuento=@GrupoDescuento      
    
        SET @CurID = @CurID + 1    
    
    END    
    
    
    INSERT INTO @Cuotas    
    SELECT distinct NumeroCuota    
    FROM #TemporalInterface WHERE NumeroCuota NOT IN ('C0','C1')      
    Order by NumeroCuota --@21      
    
    --@21      
    --@7       
    --@6  
  
 --@37  
 DECLARE @direcciones AS TABLE(  
  Id INT IDENTITY(1,1),  
  IdActor INT,  
  IdDireccion INT,  
  Cantidad INT,  
  IdUbigeoResidencia INT  
 )    
  
 --insertamos ultima direccion  
 INSERT INTO @direcciones(IdActor,IdDireccion,Cantidad)  
 SELECT AD.IdActor, MAX(AD.IdDireccion), COUNT(0) FROM #TemporalMatricula TM WITH(NOLOCK)  
 INNER JOIN ActorDireccion AD WITH(NOLOCK) ON TM.IdActor = AD.IdActor  
 WHERE AD.Principal = 1 AND AD.Activo = 1  
 GROUP BY AD.IdActor  
  
 --actualizamos el ubigeo  
 UPDATE DIR SET DIR.IdUbigeoResidencia = AD.IdUbigeoResidencia  
 FROM @direcciones DIR  
 INNER JOIN ActorDireccion AD WITH(NOLOCK) ON AD.IdActor = DIR.IdActor AND AD.IdDireccion = DIR.IdDireccion  
  
 --creamos temporal de las cuotas  
 DECLARE @vw_CO_Interfase_P09_Header TABLE (IdMatricula int , CuotaNumero INT , Monto MONEY, CompaniaSocio CHAR(8), Estado CHAR(2), MontoPagado MONEY)  --@4  
 
 --insertamos en la temporal  
 INSERT INTO @vw_CO_Interfase_P09_Header      
 SELECT C.IdMatricula , C.CuotaNumero , CD.Monto, C.CompaniaSocio, C.Estado, ISNULL(CO.MontoPagado,'0.00')   
 FROM CO_Interfase_P09_Header C  WITH(NOLOCK)    
 INNER JOIN #TemporalMatricula TM WITH(NOLOCK) ON C.IdMatricula = TM.IdMatricula AND C.CompaniaSocio = @CompaniaSocio  
 INNER JOIN CO_Interfase_P09_Detalle CD WITH(NOLOCK) ON C.TipoDocumento = CD.TipoDocumento AND C.NumeroInterno = CD.NumeroInterno   
   AND C.CompaniaSocio = CD.CompaniaSocio     
 LEFT JOIN Co_documento AS CO WITH(NOLOCK) ON CO.CompaniaSocio = @CompaniaSocio  
  AND C.IdMatricula=CO.Interfase_Matricula AND C.CuotaNumero = CO.Interfase_Cuota  
  AND CO.TipoDocumento IN ('BV','FC')   
  AND CO.estado = 'CO'  
 WHERE C.CompaniaSocio = @CompaniaSocio AND C.CuotaNumero IN (1,2)    
 UNION   
 SELECT C.IdMatricula , C.CuotaNumero , CD.Monto, C.CompaniaSocio, C.Estado, ISNULL(CO.MontoPagado,'0.00')   
 FROM CO_Interfase_P09_Header_ASOC C  WITH(NOLOCK)   
 INNER JOIN #TemporalMatricula TM WITH(NOLOCK) ON C.IdMatricula = TM.IdMatricula AND C.CompaniaSocio = @CompaniaSocio  
 INNER JOIN CO_Interfase_P09_Detalle_ASOC CD WITH(NOLOCK) ON C.TipoDocumento = CD.TipoDocumento AND C.NumeroInterno = CD.NumeroInterno   
   AND C.CompaniaSocio = CD.CompaniaSocio     
 LEFT JOIN Co_documento_ASOC AS CO WITH(NOLOCK) ON CO.CompaniaSocio = @CompaniaSocio  
  AND C.IdMatricula=CO.Interfase_Matricula AND C.CuotaNumero = CO.Interfase_Cuota  
  AND CO.TipoDocumento IN ('BV','FC')   
  AND CO.estado = 'CO'  
 WHERE C.CompaniaSocio = @CompaniaSocio AND C.CuotaNumero IN (1,2)  
 --@37  
  
    SELECT DISTINCT     
        P.IdEmpresa,    
        P.IdFacultad,    
        P.IdUnidadNegocio,    
        P.IdPeriodo,    
        'Sede' = ISNULL(S.Nombre, ''),    
        'FechaInscripcion' = isnull(convert(varchar, M.InscritoFecha, 120), ''),    
        'FechaPago' = ISNULL( rtrim(convert(varchar, M.MatriculaFecha, 120)),'' ),    
        'FechaMatricula' = ISNULL( rtrim(convert(varchar, M.MatriculaFecha, 120)), ''),    
        'FechaComision' = ISNULL( rtrim(convert(varchar, M.FechaComision, 120)), ISNULL( rtrim(convert(varchar, M.MatriculaFecha, 120)), '' )),    
        'CounterComision' = ISNULL(USUC.Login, ''),    
        'CodigoAlumno' = ISNULL(AL.CodigoAnterior, ''),    
        'NombreCompleto' = ISNULL(AC.NombreCompleto, ''),    
        'NumeroIdentidad' = ISNULL(AC.NumeroIdentidad, ''),    
        'FechaNacimiento' = ISNULL(convert(varchar, AC.FechaNacimiento, 103), '') --@31    
        ,'Sexo' = CASE WHEN AC.Genero = 1 THEN 'M' WHEN AC.Genero = 0 THEN 'F' ELSE ''END --@31    
        ,'Email' = dbo.cActorEmailStr(M.IDACTOR),    
  'ActorUbigeo' = ISNULL(UB.NombreUnido,''), --@37  
        'ActorDireccion' = ISNULL(dbo.cActorDireccionStr(M.idactor), ' '),    
        'TipoAlumno' = SPACE(50),    
        'UltimaSede' = SPACE(50),    
        'UltimoPeriodo' = SPACE(50),    
        'Proceso' = SPACE(100),    
        'IdMatricula' = M.IdMatricula,    
        'TipoMatricula' =case    
            when M.TipoCondicion = 'CC' THEN 'CURSO REPITENCIA' --@18      
            when M.TipoCondicion = 'RE' THEN 'PROMOVIDO'    
            when M.TipoCondicion = 'RP' THEN 'PROMOVIDO + CURSO' --@18      
            when M.TipoCondicion = 'RT' THEN 'REPITENCIA'    
            ELSE ''    
        END,    
        'EstadoMatricula' =CASE    
            WHEN M.EstadoMatricula = 'R' THEN 'Retiro Ciclo'    
            WHEN M.EstadoMatricula = 'N' THEN 'Normal'    
            WHEN M.EstadoMatricula = 'X' THEN 'Anulado'    
            ELSE ''    
        END,    
        'Producto' = ISNULL(pr.ProductoNombre, ''),    
        'Semestre' = ISNULL(M.PromocionNombre, ''),    
        'Seccion' = ISNULL(PG.GrupoCodigo, ''),    
        'Estado' = case    
            when PG.Estado = 'X' then 'Anulado'    
            when PG.Estado = 'A' then 'Activo'    
        end,    
        'Frecuencia' = m.DiaClaseTexto COLLATE SQL_Latin1_General_CP1_CI_AS + ' ' + dbo.gHhMmStr(m.HoraInicio) + ' - ' + dbo.gHhMmStr(m.HoraFin) --@17       
        + ISNULL(    
            CASE    
                RIGHT(m.DiaClaseTexto, 3)    
                WHEN 'Sab' THEN ' - ' + RIGHT(T.Nombre, 10)    
            END,    
            ''    
        ),    
        'Turno' = TT.Codigo,    
        'CounterPropietario' = dbo.cContacto_Sel_CounterPropietario(M.IDACTOR),    
        'ConseptoDcto' = ISNULL(DSTO.DescripcionLocal, ''),    
        'Porcentaje' =case when DSTO.Porcentaje > 0 then (DSTO.Porcentaje / 100) else 0 END,    
        'TipoServicio' =case    
            when m.TipoServicio = 'C' THEN 'Por curso'    
            when m.TipoServicio = 'M' THEN 'Por producto y curso'    
            when m.TipoServicio = 'P' THEN 'Por producto'    
        END,    
        'CantCursos' = isnull(m.NumeroCursos, 0),    
        'FormaPago' = Case    
            WHEN M.EstadoMatricula = 'X' THEN ''    
            WHEN M.CondicionPago = 'Q'    
            AND isnull(IM.Importe, 0) > 0 THEN 'CREDITO'    
   WHEN M.CondicionPago = 'C'    
            AND isnull(IM.Importe, 0) > 0 THEN 'CONTADO'    
            else 'BECA'    
     END,    
        'TipoInscripcion' = Case    
            WHEN M.TipoInscripcion = 'A' THEN 'APODERADO'    
            WHEN M.TipoInscripcion = 'E' THEN 'EMPRESA'    
            WHEN M.TipoInscripcion = 'I' THEN 'INDIVIDUAL'    
            WHEN M.TipoInscripcion = 'M' THEN 'MIXTO'    
            ELSE ''    
        END,    
        'GrupoDescuento' = ISNULL(IM.GrupoDescuento, ''),    
        'PorcentajeDescuento' = ISNULL(IM.PorcentajeDescuento, '') --@30    
        ,'NombreDescuento' = ISNULL(IM.NombreDescuento, ''),  
		'DocumentoFacturacion'=ISNULL(TD2.Nombre,''),--@39
        'EntEmpresa' = isnull(Act.NombreCompleto, ''),    
        'Pagante' = ISNULL(    
            DBO.cActorPaganteStr(m.IdMatricula, M.IdActor),    
            ''    
        ),    
        'PrecioLista' = 0,    
        'FactProyectada' = ISNULL(IM.MontoPosibleFac, 0),    
        'Importe' = isnull(im.Importe, 0),    
        'UnidadNegocio' = un.Nombre,    
        'UnidadAcademica' = ua.Nombre,    
        'Periodo' = pd.Codigo,    
        'PeriodoInicio' = CASE    
            WHEN UN.TipoServicio = 'P' THEN CONVERT(VARCHAR, P.FechaInicioPeriodo, 103)    
            ELSE CONVERT(VARCHAR, pd.Inicio, 103)    
        END --@31    
        ,'Actor' = AC.IdActor,    
        'MedioDifusion' = dbo.cMedioDifusion_Interesado(AC.IdActor),    
        'TipoMedioDifusion' = dbo.cTipoMedioDifusion_Interesado(AC.IdActor),    
        'TipoAnulacion' = ISNULL(MTR.Nombre, ''),    
        'Telefono' = actf1.telefonos --@24      
        ,'Promocion' = P.PromocionCodigo --@25      
        ,'PreAUTO' = case when (isnull(RPMA.IdMatricula, 0) = 0) then 'NO' else 'SI' end --@27      
        ,'EsReingreso' = CASE WHEN M.EstadoMatricula <> 'X' AND M.Disponible1 IS NOT NULL AND M.Disponible2 IS NOT NULL AND M.Disponible1 = 'C' AND M.Disponible2 = 'CAR' AND [dbo].[cAlumnoReingresante](AC.IdActor, P.IdPeriodo) <> 0 THEN 'SI'    
        ELSE 'NO' END --@32    
     ,'Distrito' = ISNULL(UDIS.Nombre,'') --@34    
     ,'Provincia' = ISNULL(UPRO.Nombre,'') --@34    
     ,'Departamento' = ISNULL(UDEP.Nombre,'') --@34   
     ,m.Convenio    
     ,m.Entidad   
     ,'SepararVacante'= CASE WHEN M.IdPlanPago IS NULL OR M.IdPlanPago =0  THEN 'NO' ELSE 'SI' END --@36  
  ,'MontoCanceladoMatricula' = ISNULL(MAT.MontoPagado, '0.00') --@37  
  ,'MontoCanceladoPrimeraCuota' = ISNULL(C1.MontoPagado, '0.00') --@37
  ,'CorreoBienvenida' = CASE  WHEN ISNULL(EC.IDMATRICULA,0) > 0 AND EC.CodigoRemitente='PROVEEDOR_ITB' AND EC.estado =1 AND EC.Disponible3='Bienvenida' AND EC.Disponible2 NOT LIKE '[a-zA-Z]%' THEN 'SI' ELSE 'NO' END   --@38  
    INTO #Temporal      
    FROM    
        #TemporalMatricula M      
        INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = M.IdSede    
        INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = M.IdPromocion    
        INNER JOIN UnidadNegocio un WITH(NOLOCK) ON un.IdUnidadNegocio = p.IdUnidadNegocio    
        INNER JOIN UnidadAcademica ua WITH(NOLOCK) ON ua.IdUnidadAcademica = p.IdUnidadAcademica    
        INNER JOIN Periodo pd WITH(NOLOCK) ON pd.IdPeriodo = p.IdPeriodo    
        INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON M.IdPromocion = PG.IdPromocion    
        AND M.IdGrupo = PG.IdGrupo    
        LEFT JOIN ambiente A WITH(NOLOCK) ON PG.idambiente = A.idambiente    
        INNER JOIN Actor AC WITH(NOLOCK) ON M.idActor = AC.IdActor    
        LEFT JOIN MaestroTablaRegistro TD WITH(NOLOCK) ON AC.IdDocumentoTipo = TD.IdMaestroRegistro    
        LEFT JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = M.IdActor    
        INNER JOIN PRODUCTO PR WITH(NOLOCK) ON PR.IdProducto = P.IdProducto    
        LEFT JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON M.TipoAnulacion = MTR.IdMaestroRegistro    
        LEFT JOIN Turno T WITH(NOLOCK) ON PG.IdTurno = T.IdTurno    
        INNER JOIN MaestroTablaRegistro TT WITH(NOLOCK) ON T.IdTipoTurno = TT.IdMaestroRegistro    
        INNER JOIN #TemporalInterface IM ON IM.IdMatricula=m.IdMatricula      
        LEFT JOIN Actor act WITH(NOLOCK) ON act.IdActor = M.idActor---@33    
        LEFT JOIN dbo.vw_CO_Descuentos DSTO WITH(NOLOCK) ON DSTO.DESCUENTO = M.IdDescuento---@33    
        INNER JOIN Usuario USUC WITH(NOLOCK) ON M.InscritoIdUsuario = USUC.IdUsuario    
        and USUC.IdTipoUsuario = 3    
        INNER JOIN (    
            SELECT x.idactor,    
                telefonos = STUFF(    
                    ( SELECT N', ' + x1.descripcion FROM actortelefono x1 WITH(NOLOCK) --@33    
                        WHERE x1.idactor = x.idactor FOR XML PATH(''), TYPE    
                    ).value(N'.[1]', N'nvarchar(max)'),    
                    1, 2, N''    
                )    
            FROM actortelefono x WITH(NOLOCK) GROUP BY x.idactor --@33    
        ) actf1 ON actf1.IdActor = m.idActor --@24       
        LEFT JOIN ResultadoPreMatriculaAutomatica RPMA WITH(NOLOCK) on m.IdMatricula = RPMA.IdMatricula --@27   --@33    
  LEFT JOIN @direcciones DIR ON DIR.IdActor = AC.IdActor  --@34 --@37  
  LEFT JOIN Ubigeo UB WITH(NOLOCK) ON DIR.IdUbigeoResidencia = UB.IdUbigeo --@34    
  LEFT JOIN Ubigeo UDIS WITH (NOLOCK) ON UDIS.Codigo = ISNULL(UB.Codigo,'000000') --@34    
  LEFT JOIN Ubigeo UPRO WITH (NOLOCK) ON UPRO.Codigo = ISNULL(UB.IdDepartamento,'00') + ISNULL(UB.IdProvincia,'00') + '00' --@34    
  LEFT JOIN Ubigeo UDEP WITH (NOLOCK) ON UDEP.Codigo = ISNULL(UB.IdDepartamento,'00') + '0000' --@34   
  LEFT JOIN @vw_CO_Interfase_P09_Header MAT ON MAT.IdMatricula = M.IdMatricula AND MAT.CuotaNumero = 1 --@37  
  LEFT JOIN @vw_CO_Interfase_P09_Header C1 ON C1.IdMatricula = M.IdMatricula AND C1.CuotaNumero = 2 --@37  
   LEFT JOIN BDSMTP.dbo.EnvioCorreo EC WITH (NOLOCK) ON EC.IDMATRICULA = M.IDMATRICULA 
   INNER JOIN ActorFacturacion MF WITH (NOLOCK) ON MF.IDMATRICULA = M.IDMATRICULA --@39
   LEFT JOIN TipoDocumento TD2 WITH (NOLOCK) ON MF.IdTipoDocumento=TD2.IdTipoDocumento  --@39
   
    DECLARE @min_c int, @max_c int, @CuotaNumero varchar(200)    
    
    SELECT @min_c = MIN(id), @max_c = MAX(id)    
    FROM @Cuotas     
    
    WHILE @min_c <= @max_c     
    BEGIN    
        SELECT @CuotaNumero = CuotaNumero    
        from @Cuotas    
        where Id = @min_c    
    
        SET @query = 'alter table #Temporal add ' + @CuotaNumero + ' money '     
        EXECUTE(@query) --@29    
    
        SET @query = 'update a set ' + @CuotaNumero + ' =  case b.EstadoInterface  when ''CO'' then 0 else isnull(b.MontoCuota,0) end    
            from #Temporal a       
            left join #TemporalInterface b on b.IdMatricula = a.IdMatricula and b.NumeroCuota = ''' + CAST(Ltrim(Rtrim(@CuotaNumero)) as varchar) + '''' EXECUTE(@query)    
            
        SET @min_c = @min_c + 1    
    END     
    --@6       
    --@7      
    --@8       
    --@10       
    --@12       
    --@13       
    --@14       
    --@21      
    IF NOT EXISTS ( SELECT 1 FROM #Temporal) --@21       
        BEGIN    
            SELECT * FROM #TemporalMatricula       
            WHERE IdMatricula = 0 RETURN    
        END    
    
    SELECT ROW_NUMBER() OVER( ORDER BY T.CodigoAlumno DESC) AS Nro, T.*     
    INTO #Temporal2      
    FROM #Temporal T--@21       
    
    SELECT @Max = COUNT(1) FROM #Temporal2      
    SELECT @Conta = 1     
    
    WHILE @Conta <= @Max     
    BEGIN     
        --SE CARGA EL CURSO ACTUAL DEL WHILE       
        SELECT    
            @CurIdEmpresa = IdEmpresa,    
            @CurIdFacultad = IdFacultad,    
            @CurIdUnidadNegocio = IdUnidadNegocio,    
            @CurIdPeriodo = IdPeriodo,    
            @CurIdAlumno = Actor,    
            @EstadoInicial = EstadoMatricula,    
            @IdMatricula = IdMatricula --@20      
        FROM #Temporal2      
        WHERE Nro = @Conta --SE INICIALIZAN LAS VARIABLES Y LAS TEMPORALES      
    
        SET @UltimaSede = ''    
        SET @UltimoPeriodo = ''    
        SET @Proceso = ''     
            
        IF @EstadoInicial != 'Anulado'     
        BEGIN --SE CARGA EL ESTADO INICIAL      
            SELECT @Existe = COUNT(1)    
            FROM Matricula M WITH(NOLOCK)    
            INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion    
            WHERE    
            P.IdEmpresa = @CurIdEmpresa    
            AND P.IdFacultad = @CurIdFacultad    
            AND P.IdUnidadNegocio = @CurIdUnidadNegocio    
            AND M.IdActor = @CurIdAlumno    
            AND M.EsMatricula = 1    
            AND M.Estado != 'X'    
            AND P.IdPeriodo != @CurIdPeriodo     
            IF @Existe = 0    
                SET @EstadoInicial = 'INGRESANTE'    
ELSE     
            BEGIN    
                SELECT @Existe = COUNT(1)    
                FROM Matricula M WITH(NOLOCK)    
                INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion    
                WHERE    
                P.IdEmpresa = @CurIdEmpresa    
                AND P.IdFacultad = @CurIdFacultad    
                AND P.IdUnidadNegocio = @CurIdUnidadNegocio    
                AND M.IdActor = @CurIdAlumno    
                AND M.EsMatricula = 1    
                AND M.Estado != 'X'    
                AND P.IdPeriodo =(    
                    SELECT ISNULL(PE.idPeriodoAnterior, 0)    
                    FROM Periodo PE WITH(NOLOCK)    
                    WHERE PE.IdPeriodo = @CurIdPeriodo    
                )     
                    
                IF @Existe > 0    
                    SET @EstadoInicial = 'PERMANENCIA'    
                ELSE    
                BEGIN    
                    SET @EstadoInicial = 'REINGRESANTE'    
                    SELECT TOP 1 @UltimaSede = S.Codigo,    
                    @UltimoPeriodo = PE.Codigo    
                    FROM Matricula M WITH(NOLOCK)    
                    INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion    
                    INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo    
                    INNER JOIN Sede S WITH(NOLOCK) ON P.IdSede = S.IdSede    
                    WHERE    
                    P.IdEmpresa = @CurIdEmpresa    
                    AND P.IdFacultad = @CurIdFacultad    
                    AND P.IdUnidadNegocio = @CurIdUnidadNegocio    
                    AND M.IdActor = @CurIdAlumno    
                    AND M.EsMatricula = 1    
                    AND M.Estado != 'X'    
                    AND PE.IdPeriodo NOT IN (    
                        SELECT ISNULL(PE.idPeriodoAnterior, 0)    
                        FROM Periodo PE WITH(NOLOCK)    
                        WHERE PE.IdPeriodo = @CurIdPeriodo    
         UNION SELECT @CurIdPeriodo    
                    )    
                    ORDER BY    
                    PE.IdPeriodoAnual DESC,    
                    PE.IdPeriodo DESC    
                END     
                    
                --VERIFICAR EL TIPO DE PROCESO: REINGRESO, CAMBIO DE CARRERA, TRASLADO SEDE      
                IF EXISTS (    
                    SELECT 1 FROM Reingresos WITH(NOLOCK)    
                    WHERE    
                    IdAlumno = @CurIdAlumno    
                    AND IdPeriodoReingreso = @CurIdPeriodo    
                    AND Estado = 1    
                )    
                SET @Proceso = 'REINGRESO'    
                ELSE IF EXISTS (    
                    SELECT 1    
                    FROM CambioProductoCurricula WITH(NOLOCK)    
                    WHERE    
                    IdAlumno = @CurIdAlumno    
                    AND IdPeriodo = @CurIdPeriodo    
                    AND EsCambioCarrera = 1    
                    AND Estado = 1    
                )    
                SET @Proceso = 'CAMBIO DE CARRERA'    
                ELSE IF EXISTS (    
                    SELECT 1    
                    FROM CambioProductoCurricula WITH(NOLOCK)    
                    WHERE    
                    IdAlumno = @CurIdAlumno    
                    AND IdPeriodo = @CurIdPeriodo    
                    AND EsCambioCarrera = 0    
                    AND Estado = 1    
                )    
                SET @Proceso = 'CAMBIO DE CURRICULA'    
                ELSE IF EXISTS (    
                    SELECT 1    
                    FROM TrasladoSede WITH(NOLOCK)    
                    WHERE     
                    IdAlumno = @CurIdAlumno    
                    AND IdPeriodoTraslado = @CurIdPeriodo    
                    AND Estado = 1    
                )    
                SET @Proceso = 'TRASLADO SEDE'    
            END    
        END    
    
        UPDATE #Temporal2      
        SET    
            TipoAlumno = @EstadoInicial,    
       UltimaSede = @UltimaSede,    
            UltimoPeriodo = @UltimoPeriodo,    
            Proceso = @Proceso    
        WHERE Nro = @Conta    
        SET @Conta = @Conta + 1    
    END    
    
    
 ALTER TABLE #Temporal2 DROP COLUMN Nro      
 ALTER TABLE #Temporal2 DROP COLUMN IdEmpresa      
 ALTER TABLE #Temporal2 DROP COLUMN IdFacultad      
 ALTER TABLE #Temporal2 DROP COLUMN IdUnidadNegocio      
 ALTER TABLE #Temporal2 DROP COLUMN IdPeriodo      
    
    
 SELECT T.*    
 FROM #Temporal2 T      
      
 DROP TABLE #TemporalMatricula      
 DROP TABLE #TemporalInterface      
 DROP TABLE #Temporal --@21      
 DROP TABLE #Temporal2      
      
END 