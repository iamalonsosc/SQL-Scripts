--����������������������������������������������������������������������������                                                                            
--Creado por      :                
--Funcionalidad   : Reporte Ventas-Comercial    
--Utilizado por   : MatriculaConsulta.RptComercialConsulta        
--����������������������������������������������������������������������������            
/*              
-----------------------------------------------------------------------------              
Nro	FECHA		USUARIO		DESCRIPCION              
-----------------------------------------------------------------------------     
@1  04.02.2021  PUchuya		Se agrega campos colegio, tipo y annoegreso    
@2	25.10.2022	MBUENO		Se agrega campos distrito, provincia y departamento  
@3  26.01.2023	FETORRES	Se agrego a columna SepararVacante   
@4	26.01.2023	MBUENO		Se filtra duplicado direccion y agrega montocancelado  
@5	30.01.2023	MBUENO		Se agrega parametro EsMatricula y campo UsuarioInscritoLogin  
@6	01.02.2023	MBUENO		Se iguala a nulls variables y agreaga IdMatricula y IdActor  
@7	28.03.2023	MBUENO		Se agrego a columnas Convenio y Entidad   
@8	28.03.2023	FETORRES	Se agrego a columnas TipoMedioDifusion, MedioDifusion, SedeCounter, CorreoInstitucional.
@9	10.04.2023	MBUENO		Se quitan duplicados producidos por el inner join usuario
@10	13.04.2023	MBUENO		Se agregan campo TipoSeccion y Suma cuotas por separacion de vacante
@11	21.04.2023	MBUENO		Se agregan campo Colegio, UbigeoColegio y quita SedeCounter
@12	15.05.2023	ILLOSAD		Se agregan validacion para no listar NOTAS DE CREDITO de CO_Interfase_P09_Header
@13	16.05.2023	ILLOSAD		Se agregan DISTINCT en la consulta final que retorna la informacion para el reporte
@14	17.05.2023	ILLOSAD		Se agregan columna fecha de comision
@15	18.05.2023	ILLOSAD		Se agrega fecha de matricula en caso de que fecha de comision sea NULL
@16	26.05.2023	MBUENO		Se agregan columnas retiro de asignatura y ciclo
@17	12.06.2023	ILLOSAD		Se agrega Interesado para sacar idcolegio en caso sea nulo el idcolegio de ActorAcademica
@18	22.06.2023	ILLOSAD		Se agrega columna Virtualidad
@19	30.06.2023	ALSANCHEZ	Se agrega columna DocumentoFacturacion
*/            
ALTER PROCEDURE [dbo].[cReporteComercialConsulta]  
--DECLARE         
@IdEmpresa INT,          
@ParamSede VARCHAR(MAX),          
@ParamFact VARCHAR(MAX),                
@ParamUnidadN VARCHAR(MAX),       
@ParamUnidadA VARCHAR(MAX),       
@ParamPeriodo VARCHAR(MAX),          
@ParamProducto VARCHAR(MAX),           
@ParamModulo VARCHAR(MAX),                                                                                                                       
@FechaInicio VARCHAR(10),          
@FechaFin VARCHAR(10),              
@IdUsuario INT,  
@EsMatricula BIT = NULL --@5  
AS    
SET DATEFORMAT DMY       
--SELECT @IdEmpresa=1,@ParamSede=N'36',@ParamFact=N'1',@ParamUnidadN=N'1',@ParamUnidadA=N'60',@ParamPeriodo=N'3618',@ParamProducto=N'11351',@ParamModulo=N'645,646,647,648,649,650,651,652',@FechaInicio=N'',@FechaFin=N'',@IdUsuario=386848

BEGIN        
         
 SET NOCOUNT ON;    
    
 DECLARE  @TempFacultad TABLE            
 (IdFacultad INT)            
 DECLARE @TempSede TABLE            
 (IdSede INT)            
 DECLARE @TempUnidadNegocio TABLE            
 (IdUnidadNegocio INT)            
 DECLARE @TempUnidadAcademica TABLE            
 (IdUnidadAcademica INT)            
 DECLARE @TempPeriodo TABLE            
 (IdPeriodo INT)            
 DECLARE @TempProducto TABLE            
 (IdProducto INT)            
 DECLARE @TempDisponibles TABLE            
 (Disponible1 VARCHAR(10), Disponible2 VARCHAR(10))            
            
 INSERT INTO @TempFacultad(IdFacultad)            
 SELECT distinct data FROM dbo.Split(@ParamFact,',')            
          
 INSERT INTO @TempSede(IdSede)            
 SELECT distinct data FROM dbo.Split(@ParamSede,',')            
            
 INSERT INTO @TempUnidadNegocio(IdUnidadNegocio)   
 SELECT distinct data FROM dbo.Split(@ParamUnidadN,',')            
            
 INSERT INTO @TempUnidadAcademica(IdUnidadAcademica)            
 SELECT distinct data FROM dbo.Split(@ParamUnidadA,',')            
            
 INSERT INTO @TempPeriodo(IdPeriodo)            
 SELECT distinct data FROM dbo.Split(@ParamPeriodo,',')            
            
 INSERT INTO @TempProducto(IdProducto)            
 SELECT distinct data FROM dbo.Split(@ParamProducto,',') WHERE data <> '-1'    
    
 DECLARE @CurID INT,          
   @MaxID INT,    
   @CompaniaSocio CHAR(8),     
   @CodigoPeriodo varchar(10),     
   @IdMatricula INT,    
   @IdPromocion INT,    
   @IdGrupo INT,          
   @IdActor INT,            
   @CantCursosSemestre INT,        
   @CantCursosMatriculados INT,    
   @PagoMatricula VARCHAR(200),     
   @MontoMatricula VARCHAR(200),    
   @PagoPrimeraCuota VARCHAR(200),    
   @MontoPrimeraCuota VARCHAR(200)    
     
 DECLARE @Descuento TABLE (IdMatricula INT , PorcentajeMatricula VARCHAR(20) , NombreMatricula VARCHAR(800), PorcentajeCuotaUno VARCHAR(20) , NombreCuotaUno VARCHAR(800) )    
    
 SELECT @CompaniaSocio = CompaniaSocio  FROM Empresa  WITH(NOLOCK) WHERE IdEmpresa=@IdEmpresa    
            
 TRUNCATE TABLE MatriculaConsulta      
      
 INSERT INTO MatriculaConsulta    
 SELECT  'IdMatricula' = M.IdMatricula,    
   'IdActor' = ISNULL(A.IdActor,-1),    
   'CodigoAlumno' = ISNULL(AL.CodigoAnterior,' '),    
   'Apellidos'= ISNULL(A.Paterno,' ') + ' ' + ISNULL(A.Materno,' '),    
   'Nombres'= ISNULL(A.Nombres,' '),    
   'NombreCompleto'= ISNULL(A.NombreCompleto,' '),     
   'NumeroDocumento'= ISNULL(A.NumeroIdentidad,' '),    
   'ActorGenero'= CASE WHEN A.Genero = 0 THEN 'FEMENINO' ELSE 'MASCULINO' END,    
   'SedeNombre'= S.Nombre,    
   'UnidadNegocioNombre' = ISNULL(UN.Nombre,' '),    
   'UnidadAcademicaNombre' = ISNULL(UA.Nombre,' '),    
   'IdPeriodoAnual'= PE.IdPeriodoAnual,    
   'PeriodoCodigo'= ISNULL(PE.Codigo,' '),    
   'ProductoCodigo' = ISNULL(PR.ProductoCodigo,' '),    
   'ProductoNombre' = ISNULL(PR.ProductoNombre,' '),    
   'IdPromocion'= ISNULL(P.IdPromocion,-1),    
   'PromocionCodigo' = ISNULL(P.PromocionCodigo,' '),    
   'PromocionNombre' = ISNULL(P.PromocionNombre,' '),    
   'SemestreNombre'= ISNULL(CM.Nombre,'MODULO UNICO'),    
   'IdGrupo'= ISNULL(PG.IdGrupo,-1),    
   'Seccion'= ISNULL(PG.GrupoCodigo,' '),    
   'TurnoCodigo'= ISNULL(T.Codigo,' '),    
   'TurnoNombre'= ISNULL(T.Nombre,' '),    
   'UsuarioRegistro'= ISNULL(U2.Login,' '),    
   'FechaInscripcion'= dbo.gFechaStr(M.InscritoFecha),     
   'MatriculaFecha' = ISNULL(rtrim(CONVERT(VARCHAR,M.MatriculaFecha,103)),' '),    
   'FechaNacimiento'= ISNULL(dbo.gFechaStr(A.FechaNacimiento),' '),    
   'ActorUbigeo'= '',--ISNULL(dbo.cActorDireccionUbigeo(A.IdActor),' '),    
   'ActorDireccion'= ISNULL(dbo.cActorDireccionStr(A.idactor),' '),    
   'ActorEmail' = ISNULL(dbo.cActorEmailStr(A.idactor),' '),    
   'Celular'= ISNULL(REPLACE(REPLACE(dbo.cActorTelefono_UltimoDilo(A.IdActor), '*', ''), '#', ''),''),    
   'ActorTelefono'= dbo.cActorTelefonoStr(A.IdActor),    
   'EstadoMatricula'=  CASE  M.Estado WHEN 'N' THEN 'NORMAL' WHEN 'R' THEN 'RETIRADO' WHEN 'X' THEN 'ANULADO' END,    
   'Estado' = CASE WHEN M.EsMatricula  = 1 then 'MATRICULADO' ELSE 'PRE-MATRICULADO' END ,    
   'CondicionPago' = case  when M.Condicionpago = 'C' then 'CONTADO' ELSE 'CUOTAS' END ,     
   'TipoAlumno'= CASE WHEN isnull(M.IdPeriodo, -1) = -1 THEN 'CAPTACI�N' ELSE  '' END,    
   'FechaInicioPeriodo'=dbo.fecha(case P.TipoServicio when 'C' then PE.Inicio else P.FechaInicioPeriodo end),    
   'FechaFinPeriodo'=dbo.fecha(case P.TipoServicio when 'C' then PE.Fin else P.FechaFinPeriodo end),       
   'ObservacionRetiro'= '', --ISNULL(MR.Observacion,' '),    
   'NombreRetiro' = '', --ISNULL(MTR.Nombre,' '),    
   'FechaRetiro'= '', --ISNULL(dbo.gFechaStr(MR.DocumentoFecha),' '),    
   'CantCursosSemestre'= '',    
   'CantCursosMatriculados'= '',    
   'PagoMatricula'= '',         
   'MontoMatricula' = '',    
   'PagoPrimeraCuota' = '',    
   'MontoPrimeraCuota' = '',    
   'UsuarioModificacion'= ISNULL(U3.Login, ' '),    
   'FechaModificacion'= ISNULL(dbo.gFechaStr(M.FechaModificacion),' ')  
 FROM Matricula M WITH(nolock)      
 INNER JOIN Promocion P WITH(nolock) ON M.IdPromocion=P.IdPromocion     
 INNER JOIN Periodo PE  WITH(nolock) ON P.IdPeriodo=PE.IdPeriodo    
 --LEFT JOIN MatriculaRetiro MR WITH(NOLOCK) ON MR.IdMatricula = M.IdMatricula AND MR.IdActor = M.IdActor AND MR.Estado = 'R'  --@16   
 --LEFT JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroRegistro = MR.IdMotivo --@16                                   
 INNER JOIN Actor A WITH(nolock) ON M.IdActor = A.IdActor     
 LEFT JOIN Alumno AL WITH(nolock) ON A.IdActor = AL.IdAlumno    
 LEFT JOIN Usuario U1 WITH(nolock) ON AL.IdAlumno = U1.IdActor AND U1.IdTipoUsuario = 1    
 INNER JOIN MaestroTablaRegistro TD WITH(nolock) ON A.IdDocumentoTipo=TD.IdMaestroRegistro    
 INNER JOIN Empresa E WITH(NOLOCK) ON M.IdEmpresa = E.IdEmpresa      
 INNER JOIN Sede S WITH(NOLOCK) ON M.IdSede = S.IdSede    
 INNER JOIN UnidadNegocio UN WITH(nolock) ON P.IdUnidadNegocio = UN.IdUnidadNegocio    
 INNER JOIN UnidadAcademica UA WITH(nolock) ON P.IdUnidadAcademica = UA.IdUnidadAcademica    
 INNER JOIN Producto PR WITH(nolock)ON P.IdProducto=PR.IdProducto      
 INNER JOIN PromocionGrupo PG WITH(nolock) ON PG.IdPromocion=M.IdPromocion AND PG.IdGrupo = M.IdGrupo
 LEFT JOIN Ambiente AM WITH(nolock) ON PG.idambiente=AM.IdAmbiente
 LEFT JOIN Curricula C WITH (NOLOCK) ON P.IdCurricula=C.IdCurricula
 LEFT JOIN CurriculaModulo CM  WITH(nolock) ON C.IdCurricula =CM.IdCurricula AND CM.IdModulo= ISNULL(P.IdModulo,1)                                                                               
 LEFT JOIN Turno T  WITH(nolock) ON PG.IdTurno=T.IdTurno
 --INNER JOIN MaestroTablaRegistro TT  WITH(nolock) ON T.IdTipoTurno=TT.IdMaestroRegistro --@16 
 LEFT JOIN Usuario U2 WITH(nolock) ON  M.UsuarioCreacion = U2.IdUsuario
 LEFT JOIN Usuario U3 WITH (NOLOCK) ON M.UsuarioModificacion=U3.IdUsuario                                              
 WHERE P.IdEmpresa=@IdEmpresa     
 AND ( M.EsMatricula = @EsMatricula OR @EsMatricula IS NULL)--@  
 AND P.IdSede in (select IdSede from @TempSede)        
 AND P.IdFacultad in (select IdFacultad from @TempFacultad)    
 AND P.IdUnidadNegocio in (select IdUnidadNegocio from @TempUnidadNegocio)               
 AND P.IdUnidadAcademica in (select IdUnidadAcademica from @TempUnidadAcademica)                        
 AND P.IdPeriodo in (select IdPeriodo from @TempPeriodo)                 
 AND P.IdProducto in (select IdProducto from @TempProducto)                                                                       
 --AND M.EsMatricula=1    
 --AND M.IdPeriodo IS NULL --@1    
 AND ISNULL(P.IdModulo,1)= 1       
 AND M.Estado <> 'X'     
 --AND CONVERT(VARCHAR(8),M.MatriculaFecha,112) between @FechaInicio AND @FechaFin       
 --AND M.IdActor = 1626622 --@16      
 ORDER BY  NombreCompleto
    
 DECLARE @vw_CO_Interfase_P09_Header TABLE (IdMatricula int , CuotaNumero INT , Monto MONEY, CompaniaSocio CHAR(8), Estado CHAR(2), MontoPagado MONEY)  --@4  
   
 --@4  
 INSERT INTO @vw_CO_Interfase_P09_Header      
 SELECT C.IdMatricula , C.CuotaNumero , SUM(CD.Monto), C.CompaniaSocio, C.Estado, SUM(ISNULL(CO.MontoPagado,'0.00')) --@10
 FROM CO_Interfase_P09_Header C  WITH(NOLOCK)    
 INNER JOIN MatriculaConsulta MC WITH(NOLOCK) ON C.IdMatricula = MC.IdMatricula AND C.CompaniaSocio = @CompaniaSocio   
 INNER JOIN CO_Interfase_P09_Detalle CD WITH(NOLOCK) ON C.TipoDocumento = CD.TipoDocumento AND C.NumeroInterno = CD.NumeroInterno   
	AND C.CompaniaSocio = CD.CompaniaSocio     
 LEFT JOIN Co_documento AS CO WITH(NOLOCK) ON CO.CompaniaSocio = @CompaniaSocio  
	AND C.IdMatricula=CO.Interfase_Matricula AND C.CuotaNumero = CO.Interfase_Cuota  
	AND CO.TipoDocumento IN ('BV','FC')   
	AND CO.estado = 'CO'  
 WHERE C.CompaniaSocio = @CompaniaSocio AND C.CuotaNumero IN (1,2) AND C.Estado <>'NC'  ---@12
 GROUP BY C.IdMatricula , C.CuotaNumero, C.CompaniaSocio, C.Estado --@10
 UNION   
 SELECT C.IdMatricula , C.CuotaNumero , SUM(CD.Monto), C.CompaniaSocio, C.Estado, SUM(ISNULL(CO.MontoPagado,'0.00')) --@10  
 FROM CO_Interfase_P09_Header_ASOC C  WITH(NOLOCK)   
 INNER JOIN MatriculaConsulta MC WITH(NOLOCK) ON C.IdMatricula = MC.IdMatricula AND C.CompaniaSocio = @CompaniaSocio  
 INNER JOIN CO_Interfase_P09_Detalle_ASOC CD WITH(NOLOCK) ON C.TipoDocumento = CD.TipoDocumento AND C.NumeroInterno = CD.NumeroInterno   
	AND C.CompaniaSocio = CD.CompaniaSocio     
 LEFT JOIN Co_documento_ASOC AS CO WITH(NOLOCK) ON CO.CompaniaSocio = @CompaniaSocio  
	AND C.IdMatricula=CO.Interfase_Matricula AND C.CuotaNumero = CO.Interfase_Cuota  
	AND CO.TipoDocumento IN ('BV','FC')   
	AND CO.estado = 'CO'  
 WHERE C.CompaniaSocio = @CompaniaSocio AND C.CuotaNumero IN (1,2) AND C.Estado <>'NC'  ---@12
 GROUP BY C.IdMatricula , C.CuotaNumero, C.CompaniaSocio, C.Estado --@10
 --@4  
       
 SELECT @CurID = 1, @MaxID = Max(Id) FROM MatriculaConsulta WITH(NOLOCK)    
   
 DECLARE @PorcentajeMatricula VARCHAR(20) , @NombreMatricula VARCHAR(800), @PorcentajeCuotaUno VARCHAR(20) , @NombreCuotaUno VARCHAR(800) --@6  
        
 WHILE @MaxID >= @CurID          
 BEGIN      
  --@6  
  SET @IdMatricula = NULL  
  SET @PorcentajeMatricula = NULL  
  SET @NombreMatricula = NULL  
  SET @PorcentajeCuotaUno = NULL   
  SET @NombreCuotaUno = NULL  
  SET @IdPromocion = NULL  
  SET @IdGrupo = NULL  
  SET @IdActor = NULL  
  --@6  
  
  SELECT @IdActor = IdActor,     
  @IdMatricula = IdMatricula ,            
  @IdPromocion = IdPromocion,      
  @IdGrupo = IdGrupo     
  FROM MatriculaConsulta          
  WHERE Id = @CurID          
                    
  SET @CantCursosSemestre = 0    
  SET @CantCursosMatriculados = 0    
  SET @PagoMatricula = ''    
  SET @PagoPrimeraCuota = ''    
  SET @MontoPrimeraCuota = '0.00'    
  SET @MontoMatricula = '0.00'    
      
  SET @CantCursosSemestre = (SELECT COUNT(distinct IdCurso) from Seccion WITH(nolock) where IdPromocion = @IdPromocion AND Idgrupo = @IdGrupo)    
     
  SET @CantCursosMatriculados = (SELECT COUNT(distinct IdCurso) from AlumnoCurso WITH(nolock) where IdMatricula=@IdMatricula AND IdSeccion is not null)     
    
  SET @PagoMatricula = CASE WHEN (SELECT Count(1) FROM @vw_CO_Interfase_P09_Header V    
   WHERE V.IdMatricula = @IdMatricula And V.Estado='CO' And V.CuotaNumero = 1) = 1     
   THEN 'PAGO' ELSE 'DEBE' END    
    
  SET @MontoMatricula = (SELECT  ISNULL(SUM(V.Monto),'0.00') FROM @vw_CO_Interfase_P09_Header V           
   WHERE V.IdMatricula = @IdMatricula AND V.CuotaNumero = 1)    
    
  SET @PagoPrimeraCuota = CASE WHEN (SELECT Count(1) FROM @vw_CO_Interfase_P09_Header V    
   WHERE V.IdMatricula = @IdMatricula And V.Estado='CO' And V.CuotaNumero = 2) = 1    
   THEN 'PAGO' ELSE 'DEBE' END    
    
  SET @MontoPrimeraCuota = (SELECT ISNULL(SUM(V.Monto),'0.00') FROM @vw_CO_Interfase_P09_Header V           
   WHERE V.IdMatricula = @IdMatricula AND V.CuotaNumero = 2)          
       
       
    
  SELECT @PorcentajeMatricula = Porcentaje , @NombreMatricula = DescuentoNombre FROM DescuentoAlumnoResultado WITH(NOLOCK) WHERE IdMatricula =  @IdMatricula AND Cuota = 1     
  SELECT @PorcentajeCuotaUno = Porcentaje , @NombreCuotaUno = DescuentoNombre FROM DescuentoAlumnoResultado WITH(NOLOCK) WHERE IdMatricula =  @IdMatricula AND Cuota = 2       
     
  
  INSERT INTO @Descuento VALUES ( @IdMatricula , @PorcentajeMatricula , @NombreMatricula , @PorcentajeCuotaUno, @NombreCuotaUno)    
    
  UPDATE MatriculaConsulta  SET   
   CantCursosSemestre = @CantCursosSemestre,    
   CantCursosMatriculados= @CantCursosMatriculados,    
   PagoMatricula = @PagoMatricula,    
   MontoMatricula = @MontoMatricula,    
   PagoPrimeraCuota = @PagoPrimeraCuota,    
   MontoPrimeraCuota = @MontoPrimeraCuota    
  WHERE Id = @CurID  
          
  SET @CurID = @CurID + 1          
 END  
  
	--@4 Inicio
	DECLARE @direcciones AS TABLE(  
		Id INT IDENTITY(1,1),  
		IdActor INT,  
		IdDireccion INT,  
		Cantidad INT,  
		IdUbigeoResidencia INT  
	)    
  
	--insertamos ultima direccion  
	INSERT INTO @direcciones(IdActor,IdDireccion,Cantidad)  
	SELECT AD.IdActor, MAX(AD.IdDireccion), COUNT(0) FROM MatriculaConsulta MC WITH(NOLOCK)   
	INNER JOIN ActorDireccion AD WITH(NOLOCK) ON MC.IdActor = AD.IdActor  
	WHERE AD.Principal = 1 AND AD.Activo = 1  
	GROUP BY AD.IdActor  
  
	--actualizamos el ubigeo  
	UPDATE DIR SET DIR.IdUbigeoResidencia = AD.IdUbigeoResidencia  
	FROM @direcciones DIR  
	INNER JOIN ActorDireccion AD WITH(NOLOCK) ON AD.IdActor = DIR.IdActor AND AD.IdDireccion = DIR.IdDireccion  
	--@4 Fin
  

	--@9 Inicio
	DECLARE @InteresadoActor AS TABLE (
		IdActor INT,
		IdInteresado INT
	)

	INSERT INTO @InteresadoActor
	SELECT  i.IdActor, MIN(i.IdInteresado) FROM interesado i
	WHERE  i.IdActor in (SELECT MC.IdActor FROM MatriculaConsulta MC )
	GROUP BY i.IdActor
	--@9 Fin

	--@10 Inicio
	DECLARE @IdTipoSeccion INT,  
			@IdSeccionNormal INT  
  
	SELECT @IdTipoSeccion=IdMaestroTabla FROM MaestroTabla WITH(NOLOCK) WHERE Codigo='TipoSeccion' 
     
	SELECT @IdSeccionNormal=IdMaestroRegistro FROM MaestroTablaRegistro  WITH(NOLOCK) WHERE Codigo='Normal' AND IdMaestroTabla=@IdTipoSeccion
	--@10 Fin

	--@16 Inicio
	DECLARE @MatriculasConRetiro AS TABLE(
		IdMatricula INT,
		Nombre VARCHAR(200),
		Observacion VARCHAR(MAX),
		Estado VARCHAR(10),
		Tipo VARCHAR(20),
		FechaRetiro VARCHAR(20)
	)

	INSERT INTO @MatriculasConRetiro
	SELECT MR.IdMatricula, ISNULL(MTR.Nombre,''), ISNULL(MR.Observacion,''), MR.Estado, MR.Tipo, ISNULL(dbo.gFechaStr(MR.DocumentoFecha),'') FROM MatriculaRetiro MR WITH(NOLOCK)
	LEFT JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroRegistro = MR.IdMotivo 
	WHERE MR.IdMatricula IN (SELECT MC.IdMatricula FROM MatriculaConsulta MC ) AND MR.Estado = 'R' 
	--@16 Fin
         
	SELECT MC.SedeNombre,    --@13 --@16
	MC.UnidadNegocioNombre,    
	MC.UnidadAcademicaNombre,    
	MC.IdPeriodoAnual,    
	MC.PeriodoCodigo,    
	MC.ProductoCodigo,    
	MC.ProductoNombre,    
	MC.SemestreNombre,    
	MC.PromocionCodigo,    
	MC.PromocionNombre,    
	MC.Seccion,    
	MC.TurnoCodigo,    
	MC.TurnoNombre,    
	MC.CodigoAlumno,    
	MC.Apellidos,    
	MC.Nombres,    
	MC.NombreCompleto,    
	MC.NumeroDocumento,    
	MC.ActorGenero,    
	MC.FechaNacimiento,    
	'ActorUbigeo' = ISNULL(UB.NombreUnido,''), --@4  
	MC.ActorDireccion,    
	MC.ActorEmail,    
	MC.Celular,    
	MC.ActorTelefono,    
	MC.UsuarioRegistro,    
	MC.FechaInscripcion,    
	MC.MatriculaFecha,    
	MC.EstadoMatricula,    
	MC.Estado,    
	MC.CondicionPago,    
	MC.TipoIngreso,    
	MC.FechaInicioPeriodo,    
	MC.FechaFinPeriodo,    
	--MC.ObservacionRetiro, --@16  
	--MC.MotivoRetiro, --@16
	--MC.FechaRetiro, --@16
	'MotivoRetiroAsignatura' = TRIM(ISNULL(MRRA.Nombre, '') + ' ' + ISNULL(MRRA.Observacion, '')),  --@16  
	'FechaRetiroAsignatura' = ISNULL(MRRA.FechaRetiro, ''), --@16
	'MotivoRetiroCiclo' = TRIM(ISNULL(MRRC.Nombre, '') + ' ' + ISNULL(MRRC.Observacion, '')), --@16
	'FechaRetiroCiclo' = ISNULL(MRRC.FechaRetiro, ''), --@16
	MC.CantCursosSemestre,    
	MC.CantCursosMatriculados,    
	MC.PagoMatricula,    
	MC.MontoMatricula,    
	'MontoCanceladoMatricula' = ISNULL(MAT.MontoPagado, '0.00'), --@4  
	'PorcentajeMatricula' = ISNULL(D.PorcentajeMatricula,'0.00'),    
	'DescuentoMatricula' = ISNULL(D.NombreMatricula,''),    
	MC.PagoPrimeraCuota,    
	MC.MontoPrimeraCuota,    
	'MontoCanceladoPrimeraCuota' = ISNULL(C1.MontoPagado, '0.00'), --@4  
	'PorcentajePrimeraCuota' = ISNULL(D.PorcentajeCuotaUno,'0.00') ,     
	'DescuentoPrimeraCuota' = ISNULL(D.NombreCuotaUno,'') ,    
	MC.UsuarioModificacion,    
	MC.FechaModificacion,    
	'Tipo' = CASE ISNULL(M.Tipo,'')     
		WHEN 'CC' THEN 'Cambio Curricular'    
		WHEN 'CI' THEN 'Convalidaci�n Interna'    
		WHEN 'MA' THEN 'Captaci�n'    
		WHEN 'RE' THEN 'Regular'    
		WHEN 'RI' THEN 'Reingreso'    
		WHEN 'TS' THEN 'Traslado Sede'    
		ELSE ''          
		END 
	,'Colegio' = ISNULL(C.Nombre, '') --@11  
	,'TipoColegio' = ISNULL(MTR.Nombre,'') --@1
	,'UbigeoColegio' = ISNULL(COLEU.NombreUnido, '') --@11      
	,'A�oEgreso' = ISNULL(AA.AnnoEgreso,'') --@1    
	,'Distrito' = ISNULL(UDIS.Nombre,'') --@2    
	,'Provincia' = ISNULL(UPRO.Nombre,'') --@2    
	,'Departamento' = ISNULL(UDEP.Nombre,'') --@2    
	,'SepararVacante'= CASE WHEN M.IdPlanPago IS NULL OR M.IdPlanPago =0  THEN 'NO' ELSE 'SI' END --@3  
	,'UsuarioInscritoLogin'=ISNULL(U4.Nombre,'')  --@5  
	,MC.IdActor --@6  --@10
	,MC.IdMatricula --@6 --@10
	,'MedioDifusion'=ISNULL(dbo.cInteresadoMedioDifusionStr(itm.IdInteresado),'')--@8 --@9
	,'TipoMedioDifusion'=ISNULL(dbo.cInteresadoTipoMedioDifusionStr(itm.IdInteresado),'')--@8 --@9
	,'EmailInstitucion'=ISNULL(AL.EmailInstitucion,'') --@8 --@9 --@10
	--,'SedeCounter'=ISNULL(SE.Nombre,'')--@8 --@11
	,'IdInteresado'=ISNULL(itm.IdInteresado,'')--@8
	,'Convenio'=isnull(co.Nombre,'') --@7    
	,'Entidad'=isnull(En.NombreComercial,'') --@7  
	,'TipoSeccion' = isnull(MTR2.Codigo, '') --@10
	,'FechaComision' = dbo.gFechaStr(ISNULL(M.FechaComision,MC.MatriculaFecha))   --@14	--@15
	,'Virtualidad' =  CASE ISNULL(A.Virtual,0)  --@18    
					WHEN 0 THEN 'NO'    
					WHEN 1 THEN 'SI'
					END
	,'DocumentoFacturacion'=ISNULL(TD2.Nombre,'')--@19
	FROM MatriculaConsulta MC WITH(NOLOCK)    
	INNER JOIN Matricula M WITH(NOLOCK) ON MC.IdMatricula = M.IdMatricula
	INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON MC.IdPromocion = PG.IdPromocion AND MC.IdGrupo = PG.IdGrupo AND MC.Seccion = PG.GrupoCodigo--@10  
	INNER JOIN MaestroTablaRegistro MTR2  WITH(NOLOCK)  ON ISNULL(PG.IdTipoSeccion,@IdSeccionNormal)=MTR2.IdMaestroRegistro--@10 
	LEFT JOIN @Descuento D ON MC.IdMatricula = D.IdMatricula      
	LEFT JOIN ActorAcademica AA WITH(NOLOCK) ON MC.IdActor = AA.IdActor --@1    
	LEFT JOIN @InteresadoActor ITM  ON MC.IdActor=ITM.IdActor --@9
	LEFT JOIN Interesado I WITH(NOLOCK) ON ITM.IdInteresado = I.IdInteresado --@17    
	LEFT JOIN Colegio C WITH(NOLOCK) ON C.IdColegio = ISNULL(AA.IdColegio,I.IdColegio) --@1  
	LEFT JOIN Ubigeo COLEU WITH(NOLOCK) ON C.IdUbigeo = COLEU.IdUbigeo  --@11   
	LEFT JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON C.IdTipoGestion = MTR.IdMaestroRegistro --@1    
	LEFT JOIN @direcciones DIR ON DIR.IdActor = MC.IdActor --@4  
	LEFT JOIN Ubigeo UB WITH(NOLOCK) ON DIR.IdUbigeoResidencia = UB.IdUbigeo  --@2  
	LEFT JOIN Ubigeo UDIS WITH (NOLOCK) ON UDIS.Codigo = ISNULL(UB.Codigo,'000000') --@2  
	LEFT JOIN Ubigeo UPRO WITH (NOLOCK) ON UPRO.Codigo = ISNULL(UB.IdDepartamento,'00') + ISNULL(UB.IdProvincia,'00') + '00' --@2  
	LEFT JOIN Ubigeo UDEP WITH (NOLOCK) ON UDEP.Codigo = ISNULL(UB.IdDepartamento,'00') + '0000' --@2    
	LEFT JOIN @vw_CO_Interfase_P09_Header MAT ON MAT.IdMatricula = MC.IdMatricula AND MAT.CuotaNumero = 1 --@4  
	LEFT JOIN @vw_CO_Interfase_P09_Header C1 ON C1.IdMatricula = MC.IdMatricula AND C1.CuotaNumero = 2 --@4  
	LEFT JOIN Usuario U4 WITH (NOLOCK) ON M.InscritoIdUsuario=U4.IdUsuario --@5   
	INNER JOIN Actor A WITH(NOLOCK) ON M.IdActor=A.IdActor --@10  --@18
	LEFT JOIN Alumno AL WITH(NOLOCK) ON MC.IdActor = AL.IdAlumno��--@10
	--LEFT JOIN Usuario USU WITH(NOLOCK) ON USU.IdActor=A.IdActor --@9
	--LEFT JOIN EQUIPOVENTA EV WITH(NOLOCK) ON EV.IdCounter=U4.IdUsuario and ev.activo=1 --@11
	--LEFT JOIN SEDE SE WITH(NOLOCK) ON SE.IdSede=EV.IdSede --@11
	LEFT JOIN Convenio CO WITH(NOLOCK) ON M.IdConvenio=CO.IdConvenio  --@7        
	LEFT JOIN Entidad EN WITH(NOLOCK) ON M.IdEntidad=EN.IdEntidad --@7
	LEFT JOIN @MatriculasConRetiro MRRA ON MC.IdMatricula = MRRA.IdMatricula AND MRRA.Tipo = 'RA' --@16
	LEFT JOIN @MatriculasConRetiro MRRC ON MC.IdMatricula = MRRC.IdMatricula AND MRRC.Tipo = 'RC' --@16
	INNER JOIN ActorFacturacion MF WITH (NOLOCK) ON MF.IDMATRICULA = M.IDMATRICULA --@19
    LEFT JOIN TipoDocumento TD2 WITH (NOLOCK) ON MF.IdTipoDocumento=TD2.IdTipoDocumento  --@19
END