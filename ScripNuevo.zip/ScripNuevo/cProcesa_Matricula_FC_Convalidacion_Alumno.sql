---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  
--����������������������������������������������������������������������������              
--Creado por      : Miguel Quiroz (26/11/2024)              
--Funcionalidad   : Proceso que genera matricula para FC para alumnos que requieran subsanar un curso que ya no se dicta en la malla actual  
--Utilizado por   :    
--����������������������������������������������������������������������������         
/*                              
-----------------------------------------------------------------------------                              
Nro FECHA  USUARIO  DESCRIPCION                              
-----------------------------------------------------------------------------     

*/   
--CREATE   PROCEDURE [dbo].[cProcesa_Matricula_FC_Convalidacion_Alumno]  
declare
@CodigoAlumnoIn VARCHAR(200),  
@CodigoCurriculaIn VARCHAR(200),  
@CodigoCursoIn VARCHAR(200),  
@PromocionCodigoIn VARCHAR(200),  
@GrupoCodigoIn VARCHAR(200),  
@SeccionCodigoIn VARCHAR(200),
@CostoIn CHAR(4),
@RetVal VARCHAR(200)-- out
--AS  
BEGIN  
SELECT @CodigoAlumnoIn=N'SV76685079',@CodigoCurriculaIn=N'PESEXL',@CodigoCursoIn=N'03451',@PromocionCodigoIn=N'SV.0512.00.2025-02',@GrupoCodigoIn=N'00.01.2025-02',@SeccionCodigoIn=N'03451.24.00050',@CostoIn=N'SI'
SET NOCOUNT ON  
SET @RetVal = ''

DECLARE @CurID INT,    
  @MaxID INT,  
  @pIdActor INT,   
  @pIdRegistro INT,  
  @pIdPeriodo INT,  
  @pCodigoAnterior VARCHAR(100),  
  @pPromocionCodigo VARCHAR(100),  
  @pIdCurricula INT,   
  @pSeccionCodigo VARCHAR(100),   
  @Creamatricula INT,  
  @CodigoCurricula VARCHAR(50),   
  @CodigoCurso VARCHAR(50),  
  @IdCurricula INT,   
  @IdCurso INT,  
  @IdPromocion INT,  
  @ExisteCC INT,  
  @IdRegistro INT,  
  @IdSede INT,  
  @IdModulo INT,  
  @IdModuloMaxMat INT,  
  @IdModuloMaxTemp INT,  
  @IdGrupo INT,   
  @GrupoCodigo VARCHAR(50),  
  @EsMatriculaG INT,  
  @EsMatriculaM INT,  
  @EsMatriculaAC INT,  
  @IdMatricula INT,  
  @IdAlumnoCurso INT,  
  @IdCurriculaNueva INT,  
  @IdCursoNuevo INT,  
  @IdSeccion INT,  
  @Codigo VARCHAR(10),  
  @IdCurriculaHorario INT,  
  @Glosa VARCHAR(50),  
  @TipoServicio CHAR (2),  
  @TipoCondicionMatricula CHAR(2),  
  @TipoCondicionAC CHAR(2),   
  @GeneradoInterfase VARCHAR(10),  
  @CompaniaSocio CHAR(8),  
  @ValInterfase INT,  
  @Val_Sede INT,   
  @FechaInicioPeriodo DATETIME,  
  @FechaFinPeriodo DATETIME,   
  @Val_FechaPeriodo INT,  
  @IdSede_Val INT,  
  @IdCurriculaMat INT,  
  @NumeroCuota INT,  
  @Costo CHAR(2),  
  @CuentaCosto INT,  
  @IdSedeSeccion INT,  
  @IdMatriculaAnterior INT,  
  @Min INT,  
  @ContCursosTemp INT,   
  @ContCursosCur INT,  
  @Resultado CHAR(2),  
  @IdMatriculaAnteriorHist INT,  
  @IdUnidadAcademicaHist INT,  
  @IdUnidadAcademica INT,  
  @CuentaAC INT,  
  @MallaOficial INT,  
  @EsMatriculaActual INT  
  

DECLARE @fechaDocumento VARCHAR(10)  
SET @fechaDocumento = CONVERT(VARCHAR(10),GETDATE(),103)  
  
DECLARE @Temp2 TABLE   
(  
 Id INT ,   
 CodigoAlumno VARCHAR(50),  
 CodigoCurricula VARCHAR(20),  
 CodigoCurso VARCHAR(20),  
 PromocionCodigo VARCHAR(50),  
 GrupoCodigo VARCHAR(50),  
 SeccionCodigo VARCHAR(100),  
 Costo CHAR(2),  
 CreaMatricula INT,  
 Resultado CHAR(2),  
 Observaciones VARCHAR(MAX)  
)  
  
DECLARE @Matricula AS TABLE  
(  
 Id INT IDENTITY,  
 IdMatricula INT,  
 EsMatricula INT,  
 CodigoAlumno VARCHAR(50),  
 PromocionCodigo VARCHAR(50),  
 IdActor INT,  
 Costo CHAR(2)  
)  
  
DECLARE @MatriculaAnterior AS TABLE  
(  
 IdMatricula INT  
)  
  
DECLARE @temporal AS TABLE --TEMPORAL PRINCIPAL  
(  
 Id INT IDENTITY,   
 CodigoAlumno VARCHAR(200),  
 CodigoCurricula VARCHAR(200),  
 CodigoCurso VARCHAR(200),  
 PromocionCodigo VARCHAR(200),  
 GrupoCodigo VARCHAR(200),  
 SeccionCodigo VARCHAR(200),  
 Costo CHAR(4),  
 CreaMatricula INT,  
 Resultado CHAR(50),  
 Observaciones VARCHAR(MAX)  
)  
  
INSERT INTO @temporal values (@CodigoAlumnoIn,@CodigoCurriculaIn,@CodigoCursoIn,@PromocionCodigoIn,@GrupoCodigoIn,@SeccionCodigoIn,@CostoIn,1,'OK','')  
  
SELECT @CurID=Min(Id), @MaxID=Max(Id) FROM @temporal   
/*  
VARIABLES A EDITAR  
*/  
SET @EsMatriculaG = 0 --SE VALIDA PARA QUE INGRESE A GENERAR DETALLE DE CUOTAS  
  
SET @TipoServicio = 'C' --SERVICIO CURSO  
  
SET @TipoCondicionMatricula ='CC' -- CONDICI�N MATR�CULA CURSO REPITENCIA  
  
SET @TipoCondicionAC = 'CC' --CC -- CONDICI�N ALUMNOCURSO CURSO REPITENCIA  
  
SET @CompaniaSocio =null  
  
select @CompaniaSocio=CompaniaSocio from Empresa WITH(NOLOCK) where Activo = 1  
  

if @CompaniaSocio = '00002400'
begin
select @CompaniaSocio=CompaniaSocioPadre from Empresa WITH(NOLOCK) where Activo = 1  
end

DECLARE @CurCursos TABLE(  
 Id INT IDENTITY,       
 IdCurso INT,      
 TipoCondicion VARCHAR(2),      
 NumeroVez INT,      
 IdModulo INT  
)   
    
  
WHILE @MaxID >= @CurID  
BEGIN  
 /*  
 SETEO DE VARIABLES PARA QUE NO SE QUEDE PEGADA EN MEMORIA  
 */  
 SET @pIdActor = NULL  
 SET @pIdRegistro = NULL  
 SET @pIdPeriodo = NULL  
 SET @pCodigoAnterior = NULL  
 SET @pPromocionCodigo = NULL  
 SET @pIdCurricula = NULL  
 SET @pSeccionCodigo = NULL   
 SET @Creamatricula  = NULL  
 SET @CodigoCurricula = NULL  
 SET @CodigoCurso  = NULL  
 SET @IdCurricula = NULL   
 SET @IdCurso  = NULL  
 SET @IdPromocion = NULL   
 SET @ExisteCC = NULL   
 SET @IdRegistro = NULL  
 SET @IdSede = NULL   
 SET @IdModulo  = NULL  
 SET @IdModuloMaxMat = NULL  
 SET @IdModuloMaxTemp = NULL  
 SET @IdGrupo = NULL   
 SET @GrupoCodigo = NULL  
 SET @EsMatriculaM = NULL  
 SET @EsMatriculaAC = NULL  
 SET @IdMatricula = NULL  
 SET @IdAlumnoCurso = NULL   
 SET @IdCurriculaNueva = NULL  
 SET @IdCursoNuevo = NULL   
 SET @IdSeccion = NULL  
 SET @Codigo = NULL  
 SET @IdCurriculaHorario = NULL  
 SET @Glosa = NULL  
 SET @GeneradoInterfase = NULL  
 SET @ValInterfase = NULL  
 SET @Val_Sede = NULL  
 SET @FechaInicioPeriodo = NULL  
 SET @FechaFinPeriodo = NULL --  
 SET @Val_FechaPeriodo = NULL  
 SET @IdSede_Val = NULL  
 SET @IdCurriculaMat = NULL  
 SET @NumeroCuota = NULL  
 SET @Costo = NULL  
 SET @CuentaCosto = NULL  
 SET @IdSedeSeccion = NULL  
 SET @IdMatriculaAnterior = NULL  
 SET @Min = NULL  
 SET @ContCursosTemp = NULL  
 SET @ContCursosCur = NULL  
 SET @Resultado = NULL  
 SET @IdMatriculaAnteriorHist = NULL  
 SET @IdUnidadAcademicaHist = NULL  
 SET @IdUnidadAcademica = NULL  
 SET @CuentaAC = NULL  
 SET @MallaOficial = NULL  
 SET @EsMatriculaActual = NULL  
   

if not exists(select 1 from Alumno AL with (nolock) 
			inner join @temporal T on T.CodigoAlumno = Al.CodigoAnterior)
begin
	set @RetVal = 'KO | El Alumno no existe, validar por favor.'
	RETURN
end


 SELECT --TOMA DE VALORES  
  @pCodigoAnterior = CodigoAlumno,  
  @pPromocionCodigo = PromocionCodigo,  
  @pSeccionCodigo = SeccionCodigo,  
  @pIdActor = IdAlumno,  
  @Creamatricula = CreaMatricula,  
  @CodigoCurricula = CodigoCurricula,  
  @CodigoCurso = CodigoCurso,  
  @GrupoCodigo = GrupoCodigo,  
  @Costo = Costo,  
  @Resultado = Resultado
 FROM @temporal T  
 INNER JOIN Alumno AL WITH(NOLOCK) ON T.CodigoAlumno = AL.CodigoAnterior  
 WHERE Id=@CurID 

 /*  
 SE VALIDA SI ES CON COSTO O NO PARA GUARDAR EN EL GLOSA DE MATR�CULA   
 */      
 IF @Costo = 'NO'   
 BEGIN  
  SET @Glosa = 'CURSO SUBSANA S/COBRO'  
  SET @GeneradoInterfase = 'S'  
  SET @EsMatriculaM = 1  
  SET @EsMatriculaAC = 1  
 END  
 ELSE  
 BEGIN  
  SET @Glosa = 'CURSO SUBSANA C/COBRO'  
  SET @GeneradoInterfase = NULL  
  SET @EsMatriculaM = 0  
  SET @EsMatriculaAC = 0  
 END  
  
 IF @Resultado = 'KO'  
 BEGIN  
  GOTO A  
 END  
  
  
 IF PATINDEX('%[ABCDEFGHIJKLMNOPQRSTUVWXYZ]%', @CodigoCurricula) = 0 --SE VALIDA SI ES MALLA OFICIAL O ANTIGUA  
 BEGIN  
  SET @MallaOficial = 1  
 END  
 ELSE  
 BEGIN  
  SET @MallaOficial = 0  
 END  
   
 IF @Creamatricula = 1  
 BEGIN  
  IF ISNULL(@pSeccionCodigo,'') <>''  
  BEGIN  
     
   SET @IdCurricula = (SELECT IdCurricula FROM Curricula WITH(NOLOCK) WHERE Codigo = @CodigoCurricula)  
   SET @IdCurriculaHorario= (SELECT COUNT(IdCurricula) FROM Seccion WITH(NOLOCK) WHERE Codigo = @pSeccionCodigo)  

     
   IF @IdCurriculaHorario>1  
   BEGIN  
		SELECT 
			@RetVal = 'KO | ERROR - Horario c/ mas de 1 registro'
		FROM @temporal WHERE Id=@CurID

    GOTO A  
   END  
   ELSE  
   BEGIN  
    SET @IdCurriculaHorario= (SELECT IdCurricula FROM Seccion WITH(NOLOCK) WHERE Codigo = @pSeccionCodigo)  
   END  
  
   SET @IdModuloMaxMat = (SELECT MAX(IdModulo)FROM Matricula WITH(NOLOCK) WHERE IdActor = @pIdActor AND Estado = 'N' AND EsMatricula = 1)  
   SET @IdModuloMaxTemp = (SELECT MAX(IdModulo)FROM @temporal T  
         INNER JOIN Promocion P WITH(NOLOCK)ON P.PromocionCodigo= T.PromocionCodigo   
         WHERE T.CodigoAlumno = @pCodigoAnterior)  
   IF @IdModuloMaxMat > @IdModuloMaxTemp   
   BEGIN  
		SELECT 
			@RetVal = 'KO | ERROR - No se puede matricular alumno a m�dulo inferior al �ltimo que llev�'
		FROM @temporal WHERE Id=@CurID
    GOTO A  
   END  
     
   /*  
   SE TOMA �LTIMA MATR�CULA PARA TOMAR EL �LTIMO PROGRAMA  
   */  
   SET @IdMatriculaAnteriorHist = (SELECT TOP 1 M.IdMatricula              
   FROM Matricula M  WITH (NOLOCK)                 
   INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion=P.IdPromocion                 
   INNER JOIN Producto PRO  WITH (NOLOCK) ON P.IdProducto=PRO.IdProducto AND PRO.IdTipo=2 and PRO.idsubtipo =20  
   --INNER JOIN AlumnoCurso AC WITH (NOLOCK) ON M.IdMatricula = AC.IdMatricula             
   inner join MaestroTablaRegistro mtr WITH(NOLOCK) ON pro.IdClasificacionProducto = mtr.IdMaestroRegistro   
   INNER JOIN Registro r WITH (NOLOCK) ON m.IdActor = r.IdActor AND m.IdRegistro = r.IdRegistro      
   WHERE M.IdActor = @pIdActor               
   AND M.Estado <> 'X'              
   AND M.EsMatricula = 1  
   --and p.IdUnidadAcademica = 1  --@5  
   and p.IdUnidadNegocio = 2              
   -- AND AC.EsMatricula =1       
   AND r.Estado <> 'X'             
   AND mtr.Disponible1 = 'P'  
   AND mtr.Disponible2 = 'DIP'  
   ORDER BY m.MatriculaFecha DESC)   
     
   SET  @IdUnidadAcademicaHist = (SELECT P.IdUnidadAcademica FROM Matricula M WITH(NOLOCK)  
           INNER JOIN Promocion P ON P.IdPromocion = M.IdPromocion  
           WHERE M.IdMatricula = @IdMatriculaAnteriorHist)   
  
  
   SET @IdCurso =(SELECT IdCurso FROM Curso WITH(NOLOCK) WHERE CursoCodigo = @CodigoCurso)  
   DECLARE @Count INT =(SELECT COUNT(IdPromocion) FROM Promocion WITH(NOLOCK) WHERE PromocionCodigo = @pPromocionCodigo)  
   IF @Count>1  
   BEGIN  
    INSERT INTO @Temp2  
    SELECT * FROM @temporal WHERE ID=@CurID  

		SELECT 
			@RetVal =  'KO | ERROR - Promocion c/ mas de 1 registro'
		FROM @temporal WHERE Id=@CurID
    GOTO A  
   END  
   ELSE  
   BEGIN  
    SET @IdPromocion =(SELECT IdPromocion FROM Promocion WITH(NOLOCK) WHERE PromocionCodigo = @pPromocionCodigo)   
   END  
  
     
  
   SELECT @IdGrupo = IdGrupo FROM PromocionGrupo WITH(NOLOCK) WHERE IdPromocion = @IdPromocion and GrupoCodigo = @GrupoCodigo --se cambio orden 26.08.2022  
     
     
  
   SELECT @FechaInicioPeriodo=PE.Inicio, @FechaFinPeriodo=PE.Fin  FROM Promocion P WITH(NOLOCK) --  
   INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo=PE.IdPeriodo WHERE IdPromocion=@IdPromocion  
     
   /*  
   SE VALIDA QUE NO HAYA CRUCE DE PER�ODOS  
   */  
   SET @Val_FechaPeriodo=(SELECT DISTINCT 1 FROM Matricula M WITH(NOLOCK)  
           INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion=P.IdPromocion  
           INNER JOIN Periodo PE WITH(NOLOCK) ON Pe.IdPeriodo=P.IdPeriodo  
           WHERE M.IdActor=@pIdActor AND M.Estado='N' And P.IdPromocion<>@IdPromocion  
           AND @FechaInicioPeriodo BETWEEN PE.INICIO AND PE.FIN AND GETDATE() BETWEEN PE.INICIO AND PE.FIN AND P.IdUnidadNegocio = 2  
           )  
     
     
  
   --Valida Periodo  
   IF CONVERT(VARCHAR,@FechaFinPeriodo,112)  < CONVERT(varchar,GETDATE(),112)  
   BEGIN  

		  	SELECT 
		@RetVal =  'KO | ERROR - la fecha fin del periodo no puede ser menor a la fecha actual'
		FROM @temporal WHERE Id=@CurID
    GOTO A  
   END  
     
  
   SET @IdUnidadAcademica = (SELECT IdUnidadAcademica FROM Promocion WITH(NOLOCK) WHERE IdPromocion = @IdPromocion)  
   SET @pIdPeriodo = (Select IdPeriodo from Promocion WITH(NOLOCK) where IdPromocion = @IdPromocion)  
     
     
  
   IF @MallaOficial = 1 --SOLO SE VALIDA REGISTRO DE PROGRAMA PARA MALLAS OFICIALES  
   BEGIN  
    IF @IdUnidadAcademicaHist != @IdUnidadAcademica   
    BEGIN  
     IF NOT EXISTS(SELECT DISTINCT 1 FROM TrasladoSede TS WITH(NOLOCK) WHERE IdAlumno = @pIdActor AND IdUnidadAcademica = @IdUnidadAcademica AND IdPeriodoTraslado = @pIdPeriodo)  
     BEGIN  

	  	SELECT 
			@RetVal =  'KO | ERROR - Programa destino es diferente a programa de su �ltima matr�cula'
		FROM @temporal WHERE Id=@CurID
      GOTO A  
     END  
    END  
   END  
  
     
  
   IF @IdPromocion IS NULL  
   BEGIN  
	SELECT 
		@RetVal =  'KO | ERROR - No existe la seccion en esta promocion ' + @pPromocionCodigo + ' ' + @GrupoCodigo
	FROM @temporal WHERE Id=@CurID
    GOTO A  
   END  
  
   IF @IdGrupo IS NULL --se agrego 26.08.2022  
   BEGIN  

	SELECT 
		@RetVal =  'KO | ERROR - No existe la seccion en esta promocion ' + @pPromocionCodigo + ' ' + @GrupoCodigo
	FROM @temporal WHERE Id=@CurID
    GOTO A  
   END  
     
     
  
   IF ISNULL(@Val_FechaPeriodo,0)=0  
   BEGIN  
  
    SET @IdSede_Val =(SELECT IdSede FROM Promocion WITH(NOLOCK) WHERE IdPromocion=@IdPromocion)  
    SET @Val_Sede =(SELECT DISTINCT 1 FROM Matricula WITH(NOLOCK) WHERE IdSede=@IdSede_Val AND IdActor=@pIdActor AND Estado='N')   
      
    IF ISNULL(@Val_Sede,0) = 0   
    BEGIN  
     IF @MallaOficial = 1 --SI ES MALLA OFICIAL SE VALIDA QUE SE REGISTRE TRASLADO DE SEDE SI SE LE MATRICULA A UNA DIFERENTE  
     BEGIN  
      SET @Val_Sede = (SELECT DISTINCT 1 FROM TrasladoSede WITH(NOLOCK) WHERE IdAlumno = @pIdActor and IdPeriodoTraslado = @pIdPeriodo and IdSede= @IdSede_Val)  
     END   
     ELSE  
     BEGIN  
      SET @Val_Sede =1  
     END  
       
    END  
  
    IF @Val_Sede=1  
    BEGIN  
     SET @ExisteCC = (SELECT COUNT(*)FROM CurriculaCurso WITH(NOLOCK) WHERE IdCurricula = @IdCurricula and IdCurso = @IdCurso) --SE VALIDA QUE CURSO PERTENEZCA A LA MALLA  
       SELECT @IdCurso,'@IdCurso'
	   SELECT * FROM CurriculaCurso WITH(NOLOCK) WHERE IdCurricula = @IdCurricula-- and IdCurso = @IdCurso
	   SELECT  @ExisteCC,'@ExisteCC'
     IF @ExisteCC >0  
     BEGIN --SE VALIDA SI ALUMNO ESTUDI� EN MALLA ENVIADA  
        
        
      IF (EXISTS(SELECT DISTINCT 1 FROM Matricula   
      WHERE IdActor = @pIdActor AND Estado = 'N' and IdCurricula = @IdCurricula)  
      OR EXISTS(SELECT DISTINCT 1 FROM AlumnoCurricula WHERE IdAlumno = @pIdActor and IdCurricula = @IdCurricula ))  
      BEGIN  
         
       SET @IdRegistro =(SELECT COUNT(DISTINCT M.IdRegistro)   
        FROM Matricula M WITH(NOLOCK)   
        INNER JOIN Registro R WITH(NOLOCK) ON M.IdActor = R.IdActor AND M.IdRegistro = R.IdRegistro  
        WHERE M.IdActor = @pIdActor and M.IdCurricula = @IdCurricula AND M.Estado = 'N' AND R.Estado = 'N')  
         
       IF @IdRegistro <=1  
       BEGIN  
        SET @IdRegistro =(SELECT DISTINCT M.IdRegistro   
        FROM Matricula M WITH(NOLOCK)   
        INNER JOIN Registro R WITH(NOLOCK) ON M.IdActor = R.IdActor AND M.IdRegistro = R.IdRegistro  
        WHERE M.IdActor = @pIdActor and M.IdCurricula = @IdCurricula AND M.Estado = 'N' AND R.Estado = 'N')  
          
       END  
       ELSE  
       BEGIN  
		  SELECT 
			@RetVal =  'KO | ERROR - Alumno c/ mas de 1 registro por malla'
		  FROM @temporal WHERE Id=@CurID

        GOTO A  
       END  
  
       IF @IdRegistro IS NULL  
       BEGIN  
        SET @IdRegistro =(SELECT DISTINCT IdRegistro   
        FROM AlumnoCurriculaCurso WITH(NOLOCK) WHERE IdAlumno= @pIdActor and IdCurricula = @IdCurricula)  
       END  
         
       IF @IdRegistro IS NULL  
       BEGIN  

		  SELECT 
			@RetVal = 'KO | ERROR - Registro vac�o'
		  FROM @temporal WHERE Id=@CurID
        GOTO A  
       END  
  
       SET @Codigo = (SELECT PE.Codigo FROM Promocion P WITH(NOLOCK) INNER JOIN Periodo PE WITH(NOLOCK) ON PE.IdPeriodo = P.IdPeriodo WHERE P.IdPromocion =@IdPromocion)  
         
         
       /*  
       SE VALIDA QUE ALUMNO NO EST� ESTUDIANDO EN EL PER�ODO Y PROMOCI�N A MATRICULAR  
       */  
       IF NOT EXISTS (SELECT DISTINCT 1 FROM Matricula M WITH(NOLOCK)  INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = M.IdPromocion   
                    INNER JOIN Periodo PE WITH(NOLOCK) ON PE.IdPeriodo = P.IdPeriodo  
                    WHERE M.IdActor =@pIdActor and PE.Codigo = @Codigo AND M.Estado = 'N' AND P.IdPromocion<>@IdPromocion)  
       BEGIN   
          
        SET @CuentaCosto =(SELECT COUNT(DISTINCT Costo) FROM @temporal WHERE CodigoAlumno = @pCodigoAnterior AND PromocionCodigo =@pPromocionCodigo)  
        IF @CuentaCosto >1  --SE VERIFICA QUE SI SE ENV�A REGISTROS DE COSTOS SI Y COSTOS NO, SE LE COLOCAR� COMO PRE MATRICULADO  
        BEGIN  
         SET @EsMatriculaM = 0  
        END  
          
        IF NOT EXISTS(SELECT DISTINCT 1 FROM Matricula WITH(NOLOCK) WHERE IdActor = @pIdActor and IdPromocion = @IdPromocion AND Estado = 'N') --SI NO EXISTE MATR�CULA SE INSERTAR�  
        BEGIN  
         SELECT @IdSede = IdSede, @IdModulo = 1 FROM Promocion WITH(NOLOCK) WHERE IdPromocion = @IdPromocion  
           
         SELECT @NumeroCuota = MAX(CuotaNumero) FROM CronogramaPago WITH(NOLOCK) WHERE IdPromocion = @IdPromocion  
     
         DECLARE @Numero VARCHAR(50)=''    
         EXEC cMatricula_Gen_Numero @Numero OUTPUT  
         SELECT @IdMatricula = MAX(ISNULL(IdMatricula, 0)) + 1 FROM Matricula       
          
         INSERT INTO Matricula (IdMatricula,IdEmpresa,IdSede ,IdActor,IdRegistro,IdCurricula,IdModulo,IdPromocion,IdGrupo,Numero, InscritoFecha,InscritoIdUsuario,InscritoNO,MatriculaFecha,MatriculaIdUsuario,  
         EsMatricula,EsComision,EsCerrado,IdProcedencia,IdMoneda,TipoCondicion,TipoServicio,Tipo,Estado,UsuarioCreacion,FechaCreacion,  
         UsuarioModificacion,FechaModificacion,CondicionPago,idPeriodo,TipoCondicionFinal,NumeroMatricula,NumeroCuota,TipoInscripcion)VALUES  
         (@IdMatricula,1,@IdSede,@pIdActor,@IdRegistro,@IdCurricula,@IdModulo,@IdPromocion,@IdGrupo,@Numero,GETDATE(),1,1,GETDATE(),1,  
         @EsMatriculaM,1,0,0,236,@TipoCondicionMatricula,@TipoServicio,'RE','N',1,GETDATE(),1,GETDATE(),'Q',@pIdPeriodo,NULL,@Glosa,@NumeroCuota,'I')  
           
         --select @IdMatricula,@Numero Numero, @NumeroCuota NumeroCuota,@IdModulo IdModulo,@IdSede IdSede,@EsMatriculaM EsMatriculaM  
         --,@CuentaCosto CuentaCosto,@Codigo Codigo,@IdRegistro IdRegistro, @IdCurricula IdCurricula,@pSeccionCodigo pSeccionCodigo  
         --,@Creamatricula Creamatricula,@IdCurriculaHorario dCurriculaHorario  
         --,@pIdActor pIdActor,@IdMatriculaAnteriorHist IdMatriculaAnteriorHist,@IdUnidadAcademicaHist IdUnidadAcademicaHist  
         --,@pPromocionCodigo pPromocionCodigo,@IdPromocion IdPromocion,@IdGrupo IdGrupo,@FechaInicioPeriodo FechaInicioPeriodo  
         --,@FechaFinPeriodo FechaFinPeriodo,@Val_FechaPeriodo Val_FechaPeriodo,@IdUnidadAcademica IdUnidadAcademica  
         --,@pIdPeriodo pIdPeriodo,@MallaOficial MallaOficial,@IdSede_Val IdSede_Val,@Val_Sede Val_Sede,@ExisteCC ExisteCC  
         --select   
  
         If @@ROWCOUNT = 1  
         BEGIN  
          --rollback  
		  SELECT 
			@RetVal = 'OK - Registrado correctamente - Matricula'
		  FROM @temporal WHERE Id=@CurID 
         END  
         ELSE  
         BEGIN  
          --rollback  

		  		 SELECT 
			@RetVal =  'ERROR - No se registr� Matricula'
		  FROM @temporal WHERE Id=@CurID 
         END  
   
        END  
        ELSE  
        BEGIN  

		 SELECT 
			@RetVal = Observaciones + ' | OK - Ya tiene registro de Matricula'  
		  FROM @temporal WHERE Id=@CurID 
         SELECT @IdMatricula = IdMatricula, @EsMatriculaM =EsMatricula FROM Matricula WITH(NOLOCK)  WHERE IdActor = @pIdActor AND IdPromocion = @IdPromocion and Estado = 'N'  
         SELECT @IdSede = IdSede, @IdModulo = IdModulo from Promocion WITH(NOLOCK) where IdPromocion = @IdPromocion  
         SELECT @IdGrupo = IdGrupo FROM PromocionGrupo WITH(NOLOCK) WHERE IdPromocion = @IdPromocion and GrupoCodigo = @GrupoCodigo  
        END  
  
        SELECT @EsMatriculaActual = EsMatricula FROM Matricula WITH(NOLOCK) WHERE IdMatricula = @IdMatricula  
  
        IF @EsMatriculaActual = 1 AND @Costo = 'SI'   
        BEGIN  


		 	 SELECT 
			@RetVal = 'KO | ERROR - No se puede agregar cursos de pago a una Matricula pagada'
		  FROM @temporal WHERE Id=@CurID 
         GOTO A  
        END  
  
        SET @IdMatriculaAnterior = (SELECT ISNULL(IdMatricula,0)FROM @MatriculaAnterior)  
        SET @Min = (SELECT MIN(Id) FROM @temporal)  
          
        IF @IdMatriculaAnterior IS NULL SET @IdMatriculaAnterior = 0  
  
        IF @IdMatricula != @IdMatriculaAnterior   
        BEGIN  
         DELETE FROM @MatriculaAnterior   
         INSERT INTO @MatriculaAnterior VALUES (@IdMatricula)  
        END  
          
        SELECT @IdPromocion = IdPromocion, @IdGrupo = IdGrupo, @IdSeccion = IdSeccion, @IdCurriculaNueva = IdCurricula,@IdCursoNuevo = IdCurso FROM Seccion WITH(NOLOCK) WHERE Codigo = @pSeccionCodigo  
          
        SET @IdAlumnoCurso = (SELECT MAX(IdAlumnoCurso)+1 FROM AlumnoCurso WITH(NOLOCK) WHERE IdAlumno = @pIdActor AND IdRegistro= @IdRegistro)  
          
        IF @IdAlumnoCurso IS NULL SET @IdAlumnoCurso =1  
          
        SET @IdSedeSeccion = (SELECT IdSede FROM Seccion S INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = S.IdPromocion WHERE Idseccion = @IdSeccion)  
          
  
        IF @IdCurricula IS NOT NULL and @IdCurso is not null  
        BEGIN  
         SELECT @IdCurriculaMat = IdCurricula FROM Matricula WITH(NOLOCK) WHERE IdMatricula = @IdMatricula  
         IF @IdCurricula !=@IdCurriculaMat  
         BEGIN  
		 SELECT 
			@RetVal = 'KO | '+   Observaciones + ' | ERROR - Curricula de Matricula diferente a Curricula enviada '+ CodigoCurricula
		  FROM @temporal WHERE Id=@CurID 

          GOTO A  
         END  
        END  
        ELSE  
        BEGIN   
         SELECT @IdCurriculaMat = IdCurricula FROM Matricula WITH(NOLOCK) WHERE IdMatricula = @IdMatricula  
           
         IF @IdCurriculaNueva !=@IdCurriculaMat  
         BEGIN  

		  SELECT 
			@RetVal = 'KO | '+  Observaciones + ' | ERROR - Curricula de Matricula diferente a Curricula enviada '+ CodigoCurricula
		  FROM @temporal WHERE Id=@CurID 
		  
          GOTO A  
         END  
        END  
  
        IF @IdCursoNuevo = @IdCurso AND @IdCurricula = @IdCurriculaNueva   
        BEGIN  
         SET @IdCurricula = NULL   
         SET @IdCurso = NULL  
        END  
          
        IF NOT EXISTS(SELECT DISTINCT 1 FROM AlumnoCurso WITH(NOLOCK) WHERE IdMatricula = @IdMatricula AND IdCurso = @IdCursoNuevo)  
        BEGIN  
         INSERT INTO AlumnoCurso(IdAlumno,IdRegistro,IdAlumnoCurso,IdCurricula,IdCurso,IdMatricula,IdPromocion,IdGrupo,IdSeccion,EsMatricula,TipoCondicion,UsuarioCreacion,  
         FechaCreacion,UsuarioModificacion,FechaModificacion,Estado,IdCurriculaOriginal,IdCursoOriginal,NumVezCurso,GeneradoInterface)VALUES  
         (@pIdActor,@IdRegistro,@IdAlumnoCurso,@IdCurriculaNueva,@IdCursoNuevo,@IdMatricula,@IdPromocion,@IdGrupo,@IdSeccion,@EsMatriculaAC,@TipoCondicionAC,1,GETDATE(),1,GETDATE(),'NO'  
         ,@IdCurricula,@IdCurso,2,@GeneradoInterfase)  
           
         IF @@ROWCOUNT = 1  
         BEGIN  
          --rollback  
		  SELECT 
			@RetVal = Observaciones + ' |OK - Registrado correctamente - DetalleMatricula ' + @pSeccionCodigo
		  FROM @temporal WHERE Id=@CurID 


         END  
         ELSE  
         BEGIN  


		  SELECT 
			@RetVal = Observaciones+ ' KO |ERROR - No se Registr� DetalleMatricula '+ @pSeccionCodigo  
		  FROM @temporal WHERE Id=@CurID 
         END  
        END  
        ELSE  
        BEGIN  
          UPDATE AlumnoCurso SET  
           IdSeccion =@IdSeccion,  
           IdGrupo = @IdGrupo,  
           IdPromocion = @IdPromocion,  
           EsMatricula = 1,  
           GeneradoInterface =@GeneradoInterfase  
          WHERE IdMatricula =@IdMatricula AND IdCurso = @IdCursoNuevo  
          
  
         IF @@ROWCOUNT >= 1  
         BEGIN  


		   SELECT 
			@RetVal = Observaciones + ' |ok - Actualizado correctamente - DetalleMatricula '+ @pSeccionCodigo  
		  FROM @temporal WHERE Id=@CurID 
         END  
         ELSE  
         BEGIN  


		  SELECT 
			@RetVal = Observaciones+ 'KO |ERROR - No se actualiz� DetalleMatricula '+ @pSeccionCodigo 
		  FROM @temporal WHERE Id=@CurID 
         END  
        END  
  
        IF NOT EXISTS(SELECT DISTINCT 1 FROM @Matricula WHERE IdMatricula = @IdMatricula AND Costo = 'SI') --  
        BEGIN  
         INSERT INTO @Matricula VALUES (@IdMatricula,@EsMatriculaM,@pCodigoAnterior,@pPromocionCodigo,@pIdActor,@Costo)  
        END  
       END  
       ELSE  
       BEGIN      

		 SELECT 
			@RetVal = 'KO | '+ 'ERROR - Alumno cuenta con matr�cula activa en el per�odo ' + @Codigo
		  FROM @temporal WHERE Id=@CurID 
        GOTO A  
       END  
      END  
      ELSE  
      BEGIN  
     
 
	   		 SELECT 
			@RetVal = 'KO | '+'ERROR - Alumno nunca estudi� en esta curricula'
		  FROM @temporal WHERE Id=@CurID 
      END  
     END  
     ELSE  
     BEGIN  
	  
	  	   SELECT 
			@RetVal = 'KO | '+'ERROR - Curso '+@CodigoCurso+' no pertenece a Curr�cula ' + @CodigoCurricula
		  FROM @temporal WHERE Id=@CurID 
     END  
    END  
    ELSE  
    BEGIN  


	 SELECT 
			@RetVal = 'KO | ERROR - El Alumno no tiene matriculas en la Sede Enviada'
		  FROM @temporal WHERE Id=@CurID 
    END  
   END  
   ELSE  
   BEGIN  

	
		 SELECT 
			@RetVal = 'KO | ERROR - El Alumno tiene un Periodo activo con cruce de Fechas al Periodo Enviado'
		  FROM @temporal WHERE Id=@CurID 
   END  
  END  
  ELSE  
  BEGIN    


   	 SELECT 
			@RetVal = 'KO | ERROR - El Codigo de Seccion est� vacio ' + @Codigo
		  FROM @temporal WHERE Id=@CurID 
  END  
 END  
 

 A:   
 SET @Min = (SELECT MIN(Id) FROM @temporal)   
 IF @Min != @CurID AND @IdMatricula != @IdMatriculaAnterior --SE SE INSERT� MATR�CULA PERO EN LOS CURSOS TODOS CAYERON EN KO - SE ELIMINA MATR�CULA VAC�A  
 BEGIN  
  DECLARE @CountAcc INT  
  SET @CountAcc =(SELECT COUNT(*)FROM AlumnoCurso  WITH(NOLOCK) WHERE IdMatricula = @IdMatriculaAnterior)  
  IF @CountAcc = 0  
  BEGIN  
   DELETE FROM Matricula WHERE IdMatricula = @IdMatriculaAnterior   
  END  
 END  
 SET @CurID = @CurID +1  
END  
  
/*  
 DETALLE DE CUOTAS  
*/  
IF @EsMatriculaG = 0 AND 1=(SELECT DISTINCT 1 FROM @Matricula WHERE Costo = 'SI')  
BEGIN  
 PRINT 'ENTRO'  
 DECLARE @MinMat INT,  
   @MaxMat INT,  
   @NumeroIdentidad VARCHAR(20),  
   @IdDocumentoTipo INT,  
   @DireccionCompleta VARCHAR(500),  
   @RazonSocial varchar(200),  
   @IdUbigeo INT,  
   @Telefono VARCHAR(200),  
   @Retorno INT   
  
 SELECT @MinMat=MIN(Id), @MaxMat = MAX(Id) FROM @Matricula  
 WHILE @MinMat <= @MaxMat  
 BEGIN  
  SELECT @IdMatricula = IdMatricula,  
    @pIdActor = IdActor,  
    @pCodigoAnterior = CodigoAlumno,  
    @pPromocionCodigo = PromocionCodigo,  
    @EsMatriculaM = EsMatricula  
  FROM @Matricula  
  WHERE Id = @MinMat  
  AND Costo = 'SI'  
  
  
  SET @ValInterfase = 0  
  
  IF @EsMatriculaM = 0  
  BEGIN  
   SELECT @RazonSocial=NombreCompleto,@NumeroIdentidad = NumeroIdentidad,@IdDocumentoTipo=ISNULL(IdDocumentoTipo,25),@DireccionCompleta= ISNULL(DireccionCompleta,''),@IdUbigeo =IdUbigeoNacimiento  FROM Actor WITH(NOLOCK) where IdActor =@pIdActor  
   SET @Telefono = (SELECT dbo.cActorTelefonoStr(@pIdActor))  
  
   SET @CuentaAC = (SELECT COUNT(*)FROM AlumnoCurso WHERE IdMatricula = @IdMatricula) --SI EN ALUMNOCURSO SOLO SE INSERT� UN CURSO, SE CAMBIA LA CONDICI�N DE PAGO A CONTADO  
  
   IF @CuentaAC = 1   
   BEGIN  
    UPDATE Matricula SET  
     CondicionPago ='C',  
     NumeroCuota =1  
    WHERE IdMatricula = @IdMatricula  
   END  
  
   IF NOT EXISTS(SELECT DISTINCT 1 FROM MatriculaPagante WITH(NOLOCK) WHERE IdMatricula = @IdMatricula)  
   BEGIN  
    EXEC cMatriculaPagante_Ins_Grabar @IdMatricula,@pIdActor,'N',236,0,0,NULL,1,'R',1  
   END  
  
   IF NOT EXISTS(SELECT DISTINCT 1 FROM ActorFacturacion WITH(NOLOCK) WHERE IdMatricula = @IdMatricula)  
   BEGIN  
    EXEC cActorFacturacion_Ins_Grabar @IdMatricula,@pIdActor,2,@NumeroIdentidad,@RazonSocial,@DireccionCompleta,@IdUbigeo,@Telefono,0,0,0,1  
   END  
   --CAMBIAR  
   IF NOT EXISTS(Select DISTINCT 1 FROM PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header WITH(NOLOCK) where IdMatricula = @IdMatricula and CompaniaSocio = @CompaniaSocio)  
   BEGIN  
    SET @Retorno = 0  
    EXEC  cInterfaseDocumento_Ins_Grabar_General @IdMatricula, @Retorno output  
   END  
   ELSE   
   BEGIN  
    --CAMBIAR  
    IF NOT EXISTS (Select DISTINCT 1 FROM PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header WITH(NOLOCK) where IdMatricula = @IdMatricula and Estado = 'CO' and CompaniaSocio = @CompaniaSocio)  
    BEGIN  
     SET @Retorno = 0    
     EXEC  cInterfaseDocumento_Ins_Borrar_General_ESE @IdMatricula,@CompaniaSocio,@Retorno output  
     IF @Retorno = 0  
     BEGIN  
      SET @Retorno = 0  
      EXEC  cInterfaseDocumento_Ins_Grabar_General @IdMatricula, @Retorno output  
     END  
    END  
    ELSE  
    BEGIN  

      
	   SELECT 
			@RetVal = 'KO | ERROR Interfase - Tiene Cuota Pagada'
	   FROM @temporal WHERE CodigoAlumno = @pCodigoAnterior and PromocionCodigo = @pPromocionCodigo  

     SET @ValInterfase = 1  
       
    END  
   END  
  
   BEGIN  
    EXEC cDescuentoAlumno_Upd_AutoAsignarXmatricula @IdMatricula  
   END  
  
   IF @Retorno = 0 AND @ValInterfase = 0  
   BEGIN    
	  SELECT 
			@RetVal = Observaciones + ' |OK Genero Interfase en Spring'
	   FROM @temporal WHERE CodigoAlumno = @pCodigoAnterior and PromocionCodigo = @pPromocionCodigo  

   END  
   ELSE  
   BEGIN  
		  SELECT 
			@RetVal = Observaciones + ' KO |ERROR Interfase'
	   FROM @temporal WHERE CodigoAlumno = @pCodigoAnterior and PromocionCodigo = @pPromocionCodigo  
   END  
  END  
  SET @MinMat = @MinMat + 1  
 END  
END  
END
