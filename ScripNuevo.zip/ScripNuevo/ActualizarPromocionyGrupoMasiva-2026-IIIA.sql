DECLARE @PERIODO VARCHAR(10) ='2026-IIIA'

--select 'VALIDAR INCOHERENCIAS DE IdPromocion Y IdGrupo ENTRE AlumnoCurso - Seccion '
--UPDATE AC SET IdPromocion = S.IdPromocion, IdGrupo = S.IdGrupo
SELECT PR.Codigo, M.IdMatricula, M.Numero, A.NombreCompleto, M.IdPromocion AS [IdPromocion_M], AC.IdAlumno AS [IdAlumno_AC], AC.IdRegistro AS [IdRegistro_AC], AC.IdAlumnoCurso AS [IdAlumnoCurso_AC], 
	AC.IdPromocion AS [IdPromocion_AC], AC.IdGrupo AS [IdGrupo_AC], AC.IdSeccion AS [IdSeccion_AC], S.IdPromocion AS [IdPromocion_S], S.IdGrupo AS [IdGrupo_S], S.Idseccion AS [Idseccion_S], 
	C.CursoNombre AS [CursoNombre_C], CO.CursoNombre AS [CursoNombre_CO], UN.Nombre AS [Nombre_UN], UA.Nombre AS [Nombre_UA]--, *
FROM Matricula M
	JOIN Promocion P ON M.IdPromocion = P.IdPromocion
	JOIN AlumnoCurso AC ON M.IdMatricula = AC.IdMatricula
	JOIN Seccion S ON AC.IdSeccion = S.Idseccion
	JOIN Periodo PR ON P.IdPeriodo = PR.IdPeriodo
	JOIN Alumno AL ON M.IdActor = AL.IdAlumno
	JOIN Actor A ON M.IdActor = A.IdActor
	JOIN Curso C ON AC.IdCurso = C.IdCurso
	LEFT JOIN Curso CO ON AC.IdCursoOriginal = CO.IdCurso
	LEFT JOIN UnidadNegocio UN ON P.IdUnidadNegocio = UN.IdUnidadNegocio
	LEFT JOIN UnidadAcademica UA ON P.IdUnidadAcademica = UA.IdUnidadAcademica
WHERE 
	M.Estado = 'N'
	AND 
	M.EsMatricula = 1
	AND 
	AC.EsMatricula = 1
	AND 
	PR.IdPeriodoAnual > 2025
  AND PR.Codigo= @PERIODO
	AND (
		AC.IdPromocion IS NULL 
		OR AC.IdGrupo IS NULL 
		OR (
				ISNULL(AC.IdPromocion, -1) != ISNULL(S.IdPromocion, -1) OR ISNULL(AC.IdGrupo, -1) != ISNULL(S.IdGrupo, -1)
			)
	)
	----AND M.IdMatricula=829111
ORDER BY A.NombreCompleto