
-- PASO 1 CREACION DE EL ITEM
declare @p14 int
set @p14=483255
exec cItem_Ins_Grabar @IdSistema=3,@Codigo=N'SMNUMATREGEQUIVDIP',@Nombre=N'Registro Equivalencias Diplomados',@EsEnlace=0,@EnlaceWeb=N'',@IdTipo=N'SM',@Nivel=3,@IdPadre=3002,@CodigoPadre=N'MNUMATRICULA',@Estado=N'A',@EsSeparador=0,@EsToolbar=0,@Archivo=N'',@RetVal=@p14 output
select @p14

-- PASO 2 ASIGNACION DE EL ITEM A UN MODULO
declare @p4 bit
set @p4=0
exec cRolUsuario_Val_Codigo @IdRol=-1,@IdSistema=3,@Codigo=N'SMNUMATREGEQUIVDIP',@retval=@p4 output
select @p4
go
declare @p4 bit
set @p4=0
exec cRolUsuario_Val_Nombre @IdRol=-1,@IdSistema=3,@Nombre=N'Registro Equivalencias Diplomados',@retval=@p4 output
select @p4
go
declare @p7 int
set @p7=306
exec cRolUsuario_Ins_Grabar @IdSistema=3,@Codigo=N'SMNUMATREGEQUIVDIP',@Nombre=N'Registro Equivalencias Diplomados',@Observacion=N'',@Activo=1,@UsuarioCreacion=446639,@RetVal=@p7 output
select @p7
go
exec cRolUsuarioItem_Ins_Grabar @IdSistema=3,@IdRol=306,@IdItem=3000	
exec cRolUsuarioItem_Ins_Grabar @IdSistema=3,@IdRol=306,@IdItem=470005	
exec cRolUsuarioItem_Ins_Grabar @IdSistema=3,@IdRol=306,@IdItem=483253	

--PASO 3 ASIGNACION DE EL PERMISO A EL USUARIO DESIDAT

exec cPermiso_Ins_Grabar @IdSistema=3,@IdRol=306,@IdUsuario=446639,@UsuarioCreacion=446639