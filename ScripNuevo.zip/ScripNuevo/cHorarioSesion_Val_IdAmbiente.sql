--����������������������������������������������������������������������������                                                                      
--Creado por      :Carlos Huallpa(20/01/2008)                                                          
--Funcionalidad   :Valida el cruce del ambiente dentro de la programacion de horarios
--Utilizado por   :HorarioSesion.ValIdAmbienteLis                                                            
--���������������������������������������������������������������������������� 
/*
-----------------------------------------------------------------------------
Nro		FECHA		USUARIO		DESCRIPCION
-----------------------------------------------------------------------------
@1		15.08.2011	ssalazar	se agreg� isnull a un campo 
@2		16.09.2019  YFlores		Se remplaza las funciones fecha112 por convert
@3		04/04/2025	ALSANCHEZ		Se devuelve un valor 0 en el campo EsSeparacion cuando es nulo
*/                                                                 
ALTER PROCEDURE [dbo].[cHorarioSesion_Val_IdAmbiente]              
@Fecha VARCHAR(10),                                                                  
@Inicio INT,                                                                  
@Fin INT,                                                                  
@IdAmbiente INT                                                                  
AS              
SET DATEFORMAT DMY                            
DECLARE @IdAmbientePrincipal INT                              
SET @IdAmbientePrincipal=(SELECT IdAmbientePrincipal FROM Ambiente                               
             WHERE IdAmbiente=@IdAmbiente)                              
--                                                              
SELECT HS.IdSesion                                    
,'SeccionCodigo'=S.Codigo    
,'CursoNombre'=ISNULL(C.CursoNombre,'')              
,'SeparacionAsunto'=ISNULL(ST.Asunto,'')              
,PRO.PromocionCodigo                                  
,PRO.PromocionNombre                                
,'UnidadNegocioNombre'=UN.Nombre              
,'UnidadAcademicaNombre'=UA.Nombre              
,'AmbienteCodigo'=A.Codigo                                                                  
,'AmbienteNombre'=A.Nombre  
,'SedeNombre'=SE.Nombre             
,'ActorNombreCompleto'=ISNULL(AA.NombreCompleto,'')              
,'SeccionFechaInicio'=ISNULL(CONVERT(VARCHAR(10),S.FechaInicio,103),'')    --@2                                                               
,'SeccionFechaFin'=ISNULL(CONVERT(VARCHAR(10),S.FechaFin,103),'')               --@2
,HS.Inicio                  
,HS.Fin                  
,ISNULL(HS.EsSeparacion, 0) AS 'EsSeparacion'       --@3    
,'ResponsableNombre'=ISNULL(U.Nombre,'')              
,'UsuarioNombre'=ISNULL(UU.Nombre,'')                                                      
FROM HorarioSesion HS              
INNER JOIN Seccion S              
ON HS.IdSeccion=S.IdSeccion              
LEFT JOIN Promocion PRO                                  
ON S.IdPromocion=PRO.IdPromocion               
LEFT JOIN UnidadAcademica UA              
ON PRO.IdUnidadAcademica=UA.IdUnidadAcademica              
LEFT JOIN UnidadNegocio UN              
ON PRO.IdUnidadNegocio=UN.IdUnidadNegocio              
LEFT JOIN Separacion ST                                                    
ON HS.IdSeparacion=ST.IdSeparacion              
LEFT JOIN Usuario U                                      
ON ST.IdUsuario=U.IdUsuario                   
LEFT JOIN Actor AA              
ON ISNULL(HS.IdActorReemplazo,HS.IdActorProgramado)=AA.IdActor              
LEFT JOIN Curso C                                                                  
ON S.IdCurso=C.IdCurso                                                                  
INNER JOIN Ambiente A                                                                  
ON HS.IdAmbiente=A.IdAmbiente              
INNER JOIN Sede SE            
ON A.IdSede =  SE.IdSede                                 
INNER JOIN Usuario UU                                  
ON HS.UsuarioModificacion=UU.IdUsuario              
WHERE CONVERT(VARCHAR(8),HS.Fecha,112)=CONVERT(VARCHAR(8),convert(date,@Fecha),112)    --@2 
AND (                                    
HS.Inicio BETWEEN @Inicio AND @Fin OR                        
HS.Fin BETWEEN @Inicio AND @Fin OR                                     
@Inicio BETWEEN HS.Inicio AND HS.Fin OR                                 
@Fin BETWEEN HS.Inicio AND HS.Fin)                                  
AND HS.IdAmbiente=@IdAmbiente                              
AND HS.EsPostergado=0            
AND (HS.Estado <> 'E' OR HS.Estado <> 'A')                           
UNION--del padre                         
SELECT HS.IdSesion                                    
,'SeccionCodigo'=S.Codigo                                                              
,'CursoNombre'=ISNULL(C.CursoNombre,'')              
,'SeparacionAsunto'=ISNULL(ST.Asunto,'')              
,PRO.PromocionCodigo                                  
,PRO.PromocionNombre                                
,'UnidadNegocioNombre'=UN.Nombre              
,'UnidadAcademicaNombre'=UA.Nombre                
,'AmbienteCodigo'=A.Codigo                                                                  
,'AmbienteNombre'=A.Nombre              
,'SedeNombre'=SE.Nombre             
,'ActorNombreCompleto'=ISNULL(AA.NombreCompleto,'')              
,'SeccionFechaInicio'=ISNULL(CONVERT(VARCHAR(10),S.FechaInicio,103),'') --@2                                                                
,'SeccionFechaFin'=ISNULL(CONVERT(VARCHAR(10),S.FechaFin,103),'') --@2            
,HS.Inicio                  
,HS.Fin                  
,ISNULL(HS.EsSeparacion, 0) AS 'EsSeparacion'        --@3       
,'ResponsableNombre'=ISNULL(U.Nombre,'')              
,'UsuarioNombre'=ISNULL(UU.Nombre,'')                                                      
FROM HorarioSesion HS              
INNER JOIN Seccion S              
ON HS.IdSeccion=S.IdSeccion              
LEFT JOIN Promocion PRO                                  
ON S.IdPromocion=PRO.IdPromocion               
LEFT JOIN UnidadAcademica UA              
ON PRO.IdUnidadAcademica=UA.IdUnidadAcademica              
LEFT JOIN UnidadNegocio UN              
ON PRO.IdUnidadNegocio=UN.IdUnidadNegocio              
LEFT JOIN Separacion ST                                                    
ON HS.IdSeparacion=ST.IdSeparacion              
LEFT JOIN Usuario U                                      
ON ST.IdUsuario=U.IdUsuario                                                              
LEFT JOIN Actor AA              
ON ISNULL(HS.IdActorReemplazo,HS.IdActorProgramado)=AA.IdActor              
LEFT JOIN Curso C                                                                  
ON S.IdCurso=C.IdCurso                                                                  
INNER JOIN Ambiente A                                                                  
ON HS.IdAmbiente=A.IdAmbiente              
INNER JOIN Sede SE            
ON A.IdSede =  SE.IdSede                               
INNER JOIN Usuario UU                                  
ON HS.UsuarioModificacion=UU.IdUsuario              
WHERE CONVERT(VARCHAR(8),HS.Fecha,112)=CONVERT(VARCHAR(8),convert(date,@Fecha),112)   --@2          
AND (                                    
HS.Inicio BETWEEN @Inicio AND @Fin OR                        
HS.Fin BETWEEN @Inicio AND @Fin OR                                     
@Inicio BETWEEN HS.Inicio AND HS.Fin OR                                     
@Fin BETWEEN HS.Inicio AND HS.Fin)                                 
AND HS.IdAmbiente=@IdAmbientePrincipal                              
AND HS.EsPostergado=0             
AND (HS.Estado <> 'E' OR HS.Estado <> 'A')                             
UNION--de los hijos                              
SELECT HS.IdSesion                                    
,'SeccionCodigo'=S.Codigo                                                     
,'CursoNombre'=ISNULL(C.CursoNombre,'')              
,'SeparacionAsunto'=ISNULL(ST.Asunto,'')              
,PRO.PromocionCodigo                                  
,PRO.PromocionNombre                 
,'UnidadNegocioNombre'=UN.Nombre              
,'UnidadAcademicaNombre'=UA.Nombre              
,'AmbienteCodigo'=A.Codigo                                                                  
,'AmbienteNombre'=A.Nombre             
,'SedeNombre'=SE.Nombre             
,'ActorNombreCompleto'=ISNULL(AA.NombreCompleto,'')              
,'SeccionFechaInicio'=ISNULL(CONVERT(VARCHAR(10),S.FechaInicio,103),'')     --@2                                                             
,'SeccionFechaFin'=ISNULL(CONVERT(VARCHAR(10),S.FechaFin,103),'')                --@2
,HS.Inicio                  
,HS.Fin                  
,ISNULL(HS.EsSeparacion, 0) AS 'EsSeparacion'    --@3           
,'ResponsableNombre'=ISNULL(U.Nombre,'')              
,'UsuarioNombre'=ISNULL(UU.Nombre,'')                                                      
FROM HorarioSesion HS              
INNER JOIN Seccion S              
ON HS.IdSeccion=S.IdSeccion              
LEFT JOIN Promocion PRO                                  
ON S.IdPromocion=PRO.IdPromocion               
LEFT JOIN UnidadAcademica UA              
ON PRO.IdUnidadAcademica=UA.IdUnidadAcademica              
LEFT JOIN UnidadNegocio UN              
ON PRO.IdUnidadNegocio=UN.IdUnidadNegocio              
LEFT JOIN Separacion ST                                                    
ON HS.IdSeparacion=ST.IdSeparacion              
LEFT JOIN Usuario U                                      
ON ST.IdUsuario=U.IdUsuario                                                              
LEFT JOIN Actor AA              
ON ISNULL(HS.IdActorReemplazo,HS.IdActorProgramado)=AA.IdActor              
LEFT JOIN Curso C                                      
ON S.IdCurso=C.IdCurso                                                                  
INNER JOIN Ambiente A                                                                  
ON HS.IdAmbiente=A.IdAmbiente            
INNER JOIN Sede SE            
ON A.IdSede =  SE.IdSede                                    
INNER JOIN Usuario UU                                  
ON HS.UsuarioModificacion=UU.IdUsuario              
WHERE CONVERT(VARCHAR(8),HS.Fecha,112)=CONVERT(VARCHAR(8),convert(date,@Fecha),112)    --@2     
AND (                                    
HS.Inicio BETWEEN @Inicio AND @Fin OR                        
HS.Fin BETWEEN @Inicio AND @Fin OR                                     
@Inicio BETWEEN HS.Inicio AND HS.Fin OR                                     
@Fin BETWEEN HS.Inicio AND HS.Fin)                                 
AND HS.IdAmbiente IN (SELECT IdAmbiente FROM Ambiente WHERE IdAmbientePrincipal=@IdAmbiente)                              
AND HS.EsPostergado=0           
AND (HS.Estado <> 'E' OR HS.Estado <> 'A')