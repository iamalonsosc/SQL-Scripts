UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714398
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714400
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714401
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714389
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714415
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714414
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714406
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714385
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714409
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714408
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714410
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714418
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714403
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714397
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714392
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714402
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714413
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714383
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LEGISLACIÓN LABORAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716035
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'GESTIÓN DE PERSONAS';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 718436
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'FUNDAMENTOS DEL INGLÉS';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 718436
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'GESTIÓN DE PERSONAS';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709088
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'FUNDAMENTOS DEL INGLÉS';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709088
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'GESTIÓN DE PERSONAS';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 714544
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'LOGISTICA INTERNACIONAL';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709448
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709473
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709461
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709447
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709451
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709446
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709459
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709467
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709462
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709469
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709452
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709460
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709471
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709472
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709464
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709466
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709470
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709455
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 709482
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 715016
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 715016
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 715113
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716449
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716447
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716454
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716441
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716455
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716445
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716442
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716453
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716438
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716446
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716457
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716439
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716444
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716451
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716440
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'DESARROLLO DE HABILIDADES INTERPERSONALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 711100
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 715127
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 715123
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716462
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 715146
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716466
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716469
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716473
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716471
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716472
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
 FROM AlumnoCurso AC
 INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
 INNER JOIN AlumnoCurriculaCurso ACC 
 ON ACC.IdAlumno = AC.IdAlumno 
 AND ACC.IdCurso = AC.IdCurso 
 AND ACC.IdCurricula = AC.IdCurricula
 WHERE AC.IdMatricula = 716460
 AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';