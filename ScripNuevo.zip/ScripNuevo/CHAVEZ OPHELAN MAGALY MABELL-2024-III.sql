--DECLARE @IdMatriculaAntigua INT=648022,@IdAlumno INT=1262154,@IdMatriculaNueva INT

UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (648022)


--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL,IdConvalidacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10566 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL,IdConvalidacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=9848 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL,IdConvalidacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10539 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL,IdConvalidacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10565 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL,IdConvalidacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10572 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL,IdConvalidacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10550 AND IdCurricula=5614


UPDATE AlumnoCurso SET IdCursoOriginal=10550
WHERE IdMatricula=611220 AND IdCurso=10577


SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1262154 
AND  AC.IdMatricula=648022
--AND AC.IdCurso=13514
order by ac.idregistro,ac.IdAlumnoCurso desc


--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=88
WHERE IdMatricula=787678 AND IdCurso=10572
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=89
WHERE IdMatricula=787678 AND IdCurso=10566
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=90
WHERE IdMatricula=787678 AND IdCurso=10565
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=91
WHERE IdMatricula=787678 AND IdCurso=10550
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=92
WHERE IdMatricula=787678 AND IdCurso=10539
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=93
WHERE IdMatricula=787678 AND IdCurso=9848
--(1 fila afectada)



--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=12,IdcurriculaOriginal=5614
WHERE IdMatricula=648022  AND IdCurso=10572

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=13,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=648022 AND IdCurso=10566

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=14,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=648022 AND IdCurso=10565

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=15,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=648022 AND IdCurso=10550

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=16,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=648022 AND IdCurso=13436

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=17,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=648022 AND IdCurso=9848



--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='15.00',PromedioReal='15.12',IdAlumnoCurso=12,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10572 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='14.00',PromedioReal='13.56',IdAlumnoCurso=13,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10566 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='19.00',PromedioReal='19.08',IdAlumnoCurso=14,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10565 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='18.00',PromedioReal='18.24',IdAlumnoCurso=15,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10550 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='19.00',PromedioReal='19.00',IdAlumnoCurso=16,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10539 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='15.00',PromedioReal='15.36',IdAlumnoCurso=17,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=9848 AND IdCurricula=5614

--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=4,IdCurricula=5614
WHERE IdMatricula=648022

-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO
UPDATE Matricula SET Estado='X'
WHERE IdMatricula=787678


UPDATE AlumnoCurso SET IdCursoOriginal=NULL
WHERE IdMatricula=611220 AND IdCurso=10577