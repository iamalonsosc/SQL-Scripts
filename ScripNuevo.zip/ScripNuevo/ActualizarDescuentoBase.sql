--SELECT*FROM DescuentoAcademicoBase WHERE NumeroIdentidad IN ('76086468','75014889')

UPDATE DescuentoAcademicoBase SET PeriodoCodigo='2024-IIA'
WHERE NumeroIdentidad IN ('76086468','75014889')
AND IdMaestroRegistro=47096
--(2 rows affected)