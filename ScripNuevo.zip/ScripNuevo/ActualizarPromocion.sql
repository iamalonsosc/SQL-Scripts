--SELECT estado,*fROM MATRICULA 
update Matricula set IdPromocion=98657
WHERE IDMATRICULA=680158
--select*from Promocion where IdPromocion=99128