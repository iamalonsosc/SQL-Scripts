ALTER PROCEDURE [dbo].[COp_InterfaseImportar]
--@01 bgaribay 12-04-2019  para que no actualice a empelados
--@02 Ealva 20-03-2020  Se actualiza TipoRegistro='U' si existe en personamast.
--@03  bgaribay 17-08-2021  se adicona correo de jcure y jmota
--@04  ehuillca 24-01-2022  Se comenta env�o de correos
--@05  EHuillca 14.02.2022	Se descomenta env�o de correos y se cambia destinatario de idat
--@06  Illosa   04-04-2022  Se valida como vacio cuando el campo p.EsEmpleado es null
--@07 Joel Chaccha 08-04-2022 Inclusi�n de parametro de Persona
--@08	ILOPEZ	20.03.2024	SE OPTIMIZA EL SP PASANDO DE TABLA TEMPORAL A TABLA VARIABLE PARA NO GENERAR BLOQUEOS
--@09	JMOTA	17.05.2024	se realiza envio de correo por compa�iasocio
--DECLARE
   @pPersonaCodigo int = 0
AS
BEGIN
   SET NOCOUNT ON
   SET XACT_ABORT ON

	DECLARE @vFilasConsultadas int,
	@vFilasError INT,
	@vFila int,
	@vCodigoPostal varchar(20),
	@vid int,
	@vCodigoPostalDato varchar(3),
	@vProvincia varchar(3),
	@vDepartamento varchar(3),
	@vPersona int,
	@vBodyEmail varchar(max),
	@vMensaje varchar(400),
	--VARIABLES DEL PROCESO DE IMPORTACION
	@w_nuevo int, 
	@w_result int,
	@w_cliente int,
	@w_linea int, 
	@w_line int, 
	@k int, 
	@w_total_registros int, 
	@w_docvendedo int,
	@w_count int,
	@w_doctipodoc varchar(2), 
	@w_doctipofac varchar(10), 
	@w_doctipovta varchar(10), 
	@w_docconcept varchar(10), 
	@w_docforfact varchar(10), 
	@w_docforpa varchar(10),
	@w_monto decimal,
	--OTRAS VARIABLES
	@vErrorNumber int,
	@vErrorLine int,
	@vErrorMessage varchar(300),
	@vStoredProcedure varchar(300),
	--VARIABLES DE LA TABLA TEMPORAL
	@PersonaCodigo VARCHAR(20),
	@ApellidoPaterno char(20) ,
	@ApellidoMaterno char(20) ,
	@Nombres char(20) ,
	@NombreCompleto char(65) ,
	@Busqueda char(50) ,
	@TipoDocumento char(1) ,
	@Documento char(20) ,
	@TipoPersona char(1) ,
	@FechaNacimiento datetime,
	@CiudadNacimiento char(20) ,
	@Sexo char(1) ,
	@Nacionalidad char(20) ,
	@Direccion varchar(80) ,
	@CodigoPostal char(3) ,
	@Provincia char(3) ,
	@Departamento char(3) ,
	@Telefono varchar(15) ,
	@Fax varchar(15) ,
	@Documentofiscal char(20) ,
	@DocumentoIdentidad char(20) ,
	@CarnetExtranjeria char(10) ,
	@CorreoElectronico varchar(50) ,
	@ingresofecharegistro datetime,
	@Celular char(15) ,
	@Procesado char(2) ,
	@DocumentoFactura char(15) ,
	@TipoDocumentoCO char(2) ,
	@TipoRegistro char(1) ,
	@ErrorFlag char(1),
	@w_Persona int, 
	@w_PersonaDesde int, 
	@w_PersonaHasta int, 
	@PersonaActual INT,
	@Id_Registro int,
	@Linea int,
	@Descripcion varchar(350) ,
	@CompaniaSocio VARCHAR(8)

   DECLARE @tmpPersonaInterfase Table 
   (
      Id_Registro int identity(1,1),
      id int,
      personacodigo int,
      apellidopaterno char(20) Collate DataBase_Default,
      apellidomaterno char(20) Collate DataBase_Default,
      nombres char(20) Collate DataBase_Default,
      nombrecompleto char(65) Collate DataBase_Default,
      busqueda char(50) Collate DataBase_Default,
      TipoDocumento char(1) Collate DataBase_Default,
      Documento char(20) Collate DataBase_Default,
      TipoPersona char(1) Collate DataBase_Default,
      FechaNacimiento datetime,
      CiudadNacimiento char(20) Collate DataBase_Default,
      Sexo char(1) Collate DataBase_Default,
      Nacionalidad char(20) Collate DataBase_Default,
      Direccion varchar(80) Collate DataBase_Default,
      CodigoPostal char(3) Collate DataBase_Default,
      Provincia char(3) Collate DataBase_Default,
      Departamento char(3) Collate DataBase_Default,
      Telefono varchar(15) Collate DataBase_Default,
      Fax varchar(15) Collate DataBase_Default,
      Documentofiscal char(20) Collate DataBase_Default,
      DocumentoIdentidad char(20) Collate DataBase_Default,
      CarnetExtranjeria char(10) Collate DataBase_Default,
      CorreoElectronico varchar(50) Collate DataBase_Default,
      ingresofecharegistro datetime,
      Celular char(15) Collate DataBase_Default,
      Procesado char(2) Collate DataBase_Default,
      DocumentoFactura char(15) Collate DataBase_Default,
      TipoDocumentoCO char(2) Collate DataBase_Default,
      TipoRegistro char(1) Collate DataBase_Default,
      ErrorFlag char(1) Collate DataBase_Default,
	  CompaniaSocio char(8) Collate DataBase_Default
   )

   DECLARE @tmpErroresCliente Table 
   (
      Id_Registro int identity(1,1),
      Documento varchar(100) Collate DataBase_Default,
      Linea int,
      Descripcion varchar(350) Collate DataBase_Default,
	  CompaniaSocio char(8) Collate DataBase_Default
   )

   DECLARE @tmpCompanias table
   (
      Id_Registro int identity(1,1),      
      CompaniaSocio char(8) Collate DataBase_Default,
      Correo varchar(100) Collate DataBase_Default
   )

   
      Insert Into @tmpCompanias
      (
         CompaniaSocio, Correo
      )
      Select '00002500', 'mejoracontinuazegel@inlearning.pe' Union All
	  Select '00002600', 'mejoracontinuazegel@inlearning.pe' Union All
	  Select '00002700', 'mejoracontinuaidat@inlearning.pe' Union All -- idat
	  Select '00002800', 'mejoracontinuazegel@inlearning.pe' --@7

	Set @vFilasConsultadas = 0
	Set @vFila = 1
	Set @vBodyEmail = ''
	Set @vMensaje = ''

	Update PII 
	Set TipoRegistro='U' 
	FROM PersonaMast  PM WITH(NoLock) 
	INNER JOIN Persona_Inter PII WITH(NoLock)  ON PM.Documento=PII.Documento
	where PII.Procesado='NO' --@2
 
	--BEGIN TRANSACTION;   
	--BEGIN TRY    

      --Extraemos todos las personas de interface que no han sido procesadas
		Insert Into @tmpPersonaInterfase
		(
		id, personacodigo, apellidopaterno, apellidomaterno, nombres, nombrecompleto, busqueda, TipoDocumento, Documento, TipoPersona,
		fechanacimiento, CiudadNacimiento, Sexo, Nacionalidad, Direccion, CodigoPostal, Provincia, Departamento, Telefono, Fax,
		Documentofiscal, DocumentoIdentidad, CarnetExtranjeria, CorreoElectronico, ingresofecharegistro, Celular, Procesado,
		DocumentoFactura, TipoDocumentoCO, TipoRegistro, ErrorFlag , CompaniaSocio
		)
		Select Id, personacodigo, apellidopaterno, apellidomaterno, nombres, nombrecompleto, busqueda, TipoDocumento, Documento, TipoPersona,
		Fechanacimiento, CiudadNacimiento, Sexo, Nacionalidad, Direccion, CodigoPostal, Provincia, Departamento, Telefono, Fax,
		DocumentoFiscal, DocumentoIdentidad, CarnetExtranjeria, 
		Case 
			When CorreoElectronico Is null Or RTrim(CorreoElectronico) = ''  Then 'cobranzas@zegelipae.edu.pe'
			When CHARINDEX(';', CorreoElectronico) <> 0 Then  LEFT(CorreoElectronico, CHARINDEX(';', CorreoElectronico)-1)
			Else CorreoElectronico
		End As CorreoElectronico, 
		ingresofecharegistro, Celular, Procesado,DocumentoFactura, TipoDocumentoCO, TipoRegistro, '' as ErrorFlag  , Empresa   
		From Persona_inter With (NoLock)    
		Where PersonaCodigo = Case When @pPersonaCodigo = 0 Then PersonaCodigo Else @pPersonaCodigo End 
		And Procesado = 'NO'
		--AND id IN (1015587,1015588)

		Set @vFilasConsultadas = @@RowCount      

		--Si hay registrso que procesar entonces se hace la Extracci�n de parametros
		IF @vFilasConsultadas>0
		BEGIN
			--Extracci�n de parametros
			SELECT @w_doctipodoc = Texto 
			FROM ParametrosMast with(NoLock) 
			WHERE ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
			( ParametrosMast.AplicacionCodigo ='CO' ) AND 
			( ParametrosMast.ParametroClave ='DOCTIPODOC' ) 

			SELECT @w_doctipofac = Texto
			FROM ParametrosMast with(NoLock) 
			WHERE ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
			( ParametrosMast.AplicacionCodigo ='CO' ) AND 
			( ParametrosMast.ParametroClave ='DOCTIPOFAC' ) 

			SELECT @w_doctipovta = Texto
			FROM ParametrosMast with(NoLock) 
			WHERE ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
			( ParametrosMast.AplicacionCodigo ='CO' ) AND 
			( ParametrosMast.ParametroClave ='DOCTIPOVTA' ) 

			SELECT @w_docconcept = Texto
			FROM ParametrosMast with(NoLock) 
			WHERE ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
			( ParametrosMast.AplicacionCodigo ='CO' ) AND 
			( ParametrosMast.ParametroClave ='DOCCONCEPT' ) 

			SELECT @w_docvendedo = Numero 
			FROM ParametrosMast with(NoLock) 
			WHERE ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
			( ParametrosMast.AplicacionCodigo ='CO' ) AND 
			( ParametrosMast.ParametroClave ='DOCVE�NDEDO' ) 

			SELECT @w_docforfact = Texto
			FROM ParametrosMast with(NoLock) 
			WHERE ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
			( ParametrosMast.AplicacionCodigo ='CO' ) AND 
			( ParametrosMast.ParametroClave ='DOCFORFACT' ) 

			SELECT @w_docforpa = Texto
			FROM ParametrosMast with(NoLock) 
			WHERE ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
			( ParametrosMast.AplicacionCodigo ='CO' ) AND 
			( ParametrosMast.ParametroClave ='DOCFORPA' ) 
		END
   
		--Validar que los datos consultados no presenten inconsistencias
		WHILE (@vFila <= @vFilasConsultadas)
		BEGIN

			SET @PersonaCodigo = NULL
			SET @ErrorFlag = NULL
			SET @TipoRegistro=NULL
			SET @IngresoFechaRegistro=NULL
			SET @TipoPersona=NULL
			SET @Busqueda=NULL
			SET @NombreCompleto=NULL
			SET @ApellidoPaterno=NULL
			SET @ApellidoMaterno=NULL
			SET @Nombres=NULL
			SET @Sexo=NULL
			SET @CorreoElectronico=NULL
			SET @Direccion=NULL
			SET @Departamento=NULL
			SET @Provincia=NULL
			SET @CodigoPostal=NULL
			SET @FechaNacimiento=NULL
			SET @Telefono=NULL
			SET @Celular=NULL
			SET @Fax=NULL
			SET @TipoDocumento=NULL
			SET @Documento=NULL
			SET @TipoDocumentoCO=NULL
			SET @DocumentoFiscal=NULL
			SET @DocumentoIdentidad=NULL
			SET @CarnetExtranjeria=NULL
			SET @Nacionalidad=NULL
			SET @CompaniaSocio=NULL

			Select @vid = id,
			@PersonaCodigo = Convert(varchar(20), PersonaCodigo),
			@ErrorFlag=ErrorFlag,
			@TipoRegistro=TipoRegistro,
			@IngresoFechaRegistro=IngresoFechaRegistro,
			@TipoPersona=TipoPersona,
			@Busqueda=Busqueda,
			@NombreCompleto=NombreCompleto,
			@ApellidoPaterno=ApellidoPaterno,
			@ApellidoMaterno=ApellidoMaterno,
			@Nombres=Nombres,
			@Sexo=Sexo,
			@CorreoElectronico=CorreoElectronico,
			@Direccion=Direccion,
			@Departamento=Departamento,
			@Provincia=Provincia,
			@CodigoPostal=CodigoPostal,
			@FechaNacimiento=FechaNacimiento,
			@Telefono=Telefono,
			@Celular=Celular,
			@Fax=Fax,
			@TipoDocumento=TipoDocumento,
			@Documento=Documento,
			@TipoDocumentoCO=TipoDocumentoCO,
			@DocumentoFiscal=DocumentoFiscal,
			@DocumentoIdentidad=DocumentoIdentidad,
			@CarnetExtranjeria=CarnetExtranjeria,
			@Nacionalidad=Nacionalidad,
			@CompaniaSocio=CompaniaSocio
			From @tmpPersonaInterfase
			Where Id_Registro = @vFila
			
			Set @vCodigoPostal = Null
			Set @vCodigoPostalDato = ''
			Set @vProvincia = ''
			Set @vDepartamento = ''
			SET @ErrorFlag = 'N'

			--Verificamos si el campo PersonaCodi esta vacia o nula
			IF @PersonaCodigo Is Null
			BEGIN
				SET @ErrorFlag = 'S'
        		--Registrar el error
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion, CompaniaSocio
				)
				VALUES 
				(
				@PersonaCodigo, @vFila, 'Debe indicar el numero de Persona' , @CompaniaSocio
				)			
			END
			
			--Verificamos si el campo NombreCompleto esta vacia o nula
			IF (@NombreCompleto Is Null Or RTrim(@NombreCompleto) = '')
			BEGIN
				SET @ErrorFlag = 'S'
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion,CompaniaSocio
				)
				VALUES
				(
				@PersonaCodigo, @vFila, 'Debe indicar el Nombre Completo' , @CompaniaSocio
				)
			END
			
			--Verificamos si el campo Busqueda esta vacia o nula
			IF (@Busqueda Is Null Or RTrim(@Busqueda) = '')
			BEGIN
				SET @ErrorFlag = 'S'
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion,CompaniaSocio
				)
				VALUES
				(
				@PersonaCodigo, @vFila, 'Debe indicar el Nombre de B�squeda' , @CompaniaSocio
				)
			END

			--Verificamos si el campo TipoDocumento esta dentro del ran
			IF @TipoDocumento NOT IN ('D', 'R', 'M', 'X', 'P', 'N', 'O', 'E')
			BEGIN
				SET @ErrorFlag = 'S'
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion,CompaniaSocio
				)
				VALUES
				(
				@PersonaCodigo, @vFila, 'El Tipo de Documento no es v�lido' , @CompaniaSocio
				)
			END

			--Verificamos si el campo Documento esta vacia o nula
			IF (@Documento Is Null Or RTrim(@Documento) = '')
			BEGIN
				Set @ErrorFlag = 'S'
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion , CompaniaSocio
				)
				VALUES
				(
				@PersonaCodigo, @vFila, 'Debe indicar el N�mero de Documento' , @CompaniaSocio
				)
			END

			--Verificamos si el campo TipoPersona esta dentro del ran
			IF @TipoPersona Not In ('N', 'J', 'B')
			BEGIN
				Set @ErrorFlag = 'S'
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion, CompaniaSocio
				)
				VALUES
				(
				@PersonaCodigo, @vFila, 'El Tipo de Persona no es v�lido', @CompaniaSocio
				)
			END
			
			--Verificamos si el campo TipoPersona es J
			IF @TipoPersona != 'J'
			BEGIN

				--Verificamos si el campo Sexo 
				IF @Sexo Not In ('M', 'F')
				BEGIN
					SET @ErrorFlag = 'S'
					Insert Into @tmpErroresCliente
					(
					Documento, Linea, Descripcion, CompaniaSocio
					)
					VALUES
					(
					@PersonaCodigo, @vFila, 'El Sexo no es v�lido', @CompaniaSocio
					)
				END

				--Verificamos si el campo ApellidoPaterno esta vacia o nula
				IF (@ApellidoPaterno Is Null Or RTrim(@ApellidoPaterno) = '')
				BEGIN
					Set @ErrorFlag = 'S'
					Insert Into @tmpErroresCliente
					(
					Documento, Linea, Descripcion , CompaniaSocio
					)
					VALUES
					( 
					@PersonaCodigo, @vFila, 'Debe indicar el Apellido Paterno', @CompaniaSocio
					)
				END

				--Verificamos si el campo Nombres esta vacia o nula
				IF(@Nombres Is Null Or RTrim(@Nombres) = '')
				BEGIN
					Set @ErrorFlag = 'S'
					Insert Into @tmpErroresCliente
					(
					Documento, Linea, Descripcion , CompaniaSocio
					)
					VALUES
					( 
					@PersonaCodigo, @vFila, 'Debe indicar los Nombres', @CompaniaSocio
					)
				END
			END

			--Verificamos si el campo DocumentoIdentidad esta vacia o nula
			IF (@DocumentoIdentidad Is Null Or RTrim(@DocumentoIdentidad) = '')
			BEGIN
				Set @ErrorFlag = 'S'
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion, CompaniaSocio
				)
				VALUES
				(
				@PersonaCodigo, @vFila, 'Debe indicar el Doc de Identidad', @CompaniaSocio
				)
			END

			--Verificamos si el campo DocumentoFiscal esta vacia o nula
			IF (@DocumentoFiscal Is Null Or RTrim(@DocumentoFiscal) = '')
			BEGIN
				Set @ErrorFlag = 'S'
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion, CompaniaSocio
				)
				VALUES
				(
				@PersonaCodigo, @vFila, 'Debe indicar el Doc Fiscal', @CompaniaSocio
				)
			END

			--Verificamos si el campo TipoDocumentoCO esta vacia o nula
			IF (@TipoDocumentoCO Is Null Or RTrim(@TipoDocumentoCO) = '')
			BEGIN
				Set @ErrorFlag = 'S'
				Insert Into @tmpErroresCliente
				(
				Documento, Linea, Descripcion, CompaniaSocio
				)
				VALUES
				(
				@PersonaCodigo, @vFila, 'Ingrese el Tipo de Documento Comercial', @CompaniaSocio
				)
			END
			ELSE
			BEGIN
				--Verificamos si el tipo de Documento es un Documento de tipo comercial
				IF NOT EXISTS (	SELECT 1
								FROM CO_TipoDocumento a
								WHERE a.TipoDocumento = @TipoDocumentoCO
								AND a.Estado = 'A')
				BEGIN
					Set @ErrorFlag = 'S'
					Insert Into @tmpErroresCliente
					(
					Documento, Linea, Descripcion, CompaniaSocio
					)
					VALUES
					(
					@PersonaCodigo, @vFila, 'El Tipo de Documento (Comercial) no es v�lido: ' + @TipoDocumentoCO ,  @CompaniaSocio
					)
				END
			END

			--Verificamos si el TipoRegistro es 'U' Update
			IF @TipoRegistro = 'U'
			BEGIN
				IF NOT EXISTS (	SELECT 1
								FROM PersonaMast a
								WHERE a.PersonaAnt = Convert(varchar(20), @PersonaCodigo)
								AND a.Estado = 'A') 
				BEGIN
					If NOT EXISTS(	SELECT 1
									FROM PersonaMast a
									WHERE a.Documento = @Documento
									AND a.Estado = 'A') 
					BEGIN
						Set @ErrorFlag = 'S'
						Insert Into @tmpErroresCliente
						(
						Documento, Linea, Descripcion, CompaniaSocio
						)
						VALUES
						(
						@PersonaCodigo, @vFila, 'El Cliente no es v�lido: ' + Convert(Varchar(20), @PersonaCodigo),  @CompaniaSocio
						)
					END
					ELSE
					BEGIN
						--Se actualiza el PersonaAnt de PersonaMast
						Update PersonaMast
						Set PersonaAnt = Convert(varchar(20), @PersonaCodigo)
						FROM PersonaMast a
						WHERE a.Documento = @Documento
					END
				END
			END

			--Verifica si el registro no tiene errores
			IF @ErrorFlag = 'N' AND EXISTS (Select 1
											From Persona_inter With (NoLock)    
											Where PersonaCodigo = @PersonaCodigo 
											And Procesado = 'NO') 
			BEGIN
				--Se procede a realizar el proceso de IMPORTACION
				IF @TipoRegistro = 'I' AND EXISTS (	SELECT 1 
													From PersonaMast with(NoLock) 
													Where PersonaAnt = @PersonaCodigo)
				BEGIN
					Set @TipoRegistro = 'U'			
				END

				--Verificar si el tipo de registro es U de Update
				IF @TipoRegistro = 'U'
				BEGIN
					SELECT @vPersona = Persona
					FROM PersonaMast WITH(NOLOCK) 
					WHERE PersonaAnt = @PersonaCodigo
					
					Update P
					Set p.EsCliente = 'S', 
					p.Estado = 'A', 
					p.IngresoFechaRegistro = @IngresoFechaRegistro, 
					p.IngresoAplicacionCodigo = 'CO', 
					p.IngresoUsuario =  'PERINTER2', 
					p.EstadoCivil = 'S',
					p.EnfermedadGraveFlag = 'N', 
					p.PYMEFlag = 'N', 
					p.UltimoUsuario = 'PERINTER2', 
					p.UltimaFechaModif = GetDate(), 
					p.TipoPersona = @TipoPersona, 
					p.Busqueda = @Busqueda, 
					p.NombreCompleto = @NombreCompleto, 
					p.ApellidoPaterno = @ApellidoPaterno, 
					p.ApellidoMaterno = @ApellidoMaterno, 
					p.Nombres = @Nombres, 
					p.Sexo = @Sexo, 
					p.CorreoElectronico = @CorreoElectronico,
					p.Direccion = @Direccion,
					p.CodigoPostal = Case IsNull(@Departamento + @Provincia + @CodigoPostal, '') When '' Then p.CodigoPostal Else @CodigoPostal End,
					p.Provincia = Case IsNull(@Departamento + @Provincia + @CodigoPostal, '') When '' Then p.Provincia Else @Provincia End,
					p.Departamento = Case IsNull(@Departamento + @Provincia + @CodigoPostal, '') When '' Then p.Departamento Else @Departamento End, 
					p.FechaNacimiento = @FechaNacimiento, 
					p.Telefono = @Telefono,
					p.TelefonoEmergencia = @Celular,
					p.Fax = @Fax,
					p.TipoDocumento = @TipoDocumento,
					p.Documento = @Documento,
					p.DocumentoFiscal = @DocumentoFiscal, 
					p.DocumentoIdentidad = @DocumentoIdentidad,
					p.CarnetExtranjeria = @CarnetExtranjeria,
					p.Origen = 'LIMA'
					From PersonaMast p
					Where  p.PersonaAnt = Convert(varchar(20), @PersonaCodigo)
					and IsNull(p.EsEmpleado,'')<>'S'   ---@01	--@06

					--Verificamos si el Cliente existe
					If EXISTS (	Select 1
								From ClienteMast
								Where Cliente = @vPersona)
					Begin
						--Actualiza los datos del cliente
						Update ClienteMast 
						Set TotalAcumulado = 0.00,
						IngresoMensual = 0.00,
						TipoActividad = 'I',
						PagoEfectivoFlag = 'N',
						PracticoTMCFlag = 'T',
						SuspensionFlag = 'N',
						Nacionalidad = 'N',
						Clasificacion = 'B',
						TipoDocumento = @w_doctipodoc,
						TipoFacturacion = @w_doctipofac,
						TipoVenta = @w_doctipovta,
						ConceptoFacturacion = @w_docconcept,
						Vendedor = @w_docvendedo,
						FormaFacturacion = @w_docforfact, 
						FormadePago = @w_docforpa, 
						FinanciamientoTasa = 0.00
						Where Cliente = @vPersona 
					End
					Else
					Begin
						--Se inserta un nuevo cliente
						Insert Into ClienteMast 
						( 
						Cliente, TotalAcumulado, IngresoMensual, TipoActividad, PagoEfectivoFlag, PracticoTMCFlag, SuspensionFlag, Nacionalidad, Clasificacion, 
						TipoDocumento, TipoFacturacion, TipoVenta, ConceptoFacturacion, Vendedor, FormaFacturacion, FormadePago, FinanciamientoTasa
						) 
						Values 
						( 
						@vPersona, 0.00, 0.00, 'I', 'N', 'T', 'N', 'N', 'B', @w_doctipodoc, @w_doctipofac, @w_doctipovta, @w_docconcept, @w_docvendedo, @w_docforfact, 
						@w_docforpa, 0.00
						)
					End
				END			
				ELSE
				BEGIN
					SET @w_Persona = Null 
					SET @w_PersonaDesde = 0 
					SET @w_PersonaHasta = 0 
					SET @PersonaActual =0
					
					IF EXISTS (	SELECT 1 
								FROM SY_UnidadReplicacion
								WHERE DescripcionLocal='SEE')
					BEGIN
						SELECT @PersonaActual=	CASE 
													WHEN PersonaActual % 2 = 0 THEN PersonaActual+2
													ELSE PersonaActual+3 
												END 
						FROM SY_UnidadReplicacion
						WHERE UnidadReplicacion = 'LIMA'

					END
					ELSE
					BEGIN
						SELECT  @PersonaActual=	CASE 
													WHEN PersonaActual % 2 = 1 THEN PersonaActual+2
													ELSE PersonaActual+3 
												END 
						FROM SY_UnidadReplicacion
						WHERE UnidadReplicacion = 'LIMA'
					END

					--Se actualiza el nuevo correlativo
					Update SY_UnidadReplicacion 
					SET PersonaActualImp = @PersonaActual,
					PersonaActual = @PersonaActual,
					UltimoUsuario = 'PERINTER2', 
					UltimaFechaModif = GetDate()
					WHERE UnidadReplicacion = 'LIMA' 

					--Se extrae los correlativos de personaMast
					SELECT @w_Persona = PersonaActualImp, 
					@w_PersonaDesde = RangoPersonaInicio, 
					@w_PersonaHasta = RangoPersonaFin 
					FROM SY_UnidadReplicacion With (NoLock)
					WHERE SY_UnidadReplicacion.UnidadReplicacion = 'LIMA'

					--Se verifica si el correlativo es valido
					If (@w_Persona Is Null) 
						Set @w_Persona = 0

					If (@w_Persona >= @w_PersonaHasta)
						Set @w_Persona = -1
					Else
						Set @w_Persona = @w_Persona -- + 2

					--Se genera un nuevo Cliente en PersonaMast
					Insert Into PersonaMast
					(
					Persona, EsCliente, EsProveedor, EsEmpleado, EsOtro, Estado, IngresoFechaRegistro, IngresoAplicacionCodigo, IngresoUsuario, EstadoCivil,
					EnfermedadGraveFlag, PYMEFlag, UltimoUsuario, UltimaFechaModif, TipoPersona, Busqueda, NombreCompleto, ApellidoPaterno, ApellidoMaterno, 
					Nombres, Sexo, CorreoElectronico, Direccion, CodigoPostal, Provincia, Departamento, FechaNacimiento, Telefono, TelefonoEmergencia,
					Fax, TipoDocumento, Documento, DocumentoFiscal, DocumentoIdentidad, CarnetExtranjeria, PersonaAnt, Origen, CorreoElectronicoFE, Nacionalidad
					)
					Select @w_Persona, 'S', 'N', 'N', 'N', 'A',@IngresoFechaRegistro, 'CO', 'PERINTER2', 'S', 'N', 'N', 'PERINTER2', GetDate(), @TipoPersona, @Busqueda, @NombreCompleto,
					@ApellidoPaterno, @ApellidoMaterno, @Nombres, @Sexo, @CorreoElectronico, @Direccion, @CodigoPostal, @Provincia, @Departamento, @FechaNacimiento, 
					@Telefono, @Celular, @Fax, @TipoDocumento, @Documento, @DocumentoFiscal, @DocumentoIdentidad, @CarnetExtranjeria, Convert(Varchar(15), @PersonaCodigo),
					'LIMA', @CorreoElectronico, @Nacionalidad
                 
					--Inserta el ClienteMast
					INSERT INTO ClienteMast 
					( 
					Cliente, TotalAcumulado, IngresoMensual, TipoActividad, PagoEfectivoFlag, PracticoTMCFlag, SuspensionFlag, Nacionalidad, Clasificacion, 
					TipoDocumento, TipoFacturacion, TipoVenta, ConceptoFacturacion, Vendedor, FormaFacturacion, FormadePago, FinanciamientoTasa
					) 
					VALUES 
					( 
					@w_Persona, 0.00, 0.00, 'I', 'N', 'T', 'N', 'N', 'B', @w_doctipodoc, @w_doctipofac, @w_doctipovta, @w_docconcept, @w_docvendedo, @w_docforfact, 
					@w_docforpa, 0.00
					)
				END	
    
				--Registro Procesado
				Update persona_inter
				Set Procesado = 'SI', 
				FechaProcesoImp = GetDate()
				Where Id = @vid
			End

			Update @tmpPersonaInterfase
			Set ErrorFlag = @ErrorFlag,
			TipoRegistro = @TipoRegistro
			Where Id_Registro = @vFila
			
			Set @vFila = @vFila + 1
		End

 		Select @vFilasError = COUNT(1) 
		From @tmpErroresCliente
  
		--Se verifica si existen errores para el envio del correo
		If (@vFilasError > 0)
		Begin 
			Declare @vFilaCompania int , @vFilaCompaniaMax int   
			Declare @vCompaniaSocio char(8) , @vCorreo varchar(100)
				
			Set @vFilaCompania = 1

			select @vFilaCompaniaMax = MAX(Id_Registro) from @tmpCompanias

			While (@vFilaCompania <= @vFilaCompaniaMax)
			Begin

				SET @vCompaniaSocio = NULL
				SET @vCorreo = NULL
				Set @vFila = 1
				Set @vBodyEmail = ''

				Select @vCompaniaSocio = CompaniaSocio, @vCorreo = Correo 
				From @tmpCompanias
				Where Id_Registro = @vFilaCompania

				If (Select Count(*) From @tmpErroresCliente Where CompaniaSocio = @vCompaniaSocio) > 0
				Begin

					--Se devuelve todos los registros con errores
					Set @vBodyEmail = @vBodyEmail + '<html>'
					Set @vBodyEmail = @vBodyEmail + '<head>'            
					Set @vBodyEmail = @vBodyEmail + '<style type="text/css">'
					Set @vBodyEmail = @vBodyEmail + '.headGrid {'
					Set @vBodyEmail = @vBodyEmail + '	font-weight: bold;'
					Set @vBodyEmail = @vBodyEmail + '	font-size: 11px; '
					Set @vBodyEmail = @vBodyEmail + '	color: #FFFFFF; '
					Set @vBodyEmail = @vBodyEmail + '	font-family: Tahoma, Microsoft Sans Serif; '    
					Set @vBodyEmail = @vBodyEmail + '	background-color: #539AC8;         '            
					Set @vBodyEmail = @vBodyEmail + '}'
					Set @vBodyEmail = @vBodyEmail + '.itemGrid {'
					Set @vBodyEmail = @vBodyEmail + '	background-color: #F8F8F8;'
					Set @vBodyEmail = @vBodyEmail + '	font-size: 8pt; color: #000000; font-family: Arial, Microsoft Sans Serif;'
					Set @vBodyEmail = @vBodyEmail + '}'
					Set @vBodyEmail = @vBodyEmail + '.titulo {'
					Set @vBodyEmail = @vBodyEmail + '	font-weight: bold;'
					Set @vBodyEmail = @vBodyEmail + '	font-size: 12pt; color: #000000; font-family: Arial, Microsoft Sans Serif;'
					Set @vBodyEmail = @vBodyEmail + '}'
					Set @vBodyEmail = @vBodyEmail + '</style>'
					Set @vBodyEmail = @vBodyEmail + '</head>'
					Set @vBodyEmail = @vBodyEmail + '<body>'
					Set @vBodyEmail = @vBodyEmail + '<table style="width: 100%">'
					Set @vBodyEmail = @vBodyEmail + '<tr style="height: 20pt">'
					Set @vBodyEmail = @vBodyEmail + '<td class="titulo">&nbsp;'
					Set @vBodyEmail = @vBodyEmail + 'Lista de errores de importaci�n de Clientes'                
					Set @vBodyEmail = @vBodyEmail + '</td>'
					Set @vBodyEmail = @vBodyEmail + '</tr>'
					Set @vBodyEmail = @vBodyEmail + '</table>'
					Set @vBodyEmail = @vBodyEmail + '<br>'
					Set @vBodyEmail = @vBodyEmail + '<table border="1" style="width: 100%;" cellpadding="0" cellspacing="0">'
					Set @vBodyEmail = @vBodyEmail + '<tr>'
					Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Id</td>'
					Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Persona</td>'
					Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">L�nea</td>'
					Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Descripci�n</td>'
					Set @vBodyEmail = @vBodyEmail + '</tr>'
            
					Set @vFila = 1
					While (@vFila <= @vFilasError)
					Begin
				
						If Exists (Select 1
                                   From @tmpErroresCliente
                                   Where Id_Registro = @vFila And CompaniaSocio = @vCompaniaSocio)
                        Begin 

							SET @Id_Registro=NULL
							SET @Documento=''
							SET @Linea=NULL
							SET @Descripcion=''

							SELECT @Id_Registro=Id_Registro,
							@Documento=Documento,
							@Linea=Linea,
							@Descripcion=Descripcion
							From @tmpErroresCliente
							Where Id_Registro = @vFila

							Set @vBodyEmail = @vBodyEmail + '<tr>'
               
							SET @vBodyEmail = @vBodyEmail + 
									'<td align="center" class="itemGrid">' + Convert(varchar(7), @Id_Registro) + '</td>' + 
									'<td class="itemGrid">' + @Documento + '</td>' + 
									'<td align="center" class="itemGrid">' + Convert(varchar(7), @Linea) + '</td>' + 
									'<td class="itemGrid">' + @Descripcion + '</td>'
				
							Set @vBodyEmail = @vBodyEmail + '</tr>'

						end 

						Set @vFila = @vFila + 1
					End
             
					Set @vBodyEmail = @vBodyEmail + '</table>'
					Set @vBodyEmail = @vBodyEmail + '<br>'
					Set @vBodyEmail = @vBodyEmail + '<table style="width: 100%">'
					Set @vBodyEmail = @vBodyEmail + '<tr style="height: 20pt">'
					Set @vBodyEmail = @vBodyEmail + '<td style="font-size:  9pt;font-family: Tahoma, Microsoft Sans Serif; color: red;">&nbsp;'
					Set @vBodyEmail = @vBodyEmail + 'SEE'                
					Set @vBodyEmail = @vBodyEmail + '</td>'
					Set @vBodyEmail = @vBodyEmail + '</tr>'
					Set @vBodyEmail = @vBodyEmail + '</table>'
					Set @vBodyEmail = @vBodyEmail + '</body>'
					Set @vBodyEmail = @vBodyEmail + '</html>'

				   --@03
				   --SELECT @vCorreo , @vBodyEmail
					Exec msdb.dbo.sp_send_dbmail    --@5
					@recipients = @vCorreo, 
					@copy_recipients = 'bgaribay@inlearning.edu.pe',
					@profile_name = 'Interfase SEE',
					@subject = 'Errores de importaci�n PersonaInter -  PersonaMast',
					@body = @vBodyEmail,
					@body_format = 'HTML'

				end 

				Set @vFilaCompania = @vFilaCompania + 1 
			End
			
		End
 --  END TRY
 --  BEGIN CATCH
     
	--	----Se genero un error
	--	--SELECT ERROR_NUMBER() AS ErrorNumber,
	--	--ERROR_SEVERITY() AS ErrorSeverity,
	--	--ERROR_STATE() AS ErrorState,
	--	--ERROR_PROCEDURE() AS ErrorProcedure,
	--	--ERROR_LINE() AS ErrorLine,
	--	--ERROR_MESSAGE() AS ErrorMessage;
		
	--	--Select ''

	--	Set @vErrorNumber = ERROR_NUMBER()
	--	Set @vErrorLine = ERROR_LINE()
	--	Set @vErrorMessage = ERROR_MESSAGE()
	--	Set @vStoredProcedure = ERROR_PROCEDURE()
	--	Set @vMensaje = 'Numero de error: ' + Convert(varchar(15), @vErrorNumber) +  '  Linea de Error: ' + Convert(varchar(15), @vErrorLine) + '  Mensaje: ' + @vErrorMessage + '  Stored Procedure: ' + @vStoredProcedure

	--	IF @@TranCount > 0
	--		RollBack Transaction;

	--END CATCH;
   
	--If @@TranCount > 0
	--	Commit Transaction;

	IF EXISTS(select 1 Descripcion from @tmpErroresCliente where Documento=@pPersonaCodigo)
	BEGIN 
		SELECT TOP 1 Descripcion as Estado from @tmpErroresCliente where Documento=@pPersonaCodigo
	END
	ELSE 
	BEGIN 
		SELECT 'OK' AS Estado
	ENd
   
	--If Len(@vMensaje) > 0
	--BEGIN

	--	EXEC msdb.dbo.sp_send_dbmail   
	--	@recipients = 'bgaribay@zegelipae.edu.pe;mejoracontinuaidat@inlearning.edu.pe;jcure@inlearning.edu.pe',    
	--	@profile_name = 'Interfase SEE',            
	--	@subject = 'Error de ejecuci�n de importaci�n de Documentos - Paso 1',  
	--	@body = @vMensaje,   
	--	@body_format = 'HTML'

	--END

	Set NoCount Off
End



