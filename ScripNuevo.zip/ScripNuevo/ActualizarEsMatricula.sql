UPDATE AlumnoCurso SET EsMatricula=1
WHERE IdAlumno=1648748 AND IdCurso=13798