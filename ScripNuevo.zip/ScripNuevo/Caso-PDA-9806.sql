---  PDA 		9806
-- ELIMINAR ESTE USUARIO PORQUE TIENE DUPICADO 
DELETE FROM Permiso WHERE IdUsuario=118221
--(1 row affected)
DELETE FROM EVA_InformacionActor WHERE IdUsuario=118221
----(1 row affected)
DELETE FROM Alumno  WHERE IdAlumno  = 1245234
--(1 row affected)
DELETE FROM EVA_Usuario_Acceso WHERE IdUsuario=118221
--(1 row affected)
DELETE FROM Usuario where IdActor = 1245234
--(1 row affected)