--DECLARE @IdMatriculaAntigua INT=610357,@IdAlumno INT=1274900,@IdMatriculaNueva INT

UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (610357
,646328
,674076
,725019
,776707)

UPDATE Registro SET Estado='X'
WHERE IdActor=1274900 AND IdRegistro IN (2
,3
,4
,5)

UPDATE AlumnoCurricula SET Activo=0
WHERE IdAlumno=1274900 AND IdRegistro IN (2
,3
,4
,5)


--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1274900 AND IdRegistro=1 AND IdCurso=10517 AND IdCurricula=29

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1274900 AND IdRegistro=1 AND IdCurso=10515 AND IdCurricula=29


SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1274900-- and ac.IdMatricula=610357 and ac.IdRegistro=4 --AND AC.IdCurso=13514
order by ac.idregistro,ac.IdAlumnoCurso desc


--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
--SELECT*FROM AlumnoCurso 
--MATEM�TICA APLICADA  AL USO DE LAS TECNOLOG�AS
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=45
WHERE IdMatricula=783462 AND IdCurso=10517
--(1 fila afectada)
--FUNDAMENTOS DE BASE DE DATOS
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=46
WHERE IdMatricula=783462 AND IdCurso=10515
--(1 fila afectada)


--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=6,IdAlumnoCurso=4,IdcurriculaOriginal=5612
WHERE IdMatricula=610357 AND IdCurso=10517

UPDATE AlumnoCurso SET IdRegistro=6,IdAlumnoCurso=5,IdcurriculaOriginal=5612
WHERE IdMatricula=610357 AND IdCurso=10515



--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='19.00',PromedioReal='19.00',IdAlumnoCurso=4,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1274900 AND IdRegistro=6 AND IdCurso=10517 AND IdCurricula=5612


UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='18.00',PromedioReal='18.08',IdAlumnoCurso=5,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1274900 AND IdRegistro=6 AND IdCurso=10515 AND IdCurricula=5612


--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=6,IdCurricula=5612
WHERE IdMatricula=610357

UPDATE Matricula SET Estado='X'
WHERE IdMatricula=783462

UPDATE Matricula SET Estado='N'
WHERE IdMatricula IN (646328
,674076
,725019
,776707)

UPDATE Registro SET Estado='N'
WHERE IdActor=1274900 AND IdRegistro IN (2
,3
,4
,5)

UPDATE AlumnoCurricula SET Activo=1
WHERE IdAlumno=1274900 AND IdRegistro IN (2
,3
,4
,5)