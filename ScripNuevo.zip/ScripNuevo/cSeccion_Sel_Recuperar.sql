exec cSeccion_Sel_Recuperar @IdSeccion=651645

select Estado,*from Seccion

--UPDATE Seccion SET Estado='A'
--where idseccion=651645

Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  
-----------------------------------------------------------------------------  
--Creado por:  Carlos Huallpa(26/06/2006)      
--Modificado por: Luis Rodriguez(26/02/2009)      
--Funcionalidad : Recupera la informacion de una seccion      
--Utilizado por : Seccion.SelRecuperarLis      
-----------------------------------------------------------------------------  
/*      
-----------------------------------------------------------------------------      
Nro FECHAUSUARIODESCRIPCION      
-----------------------------------------------------------------------------      
@1 18.07.2011 ssalazar se agreg� un campo capacidad de ambiente      
@2 12.07.2012 psantiago se cambio el campo NoSesion ahora compara con el nuevo campo CursoSesion de la tabla seccion      
@3 16.09.2016 gguillen agregado inner join para traer unidadacademica      
@4 17.12.2019 EHuillca Se agrega nuevo campo      
@5 27.01.2020 PUchuya Se realiza cambios para Cursos libres      
@6 07.07.2020 PUchuya Se agregar parametro cursocredito y quita case      
@7 11.08.2020 gguillen Se agrega Numero de clase para IDAT      
@8 15.01.2020 ealva Se agrega validacion para Botonera de IDAT.    
@9 01.02.2021 puchuya Se agrega campo disponible2     
@10 07.03.2021 rpineda Se agrega campo disponible3 para delegado  
@11 13.04.2021 Jnavia  Se agrega WITH (NOLOCK)  
@12 25.01.2022 PUchuya  Se agrega campo tipo modalidad para diferencias clases presenciales y virtuales  
@13 07.08.2024 Lhualpa  Se agrega campo EsAsincronico para diferenciar clases asincronicas y sincronicas
@18 18.10.2024 rotorres Se obtienen las vacantes de la tabla seccion
*/  
CREATE PROCEDURE [dbo].[cSeccion_Sel_Recuperar]   
@IdSeccion INT  
AS  
BEGIN  
 SELECT S.IdSeccion  
  ,P.IdSede  
  ,'NombreSede' = SE.Nombre  
  ,S.IdPromocion  
  ,UA.IdUnidadAcademica --@3      
  ,UN.IdUnidadNegocio --@3      
  ,'UnidadAcademicaNombre' = UA.Nombre  
  ,'UnidadNegocioNombre' = UN.Nombre  
  ,'PromocionCodigo' = P.PromocionCodigo  
  ,'PromocionNombre' = P.PromocionNombre  
  ,'IdGrupo' = ISNULL(S.IdGrupo, - 1)  
  ,'PromocionGrupoCodigo' = ISNULL(PG.GrupoCodigo, '') --@5 --@6      
  ,S.Codigo  
  ,S.IdCurso  
  ,C.CursoNombre  
  ,'SinHorario' = ISNULL(S.SinHorario, 0)  
  ,'IdAmbiente' = ISNULL(S.IdAmbiente, - 1)  
  ,'AmbienteCodigo' = ISNULL(A.Codigo, '')  
  ,'AmbienteNombre' = ISNULL(A.Nombre, '')  
  ,'IdTurno' = ISNULL(S.IdTurno, - 1)  
  ,'TurnoNombre' = ISNULL(T.Nombre, '')  
  ,'IdDuracion' = ISNULL(S.IdDuracion, - 1)  
  ,'SesionDuracionNombre' = ISNULL(SS.Nombre, '')  
  ,'SesionDuracionMinuto' = ISNULL(SS.Minuto, 1)  
  ,'FechaInicio' = dbo.fecha(S.fechainicio)  
  ,'FechaFin' = dbo.fecha(S.fechafin)  
  ,'Vacantes' =s.vacantes
  --CASE ISNULL(S.IdGrupo, - 1)  
  -- WHEN - 1  
  --  THEN S.Vacantes  
  -- ELSE PG.Vacantes  
  -- END  
  ,'IdEvaluacion' = ISNULL(S.idevaluacion, - 1)  
  ,'EvaluacionCodigo' = ISNULL(E.Codigo, '')  
  ,'EvaluacionNombre' = ISNULL(E.Nombre, '')  
  ,S.EsLibre  
  ,S.EsVirtual  
  ,S.EsCalificable  
  ,'NoSesion' = ISNULL(ISNULL(S.CursoSesion, CC.CursoSesion), 0)  
  ,S.NoBloque  
  ,S.Estado  
  ,'EstadoNombre' = CASE S.estado  
   WHEN 'A'  
    THEN 'APERTURADO'  
   WHEN 'F'  
    THEN 'FINALIZADO'  
   END  
  ,'UsuarioCreacionFecha' = U.nombre + ' (' + dbo.fechahora(S.fechacreacion) + ')'  
  ,'UsuarioModificacionFecha' = UU.nombre + ' (' + dbo.fechahora(S.fechamodificacion) + ')'  
  --------------------------------------------------------------------------@1      
  ,'Capacidad' = ISNULL(A.Capacidad, 0)  
  ,'IdActor' = ISNULL(SP.IdActor, - 1)  
  ,'NombreCompleto' = ISNULL(AC.NombreCompleto, '')  
  ----------------------------------------------------------------------------      
  ,'Nombres' = ISNULL(AC.Nombres, '') --@3      
  ,'Paterno' = ISNULL(AC.Paterno, '') --@3      
  ,'Materno' = ISNULL(AC.Materno, '') --@3      
  ,'Es360' = ISNULL(S.Es360, 0) --@4      
  ,'CursoCredito' = ISNULL(S.CursoCredito, 0) --@6 --@9    
  ,'NumeroClase' = (  
   ISNULL((  
     SELECT TOP 1 IdCurso  
     FROM [MoodleMdlLocalIsmCursos_Idat] MM WITH (NOLOCK) --@11  
     WHERE MM.IdGrupo = PG.NumeroClase  
      AND MM.ShortNameCurso LIKE '%' + ISNULL((  
        SELECT TOP 1 anexo  
        FROM SEDE S WITH (NOLOCK) --@11  
        WHERE S.Codigo = (  
          SELECT Substring  
          FROM dbo.fnSeparadorCaracteres((  
             SELECT TOP 1 M.NumeroMatricula  
             FROM Matricula M WITH (NOLOCK) --@11  
             WHERE P.IdPromocion = M.IdPromocion  
             ), '|')  
          WHERE ID = 1  
          )  
        ) + S.NumeroClase, '-1')  
     ), '-1')  
   ) --@27     
  ,'ValBotonera' = CASE   
   WHEN P.IdPeriodoAnual >= 2021  
    OR P.IdUnidadNegocio = 2  
    THEN 1  
   ELSE 0  
   END --@8    
  ,'Disponible2' = ISNULL(S.Disponible2, '') --@9    
  ,'Disponible3' = isnull(S.disponible3, '') --@10  
  ,'SeccionProfesorProgramadoLogin' = ISNULL(F.CodigoAnterior, '')  
  ,'IdTipoModalidad' = ISNULL(S.IdTipoModalidad,-1) --@12  
  ,'EsAsincronico' = ISNULL(S.EsAsincronico,-1) --@13  
 FROM Seccion S WITH (NOLOCK)  
 INNER JOIN Promocion P WITH (NOLOCK)  
  ON P.IdPromocion = S.IdPromocion  
 LEFT JOIN PromocionGrupo PG WITH (NOLOCK)  
  ON PG.IdPromocion = S.IdPromocion  
   AND PG.IdGrupo = S.IdGrupo  
 INNER JOIN Sede SE WITH (NOLOCK)  
  ON SE.IdSede = P.IdSede  
 LEFT JOIN CurriculaCurso CC WITH (NOLOCK)  
  ON CC.IdCurricula = S.IdCurricula  
   AND CC.IdCurso = S.IdCurso  
 LEFT JOIN PromocionCurso PC WITH (NOLOCK)  
  ON PC.IdPromocion = S.IdPromocion  
   AND PC.IdCurso = S.IdCurso  
 INNER JOIN Curso C WITH (NOLOCK)  
  ON C.idcurso = S.idcurso  
 LEFT JOIN SesionDuracion SS WITH (NOLOCK)  
  ON SS.idduracion = S.idduracion  
 LEFT JOIN Ambiente A WITH (NOLOCK)  
  ON A.idambiente = S.idambiente  
 LEFT JOIN Turno T WITH (NOLOCK)  
  ON T.IdTurno = S.IdTurno  
 LEFT JOIN Evaluacion E WITH (NOLOCK)  
  ON E.idevaluacion = S.idevaluacion  
 INNER JOIN Usuario U WITH (NOLOCK)  
  ON U.idusuario = S.usuariocreacion  
 INNER JOIN Usuario UU WITH (NOLOCK)  
  ON UU.idusuario = S.usuariomodificacion  
 LEFT JOIN SeccionProfesor SP WITH (NOLOCK)  
  ON SP.IdSeccion = S.IdSeccion  
   AND SP.EsResponsable = 1  
   AND SP.Activo = 1  
 LEFT JOIN Actor AC WITH (NOLOCK)  
  ON AC.IdActor = SP.IdActor  
 LEFT JOIN Facilitador F WITH (NOLOCK)  
  ON F.IdFacilitador = SP.IdActor  
 INNER JOIN UnidadNegocio UN WITH (NOLOCK) --@3      
  ON P.IdUnidadNegocio = UN.IdUnidadNegocio --@3      
 INNER JOIN UnidadAcademica UA WITH (NOLOCK) --@3      
  ON P.IdUnidadAcademica = UA.IdUnidadAcademica --@3     
 WHERE S.idseccion = @idseccion  
END


Hora de finalizaci�n: 2025-12-05T14:50:49.3951680-05:00
