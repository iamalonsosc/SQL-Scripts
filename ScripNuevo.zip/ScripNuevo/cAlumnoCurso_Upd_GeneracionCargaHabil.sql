Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--����������������������������������������������������������������������������
--Creado por	: Luis Perales Tenorio (07/12/2011)
--Funcionalidad : Permite realizar el proceso de la carga h�bil de los alumnos (Solo de los alumnos matriculados en carreras)
--Utilizado por : AlumnoCurso.UpdGeneracionCargaHabil
--����������������������������������������������������������������������������
/*
-----------------------------------------------------------------------------
Nro		FECHA			USUARIO			DESCRIPCION
-----------------------------------------------------------------------------
@1		17.04.2012		LPerales		Debemos actualizar el campo esnuevo de la tabla producto a los antiguos en 0 y los nuevos en 1 
@2		10.09.2019		Hmora			Cambios para alumnos que cambien de IES a EEST
@3		30.09.2020		Rsamame			Se agregro el parametro producto para sacar el reingreso que corresponde
@4		17.10.2023		Alsanchez		Se agrega logica de diferenciacion de precio
@5		01/08/2024		RSamame			Se agrega logica para no considerar los registros anulados
@6		26/09/2025		JQuenta			Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil
*/

CREATE PROCEDURE [dbo].[cAlumnoCurso_Upd_GeneracionCargaHabil]
@IdEmpresa INT,
@IdSede INT,
@IdFacultad INT,
@IdUnidadNegocio INT,
@IdUnidadAcademica INT, 
@IdPeriodoAnterior INT, 
@IdPeriodoNuevo INT, 
@IdProducto INT,
@IdAlumno INT,
@Tipo VARCHAR(2), --RE: Alumnos Regulares, RI: Reingresos, CB: Cambios Curriculares
@IdUsuario INT,
@SoloInvicto VARCHAR(1) --1: Solo Invictos, 0: Todos
AS
BEGIN

	--Inicio --@6
	SET NOCOUNT ON
 
	--Declaramos las variables globales
	DECLARE
	@CurID INT,
	@MaxID INT,
	@Estado VARCHAR(2),
	@Resultado VARCHAR(1000),
	@CurIdAlumno INT, 
	@CurIdMatricula INT,
	@CurIdCurricula INT,
	@CurIdRegistro INT,
	@CurIdProducto INT,
	@CurIdModulo INT,
	@CurEsNuevo INT ,
	@IdPrecioSede INT --@4

	DECLARE @TempMatricula AS TABLE --@6
	(
		Id INT IDENTITY(1,1), --@6
		IdMatricula INT,
		IdPeriodo INT,
		IdProducto INT,
		ProductoNombre VARCHAR(250),
		CodigoAlumno VARCHAR(15),
		ActorIdActor INT,
		ActorNombreCompleto VARCHAR(250),
		IdRegistro INT,
		IdCurricula INT,
		IdModulo INT,
		EsNuevo INT,
		Estado VARCHAR(2),
		Observacion VARCHAR(4000)
	)
 
	--Carga de data de los alumnos regulares
	IF @Tipo = 'RE'
	BEGIN

		INSERT INTO @TempMatricula --@6
		(
			ActorIdActor,
			IdPeriodo,
			IdProducto,
			IdRegistro,
			IdCurricula,
			IdMatricula,
			IdModulo
		)
		SELECT
			M.IdActor,
			@IdPeriodoNuevo,
			P.IdProducto,
			M.IdRegistro,
			M.IdCurricula,
			M.IdMatricula,
			M.IdModulo
		FROM Matricula M WITH (NOLOCK)
		INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion
		WHERE P.IdEmpresa = @IdEmpresa 
		AND P.IdSede = @IdSede 
		AND P.IdFacultad = @IdFacultad
		AND P.IdUnidadNegocio = @IdUnidadNegocio 
		AND P.IdUnidadAcademica = @IdUnidadAcademica 
		AND P.IdPeriodo = @IdPeriodoAnterior
		AND (P.IdProducto = @IdProducto OR @IdProducto = 0) 
		AND (M.IdActor = @IdAlumno OR @IdAlumno = 0)
		AND M.Estado <> 'X' --@5 
		AND M.EsMatricula = 1
		ORDER BY
		P.IdProducto ASC,
		M.IdModulo ASC

	END

	--Carga de data de los alumnos ingresantes con convalidaciones
	IF @Tipo = 'CI' 
	BEGIN

		INSERT INTO @TempMatricula --@6
		(
			ActorIdActor,
			IdPeriodo,
			IdProducto,
			IdRegistro,
			IdCurricula,
			IdMatricula,
			IdModulo
		)
		SELECT
			C.IdAlumno,
			C.IdPeriodoAnual,
			R.IdProducto,
			C.IdRegistro,
			C.IdCurricula,
			NULL,
			NULL
		FROM Convalidacion C WITH (NOLOCK)
		INNER JOIN Registro R WITH (NOLOCK) ON C.IdAlumno = R.IdActor
		AND C.IdRegistro = R.IdRegistro
		WHERE C.IdEmpresa = @IdEmpresa
		AND C.IdSede = @IdSede
		AND C.IdPeriodoAnual = @IdPeriodoNuevo
		AND C.Tipo = 'TE'
		AND R.Estado <> 'X'--@5
		AND (c.IdAlumno = @IdAlumno OR @IdAlumno = 0)
		AND NOT EXISTS
		(
			SELECT
				1
			FROM Matricula MA WITH (NOLOCK) 
			WHERE MA.IdEmpresa = @IdEmpresa
			AND MA.IdSede = @IdSede
			AND MA.IdActor = C.IdAlumno
			AND MA.IdRegistro = C.IdRegistro
			AND MA.EsMatricula = 1
			AND MA.IdPeriodo = @IdPeriodoNuevo
			AND MA.Estado = 'N'
		)

	END

	--Traslados de sedes
	IF @Tipo = 'TS' 
	BEGIN

		INSERT INTO @TempMatricula --@6
		(
			ActorIdActor,
			IdPeriodo,
			IdProducto,
			IdRegistro,
			IdCurricula,
			IdMatricula,
			IdModulo
		)
		SELECT
			TS.IdAlumno,
			TS.IdPeriodoTraslado,
			dbo.cMatricula_Sel_UltimaMatricula_IdProducto(TS.IdAlumno,TS.IDRegistro),
			TS.IDRegistro,
			dbo.cMatricula_Sel_UltimaMatricula_IdCurricula(TS.IdAlumno,TS.IDRegistro),
			dbo.cMatricula_Sel_UltimaMatricula_IdMatricula(TS.IdAlumno,TS.IDRegistro),
			dbo.cMatricula_Sel_UltimaMatricula_IdModulo(TS.IdAlumno,TS.IDRegistro)
		FROM TrasladoSede TS WITH (NOLOCK)
		WHERE TS.IdEmpresa = @IdEmpresa
		AND TS.IdSede = @IdSede
		AND TS.IdPeriodoTraslado = @IdPeriodoNuevo
		AND TS.Estado = 1
		AND (TS.IdAlumno = @IdAlumno OR @IdAlumno = 0)

	END 

	--Cambio de carrera
	IF @Tipo = 'CC' 
	BEGIN

		INSERT INTO @TempMatricula --@6
		(
			ActorIdActor,
			IdPeriodo,
			IdProducto,
			IdRegistro,
			IdCurricula,
			IdMatricula,
			IdModulo
		)
		SELECT
			CC.IdAlumno,CC.IdPeriodo,
			CC.IdProductoNueva,
			dbo.cMatricula_Sel_IdRegistro(CC.IdEmpresa,CC.IdSede,CC.IdAlumno,CC.IdProductoNueva,CC.IdCurriculaNueva),
			CC.IdCurriculaNueva,
			NULL,
			NULL
		FROM CambioProductoCurricula CC WITH (NOLOCK)
		WHERE CC.IdEmpresa = @IdEmpresa
		AND CC.IdSede = @IdSede
		AND CC.IdPeriodo = @IdPeriodoNuevo
		AND CC.Estado = 1
		AND (CC.IdAlumno = @IdAlumno OR @IdAlumno = 0)

	END

	--Reingresos
	IF @Tipo = 'RI' 
	BEGIN

		INSERT INTO @TempMatricula --@6
		(
			ActorIdActor,
			IdPeriodo,
			IdProducto,
			IdRegistro,
			IdCurricula,
			IdMatricula,
			IdModulo
		)
		SELECT
			R.IdAlumno,
			R.IdPeriodoReingreso,
			R.IdProductoNueva,
			dbo.cMatricula_Sel_IdRegistro(R.IdEmpresa,R.IdSede,R.IdAlumno,R.IdProductoNueva,R.IdCurriculaNueva),
			R.IdCurriculaNueva,
			NULL,
			NULL
		FROM Reingresos R WITH(NOLOCK)
		WHERE R.IdEmpresa = @IdEmpresa
		AND R.IdSede = @IdSede
		AND R.IdPeriodoReingreso = @IdPeriodoNuevo
		AND R.Estado = 1
		AND R.IdProductoNueva = @IdProducto --@3
		AND (R.IdAlumno = @IdAlumno OR @IdAlumno = 0)
	
	END
 
	--@2
	--De IES a EEST (Traslado a Escuela)
	IF @Tipo = 'TE'
	BEGIN

		INSERT INTO @TempMatricula --@6
		(
			ActorIdActor,
			IdPeriodo,
			IdProducto,
			IdRegistro,
			IdCurricula,
			IdMatricula,
			IdModulo
		)
		SELECT
			TS.IdAlumno,
			TS.IdPeriodoTraslado,
			dbo.cMatricula_Sel_UltimaMatricula_IdProducto(TS.IdAlumno,R.IDRegistro),
			TS.IDRegistro,
			dbo.cMatricula_Sel_UltimaMatricula_IdCurricula(TS.IdAlumno,R.IDRegistro),
			dbo.cMatricula_Sel_UltimaMatricula_IdMatricula(TS.IdAlumno,R.IDRegistro),
			dbo.cMatricula_Sel_UltimaMatricula_IdModulo(TS.IdAlumno,R.IDRegistro)
		FROM TrasladoSede TS WITH (NOLOCK)
		INNER JOIN Registro R WITH (NOLOCK) ON R.IdProducto = TS.IdProductoAnterior
		AND R.IdActor = TS.IdAlumno
		WHERE TS.IdEmpresa = @IdEmpresa
		AND TS.IdSede = @IdSede
		AND TS.IdPeriodoTraslado = @IdPeriodoNuevo
		AND TS.Estado = 1
		AND (TS.IdAlumno = @IdAlumno OR @IdAlumno = 0)
		AND R.Estado <> 'X'

	END
	--@2

	--Se cargan las descripciones de cada alumno
	UPDATE M SET
		M.ProductoNombre = RTRIM(P.ProductoCodigo) + '-' + RTRIM(P.ProductoNombre),
		M.ActorNombreCompleto = RTRIM(A.NombreCompleto),
		M.CodigoAlumno = ISNULL(LTRIM(RTRIM(AL.CodigoAnterior)),''),
		M.EsNuevo = P.EsNuevo
	FROM @TempMatricula M --@6
	INNER JOIN Producto P WITH (NOLOCK) ON M.IdProducto = P.IdProducto
	INNER JOIN Actor A WITH (NOLOCK) ON M.ActorIdActor = A.IdActor
	LEFT JOIN Alumno AL WITH (NOLOCK) ON AL.IdAlumno = A.IdActor 

	SELECT @CurID = 1, @MaxID = MAX(Id) FROM @TempMatricula --@6

	WHILE @CurID <= @MaxID
	BEGIN

		--Se reinicia las variales de error
		SET @Estado = 'OK'
		SET @Resultado = '' 
		SET @IdPrecioSede = NULL --@4

		--Se procesa por cada alumno
		SELECT
			@CurIdAlumno = ActorIdActor,
			@CurIdMatricula = IdMatricula,
			@CurIdRegistro = idRegistro, 
			@CurIdProducto = IdProducto,
			@CurIdModulo = IdModulo,
			@CurIdCurricula = IdCurricula,
			@CurEsNuevo = EsNuevo
		FROM @TempMatricula --@6
		WHERE Id = @CurID 

		--@4
		SELECT
			@IdPrecioSede = IdPrecioSede
		FROM Matricula WITH (NOLOCK)
		WHERE IdMatricula = @CurIdMatricula
		--@4

		--@1
		DELETE TempValidaCumplimiento
		WHERE idsesion = @@SPID
		--@1
 
		IF @Tipo = 'RE' 
		BEGIN

			--PRINT 'RE' --@6

			--PRINT 'cMatricula_Pro_CargaHabil' --@6

			EXEC cMatricula_Pro_CargaHabil
			@IdEmpresa,
			@IdSede,
			@IdPeriodoNuevo,
			@CurIdAlumno,
			@CurIdMatricula,
			@CurIdCurricula,
			@CurIdRegistro,
			@CurIdModulo,
			@CurEsNuevo,
			@IdUsuario,
			@Tipo,
			@SoloInvicto,
			@IdPrecioSede, --@4
			@Estado OUTPUT,
			@Resultado OUTPUT
										
		END
 
		--Convalidacion de Ingresantes
		IF @Tipo = 'CI'
		BEGIN

			--PRINT 'CI' --@6

			--PRINT 'cMatricula_Pro_CargaHabilConvalidacionesIngresantes' --@6
		 
			EXEC cMatricula_Pro_CargaHabilConvalidacionesIngresantes
			@IdEmpresa,
			@IdSede,
			@IdPeriodoNuevo,
			@CurIdAlumno,
			@CurIdRegistro,
			@CurIdCurricula,
			@IdProducto, --@6
			@IdUsuario,
			@Estado OUTPUT,
			@Resultado OUTPUT

		END 
 
		--Cambio de carrera y reingresos
		IF @Tipo = 'CC'
		BEGIN

			--PRINT 'CC' --@6

			--PRINT 'cAlumnoCurso_Pro_CargaHabil_CambioCurricula' --@6

			EXEC cAlumnoCurso_Pro_CargaHabil_CambioCurricula
			@IdEmpresa,
			@IdSede, 
			@IdPeriodoNuevo, 
			@CurIdAlumno,
			@IdUsuario,
			@Tipo ,
			@Estado OUTPUT,
			@Resultado OUTPUT 

		END 
 
		IF @Tipo = 'RI' 
		BEGIN

			--PRINT 'RI' --@6

			--PRINT 'cMatricula_Pro_CargaHabilReingresos' --@6

			EXEC cMatricula_Pro_CargaHabilReingresos
			@IdEmpresa,
			@IdSede,
			@IdPeriodoNuevo,
			@CurIdAlumno,
			@IdUsuario,
			@Tipo,
			@SoloInvicto,
			@IdProducto, --@3
			@Estado OUTPUT,
			@Resultado OUTPUT

		END
 
		--Traslado de sede
		IF @Tipo = 'TS'
		BEGIN

			--PRINT 'TS' --@6

			--PRINT 'cMatricula_Pro_CargaHabil_TrasladoSede' --@6

			EXEC cMatricula_Pro_CargaHabil_TrasladoSede
			@IdEmpresa,
			@IdSede,
			@IdPeriodoNuevo,
			@CurIdAlumno,
			@IdUsuario,
			@SoloInvicto,
			@IdPrecioSede, --@4
			@Estado OUTPUT,
			@Resultado OUTPUT

		END

		--@2
		--Cambios de migracion de instituto a escuela
		IF @Tipo = 'TE'
		BEGIN

			--PRINT 'TE' --@6

			--PRINT 'cMatricula_Pro_CargaHabil_TrasladoSede' --@6

			EXEC cMatricula_Pro_CargaHabil_TrasladoSede
			@IdEmpresa,
			@IdSede,
			@IdPeriodoNuevo,
			@CurIdAlumno,
			@IdUsuario,
			@SoloInvicto,
			@IdPrecioSede, --@4
			@Estado OUTPUT,
			@Resultado OUTPUT

		END
		--@2

		UPDATE @TempMatricula SET --@6
			Estado = @Estado,
			Observacion = @Resultado
		WHERE Id = @CurID
 
		SET @CurID = @CurID + 1
		
	END

	--Se devuelven los resultados
	SELECT
		ProductoNombre,
		ActorIdActor,
		CodigoAlumno,
		ActorNombreCompleto,
		Estado,
		'Observacion' = ISNULL(Observacion,'')
	FROM @TempMatricula --@6
	--Fin --@6

END


Hora de finalizaci�n: 2026-08-04T18:35:41.3939841-05:00
