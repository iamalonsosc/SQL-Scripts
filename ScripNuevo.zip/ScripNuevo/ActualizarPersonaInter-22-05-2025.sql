update persona_inter set procesado = 'xx' , tiporegistro = 'x'  WHERE id in (1253303 , 1253619)  --personacodigo = '1785185'
 
update persona_inter set  tiporegistro = 'I'  WHERE id in (1254025)