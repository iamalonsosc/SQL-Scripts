-----------------------------------------------------------------------------          
--Creado por      : Suyin Silva (22/03/2024)                      
--Funcionalidad   : Permite realizar de listados por cursos  , reporte n� 75 de reporte de matricula               
--Utilizado por   : AlumnoCurso.RptListadoAlumnosPorCurso            
--����������������������������������������������������������������������������          
/*          
-----------------------------------------------------------------------------          
Nro  FECHA   USUARIO  DESCRIPCION          
-----------------------------------------------------------------------------          
@1   21-01-2025  JCORRALES Se agrega el campo tipo condicion de matricula           
@2   23-01-2025  JCORRALES Se agrega el campo EsAsincrono  
@3	 27-01-2025	 JCORRALES Se agrega los campos de PromocionCodigo y PromocionGrupo de Matricula y Alumno Curso
@4	 30-01-2025	 ALSANCHEZ Se agrega campo cursonombrecorte #71754
*/                    

ALTER PROCEDURE [dbo].[cMatriculaReporte_ListadoAlumnos]
@IdEmpresa INT,                                                
@IdSede INT,                                                
@IdFacultad INT,                                  
@IdUnidadNegocio INT,                                  
@IdUnidadAcademica INT,                                  
@IdPeriodo INT,                                  
@IdProducto INT,                                  
@PeriodoCodigo varchar(20)                                                                 
AS        
BEGIN      
      
  SET NOCOUNT ON        
  Declare @IdModulo INT      
        
  Declare @temporal table       
  (      
   IdUnidadNegocio INT,      
   IdUnidadAcademica INT,      
   IdPeriodo INT,      
   IdSede INT,      
   IdTipoModulo INT,      
   IdProducto INT,      
   AlumnoCursoPromocionCodigo VARCHAR(50),      --@3  
   AlumnosCursoGrupoCodigo VARCHAR(50), --- @3  
   PromocionCodigoMatricula VARCHAR(50), --- @3
   GrupoCodigoMatricula VARCHAR(50), --- @3
   CodigoHorario VARCHAR(50),  --@3
   PromocionNombre VARCHAR(250),      
   CondicionMatricula varchar(200), --@1    
   diaclasetexto VARCHAR(250),      
   FechaInicio VARCHAR(20),      
   FechaFin VARCHAR(20),      
   HoraInicio VARCHAR(20),      
   HoraFin VARCHAR(20),      
   IdTurno INT,      
   Seccion VARCHAR(50), --@3   
   IdAmbiente INT,      
   EsAsincrono VARCHAR(5), -- @2  
   IdCoordinador INT,      
   IdFacilitador INT,      
   IdMatricula INT,      
   IdAlumno INT,      
   IdModulo INT,      
   FechaMatricula DATETIME,      
   IdCurso INT,      
   Estado VARCHAR(250)      
  )      
           
      SELECT @IdModulo=IdMaestroTabla FROM MaestroTabla with(nolock)   WHERE Codigo='TipoSemestre'      
      
  --Si la sede viene llena significa que el usuario a seleccionado una sede      
  IF ISNULL(@IdSede,-1)!=-1      
  BEGIN      
   INSERT INTO @temporal                                
   SELECT       
    P.IdUnidadNegocio,                              
    P.IdUnidadAcademica,                               
    P.IdPeriodo,                              
    P.IdSede,                              
    CM.IdTipoModulo,                              
    P.IdProducto,                              
    'AlumnoCursoPromocionCodigo'=P.PromocionCodigo,                --@3       
    'GrupoCodigo'=PG.GrupoCodigo,       -- @3
	'PromocionCodigoMatricula'=PR_M.PromocionCodigo,   --@3
	'GrupoCodigoMatricula'=PG_M.GrupoCodigo,  --@3
	'CodigoHorario' = S.Codigo   , --@3
    P.PromocionNombre,     
 'CondicionMatricula' = case m.TipoCondicion when 'RE' then 'PROMOVIDO' when 'RP' then 'PROMOVIDO + CURSO' when 'RT' then 'REPITENTE' when 'CC' then 'CURSO REPITENCIA' end,  --@1    
    PG.diaclasetexto,                              
    'FechaInicio'=dbo.gFechaStr(S.FechaInicio),                        
    'FechaFin'=dbo.gFechaStr(S.FechaFin),                     
    'HoraInicio'=dbo.gHhMmStr(PG.HoraInicio),                        
    'HoraFin'=dbo.gHhMmStr(PG.HoraFin),                        
    S.IdTurno,         
    'Seccion'=PG.GrupoCodigo,              
    S.IdAmbiente,                     
 'EsAsincrono' = (case when coalesce(S.EsAsincronico,0) = 1 THEN 'SI' ELSE 'NO' END) , -- @2  
    'IdCoordinador'=PG.IdCoordinador,                              
    'IdFacilitador'=SP.IdActor,       
    'IdMatricula'=M.IdMatricula,                               
    'IdAlumno'=AC.IdAlumno,          
    M.IdModulo,      
    'FechaMatricula' = ISNULL(M.MatriculaFecha,''),      
    AC.IdCurso,                              
    'Estado' = CASE WHEN AC.EsMatricula  = 1 THEN 'Matriculado' ELSE 'Pre matriculado' END      
   FROM Promocion P with(nolock)                              
   INNER JOIN PromocionGrupo PG   with(nolock)                                     
   ON PG.IdPromocion=P.IdPromocion                      
   INNER JOIN CurriculaModulo CM  with(nolock)                                    
   ON CM.IdCurricula=P.IdCurricula                               
   AND CM.IdModulo=isnull(P.IdModulo,1)                                           
   INNER JOIN Seccion S  with(nolock)                                   
   ON S.IdPromocion = PG.IdPromocion AND S.IdGrupo = PG.IdGrupo                               
   LEFT JOIN SeccionProfesor SP   with(nolock)                          
   ON S.IdSeccion = SP.IdSeccion                              
   INNER JOIN AlumnoCurso AC    with(nolock)                                 
   ON S.IdCurso = AC.IdCurso                       
      AND S.IdSeccion = AC.IdSeccion                              
      AND S.IdPromocion = AC.IdPromocion                               
      AND S.IdGrupo = AC.IdGrupo          
   INNER JOIN Matricula M with(nolock)       
   ON ac.idmatricula = M.idmatricula      
   INNER JOIN Promocion PR_M ON PR_M.IdPromocion=M.IdPromocion --@3
   inner join PromocionGrupo PG_M ON PG_m.IdPromocion=M.IdPromocion and PG_M.IdGrupo=M.IdGrupo -- @3
   WHERE P.IdEmpresa=@IdEmpresa                              
   AND (P.IdSede=@IdSede Or @IdSede = -1)      
   AND P.IdFacultad=@IdFacultad                              
   AND P.IdUnidadNegocio=@IdUnidadNegocio               
   AND P.IdUnidadAcademica=@IdUnidadAcademica                   
   AND(P.IdPeriodo = @IdPeriodo OR  @IdPeriodo = -1)                      
   AND(P.IdProducto = @IdProducto OR  @IdProducto = -1)           
   AND M.Estado in( 'N' ,'R')      
   AND M.EsMatricula = 1          
  END      
  ELSE       
  --Si la sede viene vacia selecciono "TODOS" y el usuario quiere imprimir todas las sedes      
  BEGIN      
   INSERT INTO @temporal                                
   SELECT       
    P.IdUnidadNegocio,                              
    P.IdUnidadAcademica,                               
    P.IdPeriodo,                              
    P.IdSede,                              
    CM.IdTipoModulo,                              
    P.IdProducto,                              
    'AlumnoCursoPromocionCodigo'=P.PromocionCodigo,   --@3                              
    'GrupoCodigo'=PG.GrupoCodigo,       -- @3
	'PromocionCodigoMatricula'=PR_M.PromocionCodigo,   --@3
	'GrupoCodigoMatricula'=PG_M.GrupoCodigo,  --@3
	'CodigoHorario' = S.Codigo   , --@3
    P.PromocionNombre,                              
 'CondicionMatricula' = case m.TipoCondicion when 'RE' then 'PROMOVIDO' when 'RP' then 'PROMOVIDO + CURSO' when 'RT' then 'REPITENTE' when 'CC' then 'CURSO REPITENCIA' end,  --@1    
    PG.diaclasetexto,                              
    'FechaInicio'= dbo.gFechaStr(S.FechaInicio),                        
    'FechaFin'= dbo.gFechaStr(S.FechaFin),                        
    'HoraInicio'=dbo.gHhMmStr(PG.HoraInicio),                        
    'HoraFin'= dbo.gHhMmStr(PG.HoraFin),                      
    S.IdTurno,         
    'Seccion'=PG.GrupoCodigo,                     
    S.IdAmbiente,                              
 'EsAsincrono' = (case when coalesce(S.EsAsincronico,0) = 1 THEN 'SI' ELSE 'NO' END) , -- @2  
    'IdCoordinador'=PG.IdCoordinador,                              
    'IdFacilitador'=SP.IdActor,          
    'IdMatricula'=M.IdMatricula,                          
    'IdAlumno'=AC.IdAlumno,          
    M.IdModulo,      
    'FechaMatricula' = ISNULL(M.MatriculaFecha,''),      
    AC.IdCurso,                              
    'Estado' = CASE WHEN AC.EsMatricula  = 1 THEN 'Matriculado' ELSE 'Pre matriculado' END      
   FROM Promocion P with(nolock)                              
   INNER JOIN PromocionGrupo PG   with(nolock)                                     
   ON PG.IdPromocion=P.IdPromocion                               
   INNER JOIN CurriculaModulo CM  with(nolock)                                    
   ON CM.IdCurricula=P.IdCurricula                               
   AND CM.IdModulo=isnull(P.IdModulo,1)                            
   INNER JOIN Seccion S  with(nolock)                                   
   ON S.IdPromocion = PG.IdPromocion AND S.IdGrupo = PG.IdGrupo                               
   LEFT JOIN SeccionProfesor SP   with(nolock)                                  
   ON S.IdSeccion = SP.IdSeccion                              
   INNER JOIN AlumnoCurso AC    with(nolock)                                 
   ON S.IdCurso = AC.IdCurso                       
    AND S.IdSeccion = AC.IdSeccion                              
    AND S.IdPromocion = AC.IdPromocion       
    AND S.IdGrupo = AC.IdGrupo          
   INNER JOIN Matricula m with(nolock)       
   ON ac.idmatricula = m.idmatricula      
   inner Join Periodo PE On PE.IdPeriodo = P.IdPeriodo      
   INNER JOIN Promocion PR_M ON PR_M.IdPromocion=M.IdPromocion --@3
   inner join PromocionGrupo PG_M ON PG_m.IdPromocion=M.IdPromocion and PG_M.IdGrupo=M.IdGrupo -- @3
   WHERE P.IdEmpresa=@IdEmpresa                              
   AND P.IdFacultad=@IdFacultad                              
   AND P.IdUnidadNegocio=@IdUnidadNegocio               
   AND P.IdUnidadAcademica=@IdUnidadAcademica                          
   AND(P.IdProducto = @IdProducto OR  @IdProducto = -1)                      
   AND PE.Codigo =@PeriodoCodigo      
   AND M.Estado in( 'N' ,'R')      
   AND M.EsMatricula = 1          
      
  END      
      
   SELECT     DISTINCT                
   'Division'=UN.Nombre,                              
   'Programa'=UA.Nombre,        
   'SedeCodigo'=S.Codigo,                              
   'SedeNombre'=S.Nombre,                                
   'PeriodoCodigo'=P.Codigo,       
   'ProductoNombre'=PR.ProductoNombre,          
   'CicloCurso'=ISNULL(MT.Nombre,''),    
   T.PromocionCodigoMatricula,  -- @3
   T.GrupoCodigoMatricula,     -- @3
   T.PromocionNombre,                 
   T.CondicionMatricula, --@1    
   T.DiaClaseTexto,                              
   'FechaInicio'=CONVERT(varchar,T.FechaInicio),                              
   'FechaFin'=CONVERT(varchar,T.FechaFin),                              
   T.HoraInicio,                              
   T.HoraFin,                           
   'Turno' = T4.Nombre,      
   'TurnoNombre'=TU.Nombre,                                          
   'AmbienteNombre'=isnull(AM.Nombre,''),                                              
   'FacilitadorCodigo'=isnull(F.CodigoAnterior,''),                        
   'FacilitadorNombreCompleto'=isnull(A2.NombreCompleto,''),          
   'IdMatricula'=T.IdMatricula,                       
   'CodigoAlumno'=AL.CodigoAnterior,                            
   'AlumnoNombreCompleto'=A3.NombreCompleto,            
   'CicloMatriculaAlumno' = MTA.Nombre,       
   'FechaMatricula'=CONVERT(VARCHAR(10),T.FechaMatricula,103) ,  
   'FechaNacimiento'=CONVERT(VARCHAR(10),A3.FechaNacimiento,103),                                   
   'DocumentoTipo'=MT2.Nombre,                              
   'NumeroIdentidad'=ISNULL(A3.NumeroIdentidad,''),      
   'Telefono'=[dbo].[cActorTelefono_UltimoDilo](T.IdAlumno),       
   'Email'  = [dbo].[cActorEmailStr](T.IdAlumno),                
   'CursoCodigo'=C.CursoCodigo,                        
   'CursoNombre'=C.CursoNombre,
   --'CursoNombreCorto'=C.CursoNombreIngles,
   'CursoPromocionCodigo'=T.AlumnoCursoPromocionCodigo, --@3                                
   'CursoGrupoCodigo'=T.AlumnosCursoGrupoCodigo,    --@3 
   'CodigoHorario' = T.CodigoHorario, --@3
   'Estado' = T.Estado    ,  
   'EsAsincrono' = T.EsAsincrono -- @2  
   FROM @temporal T                              
   INNER JOIN UnidadNegocio UN   with(nolock)                                  
   ON UN.IdUnidadNegocio = T.IdUnidadNegocio                              
   INNER JOIN UnidadAcademica UA  with(nolock)                                   
   ON UA.IdUnidadAcademica = T.IdUnidadAcademica                              
   INNER JOIN Curso C with(nolock)                                    
   ON C.IdCurso = T.IdCurso                              
   left JOIN Ambiente AM   with(nolock)                                  
   ON AM.IdAmbiente = T.IdAmbiente                               
   INNER JOIN Turno TU with(nolock)                                    
   ON TU.IdTurno = T.IdTurno             
   INNER JOIN MaestroTablaRegistro T4 with(nolock)       
   ON T4.IdMaestroRegistro = TU.IdTipoTurno       
   INNER JOIN Periodo P  with(nolock)                                   
   ON P.IdPeriodo = T.IdPeriodo                              
   INNER JOIN Sede S    with(nolock)                                 
   ON S.IdSede = T.IdSede                              
   INNER JOIN Producto PR  with(nolock)                                   
   ON PR.IdProducto = T.IdProducto    
   
   INNER JOIN Producto PR  with(nolock)                                   
   ON PR.IdProducto = T.IdProducto    


   LEFT JOIN MaestroTablaRegistro MT  with(nolock)                                   
   ON MT.IdMaestroRegistro = T.IdTipoModulo                              
   LEFT JOIN Actor A  with(nolock)                                   
   ON A.IdActor = T.IdCoordinador          
   LEFT JOIN Actor A2  with(nolock)                                  
   ON A2.IdActor = T.IdFacilitador                              
   LEFT JOIN Actor A3  with(nolock)                                   
   ON A3.IdActor = T.IdAlumno                             
   LEFT JOIN Facilitador F   with(nolock)                            
   ON F.IdFacilitador = T.IdFacilitador                        
   LEFT JOIN MaestroTablaRegistro MT2    with(nolock)                                 
   ON MT2.IdMaestroRegistro = A3.IdDocumentoTipo          
   INNER JOIN Alumno AL with(nolock)          
   ON AL.IdAlumno= T.IdAlumno         
   LEFT JOIN MaestroTablaRegistro MTA  with(nolock)                                   
   ON MTA.IdMaestroTabla = @IdModulo                         
   AND CONVERT(INT,MTA.Disponible1) = T.IdModulo      

         
    SET NOCOUNT OFF       
END 
