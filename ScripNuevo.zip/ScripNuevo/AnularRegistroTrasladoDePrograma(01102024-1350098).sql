UPDATE Registro SET IdSede=33
WHERE IdActor=1350098
AND IdRegistro=3
--(1 row affected)