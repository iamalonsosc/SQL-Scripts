--AGREGAR DOCENTE 
 
 INSERT INTO SeccionProfesor VALUES (655463,697057,1,1,1,GETDATE(),1,GETDATE(),null)
 --(1 fila afectada)