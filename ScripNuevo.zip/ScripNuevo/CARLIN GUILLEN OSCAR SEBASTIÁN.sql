--SELECT*FROM AlumnoCurso WHERE IdAlumno=1051133
--AND IdCurso=10111
--SELECT*FROM AlumnoCurriculaCurso 
UPDATE AlumnoCurriculaCurso SET PromedioFinal='00',PromedioReal='00',PromedioCondicion='D'
WHERE IdAlumno=1051133
AND IdCurso=10111

UPDATE AlumnoCurriculaCurso SET PromedioFinal='00',PromedioReal='00',PromedioCondicion='D'
WHERE IdAlumno=1051133
AND IdCurso=10114