--RIMAC FR�GIDEZ JOSE MIGUEL
SELECT esmatricula, *FROM ALUMNOCURSO
--UPDATE ALUMNOCURSO SET EsMatricula=1
WHERE IdAlumno=1233708 AND IdMatricula=611208 AND IDCURSO IN (10568)



select*from AlumnoCurso where IdAlumno=1233708 and IdCurso=10336
select*from Promocion where idpromocion in (80548,
87061)
select*from AlumnoCursoNomina where IdActor=1233708

order  by IdMatricula desc
--(1 fila afectada)
-----------------------------------------------------------------------------------
--SULCA HUARHUACHI MARCELA
--SELECT*FROM ALUMNOCURSO
UPDATE ALUMNOCURSO SET EsMatricula=1
WHERE IdAlumno=1373734 AND IdMatricula=532987 AND IDCURSO=9926
--(1 fila afectada)
-----------------------------------------------------------------------------------
--ENCISO MENESES FIORELLA
--SELECT*FROM ALUMNOCURSO
UPDATE ALUMNOCURSO SET EsMatricula=1
WHERE IdAlumno=1413348 AND IdMatricula=609106 --AND IDCURSO=9926
--(3 filas afectadas)
-----------------------------------------------------------------------------------
--AYRA SOTO ALEXANDER JHONATAN
--SELECT*FROM ALUMNOCURSO
UPDATE ALUMNOCURSO SET EsMatricula=1
WHERE IdAlumno=1247234 AND IdMatricula=597544 --AND IDCURSO=9926
--(1 filas afectadas)
-----------------------------------------------------------------------------------
--VILLALBA ASUAREZ ANTHONY RAMIS
--SELECT*FROM MATRICULA
UPDATE Matricula SET Estado='N'
WHERE IdMatricula=584668
--(1 filas afectadas)


INSERT INTO AlumnoCurso VALUES (1459147,4,53,5604,10133,600524,95863,1,622232,null,null,'20.00','20.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET TipoCondicion='RE', IdAlumnoCurso = 53, subsanacion=1 WHERE IdAlumno = 1459147 AND IdCurricula = 5604 AND IdCurso = 10133



INSERT INTO AlumnoCurso VALUES (1312583,5,62,5604,9934,600601,95865,4,622507,null,null,'17.00','17.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET TipoCondicion='RE', IdAlumnoCurso = 62, subsanacion=1 
 
 --update  AlumnoCurso set TipoCondicion='RE'
 --WHERE IdAlumno=1312583 AND IdRegistro=5 AND IdCurso=9934

SELECT C.CursoNombre,AC.*fROM AlumnoCurso AC
INNER JOIN Curso C ON AC.IdCurso=C.IdCurso
WHERE AC.IdAlumno=1459147  and ac.IdMatricula=600524
ORDER BY IdAlumnoCurso DESC