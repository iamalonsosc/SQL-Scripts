--select  *  from Facilitador 
--(2786 rows affected)
update Facilitador set EmailInstitucion  =replace(EmailInstitucion,'edu.pe','pe') 


--select * from usuario where EMail  like '%edu.pe%' and IdTipoUsuario�=�2
--(1151 rows affected)
update usuario set EMAIL=replace(EMAIL,'edu.pe','pe')
where EMail  like '%edu.pe%' and IdTipoUsuario�=�2