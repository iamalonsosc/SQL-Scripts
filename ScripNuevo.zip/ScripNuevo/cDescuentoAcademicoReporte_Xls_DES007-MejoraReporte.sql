----------------------------------------------------------------------------      
--Creado por      :Alonso Sanchez (26/04/2024)            
--Funcionalidad   :Reporte de la asignacion de las becas activate
--Utilizado por   :DescuentoAcademicoReporte(XlsDES007Str)
--------------------------------------------------------------         
/*      
-----------------------------------------------------------------------------      
Nro		FECHA			USUARIO					DESCRIPCION      
-----------------------------------------------------------------------------      
@1		07.05.2024		Alsanchez				Se agrega validacion por codigoBase
@2		11.09.2024		Alsanchez				Se agrega codigo del nuevo descuento para la logica de Mayor TIP0000037
@3		13.09.2024		Alsanchez				Se agrega nuevos campos al fomulario
@4		13.09.2024		Alsanchez				Se agrega Unidad de negocio y UnidadAcademica
@5		26.08.2025		JPORRAS					Se agrega codigo de descuento para CA. TIP0000043
@6		26.08.2025		Alsanchez				Se agrega nuevos codigos de descuento para Idat
@7		18.02.2026		MTAIPE					Se Actualiza  @CompaniaSocio para CA y el where de activo 
@8		22.07.2026		ALSANCHEZ				Se agrega nueva logica para consulta de los TIP
@9		22.07.2026		ALSANCHEZ				Se agrega nuevos campos para las validaciones
@10		31.07.2026		ALSANCHEZ				Se agrega companiasocio dinamica
*/ 
ALTER PROCEDURE [dbo].[cDescuentoAcademicoReporte_Xls_DES007] 
@PeriodoCodigo varchar(14),
@IdUnidadNegocio INT=NULL,--@4
@IdUnidadAcademica INT=NULL--@4
AS 
SET NOCOUNT ON
DECLARE @MIN INT , @MAX INT,@IdMatricula INT,@pDescripcion varchar(500) ,@pEstado varchar(500),@CodigoBase varchar(500),@CompaniaSocio varchar(15)--@1

CREATE TABLE #Matricula ( Id INT IDENTITY(1,1) PRIMARY KEY ,
IdMatricula INT
,SedeNombre			VARCHAR(500)
,NumeroDocumento	VARCHAR(100)
,NombreActor		VARCHAR(500)
,CodigoAlumno		VARCHAR(500)
,PromocionCodigo	VARCHAR(500)
,PromocionNombre	VARCHAR(500)
,Seccion			VARCHAR(500)
,Turno				VARCHAR(500)
,PeriodoCodigo		VARCHAR(100) 
,BaseComercial		VARCHAR(500) 
,BasePertence		VARCHAR(500)
,CodigoBase			VARCHAR(500)
,CondicionMatricula VARCHAR(500)
,TipoServicio		VARCHAR(100)
,CondicionPago		VARCHAR(500)
,FechaMatricula		VARCHAR(500)
,Estado				VARCHAR(500)  
,Estado_Actual		VARCHAR(500)
,Oferta_Alumno		VARCHAR(500)
,Beca_Actual		VARCHAR(500)
,DescuentoAplicadoUsuario	VARCHAR(500)
,Becas_Pagadas		VARCHAR(500)
,DescuentoAplicadoPagado	VARCHAR(500)
,Observacion		VARCHAR(500)
,PromedioValidar VARCHAR(500)--@9
,PagoPuntualCicloAnterior VARCHAR(500)--@9
,PromedioFinalCicloAnterior VARCHAR(500)--@9
,ciclopro INT--@9
,ciclomat INT)--@9

--@9
CREATE TABLE #SP
(
    Titulo VARCHAR(500),
    Descripcion VARCHAR(MAX)
)
--@9

DECLARE @MAESTROTABLAREGISTRO TABLE (Id INT IDENTITY(1,1) PRIMARY KEY,
IdMaestroRegistro INT,
Codigo VARCHAR(500),
Nombre VARCHAR(500),
Promedio VARCHAR(10),
Activo INT);

INSERT INTO @MAESTROTABLAREGISTRO
SELECT IdMaestroRegistro,Codigo,Nombre,Disponible1,Activo FROM  MaestroTablaRegistro
WHERE IdMaestroTabla =1905 AND Disponible10='ACTIVATE' AND Activo=1 --@8
--and Codigo IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019','TIP0000037','TIP0000043','TIP0000049','TIP0000050','TIP0000059','TIP0000060')--@2 --@5 @6 

SELECT @CompaniaSocio=CompaniaSocio FROM Empresa Empresa where Activo=1 --@7

	IF(@CompaniaSocio='00002600')--@7
	BEGIN
		SELECT @CompaniaSocio=CompaniaSocioPadre FROM Empresa where Activo=1 --@7
	END

insert into #Matricula
SELECT DISTINCT   M.IdMatricula,
SE.Nombre ,
ISNULL(Ac.NumeroIdentidad,''),
Ac.NombreCompleto ,
ISNULL(AL.CodigoAnterior,''),
ISNULL(p.PromocionCodigo,''),
ISNULL(p.PromocionNombre,'')Carrera,
ISNULL(pg.GrupoCodigo,'') Seccion,
ISNULL(T.Nombre,'') Turno,
ISNULL(pe.Codigo,'') Periodo ,
'[' + s.Codigo + '] [' + b.PeriodoCodigo + '] [' + pr.ProductoNombre + ']' ,
mtr.Nombre ,
mtr.codigo,
'CondicionMatricula' = case m.TipoCondicion when 'RE' then 'PROMOVIDO' when 'RP' then 'PROMOVIDO + CURSO' when 'RT' then 'REPITENTE' when 'CC' then 'CURSO REPITENCIA' end,
'TipoServicio' = CASE WHEN M.TipoServicio = 'P' THEN 'PRODUCTO' WHEN M.TipoServicio = 'C' THEN 'CURSO' WHEN M.TipoServicio = 'M' THEN 'PRODUCTO + CURSO' ELSE '' END ,
'CondicionPago' = case  when condicionpago = 'C' then 'CONTADO' ELSE 'CUOTAS' END ,   
'FechaMatricula' = convert(varchar, ISNULL(m.MatriculaFecha, M.InscritoFecha), 103),
'Estado' = case when m.EsMatricula  = 1 then 'MATRICULADO' ELSE 'PRE' END,
'Estado_Actual' = CASE M.Estado  WHEN 'N' THEN 'NORMAL'   WHEN 'X' THEN 'ANULADO' WHEN 'R' THEN 'RETIRO CICLO' END 
,'' --Oferta_Alumno
,'' --Beca_Actual
,'' --DescuentoAplicadoUsuario
,'' --Becas_Pagadas--@3
,'' --DescuentoAplicadoPagado--@3
,'' --Observacion
,MTR.Promedio 'Promedio a Validar'
,'' --Pago puntual --@9
,'' --PromedioFinal --@9
,P.IdModulo 'Modulo de promocion' --@9
,M.IdModulo 'Modulo de matricula' --@9
FROM MATRICULA M
INNER JOIN Actor AC WITH(NOLOCK) ON M.IdActor = Ac.IdActor
INNER JOIN Alumno AL WITH(NOLOCK) ON AC.IdActor = AL.IdAlumno
INNER JOIN Promocion P WITH(NOLOCK) ON M.IdPromocion = P.IdPromocion
INNER JOIN Periodo PE WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo 
INNER JOIN DescuentoAcademicoBase B WITH(NOLOCK) ON B.IDACTOR = M.IDACTOR AND B.Activo=1
INNER JOIN @MAESTROTABLAREGISTRO MTR  ON MTR.IdMaestroRegistro = B.IdMaestroRegistro
INNER JOIN sede s WITH(NOLOCK) on s.IdSede = b.IdSede --Todo beca activate debe tener sede
INNER JOIN sede SE WITH(NOLOCK) on SE.IdSede = P.IdSede
INNER JOIN Producto pr WITH(NOLOCK) on pr.IdProducto = b.IdProducto --Todo beca activate debe tener producto
LEFT JOIN PromocionGrupo pg  WITH(NOLOCK) on pg.IdPromocion = m.IdPromocion and pg.IdGrupo = m.IdGrupo   
LEFT JOIN Turno t  WITH(NOLOCK)on t.IdTurno = pg.IdTurno   
WHERE PE.CODIGO = @PeriodoCodigo
AND M.Estado <>'X'
AND (P.IdUnidadNegocio= @IdUnidadNegocio OR ISNULL(@IdUnidadNegocio,-1)=-1 )--@4
AND (P.IdUnidadAcademica= @IdUnidadAcademica OR ISNULL(@IdUnidadAcademica,-1)=-1 )--@4

SELECT @MIN = MIN(ID), @MAX = MAX(ID) from #Matricula

WHILE @MIN <= @MAX
BEGIN

	SET @IdMatricula = NULL 
	SET @CodigoBase=NULL--@1
	SET @pDescripcion=NULL

	SELECT @IdMatricula = IdMatricula,@CodigoBase=CodigoBase  FROM #Matricula WHERE ID = @Min --@1
	EXEC  dbo.cAsignacion_BecaActivate @IdMatricula ,@CodigoBase,@pEstado OUT,@pDescripcion OUT --@1

	UPDATE #Matricula SET Observacion=@pDescripcion
	WHERE ID = @Min

	UPDATE #Matricula
	SET Beca_Actual = ISNULL( DAR.DescuentoNombre,''),
	DescuentoAplicadoUsuario = CASE WHEN ISNULL(US.Login, '') = '' THEN '' ELSE CONCAT(ISNULL(DAR.DescuentoNombre, ''), ' - ', ISNULL(US.Login, ''), ' - ', ISNULL(CONVERT(varchar(10), DAV.FechaCreacion, 103), '')) END
	FROM #Matricula M
	INNER JOIN CO_Interfase_P09_Header CIP09 WITH(NOLOCK) ON CIP09.CompaniaSocio=@CompaniaSocio AND M.IdMatricula = CIP09.IdMatricula AND CIP09.Estado <>'CO'  --@3
	INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON M.IdMatricula = DAR.IdMatricula AND DAR.Cuota = CIP09.CuotaNumero
	INNER JOIN DescuentoAcademico  DA WITH(NOLOCK) ON DA.IdDescuentoAcademico = DAR.IdDescuentoAcademico
	INNER JOIN DescuentoAcademicoPoblacion  DAP WITH(NOLOCK) ON DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico
	INNER JOIN @MAESTROTABLAREGISTRO  MTR ON  MTR.IdMaestroRegistro = DAP.IdTipoSituacionAlumno
	LEFT JOIN DescuentoAlumnoEvidencia DAV WITH(NOLOCK) ON DAV.IdMatricula= M.IdMatricula  AND DAV.IdDescuentoAcademico = DAR.IdDescuentoAcademico
	LEFT JOIN Usuario US WITH(NOLOCK) ON US.IdUsuario=DAV.UsuarioCreacion
	WHERE  M.ID = @Min AND  M.IdMatricula = @IdMatricula;


	UPDATE #Matricula
	SET Becas_Pagadas = ISNULL( DAR.DescuentoNombre,''),--@3
	DescuentoAplicadoPagado = CASE WHEN ISNULL(US.Login, '') = '' THEN '' ELSE CONCAT(ISNULL(DAR.DescuentoNombre, ''), ' - ', ISNULL(US.Login, ''), ' - ', ISNULL(CONVERT(varchar(10), DAV.FechaCreacion, 103), '')) END--@3
	FROM #Matricula M
	INNER JOIN CO_Interfase_P09_Header CIP09 WITH(NOLOCK) ON CIP09.CompaniaSocio=@CompaniaSocio AND M.IdMatricula = CIP09.IdMatricula AND CIP09.Estado ='CO'  --@3
	INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON M.IdMatricula = DAR.IdMatricula AND DAR.Cuota = CIP09.CuotaNumero
	INNER JOIN DescuentoAcademico  DA WITH(NOLOCK) ON DA.IdDescuentoAcademico = DAR.IdDescuentoAcademico
	INNER JOIN DescuentoAcademicoPoblacion  DAP WITH(NOLOCK) ON DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico
	INNER JOIN @MAESTROTABLAREGISTRO  MTR ON  MTR.IdMaestroRegistro = DAP.IdTipoSituacionAlumno
	LEFT JOIN DescuentoAlumnoEvidencia DAV WITH(NOLOCK) ON DAV.IdMatricula= M.IdMatricula  AND DAV.IdDescuentoAcademico = DAR.IdDescuentoAcademico
	LEFT JOIN Usuario US WITH(NOLOCK) ON US.IdUsuario=DAV.UsuarioCreacion
	WHERE  M.ID = @Min AND  M.IdMatricula = @IdMatricula;


	--@9
	DELETE FROM #SP

    INSERT INTO #SP
    EXEC cDescuentoAcademico_Sel_DatosActorMatriculado
         @IdMatricula = @IdMatricula,
         @CompaniaSocio = @CompaniaSocio

	UPDATE M
		   SET M.PagoPuntualCicloAnterior =
				(SELECT TOP 1 Descripcion
				 FROM #SP
				 WHERE Titulo = 'PagoPuntual_CicloAnterior'),

			   M.PromedioFinalCicloAnterior =
				(SELECT TOP 1 Descripcion
				 FROM #SP
				 WHERE Titulo = 'PromedioCicloAtenrior')
		FROM #Matricula M
		WHERE M.Id = @MIN
	--@9

	SET @Min=@Min+1
END 

SELECT*FROM #Matricula
ORDER BY ID
DROP TABLE #Matricula 