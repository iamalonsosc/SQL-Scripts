--SELECT*FROM ActaConsolidada 
UPDATE ActaConsolidada SET TurnoNombre='NOCHE'
WHERE Seccion='215.I.10.2023-IIIE-I-F'
AND TurnoNombre IS NULL
--(21 rows affected)