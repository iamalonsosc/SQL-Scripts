USE AcademicoIDAT;

GO



UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 746333
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739585
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739586
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739587
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739591
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739625
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739594
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739636
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739637
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739640
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739607
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739635
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739560
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739584
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739568
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739623
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739559
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 746354
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739566
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739590
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739592
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739571
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739643
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739570
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739609
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739617
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739628
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739582
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739577
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739562
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739624
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739599
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739569
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739597
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739612
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739638
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739572
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739567
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739604
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739629
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739564
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739581
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739626
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739618
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739565
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739589
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739610
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739602
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739614
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739593
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739563
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739603
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739600
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739613
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739605
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739611
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739596
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739632
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739621
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739615
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739627
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 751244
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739649
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'BALANCED SCORECARD E INDICADORES DE GESTI�N';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739650
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'BALANCED SCORECARD E INDICADORES DE GESTI�N';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739652
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'BALANCED SCORECARD E INDICADORES DE GESTI�N';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739790
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739774
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739772
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739773
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739786
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739784
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739764
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739776
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739779
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739767
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739775
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739778
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739788
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739763
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739771
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739777
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739758
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739765
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739782
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739761
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739899
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739893
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739888
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739884
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739894
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739890
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739905
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739886
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739917
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739900
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739908
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739889
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739885
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739896
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739903
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739891
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739882
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739883
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739902
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739887
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739906
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739909
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739895
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739914
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 738774
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739912
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 739897
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740069
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740038
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 748551
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'PROYECCI�N 3D Y REALIDAD VIRTUAL';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 748541
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'PROYECCI�N 3D Y REALIDAD VIRTUAL';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 748543
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'PROYECCI�N 3D Y REALIDAD VIRTUAL';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 746596
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'PROYECCI�N 3D Y REALIDAD VIRTUAL';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 748538
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'PROYECCI�N 3D Y REALIDAD VIRTUAL';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740331
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 741551
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 746696
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'SEMINARIO SOBRE RETOS Y REFLEXIONES SOCIALES';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740515
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'ESTRATEGIA DE SOCIAL MEDIA';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740516
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'ESTRATEGIA DE SOCIAL MEDIA';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740519
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'ESTRATEGIA DE SOCIAL MEDIA';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740517
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'ESTRATEGIA DE SOCIAL MEDIA';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740523
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'ESTRATEGIA DE SOCIAL MEDIA';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740522
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'ESTRATEGIA DE SOCIAL MEDIA';
UPDATE ACC SET ACC.Subsanacion = 1
  FROM AlumnoCurso AC
  INNER JOIN Curso CU ON CU.IdCurso = AC.IdCurso
  INNER JOIN AlumnoCurriculaCurso ACC 
  ON ACC.IdAlumno = AC.IdAlumno 
  AND ACC.IdCurso = AC.IdCurso 
  AND ACC.IdCurricula = AC.IdCurricula
  WHERE AC.IdMatricula = 740518
  AND UPPER(LTRIM(RTRIM(CU.CursoNombre))) = 'ESTRATEGIA DE SOCIAL MEDIA';
