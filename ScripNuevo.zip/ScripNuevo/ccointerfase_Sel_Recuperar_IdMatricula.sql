--����������������������������������������������������������������������������                                                
--Creado por      : Rosita Zacar�as (20/12/2012)                                                
--Funcionalidad   : Permite recuperar cuotas x idmatricula                                               
--Utilizado por   : ccointerfase_Sel_Recuperar_IdMatricula                                              
--����������������������������������������������������������������������������              
/*            
-----------------------------------------------------------------------------
Nro     FECHA			USUARIO						DESCRIPCION           
-----------------------------------------------------------------------------
@1		2018.04.19		jmota						se agrega campos para consulta administrativo           
@2		2019.01.08		Eloy Alva (SigComt)			Se hace la Consulta de la CompaniaSocio        
@3		02.09.2019		EHuillca					Se agrega nuevo campo "NumeroInterno"        
@4		24.09.2019		YFlores						Se reemplazan datos de "DESCUENTO POR PPPM" por valores de la tabla ParametroEmpresa        
@5		12.01.2021		Jnavia						Se agrega cuotas a la consulta        
@6		31.08.2021		Jnavia						Se valida que monto se debe mostrar y se agrega nuevos campos        
@7		08.09.2021		Jnavia						Se valida que monto se debe mostrar para cursos        
@8		14.09.2021		Jnavia						Se valida que monto se debe mostrar para Monto Promo        
@9		03.10.2022		mbueno						Se cambia si el grupo de descuento es nulo como -1 para listarse        
@10		2022.11.17		EHuillca					Se retira SUM de campo MontoPagado    
@11		2024.05.01		FETORRES					Se agrega logica para que CA tome la compania socio de ZEGEL desde 01/05/2024.  
@12		2024.05.23		FETORRES					Se agrega logica para que tome por sucursal la companiasocio en caso la fecha sea menor a 01/05/2024.  
@13		2024.06.05		MQUIROZ						Se agrega validacion para ITS por compania socio
@14		26/09/2025		JQuenta						Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil
													Se agrega nuevo campo IdActor y se mejora el filtro para poder visualizar correctamente las interfases de pago
*/

ALTER PROCEDURE [dbo].[ccointerfase_Sel_Recuperar_IdMatricula]
@IdMatricula INT,          
@CompaniaSocio CHAR(8) --@2                                               
AS                                                
BEGIN

	--Inicio --@14
	SET NOCOUNT ON --@14

	--Inicio @4        
	DECLARE
	@Valor VARCHAR(800),
	@Valor2 VARCHAR(800),
	@Valor3 VARCHAR(800),
	@FechaMatricula VARCHAR(10),
	@IdActor INT --@14
         
	SELECT
		@Valor = Valor,
		@Valor2 = Valor2,
		@Valor3 = Valor3          
	FROM ParametroEmpresa PE WITH (NOLOCK)        
	INNER JOIN Empresa E WITH (NOLOCK) ON E.IdEmpresa = PE.IdEmpresa        
	WHERE CompaniaSocio = @CompaniaSocio        
	AND Nombre = 'DESCUENTOSCUOTASPAGO'        
	--Fin @4

	--Inicio --@14
	SELECT
		@IdActor = IdActor,
		@FechaMatricula = CONVERT(VARCHAR(10),FechaCreacion,112)
	FROM Matricula WITH (NOLOCK)
	WHERE IdMatricula = @IdMatricula    
	--Fin --@14

	IF @CompaniaSocio = '00002600'  --@11    
	BEGIN

		IF @FechaMatricula < '20240501' --@11
		BEGIN

			--@12
			IF EXISTS
			(
				SELECT
					1
				FROM PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header WITH (NOLOCK)
				WHERE IdMatricula = @IdMatricula
				AND Sucursal IN ('SECA','SECI')
			)
			--@12
			BEGIN

				--@12
				SET @CompaniaSocio =
				(
					SELECT
						CompaniaSocioPadre
					FROM Empresa WITH (NOLOCK)
					WHERE IdEmpresa = 1
				)
				--@12

			END
			ELSE
			BEGIN

				SET @CompaniaSocio = 
				(
					SELECT
						CompaniaSocio
					FROM Empresa WITH (NOLOCK)
					WHERE IdEmpresa = 1
				)

			END

		END    
		ELSE
		BEGIN

			SET @CompaniaSocio = 
			(
				SELECT
					CompaniaSocioPadre
				FROM Empresa WITH (NOLOCK)
				WHERE IdEmpresa = 1
			)

		END

	END   
	--@13 Inicio
	ELSE IF @CompaniaSocio = '00002400'
	BEGIN

		SELECT
			@CompaniaSocio = CompaniaSocioPadre
		FROM Empresa WITH (NOLOCK)
		WHERE IdEmpresa = 1

	END
	--@13 Fin
         
	SELECT           
		C.CuotaNumero,
		'CuotaNumeroNombre' =
		CASE
			WHEN C.CuotaNumero = 1 THEN 'MATR�CULA'           
			WHEN C.CuotaNumero = 2 THEN 'CUOTA 1'          
			WHEN C.CuotaNumero = 3 THEN 'CUOTA 2'          
			WHEN C.CuotaNumero = 4 THEN 'CUOTA 3'          
			WHEN C.CuotaNumero = 5 THEN 'CUOTA 4'          
			WHEN C.CuotaNumero = 6 THEN 'CUOTA 5'          
			WHEN C.CuotaNumero = 7 THEN 'CUOTA 6'          
			WHEN C.CuotaNumero = 8 THEN 'CUOTA 7'        
			WHEN C.CuotaNumero = 9 THEN 'CUOTA 8' --@5        
			WHEN C.CuotaNumero = 10 THEN 'CUOTA 9' --@5        
			WHEN C.CuotaNumero = 11 THEN 'CUOTA 10' --@5        
			WHEN C.CuotaNumero = 12 THEN 'CUOTA 11' --@5        
			ELSE ''
		END,                            
		'FechaVencimiento' = dbo.fecha(C.FechaVencimiento),                                
		'Estado' =
		CASE
			C.Estado                   
			WHEN 'PF' THEN 'POR FACTURAR'                   
			WHEN 'AN' THEN 'ANULADO'                 
			WHEN 'GE' THEN 'GENERADO'                 
			WHEN 'PR' THEN 'FACT-SPRING'
			WHEN 'CO' THEN  'COBRADO'
			ELSE ''
		END,                
		'Monto' = ISNULL(SUM(CD.monto),''), --@6            
		'MontoPagado' = ISNULL(CO.MontoPagado,''), --@10        
		--Inicio @1          
		'InterfaseGrupodescuento' = ISNULL(C.Grupodescuento,-1),          
		'InterfaseEstado' = ISNULL(C.Estado,''),          
		'NumeroDocumento' = ISNULL(C.NumeroDocumento,''),          
		'IdDescuentoAcademico' = ISNULL(DAR.IdDescuentoAcademico,-1) ,          
		'GrupoDescuento' = ISNULL(DAR.GrupoDescuento,-1),          
		'DescuentoPorcentaje' =
		CASE
			WHEN CAST(ISNULL(DAR.Porcentaje,0.00) AS DECIMAL(5,2) ) = 0.00 THEN @Valor --@4        
			ELSE 
				CASE
					WHEN ISNULL(DAC.Porcentaje,0.00) = 0 THEN CAST(ISNULL(DA.Disponible2,ISNULL(DA.Porcentaje,0.00)) AS DECIMAL(5,2))           
					ELSE DAC.Porcentaje           
				END            
		END,          
		'DescuentoPorcentajeTexto' =
		CASE
			WHEN ISNULL(CAST(DAR.Porcentaje AS VARCHAR(8)),'') = '' THEN @Valor2 --@4        
			ELSE
				CASE
					WHEN ISNULL(DAC.Porcentaje,0.00) = 0 THEN ISNULL(DA.Disponible2,ISNULL(CAST(DA.Porcentaje AS VARCHAR(8)),'')) + ' %'           
					ELSE CAST(DAC.Porcentaje AS VARCHAR(8))           
				END           
		END,          
		'DescuentoNombre' = 
		CASE
			WHEN ISNULL(CAST(DAR.Porcentaje AS VARCHAR(8)),'') = '' THEN @Valor3 --@4        
			ELSE
				CASE
					WHEN ISNULL(DAC.Porcentaje,0.00) = 0.0000 THEN ISNULL(DAR.DescuentoNombre,'')           
					ELSE DAC.Nombre           
				END           
		END ,        
		--Fin @1          
		'NumeroInterno' = CD.NumeroInterno, --@3        
		'MontoHomologado' = ISNULL(SUM(ISNULL(P.MontoHomologado,CD.monto)),''), --@6 --@7 --@8        
		'DescuentoPorcentajeLista' = ISNULL(DAR.PorcentajeRegular,0.00) --@6        
	FROM PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header C WITH (NOLOCK)                  
	INNER JOIN PLDB01.SpringUnido.dbo.CO_Interfase_P09_Detalle CD WITH (NOLOCK) ON C.TipoDocumento = CD.TipoDocumento
	AND C.NumeroInterno = CD.NumeroInterno               
	LEFT JOIN PLDB01.SpringUnido.dbo.CO_Documento AS CO WITH (NOLOCK) ON C.IdMatricula = CO.Interfase_Matricula
	AND C.CuotaNumero = CO.Interfase_Cuota
	AND CO.TipoDocumento IN ('BV','FC')
	AND CO.estado <> 'AN'
	AND CO.CompaniaSocio = CD.CompaniaSocio --@2        
	--Inicio @1           
	LEFT JOIN DescuentoAlumnoResultado DAR WITH (NOLOCK) ON DAR.IdMatricula = C.IdMatricula
	AND DAR.Cuota = C.CuotaNumero
	AND ISNULL(C.Grupodescuento,-1) = DAR.GrupoDescuento --@9          
	LEFT JOIN DescuentoAcademico DA WITH (NOLOCK) ON DA.IdDescuentoAcademico = DAR.IdDescuentoAcademico           
	LEFT JOIN DescuentoAcademicoCuota DAC WITH (NOLOCK) ON DAC.IdDescuentoAcademico = DA.IdDescuentoAcademico
	AND DAC.Cuota = DAR.Cuota                                      
	--Fin @1        
	LEFT JOIN PLDB01.SpringUnido.dbo.CO_Precio P WITH (NOLOCK) ON P.ItemCodigo = CD.ItemCodigo
	AND P.UnidadNegocio = C.Sucursal
	AND P.TipoFacturacion = 
	CASE
		WHEN CD.ItemCodigo LIKE '%C%' THEN 'CON'
		ELSE C.TipoFacturacion
	END
	AND P.TipoCliente = C.TipoCliente
	AND P.CompaniaSocio = C.CompaniaSocio --@6        
	WHERE C.IdMatricula = @IdMatricula                    
	AND C.Estado NOT IN ('EL','TR')              
	AND C.TipoDocumento IN ('BV','FC')             
	AND C.CompaniaSocio = @CompaniaSocio  --@2          
	AND CD.CompaniaSocio = @CompaniaSocio --@2
	AND TRIM(C.Cliente) = TRIM(CONVERT(CHAR(15),@IdActor)) --@14
	GROUP BY CuotaNumero,                                
	dbo.fecha(c.FechaVencimiento),                                
	C.Estado,
	DAR.Porcentaje,
	DA.Porcentaje,
	DA.Disponible2,
	DAR.DescuentoNombre,
	DAC.Porcentaje,
	DAC.Nombre,
	C.Grupodescuento,
	C.Estado,
	C.NumeroDocumento,
	DAR.IdDescuentoAcademico,
	DAR.GrupoDescuento,
	CD.NumeroInterno,        
	DAR.EsHomologado,
	DAR.PorcentajeRegular,
	CO.MontoPagado --@6 --@10        
	ORDER BY C.CuotaNumero ASC
	--Fin --@14

END
