----����������������������������������������������������������������������������                                    
--Creado por      :Heber Cachi(25/08/2022)                            
--Funcionalidad   :Valida que exista el monto para curso                   
--Utilizado por   :       
--����������������������������������������������������������������������������           
/*  
-----------------------------------------------------------------------------  
Nro FECHA  USUARIO  DESCRIPCION  
-----------------------------------------------------------------------------  
@1 2022.09.28 EHuillca Se modifica l�gica de validaci�n  
@2 2022.10.04 EHuillca Se agrega nuevo par�metro  
@3 2023.12.06 Illosad  Se agrega parametro @idpromocion a funcion para obtener tipo de cliente  
@4 2024.05.01 FETORRES Se agrega logica para que CA tome la compania socio de ZEGEL.
@5 2024.06.05 MQUIROZ  Se agrega validacion para ITS por compania socio
@6 2025.02.19 ALSANCHEZ	Se quita momentaneamente el precio por C para CA
*/        
ALTER PROCEDURE [dbo].[cCO_Precio_Val_Monto]   
@IdMatricula INT, --@1  
@IdPromocion INT,  
@CompaniaSocio VARCHAR(8),  
@IdGrupo INT = NULL, --@2  
@RetVal VARCHAR(200) OUTPUT, --@1  
@Monto MONEY OUTPUT --@1  

AS  
BEGIN  
 SET NOCOUNT ON;  
  
 SET @RetVal = '' --@1  
 SET @Monto = -1  
  
 DECLARE @ItemCodigo VARCHAR(20)  
   ,@UnidadNegocio VARCHAR(4)  
   ,@TipoCliente VARCHAR(2) --= '01' --Para cursos el tipo cliente siempre es 01 --@1  
   ,@IdSede INT  
   ,@IdPromocionMat INT  
   ,@Servicio CHAR(1)
   ,@CompaniaSocioPadre VARCHAR(8)
    IF @CompaniaSocio='00002600' or @CompaniaSocio = '00002400' --@4 --@5
	BEGIN  
	SELECT @CompaniaSocioPadre=CompaniaSocioPadre FROM Empresa  
	END  
 
 SET @TipoCliente =(Select dbo.cCo_Precio_ObtenerTipoListaPrecio(@IdMatricula,@IdPromocion,@IdGrupo,@CompaniaSocio)) --@1 --@2 --@3 
    
 SELECT @Servicio = TipoServicio, @IdPromocionMat = IdPromocion FROM Matricula WITH(NOLOCK) WHERE IdMatricula = @IdMatricula --@1  
   
 --Seteamos variables segun datos del IdPromocion  
 SELECT @ItemCodigo = ServicioCodigo--REPLACE(ServicioCodigo, 'P', 'C') --@1  
  ,@UnidadNegocio = Sucursal   
  ,@IdSede = P.IdSede  
 FROM Promocion P WITH(NOLOCK)  
 INNER JOIN Sede S WITH(NOLOCK) ON P.IdSede = S.IdSede  
 WHERE IdPromocion = @IdPromocion  
   
 --Inicio @1  
 IF @Servicio = 'C'   
 BEGIN  
  --SET @TipoCliente = '01'
  --SELECT @ItemCodigo = REPLACE(@ItemCodigo,'P','C')   
  SET @TipoCliente =CASE WHEN @CompaniaSocio = '00002600' THEN @TipoCliente ELSE '01'   END--@6
  SELECT @ItemCodigo = CASE WHEN @CompaniaSocio = '00002600' THEN @ItemCodigo ELSE REPLACE(@ItemCodigo, 'P', 'C') END--@6
 END  
  
 IF @Servicio ='M'  
 BEGIN  
  IF @IdPromocion !=@IdPromocionMat  
  BEGIN  
   --SET @TipoCliente = '01'  
   --SELECT @ItemCodigo = REPLACE(@ItemCodigo,'P','C') 
   SET @TipoCliente =CASE WHEN @CompaniaSocio = '00002600' THEN @TipoCliente ELSE '01'   END--@6
   SELECT @ItemCodigo = CASE WHEN @CompaniaSocio = '00002600' THEN @ItemCodigo ELSE REPLACE(@ItemCodigo, 'P', 'C') END--@6
  END  
 END   
 --Fin @1  
   
   IF @CompaniaSocio='00002600' or @CompaniaSocio = '00002400' --@4 --@5
	BEGIN  
	SELECT @CompaniaSocio=CompaniaSocioPadre FROM Empresa  
	END 

 --Busqueda del precio respectivo segun variables seteadas  
 IF @IdSede = 4 --Inicio @1  
 BEGIN  
  IF NOT EXISTS(SELECT DISTINCT 1 FROM CO_Precio_ASOC WITH(NOLOCK) WHERE ItemCodigo = @ItemCodigo AND UnidadNegocio = @UnidadNegocio AND TipoCliente = @TipoCliente AND CompaniaSocio = @CompaniaSocio)  
  BEGIN  
   SET @RetVal = 'SERVICIO: ' + @ItemCodigo + ' - SEDE: ' + @UnidadNegocio + ' - TIPOCLIENTE: ' + @TipoCliente  
  END  
  ELSE  
  BEGIN  
   SET @Monto = (SELECT TOP 1 Monto FROM CO_Precio_ASOC WITH(NOLOCK) WHERE ItemCodigo = @ItemCodigo AND UnidadNegocio = @UnidadNegocio AND TipoCliente = @TipoCliente AND CompaniaSocio = @CompaniaSocio)  
  END    
 END  
 ELSE  
 BEGIN  
  IF NOT EXISTS(SELECT DISTINCT 1 FROM CO_Precio WITH(NOLOCK) WHERE ItemCodigo = @ItemCodigo AND UnidadNegocio = @UnidadNegocio AND TipoCliente = @TipoCliente AND CompaniaSocio = @CompaniaSocio)    
  BEGIN  
   SET @RetVal = 'SERVICIO: ' + @ItemCodigo + ' - SEDE: ' + @UnidadNegocio + ' - TIPOCLIENTE: ' + @TipoCliente  
  END  
  ELSE  
  BEGIN  
   SET @Monto = (SELECT TOP 1 Monto FROM CO_Precio WITH(NOLOCK) WHERE ItemCodigo = @ItemCodigo AND UnidadNegocio = @UnidadNegocio AND TipoCliente = @TipoCliente AND CompaniaSocio = @CompaniaSocio)   
  END   
 END --Fin @1  
  
 SET NOCOUNT OFF;  
END  