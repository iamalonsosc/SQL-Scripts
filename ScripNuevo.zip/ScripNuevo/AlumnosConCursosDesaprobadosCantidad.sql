--SELECT  *FROM promociongrupocierre WHERE IdActor=1641473
--SELECT*FROM alumnoseguimiento where IdAlumno=1641473 AND IdSede=50
--SELECT  *FROM fichaprogramacion-- WHERE IDAL
--SELECT *FROM fichaprogramaciondetalle WHERE IdActor=1641473 AND IdSede=50
--SELECT *FROM solicitudbeca where IdAlumno=1641473


--SELECT*FROM Matricula WHERE IdActor IN (1641473) AND IdSede=50
--IdAlumno
--IdRegistro
--IdCurricula

    SELECT  ACC.IdAlumno,AC.NombreCompleto,PRO.PromocionCodigo,'CantCursosDesaModulo'=Count(ACC.idcurso)--CU.CursoNombre,
    FROM   alumnocurriculacurso ACC WITH(nolock) 
	--INNER JOIN Curso CU WITH(nolock) ON CU.IdCurso=ACC.IdCurso
	INNER JOIN Matricula MA WITH(nolock) ON MA.IdActor=ACC.IdAlumno AND MA.IdRegistro=ACC.IdRegistro AND MA.IdCurricula=ACC.IdCurricula
	INNER JOIN Promocion PRO WITH(nolock) ON PRO.IdPromocion=MA.IdPromocion
	INNER JOIN Periodo PE WITH(nolock) ON PE.IdPeriodo=PRO.IdPeriodo
	INNER JOIN Actor AC WITH(nolock) ON AC.IdActor = ACC.IdAlumno
    WHERE  PE.Codigo='2024-III'
	AND PRO.IdUnidadAcademica=57
	AND MA.EsMatricula=1
	AND MA.Estado <> 'X'
	AND ACC.PromedioCondicion = 'D'
	--AND NombreCompleto='CHICLAYO CHAUCA JHOSSELY GERALDINE'
	GROUP BY AC.NombreCompleto,PRO.PromocionCodigo,ACC.IdAlumno--,CU.CursoNombre
	ORDER BY AC.NombreCompleto



	SELECT  ACC.IdAlumno,AC.NombreCompleto,,PRO.PromocionCodigo,'CantCursosDesaModulo'=Count(ACC.idcurso)--CU.CursoNombre,
    FROM   alumnocurriculacurso ACC WITH(nolock) 
	--INNER JOIN Curso CU WITH(nolock) ON CU.IdCurso=ACC.IdCurso
	INNER JOIN Matricula MA WITH(nolock) ON MA.IdActor=ACC.IdAlumno AND MA.IdRegistro=ACC.IdRegistro AND MA.IdCurricula=ACC.IdCurricula
	INNER JOIN Promocion PRO WITH(nolock) ON PRO.IdPromocion=MA.IdPromocion
	INNER JOIN Periodo PE WITH(nolock) ON PE.IdPeriodo=PRO.IdPeriodo
	INNER JOIN Actor AC WITH(nolock) ON AC.IdActor = ACC.IdAlumno
	
    WHERE  PE.Codigo='2025-I'
	AND PRO.IdUnidadAcademica=57
	--AND MA.EsMatricula=1
	AND MA.Estado <> 'X'
	AND ACC.PromedioCondicion = 'D'
	GROUP BY AC.NombreCompleto,PRO.PromocionCodigo,ACC.IdAlumno--,CU.CursoNombre
	ORDER BY AC.NombreCompleto

