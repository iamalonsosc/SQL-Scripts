--select * from alumno
--(318000 rows affected)

update alumno set EmailInstitucion  =replace(EmailInstitucion,'edu.pe','pe') 

--select * from usuario where EMail  like '%edu.pe%' and IdTipoUsuario = 1
--(283628 rows affected)

update usuario set EMAIL=replace(EMAIL,'edu.pe','pe')
where EMail  like '%edu.pe%' and IdTipoUsuario�=�1