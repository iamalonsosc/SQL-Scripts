--PUICAN LOPEZ FRANCISCA HAYDEE

--COMUNICACI�N 1 
UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40469,Promediofinal=17, PromedioReal=17, PromedioCondicion='A',TipoCondicion='CO', 
Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioSedeCurricula - tkt 53082', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1431032 and  idcurricula=5815 and idcurso in (11602)
--(1 row affected)



DELETE FROM AlumnoCurso where IdAlumno = 1431032 and IdCurricula=5815 
AND IdCurso IN (11602) AND IdMatricula=566243
--(1 row affected)