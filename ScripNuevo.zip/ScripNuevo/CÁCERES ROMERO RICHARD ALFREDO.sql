--SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
--INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
--WHERE AC.IdAlumno=1436458 
----AND AC.IdCurso=10416 
----AND AC.IdCursoOriginal=10416 
--AND AC.IdMatricula=674991 
----AND AC.EsMatricula=1
--order by ac.idregistro,ac.IdAlumnoCurso desc


--SELECT SE.*FROM Seccion SE
--INNER JOIN Promocion PRO ON SE.IdPromocion=PRO.IdPromocion
--WHERE SE.IdPeriodoAnual=2025 
--AND SE.IdCurso=10416 
--AND SE.IdCurricula=5613 
--AND PRO.IdSede=40
--AND PRO.PromocionCodigo LIKE '%2025-I%' 


--ESTRATEGIAS DE PUBLICIDAD Y PROMOCI�N
INSERT INTO AlumnoCurso VALUES (1436458,2,78,5613,10416,674991,97378,2,640944,null,null,'19.00','19.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL
,PromedioFinal='19.00'
,PromedioReal= '19.00'
,IdAlumnoCurso=78
,TipoCondicion='RE'
--select*from AlumnoCurriculaCurso 
where IdAlumno=1436458 and IdCurso=10416 AND IdRegistro=2