
	DECLARE 
		@CuotaNumero INT
		,@GrupoOrigen varchar(100)
		,@CompaniaSocio VARCHAR(8)
		,@IdMatricula INT
		,@GrupoCombinacion INT
		,@MIN INT
		,@MAX INT
		,@p6 nvarchar(max)
		,@IdActor INT
		,@IdTipo INT
		,@NombreCorto varchar(100)
		,@PeriodosValidar VARCHAR(50)

	DECLARE @AlumnosMatriculados TABLE  (
		ID INT IDENTITY(1,1)
		,CuotaNumero INT
		,IdMatricula INT
		,IdActor INT
		,NombreCompleto VARCHAR(250)
		,PromocionNombre VARCHAR(250)
		,PromocionCodigo VARCHAR(250)
		,Periodo VARCHAR(10)
		,IdUnidadAcademica INT
		,GrupoDescuento INT
	);

	DECLARE @AlumnosCumplenRequisitos TABLE  (
		ID INT IDENTITY(1,1)
		,CuotaNumero INT
		,Monto DECIMAL(18,2)
		,GrupoDescuento INT
		,GrupoCombinacion VARCHAR(50)
		,IdMatricula INT
		,IdActor INT
	);

	DECLARE @AlumnosSinDescuento AS TABLE 
		(id int IDENTITY (1,1)
		,IdActor VARCHAR (50)
		,IdMatricula VARCHAR (50)
		,NombreCompleto VARCHAR (250)
		,PromocionNombre VARCHAR(255)
		,PromoCionCodigo VARCHAR(255)
		,Periodo VARCHAR (50)
		,CuotaNumero INT
		,GrupoDescuento INT
	);
	DECLARE @TempPeriodo TABLE
		(CodigoPeriodo VARCHAR(30))


	SELECT @CompaniaSocio=CompaniaSocio FROM  Empresa WITH (NOLOCK)-- SACAMOS LA COMPA�IA
	SELECT @IdTipo = IdMaestroRegistro FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo='DESVALENCIA'-- BUSCAMOS EL TIPO DEL DESCUENTO COMBINACION
	SELECT @NombreCorto  = NombreCorto FROM Empresa WITH (NOLOCK) WHERE IdEmpresa = 1-- BUSCAMOS EL NOMBRE CORTO
	SET @PeriodosValidar = ISNULL((Select Valor from Parametro WITH(NOLOCK) where Nombre='PeriodosValidarDescuento' AND Valor2=@CompaniaSocio AND Activo=1),'')--BUSCAMOS LOS PERIODOS QUE VALIDAREMOS EN IDAT O ZEGEL

	--INSERTAMOS LOS PERIODOS A VALIDAR POR MARCA
	INSERT INTO @TempPeriodo
		SELECT DISTINCT txt_value FROM dbo.uf_Parse(@PeriodosValidar,',')

-- PRIMERO ESTAMOS SACANDO LOS DATOS NECESARIOS DE LA MATRICULA ACTUAL DEL ALUMNO, PARA PODER TENER LAS CUOTAS
 --DATOS DE LA MATRICULA 
	INSERT INTO @AlumnosMatriculados
		SELECT DISTINCT  
		'CuotaNumero' = 3-- COLOCAMOS EN DURO LA CUOTA QUE TENEMOS QUE VALIDARLE EN ESTE CASO LA SEGUNDA CUOTA
		,MA.IdMatricula
		,MA.IdActor
		,AC.NombreCompleto
		,PRO.PromocionNombre
		,PRO.PromocionCodigo
		,PE.Codigo
		,PRO.IdUnidadAcademica
		,DAR.GrupoDescuento
		FROM Matricula MA WITH(NOLOCK)
		INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK)ON MA.IdMatricula=DAR.IdMatricula 
		INNER JOIN Promocion PRO WITH(NOLOCK)ON MA.IdPromocion = PRO.IdPromocion 
		INNER JOIN Periodo PE WITH(NOLOCK)ON PRO.IdPeriodo = PE.IdPeriodo
		INNER JOIN Actor AC WITH(NOLOCK)ON MA.IdActor=AC.IdActor
		WHERE DAR.GrupoDescuento = 1905 --VALIDAMOS QUE SEAN CUOTAS 100% GRATIS
		AND DAR.Cuota = 2 
		AND MA.Estado ='N'
		AND MA.EsMatricula=1
		AND PRO.IdUnidadAcademica IN (60,57)
		AND PRO.IdUnidadNegocio =1
		AND PE.Codigo IN ((Select isnull(CodigoPeriodo,'') FROM @TempPeriodo))--CONSULTAMOS LOS PERIODOS QUE PARAMETRIZAMOS
		AND MA.IdModulo=1
		AND MA.TipoCondicion='RE'
		AND MA.TipoServicio='P'
		--AND MA.MatriculaFecha=GETDATE()
		
	
	INSERT INTO @AlumnosMatriculados
		SELECT DISTINCT  
		DAR.Cuota -- COLOCAMOS LA CUOTA QUE SE LE VA A VALIDAR AL ALUMNO
		,MA.IdMatricula
		,MA.IdActor
		,AC.NombreCompleto
		,PRO.PromocionNombre
		,PRO.PromocionCodigo
		,PE.Codigo
		,PRO.IdUnidadAcademica
		,DAR.GrupoDescuento
		FROM Matricula  MA WITH(NOLOCK)
		LEFT JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON MA.IdMatricula=DAR.IdMatricula
		INNER JOIN Promocion PRO WITH(NOLOCK) ON MA.IdPromocion = PRO.IdPromocion
		INNER JOIN Periodo PE WITH(NOLOCK) ON PRO.IdPeriodo = PE.IdPeriodo 
		INNER JOIN Actor AC WITH(NOLOCK)ON MA.IdActor=AC.IdActor
		WHERE  DAR.GrupoDescuento <> 1905 --VALIDAMOS QUE SEAN CUOTAS DIFERENTES DE GRATIS
		AND  DAR.Cuota = 2
		AND MA.Estado ='N'
		AND MA.EsMatricula = 1
		AND PRO.IdUnidadAcademica IN(60,57)
		AND PRO.IdUnidadNegocio = 1
		AND PE.Codigo IN ((Select isnull(CodigoPeriodo,'') FROM @TempPeriodo))
		AND MA.IdModulo=1
		AND MA.TipoCondicion='RE'
		AND MA.TipoServicio='P'
		--AND MA.MatriculaFecha=GETDATE()
		
 
 --AHORA CON TODA ESA INFORMACION NOS VAMOS A VALIDAR SU DOCUMENTO, SU HEADER, SU MONTO, Y SI SE MERECE O NO EL DESCUENTO 
	INSERT  INTO @AlumnosCumplenRequisitos
		SELECT 
		DA.CuotaNumero,
		CO.MontoTotal,
		CH.GrupoDescuento,
		DAC.GrupoCombinacion,
		DA.IdMatricula,
		DA.IdActor
		FROM @AlumnosMatriculados DA 
		INNER JOIN vw_CO_Interfase_P09_Header CH WITH(NOLOCK) ON DA.IdMatricula = CH.IdMatricula 
		AND DA.CuotaNumero = CH.CuotaNumero
		INNER JOIN vw_CO_Documento CO WITH(NOLOCK) ON DA.IdMatricula = CO.Interfase_Matricula 
		AND DA.CuotaNumero = CO.Interfase_Cuota
		AND SUBSTRING(CH.NumeroDocumento, 4, LEN(CH.NumeroDocumento)) = CO.NumeroDocumento
		AND CH.Estado=CO.Estado
		AND CH.CompaniaSocio=CO.CompaniaSocio
		INNER JOIN DescuentoAcademicoCombinacion DAC WITH(NOLOCK)ON CH.GrupoDescuento = DAC.GrupoDescuento
		AND CO.MontoTotal = DAC.Monto
		AND CH.CuotaNumero = DAC.CuotaNumero
		AND DA.IdUnidadAcademica=DAC.Area
		AND DA.Periodo=DAC.Campana
		AND DAC.IdTipo=@IdTipo
		WHERE CH.Estado IN ('PR')
		AND CO.TipoDocumento = ('PC')
		AND CH.CompaniaSocio = @CompaniaSocio
		
	--PLDB01.SpringUnido.dbo.
	INSERT INTO @AlumnosSinDescuento 
		SELECT  AM.IdActor
		,AM.IdMatricula
		,AM.NombreCompleto
		,AM.PromocionNombre
		,AM.PromocionCodigo
		,AM.Periodo
		,AM.CuotaNumero
		,AM.GrupoDescuento
		FROM @AlumnosMatriculados AM
		WHERE NOT EXISTS (SELECT 1 FROM @AlumnosCumplenRequisitos ACR WHERE ACR.IdMatricula = AM.IdMatricula AND ACR.CuotaNumero = AM.CuotaNumero)

	SELECT @MIN = MIN(ID), @MAX = MAX(ID) from @AlumnosCumplenRequisitos
	--CREAMOS EL WHILE EN DONDE SE VAN A PROCESAR EL NUEVO DESCUENTO ASIGNADO PARA EL ALUMNO
	WHILE @MIN <= @MAX
	BEGIN

		SET @IdMatricula = NULL 
		SET @CuotaNumero=NULL
		SET @GrupoCombinacion=NULL
		SET @GrupoOrigen=NULL
		SET @IdActor=NULL
		SELECT @CuotaNumero=CuotaNumero,@IdMatricula=IdMatricula,@GrupoCombinacion=GrupoCombinacion,@GrupoOrigen=GrupoDescuento,@IdActor=IdActor FROM @AlumnosCumplenRequisitos WHERE ID = @Min

		--ACTUALIZAMOS EL DESCUENTO EN DESCUENTOALUMNO Y DESCUENTOALUMNORESULTADO ADICIONAL TAMBIEN SE ACTUALIZA SU HEADER Y SU CO DOCUMENTO
		exec cDescuentoAlumno_Upd_ProcesoForzado 
		@IdMatricula=@IdMatricula
		,@Cuota=@CuotaNumero
		,@GrupoDescuento=@GrupoCombinacion
		,@UsuarioCreacion=446639
		,@EsVencimiento=0
		,@RetVal=@p6 output
		,@CompaniaSocio=@CompaniaSocio
		print @p6

		SET @Min=@Min+1
	END


	--AHORA VALIDAMOS EL ENVIO DE LOS ALUMNOS QUE NO CUMPLEN LOS REQUISITOS PARA ASIGNARLE UN DESCUENTO (NO CUENTAN CON EQUIVALENCIAS)
	--IF EXISTS (SELECT 1 FROM @AlumnosSinDescuento)
	--BEGIN
	
	--	DECLARE   @SinDescuentoMin int
	--			  ,@SinDescuentoMax int
	--			  ,@SinDescuentoIdActor VARCHAR(50)
	--			  ,@SinDescuentoIdMatricula VARCHAR(50)
	--			  ,@SinDescuentoNombreCompleto VARCHAR (255)
	--			  ,@SinDescuentoPromocionNombre VARCHAR (255)
	--			  ,@SinDescuentoPromocionCodigo VARCHAR (255)
	--			  ,@SinDescuentoPeriodo VARCHAR (255)
	--			  ,@tableHTML  NVARCHAR(MAX)

	--	SELECT @SinDescuentoMin = min(id), @SinDescuentoMax = max(id) from @AlumnosSinDescuento 

	--	SET @tableHTML = '<H2>Env�o de Alumnos sin equivalencias: <br></H2><table border = "1">' 

	--	SET @tableHTML = @tableHTML + '<table style="width:100%">
	--								  <tr>
	--									<th style="border: 1px solid black;">IdActor</th>
	--									<th style="border: 1px solid black;">IdMatricula</th>
	--									<th style="border: 1px solid black;">NombreCompleto</th> 
	--									<th style="border: 1px solid black;">PromocionNombre</th> 
	--									<th style="border: 1px solid black;">PromocionCodigo</th> 
	--									<th style="border: 1px solid black;">Perido</th> 
	--								  </tr>'

	--	WHILE @SinDescuentoMin <= @SinDescuentoMax  
	--	BEGIN

	--		SET @SinDescuentoIdActor = NULL
	--		SET @SinDescuentoIdMatricula = NULL
	--		SET @SinDescuentoNombreCompleto = NULL
	--		SET @SinDescuentoPromocionNombre = NULL
	--		SET @SinDescuentoPromocionCodigo = NULL
	--		SET @SinDescuentoPeriodo = NULL

	--		SELECT @SinDescuentoIdActor=IdActor
	--		,@SinDescuentoIdMatricula=IdMatricula
	--		,@SinDescuentoNombreCompleto=NombreCompleto
	--		,@SinDescuentoPromocionNombre=PromocionNombre
	--		,@SinDescuentoPromocionCodigo=PromoCionCodigo
	--		,@SinDescuentoPeriodo=Periodo
	--		FROM @AlumnosSinDescuento 

	--		WHERE ID = @SinDescuentoMin  

	--			SET @tableHTML  = @tableHTML  +  '<tr>'
	--			SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoIdActor +'</td>'
	--			SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoIdMatricula +'</td>'
	--			SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoNombreCompleto +'</td>'
	--			SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoPromocionNombre +'</td>'
	--			SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoPromocionCodigo +'</td>'
	--			SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoPeriodo +'</td>'
	--			SET @tableHTML  = @tableHTML  +  '</tr>'
				
	--	SET @SinDescuentoMin = @SinDescuentoMin + 1  
	--	END 
		
	--	SET @tableHTML = @tableHTML + '</table>' 

	--	DECLARE @CorreosDestinatarios varchar(500), @body varchar(max), @subject varchar(150)

	--	SELECT @CorreosDestinatarios =  ListaCorreoUno  , 
	--	@body = REPLACE(CabeceraMensaje ,'[Tabla]',@tableHTML)  , 
	--	@subject = REPLACE(AsuntoMensaje , '[Empresa]' , @NombreCorto )   
	--	FROM Correo WITH(NOLOCK) WHERE Nombre = 'AlertaAlumnosSinDescuento' 


	--	EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar 
	--	@recipients = @CorreosDestinatarios, 
	--	@profile_name = 'Smart',             
	--	@subject = @subject,                
	--	@body =  @body,     
	--	@body_format = 'HTML' ;

	--END 