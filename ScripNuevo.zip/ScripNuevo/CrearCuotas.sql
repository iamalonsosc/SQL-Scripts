--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678625)
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20250208','INF','MAT','0001',1760465,NULL,'202502FC','LO','IDTV',NULL,'20250107','GE','M',NULL,0,678625,'B640',NULL,1,NULL,NULL,'2025-02',3941,54,NULL,'N','P','Q','20250107',1,NULL,NULL,'N','20250107',3378,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
--(1 row affected)
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20250416','INF','NOR','0001',1760465,NULL,'202502FC','LO','IDTV',NULL,'20250107','GE','M',NULL,0,678625,'B640',NULL,3,NULL,NULL,'2025-02',3941,54,NULL,'N','P','Q','20250107',1,NULL,NULL,'N','20250107',3378,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
----(1 row affected)

--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678656)
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20250208','INF','MAT','0001',1760651,NULL,'202502FC','LO','IDTV',NULL,'20250107','GE','M',NULL,0,678656,'B640',NULL,1,NULL,NULL,'2025-02',3941,54,NULL,'N','P','Q','20250107',1,NULL,NULL,'N','20250107',3378,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
--(1 row affected)
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20250416','INF','NOR','0001',1760651,NULL,'202502FC','LO','IDTV',NULL,'20250107','GE','M',NULL,0,678656,'B640',NULL,3,NULL,NULL,'2025-02',3941,54,NULL,'N','P','Q','20250107',1,NULL,NULL,'N','20250107',3378,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
----(1 row affected)


--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678611)
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20250208','INF','MAT','0001',1760607,NULL,'202502FC','LO','IDTV',NULL,'20250107','GE','M',NULL,0,678611,'B640',NULL,1,NULL,NULL,'2025-02',3941,54,NULL,'N','P','Q','20250107',1,NULL,NULL,'N','20250107',3378,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
--(1 row affected)
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20250416','INF','NOR','0001',1760607,NULL,'202502FC','LO','IDTV',NULL,'20250107','GE','M',NULL,0,678611,'B640',NULL,3,NULL,NULL,'2025-02',3941,54,NULL,'N','P','Q','20250107',1,NULL,NULL,'N','20250107',3378,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
----(1 row affected)

DECLARE @NumeroInterno1 INT,@NumeroInterno2 INT,@NumeroInterno3 INT,@NumeroInterno4 INT,@NumeroInterno5 INT,@NumeroInterno6 INT

SELECT @NumeroInterno1 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678625) AND CuotaNumero=1
SELECT @NumeroInterno2 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678625) AND CuotaNumero=3

SELECT @NumeroInterno3 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678656) AND CuotaNumero=1
SELECT @NumeroInterno4 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678656) AND CuotaNumero=3

SELECT @NumeroInterno5 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678611) AND CuotaNumero=1
SELECT @NumeroInterno6 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678611) AND CuotaNumero=3

--SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (12520297,12519775,12519579)

--PRIMER CASO
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno1,2,'S','Y54P149640','1.00','','GE','346.33','346.00',3,NULL,'00002700','DESIDAT',GETDATE(),'')
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno2,3,'S','Y54P149640','1.00','','GE','346.33','346.00',3,NULL,'00002700','DESIDAT',GETDATE(),'')

--SEGUNDO CASO
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno3,2,'S','Y54P149640','1.00','','GE','346.33','346.00',3,NULL,'00002700','DESIDAT',GETDATE(),'')
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno4,3,'S','Y54P149640','1.00','','GE','346.33','346.00',3,NULL,'00002700','DESIDAT',GETDATE(),'')

--TERCER CASO
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno5,2,'S','Y54P149640','1.00','','GE','346.33','346.00',3,NULL,'00002700','DESIDAT',GETDATE(),'')
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno6,3,'S','Y54P149640','1.00','','GE','346.33','346.00',3,NULL,'00002700','DESIDAT',GETDATE(),'')



SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678625)
SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678656)
SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (678611)

SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=678625 AND CompaniaSocio='00002700')
SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=678656 AND CompaniaSocio='00002700')
SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=678611 AND CompaniaSocio='00002700')