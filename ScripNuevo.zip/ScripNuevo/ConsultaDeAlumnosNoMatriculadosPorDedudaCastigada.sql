DECLARE @IdActorTem INT=null,@DocumentoCastigados NVARCHAR(255)=null, @MAX INT ,@MIN INT


CREATE TABLE #TablaTemporal (
  ID INT IDENTITY,
  IdActor INT,
  IdMatricula INT,
  IdSede INT,
  NombreCompleto NVARCHAR(255),
  CodigoAnterior NVARCHAR(255),
  PromocionCodigo NVARCHAR(255),
  Codigo NVARCHAR(255),
  TipoDocumento NVARCHAR(255),
  NumeroDocumento NVARCHAR(255),
  DocumentosCastigados NVARCHAR(255),
  FechaPago DATETIME,
  InscritoFecha DATETIME
);


INSERT INTO #TablaTemporal
SELECT ACT.IdActor,MA.IdMatricula,MA.IdSede,ACT.NombreCompleto,ALM.CodigoAnterior,PRO.PromocionCodigo,PER.Codigo,
COD.TipoDocumento,COD.NumeroDocumento,'',COD.FechaDocumento AS FechaPago,MA.InscritoFecha 
FROM Matricula MA
INNER JOIN Promocion PRO ON MA.IdPromocion=PRO.IdPromocion
INNER JOIN Periodo PER ON  MA.IdPeriodo=PER.IdPeriodo
INNER JOIN Actor ACT ON MA.IdActor=ACT.IdActor
INNER JOIN Alumno ALM ON MA.IdActor=ALM.IdAlumno
INNER JOIN CO_Documento COD ON MA.IdMatricula=COD.Interfase_Matricula AND COD.Interfase_Cuota=1 
AND COD.TipoFacturacion='MAT' AND
COD.Estado='CO'
WHERE PER.IdPeriodoAnual=2023 AND MA.EsMatricula=0 AND MA.Estado='N' AND 
EXISTS(SELECT*FROM CO_Interfase_P09_Header  CIH WHERE CIH.IdMatricula=MA.IdMatricula 
AND CIH.TipoFacturacion='MAT' AND CIH.Estado='CO')
ORDER BY 11


SELECT @MIN=MIN(ID), @MAX=MAX(ID) FROM #TablaTemporal 

WHILE @MIN<=@MAX
BEGIN
	SET @IdActorTem = NULL
	SET @DocumentoCastigados=NULL

	SELECT @IdActorTem = IdActor FROM #TablaTemporal WHERE ID = @MIN
	
	IF EXISTS (SELECT DISTINCT 1 FROM vw_Deudas WITH (NOLOCK) WHERE PersonaAnt = CONVERT(VARCHAR, @IdActorTem) 
	
       AND CONVERT(VARCHAR, FechaVencimiento, 112) < CONVERT(VARCHAR, ISNULL(null, getdate()), 112) AND EstadoDeuda='Castigada') 
	 BEGIN
	  
	set @DocumentoCastigados=( SELECT string_agg(Tipo+numerodocumento,';') FROM vw_Deudas WITH (NOLOCK) WHERE PersonaAnt = CONVERT(VARCHAR, @IdActorTem) 
       AND CONVERT(VARCHAR, FechaVencimiento, 112) < CONVERT(VARCHAR, ISNULL(null, getdate()), 112) AND EstadoDeuda='Castigada')
	
    UPDATE #TablaTemporal  SET DocumentosCastigados=@DocumentoCastigados WHERE ID = @MIN

END
 

	
SET @MIN=@MIN+1

END
SELECT*FROM #TablaTemporal
ORDER BY 12


DROP TABLE #TablaTemporal