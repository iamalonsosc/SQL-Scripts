update CO_Documento set ClienteNumero = '1119565' , ClienteNombre = 'CONDORI HUAMAN RUTH MAGDALENA' ,
ClienteDireccion = 'AV DEFENSORES DEL MORRO MZ E LT 1A URB LA CAMPI�A',
ClienteCobrarA = '1119565'
where ClienteRUC = '75286785' and Estado <> 'AN'
--(7 rows affected)