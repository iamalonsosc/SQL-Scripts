--------------------------------------------------------------                            
--Creado por      : Israel Lopez (20/09/2012)                            
--Funcionalidad   : Permite recuperar los registro para la generaciON de Actas Consolidadas          
--Utilizado por   : NotaReporte.cActaConsolidada_Sel                            
--------------------------------------------------------------                            
/*              
-----------------------------------------------------------------------------              
Nro  FECHA  USUARIO  DESCRIPCION              
-----------------------------------------------------------------------------             
@1  06/02/2013 mfernandez  error no se podria convertir '16.00' en int, se paso los 0 en '0'          
@2  06/02/2013 ilopeza  se agrega distinct          
@3  23.04.2013 ilopeza  se cambia la fecha de fin          
@4  20.09.2013 ilopez  se quita el filtro de los cursos virtuales, se reemplaza '-' por ' '          
@5  23.09.2013 mfernandez se agregan 2 campos nuevos a la consulta          
@6  02.10.2013 ilopez  se quitan los duplicados en caso de los repitentes del curso          
@7  18.03.2014 ilopez  se agrega la condiciON que las notas convalidadas salgan asi el alumno se haya retirado del curso          
@8  07.08.2015 pzapata  se modific�Ela forma del c�lculo del "promedioponderado" y el nombre del semestre.          
@9  12.08.2015 pzapata  se modific�Ela forma del obtener la nota del curso "PromedioCurso" para evitar que se muestren notas del semestre anterior.          
@10  14.08.2015 pzapata  se agreg�Ecampo TipoCondiciON   
@11  27.08.2016 se agrega la opciON de guardar la actas en tabla ActasSemestrales y la condiciON de actualizar la tabla o solo consultar en caso de que el periodo este cerrado        
@12 22.09.2017 ilopez se carga el nombrecorto del producto   
@13 26.08.2019 Nicolas Huanca Pastor (Sigcomt) Se agregaron los campos: NombreIES,Direccion2,NombreDirectorGeneral,NombreSecretarioAcademico,TipoGestion,DREGRE,TipoSede  
@14 02.10.2019 Jnavia se valida equivalencias agregando el IdCursoOriginal  
@15 21.11.2019 JRAVICHAGUA Se cambia de longitud en parametro PromocionCodigo a 30  
@16 26.03.2020 Jleo		Se regulariza b�squeda de Unidad Negocio- Unidad Acad�mica  
@17 26.03.2021 Rsamame		Baja Academica se agrega en el Case
@18 01.12.2022 EHuillca Se coloca ISNULL a campo cursonombreoficial
@19 27.07.2022 Alsanchez Traer nota del historial de notas
@20	04.08.2023 EHuillca - Se agrega validaci�n para que tome en cuenta a los cursos convalidados de tipo AM
@21	05.09.2023 Alsanchez  Se agrega isnull para el campo EsElectivo
@22	28.09.2023 Alsanchez  Se retira isnull para el campo EsElectivo
@23 11.07.2024 Fmartinez  Se agrega el procesado de actas JSON
@24	15.07.2024 Alsanchez  Se agrega condicion solo para cursos matriculados
@25	04.03.2025 Alsanchez  Se cambia el "-" por un "/" para la separacion de los nombres en el reporte 
@26 28.02.2025 Ralcantara Se agrega campos para nuevo formano JSON Minedu 
@27 27.10.2025 Illosad	  Se agrega campos a observaciones y usuario de creacion  
@28 04.12.2025 Illosad	  Se descomenta variable para validar cierre de periodo y se agrega valor para procesar
@29	27.01.2026 Alsanchez		Se agrega nueco campo OBSERVACION
*/             
ALTER PROCEDURE [dbo].[cActaConsolidada_Sel]                          
--DECLARE
@IdEmpresa INT,               
@IdSede INT,               
@IdFacultad INT,               
@IdUnidadAcademica INT,               
@IdUnidadNegocio INT,               
@IdPeriodo INT,               
@IdProducto INT,      
@Migracion INT = 0,	----VALOR PARA MIGRAR       
@usuario INT,	--@27
@Procesa char(1) -- @28
AS              
BEGIN              
	SET NOCOUNT ON              
      
	DECLARE @PCerrado INT,       
	@PeriodoCodigo VARCHAR(50),       
	@nformativo VARCHAR(50),      
	@codigoModular VARCHAR(50),      
	@NotaDefault CHAR(4),      
	@Id INT,      
	@IdAlumno INT,      
	@IdRegistro INT,      
	@IdCurricula INT,      
	@IdModulo INT,      
	@NroRD varchar(100),      
	@IdModuloCo int,    
	@FechaAutori varchar(100),    
	@FechaReva varchar(100),  
	--Para el reporte de Registro de Matricula  
	@NombreIES varchar(200),--Valor 6 Paramentro nomina 1  --@13  
	@Direccion2 varchar (500), --Valor8 Paramentro nomina 1 --@13  
	@TipoGestion varchar(200),--Valor 6 Paramentro nomina 2 --@13  
	@TipoSede varchar (500), --Valor8 Paramentro nomina 2 --@13  
	@NombreDirectorGeneral varchar (1000),    --Valor Paramentro nomina 1 --@13  
	@NombreSecretarioAcademico varchar (1000), --Valor7 Paramentro nomina 1 --@13  
	@DREGRE varchar (1000) --Valor7 Paramentro nomina 2 --@13  
 
	DECLARE @AlumnoActaAgrupado TABLE 
	(      
		Id INT IDENTITY,      
		IdAlumno INT,      
		IdRegistro INT,      
		IdCurricula INT,      
		IdModulo INT
	) 
      
	DECLARE @CurriculaCurso TABLE (     
		IdSede INT,        
		IdPeriodo INT,              
		IdPromociON INT,               
		PromocionCodigo VARCHAR(30),--@15               
		IdGrupo INT,               
		GrupoCodigo VARCHAR(20),               
		TurnoCodigo VARCHAR(20),   
		TurnoNombre VARCHAR(100),              
		IdCurricula INT,               
		IdCurso INT,               
		CursoCodigo VARCHAR(10),               
		CursoNombreOficial VARCHAR(200),              
		CursoCredito REAL,               
		IdTipo INT, --@5              
		CursoTipo VARCHAR(100), --@5              
		IdModulo INT,               
		ModuloNombre VARCHAR(200),              
		CodigoFacilitador VARCHAR(20),               
		Nombrefacilitador VARCHAR(150),              
		FechaInicio VARCHAR(100),              
		FechaFin VARCHAR(100),              
		PeriodoNombre VARCHAR(100),              
		Orden VARCHAR(2)  ,            
		Extra INT,      
		IdCertificado INT,      
		MaxModulo INT)        
      
	SET @PCerrado=0         
	SET @PeriodoCodigo = ''         
	SET @nformativo =''      
	SET @codigoModular =''      
	SET @NotaDefault = '''---'      
        
	SELECT @PeriodoCodigo=Codigo , @PCerrado=EsCierre --@28
	FROM Periodo       
	WHERE IdPeriodo=@IdPeriodo         
    
	IF isnull(@Procesa,0) = 1 
	BEGIN      
		IF @PCerrado=0 OR @Migracion=1 ---Si el periodo esta abierto      
		BEGIN      
 
			--se crea una tabla que contiene las promociones, secciones, modulo, cursos de la curricula y el facilitador que dicta cada curso       
			SELECT @nformativo=ISNULL(ESP.Valor4,''),              
			@codigoModular=ISNULL(ESP.Valor5,''),    
			@FechaAutori= ISNULL(ESP.Valor3,''),  
			@NombreIES = ISNULL(ESP.Valor6,''),         --@13  
			@Direccion2 =  ISNULL(ESP.Valor8,''),       --@13         
			@NombreDirectorGeneral =  ISNULL(ESP.Valor,''),       --@13  
			@NombreSecretarioAcademico =  ISNULL(ESP.Valor7,'')       --@13  
			FROM ParametroUnidadAcademica ESP WITH (NOLOCK)                
			WHERE ESP.IdEmpresa=@IdEmpresa              
			AND ESP.IdSede=@IdSede              
			AND ESP.Nombre='ParametroNomina1'        
			AND (ESP.IdProducto = @IdProducto OR @IdProducto = 0)        
      
			SELECT @FechaReva= ISNULL(ESP.Valor3,''),  
			@TipoGestion = ISNULL(ESP.Valor6,''),      --@13  
			@DREGRE = ISNULL(ESP.Valor7,''),      --@13  
			@TipoSede =  ISNULL(ESP.Valor8,'')   --@13             
			FROM ParametroUnidadAcademica ESP WITH (NOLOCK)                
			WHERE ESP.IdEmpresa=@IdEmpresa              
			AND ESP.IdSede=@IdSede              
			AND ESP.Nombre='ParametroNomina2'        
			AND (ESP.IdProducto = @IdProducto OR @IdProducto = 0)     
      
              
			--se carga la tabla temporal              
			INSERT INTO @CurriculaCurso       
			(IdSede,IdPeriodo,IdPromocion, PromocionCodigo, IdGrupo, GrupoCodigo, TurnoCodigo, TurnoNombre,IdCurricula, IdCurso, CursoCodigo, CursoNombreOficial,CursoCredito,       
			IdTipo, CursoTipo, IdModulo, ModuloNombre, CodigoFacilitador, Nombrefacilitador, FechaInicio, FechaFin, PeriodoNombre, Orden,Extra,IdCertificado,MaxModulo)              
			SELECT DISTINCT  ACN.IdSede,ACN.IdPeriodo,1 IdPromocion,'' PromocionCodigo ,1  IdGrupo, '' GrupoCodigo,    
			'TurnoCodigo'='','TurnoNombre'='',             
			acn.IdCurricula,CC.IdCurso,CU.CursoCodigo,CC.CursoNombreOficial,CC.CursoCredito,CC.IdTipo,'CursoTipo'=MTR2.Nombre,CC.IdModulo,ISNULL(MTR3.Codigo,''),      
			NULL,NULL,convert(varchar,Per.Inicio,103),convert(varchar,Per.Fin,103),NULL,Convert(varchar(2),CC.Orden),CC.Orden,TMP.IdCertificado,TMP.IdModulo      
			FROM AlumnoCursoNomina ACN  WITH(NOLOCK)        
			INNER JOIN Periodo PER   WITH(NOLOCK) ON ACN.IdPeriodo = PER.IdPeriodo      
			LEFT OUTER JOIN CurriculaModulo CM WITH(NOLOCK) ON ACN.IdModulo=CM.IdModulo AND ACN.IdCurricula=CM.IdCurricula           
			LEFT JOIN MaestroTablaRegistro MTR3 WITH(NOLOCK) ON CM.IdTipoModulo = MTR3.IdMaestroRegistro             
			INNER JOIN Curricula C WITH(NOLOCK) ON ACN.IdCurricula = C.IdCurricula              
			INNER JOIN CurriculaCurso CC WITH(NOLOCK) ON ACN.IdCurricula = CC.IdCurricula AND ACN.IdModulo=CC.IdModulo AND aCN.IdCurso = cc.IdCurso    
			INNER JOIN Curso CU WITH(NOLOCK) ON CC.IdCurso = CU.IdCurso                  
			LEFT JOIN MaestroTablaRegistro MTR2 WITH(NOLOCK) ON CC.IdTipo = MTR2.IdMaestroRegistro      
			LEFT JOIN (  SELECT CE.IdCurricula,CE.IdCertificado,CC.IdCurso,'IdModulo'=MAX(CCU.IdModulo)      
			FROM Certificado CE WITH(NOLOCK)       
			INNER JOIN CertificadoCurso CC WITH(NOLOCK) ON CE.IdCertificado=CC.IdCertificado      
			INNER JOIN CertificadoCurso CC2 WITH(NOLOCK) ON CC.IdCertificado=CC2.IdCertificado      
			INNER JOIN CurriculaCurso CCU WITH(NOLOCK) ON CCU.IdCurricula=CE.IdCurricula AND CCU.IdCurso=CC2.IdCurso      
			INNER JOIN Curricula CU WITH(NOLOCK) ON CU.IdCurricula=CCU.IdCurricula      
			WHERE CU.IdProducto = @IdProducto        
			GROUP BY CE.IdCurricula,CE.IdCertificado,CC.IdCurso) TMP     
			ON TMP.IdCurricula=acn.IdCurricula AND TMP.IdCurso=CC.IdCurso      
			WHERE acn.IdEmpresa = @IdEmpresa             
			AND acn.IdSede = @IdSede                       
			AND acn.IdPeriodo = @IdPeriodo              
			AND acn.IdProducto = @IdProducto              
			AND C.Estado != 'X'       
			--AND ISNULL(CC.ESELECTivo,0)�=�0   --@21
			AND CC.ESELECTivo�=�0   --@22
			--AND acn.IdModulo=4         
			--AND acn.SeccionNomina = '2.I.12.2016-II-I-F'      
			ORDER BY IdPromociON ,IdGrupo,CC.IdModulo, CC.Orden, CC.CursoNombreOficial    
            
			--se actualiza la temporal cON los nombres de los facilitadores              
			--UPDATE T              
			--SET T.CodigoFacilitador=F.CodigoAnterior,      
			--T.Nombrefacilitador=A.NombreCompleto              
			--FROM @CurriculaCurso T               
			--INNER JOIN SecciON S WITH(NOLOCK) ON T.IdPromocion=S.IdPromociON AND T.IdGrupo=S.IdGrupo AND T.IdCurricula=S.IdCurricula AND T.IdCurso=S.IdCurso      
			--INNER JOIN SeccionProfesor SP WITH(NOLOCK) ON S.IdSeccion=SP.IdSecciON              
			--INNER JOIN Facilitador F WITH(NOLOCK) ON SP.IdActor=F.IdFacilitador              
			--INNER JOIN Actor A WITH(NOLOCK) ON F.IdFacilitador=A.IdActor      
			--WHERE SP.EsResponsable=1            
						--    Select * from @CurriculaCurso return 
			--se llena la temporal del actar --11737              
			--@2        
			SELECT DISTINCT T.IdPromociON            
							,T.PromocionCodigo            
							,T.IdGrupo            
							,T.GrupoCodigo            
							,ACN.Turno TurnoCodigo            
							,ACN.Turno TurnoNombre            
							,T.IdCurricula            
							,T.IdCurso            
							,T.CursoCodigo            
							,'CursoNombreOficial'=T.CursoCodigo+'/'+REPLACE(T.CursoNombreOficial,'/',' ')+'/'+T.CursoTipo+'-'+ISNULL(T.Orden,0) --@18       --@25     
							,'CursoCredito'=ISNULL(T.CursoCredito,0)            
							,T.IdTipo            
							, T.CursoTipo            
							,'IdModulo'=ISNULL(T.IdModulo,0)      
							,'ModuloNombre'=ISNULL(T.ModuloNombre,'')            
							,T.CodigoFacilitador            
							,T.NombreFacilitador            
							,'Seccion'=acn.SeccionNomina--ISNULL(M.Seccion,T.GrupoCodigo)            
							,M.IdMatricula            
							,AL.IdAlumno            
							,'UltimaMatricula'=CONVERT(VARCHAR(50), '-')                 
							,'CodigoAlumno'=AL.CodigoAnterior            
							,'NombreAlumno'=A.NombreCompleto            
							,'Sexo'=CASE WHEN ISNULL(A.Genero,1)=1 THEN 'M' ELSE 'F' END            
							,'DNI'=''''+ISNULL(A.NumeroIdentidad,'')            
							,'CondicionPago'=CASE WHEN M.IdBeca IS NULL THEN 'P' ELSE 'G' END      
							,'PromedioCondicion'=ISNULL(ACC.PromedioCondicion,'D')            
							,'CursosAprobados'=0            
							,'CursosDesaprobados'=0       
							,'EstadoPromovido'=CASE WHEN M.Estado='R' THEN 'RETIRADO ' ELSE '' END            
							,'EstadoMatricula'=CASE WHEN M.Estado='R' THEN 'RETIRADO' WHEN M.Estado='X' THEN 'ANULADO' WHEN M.Estado='B' THEN 'NORMAL' WHEN M.Estado='N' THEN 'NORMAL' END      --@17
							,'EstadoCurso'=CASE WHEN AC.Estado='NO' THEN 'NORMAL' WHEN AC.Estado='RA' THEN 'RETIRO CURSO' WHEN AC.Estado='RC' THEN 'RETIRO CICLO' END      
							,'PromedioCurso'= convert(varchar(200)    
							,
							CASE WHEN M.TipoCondiciON != 'RT' OR CO.Tipo = 'AM' THEN --@20
								CASE WHEN ACC.TipoCondicion='CO'/*@7*/ THEN ISNULL(ACC.PromedioFinal,@NotaDefault)             
								ELSE       
									CASE WHEN AC.Estado='RA' THEN 'DPI'             
									ELSE ISNULL(AC.PromedioFinal,@NotaDefault)    --@19
									END             
								END              
								ELSE ISNULL(AC.PromedioFinal,@NotaDefault)     
							END
							)                     
							,'PromedioPonderado'=CAST(0 AS NUMERIC(5,2))      
							,T.FechaInicio      
							,T.FechaFin     
							,PE.Nombre            
							,'PeriodoCodigoT'=ISNULL(PE.Codigo, '')             
							,T.Orden      
							,M.TipoCondiciON            
							,'NumeroRD'=SPACE(100)      
							,M.IdRegistro,      
							'EFormativa'= '' --Se puso en blanco por solicitud del usuario .    
							--CASE WHEN T.MaxModulo= ISNULL(T.IdModulo,0) THEN      
							-- CASE WHEN ACCE.CumplidasPPP>=ACCE.ACumplirPPP  THEN 'A'       
							-- ELSE 'D'       
							-- END        
							--ELSE ''      
							--END   
							--@26 Inicio
							,'apellido_paterno' = A.Paterno
							,'apellido_materno' = A.Materno
							,'nombres' = A.Nombres
							,'fecha_nacimiento' = A.FechaNacimiento
							,'fecha_ingreso' = PE.Inicio
							,'SeccionNominaMinedu' = REVERSE(LEFT(REVERSE(ACN.SeccionNomina), CHARINDEX('-', REVERSE(ACN.SeccionNomina)) -1))
							--@26 Fin
			INTO #AlumnoActa              
			--FROM @CurriculaCurso T                    
			--INNER JOIN AlumnoCursoNomina ACN WITH(NOLOCK)     
			--ON T.IdCurricula=ACN.IdCurricula AND T.IdModulo=ACN.IdModulo   AND t.idsede = acn.idsede AND t.idperiodo = acn.IdPeriodo    
			--INNER JOIN Matricula M   WITH(NOLOCK) ON M.IdMatricula=ACN.IdMatricula          
			--INNER JOIN AlumnoCurriculaCurso ACC WITH(NOLOCK) ON M.IdActor=ACC.IdAlumno AND M.IdRegistro=ACC.IdRegistro AND M.IdCurricula=ACC.IdCurricula AND T.IdCurso=ACC.IdCurso      
			--INNER JOIN Alumno AL WITH(NOLOCK) ON M.IdActor=AL.IdAlumno        
			--INNER JOIN Actor A WITH(NOLOCK) ON M.IdActor=A.IdActor              
			--LEFT JOIN AlumnoCurso AC WITH(NOLOCK) ON  ACC.IdCurso=AC.IdCurso AND AC.IdMatricula=M.IdMatricula--@6              
			----LEFT JOIN PromociON P WITH(NOLOCK) ON P.IdPromociON = AC.IdPromociON               
			--LEFT JOIN Periodo PE WITH(NOLOCK) ON PE.IdPeriodo = ACN.IdPeriodo       
			--LEFT JOIN AlumnoCurriculaCertificado ACCE WITH(NOLOCK) ON ACCE.IdAlumno=AC.IdAlumno AND ACCE.IdRegistro=AC.IdRegistro AND ACCE.IdCurricula=AC.IdCurricula AND ACCE.IdCertificado=T.IdCertificado -- Nueva fila agregada          
			FROM @CurriculaCurso T                    
			INNER JOIN AlumnoCursoNomina ACN WITH(NOLOCK)     
			ON T.IdCurricula=ACN.IdCurricula     
			AND T.IdModulo=ACN.IdModulo       
			AND t.idsede = acn.idsede     
			AND t.idperiodo = acn.IdPeriodo    
			AND t.idcurso = acn.idcurso    
			INNER JOIN Matricula M   WITH(NOLOCK) ON M.IdMatricula=ACN.IdMatricula          
			INNER JOIN AlumnoCurriculaCurso ACC WITH(NOLOCK) ON M.IdActor=ACC.IdAlumno AND M.IdRegistro=ACC.IdRegistro AND M.IdCurricula=ACC.IdCurricula AND T.IdCurso=ACC.IdCurso      
			LEFT JOIN Convalidacion CO WITH(NOLOCK) ON ACC.IdConvalidacion = CO.IdConvalidacion --@20
			INNER JOIN Alumno AL WITH(NOLOCK) ON ACN.IdActor=AL.IdAlumno              
			INNER JOIN Actor A WITH(NOLOCK) ON ACN.IdActor=A.IdActor              
			LEFT JOIN AlumnoCurso AC WITH(NOLOCK) ON  ACn.IdCurso=ISNULL(AC.IdCursoOriginal,AC.IdCurso) AND ACn.IdMatricula=ac.IdMatricula AND AC.EsMatricula=1--@14  @24       
			----LEFT JOIN PromociON P WITH(NOLOCK) ON P.IdPromociON = AC.IdPromociON               
			INNER JOIN Periodo PE WITH(NOLOCK) ON PE.IdPeriodo = ACN.IdPeriodo       
			LEFT JOIN AlumnoCurriculaCertificado ACCE WITH(NOLOCK) ON ACCE.IdAlumno=AC.IdAlumno AND ACCE.IdRegistro=AC.IdRegistro AND ACCE.IdCurricula=AC.IdCurricula AND ACCE.IdCertificado=T.IdCertificado -- Nueva fila agregada              
 
      
			SELECT DISTINCT 1 IdPromociON            
							,'' PromocionCodigo            
							,1 IdGrupo            
							,'' GrupoCodigo            
							,ACN.Turno TurnoCodigo            
							,ACN.Turno TurnoNombre            
							,ACN.IdCurricula            
							,t.IdCurso            
							,T.CursoCodigo            
							,'CursoNombreOficial'=T.CursoCodigo+'/'+REPLACE(T.CursoNombreOficial,'/',' ')+'/'+T.CursoTipo+'-'+ISNULL(T.Orden,0) --@18       @25    
							,'CursoCredito'=ISNULL(T.CursoCredito,0)            
							,T.IdTipo            
							, T.CursoTipo            
							,'IdModulo'=ISNULL(T.IdModulo,0)      
							,'ModuloNombre'=ISNULL(T.ModuloNombre,'')        
							,T.CodigoFacilitador            
							,T.NombreFacilitador            
							,'Seccion'=acn.SeccionNomina--ISNULL(M.Seccion,T.GrupoCodigo)            
							,ACN.IdMatricula            
							,AL.IdAlumno            
							,'UltimaMatricula'=CONVERT(VARCHAR(50), '-')                 
							,'CodigoAlumno'=AL.CodigoAnterior            
							,'NombreAlumno'=A.NombreCompleto            
							,'Sexo'=CASE WHEN ISNULL(A.Genero,1)=1 THEN 'M' ELSE 'F' END            
							,'DNI'=''''+ISNULL(A.NumeroIdentidad,'')            
							,'CondicionPago'='P'     
							,'PromedioCondicion'=ISNULL(dbo.fnGetPromedioCondicion(ca.IdAlumno, ca.IdRegistro, ca.IdCurso, ca.Nota), '~') --ISNULL(CA.PromedioCondicion,'D')--    
							,'CursosAprobados'=0            
							,'CursosDesaprobados'=0       
							,'EstadoPromovido'= 'PROMOVIDO'          
							,'EstadoMatricula'= 'NORMAL'     
							,'EstadoCurso'='NORMAL'      
							,'PromedioCurso'= convert(varchar(200),ca.Nota)                
							,'PromedioPonderado'=CAST(0 AS NUMERIC(5,2))      
							,T.FechaInicio      
							,T.FechaFin            
							,PE.Nombre            
							,'PeriodoCodigoT'=ISNULL(PE.Codigo, '')             
							,T.Orden      
							,TipoCondiciON = 'RE'             
							,'NumeroRD'=SPACE(100)      
							,CA.IdRegistro,      
							'EFormativa'= ''
							--@26 Inicio
							,'apellido_paterno' = A.Paterno
							,'apellido_materno' = A.Materno
							,'nombres' = A.Nombres
							,'fecha_nacimiento' = A.FechaNacimiento
							,'fecha_ingreso' = PE.Inicio
							,'SeccionNominaMinedu' = REVERSE(LEFT(REVERSE(ACN.SeccionNomina), CHARINDEX('-', REVERSE(ACN.SeccionNomina)) -1))
							--@26 Fin
			INTO #AlumnoActa2       
			FROM @CurriculaCurso T        
			INNER JOIN AlumnoCursoNomina acn WITH(NOLOCK) ON T.IdCurricula=ACN.IdCurricula AND T.IdModulo=ACN.IdModulo   AND t.idsede = acn.idsede AND t.IdCurso = acn.IdCurso    
			INNER JOIN Cargo c WITH(NOLOCK) ON acn.idsede = c.IdSede AND acn.IdPeriodo = c.idperiodo --AND acn.IdProducto = c.IdProducto    
			INNER JOIN CargoAlumno CA WITH(NOLOCK) ON c.IdCargo = ca.IdCargo AND ca.IdAlumno = acn.IdActor AND ca.IdCurso = acn.IdCurso  --AND ca.IdCurricula = acn.IdCurricula    
			INNER JOIN Matricula M   WITH(NOLOCK) ON M.IdMatricula=ACN.IdMatricula --@26        
			INNER JOIN Alumno AL WITH(NOLOCK) ON acn.IdActor=AL.IdAlumno              
			INNER JOIN Actor A WITH(NOLOCK) ON acn.IdActor=A.IdActor     
			LEFT JOIN Periodo PE WITH(NOLOCK) ON PE.IdPeriodo = ACN.IdPeriodo         
			WHERE c.idsede = @IdSede       
				  AND c.IdPeriodo = @IdPeriodo        
				  --AND c.idProducto = @IdProducto          
    
			insert into #AlumnoActa    
			select * FROM  #AlumnoActa2       
    
			UPDATE TMP SET 
				UltimaMatricula=CASE WHEN TMP.TipoCondiciON = 'RT' THEN        
				isnull((SELECT TOP 1 PE.Codigo                      
			FROM AlumnoCurso AL WITH (NOLOCK)                          
			LEFT JOIN PromociON P WITH (NOLOCK) ON al.IdPromocion=P.IdPromociON                   
			LEFT JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo=PE.IdPeriodo               
			WHERE AL.IdAlumno=TMP.IdAlumno                 
				  AND AL.IdCurricula = TMP.IdCurricula            
				  AND AL.IdMatricula<TMP.IdMatricula            
				  AND AL.PromedioCondicion='A'            
				  AND AL.EsMatricula = 1            
				  AND AL.Estado = 'NO'            
			ORDER BY AL.FechaCreaciON DESC), '')        
			ELSE ''            
			END       
			FROM #AlumnoActa TMP WITH(NOLOCK)              
        
    
			UPDATE TMP SET 
				TMP.CursosDesaprobados=(SELECT COUNT(1)--cantidad de cursos desaprobados               
			FROM #AlumnoActa AC WITH(NOLOCK)              
			WHERE tmp.IdAlumno = ac.IdAlumno      
				  --AND tmp.IdModulo = ac.IdModulo      
				  AND tmp.SecciON = ac.SecciON      
				  AND AC.PromedioCondicion='D'              
				  AND AC.PromedioCurso != @NotaDefault       
				  AND AC.EstadoPromovido!='RETIRADO'),              
			TMP.CursosAprobados=( SELECT COUNT(1)--cantidad de cursos aprobados               
			FROM #AlumnoActa AC WITH(NOLOCK)               
			WHERE tmp.IdAlumno = ac.IdAlumno     
				  --AND tmp.IdModulo = ac.IdModulo    
				  AND tmp.SecciON = ac.SecciON                
				  AND AC.PromedioCondicion='A'              
				  AND AC.PromedioCurso != @NotaDefault       
				  AND AC.EstadoPromovido!='RETIRADO'),        
			TMP.PromedioCurso =CASE WHEN PromedioCurso = @NotaDefault AND UltimaMatricula != '' THEN       
										 @NotaDefault + ','+ UltimaMatricula      
									ELSE PromedioCurso       
									END,            
			TMP.PromedioPonderado=CASE WHEN EstadoMatricula='RETIRADO' THEN 0--se actualiza el promedio  ponderado       
									   ELSE ISNULL(PGC.PromedioReal,0)      
									   END     
			,TMP.EstadoPromovido=CASE WHEN  isnull(TMP.EstadoPromovido,'')='' THEN      
										  CASE WHEN  isnull(TMP.IdModulo,0)<=4 THEN --se actualiza el estado promovido              
										  CASE WHEN isnull(TMP.CursosDesaprobados,0)>=5 THEN 'REPITENTE'       
										  ELSE 'PROMOVIDO'       
										  END              
									  WHEN  isnull(TMP.IdModulo,0)>4 THEN                       
										  CASE WHEN isnull(TMP.CursosDesaprobados,0)>=2 THEN 'REPITENTE'       
										  ELSE 'PROMOVIDO'       
										  END              
									  END             
									  ELSE isnull(TMP.EstadoPromovido,'')      
									  END       
			FROM #AlumnoActa TMP WITH(NOLOCK)              
			LEFT JOIN PromocionGrupoCierre PGC WITH(NOLOCK) ON TMP.IdMatricula=PGC.IdMatricula     
      
			------------------------------------------------------------------------------------------------------------------------  
			update #AlumnoActa set PromedioCurso = PromedioCurso + ','+ UltimaMatricula + ',' + @NotaDefault  
			WHERE UltimaMatricula <> '' AND PromedioCurso <> 'DPI'  
			------------------------------------------------------------------------------------------------------------------------  
      
			--tabla para calcular los RDs      
			DELETE @AlumnoActaAgrupado      
			INSERT INTO @AlumnoActaAgrupado      
			SELECT DISTINCT TMP.IdAlumno,TMP.IdRegistro,TMP.IdCurricula,TMP.IdModulo      
			FROM #AlumnoActa TMP WITH(NOLOCK)      
      
			WHILE EXISTS (SELECT 1 FROM @AlumnoActaAgrupado)      
			BEGIN      
				SELECT TOP 1 @IdAlumno=IdAlumno,@IdRegistro=IdRegistro,@IdCurricula=IdCurricula,@IdModulo=IdModulo      
				FROM @AlumnoActaAgrupado          
				ORDER BY Id      
      
				SELECT @NroRD =''      
      
				SELECT @NroRD = (      
				SELECT top 1  NroRD      
				FROM TrasladoSede WITH(NOLOCK)       
				WHERE IdAlumno = @IdAlumno      
					  AND Estado = 1      
					  AND IDRegistro = @IdRegistro      
					  AND IdPeriodoTraslado=@IdPeriodo      
					  AND NroRD IS NOT NULL      
				ORDER BY FechaCreaciON      
				UNION      
				SELECT  top 1 NroRD      
				FROM CambioProductoCurricula  WITH(NOLOCK)      
				WHERE IdAlumno = @IdAlumno      
					  AND Estado = 1      
					  AND IdCurriculaNueva = @IdCurricula      
					  AND IdCurriculaAnterior!=IdCurriculaNueva      
					  AND IdPeriodo=@IdPeriodo      
					  AND NroRD IS NOT NULL      
				ORDER BY FechaCreaciON      
				UNION      
				SELECT  top 1  NroRD      
				FROM Reingresos WITH(NOLOCK)       
				WHERE IdAlumno = @IdAlumno      
					  AND Estado = 1      
					  AND IdCurriculaNueva = @IdCurricula      
					  AND IdCurriculaAnterior!=IdCurriculaNueva      
					  AND IdPeriodoReingreso=@IdPeriodo      
					  AND NroRD IS NOT NULL      
				ORDER BY FechaCreaciON    
				UNION      
				SELECT  top 1  NroRD      
				FROM ConvalidaciON c WITH(NOLOCK)      
				WHERE c.IdAlumno = @IdAlumno      
					  AND c.IDRegistro = @IdRegistro      
					  AND c.Estado='R'      
					  AND c.tipo = 'TE'      
					  AND IdPeriodoAnual=@IdPeriodo      
					  AND c.NroRD IS NOT NULL      
				ORDER BY FechaCreacion)      
      
				SELECT @IdModuloCo = MAX(IdModulo)      
				FROM AlumnoCurriculaCurso WITH(NOLOCK)      
				WHERE IdAlumno = @IdAlumno       
					  AND IdRegistro = @IdRegistro       
					  AND IdCurricula = @IdCurricula      
					  AND TipoCondiciON = 'CO'      
      
				IF @IdModulo>@IdModuloCo SELECT @NroRD =  ''      
      
				UPDATE #AlumnoActa      
				SET NumeroRD=ISNULL(@NroRD ,'')      
				WHERE IdAlumno=@IdAlumno      
				AND IdRegistro=@IdRegistro      
				AND IdCurricula=@IdCurricula      
				AND IdModulo=@IdModulo      
         
				DELETE @AlumnoActaAgrupado      
				WHERE Id = (SELECT TOP 1 Id FROM @AlumnoActaAgrupado ORDER BY Id)      
			END      
      
			--Se verifica si ya estan generadas las actas      
			--Si no existe las actas generadas cON los valores de ingreso se inserta      
			IF NOT EXISTS ( SELECT 1 FROM ActaConsolidada WITH (NOLOCK) WHERE IdEmpresa= @IdEmpresa       
							AND IdFacultad= @IdFacultad       
							AND IdSede=@IdSede       
							AND IdPeriodo= @IdPeriodo       
							AND IdProducto=@IdProducto       
							AND IdUnidadNegocio=  @IdUnidadNegocio --@16    
							AND IdUnidadAcademica=@IdUnidadAcademica ) --@16     
			BEGIN     
	 
				INSERT INTO ActaConsolidada       
				(EsNuevo,ProductoCodigo,ProductoNombre,IdPromocion,PromocionCodigo,IdGrupo,GrupoCodigo,                
				TurnoCodigo,TurnoNombre,IdCurricula,IdCurso,CursoCodigo,CursoNombreOficial,CursoCredito,IdTipo,CursoTipo,IdModulo,               
				ModuloNombre,CodigoFacilitador,NombreFacilitador,Seccion,IdMatricula,IdAlumno,UltimaMatricula,CodigoAlumno,NombreAlumno,      
				Sexo,DNI,CondicionPago,PromedioCondicion,CursosAprobados,CursosDesaprobados,EstadoPromovido,EstadoMatricula,                  
				EstadoCurso,PromedioCurso,PromedioPonderado,FechaInicio,FechaFin,Nombre,PeriodoCodigoT,Orden,TipoCondicion,NumeroRD,      
				IdRegistro,EFormativa,
				apellido_paterno,apellido_materno,nombres,fecha_nacimiento,fecha_ingreso,SeccionNominaMinedu,-- @26
				SeccionCodigo,PeriodoCodigo,Direccion,Region,Departamento,Provincia,Distrito,NFormativo,      
				FechaFinPeriodo,PeriodoNombre,IdProducto,IdEmpresa,IdSede,IdFacultad,IdUnidadAcademica,IdUnidadNegocio,IdPeriodo,CModular,
				FechaAutoriza,FechaReva,NombreIES,Direccion2,TipoGestion,TipoSede,NombreDirectorGeneral,NombreSecretarioAcademico,DREGRE,
				UsuarioCreacion, FechaCreacion)       --@27

				SELECT DISTINCT 'EsNuevo'=CAST(PR.EsNuevo AS INT)       
								,PR.ProductoCodigo            
								,PR.ProductoNombreCorto      
								,AA.*            
								,'SeccionCodigo'=REPLACE(REPLACE(AA.Seccion,'.',''),'-',''),              
								'PeriodoCodigo'=PE.Codigo            
								,S.DirecciON            
								,'Region'=S.DireccionRegional         
								,'Departamento'= UU.Nombre          
								,'Provincia'=P.Nombre            
								,'Distrito'=D.Nombre          
								,'NFormativo'=@nformativo      
								,'FechaFinPeriodo'=AA.FechaFin      
								,'PeriodoNombre'=PE.Nombre           
								,'IdProducto'=PR.IdProducto      
								,@IdEmpresa as IdEmpresa              
								,@IdSede as IdSede       
								,@IdFacultad as IdFacultad             
								,@IdUnidadAcademica as IdUnidadAcademica           
								,@IdUnidadNegocio as IdUnidadNegocio           
								,@IdPeriodo as IdPeriodo      
								,@codigoModular as CModular    
								,@FechaAutori as FechaAutori   
								,@FechaReva as FechaReva  
								,@NombreIES as NombreIES----@13  
								,@Direccion2 as Direccion2 ----@13  
								,@TipoGestion as TipoGestion----@13  
								,@TipoSede as TipoSede----@13  
								,@NombreDirectorGeneral as NombreDirectorGeneral----@13   
								,@NombreSecretarioAcademico as NombreSecretarioAcademico----@13 
								,@DREGRE as DREGRE----@13  
								,@usuario	--@27
								,GETDATE()	--@27
				FROM #AlumnoActa AA WITH(NOLOCK)              
				INNER JOIN Sede S WITH (NOLOCK) ON S.IdSede=@IdSede              
				INNER JOIN Ubigeo D WITH (NOLOCK) ON S.IdUbigeo=D.IdUbigeo              
				INNER JOIN Ubigeo P WITH (NOLOCK) ON P.IdPais=D.IdPais AND P.IdUbigeo=D.IdDepartamento+D.IdProvincia+'00'         
				INNER JOIN Ubigeo UU WITH (NOLOCK) ON D.IdDepartamento=UU.IdDepartamento AND UU.IdProvincia='00' AND UU.IdDistrito='00'             
				INNER JOIN Periodo PE WITH (NOLOCK) ON PE.IdPeriodo=@IdPeriodo              
				INNER JOIN Producto PR WITH (NOLOCK) ON PR.IdProducto=@IdProducto                      
				ORDER BY AA.orden, AA.Seccion,AA.CursoNombreOficial,AA.NombreAlumno              
      
				SELECT *      
				FROM ActaConsolidada WITH (NOLOCK)      
				WHERE IdEmpresa= @IdEmpresa       
					  AND IdFacultad= @IdFacultad       
					  AND IdSede=@IdSede       
					  AND IdPeriodo= @IdPeriodo       
					  AND IdProducto=@IdProducto       
					  AND IdUnidadNegocio = @IdUnidadNegocio --@16
					  AND IdUnidadAcademica=  @IdUnidadAcademica   --@16
				ORDER BY orden, Seccion,CursoNombreOficial,NombreAlumno       
				----procesamos con el sp nuevo de actas json con los parametros de este sp
				--Inicio @23
				EXECUTE [cProcesa_Acta_JSON_Minedu]
				@IdPeriodoNomina = @IdPeriodo,
				@IdEmpresa = @IdEmpresa,
				@IdSedeNomina = @IdSede ,
				@IdUnidadAcademicaNomina = @IdUnidadAcademica,
				@IdUnidadNegocioNomina = @IdUnidadNegocio,
				@IdProductoNomina = @IdProducto,
				@IdUsuario = @usuario	--@27
				--Fin @23
				DROP TABLE #AlumnoActa       
			END      
			ELSE       
			BEGIN    
 
				DELETE FROM  ActaConsolidada        
				WHERE IdEmpresa= @IdEmpresa       
				AND IdFacultad= @IdFacultad       
				AND IdSede=@IdSede       
				AND IdPeriodo= @IdPeriodo       
				AND IdProducto=@IdProducto       
				AND IdUnidadNegocio=@IdUnidadNegocio  --@16
				AND IdUnidadAcademica=@IdUnidadAcademica   --@16  
				--Inicio @23
				----eliminamos de la tabla nueva de actas json con los parametros del delete ActaConsolidada
				DELETE FROM AlumnoCursoActaJson 
				WHERE IdSede=@IdSede       
				AND IdPeriodo= @IdPeriodo       
				AND IdProducto=@IdProducto       
				AND IdUnidadNegocio=@IdUnidadNegocio
				AND IdUnidadAcademica=@IdUnidadAcademica 				
				----
				--Fin @23
				INSERT INTO ActaConsolidada (EsNuevo,ProductoCodigo,ProductoNombre,IdPromocion,PromocionCodigo,IdGrupo,GrupoCodigo,                
				TurnoCodigo,TurnoNombre,IdCurricula,IdCurso,CursoCodigo,CursoNombreOficial,CursoCredito,IdTipo,CursoTipo,IdModulo,      
				ModuloNombre,CodigoFacilitador,NombreFacilitador,Seccion,IdMatricula,IdAlumno,UltimaMatricula,CodigoAlumno,NombreAlumno,      
				Sexo,DNI,CondicionPago,PromedioCondicion,CursosAprobados,CursosDesaprobados,EstadoPromovido,EstadoMatricula,      
				EstadoCurso,PromedioCurso,PromedioPonderado,FechaInicio,FechaFin,Nombre,PeriodoCodigoT,Orden,TipoCondicion,NumeroRD,      
				IdRegistro,EFormativa,
				apellido_paterno,apellido_materno,nombres,fecha_nacimiento,fecha_ingreso,SeccionNominaMinedu, --@26
				SeccionCodigo,PeriodoCodigo,Direccion,Region,Departamento,Provincia,Distrito,NFormativo,      
				FechaFinPeriodo,PeriodoNombre,IdProducto,IdEmpresa,IdSede,IdFacultad,IdUnidadAcademica,IdUnidadNegocio,IdPeriodo,CModular,
				FechaAutoriza,FechaReva,NombreIES,Direccion2,TipoGestion,TipoSede,NombreDirectorGeneral,NombreSecretarioAcademico,DREGRE,
				UsuarioCreacion, FechaCreacion)       
				SELECT distinct  'EsNuevo'=CAST(PR.EsNuevo AS INT)           
								,PR.ProductoCodigo            
								,PR.ProductoNombreCorto            
								,AA.*            
								,'SeccionCodigo'=REPLACE(REPLACE(AA.Seccion,'.',''),'-',''),              
								'PeriodoCodigo'=PE.Codigo            
								,S.DirecciON            
								,'Region'=S.DireccionRegional         
								,'Departamento'= UU.Nombre          
								,'Provincia'=P.Nombre            
								,'Distrito'=D.Nombre          
								--,'EFormativa' ='A', 12         
								,'NFormativo'=@nformativo,                 
								'FechaFinPeriodo'=AA.FechaFin,              
								'PeriodoNombre'=PE.Nombre,               
								'IdProducto'=PR.IdProducto,      
								@IdEmpresa as IdEmpresa,               
								@IdSede as IdSede,               
								@IdFacultad as IdFacultad,               
								@IdUnidadAcademica as IdUnidadAcademica,               
								@IdUnidadNegocio as IdUnidadNegocio,               
								@IdPeriodo as IdPeriodo,      
								@codigoModular as CModular    
								,@FechaAutori as FechaAutori,    
								@FechaReva as FechaReva  
								,@NombreIES as NombreIES----@13  
								,@Direccion2 as Direccion ----@13  
								,@TipoGestion as TipoGestion----@13  
								,@TipoSede as TipoSede----@13  
								,@NombreDirectorGeneral as NombreDirectorGeneral   ----@13  
								,@NombreSecretarioAcademico as NombreSecretarioAcademico----@13  
								,@DREGRE as DREGRE     ----@13  
								,@usuario
								,getdate()     
				FROM #AlumnoActa AA WITH(NOLOCK)               
				INNER JOIN Sede S WITH (NOLOCK) ON S.IdSede=@IdSede              
				INNER JOIN Ubigeo D WITH (NOLOCK) ON S.IdUbigeo=D.IdUbigeo              
				INNER JOIN Ubigeo P WITH (NOLOCK) ON P.IdPais=D.IdPais AND P.IdUbigeo=D.IdDepartamento+D.IdProvincia+'00'         
				INNER JOIN Ubigeo UU WITH (NOLOCK) ON D.IdDepartamento=UU.IdDepartamento AND UU.IdProvincia='00' AND UU.IdDistrito='00'             
				INNER JOIN Periodo PE WITH (NOLOCK) ON PE.IdPeriodo=@IdPeriodo              
				INNER JOIN Producto PR WITH (NOLOCK) ON PR.IdProducto=@IdProducto                     
				ORDER BY AA.orden, AA.Seccion,AA.CursoNombreOficial,AA.NombreAlumno              
      
				SELECT *      
				FROM ActaConsolidada  WITH (NOLOCK)      
				WHERE IdEmpresa= @IdEmpresa       
					  AND IdFacultad= @IdFacultad       
					  AND IdSede=@IdSede      
					  AND IdPeriodo= @IdPeriodo       
					  AND IdProducto=@IdProducto       
					  AND IdUnidadNegocio= @IdUnidadNegocio     --@16      
					  AND IdUnidadAcademica= @IdUnidadAcademica --@16
				ORDER BY orden, Seccion,--CursoNombreOficial,    
				NombreAlumno COLLATE modern_spanish_ci_as       
				----procesamos con el sp nuevo de actas json con los parametros de este sp
				--Inicio @23
				EXECUTE [cProcesa_Acta_JSON_Minedu]
				@IdPeriodoNomina = @IdPeriodo,
				@IdEmpresa = @IdEmpresa,
				@IdSedeNomina = @IdSede ,
				@IdUnidadAcademicaNomina = @IdUnidadAcademica,
				@IdUnidadNegocioNomina = @IdUnidadNegocio,
				@IdProductoNomina = @IdProducto,
				@IdUsuario = @usuario	--@27
				--Fin @23					
			
				DROP TABLE #AlumnoActa                  
			END      
		END          
		ELSE ---Si el periodo esta cerrado      
		BEGIN       
			SELECT AC.*      
			FROM ActaConsolidada AC WITH (NOLOCK)      
			WHERE IdEmpresa= @IdEmpresa       
				  AND IdFacultad= @IdFacultad       
				  AND IdSede=@IdSede       
				  AND IdPeriodo= @IdPeriodo       
				  AND IdProducto=@IdProducto       
				  AND IdUnidadNegocio= @IdUnidadNegocio     --@16
				  AND IdUnidadAcademica= @IdUnidadAcademica   --@16 
			ORDER BY orden, Seccion,--CursoNombreOficial,    
			NombreAlumno COLLATE modern_spanish_ci_as        
		END    
	END
	ELSE
	BEGIN
		SELECT AC.*      
		FROM ActaConsolidada AC WITH (NOLOCK)      
		WHERE IdEmpresa= @IdEmpresa       
				AND IdFacultad= @IdFacultad       
				AND IdSede=@IdSede       
				AND IdPeriodo= @IdPeriodo       
				AND IdProducto=@IdProducto       
				AND IdUnidadNegocio= @IdUnidadNegocio     --@16
				AND IdUnidadAcademica= @IdUnidadAcademica   --@16 
		ORDER BY orden, Seccion,--CursoNombreOficial,    
		NombreAlumno COLLATE modern_spanish_ci_as       
	END  
	SET NOCOUNT OFF          
END
