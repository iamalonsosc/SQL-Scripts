--����������������������������������������������������������������������������      
--Creado por      :Israel Lopez(24/07/2012)      
--Funcionalidad   :Permite listar la Situacui�n Acad�mica del alumno      
--Utilizado por   :cSituacionAcademica.SelListarLis      
--����������������������������������������������������������������������������      
/*      
-----------------------------------------------------------------------------      
Nro	FECHA		USUARIO		DESCRIPCION      
-----------------------------------------------------------------------------      
@1	13.11.2012	ilopez		se cambio el ordenamiento      
@2	02.04.2013	mfernandez  se agregaron campos para el filtro por curricula-producto      
@3	16.04.2013	ilopez		se agrega filtro por ultimo registro de matricula registrado      
@4	26.04.2013	mfernandez	se incluyo join con registro donde Registro.Estado IN (N,R)      
@5	17.01.2014	ilopez		se muestra la informaci�n del cargo correctamente      
@6	29.01.2014	ilopez		se formatea el nulo de la columna      
@7	07.04.2014	ilopez		Se corrige el error cuando el alumno ha hecho cambio de sedes o productos      
@8	08.05.2014	ilopez		se carga el periodo de cargo solo si aprobo el cargo      
@9	30.04.2015	lciudad		se agrego fecha inicio, fecha fin , codigoo seccion (mejoras Smart 2015)      
@10 09/09/2015	aaurora		Nuevo Reglamento de Extensi�n      
@11 15.09.2016	ilopez		se muestran todas las notas incluyendo las desaprobatorias por cargo      
@12 03/10/2017	ccrisologo	se agrega para que muestre los cursos con estado NO de las matriculas con estado N      
@13 27.03.2018	jnavia		Se agrega los cursos equivalentes      
@14 02.05.2019	LeandroOrdo�ez (Sigcomt) Obtener el tipo de registro seg�n su convalidaci�n.      
@15 17.02.2020	PUchuya		Se agrega logica para listar la malla oficial      
@16 20.04.2021	rpineda		se agrega @IdSeccion    
@17 23.08.2021	Hmora		Se modifica consulta de UnidadAcademica
@18	01.09.2021	EHuillca	Se modifica consulta de registro y validacion en consulta de unidad acad�mica
@19	17.09.2021	EHuillca	Se agrega nueva validaci�n por malla	
@20 2021.11.23	hcachi		Se agrega CASE para Evaluacion Extraordinaria
@21 2022.02.24	hcachi		Se agrega validacion para que no setee variables (@CurIdUnidadAcademica) de matriculas anuladas
@22	30.03.2022	EHuillca	Se modifica relaci�n entre registro con matr�cula para alumnos con nuevas mallas que no se visualiza data.
*/
--CREATE PROCEDURE [dbo].[cSituacionAcademica_Sel_Listar] 
DECLARE
@IdAlumno INT
--AS
BEGIN
	SET NOCOUNT ON
	SELECT @IdAlumno=1254944
	DECLARE @MaxID INT
		,@CurID INT
		,@CurIdAlumno INT
		,@CurIdRegistro INT
		,@CurIdCurricula INT
		,@CurIdCurso INT
		,@CurIdConvalidacion INT
		,@CurPromedioCondicion VARCHAR(20)
		,@CurConvalidacionDescripcion VARCHAR(500)
		,@CurCursoPeriodoCodigo VARCHAR(20)
		,@CurCursoNroVez INT
		,@CurIdUnidadAcademica INT
		,@CurUnidadAcademicaCodigo VARCHAR(10)
		,@CurUnidadAcademicaNombre VARCHAR(200)
		,@CurIdEmpresa INT
		,@CurIdSede INT
		,@CurIdFacultad INT
		,@CurIdUnidadNegocio INT
		,@CurIdProducto INT
		,@FechaInicio DATE
		,@FechaFin DATE
		,@CodigoSeccion VARCHAR(50)
		,@CurSedeNombre VARCHAR(200)
		,@CurFacultadNombre VARCHAR(200)
		,@CurUnidadNegocioNombre VARCHAR(200) --@15      
		,@IdSeccion INT --@16    
		,@IdMatricula INT --@16
		,@IdCurricula INT --@18
		--@7      
	DECLARE @Registro TABLE (
		Id INT IDENTITY
		,IdActor INT
		,IdRegistro INT
		,IdEmpresa INT
		,IdSede INT
		,IdFacultad INT
		,IdUnidadNegocio INT
		,IdProducto INT
		,IdCurricula INT --@18
		)

	--SE CARGA LA TABLA DE REGISTROS CON LOS UN UNICO PRODUCTO SI ESTE SE REPITE EN LA MISMA SEDE      
	INSERT INTO @Registro
	SELECT R.IdActor
		,NULL
		,R.IdEmpresa
		,R.IdSede
		,IdFacultad
		,IdUnidadNegocio
		,IdProducto
		,M.IdCurricula
	FROM Registro R WITH (NOLOCK)
	LEFT JOIN Matricula M WITH (NOLOCK) ON M.IdActor = R.IdActor --@22
		AND M.IdRegistro = R.IdRegistro --@18
	WHERE R.IdActor = @IdAlumno
		AND R.Estado != 'X'
	GROUP BY R.IdActor
		,R.IdEmpresa
		,R.IdSede
		,IdFacultad
		,IdUnidadNegocio
		,IdProducto
		,m.IdCurricula --@18
	HAVING COUNT(1) > 1

	SELECT @CurID = 1
		,@MaxID = Max(Id)
	FROM @Registro

	WHILE @MaxID >= @CurID
	BEGIN
		--SE CARGA EL PRIMER REGISTRO DEL CURSOR      
		SELECT @CurIdAlumno = IdActor
			,@CurIdEmpresa = IdEmpresa
			,@CurIdSede = IdSede
			,@CurIdFacultad = IdFacultad
			,@CurIdUnidadNegocio = IdUnidadNegocio
			,@CurIdProducto = IdProducto
			,@IdCurricula = IdCurricula --@18
		FROM @Registro
		WHERE Id = @CurID

		SELECT TOP 1 @CurIdRegistro = R.IdRegistro
		FROM Registro R WITH (NOLOCK)
		LEFT JOIN Matricula M WITH (NOLOCK) ON R.IdActor = M.IdActor --@18    --@22
			AND R.IdRegistro = M.IdRegistro
		WHERE R.IdActor = @CurIdAlumno
			AND R.IdEmpresa = @CurIdEmpresa
			AND R.IdSede = @CurIdSede
			AND R.IdFacultad = @CurIdFacultad
			AND R.IdUnidadNegocio = @CurIdUnidadNegocio
			AND R.IdProducto = @CurIdProducto
			AND R.Estado != 'X'
			AND M.Estado != 'X'
			AND M.EsMatricula = 1
			AND M.IdCurricula = @IdCurricula --@18
		ORDER BY ISNULL(M.MatriculaFecha, M.InscritoFecha) DESC

		UPDATE @Registro
		SET IdRegistro = @CurIdRegistro
		WHERE Id = @CurID

		SET @CurID = @CurID + 1
	END

	--SE CARGA LA TABLA DE REGISTROS QUE TIENE SOLO UN PRODUCTO MATRICULADO POR SEDE      
	INSERT INTO @Registro
	SELECT R.IdActor
		,R.IdRegistro
		,R.IdEmpresa
		,R.IdSede
		,IdFacultad
		,IdUnidadNegocio
		,IdProducto
		,M.IdCurricula
	FROM Registro R WITH (NOLOCK)
	LEFT JOIN Matricula M WITH (NOLOCK) ON M.IdActor = R.IdActor --@22
		AND M.IdRegistro = R.IdRegistro --@18
	WHERE R.IdActor = @IdAlumno
		AND R.Estado != 'X'
		AND NOT EXISTS (
			SELECT 1
			FROM @Registro R2
			WHERE R.IdActor = R2.IdActor
				AND R.IdEmpresa = R2.IdEmpresa
				AND R.IdSede = R2.IdSede
				AND R.IdFacultad = R2.IdFacultad
				AND R.IdUnidadNegocio = R2.IdUnidadNegocio
				AND R.IdProducto = R2.IdProducto
				AND M.IdCurricula = R2.IdCurricula --@19 
			)

	DECLARE @Tmp TABLE (
		Id INT IDENTITY
		,IdAlumno INT
		,IdRegistro INT
		,IdEmpresa INT
		,IdSede INT
		,IdFacultad INT
		,IdUnidadNegocio INT
		,IdUnidadAcademica INT
		,UnidadAcademicaCodigo VARCHAR(10)
		,UnidadAcademicaNombre VARCHAR(200)
		,IdProducto INT
		,ProductoCodigo VARCHAR(10)
		,ProductoNombre VARCHAR(200)
		,IdCurricula INT
		,IdModulo INT
		,CursoNivel VARCHAR(100)
		,ModuloOrden INT
		,IdCurso INT
		,CursoCodigo VARCHAR(10)
		,CursoNombre VARCHAR(200)
		,Orden INT
		,CursoCredito REAL
		,NumVezCurso INT
		,PeriodoCodigo VARCHAR(20)
		,IdConvalidacion INT
		,ConvalidacionDescripcion VARCHAR(800)
		,PromedioFinal VARCHAR(10)
		,PromedioReal VARCHAR(100)
		,PromedioCondicion VARCHAR(20)
		,TipoCondicion VARCHAR(2)
		,Estado VARCHAR(20)
		,Requisito VARCHAR(50)
		,CurriculaNombre VARCHAR(200)
		,CurriculaCodigo VARCHAR(200)
		,SedeNombre VARCHAR(200)
		,FacultadNombre VARCHAR(200)
		,UnidadNegocioNombre VARCHAR(200)
		,IdCurriculaProducto VARCHAR(200)
		,CodigoCurriculaProducto VARCHAR(200)
		,NombreCurriculaProducto VARCHAR(200)
		,FechaInicio VARCHAR(10)
		,FechaFin VARCHAR(10)
		,CodigoSeccion VARCHAR(50)
		,IdSeccion INT
		,IdMatricula INT --@16  
		)

	INSERT INTO @Tmp
	SELECT DISTINCT R.IdActor
		,R.IdRegistro
		,R.IdEmpresa
		,R.IdSede
		,R.IdFacultad
		,R.IdUnidadNegocio
		,- 1
		,''
		,''
		,R.IdProducto
		,P.ProductoCodigo
		,P.ProductoNombre
		,AC.IdCurricula
		,ACC.IdModulo
		,'CursoNivel' = ISNULL(CM.Nombre, '')
		,'ModuloOrden' = ISNULL(CM.Orden, '')
		,ACC.IdCurso
		,C.CursoCodigo
		,CC.CursoNombreOficial
		,CC.ORDEN
		,'CursoCredito' = ISNULL(CC.CursoCredito, - 1)
		,'NumVezCurso' = 0
		,'PeriodoCodigo' = '-1'
		,'IdConvalidacion' = ISNULL(ACC.IdConvalidacion, - 1)
		,''
		,'PromedioFinal' = ISNULL(ACC.PromedioFinal, '-')
		,'PromedioReal' = ISNULL(ACC.PromedioReal, '-')
		,'PromedioCondicion' = ISNULL(ACC.PromedioCondicion, '')
		,'TipoCondicion' = ISNULL(ACC.TipoCondicion, '') --@6      
		,'Estado' = ISNULL(CASE 
								WHEN ACC.PromedioCondicion = 'D'
									THEN 'DESAPROBADO'
								WHEN ACC.PromedioCondicion = 'A'
									THEN 'APROBADO'
								END, 'PENDIENTE')
		,'Requisito' = ''
		,'CurriculaNombre' = ISNULL(CRR.Nombre, '')
		,'CurriculaCodigo' = ISNULL(CRR.Codigo, '')
		,'SedeNombre' = ISNULL(SE.Nombre, '')
		,'FacultadNombre' = ISNULL(F.Nombre, '')
		,'UnidadNegocioNombre' = ISNULL(UN.Nombre, '')
		,'IdCurriculaProducto' = ISNULL(CONVERT(VARCHAR, AC.IdCurricula), '') + ISNULL(CONVERT(VARCHAR, P.IdProducto), '')
		,'CodigoCurriculaProducto' = ISNULL(CRR.Codigo, '') + '-' + ISNULL(P.ProductoCodigo, '')
		,'NombreCurriculaProducto' = ISNULL(CRR.Codigo, '') + '-' + ISNULL(P.ProductoNombre, '')
		,'FechaInicio' = ''
		,'FechaFin' = ''
		,'CodigoSeccion' = ''
		,'IdSeccion' = 0 --@16  
		,'IdMatricula' = 0 --@16  
	FROM @Registro R
	INNER JOIN AlumnoCurricula AC WITH (NOLOCK) ON R.IdActor = AC.IdAlumno AND R.IdRegistro = AC.IdRegistro
	INNER JOIN AlumnoCurriculaCurso ACC WITH (NOLOCK) ON AC.IdAlumno = ACC.IdAlumno AND AC.IdRegistro = ACC.IdRegistro AND AC.IdCurricula = ACC.IdCurricula
	INNER JOIN Curso C WITH (NOLOCK) ON ACC.IdCurso = C.IdCurso
	LEFT JOIN CurriculaModulo CM WITH (NOLOCK) ON CM.IdModulo = ACC.IdModulo AND CM.IdCurricula = ACC.IdCurricula
	LEFT JOIN CurriculaCurso CC WITH (NOLOCK) ON ACC.IdCurricula = CC.IdCurricula AND acc.IdCurso = CC.IdCurso
	LEFT JOIN Producto P WITH (NOLOCK) ON R.IdProducto = P.IdProducto
	LEFT JOIN Curricula CRR WITH (NOLOCK) ON AC.IdCurricula = CRR.IdCurricula
	LEFT JOIN UnidadNegocio UN WITH (NOLOCK) ON R.IdUnidadNegocio = UN.IdUnidadNegocio
	LEFT JOIN Facultad F WITH (NOLOCK) ON R.IdFacultad = F.IdFacultad
	LEFT JOIN Sede SE WITH (NOLOCK) ON R.IdSede = SE.IdSede
	LEFT JOIN CurriculaSyllabus CS WITH (NOLOCK) ON CS.IdCurricula = CC.IdCurricula AND CS.IdCurso = CC.IdCurso
	WHERE AC.Activo = 1

	SELECT @CurID = 1
		,@MaxID = Max(Id)
	FROM @Tmp

	WHILE @MaxID >= @CurID
	BEGIN
		--SE CARGA EL PRIMER REGISTRO DEL CURSOR      
		SELECT @CurIdAlumno = IdAlumno
			,@CurIdRegistro = IdRegistro
			,@CurIdCurricula = IdCurricula
			,@CurIdCurso = IdCurso
			,@CurIdConvalidacion = IdConvalidacion
			,@CurPromedioCondicion = PromedioCondicion
		FROM @Tmp
		WHERE Id = @CurID

		SET @CurConvalidacionDescripcion = ''
		SET @CurCursoPeriodoCodigo = ''
		SET @CurCursoNroVez = 1
		SET @CurIdUnidadAcademica = - 1
		SET @CurUnidadAcademicaCodigo = ''
		SET @CurUnidadAcademicaNombre = ''
		SET @FechaInicio = NULL
		SET @FechaFin = NULL
		SET @CodigoSeccion = ''
		SET @IdSeccion = 0 --@16    

		IF @CurIdConvalidacion > 0
		BEGIN
			SELECT @CurCursoPeriodoCodigo = ISNULL(P.Codigo, '')
				,@CurConvalidacionDescripcion = ' N�mero: ' + ISNULL(C.Numero, '') + + '<br>' + ' Tipo: ' + UPPER(dbo.cEgresado_Sel_PeriodoIngresoObservacion(@CurIdAlumno, @CurIdCurricula, @CurIdRegistro)) + --@14      
												+ '<br>' + ' Observaci�n: ' + ISNULL(C.Observacion, '') + + '<br>' + ' Fecha: ' + CONVERT(VARCHAR, C.FechaCreacion, 104) + + '<br>' + ' Usuario: ' + ISNULL(U.LOGIN, '')
				,@CurCursoNroVez = 0
			FROM Convalidacion C WITH (NOLOCK)
			LEFT JOIN Usuario U WITH (NOLOCK) ON C.UsuarioCreacion = U.IdUsuario
			LEFT JOIN Periodo P WITH (NOLOCK) ON C.IdPeriodoAnual = P.IdPeriodo
			WHERE C.IdConvalidacion = @CurIdConvalidacion
				AND C.Estado = 'R'
		END
		ELSE
		BEGIN
			--@5 se carga el periodo del cargo      
			SELECT @CurCursoPeriodoCodigo = ISNULL(P.Codigo, '')
				--@20 Inicio
				--,@CurConvalidacionDescripcion = ' N�mero: ' + ISNULL(CAST(C.IdCargo AS VARCHAR), '') + + '<br>' + ' Tipo: Examen de Cargo' + + '<br>' + ' Observaci�n: Periodo: ' + ISNULL(P.Codigo, '') + + '<br>' + ' Fecha: ' + ISNULL(CONVERT(VARCHAR, ISNULL(CA.FechaModificacion, CA.FechaCreacion), 104), '') + + '<br>' + ' Usuario: ' + ISNULL(U.LOGIN, '')
				,@CurConvalidacionDescripcion = CASE WHEN C.Criterio = 'E' THEN ' N�mero: ' + ISNULL(CAST(C.IdCargo AS VARCHAR), '') + + '<br>' + ' Tipo: Evaluacion Extraordinaria' + + '<br>' + ' Observaci�n: Periodo: ' + ISNULL(P.Codigo, '') + + '<br>' + ' Fecha: '
 + ISNULL(CONVERT(VARCHAR, ISNULL(CA.FechaModificacion, CA.FechaCreacion), 104), '') + + '<br>' + ' Usuario: ' + ISNULL(U.LOGIN, '')
													ELSE ' N�mero: ' + ISNULL(CAST(C.IdCargo AS VARCHAR), '') + + '<br>' + ' Tipo: Examen de Cargo' + + '<br>' + ' Observaci�n: Periodo: ' + ISNULL(P.Codigo, '') + + '<br>' + ' Fecha: ' + ISNULL(CONVERT(VARCHAR, ISNULL(CA.FechaModificacion, CA.FechaCreacion), 104), '') + + '<br>' + ' Usuario: ' + ISNULL(U.LOGIN, '')
													END --@20 Fin													
			FROM CargoAlumno CA WITH (NOLOCK)
			INNER JOIN Cargo C WITH (NOLOCK) ON CA.IdCargo = C.IdCargo
			INNER JOIN Periodo P WITH (NOLOCK) ON C.IdPeriodo = P.IdPeriodo
			INNER JOIN Usuario U WITH (NOLOCK) ON ISNULL(CA.UsuarioModificacion, CA.UsuarioCreacion) = U.IdUsuario
			INNER JOIN AlumnoCurriculaCurso ACC WITH (NOLOCK) ON ACC.IdAlumno = CA.IdAlumno
																AND ACC.IdRegistro = CA.IdRegistro
																AND ACC.IdCurricula = CA.IdCurricula
																AND ACC.IdCurso = CA.IdCurso
			WHERE CA.IdAlumno = @CurIdAlumno
				AND CA.IdRegistro = @CurIdRegistro
				AND CA.IdCurricula = @CurIdCurricula
				AND CA.IdCurso = @CurIdCurso
				AND CA.Nota = ACC.PromedioFinal

			--AND ISNULL(ACC.PromedioCondicion,'')='A'--@8      
			SELECT TOP 1 @CurCursoNroVez = AC.NumVezCurso
				,@FechaInicio = PG.FechaInicio--@9      
				,@FechaFin = PG.FechaFin --@9      
				,@CodigoSeccion = PG.GrupoCodigo --@9      
				,@IdSeccion = AC.IdSeccion --@16    
				,@IdMatricula = M.IdMatricula --@16  
			FROM AlumnoCurso AC WITH (NOLOCK)
			INNER JOIN Matricula M WITH (NOLOCK) ON AC.IdMatricula = M.IdMatricula
			INNER JOIN PromocionGrupo pg WITH (NOLOCK) ON pg.IdPromocion = AC.IdPromocion AND pg.IdGrupo = Ac.IdGrupo
			WHERE AC.IdAlumno = @CurIdAlumno
				AND AC.IdRegistro = @CurIdRegistro
				AND ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) = @CurIdCurricula --@13      
				AND ISNULL(AC.IdCursoOriginal, AC.IdCurso) = @CurIdCurso --@13      
				AND AC.TipoCondicion = 'EC'
			--ORDER BY PE.IdPeriodo DESC      
			ORDER BY ISNULL(M.MatriculaFecha, M.InscritoFecha) DESC --@1      

			IF LTRIM(RTRIM(@CurConvalidacionDescripcion)) = ''
			BEGIN
				--@10 se verifica si tiene Suficiencia/Cargo      
				SELECT @CurCursoPeriodoCodigo = ISNULL(PE.Codigo, '')
					,@CurConvalidacionDescripcion = CASE 
						WHEN ISNULL(AC.IdDecreto, - 1) = - 1
							THEN ''
						ELSE ' N�mero: ' + ISNULL(CAST(DA.Codigo AS VARCHAR), '') + CASE UN.TipoServicio
								WHEN 'C'
									THEN + '<br>' + ' Tipo: Examen de Suficiencia'
								WHEN 'P'
									THEN + '<br>' + ' Tipo: Examen de Cargo'
								ELSE + '<br>' + ' Tipo: Examen'
								END + '<br>' + ' Observaci�n: ' + ISNULL(DE.Descripcion, '') + + '<br>' + ' Periodo: ' + ISNULL(PE.Codigo, '') + + '<br>' + ' Fecha: ' + ISNULL(CONVERT(VARCHAR, ISNULL(DE.FechaModificacion, DE.FechaCreacion), 104), '') + + '<br>' + ' Usuario: ' + 
ISNULL(U.LOGIN, '')
						END
					,@CurCursoNroVez = AC.NumVezCurso
					,@FechaInicio = PG.FechaInicio
					,@FechaFin = PG.FechaFin
					,@CodigoSeccion = PG.GrupoCodigo
					,@IdSeccion = AC.IdSeccion --@16    
					,@IdMatricula = M.IdMatricula --@16  
				FROM AlumnoCurso AC WITH (NOLOCK)
				INNER JOIN Matricula M WITH (NOLOCK) ON AC.IdMatricula = M.IdMatricula
				INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON pg.IdPromocion = AC.IdPromocion AND pg.IdGrupo = Ac.IdGrupo
				LEFT JOIN Decreto DE WITH (NOLOCK) ON AC.IdDecreto = DE.IdDecreto
				LEFT JOIN DecretoCabecera DA WITH (NOLOCK) ON DE.IdDecretoCabecera = DA.IdDecretoCabecera
				LEFT JOIN Periodo PE WITH (NOLOCK) ON DA.IdPeriodo = PE.IdPeriodo
				LEFT JOIN Usuario U WITH (NOLOCK) ON ISNULL(DE.UsuarioModificacion, DE.UsuarioCreacion) = U.IdUsuario
				LEFT JOIN UnidadNegocio UN WITH (NOLOCK) ON DA.IdUnidadNegocio = UN.IdUnidadNegocio
				WHERE AC.IdAlumno = @CurIdAlumno
					AND AC.IdRegistro = @CurIdRegistro
					AND ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) = @CurIdCurricula --@13      
					AND ISNULL(AC.IdCursoOriginal, AC.IdCurso) = @CurIdCurso --@13      
					AND M.Estado != 'X' --HUILLCA
					AND AC.Estado = 'NO'
					AND M.EsMatricula = 1
					AND AC.EsMatricula = 1
				ORDER BY ISNULL(M.MatriculaFecha, M.InscritoFecha) DESC
			END
		END

		IF LTRIM(RTRIM(@CurPromedioCondicion)) != ''
			AND LTRIM(RTRIM(@CurConvalidacionDescripcion)) = ''
		BEGIN
		--SELECT @CurIdAlumno,@CurIdRegistro,@CurIdCurricula,@CurIdCurso

			SELECT TOP 1 @CurCursoPeriodoCodigo = PE.Codigo
				,@CurCursoNroVez = AC.NumVezCurso
				,@CurConvalidacionDescripcion = ''
				,@FechaInicio = PG.FechaInicio --@9  
				,@FechaFin = PG.FechaFin --@9 
				,@CodigoSeccion = PG.GrupoCodigo --@9      
				,@IdSeccion = AC.IdSeccion --@16    
				,@IdMatricula = M.IdMatricula --@16  
			FROM AlumnoCurso AC WITH (NOLOCK)
			INNER JOIN Promocion P WITH (NOLOCK) ON AC.IdPromocion = P.IdPromocion
			INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
			INNER JOIN Matricula M WITH (NOLOCK) ON AC.IdMatricula = M.IdMatricula
			INNER JOIN PromocionGrupo pg WITH (NOLOCK) ON pg.IdPromocion = AC.IdPromocion AND pg.IdGrupo = Ac.IdGrupo
			WHERE AC.IdAlumno = @CurIdAlumno
				AND AC.IdRegistro = @CurIdRegistro
				AND ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) = @CurIdCurricula --@13      
				AND ISNULL(AC.IdCursoOriginal, AC.IdCurso) = @CurIdCurso --@13      
				AND AC.EsMatricula = 1
				AND M.Estado != 'X' --@12 --HUILLCA
				AND AC.estado = 'NO' --@12      
				--ORDER BY PE.IdPeriodo DESC      
			ORDER BY ISNULL(M.MatriculaFecha, M.InscritoFecha) DESC --@1      
		END
		
		--SELECT IdAlumno,IdCurricula,IdEmpresa,IdFacultad,IdUnidadNegocio,IdProducto,IdCurso FROM @Tmp

		SELECT @CurIdUnidadAcademica = ISNULL(UA.IdUnidadAcademica, - 1)
			,@CurUnidadAcademicaCodigo = ISNULL(UA.Codigo, '')
			,@CurUnidadAcademicaNombre = ISNULL(UA.Nombre, '')
		FROM @Tmp T
		LEFT JOIN Matricula M WITH (NOLOCK) ON M.IdActor = T.IdAlumno AND T.IdCurricula = M.IdCurricula --@17
		LEFT JOIN Promocion PR WITH (NOLOCK) ON T.IdEmpresa = PR.IdEmpresa
												AND M.IdSede = PR.IdSede --@18   
												AND T.IdFacultad = PR.IdFacultad
												AND T.IdUnidadNegocio = PR.IdUnidadNegocio
												AND T.IdProducto = PR.IdProducto
												AND M.IdCurricula = PR.IdCurricula --@17
												AND M.IdPromocion = PR.IdPromocion --@17  
												--AND ISNULL(T.IdModulo,-1)=ISNULL(PR.IdModulo,ISNULL(T.IdModulo,-1))      
		LEFT JOIN UnidadAcademica UA WITH (NOLOCK) ON PR.IdUnidadAcademica = UA.IdUnidadAcademica
		WHERE Id = @CurID
			AND M.Estado <> 'X' --@21


			


			--SELECT @CurCursoPeriodoCodigo,@CurIdCurso
		UPDATE T
		SET T.ConvalidacionDescripcion = @CurConvalidacionDescripcion
			,T.PeriodoCodigo = @CurCursoPeriodoCodigo
			,T.NumVezCurso = @CurCursoNroVez
			,T.IdUnidadAcademica = @CurIdUnidadAcademica
			,T.UnidadAcademicaCodigo = @CurUnidadAcademicaCodigo
			,T.UnidadAcademicaNombre = @CurUnidadAcademicaNombre
			,T.FechaInicio = ISNULL(CONVERT(VARCHAR(10), @FechaInicio, 103), '')--@9
			,T.FechaFin = ISNULL(CONVERT(VARCHAR(10), @FechaFin, 103), '')--@9
			,T.CodigoSeccion = ISNULL(@CodigoSeccion, '') --@9      
			,T.IdSeccion = isnull(@IdSeccion, 0) --@16    
			,T.IdMatricula = ISNULL(@IdMatricula, 0) --@16  
		FROM @Tmp T
		WHERE Id = @CurID
			AND IdCurso = @CurIdCurso

		SET @CurID = @CurID + 1
	END
	
	--Inicio @15      
	DECLARE @Curricula TABLE (
		Id INT IDENTITY
		,IdCurricula INT
		,IdAlumno INT
		,IdRegistro INT
		,IdEmpresa INT
		,IdSede INT
		,IdFacultad INT
		,IdUnidadNegocio INT
		,IdUnidadAcademica INT
		,UnidadAcademicaCodigo VARCHAR(10)
		,UnidadAcademicaNombre VARCHAR(200)
		,SedeNombre VARCHAR(200)
		,FacultadNombre VARCHAR(200)
		,UnidadNegocioNombre VARCHAR(200)
		)
	DECLARE @Max INT
		,@Min INT
		,@IdCurriculaOficial INT

	INSERT INTO @Curricula
	SELECT DISTINCT IdCurricula
		,IdAlumno
		,IdRegistro
		,IdEmpresa
		,IdSede
		,IdFacultad
		,IdUnidadNegocio
		,IdUnidadAcademica
		,UnidadAcademicaCodigo
		,UnidadAcademicaNombre
		,SedeNombre
		,FacultadNombre
		,UnidadNegocioNombre
	FROM @Tmp

	SELECT @Min = 1
		,@Max = Max(Id)
	FROM @Curricula

	--recorre las curriculas      
	WHILE @Max >= @Min
	BEGIN
		SELECT @CurIdCurricula = IdCurricula
			,@IdAlumno = IdAlumno
			,@CurIdRegistro = IdRegistro
			,@CurIdEmpresa = IdEmpresa
			,@CurIdFacultad = IdFacultad
			,@CurIdSede = IdSede
			,@CurIdUnidadNegocio = IdUnidadNegocio
			,@CurIdUnidadAcademica = IdUnidadAcademica
			,@CurUnidadAcademicaCodigo = UnidadAcademicaCodigo
			,@CurUnidadAcademicaNombre = UnidadAcademicaNombre
			,@CurSedeNombre = SedeNombre
			,@CurFacultadNombre = FacultadNombre
			,@CurUnidadNegocioNombre = UnidadNegocioNombre
		FROM @Curricula
		WHERE Id = @Min

		SET @IdCurriculaOficial = dbo.cCurricula_EsOficial(@CurIdCurricula)

		--SI TIENE OFICIAL      
		IF @IdCurriculaOficial <> @CurIdCurricula
		BEGIN
			INSERT INTO @Tmp
			SELECT DISTINCT @IdAlumno
				,@CurIdRegistro
				,@CurIdEmpresa
				,@CurIdSede
				,@CurIdFacultad
				,@CurIdUnidadNegocio
				,@CurIdUnidadAcademica
				,@CurUnidadAcademicaCodigo
				,@CurUnidadAcademicaNombre
				,P.IdProducto
				,P.ProductoCodigo
				,P.ProductoNombre
				,'IdCurricula' = ISNULL(ACC.IdCurricula, - 1)
				,'IdModulo' = ISNULL(ACC.IdModulo, '')
				,'CursoNivel' = ISNULL(CM.Nombre, '')
				,'ModuloOrden' = ISNULL(CM.Orden, '')
				,'IdCurso' = ISNULL(ACC.IdCurso, - 1)
				,'CursoCodigo' = ISNULL(C.CursoCodigo, '')
				,'CursoNombreOficial' = ISNULL(CC.CursoNombreOficial, '')
				,'ORDEN' = ISNULL(CC.ORDEN, 0)
				,'CursoCredito' = ISNULL(CC.CursoCredito, - 1)
				,'NumVezCurso' = 0
				,'PeriodoCodigo' = '-1'
				,'IdConvalidacion' = - 1
				,''
				,'PromedioFinal' = ISNULL(ACC.PromedioFinal, '-')
				,'PromedioReal' = ISNULL(ACC.PromedioReal, '-')
				,'PromedioCondicion' = ISNULL(ACC.PromedioCondicion, '')
				,'TipoCondicion' = ISNULL(ACC.TipoCondicion, '')
				,'Estado' = ISNULL(CASE 
									WHEN ACC.PromedioCondicion = 'D' THEN 'DESAPROBADO'
									WHEN ACC.PromedioCondicion = 'A' THEN 'APROBADO'
									END, 'PENDIENTE')
				,'Requisito' = ''
				,'CurriculaNombre' = ISNULL(CU.Nombre, '')
				,'CurriculaCodigo' = ISNULL(CU.Codigo, '')
				,@CurSedeNombre
				,@CurFacultadNombre
				,@CurUnidadNegocioNombre
				,'IdCurriculaProducto' = ISNULL(CONVERT(VARCHAR, ACC.IdCurricula), '') + ISNULL(CONVERT(VARCHAR, P.IdProducto), '')
				,'CodigoCurriculaProducto' = ISNULL(CU.Codigo, '') + '-' + ISNULL(P.ProductoCodigo, '')
				,'NombreCurriculaProducto' = ISNULL(CU.Codigo, '') + '-' + ISNULL(P.ProductoNombre, '')
				,'FechaInicio' = ''
				,'FechaFin' = ''
				,'CodigoSeccion' = ''
				,'IdSeccion' = 0
				,'IdMatricula' = 0 --@16  
			FROM Curricula CU WITH (NOLOCK)
			INNER JOIN AlumnoCurriculaCurso ACC WITH (NOLOCK) ON CU.IdCurricula = ACC.IdCurricula
			LEFT JOIN Curso C WITH (NOLOCK) ON ACC.IdCurso = C.IdCurso
			LEFT JOIN CurriculaModulo CM WITH (NOLOCK) ON CM.IdModulo = ACC.IdModulo AND CM.IdCurricula = ACC.IdCurricula
			LEFT JOIN CurriculaCurso CC WITH (NOLOCK) ON ACC.IdCurricula = CC.IdCurricula AND acc.IdCurso = CC.IdCurso
			LEFT JOIN Producto P WITH (NOLOCK) ON CU.IdProducto = P.IdProducto
			LEFT JOIN CurriculaSyllabus CS WITH (NOLOCK) ON CS.IdCurricula = CC.IdCurricula AND CS.IdCurso = CC.IdCurso
			WHERE CU.EsOficial = 1
				AND CU.IdCurricula = @IdCurriculaOficial
				AND ACC.IdAlumno = @IdAlumno
		END

		SET @IdCurriculaOficial = NULL
		SET @Min = @Min + 1
	END

	--Fin @15      
	SELECT T.Id
		,T.IdAlumno
		,T.IdRegistro
		,T.IdEmpresa
		,T.IdSede
		,T.IdFacultad
		,T.IdUnidadNegocio
		,T.IdUnidadAcademica
		,T.UnidadAcademicaCodigo
		,T.UnidadAcademicaNombre
		,T.IdProducto
		,T.ProductoCodigo
		,T.ProductoNombre
		,T.IdCurricula
		,T.IdModulo
		,T.CursoNivel
		,T.ModuloOrden
		,T.IdCurso
		,T.CursoCodigo
		,T.CursoNombre
		,T.CursoCredito
		,ISNULL(T.NumVezCurso, 1) AS NumVezCurso
		,T.PeriodoCodigo
		,T.IdConvalidacion
		,T.ConvalidacionDescripcion
		,T.PromedioFinal
		,T.PromedioReal
		,T.PromedioCondicion
		,T.TipoCondicion
		,T.Estado
		,T.Requisito
		,T.CurriculaNombre
		,T.CurriculaCodigo
		,T.SedeNombre
		,T.FacultadNombre
		,T.UnidadNegocioNombre
		,'Syllabus' = dbo.fCurriculaSyllabus_Sel_Recuperar(T.IdCurricula, T.IdCurso)
		,IdCurriculaProducto
		,CodigoCurriculaProducto
		,NombreCurriculaProducto
		,'FechaInicio' = CASE 
							WHEN (T.PeriodoCodigo) = ''	THEN ''
							ELSE T.FechaInicio
							END --@9
		,'FechaFin' = CASE 
						WHEN (T.PeriodoCodigo) = '' THEN ''
						ELSE T.FechaFin
						END --@9 
		,'CodigoSeccion' = CASE 
							WHEN (T.PeriodoCodigo) = ''	THEN ''
							ELSE T.CodigoSeccion
							END --@9      
		,'IdSeccion' = T.IdSeccion --@16  
		,'IdMatricula' = T.IdMatricula --@16  
	FROM @Tmp T
	ORDER BY ProductoNombre
		,IdCurricula
		,ModuloOrden
		,Orden

	SET NOCOUNT OFF
END

