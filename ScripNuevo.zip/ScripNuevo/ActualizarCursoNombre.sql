--INFORMACI�N CONTABLE

UPDATE Curso SET CursoNombre='INFORMACI�N CONTABLE PARA LA GESTI�N'
WHERE IdCurso=9911

UPDATE CurriculaCurso SET CursoNombreOficial='INFORMACI�N CONTABLE PARA LA GESTI�N'
WHERE IdCurso=9911

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial='INFORMACI�N CONTABLE PARA LA GESTI�N'
WHERE IdCurso=9911

UPDATE AlumnoCursoActaJson SET CursoNombre='INFORMACI�N CONTABLE PARA LA GESTI�N'
WHERE IdCurso=9911

UPDATE ActaConsolidada SET cursoNombreOficial='INFORMACI�N CONTABLE PARA LA GESTI�N'
WHERE IdCurso=9911

--ADMINISTRACI�N LOG�STICA

UPDATE Curso SET CursoNombre='ADMINISTRACION LOGISTICA'
WHERE IdCurso=9925

UPDATE CurriculaCurso SET CursoNombreOficial='ADMINISTRACION LOGISTICA'
WHERE IdCurso=9925

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial='ADMINISTRACION LOGISTICA'
WHERE IdCurso=9925

UPDATE AlumnoCursoActaJson SET CursoNombre='ADMINISTRACION LOGISTICA'
WHERE IdCurso=9925

UPDATE ActaConsolidada  SET cursoNombreOficial='ADMINISTRACION LOGISTICA'
WHERE IdCurso=9925

--AUDITORIA TRIBUTARIA

UPDATE Curso SET CursoNombre='AUDITORIA TRIBUTARIA'
WHERE IdCurso=10068

UPDATE CurriculaCurso SET CursoNombreOficial='AUDITORIA TRIBUTARIA'
WHERE IdCurso=10068

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial='AUDITORIA TRIBUTARIA'
WHERE IdCurso=10068

UPDATE AlumnoCursoActaJson SET CursoNombre='AUDITORIA TRIBUTARIA'
WHERE IdCurso=10068

UPDATE ActaConsolidada  SET cursoNombreOficial='AUDITORIA TRIBUTARIA'
WHERE IdCurso=10068

--PROYECTO PORTAFOLIO DIGITAL

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 4: Proyecto Portafolio Digital')
WHERE IdCurso=10579

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 4: Proyecto Portafolio Digital')
WHERE IdCurso=10579

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 4: Proyecto Portafolio Digital')
WHERE IdCurso=10579

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 4: Proyecto Portafolio Digital')
WHERE IdCurso=10579

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 4: Proyecto Portafolio Digital')
WHERE IdCurso=10579

--DESARROLLO PROFESIONAL

UPDATE Curso SET CursoNombre= UPPER('DESARROLLO PROFESIONAL')
WHERE IdCurso=9874

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('DESARROLLO PROFESIONAL')
WHERE IdCurso=9874 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('DESARROLLO PROFESIONAL')
WHERE IdCurso=9874

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('DESARROLLO PROFESIONAL')
WHERE IdCurso=9874

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('DESARROLLO PROFESIONAL')
WHERE IdCurso=9874

--PROYECCI�N 3D Y REALIDAD VIRTUAL

UPDATE Curso SET CursoNombre= UPPER('Proyecci�n Digital 3D y Realidad Virtual')
WHERE IdCurso=10489

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecci�n Digital 3D y Realidad Virtual')
WHERE IdCurso=10489

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecci�n Digital 3D y Realidad Virtual')
WHERE IdCurso=10489

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecci�n Digital 3D y Realidad Virtual')
WHERE IdCurso=10489

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecci�n Digital 3D y Realidad Virtual')
WHERE IdCurso=10489


--DIRECCION CREATIVA E INNOVACION EN MEDIOS

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 2:  Direcci�n Creativa e Innovaci�n en Medios')
WHERE IdCurso=10418

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 2:  Direcci�n Creativa e Innovaci�n en Medios')
WHERE IdCurso=10418

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 2:  Direcci�n Creativa e Innovaci�n en Medios')
WHERE IdCurso=10418

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 2:  Direcci�n Creativa e Innovaci�n en Medios')
WHERE IdCurso=10418

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 2:  Direcci�n Creativa e Innovaci�n en Medios')
WHERE IdCurso=10418

--DISE�O DE INTERFACES GR�FICAS Y ENTORNOS VIRTUALES

UPDATE Curso SET CursoNombre=UPPER('Dise�o de Interfaces Gr�ficas y  Entornos Virtuales')
WHERE IdCurso=10414

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Dise�o de Interfaces Gr�ficas y  Entornos Virtuales')
WHERE IdCurso=10414 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Dise�o de Interfaces Gr�ficas y  Entornos Virtuales')
WHERE IdCurso=10414

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Dise�o de Interfaces Gr�ficas y  Entornos Virtuales')
WHERE IdCurso=10414

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Dise�o de Interfaces Gr�ficas y  Entornos Virtuales')
WHERE IdCurso=10414

-- Estad�stica para Comunicadores

UPDATE Curso SET CursoNombre=UPPER('ESTAD�STICA PARA COMUNICADORES')
WHERE IdCurso=10411

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('ESTAD�STICA PARA COMUNICADORES')
WHERE IdCurso=10411 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('ESTAD�STICA PARA COMUNICADORES')
WHERE IdCurso=10411

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('ESTAD�STICA PARA COMUNICADORES')
WHERE IdCurso=10411

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('ESTAD�STICA PARA COMUNICADORES')
WHERE IdCurso=10411

-- TECNICAS Y  ESTRATEGIAS BTL

UPDATE Curso SET CursoNombre=UPPER('T�CNICAS Y ESTRATEGIAS BTL')
WHERE IdCurso=10373

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('T�CNICAS Y ESTRATEGIAS BTL')
WHERE IdCurso=10373 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('T�CNICAS Y ESTRATEGIAS BTL')
WHERE IdCurso=10373

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('T�CNICAS Y ESTRATEGIAS BTL')
WHERE IdCurso=10373

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('T�CNICAS Y ESTRATEGIAS BTL')
WHERE IdCurso=10373

-- DIRECCI�N DE PROYECTO PUBLICITARIO


UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 5:  Direcci�n de Proyecto Publicitario')
WHERE IdCurso=10415

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 5:  Direcci�n de Proyecto Publicitario')
WHERE IdCurso=10415 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 5:  Direcci�n de Proyecto Publicitario')
WHERE IdCurso=10415

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 5:  Direcci�n de Proyecto Publicitario')
WHERE IdCurso=10415

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 5:  Direcci�n de Proyecto Publicitario')
WHERE IdCurso=10415

-- PLAN  DE MARKETING Y ESTRATEGIA DIGITALES

UPDATE Curso SET CursoNombre= UPPER('Plan de Marketing y Estrategias Digitales')
WHERE IdCurso=11416

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Plan de Marketing y Estrategias Digitales')
WHERE IdCurso=11416 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Plan de Marketing y Estrategias Digitales')
WHERE IdCurso=11416

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Plan de Marketing y Estrategias Digitales')
WHERE IdCurso=11416

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Plan de Marketing y Estrategias Digitales')
WHERE IdCurso=11416


-- PLANNING DE MEDIOS

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 4:  Planning de Medios')
WHERE IdCurso=9812

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 4:  Planning de Medios')
WHERE IdCurso=9812 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 4:  Planning de Medios')
WHERE IdCurso=9812

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 4:  Planning de Medios')
WHERE IdCurso=9812

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 4:  Planning de Medios')
WHERE IdCurso=9812

-- GESTI�N DE PROYECTOS DE TECNOLOG�A DE INFORMACI�N

UPDATE Curso SET CursoNombre= UPPER('GESTI�N DE PROYECTOS DE TIC')
WHERE IdCurso=10511

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('GESTI�N DE PROYECTOS DE TIC')
WHERE IdCurso=10511 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('GESTI�N DE PROYECTOS DE TIC')
WHERE IdCurso=10511

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('GESTI�N DE PROYECTOS DE TIC')
WHERE IdCurso=10511

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('GESTI�N DE PROYECTOS DE TIC')
WHERE IdCurso=10511

-- GESTI�N DE TESORER�A

UPDATE Curso SET CursoNombre= UPPER('Gesti�n de Tesoreria')
WHERE IdCurso=10064

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Gesti�n de Tesoreria')
WHERE IdCurso=10064 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Gesti�n de Tesoreria')
WHERE IdCurso=10064

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Gesti�n de Tesoreria')
WHERE IdCurso=10064

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Gesti�n de Tesoreria')
WHERE IdCurso=10064

-- HERRAMIENTAS DE PROGRAMACI�N II

UPDATE Curso SET CursoNombre= UPPER('HERRAMIENTAS DE PROGRAMACI�N  2')
WHERE IdCurso=10449

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('HERRAMIENTAS DE PROGRAMACI�N  2')
WHERE IdCurso=10449 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('HERRAMIENTAS DE PROGRAMACI�N  2')
WHERE IdCurso=10449

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('HERRAMIENTAS DE PROGRAMACI�N  2')
WHERE IdCurso=10449

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('HERRAMIENTAS DE PROGRAMACI�N  2')
WHERE IdCurso=10449


-- INFORM�TICA APLICADAS A LOS NEGOCIOS

UPDATE Curso SET CursoNombre= UPPER('Inform�tica aplicada a los Negocios')
WHERE IdCurso=9856

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Inform�tica aplicada a los Negocios')
WHERE IdCurso=9856 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Inform�tica aplicada a los Negocios')
WHERE IdCurso=9856

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Inform�tica aplicada a los Negocios')
WHERE IdCurso=9856

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Inform�tica aplicada a los Negocios')
WHERE IdCurso=9856

-- INVESTIGACI�N DE MERCADOS

UPDATE Curso SET CursoNombre= UPPER('Investigaci�nde Mercados')
WHERE IdCurso=10105

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Investigaci�nde Mercados')
WHERE IdCurso=10105 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Investigaci�nde Mercados')
WHERE IdCurso=10105

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Investigaci�nde Mercados')
WHERE IdCurso=10105

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Investigaci�nde Mercados')
WHERE IdCurso=10105


-- LABORATORIO DE INTEGRACI�N 1 � TALLER CONTABLE I

UPDATE Curso SET CursoNombre= UPPER('Laboratorio de Integraci�n 1: Taller Contable I')
WHERE IdCurso=13421

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Laboratorio de Integraci�n 1: Taller Contable I')
WHERE IdCurso=13421 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Laboratorio de Integraci�n 1: Taller Contable I')
WHERE IdCurso=13421

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Laboratorio de Integraci�n 1: Taller Contable I')
WHERE IdCurso=13421

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Laboratorio de Integraci�n 1: Taller Contable I')
WHERE IdCurso=13421

-- LABORATORIO DE INTEGRACI�N 1- PROCESO TALLER SIMULADOR CAJA

UPDATE Curso SET CursoNombre= UPPER('Laboratorio De Integraci�n 1 - Proceso Taller Simulador De Caja')
WHERE IdCurso=13430

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Laboratorio De Integraci�n 1 - Proceso Taller Simulador De Caja')
WHERE IdCurso=13430 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Laboratorio De Integraci�n 1 - Proceso Taller Simulador De Caja')
WHERE IdCurso=13430

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Laboratorio De Integraci�n 1 - Proceso Taller Simulador De Caja')
WHERE IdCurso=13430

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Laboratorio De Integraci�n 1 - Proceso Taller Simulador De Caja')
WHERE IdCurso=13430


-- LABORATORIO DE INTEGRACI�N 2 - SISTEMA CONTABLE B�SICO

UPDATE Curso SET CursoNombre= UPPER('Laboratorio de Integraci�n 2: Sistema Contable B�sico')
WHERE IdCurso=13422

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Laboratorio de Integraci�n 2: Sistema Contable B�sico')
WHERE IdCurso=13422 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Laboratorio de Integraci�n 2: Sistema Contable B�sico')
WHERE IdCurso=13422

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Laboratorio de Integraci�n 2: Sistema Contable B�sico')
WHERE IdCurso=13422


UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Laboratorio de Integraci�n 2: Sistema Contable B�sico')
WHERE IdCurso=13422


-- MATEM�TICA APLICADA  AL USO DE LAS TECNOLOG�AS

UPDATE Curso SET CursoNombre= UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=13521

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=13521 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=13521

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=13521

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=13521

-- PLANEAMIENTO ESTRAT�GICO PARA LOS NEGOCIOS INTERNACIONALES

UPDATE Curso SET CursoNombre= UPPER('Planeamiento Estrat�gico para Negocios Internacionales')
WHERE IdCurso=9990

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Planeamiento Estrat�gico para Negocios Internacionales')
WHERE IdCurso=9990 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Planeamiento Estrat�gico para Negocios Internacionales')
WHERE IdCurso=9990

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Planeamiento Estrat�gico para Negocios Internacionales')
WHERE IdCurso=9990

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Planeamiento Estrat�gico para Negocios Internacionales')
WHERE IdCurso=9990

-- PRINCIPIOS DE AUDITOR�A FINANCIERA

UPDATE Curso SET CursoNombre= UPPER('Principios de Auditoria Financiera')
WHERE IdCurso=10067

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Principios de Auditoria Financiera')
WHERE IdCurso=10067 


UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Principios de Auditoria Financiera')
WHERE IdCurso=10067

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Principios de Auditoria Financiera')
WHERE IdCurso=10067

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Principios de Auditoria Financiera')
WHERE IdCurso=10067


-- PRODUCCI�N AUDIOVISUAL DIGITAL

UPDATE Curso SET CursoNombre= UPPER('Producci�n Audiovisual Digital')
WHERE IdCurso=10396

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Producci�n Audiovisual Digital')
WHERE IdCurso=10396 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Producci�n Audiovisual Digital')
WHERE IdCurso=10396

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Producci�n Audiovisual Digital')
WHERE IdCurso=10396

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Producci�n Audiovisual Digital')
WHERE IdCurso=10396

-- PROYECTO CERTIFICADOR DE DESARROLLO SOFTWARE II

UPDATE Curso SET CursoNombre= UPPER('PROYECTO CERTIFICADOR DE DESARROLLO DE SOFTWARE 2')
WHERE IdCurso=10507

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE DESARROLLO DE SOFTWARE 2')
WHERE IdCurso=10507 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE DESARROLLO DE SOFTWARE 2')
WHERE IdCurso=10507

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('PROYECTO CERTIFICADOR DE DESARROLLO DE SOFTWARE 2')
WHERE IdCurso=10507

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE DESARROLLO DE SOFTWARE 2')
WHERE IdCurso=10507

-- PROYECTO CERTIFICADOR DE DESARROLLO SOFTWARE III

UPDATE Curso SET CursoNombre= UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 3')
WHERE IdCurso=10514

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 3')
WHERE IdCurso=10514 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 3')
WHERE IdCurso=10514

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 3')
WHERE IdCurso=10514

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 3')
WHERE IdCurso=10514

-- PROYECTO DESARROLLO SOFTWARE II

UPDATE Curso SET CursoNombre= UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 2')
WHERE IdCurso=10516

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 2')
WHERE IdCurso=10516 


UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 2')
WHERE IdCurso=10516

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 2')
WHERE IdCurso=10516

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 2')
WHERE IdCurso=10516


-- PROYECTO DE PRODUCCI�N DIGITAL

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 3:  Proyectos de Producci�n Digital')
WHERE IdCurso=10395

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 3:  Proyectos de Producci�n Digital')
WHERE IdCurso=10395 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 3:  Proyectos de Producci�n Digital')
WHERE IdCurso=10395

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 3:  Proyectos de Producci�n Digital')
WHERE IdCurso=10395

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 3:  Proyectos de Producci�n Digital')
WHERE IdCurso=10395

-- PROYECTO DESARROLLO SOFTWARE 1

UPDATE Curso SET CursoNombre= UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 1')
WHERE IdCurso=10501

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 1')
WHERE IdCurso=10501 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 1')
WHERE IdCurso=10501

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 1')
WHERE IdCurso=10501

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('PROYECTO INTEGRADOR DESARROLLO SOFTWARE 1')
WHERE IdCurso=10501

-- PROYECTO EDITORIAL DIGITAL

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 3: Proyecto Editorial Digital')
WHERE IdCurso=10576

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 3: Proyecto Editorial Digital')
WHERE IdCurso=10576 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 3: Proyecto Editorial Digital')
WHERE IdCurso=10576

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 3: Proyecto Editorial Digital')
WHERE IdCurso=10576

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 3: Proyecto Editorial Digital')
WHERE IdCurso=10576

-- PROYECTO DE IDENTIDAD Y COMUNICACI�N CORPORATIVA

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 2: Proyecto de Identidad y Comunicaci�n Corporativa')
WHERE IdCurso=9789

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 2: Proyecto de Identidad y Comunicaci�n Corporativa')
WHERE IdCurso=9789 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 2: Proyecto de Identidad y Comunicaci�n Corporativa')
WHERE IdCurso=9789

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 2: Proyecto de Identidad y Comunicaci�n Corporativa') 
WHERE IdCurso=9789

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 2: Proyecto de Identidad y Comunicaci�n Corporativa') 
WHERE IdCurso=9789

-- TALLER: MARKETING DE SERVICIOS

UPDATE Curso SET CursoNombre= UPPER('Taller Marketing de Servicios')
WHERE IdCurso=10110

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Taller Marketing de Servicios')
WHERE IdCurso=10110 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Taller Marketing de Servicios')
WHERE IdCurso=10110

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Taller Marketing de Servicios')
WHERE IdCurso=10110

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Taller Marketing de Servicios')
WHERE IdCurso=10110

-- PROYECTO INTEGRADOR: PROCESO DE GESTI�N DOCUMENTARIA

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador: Proceso de Gesti�n Documentaria')
WHERE IdCurso=9918

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador: Proceso de Gesti�n Documentaria')
WHERE IdCurso=9918 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador: Proceso de Gesti�n Documentaria')
WHERE IdCurso=9918

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador: Proceso de Gesti�n Documentaria')
WHERE IdCurso=9918

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador: Proceso de Gesti�n Documentaria')
WHERE IdCurso=9918

-- TALLER DE ADMINISTRACI�N DE AGENCIAS

UPDATE Curso SET CursoNombre= UPPER('Taller Administraci�n de Agencias')
WHERE IdCurso=9882

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Taller Administraci�n de Agencias')
WHERE IdCurso=9882 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Taller Administraci�n de Agencias')
WHERE IdCurso=9882

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Taller Administraci�n de Agencias')
WHERE IdCurso=9882

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Taller Administraci�n de Agencias')
WHERE IdCurso=9882

-- TALLER DE ASESOR�A FINANCIERA

UPDATE Curso SET CursoNombre= UPPER('Taller Asesor�a Financiera')
WHERE IdCurso=9877

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Taller Asesor�a Financiera')
WHERE IdCurso=9877 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Taller Asesor�a Financiera')
WHERE IdCurso=9877

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Taller Asesor�a Financiera')
WHERE IdCurso=9877

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Taller Asesor�a Financiera')
WHERE IdCurso=9877

-- TALLER DE MARKETING DIGITAL

UPDATE Curso SET CursoNombre= UPPER('Taller Marketing Digital')
WHERE IdCurso=10114

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Taller Marketing Digital')
WHERE IdCurso=10114 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Taller Marketing Digital')
WHERE IdCurso=10114

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Taller Marketing Digital')
WHERE IdCurso=10114

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Taller Marketing Digital')
WHERE IdCurso=10114


-- APLICACIONES CON ENFOQUE ORIENTADA A SERVICIOS

UPDATE Curso SET CursoNombre= UPPER('APLICACIONES CON ENFOQUE ORIENTADO A SERVICIOS')
WHERE IdCurso=10512

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('APLICACIONES CON ENFOQUE ORIENTADO A SERVICIOS')
WHERE IdCurso=10512 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('APLICACIONES CON ENFOQUE ORIENTADO A SERVICIOS')
WHERE IdCurso=10512

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('APLICACIONES CON ENFOQUE ORIENTADO A SERVICIOS')
WHERE IdCurso=10512

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('APLICACIONES CON ENFOQUE ORIENTADO A SERVICIOS')
WHERE IdCurso=10512

-- DESARROLLO DE APLICACIONES M�VILES I

UPDATE Curso SET CursoNombre= UPPER('DESARROLLO DE APLICACIONES M�VILES 1')
WHERE IdCurso=10510

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('DESARROLLO DE APLICACIONES M�VILES 1')
WHERE IdCurso=10510 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('DESARROLLO DE APLICACIONES M�VILES 1')
WHERE IdCurso=10510

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('DESARROLLO DE APLICACIONES M�VILES 1')
WHERE IdCurso=10510

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('DESARROLLO DE APLICACIONES M�VILES 1')
WHERE IdCurso=10510

-- DESARROLLO DE SERVICIOS WEB I

UPDATE Curso SET CursoNombre= UPPER('DESARROLLO DE SERVICIOS WEB 1')
WHERE IdCurso=10464

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('DESARROLLO DE SERVICIOS WEB 1')
WHERE IdCurso=10464 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('DESARROLLO DE SERVICIOS WEB 1')
WHERE IdCurso=10464

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('DESARROLLO DE SERVICIOS WEB 1')
WHERE IdCurso=10464

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('DESARROLLO DE SERVICIOS WEB 1')
WHERE IdCurso=10464

-- BRANDING

--UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 5: Branding')
--WHERE IdCurso=10549

--UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 5: Branding')
--WHERE IdCurso=10549 

--UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 5: Branding')
--WHERE IdCurso=10549

--UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 5: Branding')
--WHERE IdCurso=10549

--UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 5: Branding')
--WHERE IdCurso=10549

-- COMUNICACI�N I

UPDATE Curso SET CursoNombre= UPPER('COMUNICACI�N 1')
WHERE IdCurso=9848

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('COMUNICACI�N 1')
WHERE IdCurso=9848 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('COMUNICACI�N 1')
WHERE IdCurso=9848

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('COMUNICACI�N 1')
WHERE IdCurso=9848

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('COMUNICACI�N 1')
WHERE IdCurso=9848

-- CONTABILIDAD DE COSTOS II

UPDATE Curso SET CursoNombre= UPPER('CONTABILIDAD DE COSTOS II')
WHERE IdCurso=10962

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('CONTABILIDAD DE COSTOS II')
WHERE IdCurso=10962 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('CONTABILIDAD DE COSTOS II')
WHERE IdCurso=10962

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('CONTABILIDAD DE COSTOS II')
WHERE IdCurso=10962

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('CONTABILIDAD DE COSTOS II')
WHERE IdCurso=10962

-- CONTROL Y AUTOMAT.DE PROCESOS

UPDATE Curso SET CursoNombre= UPPER('Control y Automatizaci�n de Procesos')
WHERE IdCurso=10158

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Control y Automatizaci�n de Procesos')
WHERE IdCurso=10158 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Control y Automatizaci�n de Procesos')
WHERE IdCurso=10158

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Control y Automatizaci�n de Procesos')
WHERE IdCurso=10158

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Control y Automatizaci�n de Procesos')
WHERE IdCurso=10158

-- Proyecto de Mecatr�nica 2

UPDATE Curso SET CursoNombre= UPPER('Proyecto de Mecatr�nica 2')
WHERE IdCurso=10262

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto de Mecatr�nica 2')
WHERE IdCurso=10262

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto de Mecatr�nica 2')
WHERE IdCurso=10262

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto de Mecatr�nica 2')
WHERE IdCurso=10262

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto de Mecatr�nica 2')
WHERE IdCurso=10262

-- DESARROLLO AVANZADO DE APLICACIONES II

UPDATE Curso SET CursoNombre= UPPER('DESARROLLO AVANZADO DE APLICACIONES 2')
WHERE IdCurso=10506

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('DESARROLLO AVANZADO DE APLICACIONES 2')
WHERE IdCurso=10506

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('DESARROLLO AVANZADO DE APLICACIONES 2')
WHERE IdCurso=10506

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('DESARROLLO AVANZADO DE APLICACIONES 2')
WHERE IdCurso=10506

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('DESARROLLO AVANZADO DE APLICACIONES 2')
WHERE IdCurso=10506


-- DESARROLLO DE APLICACIONES M�VILES II

UPDATE Curso SET CursoNombre= UPPER('DESARROLLO DE APLICACIONES M�VILES 2')
WHERE IdCurso=10515

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('DESARROLLO DE APLICACIONES M�VILES 2')
WHERE IdCurso=10515 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('DESARROLLO DE APLICACIONES M�VILES 2')
WHERE IdCurso=10515

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('DESARROLLO DE APLICACIONES M�VILES 2')
WHERE IdCurso=10515

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('DESARROLLO DE APLICACIONES M�VILES 2')
WHERE IdCurso=10515

-- DESARROLLO DE SERVICIOS WEB II

UPDATE Curso SET CursoNombre= UPPER('DESARROLLO DE SERVICIOS WEB 2')
WHERE IdCurso=10465

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('DESARROLLO DE SERVICIOS WEB 2')
WHERE IdCurso=10465 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('DESARROLLO DE SERVICIOS WEB 2')
WHERE IdCurso=10465

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('DESARROLLO DE SERVICIOS WEB 2')
WHERE IdCurso=10465

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('DESARROLLO DE SERVICIOS WEB 2')
WHERE IdCurso=10465

-- DISE�O MOBILIARIO

UPDATE Curso SET CursoNombre= UPPER('Dise�o de mobiliario')
WHERE IdCurso=10493

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Dise�o de mobiliario')
WHERE IdCurso=10493 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Dise�o de mobiliario')
WHERE IdCurso=10493

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Dise�o de mobiliario')
WHERE IdCurso=10493

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Dise�o de mobiliario')
WHERE IdCurso=10493

-- INGL�S III

UPDATE Curso SET CursoNombre= UPPER('Ingl�s 3')
WHERE IdCurso=9907

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Ingl�s 3')
WHERE IdCurso=9907 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Ingl�s 3')
WHERE IdCurso=9907

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Ingl�s 3')
WHERE IdCurso=9907

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Ingl�s 3')
WHERE IdCurso=9907

-- ELECTROT�CNIA AUTOMOTRIZ

UPDATE Curso SET CursoNombre= UPPER('Electrotecnia Automotriz')
WHERE IdCurso=10183

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Electrotecnia Automotriz')
WHERE IdCurso=10183

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Electrotecnia Automotriz')
WHERE IdCurso=10183

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Electrotecnia Automotriz')
WHERE IdCurso=10183

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Electrotecnia Automotriz')
WHERE IdCurso=10183

-- ESTANDARES APLICADOS A LA SEGURIDAD DE LA INFORMACI�N

UPDATE Curso SET CursoNombre=UPPER('ESTANDARES APLICADOS A LA SEGURIDAD DE INFORMACI�N')
WHERE IdCurso=11410

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('ESTANDARES APLICADOS A LA SEGURIDAD DE INFORMACI�N')
WHERE IdCurso=11410

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('ESTANDARES APLICADOS A LA SEGURIDAD DE INFORMACI�N')
WHERE IdCurso=11410

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('ESTANDARES APLICADOS A LA SEGURIDAD DE INFORMACI�N')
WHERE IdCurso=11410

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('ESTANDARES APLICADOS A LA SEGURIDAD DE INFORMACI�N')
WHERE IdCurso=11410

-- ESTRUCTURA DE DATOS Y PROGRAMACI�N ORIENTADA A OBJETIVOS

UPDATE Curso SET CursoNombre= UPPER('ESTRUCTURA DE DATOS Y PROGRAMACI�N ORIENTADA A OBJETOS')
WHERE IdCurso=10502

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('ESTRUCTURA DE DATOS Y PROGRAMACI�N ORIENTADA A OBJETOS')
WHERE IdCurso=10502

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('ESTRUCTURA DE DATOS Y PROGRAMACI�N ORIENTADA A OBJETOS')
WHERE IdCurso=10502

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('ESTRUCTURA DE DATOS Y PROGRAMACI�N ORIENTADA A OBJETOS')
WHERE IdCurso=10502

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('ESTRUCTURA DE DATOS Y PROGRAMACI�N ORIENTADA A OBJETOS')
WHERE IdCurso=10502

-- PROYECTO CERTIFICADOR DE REDES III

UPDATE Curso SET CursoNombre= UPPER('PROYECTO CERTIFICADOR DE REDES 3')
WHERE IdCurso=10627

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE REDES 3')
WHERE IdCurso=10627

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE REDES 3')
WHERE IdCurso=10627

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('PROYECTO CERTIFICADOR DE REDES 3')
WHERE IdCurso=10627

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE REDES 3')
WHERE IdCurso=10627


-- PROYECTO DE REDES Y COMUNICACIONES II

UPDATE Curso SET CursoNombre= UPPER('PROYECTO DE REDES Y COMUNICACIONES 2')
WHERE IdCurso=10624

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('PROYECTO DE REDES Y COMUNICACIONES 2')
WHERE IdCurso=10624

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('PROYECTO DE REDES Y COMUNICACIONES 2')
WHERE IdCurso=10624

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('PROYECTO DE REDES Y COMUNICACIONES 2')
WHERE IdCurso=10624

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('PROYECTO DE REDES Y COMUNICACIONES 2')
WHERE IdCurso=10624

-- INGL�S II

UPDATE Curso SET CursoNombre= UPPER('Ingl�s 2')
WHERE IdCurso=9902

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Ingl�s 2')
WHERE IdCurso=9902

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Ingl�s 2')
WHERE IdCurso=9902

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Ingl�s 2')
WHERE IdCurso=9902

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Ingl�s 2')
WHERE IdCurso=9902

-- PROYECTO INTEGRADOR III: TALLER DE DISE�O DE INTERIORES III - ESPACIO HOTELERO

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 3: Taller de Dise�o de interiores III -  Espacio Hotelero')
WHERE IdCurso=10597

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 3: Taller de Dise�o de interiores III -  Espacio Hotelero')
WHERE IdCurso=10597

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 3: Taller de Dise�o de interiores III -  Espacio Hotelero')
WHERE IdCurso=10597

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 3: Taller de Dise�o de interiores III -  Espacio Hotelero')
WHERE IdCurso=10597

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 3: Taller de Dise�o de interiores III -  Espacio Hotelero')
WHERE IdCurso=10597

-- INGL�S IV

UPDATE Curso SET CursoNombre= UPPER('Ingl�s 4')
WHERE IdCurso=9912

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Ingl�s 4')
WHERE IdCurso=9912

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Ingl�s 4')
WHERE IdCurso=9912

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Ingl�s 4')
WHERE IdCurso=9912

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Ingl�s 4')
WHERE IdCurso=9912


-- PROYECTO INTEGRADOR V: TALLER DE DISE�O DE INTERIORES V - ESPACIO COMERCIAL INTEGRAL

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 5: Taller de Dise�o de interiores V - Espacio Comercial Integral')
WHERE IdCurso=10599

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 5: Taller de Dise�o de interiores V - Espacio Comercial Integral')
WHERE IdCurso=10599

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 5: Taller de Dise�o de interiores V - Espacio Comercial Integral')
WHERE IdCurso=10599

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 5: Taller de Dise�o de interiores V - Espacio Comercial Integral')
WHERE IdCurso=10599

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 5: Taller de Dise�o de interiores V - Espacio Comercial Integral')
WHERE IdCurso=10599


-- MANTENIMIENTO DE M�QUINAS EL�CTRICAS

UPDATE Curso SET CursoNombre= UPPER('Mantenimiento de Maquinas El�ctricas')
WHERE IdCurso=10222

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Mantenimiento de Maquinas El�ctricas')
WHERE IdCurso=10222

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Mantenimiento de Maquinas El�ctricas')
WHERE IdCurso=10222

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Mantenimiento de Maquinas El�ctricas')
WHERE IdCurso=10222

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Mantenimiento de Maquinas El�ctricas')
WHERE IdCurso=10222


-- MATEM�TICA APLICADA AL USO DE TECNOLOG�AS

UPDATE Curso SET CursoNombre= UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=10229

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=10229 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=10229

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=10229

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('MATEM�TICA APLICADA AL USO DE LAS TECNOLOG�AS')
WHERE IdCurso=10229

-- PROGRAMACI�N APLICADA II 

UPDATE Curso SET CursoNombre= UPPER('Programaci�n Aplicada 2')
WHERE IdCurso=10248

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Programaci�n Aplicada 2')
WHERE IdCurso=10248 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Programaci�n Aplicada 2')
WHERE IdCurso=10248

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Programaci�n Aplicada 2')
WHERE IdCurso=10248

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Programaci�n Aplicada 2')
WHERE IdCurso=10248

-- PROYECTO CERTIFICADOR DE ELECTR�NICA II

UPDATE Curso SET CursoNombre= UPPER('Proyecto Certificador  de Electr�nica 2')
WHERE IdCurso=10259

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Certificador  de Electr�nica 2')
WHERE IdCurso=10259 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Certificador  de Electr�nica 2')
WHERE IdCurso=10259

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Certificador  de Electr�nica 2')
WHERE IdCurso=10259

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Certificador  de Electr�nica 2')
WHERE IdCurso=10259

-- PROYECTO CERTIFICADOR DE ELECTR�NICA III

UPDATE Curso SET CursoNombre= UPPER('Proyecto Certificador de Electr�nica 3')
WHERE IdCurso=10260

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Certificador de Electr�nica 3')
WHERE IdCurso=10260 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Certificador de Electr�nica 3')
WHERE IdCurso=10260

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Certificador de Electr�nica 3')
WHERE IdCurso=10260

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Certificador de Electr�nica 3')
WHERE IdCurso=10260

-- PROYECTO DE SISTEMAS ELECTR�NICOS II

UPDATE Curso SET CursoNombre= UPPER('Proyecto de Sistemas Electr�nicos 2')
WHERE IdCurso=10265

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto de Sistemas Electr�nicos 2')
WHERE IdCurso=10265 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto de Sistemas Electr�nicos 2')
WHERE IdCurso=10265

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto de Sistemas Electr�nicos 2')
WHERE IdCurso=10265

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto de Sistemas Electr�nicos 2')
WHERE IdCurso=10265

-- PROYECTO CERTIFICADOR DE MECATR�NICA AUTOMOTRIZ II

UPDATE Curso SET CursoNombre= UPPER('Proyecto Certificador de Mecatr�nica Automotriz 2')
WHERE IdCurso=10255

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 2')
WHERE IdCurso=10255 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 2')
WHERE IdCurso=10255

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 2')
WHERE IdCurso=10255

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 2')
WHERE IdCurso=10255

-- PROYECTO CERTIFICADOR DE MECATR�NICA AUTOMOTRIZ III

UPDATE Curso SET CursoNombre= UPPER('Proyecto Certificador de Mecatr�nica Automotriz 3')
WHERE IdCurso=10256

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 3')
WHERE IdCurso=10256 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 3')
WHERE IdCurso=10256

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 3')
WHERE IdCurso=10256


UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 3')
WHERE IdCurso=10256

-- PROYECTO CERTIFICADOR DE MECATR�NICA AUTOMOTRIZ IV

UPDATE Curso SET CursoNombre= UPPER('Proyecto Certificador de Mecatr�nica Automotriz 4')
WHERE IdCurso=10257

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 4')
WHERE IdCurso=10257 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 4')
WHERE IdCurso=10257

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 4')
WHERE IdCurso=10257

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica Automotriz 4')
WHERE IdCurso=10257

-- SISTEMAS COMPUTARIZADAS PARA LA DIN�MICA Y MEC�NICA DEL AUTOM�VIL

UPDATE Curso SET CursoNombre= UPPER('Sistemas Computarizados para la Din�mica y Mec�nica del Autom�vil')
WHERE IdCurso=10314

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Sistemas Computarizados para la Din�mica y Mec�nica del Autom�vil')
WHERE IdCurso=10314 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Sistemas Computarizados para la Din�mica y Mec�nica del Autom�vil')
WHERE IdCurso=10314

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Sistemas Computarizados para la Din�mica y Mec�nica del Autom�vil')
WHERE IdCurso=10314

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Sistemas Computarizados para la Din�mica y Mec�nica del Autom�vil')
WHERE IdCurso=10314

-- T�CNICAS DE SOLUCIONES Y DIAGN�STICO ELECTR�NICO

UPDATE Curso SET CursoNombre= UPPER('T�cnicas de Soluci�n y Diagnostico Electr�nico')
WHERE IdCurso=10347

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('T�cnicas de Soluci�n y Diagnostico Electr�nico')
WHERE IdCurso=10347 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('T�cnicas de Soluci�n y Diagnostico Electr�nico')
WHERE IdCurso=10347

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('T�cnicas de Soluci�n y Diagnostico Electr�nico')
WHERE IdCurso=10347

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('T�cnicas de Soluci�n y Diagnostico Electr�nico')
WHERE IdCurso=10347

-- PROYECTO CERTIFICADOR DE MECATR�NICA II

UPDATE Curso SET CursoNombre= UPPER('Proyecto Certificador de Mecatr�nica 2')
WHERE IdCurso=11019

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica 2')
WHERE IdCurso=11019 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica 2')
WHERE IdCurso=11019

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Certificador de Mecatr�nica 2')
WHERE IdCurso=11019

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica 2')
WHERE IdCurso=11019


-- PROYECTO CERTIFICADOR DE MECATR�NICA III

UPDATE Curso SET CursoNombre= UPPER('Proyecto Certificador de Mecatr�nica 3')
WHERE IdCurso=11020

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica 3')
WHERE IdCurso=11020 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica 3')
WHERE IdCurso=11020

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Certificador de Mecatr�nica 3')
WHERE IdCurso=11020

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Certificador de Mecatr�nica 3')
WHERE IdCurso=11020


-- PROYECTO CERTIFICADOR DE REDES II

UPDATE Curso SET CursoNombre= UPPER('PROYECTO CERTIFICADOR DE REDES 2')
WHERE IdCurso=10613

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE REDES 2')
WHERE IdCurso=10613 

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE REDES 2')
WHERE IdCurso=10613

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('PROYECTO CERTIFICADOR DE REDES 2')
WHERE IdCurso=10613

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('PROYECTO CERTIFICADOR DE REDES 2')
WHERE IdCurso=10613

-- PROYECTO DE REDES Y COMUNICACIONES I

UPDATE Curso SET CursoNombre= UPPER('PROYECTO DE REDES Y COMUNICACIONES 1')
WHERE IdCurso=10617

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('PROYECTO DE REDES Y COMUNICACIONES 1')
WHERE IdCurso=10617

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('PROYECTO DE REDES Y COMUNICACIONES 1')
WHERE IdCurso=10617

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('PROYECTO DE REDES Y COMUNICACIONES 1')
WHERE IdCurso=10617

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('PROYECTO DE REDES Y COMUNICACIONES 1')
WHERE IdCurso=10617

-- REDES INAL�MBRICAS II

UPDATE Curso SET CursoNombre= UPPER('REDES INAL�MBRICAS 2')
WHERE IdCurso=10621

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('REDES INAL�MBRICAS 2')
WHERE IdCurso=10621

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('REDES INAL�MBRICAS 2')
WHERE IdCurso=10621

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('REDES INAL�MBRICAS 2')
WHERE IdCurso=10621

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('REDES INAL�MBRICAS 2')
WHERE IdCurso=10621

-- PROYECTO INTEGRADOR IV: TALLER DE DISE�O DE INTERIORES IV - ESPACIO GASTRON�MICO

UPDATE Curso SET CursoNombre= UPPER('Proyecto Integrador 4:  Taller de Dise�o de interiores IV - Espacio Gastron�mico')
WHERE IdCurso=10598

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Proyecto Integrador 4:  Taller de Dise�o de interiores IV - Espacio Gastron�mico')
WHERE IdCurso=10598

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Proyecto Integrador 4:  Taller de Dise�o de interiores IV - Espacio Gastron�mico')
WHERE IdCurso=10598

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Proyecto Integrador 4:  Taller de Dise�o de interiores IV - Espacio Gastron�mico')
WHERE IdCurso=10598

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Proyecto Integrador 4:  Taller de Dise�o de interiores IV - Espacio Gastron�mico')
WHERE IdCurso=10598

-- SISTEMAS DE INYECCI�N GASOLINA Y DI�SEL

UPDATE Curso SET CursoNombre= UPPER('Sistemas de Inyecci�n Gasolina y Diesel')
WHERE IdCurso=10304

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Sistemas de Inyecci�n Gasolina y Diesel')
WHERE IdCurso=10304

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Sistemas de Inyecci�n Gasolina y Diesel')
WHERE IdCurso=10304

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Sistemas de Inyecci�n Gasolina y Diesel')
WHERE IdCurso=10304

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Sistemas de Inyecci�n Gasolina y Diesel')
WHERE IdCurso=10304

-- SEGURIDAD OCUPACIONAL E INDUSTRIAL

UPDATE Curso SET CursoNombre= UPPER('Seguridad y Salud Ocupacional')
WHERE IdCurso=10299

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Seguridad y Salud Ocupacional')
WHERE IdCurso=10299

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Seguridad y Salud Ocupacional')
WHERE IdCurso=10299

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Seguridad y Salud Ocupacional')
WHERE IdCurso=10299

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Seguridad y Salud Ocupacional')
WHERE IdCurso=10299

-- BRANDING

--UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Branding')
--WHERE IdCurso=10549 AND  nombreProducto='CIENCIAS PUBLICITARIAS'

--UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Branding')
--WHERE IdCurso=10549 AND ProductoNombre='CIENCIAS PUBLICITARIAS'