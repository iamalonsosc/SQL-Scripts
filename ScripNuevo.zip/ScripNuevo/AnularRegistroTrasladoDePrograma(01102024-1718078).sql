--SELECT IdSede,*FROM Registro
UPDATE Registro SET IdSede=48
WHERE IdActor=1718078
AND IdRegistro=1
--(1 row affected)