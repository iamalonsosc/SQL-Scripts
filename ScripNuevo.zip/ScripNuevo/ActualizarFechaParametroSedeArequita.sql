--11 de marzo 2024
--SELECT*FROM ParametroUnidadAcademica where idsede=47 AND Nombre='ParametroNomina1'
UPDATE ParametroUnidadAcademica SET Valor3='11/03/2024'
WHERE  IdSede=47 AND Nombre='ParametroNomina1'
--(72 rows affected)
--SELECT*FROM ParametroUnidadAcademica 
UPDATE ParametroUnidadAcademica SET Valor3='11/03/2024'
WHERE  IdSede=47 AND Nombre='ParametroNomina2'
--(72 rows affected)