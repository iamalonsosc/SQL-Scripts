--SELECT*FROM Registro 
UPDATE Registro SET IdSede=34
WHERE IdActor=1641996 AND IdRegistro=1
--(1 row affected)