select doc.Estado,MontoTotal,doc.MontoPagado,dco.MontoPagado,co.Estado,co.FechaCobranza,* 
from CO_Documento doc
inner join co_documentocobranza dco on doc.tipodocumento=dco.tipodocumento and doc.NumeroDocumento=dco.NumeroDocumento and doc.CompaniaSocio=dco.CompaniaSocio
inner join CO_Cobranza co on dco.CobranzaNumero=co.CobranzaNumero
where doc.CompaniaSocio='00002700' and doc.TipoDocumento in ('BV','FC','ND' )
and doc.Estado='PR'
and doc.MontoTotal=dco.MontoPagado
and co.Estado<>'AN'

--select doc.Estado,MontoTotal,doc.MontoPagado,dco.MontoPagado,co.Estado,co.FechaCobranza,* 
update doc set Doc.estado='CO',Doc.MontoPagado=dco.MontoPagado
from CO_Documento doc
inner join co_documentocobranza dco on doc.tipodocumento=dco.tipodocumento and doc.NumeroDocumento=dco.NumeroDocumento and doc.CompaniaSocio=dco.CompaniaSocio
inner join CO_Cobranza co on dco.CobranzaNumero=co.CobranzaNumero
where doc.CompaniaSocio='00002700' and doc.TipoDocumento in ('BV','FC','ND' )
and doc.Estado='PR'
and doc.MontoTotal=dco.MontoPagado
and co.Estado<>'AN'





select Estado,MontoTotal,MontoPagado, * from CO_Documento where tipodocumento='BV' and NumeroDocumento='B497-0198968'
select * from CO_DocumentoCobranza where tipodocumento='BV' and NumeroDocumento='B497-0198968'
select * from CO_Cobranza where CobranzaNumero=2543709
select * from CO_CobranzaDetalle where CobranzaNumero=2543709
