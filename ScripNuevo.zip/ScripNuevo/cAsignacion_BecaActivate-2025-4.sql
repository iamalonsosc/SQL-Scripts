----------------------------------------------------------------------------      
--Creado por      :Alonso Sanchez (26/04/2024)            
--Funcionalidad   :Permite validar la asignacion de las becas activate
--Utilizado por   :cDescuentoAcademicoReporte_Xls_DES007
--------------------------------------------------------------         
/*      
-----------------------------------------------------------------------------      
Nro		FECHA			USUARIO					DESCRIPCION      
-----------------------------------------------------------------------------    
@1		07.05.2024		ALSANCHEZ				REEMPLAZAR CONDICION POR EL MANTIENE LA BECA
@2		15.08.2024		ALSANCHEZ				Nueva logica de beca mayo
@3		29.08.2024		ALSANCHEZ				Validar si el alumno tiene la beca en periodos pasados
@4		12.09.2024		ALSANCHEZ				Agregamos la condicion por cambio de modalidad para la sede 48 
@5		13.09.2024		ALSANCHEZ				Agregamos validacion por compania socio 00002700
@6		18.09.2024		LPARIONA				Agregamos validacion por compania socio 00002500
@7		20.09.2024		LPARIONA				Se valida solo para companiasocio 00002700 en DescuentoAlumno
@8		21.09.2024		ALSANCHEZ				Se agregan validaciones y mejoras para el traslado de programa de IES a ESCUELA
@9		26.09.2024		ALSANCHEZ				Se agrega nueva validacion para no tener en cuenta el cambio por TIPO CONDICION
@10		07.01.2024		ALSANCHEZ				Se agrega un top 1 y un order by desc, para traer exactamente la ultima matricula creada
@11		10.01.2024		ALSANCHEZ				Todo alumno con la beca 37, consultara si anteriormente tuvo la beca 17
@12		19.02.2025		ALSANCHEZ				Se agrega condicion solo para las becas de CORRIENTE ALTERNA
@13		29.04.2025		ALSANCHEZ				Se modica el numero de las cuotas apartir de cuando se validara la captacion y secuencial
*/   
ALTER PROCEDURE [dbo].[cAsignacion_BecaActivate]
@IdMatricula INT ,
@CodigoBase VARCHAR(100),
@Retorno BIT OUT,
@pDescripcion varchar(500) OUT
AS  

BEGIN 
/*
GLOSARIO:
	RE -> Promovido
	RP -> Promovido + Curso
	RT -> Repitencia
	CC -> Curso�Repitencia
*/
	DECLARE @IdActor INT,
	@IdSedeActual INT,
	@IdSedeAnterior INT,
	@CodigoPeriodo VARCHAR(10),
	@IdUnidadAcademica INT,
	@IdUnidadNegocio INT,
	@TipoTurnoActual VARCHAR(15),
	@TipoCondicionActual VARCHAR(10),
	@CambioCarreraBeca INT,
	@CompaniaSocio VARCHAR(10),
	@PromedioBeca REAl,
	@PeriodosAnterioresConcatenados VARCHAR(MAX),
	@IdModuloBecaValidar INT,
	@IdProductoActual INT,
	@IdProductoAnterior INT,
	@IdMatriculaAnterior INT,
	@IdModuloPagoAnterior INT,
	@IdModuloActual INT,
	@IdTipoConsulta INT,
	@PeriodoCodigoBase VARCHAR(20),
	@TurnoAnterior varchar(50),
	@ProductoAnterior varchar(100),
	@ProductoActual varchar(100),
	@SedeActual VARCHAR(50),
	@SedeNombreAnterior VARCHAR(50),
	@PeriodoCodigoMatriculaAnterior VARCHAR(50),
	@PromedioReal real,
	@IdModulo INT,
	@TieneBecaDescuentoAlumnoResultado BIT=0,--@1	
	@IdModuloAnterior INT,
	@IdPeriodoAnteriorTS INT,--@8
	@IdPeriodoActual INT--@8

	-- DECLARAMOS TODAS LAS VARIABLES DE VALIDACI�N
	DECLARE 
	@ValidaTipoTurno BIT = 1,
	@ValidaTipoCondicion BIT = 1 ,
	@ValidaRetiro BIT= 1  ,
	@ValidaCambioSede BIT= 1 ,
	@ValidaPagoPuntualBeca BIT= 1 , 
	@ValidaReingreso BIT= 1 ,
	@Validacion2024 BIT=0,
	@ValidaCambioDeModalidad BIT=0;

	--DECLARAMOS TODAS LAS VARIABLES DE EXLUCI�N
	DECLARE 
	@ExcluidoPorPromedio BIT = 0 ,
	@ExcluidoPorTurno BIT = 0 ,
	@ExcluidoPorCondicion BIT = 0 ,
	@ExcluidoPorRetiro BIT = 0 , 
	@ExcluidoPorCambioSede BIT = 0 , 
	@ExcluidoPorCambioCarrera BIT = 0 ,
	@ExcluidoPorPagoPuntual INT = 0 ,
	@ExcluidoPorPeriodoAnterior BIT = 0,
	@ExcluidoPorReingresante BIT = 0 ,
	@ExcluidoPorNoTenerMatricula BIT = 0 ,
	@ExcluidoPorBeca BIT = 0,
	@ExcluidoPorNoTenerMatriculaAProcesar BIT = 0,
	@ExcluidoPorCambioDeModalidad BIT = 0,
	@ExcluidoPorNoCorrespondeBeca BIT = 0,
	@ExcluidoPorSecuencialidad BIT=0,
	@ExcluidoPorBase BIT=0,
	@ExcluidoPorPromedio37 BIT = 0;

	Declare @PeriodosAnteriores table    
	(CodigoPeriodoPadre varchar(20),    
	CodigoPeriodoAnterior varchar(20),     
	IdPeriodoPadre int,    
	IdPeriodoAnterior int) 

	DECLARE @MatriculaAnterior TABLE (
	IdActor INT,
	IdMatricula INT,
	EsMatricula INT,
	PromocionCodigo VARCHAR(50),
	PromocionNombre VARCHAR(100),
	IdSede INT,
	SedeNombreAnterior varchar(50),
	IdPeriodo INT,
	Codigo VARCHAR(50),
	IdProducto INT,
	ProductoNombre VARCHAR(100),
	GrupoCodigo VARCHAR(50),
	IdGrupo INT,
	IdTurno INT,
	TurnoNombre VARCHAR(100),
	IdTipoTurno INT,
	TipoTurnoDispo5 VARCHAR(50),
	TipoCondicion VARCHAR(50),
	Estado VARCHAR(50),
	MatriculaTipo VARCHAR(50),
	PromedioReal REAL,
	IdModulo INT,
	PeriodoCodigoBase VARCHAR(20),
	NombreDescuento VARCHAR(100),
	CodigoDescuento VARCHAR(50),
	IdTipoConsulta INT,
	TieneBecaDescuentoAlumnoResultado BIT,
	TieneBecaDescuentoAlumno BIT);--@3	
	
	--  CODIGO DE BASE POR CAMBIO DE TURNO
	DECLARE @IdMaestroRegistroCT INT �
���	SELECT @IdMaestroRegistroCT = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000020' 
	--  CODIGO DE BASE POR CAMBIO DE SEDE
	DECLARE @IdMaestroRegistroCS INT �
���	SELECT @IdMaestroRegistroCS = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000027'
	--  CODIGO DE BASE POR CAMBIO DE CARRERA 
	DECLARE @IdMaestroRegistroCC INT �
���	SELECT @IdMaestroRegistroCC = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000032'
	--CODIGO DE BASE POR TRASLADO DE PROGRAMA O SEDE
	DECLARE @IdMaestroRegistroTS INT �--@8
���	SELECT @IdMaestroRegistroTS = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000039'--@8
	--CODIGO DE BASE POR TIPO DE CONDICION
	DECLARE @IdMaestroRegistroTC INT �--@9
���	SELECT @IdMaestroRegistroTC = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000040'--@9

	--Selecionamos la empresa a la que pertenece 
	SELECT @CompaniaSocio= CompaniaSocio FROM Empresa

	SET @IdMatriculaAnterior = NULL 
	SET @IdModuloPagoAnterior = NULL 
			
END 

-- obtenener los datos de su ultima matricula del alumno
--Obtenemos el periodo  actual del alumno
SELECT 
@IdPeriodoActual=PE.IdPeriodo,
@CodigoPeriodo=PE.Codigo,
@IdSedeActual=MA.IdSede,
@SedeActual=S.Nombre,
@IdUnidadAcademica=PE.IdUnidadAcademica,
@IdUnidadNegocio=PE.IdUnidadNegocio,
@IdActor=MA.IdActor,
@TipoTurnoActual=MTR.Disponible5,
@TipoCondicionActual=MA.TipoCondicion,
@IdProductoActual= P.IdProducto,
@ProductoActual=P.PromocionNombre,
@IdModuloActual = MA.IdModulo
FROM Matricula MA WITH (NOLOCK)
INNER JOIN sede s WITH(NOLOCK) on s.IdSede = MA.IdSede
INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo 
INNER JOIN Turno TU WITH(NOLOCK) ON PG.idturno = TU.idturno 
INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.idmaestroregistro=tu.idtipoturno
INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
WHERE MA.IdMatricula = @IdMatricula AND P.IdUnidadNegocio = 1   AND  MA.Estado <> 'X'

	IF  @CodigoPeriodo is null
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'NO OBTIENE MATRICULA O PRE , EN EL PERIODO A PROCESAR '
		SET @ExcluidoPorNoTenerMatriculaAProcesar=1
		RETURN
	END
--obtenemos los periodos anteriores
INSERT INTO @PeriodosAnteriores (CodigoPeriodoPadre,CodigoPeriodoAnterior, IdPeriodoPadre,IdPeriodoAnterior) 
SELECT  DISTINCT PE.Codigo AS 'PADRE',PE2.Codigo AS 'ANTERIOR',PE.IdPeriodo,PE2.IdPeriodo 
FROM PeriodoEquivalencia PEE WITH (NOLOCK)
INNER JOIN Periodo PE WITH (NOLOCK) ON PEE.IdPeriodoPadre = PE.IdPeriodo
INNER JOIN Periodo PE2 WITH (NOLOCK) ON PEE.IdPeriodoEquivalencia = PE2.IdPeriodo
WHERE PE.Codigo=@CodigoPeriodo  AND PEE.EsSiguiente=0
AND PE.IdUnidadAcademica=@IdUnidadAcademica AND PE.IdUnidadNegocio=@IdUnidadNegocio

-- VALIDAMOS QUE EXISTA PERIODO ANTERIOR --  EN EQUIVALENCIA  - FALTA
	IF  NOT EXISTS(SELECT 1 FROM @PeriodosAnteriores)
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'NO SE OBTIENE INFORMACI�N SOBRE EL PERIODO ANTERIOR DEL ALUMNO(VALIDAR CONFIGURACI�N DE PERIODO)'
		SET @ExcluidoPorPeriodoAnterior=1
		RETURN
	END

--OBTENEMOS DATOS DE LA MATRICULA ANTERIOR DEL ALUMNO
 INSERT INTO  @MatriculaAnterior     
(IdActor,IdMatricula,PromocionCodigo,PromocionNombre ,IdSede,SedeNombreAnterior,IdPeriodo,Codigo,IdProducto,ProductoNombre,GrupoCodigo,IdGrupo,IdTurno,
TurnoNombre,IdTipoTurno,TipoTurnoDispo5,TipoCondicion,Estado,MatriculaTipo,PromedioReal,IdModulo,PeriodoCodigoBase,NombreDescuento,CodigoDescuento,IdTipoConsulta,TieneBecaDescuentoAlumnoResultado,TieneBecaDescuentoAlumno) --@3	
SELECT DISTINCT TOP 1 MA.IdActor, MA.IdMatricula, P.PromocionCodigo,P.PromocionNombre, P.IdSede,S.Nombre,P.IdPeriodo,PE.Codigo , RE.IdProducto ,PR.ProductoNombre ,--@10
PG.GrupoCodigo,PG.IdGrupo , TU.IdTurno ,TU.Nombre, TU.IdTipoTurno ,MTR.Disponible5 TipoTurnoDispo5,
CASE WHEN MA.TipoCondicion IN ('CC','RT') THEN 'RT' ELSE 'RE' END MatriculaTipoCondicion,MA.Estado,MA.Tipo MatriculaTipo,PGC.PromedioReal,
P.IdModulo,'','','',NULL,0,0--@3	
FROM Matricula MA WITH (NOLOCK)
INNER JOIN sede s WITH(NOLOCK) on s.IdSede = MA.IdSede
INNER JOIN Registro RE WITH(NOLOCK) ON RE.IdActor=MA.IdActor AND RE.IdRegistro=MA.IdRegistro
INNER JOIN producto PR WITH(NOLOCK) ON  RE.idproducto = PR.idproducto
INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
INNER JOIN PeriodoCabecera PC WITH(NOLOCK) ON PE.IdPeriodoCabecera=PC.IdPeriodoCabecera
INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo 
INNER JOIN Turno TU WITH(NOLOCK) ON PG.idturno = TU.idturno 
INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.idmaestroregistro=tu.idtipoturno
LEFT JOIN PromocionGrupoCierre PGC WITH(NOLOCK) ON MA.IdMatricula = PGC.IdMatricula 
WHERE MA.IdActor=@IdActor  
AND P.IdUnidadNegocio =@IdUnidadNegocio 
AND  P.IdUnidadAcademica=@IdUnidadAcademica
AND  MA.Estado <> 'X'
AND PE.IdPeriodo IN (SELECT IdPeriodoAnterior FROM @PeriodosAnteriores)
-- AND MTR2.codigo  IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019')
ORDER BY IdMatricula DESC --@10

-- INICIO ALSANCHEZ @8
--VALIDAMOS SI EXISTE MATRICULA ANTERIOR EN SU TRASLADO DE SEDE
	IF  NOT EXISTS(SELECT 1 FROM @MatriculaAnterior)
	BEGIN
		--VALIDAMOS SI LE CORRESPONDE CAMBIO DE PROGRAMA 
		IF  EXISTS(SELECT 1 FROM DescuentoAcademicoBase WITH(NOLOCK) WHERE IdActor=@IdActor AND IdMaestroRegistro=@IdMaestroRegistroTS AND Activo = 1 AND PeriodoCodigo=@CodigoPeriodo)
		BEGIN
			--BUSCAMOS SU CAMBIO DE PROGRAMA
			SELECT @IdPeriodoAnteriorTS=IdPeriodoAnterior FROM TrasladoSede WITH(NOLOCK)
			WHERE IdAlumno=@IdActor 
			AND IdPeriodoTraslado=@IdPeriodoActual
			AND Estado=1 
			--SI EN TODO CASO EXISTE, REGISTRA LA MATRICULA ANTERIOR A BUSCAR
			 INSERT INTO  @MatriculaAnterior     
			(IdActor,IdMatricula,PromocionCodigo,PromocionNombre ,IdSede,SedeNombreAnterior,IdPeriodo,Codigo,IdProducto,ProductoNombre,GrupoCodigo,IdGrupo,IdTurno,
			TurnoNombre,IdTipoTurno,TipoTurnoDispo5,TipoCondicion,Estado,MatriculaTipo,PromedioReal,IdModulo,PeriodoCodigoBase,NombreDescuento,CodigoDescuento,IdTipoConsulta,TieneBecaDescuentoAlumnoResultado,TieneBecaDescuentoAlumno) --@3	
			SELECT DISTINCT MA.IdActor, MA.IdMatricula, P.PromocionCodigo,P.PromocionNombre, P.IdSede,S.Nombre,P.IdPeriodo,PE.Codigo , RE.IdProducto ,PR.ProductoNombre ,
			PG.GrupoCodigo,PG.IdGrupo , TU.IdTurno ,TU.Nombre, TU.IdTipoTurno ,MTR.Disponible5 TipoTurnoDispo5,
			CASE WHEN MA.TipoCondicion IN ('CC','RT') THEN 'RT' ELSE 'RE' END MatriculaTipoCondicion,MA.Estado,MA.Tipo MatriculaTipo,PGC.PromedioReal,
			P.IdModulo,'','','',NULL,0,0--@3	
			FROM Matricula MA WITH (NOLOCK)
			INNER JOIN sede s WITH(NOLOCK) on s.IdSede = MA.IdSede
			INNER JOIN Registro RE WITH(NOLOCK) ON RE.IdActor=MA.IdActor AND RE.IdRegistro=MA.IdRegistro
			INNER JOIN producto PR WITH(NOLOCK) ON  RE.idproducto = PR.idproducto
			INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
			INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
			INNER JOIN PeriodoCabecera PC WITH(NOLOCK) ON PE.IdPeriodoCabecera=PC.IdPeriodoCabecera
			INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo 
			INNER JOIN Turno TU WITH(NOLOCK) ON PG.idturno = TU.idturno 
			INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.idmaestroregistro=tu.idtipoturno
			LEFT JOIN PromocionGrupoCierre PGC WITH(NOLOCK) ON MA.IdMatricula = PGC.IdMatricula 
			WHERE MA.IdActor=@IdActor  
			AND  MA.Estado <> 'X'
			AND PE.IdPeriodo =@IdPeriodoAnteriorTS
		END 
	END
-- FIN ALSANCHEZ @8	
	UPDATE MA SET MA.NombreDescuento=MTR2.Nombre,
	MA.CodigoDescuento=MTR2.Codigo,
	MA.IdTipoConsulta = MTR2.IdMaestroRegistro,
	MA.PeriodoCodigoBase=DAB.PeriodoCodigo
	FROM @MatriculaAnterior AS MA
	INNER JOIN DescuentoAcademicoBase AS DAB WITH(NOLOCK) ON DAB.IdActor = MA.IdActor
	INNER JOIN MaestroTablaRegistro AS MTR2  WITH(NOLOCK) ON MTR2.IdMaestroRegistro = DAB.IdMaestroRegistro 
	WHERE MTR2.Codigo = @CodigoBase AND DAB.Activo=1

	UPDATE MA SET MA.TieneBecaDescuentoAlumnoResultado= 1
	FROM @MatriculaAnterior AS MA
	INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON DAR.IdMatricula = MA.IdMatricula
	INNER JOIN DescuentoAcademico AS DA WITH(NOLOCK) ON DA.IdDescuentoAcademico = DAR.IdDescuentoAcademico
	INNER JOIN DescuentoAcademicoPoblacion DAP WITH(NOLOCK) ON DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico 
	AND (MA.IdTipoConsulta = case when ma.IdTipoConsulta=29317 and DAP.IdTipoSituacionAlumno=47096 AND @CompaniaSocio='00002700' then 29317 else dap.IdTipoSituacionAlumno end)--@11

	
	SELECT TOP 1 @IdMatriculaAnterior = IdMatricula , 
	@IdSedeAnterior=IdSede,
	@IdModuloPagoAnterior = CASE WHEN IdModulo = 1 THEN 3 ELSE 2 END,--@13
	@PeriodoCodigoBase=ISNULL(PeriodoCodigoBase,''),
	@TurnoAnterior=TipoTurnoDispo5,
	@ProductoAnterior=ProductoNombre,
	@SedeNombreAnterior=SedeNombreAnterior,
	@PeriodoCodigoMatriculaAnterior = Codigo,
	@PromedioReal=PromedioReal,
	@IdProductoAnterior=IdProducto,
	@IdTipoConsulta=isnull(IdTipoConsulta,-1),
	@TieneBecaDescuentoAlumnoResultado = TieneBecaDescuentoAlumnoResultado,
	@IdModuloAnterior =IdModulo  FROM @MatriculaAnterior 
	
	--Validamos que el alumno cuenta con la beca activate anteriomente, aunque no la alla tenido en su resultado
	IF  @TieneBecaDescuentoAlumnoResultado=0 AND @CompaniaSocio='00002700'--@3--@7	
	BEGIN
		UPDATE MA SET MA.TieneBecaDescuentoAlumno= 1
		FROM @MatriculaAnterior AS MA
		INNER JOIN DescuentoAlumno DAR WITH(NOLOCK) ON DAR.IdMatricula = MA.IdMatricula
		INNER JOIN DescuentoAcademico AS DA WITH(NOLOCK) ON DA.IdDescuentoAcademico = DAR.IdDescuentoAcademico
		INNER JOIN DescuentoAcademicoPoblacion DAP WITH(NOLOCK) ON DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico 
		AND (MA.IdTipoConsulta = case when ma.IdTipoConsulta=29317 and DAP.IdTipoSituacionAlumno=47096 AND @CompaniaSocio='00002700' then 29317 else dap.IdTipoSituacionAlumno end)--@11
		WHERE DA.Activo=1
		SELECT @TieneBecaDescuentoAlumnoResultado=TieneBecaDescuentoAlumno FROM @MatriculaAnterior
	END

	IF  @IdTipoConsulta=-1
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'ALUMNO NO SE ENCUENTRA REGISTRADO EN LA BASE '+ convert(varchar,@CodigoBase)
		
		SET @ExcluidoPorBase = 1
		RETURN
	END

	-- 1 MAYOR O IGUAL AL 2024, 0 ES CUANDO NO SEA 2024
	IF @CompaniaSocio='00002700' OR @CompaniaSocio='00002500' --@5--@6
	BEGIN
		SET @Validacion2024=  CASE WHEN (CASE WHEN LEFT (@PeriodoCodigoBase,4)='' THEN 0 ELSE CONVERT(INT,LEFT (@PeriodoCodigoBase,4)) END)>=2024 THEN 1 ELSE 0 END 
	END
	

	SELECT @PromedioBeca = Disponible1,
	@CambioCarreraBeca=Disponible3,
	@IdModuloBecaValidar=Disponible5,
	@ValidaRetiro=Disponible2,
	@ValidaCambioSede=Disponible4,
	@ValidaTipoCondicion=Disponible6,
	@ValidaPagoPuntualBeca=Disponible7,
	@ValidaTipoTurno= Disponible8,
	@ValidaReingreso = Disponible9 FROM MaestroTablaRegistro WITH(NOLOCK) 
	WHERE  IdmaestroRegistro = @IdTipoConsulta	
	
	SELECT @PeriodosAnterioresConcatenados = COALESCE(@PeriodosAnterioresConcatenados + ', ', '') + CAST(CodigoPeriodoAnterior AS VARCHAR(50))
	FROM (SELECT DISTINCT CodigoPeriodoAnterior FROM @PeriodosAnteriores) AS Temp

	SELECT @ValidaCambioDeModalidad=Valor FROM EmpresaSedeParametro WHERE Nombre='SEDEMODVIRTUAL' AND IdSede=@IdSedeAnterior AND Activo=1--@4
	--INICIAMOS LAS VALIDACIONES
BEGIN

	--CONDICION SOLO PARA LOS DE CORRIENTE ALTERA
	IF @CompaniaSocio='00002600' --@12
	BEGIN
	-- PIERDE LA BECA SI SU PROMEDIO ES MENOR A DESAPROBATORIO
		IF @PromedioReal < @PromedioBeca -- 18
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion = 'EXCLUIDO POR PROMEDIO, EL PROMEDIO DEL ALUMNO ES: ' + CONVERT(VARCHAR, @PromedioReal)
			SET @ExcluidoPorPromedio37 = 1
			RETURN
		END

		-- CUANDO ES SU TERCER CICLO PIERDE LA BECA
		--SET @IdModuloPagoAnterior = 2
		SET @ExcluidoPorPagoPuntual = ISNULL((SELECT dbo.cPagoPuntual(@IdActor, @CompaniaSocio, @IdMatriculaAnterior, @IdModuloPagoAnterior)), 0)

		IF @ExcluidoPorPagoPuntual = 1 
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion = 'EXCLUIDO POR PAGO PUNTUAL EN SU MATRICULA ANTERIOR, EL PERIODO DE LA MATRICULA ES: ' + @PeriodoCodigoMatriculaAnterior
			RETURN
		END
    
		-- SI NO SE CUMPLE NINGUNA CONDICI�N, TODO EST� CORRECTO
		SET @Retorno = 1
		SET @pDescripcion = 'SI LE CORRESPONDE LA BECA'
		SELECT @pDescripcion
		RETURN
	END

	--CONDICION PARA LA NUEVA LOGICA IDAT 
	IF @CodigoBase = 'TIP0000037' --@2
	BEGIN
		--PIERDE LA BECA SI SU PROMEDIO ES MENOR A DESAPROBATORIO
		IF   @PromedioReal<@PromedioBeca--12.5
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion= 'EXCLUIDO POR PROMEDIO (LOGICA 2024 MAYO), EL PROMEDIO DEL ALUMNO ES : '+ convert(varchar,@PromedioReal)
			SET @ExcluidoPorPromedio37 = 1
			RETURN
		END

		--CUANDO ES SU TERCER CICLO PIERDE LA BECA

		IF  @PeriodoCodigoMatriculaAnterior <> @PeriodoCodigoBase
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion= 'EXCLUIDO POR SECUENCIALIDAD MAYOR AL SEGUNDO CICLO (LOGICA 2024 MAYO)'
			SET @ExcluidoPorSecuencialidad = 1
			RETURN
		END

	END
	-- Validamos que la matricula actual tenga una matricula anterior
	IF  NOT EXISTS(SELECT 1 FROM @MatriculaAnterior)
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'EXCLUIDO POR NO TENER UNA MATRICULA ANTERIOR - EN LOS PERIODOS : ' + @PeriodosAnterioresConcatenados
		SET @ExcluidoPorNoTenerMatricula=1
		RETURN
	END
	-- VALIDAR SI TIENE BECA ACTIVATE EN LA MATRICULA ANTERIOR 
	IF  (@TieneBecaDescuentoAlumnoResultado = 0 OR @IdTipoConsulta=-1 ) AND @IdModuloAnterior > 1 --@1	
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion='EXCLUIDO POR NO CONTAR CON LA BECA ACTIVATE EN SU MATRICULA ANTERIOR - EN EL PERIODO : ' + @PeriodoCodigoMatriculaAnterior
		SET @ExcluidoPorBeca=1
		RETURN
	END
	-- VALIDAR SI TIENE CAMBIO DE TURNO 
	--ESTA LOGICA SOLO APLICA PARA TODOS LOS ALUMNOS DEL 2024 HACIA ADELANTE 
	IF @Validacion2024 = 0
	BEGIN
		IF NOT EXISTS( SELECT 1 FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor 
		AND IdMaestroRegistro = @IdMaestroRegistroCT AND B.Activo = 1 AND PeriodoCodigo=@CodigoPeriodo)
		BEGIN
			IF @TipoTurnoActual<>@TurnoAnterior AND @IdPeriodoAnteriorTS IS NULL--@8
			BEGIN
				SET @Retorno = 0
				SET @pDescripcion= 'EXCLUIDO POR CAMBIO DE TURNO: ANTERIOR ( '+@TurnoAnterior+' )'+ ' y ACTUAL( ' +@TipoTurnoActual+' )' -- IMPRIMIR EL TURNO QUE LE CORRESPONDE (TURNO ACTUAL Y TURNO ANTERIOR)
				SET @ExcluidoPorTurno=1
				RETURN
			END
		END

		-- VALIDAR SI TIENE CAMBIO DE CARRERA
		IF NOT EXISTS( SELECT 1 FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor 
		AND IdMaestroRegistro = @IdMaestroRegistroCC AND B.Activo = 1 AND PeriodoCodigo=@CodigoPeriodo)
		BEGIN
			--SI @IdPeriodoAnteriorTS VIENE CON ALGUN VALOR ES PORQUE HA TENIDO UN CAMBIO DE PROGRAMA
			IF @IdProductoActual<>@IdProductoAnterior AND @IdPeriodoAnteriorTS IS NULL--@8
			BEGIN
				SET @Retorno = 0
				SET @pDescripcion= 'EXCLUIDO POR CAMBIO DE CARRERA, ANTERIOR: '+ @ProductoAnterior + ' y ACTUAL : ' + @ProductoActual -- IMPRIMIR LA CARRERA QUE LE CORRESPONDE (CARRERA ACTUAL Y CARRERA ANTERIOR)
				SET @ExcluidoPorCambioCarrera=1
				RETURN
			END
		END
	END

	-- VALIDAR SI TIENE CAMBIO DE TIPO CONDICION
	IF NOT EXISTS( SELECT 1 FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor 
		AND IdMaestroRegistro = @IdMaestroRegistroTC AND B.Activo = 1 AND PeriodoCodigo=@CodigoPeriodo AND IdUnidadAcademica=@IdUnidadAcademica)--@9
	BEGIN
		IF   @TipoCondicionActual <> 'RE' 
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion= 'EXCLUIDO POR  TIPO DE CONDICION(NO REGULAR), ACTUAL : '+ @TipoCondicionActual --TIPO DE CONDICION ACTUAL QUE SE IMPRIMA
			SET @ExcluidoPorCondicion=1
			RETURN
		END
	END

	-- Validamos que no tenga retiro de ciclo en su carrera
	IF EXISTS(SELECT 1 FROM MatriculaRetiro WITH(NOLOCK) WHERE IdActor = @IdActor AND Estado = 'R' 
	AND Tipo = 'RC' AND (IdMatricula IN (SELECT IdMatricula FROM @MatriculaAnterior)OR EXISTS(SELECT 1 FROM @MatriculaAnterior WHERE Estado = 'R')))
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion='EXCLUIDO POR RETIRO DE CICLO EN SU MATRICULA ANTERIOR'
		SET @ExcluidoPorRetiro=1
		RETURN
	END
	--Validamos si el alumno tiene un cambio de modalidad en su matricula
	--Cambio de petit 2 a otra sede, se considera cambio de modalidad
	IF NOT EXISTS( SELECT 1 FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor --@4
	AND IdMaestroRegistro = @IdMaestroRegistroCS AND B.Activo = 1 AND PeriodoCodigo=@CodigoPeriodo) 
	BEGIN
		IF @ValidaCambioDeModalidad=1 AND @IdSedeActual<>@IdSedeAnterior
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion= 'EXCLUIDO POR TENER UN CAMBIO DE MODALIDAD EN SU MATRICULA EN EL PERIODO : ' + @PeriodoCodigoMatriculaAnterior
			SET @ExcluidoPorCambioDeModalidad=1
			RETURN
		END
	END
	-- Validamos que no tenga cambio de sede 
	IF NOT EXISTS( SELECT 1 FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor 
	AND IdMaestroRegistro = @IdMaestroRegistroCS AND B.Activo = 1 AND PeriodoCodigo=@CodigoPeriodo) 
	BEGIN
		IF @IdSedeActual<>@IdSedeAnterior AND @IdPeriodoAnteriorTS IS NULL--@8
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion= 'EXCLUIDO POR CAMBIO DE SEDE, ANTERIOR  : '+ @SedeNombreAnterior +' y  ACTUAL ES :'+ @SedeActual
			SET @ExcluidoPorCambioSede=1
			RETURN
		END
	END
	--Validamos el ciclo de la beca con el de su matricula
	IF @IdModuloActual>@IdModuloBecaValidar
	BEGIN
		-- Validamos que su promedio sea mayor a 18 en su carrera
		-- si tu beca es TIP0000013	NULL	BECA AMERICA TV SECUENCIAL 50% X 2 CICLOS 
		--  y modulo > 2  no validamos por primedio 
		IF   @PromedioReal<@PromedioBeca
		BEGIN
			SET @Retorno = 0
			SET @pDescripcion= 'EXCLUIDO POR PROMEDIO, EL PROMEDIO DEL ALUMNO ES : '+ convert(varchar,@PromedioReal) --EXLUCIDO POR PROMEDIO INCLUIR EL PROMEDIO ACTUAL QUE TIENE
			SET @ExcluidoPorPromedio = 1
			RETURN
		END

		--IF @Validacion2024=1
		--BEGIN
		--	SET @IdModuloPagoAnterior=3--@13
		--END

		SET @ExcluidoPorPagoPuntual=ISNULL((SELECT dbo.cPagoPuntual (@IdActor,@CompaniaSocio,@IdMatriculaAnterior, @IdModuloPagoAnterior)),0)
		IF @ExcluidoPorPagoPuntual = 1 
		BEGIN
			-- si tu beca es TIP0000013	NULL	BECA AMERICA TV SECUENCIAL 50% X 2 CICLOS 
			--  y modulo > 2  no validamos por promedio 
			SET @Retorno = 0
			SET @pDescripcion= 'EXCLUIDO POR PAGO PUNTUAL EN SU MATRICULA ANTERIOR, EL PERIODO DE LA MATRICULA ES: ' + @PeriodoCodigoMatriculaAnterior
			RETURN
		END

	END

	IF @ExcluidoPorRetiro = 0 
	AND @ExcluidoPorBeca = 0
	AND @ExcluidoPorTurno = 0
	AND @ExcluidoPorCambioCarrera = 0
	AND @ExcluidoPorCondicion = 0
	AND @ExcluidoPorPromedio = 0
	AND @ExcluidoPorCambioSede = 0
	AND @ExcluidoPorSecuencialidad=0
	AND @ExcluidoPorBase=0
	AND @ExcluidoPorCambioDeModalidad=0--@4
	AND @ExcluidoPorPagoPuntual=0
	AND @ExcluidoPorNoTenerMatricula=0
	AND @ExcluidoPorPromedio37 = 0
	AND @ExcluidoPorNoTenerMatriculaAProcesar=0
	AND @ExcluidoPorPeriodoAnterior=0
	BEGIN	
		SET @Retorno = 1
		SET @pDescripcion = 'SI LE CORRESPONDE LA BECA'
		RETURN								 		
	END
	ELSE
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion = 'NO LE CORRESPONDE LA BECA'
		RETURN
	END

END