--BD
USE AcademicoIDAT
GO

SET NOCOUNT ON

DECLARE @Periodocodigo VARCHAR(50) = '2024-IIIA',
@FechaVencimientoNuevo varchar(20) = '20240825' , 
@CompaniaSocio varchar(20) = '00002700',
@CuotaNumero INT = 2,
@IdModulo INT = 1

--SELECT CONVERT(VARCHAR, GETDATE(), 112) --20230918

DECLARE @TempPeriodo TABLE        
	(PeriodoCodigo VARCHAR(MAX))   

INSERT INTO @TempPeriodo(PeriodoCodigo)        
	SELECT distinct data FROM dbo.Split(@Periodocodigo,',')  

DECLARE @table AS TABLE(id INT IDENTITY(1,1) , idmatricula INT , NumeroInterno INT, NumeroDocumento VARCHAR(100), tipo VARCHAR(100),
nombres VARCHAR(200), codigo VARCHAR(100), promocionCodigo VARCHAR(100), nombrePromocion VARCHAR(100), matriculafecha VARCHAR(50), 
InscritoFecha VARCHAR(100), estado VARCHAR(10), cuota INT, FechaVencimiento VARCHAR(50), UnidadNegocio VARCHAR(100), UnidadAcademica VARCHAR(100))

--select * from UnidadAcademica

----/*UPDATE SMART*/
--UPDATE cp SET cp.FechaVencimiento = @FechaVencimientoNuevo
--FROM promocion p
--INNER JOIN periodo pe on pe.idperiodo = p.idperiodo 
--INNER JOIN CronogramaPago CP ON CP.IdPromocion = P.IdPromocion 
--where pe.codigo IN (SELECT PeriodoCodigo FROM @TempPeriodo)
--AND CP.CuotaNumero = @CuotaNumero
--AND P.IdModulo = @IdModulo

/*UPDATE SPRING*/
INSERT INTO @table ( idmatricula,NumeroInterno,NumeroDocumento,tipo, nombres,codigo, promocionCodigo, nombrePromocion,matriculafecha,InscritoFecha,estado,cuota,FechaVencimiento,UnidadNegocio,UnidadAcademica)
SELECT m.idmatricula , H.NumeroInterno , H.NumeroDocumento, 'Pre', a.NombreCompleto, '',p.PromocionCodigo, p.PromocionNombre
,CONVERT(varchar,M.matriculafecha,112), CONVERT(varchar,M.InscritoFecha,112), H.Estado, H.CuotaNumero, CONVERT(varchar,H.FechaVencimiento,112), un.Nombre, ua.Nombre
FROM Matricula m
INNER JOIN actor a on a.IdActor = m.IdActor
INNER JOIN promocion p on p.idpromocion = m.idpromocion
INNER JOIN periodo pe on pe.idperiodo = p.idperiodo 
INNER JOIN UnidadAcademica ua on p.IdUnidadAcademica = ua.IdUnidadAcademica
INNER JOIN UnidadNegocio un on p.IdUnidadNegocio = un.IdUnidadNegocio
INNER JOIN CO_Interfase_P09_Header H 
	ON H.IdMatricula = M.IdMatricula AND H.CompaniaSocio = @CompaniaSocio AND CUOTANUMERO = @CuotaNumero AND H.ESTADO IN ('PR', 'GE')
WHERE m.estado <> 'X'
AND pe.codigo IN (SELECT PeriodoCodigo FROM @TempPeriodo)
AND M.EsMatricula=0
AND P.IdUnidadAcademica = 57
AND P.IdModulo = @IdModulo
--AND CONVERT(varchar,H.FechaVencimiento,112) != @FechaVencimientoNuevo
UNION
SELECT m.idmatricula , H.NumeroInterno , H.NumeroDocumento,'Matriculado',a.NombreCompleto, '',p.PromocionCodigo, p.PromocionNombre
,CONVERT(varchar,M.matriculafecha,112), CONVERT(varchar,M.InscritoFecha,112), H.Estado, H.CuotaNumero, CONVERT(varchar,H.FechaVencimiento,112), un.Nombre, ua.Nombre
FROM Matricula m
INNER JOIN actor a on a.IdActor = m.IdActor
INNER JOIN promocion p on p.idpromocion = m.idpromocion
INNER JOIN periodo pe on pe.idperiodo = p.idperiodo
INNER JOIN UnidadAcademica ua on p.IdUnidadAcademica = ua.IdUnidadAcademica
INNER JOIN UnidadNegocio un on p.IdUnidadNegocio = un.IdUnidadNegocio
INNER JOIN CO_Interfase_P09_Header H 
	ON H.IdMatricula = M.IdMatricula AND H.CompaniaSocio = @CompaniaSocio AND CUOTANUMERO = @CuotaNumero AND H.ESTADO IN ('PR', 'GE')
WHERE m.estado  <> 'X'
AND pe.codigo IN (SELECT PeriodoCodigo FROM @TempPeriodo)
AND M.EsMatricula=1
AND P.IdUnidadAcademica = 57
AND P.IdModulo = @IdModulo
--AND CONVERT(varchar,H.FechaVencimiento,112) != @FechaVencimientoNuevo


DECLARE @MIN INT , @MAX INT, @idmatricula INT , @NumeroInterno INT, @Estado VARCHAR(10) , @NumeroDocumento VARCHAR(100)

SELECT @MIN = MIN(ID), @MAX  = MAX(ID) FROM @table


WHILE @MIN <= @MAX
BEGIN

	--PRINT 'Avance: ' + CONVERT(VARCHAR,@MIN)

	SET @idmatricula = NULL
	SET @NumeroInterno = NULL 
	SET @NumeroDocumento = NULL 

	SELECT @idmatricula = idmatricula, 
	@NumeroInterno = NumeroInterno ,
	@NumeroDocumento = NumeroDocumento  FROM @table WHERE ID = @MIN

	--UPDATE PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header SET FechaVencimiento = @FechaVencimientoNuevo,FechaModificacion=GETDATE() 
	--WHERE CompaniaSocio = @CompaniaSocio AND NumeroInterno = @NumeroInterno 

	--UPDATE PLDB01.SpringUnido.dbo.CO_Documento SET FechaVencimiento = @FechaVencimientoNuevo,UltimaFechaModif=GETDATE(),  ULTIMOusuario = 'ADMIN'
	--WHERE CompaniaSocio = @CompaniaSocio AND TipoDocumento = LEFT( @NumeroDocumento , 2 ) 
	--AND NumeroDocumento = SUBSTRING(@NumeroDocumento,4,100) AND Estado = CASE Interfase_Cuota WHEN 1 THEN 'AP' ELSE 'PR' END

	PRINT 'UPDATE CO_Interfase_P09_Header SET FechaVencimiento = ''' + @FechaVencimientoNuevo + ''',FechaModificacion=GETDATE() WHERE CompaniaSocio = ''00002700'' AND NumeroInterno = ''' + convert(varchar,@NumeroInterno) + ''' AND LEFT(ISNULL(''' + @NumeroDocumento + ''',''''),2) NOT IN (''FC'')  AND Estado != ''CO'' '

	PRINT 'UPDATE CO_Documento SET FechaVencimiento = ''' + @FechaVencimientoNuevo + ''',UltimaFechaModif=GETDATE() WHERE CompaniaSocio =''00002700'' AND TipoDocumento = LEFT( ''' + @NumeroDocumento + ''' , 2 ) AND NumeroDocumento = SUBSTRING( ''' + @NumeroDocumento + ''',4,100) AND TipoDocumento NOT IN(''FC'') AND Estado =  ''PR'' '

	SET @MIN = @MIN + 1  
END

SET NOCOUNT OFF

--select T.*, H.FechaVencimiento Vencimiento_Interfase, D.FechaVencimiento Vencimiento_Documento  
--from @table t
--INNER JOIN PLDB01.SpringUnido.dbo.CO_Interfase_P09_Header H 
--ON H.IdMatricula = t.IdMatricula AND H.CompaniaSocio = @CompaniaSocio AND H.NumeroInterno = T.NumeroInterno 
--LEFT JOIN PLDB01.SpringUnido.dbo.CO_Documento D 
--ON H.CompaniaSocio = @CompaniaSocio AND D.TipoDocumento = LEFT( T.NumeroDocumento , 2 ) AND D.NumeroDocumento = SUBSTRING(T.NumeroDocumento,4,100)
