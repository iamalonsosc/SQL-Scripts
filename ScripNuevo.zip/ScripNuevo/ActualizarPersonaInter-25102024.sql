UPDATE persona_inter SET procesado='NO',tiporegistro='X'
WHERE id=8190

UPDATE persona_inter SET tiporegistro='I'
WHERE id=1149025