
DECLARE
@IdProgramacion INT,
@UsuarioCreacion INT,
@RetVal INT 
BEGIN     
Select @IdProgramacion=31595,@UsuarioCreacion=1,@RetVal = NULL
--print 'hola'

	SET NOCOUNT ON
	
	SET DATEFORMAT DMY     
   
	SET @RetVal = 0     

	CREATE TABLE #MaestroTablaRegistro
	(
		IdMaestroRegistro INT,
		Codigo Varchar(100),
		Nombre VARCHAR(1000)
	)

	DECLARE
	@PtjeMinimo DECIMAL(18,8),      
	@TotAlumnosMat INT,      
	@TotAlumnosEnc INT,     
	@TotAlumnosEncReal INT,      
	@TotAlumnosPrg INT,      
	@PtjePregunta DECIMAL(18,8),      
	@PromPregunta DECIMAL(18,8),      
	@PromSubArea DECIMAL(18,8),      
	@PromArea DECIMAL(18,8),
	@PromEncuesta DECIMAL(18,8),     
	@PromEncuestaNPS DECIMAL(18,8),     
	@PromGeneral DECIMAL(18,8),     
	@SumPromPregunta DECIMAL(18,8),     
	@SumPromSubArea DECIMAL(18,8),     
	@CtaPromSubArea INT,     
	@SumPromArea DECIMAL(18,8),     
	@CtaPromArea INT,     
	@SumPromEncuesta DECIMAL(18,8),     
	@CtaPromEncuesta INT,     
	@SumPromGeneral DECIMAL(18,8),     
	@CtaPromGeneral INT ,     
	@Concatenar VARCHAR(MAX),     
	@EsAbierta BIT,     
	@Disponible1 VARCHAR(10),     
	@IdSeccion INT, --Bucle1 EAA     
	@IdPromocion INT, --Bucle1 ESA     
	@IdGrupo INT, --Bucle1 ESA     
	@IdArea INT, --Bucle2     
	@IdSubArea INT, --Bucle3      
	@IdPregunta INT, --Bucle4     
	@IdPreguntaNPS INT,  
	@IdAlternativa INT, --Bucle5     
	@IdDocente INT, --Bucle1 ESA     
	@Valor DECIMAL(18,8),      
	@Promediable INT,     
	@IdTipoPregunta INT,     
	@ValorPregunta DECIMAL(18,8), --@13     
	@PromediablePregunta INT, --@13     
	@PcjeRptaEncAca DECIMAL(5,2), --@15,     
	@IdSede INT, --@16     
	@FechaActual DATETIME,
	@MIN INT,
	@MAX INT,
	@MIN_Area INT,
	@MAX_Area INT,
	@MIN_SubArea INT,
	@MAX_SubArea INT,
	@MIN_Pregunta INT,
	@MAX_Pregunta INT,
	@MIN_Alternativa INT,
	@MAX_Alternativa INT,
	@TotalAlumnoNPS910 INT, --@20   
	@TotalAlumnoNPS06 INT, --@20   
	@CodigoArea VARCHAR(200)

	CREATE TABLE #EncuestaResumenSinAlternativas
	(
		IdProgramacionDetalle INT,
		IdProgramacion INT,
		IdFicha INT,
		IdEmpresa INT,
		IdSede INT,
		IdFacultad INT,
		IdUnidadNegocio INT,
		IdUnidadAcademica INT,
		IdPeriodo INT,
		IdProducto INT,
		IdSemestre INT,
		IdPromocion INT,
		IdGrupo INT,
		IdSeccion INT,
		IdCurso INT,
		IdActor INT,
		IdDocente INT,
		IdPregunta INT,
		IdTipoPregunta INT,
		IdArea INT,
		IdSubArea INT,
		IdTipoEncuesta INT,
		IdEstado INT,
		IdSistema INT,
		FechaInicio DATETIME,
		FechaFin DATETIME,
		Respondio INT,
		FechaRespuesta VARCHAR(100),-- PUEDE SER FECHA
		CodigoSede VARCHAR(20),
		NombreSede VARCHAR(100),
		CodigoPeriodo VARCHAR(20),
		NombrePeriodo VARCHAR(100),
		CodigoDivicion VARCHAR(20),
		NombreDivicion VARCHAR(100),
		CodigoPrograma VARCHAR(20),
		NombrePrograma VARCHAR(100),
		CodigoProducto VARCHAR(20),
		NombreProducto VARCHAR(150),
		CodigoSemestre VARCHAR(20),
		NombreSemestre VARCHAR(100),
		CodigoCurso VARCHAR(20),
		NombreCurso VARCHAR(200),
		CodigoSeccion VARCHAR(20),
		CodigoDocente VARCHAR(20),
		NombreDocente VARCHAR(150),
		CodigoArea VARCHAR(20),
		NombreArea VARCHAR(1000),
		CodigoSubArea VARCHAR(20),
		NombreSubArea VARCHAR(1000),
		DesEncuesta VARCHAR(200),
		TipoEncuesta VARCHAR(500),
		Dsp1TipoEncuesta VARCHAR(100),
		Dsp2TipoEncuesta VARCHAR(100),
		Dsp3TipoEncuesta VARCHAR(100),
		Dsp4TipoEncuesta VARCHAR(100),
		Dsp5TipoEncuesta VARCHAR(100),
		OrdenPregunta INT,
		DescPregunta VARCHAR(1000),
		DescAlternativa VARCHAR(8000),
		TipoPregunta VARCHAR(1000),
		TipoControl  VARCHAR(10),
		PtjeMinimo DECIMAL(18,8),
		TotAlumnosMat INT,
		TotAlumnosEnc INT,
		TotAlumnosPrg INT,
		TotAlumnosEncReal INT,
		TotalAlumnoNPS910 INT,
		TotalAlumnoNPS06 INT,
		PtjePregunta DECIMAL(18,8) ,
		PromPregunta DECIMAL(18,8) ,
		PromSubArea DECIMAL(18,8) ,
		PromArea  DECIMAL(18,8) ,
		PromEncuesta DECIMAL(18,8) ,
		PromGeneral DECIMAL(18,8) ,
		Respuesta VARCHAR(500),
		Vigente BIT,
		TipoCodSistema VARCHAR(10),
		CabEstado INT, --PUEDE SER VARCHAR
		DetEstado INT, --PUEDE SER VARCHAR
		EncEstado INT, --PUEDE SER VARCHAR
		UsuarioCreacion INT,
		FechaCreacion DATETIME,
		UsuarioModIFicacion INT,
		FechaModIFicacion DATETIME,
		ValorPregunta INT,
		PromediablePregunta INT
	)

	CREATE TABLE #FichaRespuestaActor
	(
		IdFicha INT,
		IdPregunta INT,
		IdAlternativa INT ,
		Respuesta VARCHAR(1000),
		IdActor INT,
		IdActividad INT,
		Fecha DATETIME,
		IdProgramacion INT,
		IdProgramacionDetalle INT
	)

	CREATE TABLE #FichaProgramacionDetalle
	(
		IdProgramacion INT,
		IdProgramacionDetalle INT,
		IdEmpresa INT,
		IdSede INT,
		IdFacultad INT,
		IdUnidadNegocio INT,
		IdUnidadAcademica INT,
		IdPeriodo INT,
		IdProducto INT,
		IdPromocion INT,
		IdGrupo INT,
		IdCurso INT,
		IdSeccion INT,
		IdDocente INT,
		Respondio INT,
		IdEstado INT,
		IdSemestre INT,
		IdActor INT
	)

	--Inicio @27
	CREATE TABLE #EncuestaResumen
	(
		IdProgramacionDetalle INT,
		IdProgramacion INT,
		IdFicha INT,
		IdEmpresa INT,
		IdSede INT,
		IdFacultad INT,
		IdUnidadNegocio INT,
		IdUnidadAcademica INT,
		IdPeriodo INT,
		IdProducto INT,
		IdSemestre INT,
		IdPromocion INT,
		IdGrupo INT,
		IdSeccion INT,
		IdCurso INT,
		IdActor INT,
		IdDocente INT,
		IdPregunta INT,
		IdTipoPregunta INT,
		IdAlternativa INT,
		IdArea INT,
		IdSubArea INT,
		IdTipoEncuesta INT,
		IdEstado INT,
		IdSistema INT,
		FechaInicio DATETIME,
		FechaFin DATETIME,
		Respondio INT,
		FechaRespuesta VARCHAR(100), --PUEDE SER FECHA
		CodigoSede VARCHAR(20),
		NombreSede VARCHAR(100),
		CodigoPeriodo VARCHAR(20),
		NombrePeriodo VARCHAR(100),
		CodigoDivicion VARCHAR(20),
		NombreDivicion VARCHAR(100),
		CodigoPrograma VARCHAR(20),
		NombrePrograma VARCHAR(100),
		CodigoProducto VARCHAR(20),
		NombreProducto VARCHAR(150),
		CodigoSemestre VARCHAR(20),
		NombreSemestre VARCHAR(100),
		CodigoCurso VARCHAR(20),
		NombreCurso VARCHAR(200),
		CodigoSeccion VARCHAR(20),
		CodigoDocente VARCHAR(20),
		NombreDocente VARCHAR(150),
		CodigoArea VARCHAR(20),
		NombreArea VARCHAR(1000),
		CodigoSubArea VARCHAR(20),
		NombreSubArea VARCHAR(1000),
		DesEncuesta VARCHAR(200),
		Valor INT,
		Promediable BIT,
		TipoEncuesta VARCHAR(500),
		Dsp1TipoEncuesta VARCHAR(100),
		Dsp2TipoEncuesta VARCHAR(100),
		Dsp3TipoEncuesta VARCHAR(100),
		Dsp4TipoEncuesta VARCHAR(100),
		Dsp5TipoEncuesta VARCHAR(100),
		OrdenPregunta INT,
		OrdenAlternativa INT,
		DescPregunta VARCHAR(1000),
		Opcion VARCHAR(3),
		DescAlternativa VARCHAR(8000),
		TipoPregunta VARCHAR(1000),
		TipoControl VARCHAR(10),
		PtjeMinimo DECIMAL(18,8),
		TotAlumnosMat INT,
		TotAlumnosEnc INT,
		TotAlumnosPrg INT,
		TotAlumnosEncReal INT,
		TotalAlumnoNPS910 INT,
		TotalAlumnoNPS06 INT,
		PtjePregunta DECIMAL(18,8) ,
		PromPregunta DECIMAL(18,8) ,
		PromSubArea  DECIMAL(18,8) ,
		PromArea DECIMAL(18,8) ,
		PromEncuesta DECIMAL(18,8) ,
		PromGeneral DECIMAL(18,8) ,
		Respuesta VARCHAR(500),
		Vigente  BIT,
		TipoCodSistema  VARCHAR(10),
		CabEstado INT, --PUEDE SER VARCHAR
		DetEstado INT, --PUEDE SER VARCHAR
		EncEstado INT, --PUEDE SER VARCHAR
		UsuarioCreacion INT,
		FechaCreacion DATETIME,
		UsuarioModIFicacion INT,
		FechaModIFicacion DATETIME,
		ValorPregunta INT,
		PromediablePregunta INT
	)

	CREATE TABLE #EncuestaDetalleEAA
	(
		ID INT IDENTITY(1,1) PRIMARY KEY,
		IdSeccion INT,
		IdDocente INT,
		TotAlumnosEnc INT
	)
	
	CREATE TABLE #EncuestaDetalleESA
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdPromocion INT,
		IdGrupo INT,
		TotAlumnosEnc INT
	)

	CREATE TABLE #EncuestaDetalle360
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdDocente INT,
		TotAlumnosEnc INT
	)

	CREATE TABLE #EncuestaDetalleAEP
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdDocente INT,
		TotAlumnosEnc INT
	)      

	DECLARE @EncuestaAreaEAA TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY,
		IdArea INT,
		CodigoArea VARCHAR(200),
		TotalAlumnoNPS910 INT,
		TotalAlumnoNPS06 INT
	)       

	DECLARE @EncuestaSubAreaEAA TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdSubArea INT
	)

	DECLARE @EncuestaPreguntaEAA TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdPregunta INT,
		ValorPregunta INT ,
		PromediablePregunta INT
	)

	DECLARE @AlternativaEAA TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdAlternativa INT,
		Valor INT ,
		Promediable BIT,
		IdTipoPregunta INT,
		TotAlumnosPrg INT,
		TotAlumnosEncReal INT
	)

	DECLARE @EncuestaAreaESA TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY,
		IdArea INT
	)  

	DECLARE @EncuestaSubAreaESA TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdSubArea INT
	)

	DECLARE @EncuestaPreguntaESA TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdPregunta INT,
		ValorPregunta INT ,
		PromediablePregunta INT
	)

	DECLARE @AlternativaESA TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdAlternativa INT,
		Valor INT ,
		Promediable BIT,
		IdTipoPregunta INT ,
		TotAlumnosPrg INT,
		TotAlumnosEncReal INT
	)     

	DECLARE @EncuestaArea360 TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY,
		IdArea INT
	)

	DECLARE @EncuestaSubArea360 TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdSubArea INT
	)

	DECLARE @EncuestaPregunta360 TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdPregunta INT,
		ValorPregunta INT ,
		PromediablePregunta INT
	)

	DECLARE @Alternativa360 TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdAlternativa INT,
		Valor INT ,
		Promediable BIT,
		IdTipoPregunta INT ,
		TotAlumnosPrg INT,
		TotAlumnosEncReal INT
	)

	DECLARE @EncuestaAreaAEP TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY,
		IdArea INT
	)

	DECLARE @EncuestaSubAreaAEP TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdSubArea INT
	)

	DECLARE @EncuestaPreguntaAEP TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdPregunta INT,
		ValorPregunta INT ,
		PromediablePregunta INT
	)

	DECLARE @AlternativaAEP TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdAlternativa INT,
		Valor INT ,
		Promediable BIT,
		IdTipoPregunta INT ,
		TotAlumnosPrg INT,
		TotAlumnosEncReal INT
	)

	DECLARE @EncuestaAreaEPG TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY,
		IdArea INT
	)

	DECLARE @EncuestaSubAreaEPG TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdSubArea INT
	)

	DECLARE @EncuestaPreguntaEPG TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdPregunta INT,
		ValorPregunta INT ,
		PromediablePregunta INT
	)

	DECLARE @AlternativaEPG TABLE
	(
		ID INT IDENTITY(1,1) PRIMARY KEY ,
		IdAlternativa INT,
		Valor INT ,
		Promediable BIT,
		IdTipoPregunta INT,
		TotAlumnosPrg INT,
		TotAlumnosEncReal INT
	)  
   
	--Inicio --@33
	DECLARE @TempPreguntasNPS AS TABLE
	(
		IdPregunta INT
	)

	INSERT @TempPreguntasNPS
	(
		IdPregunta
	)
	SELECT
		MTR.IdMaestroRegistro 
	FROM MaestroTabla MT WITH (NOLOCK)
	INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MT.IdMaestroTabla = MTR.IdMaestroTabla
	WHERE MT.Codigo = 'PreguntasE'
	AND MTR.Codigo LIKE '%EV_EA%'
	--Fin --@33   

	SET @FechaActual = GETDATE()
	SET @MIN = 0
	SET @MAX = 0
	--Fin @27
	SET @PtjeMinimo = 0
	SET @TotAlumnosMat = 0
	SET @TotAlumnosEnc = 0
	SET @TotAlumnosPrg = 0
	SET @TotAlumnosEncReal = 0
	SET @TotalAlumnoNPS910 = 0
	SET @TotalAlumnoNPS06 = 0
	SET @PtjePregunta = NULL
	SET @PromPregunta  =NULL     
	SET @PromSubArea = NULL
	SET @PromArea = NULL
	SET @PromEncuesta = NULL
	SET @PromGeneral = NULL     
    
	--SE CARGA LA TABLA TEMPORAL DE TRABAJO DE RESPUESTA SOLAMENTE CON LA PROGRAMACION A CONSOLIDAR
	INSERT INTO #FichaRespuestaActor
	SELECT
		IdFicha,
		IdPregunta,
		IdAlternativa,
		Respuesta,
		IdActor,
		IdActividad,
		Fecha,
		IdProgramacion,
		IdProgramacionDetalle
	FROM FichaRespuestaActor
	WHERE IdProgramacion = @IdProgramacion

	--@2     
	--se sincroniza la tabla #FichaRespuestaActor y #FichaProgramacionDetalle.Respondio para que coincidan los alumnos que respondieron en ambas tablas     
	UPDATE fpd      
	SET fpd.Respondio=CASE WHEN fra.IdActor IS NULL THEN 0 ELSE 1 END,     
	FechaRespuesta=CASE WHEN fra.IdActor IS NULL THEN null ELSE fra.Fecha END  --@6     
	FROM FichaProgramacionDetalle fpd WITH (NOLOCK)      
	LEFT JOIN #FichaRespuestaActor fra WITH (NOLOCK) ON fpd.IdProgramacion=fra.IdProgramacion and fpd.IdProgramacionDetalle=fra.IdProgramacionDetalle     
	WHERE fpd.IdProgramacion=@IdProgramacion     

	--SE CARGA LA TABLA TEMPORAL DE TRABAJO DE RESPUESTA SOLAMENTE CON LA PROGRAMACION A CONSOLIDAR
	INSERT INTO #FichaProgramacionDetalle
	SELECT
		IdProgramacion,
		IdProgramacionDetalle,
		IdEmpresa,
		IdSede,
		IdFacultad,
		IdUnidadNegocio,
		IdUnidadAcademica,
		IdPeriodo,
		IdProducto,
		IdPromocion,
		IdGrupo,
		IdCurso,
		IdSeccion,
		IdDocente,
		Respondio,
		IdEstado,
		IdSemestre,
		IdActor
	FROM FichaProgramacionDetalle
	WHERE IdProgramacion=@IdProgramacion
 
	--se borran todos los resultados consolidados previamente     
	DELETE FROM FichaProgramacionResumen     
	WHERE IdProgramacion=@IdProgramacion     
     
	--@5 Porcentaje de Respuesta en la Encuesta Academica para la 360     
	--SET @PcjeRptaEncAca=0.3     
	--SELECT CAST(Valor AS DECIMAL(5,2))     
	--FROM Parametro     
	--WHERE Nombre= 'PcjeRptaEncAca'      
    
	--Creamos la tabla temporal con todos los datos Basicos SIN ALTERNATIVAS
	INSERT INTO #EncuestaResumenSinAlternativas --@27
	SELECT DISTINCT
		IdProgramacionDetalle=0,
		fd.IdProgramacion,
		fp.IdFicha,
		fd.IdEmpresa,
		fd.IdSede,
		fd.IdFacultad,
		fd.IdUnidadNegocio,
		fd.IdUnidadAcademica,
		fd.IdPeriodo,
		fd.IdProducto,     
		fd.IdSemestre,
		fd.IdPromocion,
		fd.IdGrupo,
		fd.IdSeccion,
		fd.IdCurso,
		IdActor=0,
		fd.IdDocente,
		fp.IdPregunta,
		IdTipoPregunta=fp.IdTipo,
		fp.IdArea,
		fp.IdSubArea,
		IdTipoEncuesta=f.IdTipo,     
		pg.IdEstado,
		IdSistema=f.IdSistema,
		'FechaInicio'= @FechaActual,
		'FechaFin'= @FechaActual,
		Respondio=0,
		FechaRespuesta='',
		CodigoSede= '',
		NombreSede= '',
		CodigoPeriodo= '',     
		NombrePeriodo= '',
		CodigoDivicion= '',
		NombreDivicion= '',
		CodigoPrograma= '',
		NombrePrograma= '',
		CodigoProducto= '',
		NombreProducto= '',
		CodigoSemestre=CM.Codigo,     
		NombreSemestre=CM.Nombre,
		CodigoCurso= s.Codigo,
		NombreCurso= '',
		CodigoSeccion= PRG.GrupoCodigo,
		CodigoDocente= '',
		NombreDocente= '',
		CodigoArea= '',
		NombreArea= '',
		CodigoSubArea= '',     
		NombreSubArea= '',
		DesEncuesta=f.Nombre,
		TipoEncuesta= '',
		Dsp1TipoEncuesta='',
		Dsp2TipoEncuesta='',
		Dsp3TipoEncuesta='',
		Dsp4TipoEncuesta='',
		Dsp5TipoEncuesta='',
		OrdenPregunta=fp.Orden,  --@25 --@26
		DescPregunta= '',
		DescAlternativa= '',
		TipoPregunta= '',
		TipoControl= '',
		PtjeMinimo=@PtjeMinimo,
		TotAlumnosMat=@TotAlumnosMat,     
		TotAlumnosEnc=@TotAlumnosEnc,
		TotAIdUnidadNegociolumnosPrg=@TotAlumnosPrg,
		TotAlumnosEncReal=@TotAlumnosEncReal,
		TotalAlumnoNPS910=@TotalAlumnoNPS910,
		TotalAlumnoNPS06=@TotalAlumnoNPS06,
		PtjePregunta=@PtjePregunta,
		PromPregunta=@PromPregunta,
		PromSubArea=@PromSubArea,
		PromArea=@PromArea,
		PromEncuesta=@PromEncuesta,     
		PromGeneral=@PromGeneral,
		Respuesta='',
		Vigente=fp.Vigente,
		TipoCodSistema='',
		CabEstado='',
		DetEstado='',
		EncEstado='',
		UsuarioCreacion=@UsuarioCreacion,
		FechaCreacion= @FechaActual,     
		UsuarioModIFicacion=@UsuarioCreacion,
		FechaModIFicacion= @FechaActual,
		ValorPregunta= fp.Valor,
		PromediablePregunta = fp.Promediable--@13
	FROM FichaProgramacion pg WITH (NOLOCK)
	INNER JOIN #FichaProgramacionDetalle fd WITH (NOLOCK) ON pg.IdProgramacion = fd.IdProgramacion    
	INNER JOIN Ficha f WITH (NOLOCK) ON f.IdFicha=pg.IdFicha     
	INNER JOIN FichaPregunta fp WITH (NOLOCK) ON f.IdFicha=fp.IdFicha     
	LEFT JOIN Promocion P WITH (NOLOCK) ON FD.IdPromocion = P.IdPromocion
	LEFT JOIN CurriculaModulo CM WITH (NOLOCK) ON P.IdModulo=CM.IdModulo AND P.IdCurricula=CM.IdCurricula
	LEFT JOIN PromocionGrupo PRG WITH (NOLOCK) ON P.IdPromocion=PRG.IdPromocion AND FD.IdGrupo=PRG.IdGrupo  
	LEFT JOIN Seccion S WITH (NOLOCK) ON FD.IdSeccion=S.IdSeccion   
	WHERE pg.IdProgramacion=@IdProgramacion     
	AND fd.Respondio=1 --@2     
	AND fd.IdEstado = 1
	--AND FD.IdSeccion IN (612159,611042,599804)

	--Creamos la tabla temporal con todos los datos Basicos
	INSERT INTO #EncuestaResumen --@27
	SELECT DISTINCT
		IdProgramacionDetalle,
		IdProgramacion,
		pg.IdFicha,
		IdEmpresa,
		IdSede,
		IdFacultad,
		IdUnidadNegocio,
		IdUnidadAcademica,
		IdPeriodo,
		IdProducto,
		IdSemestre,
		IdPromocion,
		IdGrupo,
		IdSeccion,
		IdCurso,
		IdActor,
		IdDocente,
		pg.IdPregunta,
		IdTipoPregunta,
		pa.IdAlternativa,
		IdArea,
		IdSubArea,
		IdTipoEncuesta ,
		IdEstado,
		IdSistema,
		FechaInicio ,
		FechaFin ,
		Respondio ,
		FechaRespuesta,-- PUEDE SER FECHA
		CodigoSede   ,
		NombreSede  ,
		CodigoPeriodo   ,
		NombrePeriodo  ,
		CodigoDivicion   ,
		NombreDivicion  ,
		CodigoPrograma   ,
		NombrePrograma  ,
		CodigoProducto   ,
		NombreProducto ,
		CodigoSemestre   ,
		NombreSemestre  ,
		CodigoCurso   ,
		NombreCurso ,
		CodigoSeccion   ,
		CodigoDocente   ,
		NombreDocente ,
		CodigoArea ,
		NombreArea ,
		CodigoSubArea   ,
		NombreSubArea  ,
		DesEncuesta,
		pa.Valor,
		pa.Promediable,
		TipoEncuesta,
		Dsp1TipoEncuesta  ,
		Dsp2TipoEncuesta  ,
		Dsp3TipoEncuesta  ,
		Dsp4TipoEncuesta  ,
		Dsp5TipoEncuesta  ,
		OrdenPregunta ,
		PA.Orden ,
		DescPregunta ,
		PA.Opcion,
		DescAlternativa ,
		TipoPregunta ,
		TipoControl,
		PtjeMinimo ,
		TotAlumnosMat ,
		TotAlumnosEnc ,
		TotAlumnosPrg ,
		TotAlumnosEncReal ,
		TotalAlumnoNPS910,
		TotalAlumnoNPS06 ,
		PtjePregunta  ,
		PromPregunta  ,
		PromSubArea   ,
		PromArea   ,
		PromEncuesta  ,
		PromGeneral   ,
		Respuesta,
		pg.Vigente,
		TipoCodSistema ,
		CabEstado , -- PUEDE SER VARCHAR
		DetEstado ,-- PUEDE SER VARCHAR
		EncEstado ,-- PUEDE SER VARCHAR
		UsuarioCreacion ,
		FechaCreacion ,
		UsuarioModIFicacion ,
		FechaModIFicacion ,
		ValorPregunta ,
		PromediablePregunta
	FROM #EncuestaResumenSinAlternativas pg WITH (NOLOCK)
	LEFT JOIN PreguntaAlternativa pa WITH (NOLOCK) ON PG.IdFicha=PA.IdFicha AND PG.IdPregunta=PA.IdPregunta

	--se recupera el tipo de ficha y sede  
	SELECT TOP 1
		@Disponible1=MTR.Disponible1, @IdSede = IdSede
	FROM #EncuestaResumen ER WITH (NOLOCK)
	INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON ER.IdTipoEncuesta=MTR.IdMaestroRegistro  

	--INICIO @16
	SELECT
		@PcjeRptaEncAca=CAST(Valor AS DECIMAL(5,2))     
	FROM EmpresaSedeParametro WITH (NOLOCK) --@19     
	WHERE Nombre= 'PcjeRptaEncAca' and IdSede = @IdSede     
	--FIN @16

	INSERT INTO #MaestroTablaRegistro
	SELECT DISTINCT
		MTR.IdMaestroRegistro ,
		MTR.Codigo ,
		MTR.Nombre 
	FROM MaestroTabla MT WITH(NOLOCK)
	INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MT.IdMaestroTabla=MTR.IdMaestroTabla
	WHERE MT.Codigo IN (
	'TipoEncuesta',
	'TipoPregunta',
	'AreaE',
	'SubAreaE',
	'AlternativasE',
	'PreguntasE')
       
	--Actualizamos Actualiza Pregunta     
	UPDATE t     
	SET t.DescPregunta = dp.Nombre     
	FROM #EncuestaResumen t  WITH(NOLOCK)   
	--INNER JOIN MaestroTablaRegistro dp WITH (NOLOCK) on (t.IdPregunta=dp.IdMaestroRegistro)     
	INNER JOIN #MaestroTablaRegistro dp WITH (NOLOCK)ON (t.IdPregunta=dp.IdMaestroRegistro)

	--Actualiza Alternativa     
	UPDATE t     
	SET t.DescAlternativa = da.Nombre     
	FROM #EncuestaResumen t WITH(NOLOCK)     
	--INNER JOIN MaestroTablaRegistro da WITH (NOLOCK)on (t.IdAlternativa=da.IdMaestroRegistro)
	INNER JOIN #MaestroTablaRegistro da WITH (NOLOCK) on (t.IdAlternativa=da.IdMaestroRegistro)     

	--Actualizamos Tipo Pregunta     
	UPDATE t     
	SET t.TipoPregunta = tp.Nombre     
	FROM #EncuestaResumen t WITH(NOLOCK)
	INNER JOIN #MaestroTablaRegistro tp WITH (NOLOCK) on (t.IdTipoPregunta=tp.IdMaestroRegistro) --@27
   
	--Actualizamos Area     
	UPDATE t     
	SET t.CodigoArea =a.Codigo,
	t.NombreArea=a.Nombre     
	FROM #EncuestaResumen t WITH(NOLOCK)
	INNER JOIN #MaestroTablaRegistro a WITH (NOLOCK)on (t.IdArea=a.IdMaestroRegistro) --@27

	--Actualizamos Sub Area     
	UPDATE t     
	SET t.CodigoSubArea = sa.Codigo,t.NombreSubArea=sa.Nombre     
	FROM #EncuestaResumen t WITH(NOLOCK)
	INNER JOIN #MaestroTablaRegistro sa WITH (NOLOCK)on (t.IdSubArea=sa.IdMaestroRegistro) --@27

	--Actualizamos Tipo Encuesta     
	UPDATE t     
	SET t.TipoEncuesta=te.Nombre     
	FROM #EncuestaResumen t WITH(NOLOCK)
	INNER JOIN #MaestroTablaRegistro te ON (t.IdTipoEncuesta=te.IdMaestroRegistro) --@27    

	--Actualizamos Datos Generales       
	UPDATE t     
	SET t.CodigoSede=s.Codigo,t.NombreSede=s.Nombre,     
	t.CodigoDivicion=un.Codigo,t.NombreDivicion=un.Nombre,     
	t.CodigoPrograma=ua.Codigo,t.NombrePrograma=ua.Nombre,     
	t.CodigoPeriodo=p.Codigo,t.NombrePeriodo=p.Nombre,     
	t.CodigoProducto=pr.ProductoCodigo,t.NombreProducto=pr.ProductoNombre,     
	t.CodigoCurso=c.CursoCodigo,t.NombreCurso=c.CursoNombre   
	FROM #EncuestaResumen t WITH (NOLOCK)      
	INNER JOIN Sede s WITH (NOLOCK) ON s.IdSede=t.IdSede  
	LEFT JOIN UnidadNegocio un WITH (NOLOCK) ON un.IdUnidadNegocio=t.IdUnidadNegocio     
	LEFT JOIN UnidadAcademica ua WITH (NOLOCK) ON ua.IdUnidadAcademica=t.IdUnidadAcademica     
	LEFT JOIN Periodo p WITH (NOLOCK) ON p.IdPeriodo=t.IdPeriodo     
	LEFT JOIN Producto pr WITH (NOLOCK) ON pr.IdProducto=t.IdProducto     
	LEFT JOIN Curso c WITH (NOLOCK) ON c.IdCurso=t.IdCurso

	CREATE NONCLUSTERED INDEX [IDX_#MaestroTablaRegistro_001]
	ON [dbo].[#MaestroTablaRegistro] (IdMaestroRegistro)
   
	CREATE NONCLUSTERED INDEX [IDX_#EncuestaResumen_001]
	ON [dbo].[#EncuestaResumen] (IdProgramacion,IdSeccion,IdDocente,IdArea,IdSubArea,IdPregunta)

	CREATE NONCLUSTERED INDEX [IDX_#FichaRespuestaActor_001]
	ON [dbo].[#FichaRespuestaActor] ([IdProgramacion])

	CREATE NONCLUSTERED INDEX [IDX_#FichaProgramacionDetalle_001]
	ON [dbo].[#FichaProgramacionDetalle] (IdProgramacion,IdProgramacionDetalle,IdEmpresa,IdSede,IdFacultad,IdUnidadNegocio,IdUnidadAcademica,IdPeriodo,
	IdProducto,IdPromocion,IdGrupo,IdCurso,IdSeccion,IdDocente,Respondio)

	--Inicio @27
	--SI ES UNA ENCUESTA ACADEMICA EL RESUMEN ES POR SECCION, AREA, SUBAREA, PREGUNTA Y ALTERNATIVA     
	IF @Disponible1='EAA'--ENCUESTA ACADEMICA     
	BEGIN

		--Docente     
		UPDATE t     
		SET t.NombreDocente = a.NombreCompleto,t.CodigoDocente=F.CodigoAnterior     
		FROM #EncuestaResumen t WITH (NOLOCK)  
		INNER JOIN Actor a WITH (NOLOCK) on (t.IdDocente=a.IdActor)     
		INNER JOIN Facilitador F WITH (NOLOCK) on (t.IdDocente=F.IdFacilitador)       

		--@22 
		--total de alumno matriculados 
		UPDATE t     
		SET t.TotAlumnosMat=( SELECT COUNT(DISTINCT FD.IdActor)     
		FROM #FichaProgramacionDetalle FD WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3       
		AND FD.IdEmpresa=T.IdEmpresa  
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad
		AND FD.IdUnidadNegocio=T.IdUnidadNegocio       
		AND FD.IdUnidadAcademica=T.IdUnidadAcademica       
		AND FD.IdPeriodo=T.IdPeriodo       
		AND FD.IdProducto=T.IdProducto       
		AND FD.IdPromocion=T.IdPromocion       
		AND FD.IdGrupo=T.IdGrupo       
		AND FD.IdCurso=T.IdCurso       
		AND FD.IdSeccion=T.IdSeccion
		and FD.IdDocente =T.IdDocente  ---@23      
		) FROM #EncuestaResumen t WITH (NOLOCK)       
		--@22  

		--total de alumnos encuestados
		UPDATE t     
		SET t.TotAlumnosEnc=( SELECT COUNT(DISTINCT IdActor)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3       
		AND FD.IdEmpresa=T.IdEmpresa  
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad
		AND FD.IdUnidadNegocio=T.IdUnidadNegocio       
		AND FD.IdUnidadAcademica=T.IdUnidadAcademica       
		AND FD.IdPeriodo=T.IdPeriodo       
		AND FD.IdProducto=T.IdProducto       
		AND FD.IdPromocion=T.IdPromocion       
		AND FD.IdGrupo=T.IdGrupo       
		AND FD.IdCurso=T.IdCurso       
		AND FD.IdSeccion=T.IdSeccion
		and FD.IdDocente =T.IdDocente  --@23       
		AND FD.Respondio=1 
		) FROM #EncuestaResumen t WITH (NOLOCK)       
 
		--total de alumnos por pregunta
		UPDATE T
		SET t.TotAlumnosPrg=( SELECT COUNT(DISTINCT FRA.IdActor)      
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle FD  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle
		WHERE FRA.IdProgramacion=T.IdProgramacion  AND FD.IdSeccion=T.IdSeccion     
		AND FD.IdDocente =T.IdDocente  --@23
		AND FRA.IdPregunta=T.IdPregunta     
		AND FRA.IdAlternativa=T.IdAlternativa     
		AND FD.Respondio=1     
		) FROM #EncuestaResumen T WITH (NOLOCK)     
       
		--total de alumnos encuestados real
		UPDATE T
		SET T.TotAlumnosEncReal=(SELECT COUNT(DISTINCT FRA.IdActor)     
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle     
		WHERE FRA.IdProgramacion=T.IdProgramacion  
		AND FD.IdSeccion=T.IdSeccion   
		and FD.IdDocente =T.IdDocente  --@23   
		AND FRA.IdPregunta=T.IdPregunta
		AND FD.Respondio=1
		) FROM #EncuestaResumen T WITH (NOLOCK)     

		IF EXISTS ( SELECT 1 
		FROM #EncuestaResumen ER WITH(NOLOCK)
		INNER JOIN #MaestroTablaRegistro MTR WITH(NOLOCK) ON ER.IdArea=MTR.IdMaestroRegistro
		WHERE MTR.Codigo like 'NPS%')  --@30      
		BEGIN   

			UPDATE T
			SET T.TotalAlumnoNPS910=( SELECT COUNT(DISTINCT FRA.IdActor)     
			FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
			INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle     
			INNER JOIN #MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.IdMaestroRegistro=FRA.IdAlternativa     
			WHERE FRA.IdProgramacion=T.IdProgramacion  
			AND FD.IdSeccion=T.IdSeccion   
			and FD.IdDocente =T.IdDocente  --@23   
			AND FRA.IdPregunta=T.IdPregunta
			AND FD.Respondio=1
			AND MTR.Codigo in ('NU09','NU10')   
			) FROM #EncuestaResumen T WITH (NOLOCK) 
 
			UPDATE T
			SET T.TotalAlumnoNPS06=( SELECT COUNT(DISTINCT FRA.IdActor)     
			FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
			INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle     
			INNER JOIN #MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.IdMaestroRegistro=FRA.IdAlternativa     
			WHERE FRA.IdProgramacion=T.IdProgramacion  
			AND FD.IdSeccion=T.IdSeccion   
			and FD.IdDocente =T.IdDocente  --@23   
			AND FRA.IdPregunta=T.IdPregunta
			AND FD.Respondio=1
			AND MTR.Codigo in ('NU11','NU01','NU02','NU03','NU04','NU05','NU06')   
			) FROM #EncuestaResumen T WITH (NOLOCK) 
   
		END  -- Fin @20   

       
		--@15 se borra todos los alumnos que llegan al 30%     
		DELETE #EncuestaResumen     
		WHERE (CASE WHEN TotAlumnosMat>0 THEN ROUND(CAST(TotAlumnosEnc AS DECIMAL)/CAST(TotAlumnosMat AS DECIMAL),2) ELSE 0.0 END) < @PcjeRptaEncAca    

		INSERT INTO #EncuestaDetalleEAA
		(IdSeccion,IdDocente,TotAlumnosEnc) --@27
		SELECT IdSeccion,IdDocente,TotAlumnosEnc       --@23
		FROM (SELECT DISTINCT IdSeccion,IdDocente,TotAlumnosEnc       --@23
		FROM #EncuestaResumen WITH (NOLOCK))AS Temp

		PRINT 'TOTAL: ' + CONVERT(VARCHAR, @MAX)

		--INICIO DETALLE     
		SELECT @MIN = MIN(ID), @MAX = MAX(id) FROM #EncuestaDetalleEAA WITH (NOLOCK)
		
		WHILE @MIN <= @MAX ---@24
		BEGIN

			PRINT 'PROGRESO: ' + CONVERT(VARCHAR, @MIN)

			SET @IdSeccion = NULL
			SET @IdDocente = NULL
			SET @TotAlumnosEnc = NULL
     
			SELECT @IdSeccion=IdSeccion,@IdDocente =IdDocente,@TotAlumnosEnc=TotAlumnosEnc      --@23
			FROM #EncuestaDetalleEAA WITH (NOLOCK)
			WHERE ID = @MIN 
  
			IF @TotAlumnosEnc >0      
			BEGIN

				SET @PromEncuesta=NULL     
				SET @SumPromEncuesta=NULL     
				SET @CtaPromEncuesta=NULL     
				SET @TotalAlumnoNPS910=NULL
				SET @TotalAlumnoNPS06=NULL 
  
				--INICIO AREA
				DELETE FROM @EncuestaAreaEAA
				SET @MIN_Area = 0
				SET @MAX_Area = 0

				INSERT INTO @EncuestaAreaEAA(IdArea,CodigoArea,TotalAlumnoNPS910,TotalAlumnoNPS06)       
				SELECT IdArea,CodigoArea,TotalAlumnoNPS910,TotalAlumnoNPS06  
				FROM ( SELECT DISTINCT IdArea,CodigoArea,TotalAlumnoNPS910,TotalAlumnoNPS06      
				FROM #EncuestaResumen WITH (NOLOCK)    
				WHERE IdProgramacion=@IdProgramacion      
				AND IdSeccion=@IdSeccion
				and IdDocente =@IdDocente) AS Temp       --@23 
   
				SELECT @MIN_Area = MIN(ID) , @MAX_Area = MAX(ID) FROM @EncuestaAreaEAA 
				WHILE @MIN_Area <= @MAX_Area       
				BEGIN 

					SET @IdArea = NULL
					SET @PromArea = NULL     
					SET @SumPromArea = NULL     
					SET @CtaPromArea = NULL  
					SET @CodigoArea = NULL
					SET @TotalAlumnoNPS910 = NULL
					SET @TotalAlumnoNPS06 = NULL
 
					SELECT @IdArea=IdArea,
					@CodigoArea=CodigoArea,
					@TotalAlumnoNPS910=TotalAlumnoNPS910,
					@TotalAlumnoNPS06=TotalAlumnoNPS06
					FROM @EncuestaAreaEAA
					WHERE ID = @MIN_Area     

					--INICIO SUB AREA
					DELETE FROM @EncuestaSubAreaEAA
					SET @MIN_SubArea = 0
					SET @MAX_SubArea = 0
   
					INSERT INTO @EncuestaSubAreaEAA(IdSubArea)
					SELECT IdSubArea   
					FROM ( SELECT DISTINCT IdSubArea      
					FROM #EncuestaResumen WITH (NOLOCK)    
					WHERE IdProgramacion=@IdProgramacion      
					AND IdSeccion=@IdSeccion 
					and IdDocente =@IdDocente --@23    
					AND IdArea=@IdArea )AS Temp       
   
					SELECT @MIN_SubArea = MIN(ID) , @MAX_SubArea = MAX(ID) FROM @EncuestaSubAreaEAA
					WHILE @MIN_SubArea <= @MAX_SubArea     
					BEGIN

						SET @IdSubArea = NULL
  
						SELECT @IdSubArea=IdSubArea      
						FROM @EncuestaSubAreaEAA
						WHERE ID = @MIN_SubArea  
     
						SET @PromSubArea = NULL     
						SET @SumPromSubArea = NULL     
						SET @CtaPromSubArea = NULL     
						SET @EsAbierta = 0     

						--INICIO PREGUNTA
						DELETE FROM @EncuestaPreguntaEAA
						SET @MIN_Pregunta = 0
						SET @MAX_Pregunta = 0    
     
						INSERT INTO @EncuestaPreguntaEAA(IdPregunta,ValorPregunta,PromediablePregunta)
						SELECT IdPregunta,ValorPregunta,PromediablePregunta --@13     
						FROM ( SELECT DISTINCT IdPregunta,ValorPregunta,PromediablePregunta     
						FROM #EncuestaResumen WITH (NOLOCK)     
						WHERE IdProgramacion=@IdProgramacion      
						AND IdSeccion=@IdSeccion
						and IdDocente =@IdDocente  --@23      
						AND IdArea=@IdArea
						--AND IdPregunta=47166
						AND IdSubArea=@IdSubArea) AS Temp  

						--SELECT*FROM @EncuestaPreguntaEAA


						SELECT @MIN_Pregunta = MIN(ID) , @MAX_Pregunta = MAX(ID) FROM @EncuestaPreguntaEAA
						WHILE @MIN_Pregunta <=  @MAX_Pregunta
						BEGIN

							SET @IdPregunta = NULL
							SET @ValorPregunta = NULL
							SET @PromediablePregunta = NULL
  
							SELECT @IdPregunta=IdPregunta,
							@ValorPregunta=ValorPregunta,
							@PromediablePregunta=PromediablePregunta--@13     
							FROM @EncuestaPreguntaEAA
							WHERE Id = @MIN_Pregunta   
      
							SET @PromPregunta = NULL     
							SET @SumPromPregunta = NULL
     
							--INICIO ALTERNATIVA     
							DELETE FROM @AlternativaEAA
							SET @MIN_Alternativa = 0
							SET @MAX_Alternativa = 0    
      
							SET @Valor=0     
							SET @Promediable=1     
							SET @IdTipoPregunta=0     

							INSERT INTO @AlternativaEAA(IdAlternativa,Valor,Promediable,IdTipoPregunta,TotAlumnosPrg,TotAlumnosEncReal)
							SELECT IdAlternativa,Valor,Promediable,IdTipoPregunta,TotAlumnosPrg,TotAlumnosEncReal
							FROM ( SELECT DISTINCT IdAlternativa,'Valor'=ISNULL(Valor,0),'Promediable'=ISNULL(Promediable,1),IdTipoPregunta,
							TotAlumnosPrg,TotAlumnosEncReal
							FROM #EncuestaResumen WITH (NOLOCK)    
							WHERE IdProgramacion=@IdProgramacion      
							AND IdSeccion=@IdSeccion 
							and IdDocente =@IdDocente --@23    
							AND IdArea=@IdArea     
							AND IdSubArea=@IdSubArea      
							AND IdPregunta=@IdPregunta )AS Temp      

							SELECT @MIN_Alternativa = MIN(ID) , @MAX_Alternativa = MAX(ID) FROM @AlternativaEAA
							WHILE @MIN_Alternativa <=   @MAX_Alternativa
							BEGIN

								SELECT @IdAlternativa=IdAlternativa,@Valor=Valor,@Promediable=Promediable,@IdTipoPregunta=IdTipoPregunta,
								@TotAlumnosPrg=TotAlumnosPrg,@TotAlumnosEncReal=TotAlumnosEncReal
								FROM @AlternativaEAA
								WHERE ID = @MIN_Alternativa  

								IF @IdTipoPregunta=1426--ABIERTA   
								BEGIN    
								
									SET @EsAbierta=1     
									--SE CONCATENA LAS RESPUESTAS DE LOS ALUMNOS      
									SET @Concatenar = ''     
									SELECT @Concatenar=@Concatenar+TMP.Respuesta+' / '--@10     
									FROM ( SELECT DISTINCT fa.Respuesta     
									FROM #FichaRespuestaActor fa WITH (NOLOCK)     
									INNER JOIN FichaPregunta fp WITH (NOLOCK) ON fa.IdFicha=fp.IdFicha AND fa.IdPregunta=fp.IdPregunta     
									INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle     
									WHERE fa.IdProgramacion=@IdProgramacion     
									AND fd.IdSeccion=@IdSeccion
									AND IdDocente =@IdDocente     --@23
									AND fp.IdArea=@IdArea     
									AND fp.IdSubArea=@IdSubArea     
									AND fa.IdPregunta=@IdPregunta     
									AND fd.Respondio=1     
									AND ISNULL(fa.Respuesta,'')!='')TMP

									IF LEN(@Concatenar)>0 SET @Concatenar=SUBSTRING(@Concatenar,1,LEN(@Concatenar)-2)     

									UPDATE #EncuestaResumen     
									SET DescAlternativa=@Concatenar     
									WHERE IdProgramacion=@IdProgramacion      
									AND IdSeccion=@IdSeccion     
									AND IdDocente =@IdDocente  --@23
									AND IdArea=@IdArea     
									AND IdSubArea=@IdSubArea      
									AND IdPregunta=@IdPregunta   
									
								END     
								ELSE     
								BEGIN     
     
									Set @EsAbierta = 0; --@14     

									--se asignan variables--@6     
									IF @TotAlumnosEncReal>0      
									BEGIN

										IF @Promediable=1 SET @PtjePregunta = (@Valor * @TotAlumnosPrg) / @TotAlumnosEncReal     
										ELSE SET @PtjePregunta = NULL

									END     
									ELSE SET @PtjePregunta = NULL     
     
									IF @PtjePregunta IS NOT NULL     
									SET @SumPromPregunta = ISNULL(@SumPromPregunta,0) + @PtjePregunta     
     
									--se actualiza el total de alumnos y el puntaje por pregunta     
									UPDATE #EncuestaResumen      
									SET PtjePregunta=@PtjePregunta     
									WHERE IdProgramacion=@IdProgramacion     
									AND IdSeccion=@IdSeccion
									AND IdDocente =@IdDocente  --@23    
									AND IdArea=@IdArea     
									AND IdSubArea=@IdSubArea     
									AND IdPregunta=@IdPregunta     
									AND IdAlternativa=@IdAlternativa

								END     
     
								SET @MIN_Alternativa = @MIN_Alternativa + 1

							END
  
							IF @EsAbierta = 0 AND @Promediable  = 1 --@13     
							BEGIN

								--FIN ALTERNATIVA     
								--se asignan variables     
								SET @PromPregunta = @SumPromPregunta    
     
								IF @PromPregunta IS NOT NULL      
								BEGIN
								
									SET @SumPromSubArea = ISNULL(@SumPromSubArea,0) + @PromPregunta     
									SET @CtaPromSubArea = ISNULL(@CtaPromSubArea,0) + 1     
     
									SET @SumPromArea = ISNULL(@SumPromArea,0) + @SumPromPregunta     
									SET @CtaPromArea = ISNULL(@CtaPromArea,0) + 1     
    
									--SET @SumPromEncuesta = ISNULL(@SumPromEncuesta,0) + @SumPromPregunta     
									SET @SumPromEncuesta = (ISNULL(@SumPromPregunta,0) * (@ValorPregunta/100)) + ISNULL(@SumPromEncuesta,0)     
									SET @CtaPromEncuesta = ISNULL(@CtaPromEncuesta,0) + 1     
     
									SET @SumPromGeneral = ISNULL(@SumPromGeneral,0) + @SumPromPregunta     
									SET @CtaPromGeneral = @CtaPromGeneral + 1     
    
									--SELECT 'B1','@IdSeccion'=@IdSeccion,'@IdArea'=@IdArea,'@IdSubArea'=@IdSubArea,'@IdPregunta'=@IdPregunta,'@SumPromPregunta'=@SumPromPregunta,'@PromPregunta'=@PromPregunta,'@PromediablePregunta'=@PromediablePregunta,'@SumPromEncuesta'=@SumPromEncuesta,'@CtaPromEncuesta'=@CtaPromEncuesta     

								END
								
							END     
       
							IF @CodigoArea not like 'NPS%'  --@30      
							BEGIN

								--se actualiza el promedio de las preguntas del subarea     
								UPDATE #EncuestaResumen      
								SET PromPregunta=@PromPregunta--,     
								WHERE IdProgramacion=@IdProgramacion     
								AND IdSeccion=@IdSeccion  
								AND IdDocente =@IdDocente  --@23  
								AND IdArea=@IdArea     
								AND IdSubArea=@IdSubArea     
								AND IdPregunta=@IdPregunta

							END

							SET @MIN_Pregunta = @MIN_Pregunta + 1      

						END      
						--FIN PREGUNTA     
     
						--se asignan variables     
						IF @SumPromSubArea IS NOT NULL AND @CtaPromSubArea IS NOT NULL     
						SET @PromSubArea = @SumPromSubArea / @CtaPromSubArea  
     
						--select 'B2','@IdArea'=@IdArea,'@@IdSubArea'=@IdSubArea,'@@IdPregunta'=@IdPregunta, '@@SumPromSubArea'=@SumPromSubArea,'@@CtaPromSubArea'=@CtaPromSubArea,'@PromSubArea'=@PromSubArea      
      
						IF @CodigoArea not like 'NPS%'  --@30      
						BEGIN

							--se actualiza el promedio del subarea     
							UPDATE #EncuestaResumen      
							SET PromSubArea=@PromSubArea     
							WHERE IdProgramacion=@IdProgramacion     
							AND IdSeccion=@IdSeccion     
							AND IdDocente =@IdDocente  --@23
							AND IdArea=@IdArea     
							AND IdSubArea=@IdSubArea

						END

						SET @MIN_SubArea = @MIN_SubArea + 1
  
					END
					--FIN SUBAREA     
     
					--se asignan variables   
					IF @SumPromArea IS NOT NULL AND @CtaPromArea IS NOT NULL     
					SET @PromArea = @SumPromArea / @CtaPromArea     
     
					--select 'B3','@IdArea'=@IdArea,'@@IdSubArea'=@IdSubArea,'@@IdPregunta'=@IdPregunta, '@SumPromArea'=@SumPromArea,'@CtaPromArea'=@CtaPromArea,'@PromArea'=@PromArea      
					--IF (SELECT Nombre FROM MaestroTablaRegistro WITH(NOLOCK) WHERE IdMaestroRegistro=@IdArea)='NPS' -- Inicio @20   
					IF @CodigoArea like 'NPS%'  --@30      
					BEGIN
     
						IF @TotalAlumnoNPS910>0     
						BEGIN

							IF @TotalAlumnoNPS06>0   
							BEGIN
						
								SET @PromArea= (@TotalAlumnoNPS910*100/@TotAlumnosEncReal)-(@TotalAlumnoNPS06*100/@TotAlumnosEncReal)

							END   
							ELSE   
							BEGIN
								SET @PromArea= (@TotalAlumnoNPS910*100/@TotAlumnosEncReal)

							END

						END   
						ELSE   
						BEGIN

							IF @TotalAlumnoNPS06>0   
							BEGIN  
						
								SET @PromArea= 0-(@TotalAlumnoNPS06*100/@TotAlumnosEncReal)   

							END   
							ELSE   
							BEGIN   

								SET @PromArea= 0   

							END

						END   

						UPDATE #EncuestaResumen      --@21 
						SET PromPregunta=@PromArea     
						WHERE IdProgramacion=@IdProgramacion     
						AND IdSeccion=@IdSeccion  
						AND IdDocente =@IdDocente   --@23 
						AND IdArea=@IdArea   
 
						UPDATE #EncuestaResumen      --@21 
						SET PromSubArea=@PromArea     
						WHERE IdProgramacion=@IdProgramacion     
						AND IdSeccion=@IdSeccion  
						AND IdDocente =@IdDocente  --@23  
						AND IdArea=@IdArea

					END  -- Fin @20
     
					--se actualiza el promedio del area     
					UPDATE #EncuestaResumen      
					SET PromArea=@PromArea     
					WHERE IdProgramacion=@IdProgramacion     
					AND IdSeccion=@IdSeccion   
					AND IdDocente =@IdDocente  --@23 
					AND IdArea=@IdArea     
      
					SET @MIN_Area = @MIN_Area + 1

				END       
				--FIN AREA    
     
				--se asignan variables     
				--@13     
				IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL     
				SET @PromEncuesta = @SumPromEncuesta     
				--IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL     
				-- SET @PromEncuesta = @SumPromEncuesta / @CtaPromEncuesta     
				--@13

				---INICIO @31  
				--se actualiza el promedio de la encuesta     
				--UPDATE #EncuestaResumen      
				--SET PromEncuesta=@PromEncuesta     
				--WHERE IdProgramacion=@IdProgramacion     
				--AND IdSeccion=@IdSeccion     
				--AND IdDocente =@IdDocente 
  
				--se actualiza el promedio de la encuesta     

				--Inicio --@33
				/*
				SELECT @IdPreguntaNPS = IdMaestroRegistro FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'EV_EA25_1'
				IF @IdPregunta = @IdPreguntaNPS
				*/
				--Fin --@33
				--SELECT *fROM @TempPreguntasNPS
				--SELECT @IdPregunta,'IdPregunta'
				--Inicio --@33
				--IF EXISTS
				--(
				--	SELECT
				--		1
				--	FROM @TempPreguntasNPS
				--	WHERE IdPregunta = @IdPregunta
				--)
				----Fin --@33
				--BEGIN 

					--SE PONE EL /2 PARA OBTENER UN VALOR NEGATIVO PORQUE NO SE PERMITE PONER -1
					--SET @PromEncuestaNPS = @PromEncuesta / 2

					--UPDATE #EncuestaResumen SET
					--	PromEncuesta = @PromEncuestaNPS 
					--	--PromPregunta = CAST(ROUND(@PromEncuestaNPS * 100, 0) AS INT)
					--WHERE IdProgramacion = @IdProgramacion   
					--AND IdSeccion = @IdSeccion   
					--AND IdDocente = @IdDocente
					UPDATE #EncuestaResumen SET
					PromEncuesta = @PromEncuesta  
					WHERE IdProgramacion=@IdProgramacion   
					AND IdSeccion = @IdSeccion   
					AND IdDocente = @IdDocente

				--END  
				--ELSE  
				--BEGIN

				--	UPDATE #EncuestaResumen SET
				--		PromEncuesta = @PromEncuesta  
				--	WHERE IdProgramacion=@IdProgramacion   
				--	AND IdSeccion = @IdSeccion   
				--	AND IdDocente = @IdDocente

				--END    
				--FIN @31  
 
			END

			SET  @MIN = @MIN + 1
	
		END

		--DROP TABLE #EncuestaDetalleEAA
		
	END

	--SI ES UNA ENCUESTA DE SERVICIOS DE ALUMNO EL RESUMEN ES POR PROMOCION, AREA, SUBAREA, PREGUNTA Y ALTERNATIVA     
	IF @Disponible1='ESA'--ENCUESTA SERVICIOS DE ALUMNO     
	BEGIN

		--Turno     
		UPDATE t     
		SET t.IdCurso=TU.IdTurno,T.CodigoCurso=MTR.Codigo,T.NombreCurso=MTR.Nombre     
		FROM #EncuestaResumen t WITH (NOLOCK)     
		INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON T.IdPromocion=PG.IdPromocion AND T.IdGrupo=PG.IdGrupo     
		INNER JOIN Turno TU WITH (NOLOCK) ON PG.IdTurno=TU.IdTurno     
		INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON TU.IdTipoTurno=MTR.IdMaestroRegistro     
     
		--total de alumno matriculados 
		UPDATE t     
		SET t.TotAlumnosMat=( SELECT COUNT(DISTINCT FD.IdActor)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3       
		AND FD.IdEmpresa=T.IdEmpresa 
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad
		AND FD.IdUnidadNegocio=T.IdUnidadNegocio       
		AND FD.IdUnidadAcademica=T.IdUnidadAcademica       
		AND FD.IdPeriodo=T.IdPeriodo       
		AND FD.IdProducto=T.IdProducto       
		AND FD.IdPromocion=T.IdPromocion       
		AND FD.IdGrupo=T.IdGrupo      
		) FROM #EncuestaResumen t   WITH (NOLOCK)
		--@232   
       
		--total de alumnos encuestados
		UPDATE t     
		SET t.TotAlumnosEnc=( SELECT COUNT(DISTINCT FD.IdActor)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3
		AND FD.IdEmpresa=T.IdEmpresa 
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad
		AND FD.IdUnidadNegocio=T.IdUnidadNegocio       
		AND FD.IdUnidadAcademica=T.IdUnidadAcademica       
		AND FD.IdPeriodo=T.IdPeriodo       
		AND FD.IdProducto=T.IdProducto       
		AND FD.IdPromocion=T.IdPromocion       
		AND FD.IdGrupo=T.IdGrupo       
		AND FD.Respondio=1 
		) FROM #EncuestaResumen t WITH (NOLOCK)
       
		--total de alumnos por pregunta
		UPDATE T
		SET t.TotAlumnosPrg=( SELECT COUNT(DISTINCT FRA.IdActor)      
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle FD  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle
		WHERE FRA.IdProgramacion=T.IdProgramacion    
		AND FD.IdPromocion=T.IdPromocion
		AND FD.IdGrupo=T.IdGrupo
		AND FRA.IdPregunta=T.IdPregunta     
		AND FRA.IdAlternativa=T.IdAlternativa     
		AND FD.Respondio=1     
		) FROM #EncuestaResumen T WITH (NOLOCK)     
       
		--total de alumnos encuestados real
		UPDATE T
		SET T.TotAlumnosEncReal=(SELECT COUNT(DISTINCT FRA.IdActor)     
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)       
		INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle
		INNER JOIN PreguntaAlternativa pa WITH (NOLOCK) ON FRA.IdFicha=PA.IdFicha AND FRA.IdPregunta=PA.IdPregunta AND FRA.IdAlternativa=PA.IdAlternativa
		WHERE FRA.IdProgramacion=T.IdProgramacion   
		AND FD.IdPromocion=T.IdPromocion
		AND FD.IdGrupo=T.IdGrupo   
		AND FRA.IdPregunta=T.IdPregunta
		AND FD.Respondio=1
		AND ISNULL(PA.Promediable,1)=1
		) FROM #EncuestaResumen T WITH (NOLOCK) 

		INSERT #EncuestaDetalleESA(IdPromocion,IdGrupo,TotAlumnosEnc)
		SELECT DISTINCT IdPromocion,IdGrupo,TotAlumnosEnc      
		FROM #EncuestaResumen

		SET @MIN = 0
		SET @MAX = 0
 
		SELECT @MIN = MIN(ID), @MAX = MAX(id) FROM #EncuestaDetalleESA WITH (NOLOCK)
		--INICIO DETALLE
		WHILE  @MIN <= @MAX       
		BEGIN     

			SELECT @IdPromocion=IdPromocion,@IdGrupo=IdGrupo,@TotAlumnosEnc=TotAlumnosEnc      
			FROM #EncuestaDetalleESA WITH (NOLOCK)
			WHERE ID = @MIN
      
			IF @TotAlumnosEnc >0      
			BEGIN      
			SET @PromEncuesta = NULL     
			SET @SumPromEncuesta = NULL     
			SET @CtaPromEncuesta = NULL      
   
			--INICIO AREA
			DELETE FROM @EncuestaAreaESA
			SET @MIN_Area = 0
			SET @MAX_Area = 0
  
			INSERT INTO @EncuestaAreaESA(IdArea)
			SELECT DISTINCT IdArea      
			FROM #EncuestaResumen WITH (NOLOCK)     
			WHERE IdProgramacion=@IdProgramacion      
			AND IdPromocion=@IdPromocion     
			AND IdGrupo=@IdGrupo
   
			SELECT @MIN_Area=MIN(ID), @MAX_Area=MAX(ID) FROM @EncuestaAreaESA  
			WHILE @MIN_Area <= @MAX_Area
			BEGIN 
      
				SELECT @IdArea=IdArea      
				FROM @EncuestaAreaESA
				WHERE ID = @MIN_Area      
 
				SET @PromArea = NULL     
				SET @SumPromArea = NULL     
				SET @CtaPromArea = NULL
 
				DELETE FROM @EncuestaSubAreaESA
				SET @MIN_SubArea = 0
				SET @MAX_SubArea = 0    
    
				--INICIO SUB AREA   
				INSERT INTO @EncuestaSubAreaESA(IdSubArea)
				SELECT DISTINCT 'IdSubArea'=ISNULL(IdSubArea,0)     
				FROM #EncuestaResumen WITH (NOLOCK)     
				WHERE IdProgramacion=@IdProgramacion      
				AND IdPromocion=@IdPromocion
				AND IdGrupo=@IdGrupo
				AND IdArea=@IdArea

				SELECT @MAX_SubArea = MAX(ID), @MIN_Area = MIN(ID) FROM @EncuestaSubAreaESA
				WHILE  @MIN_SubArea <= @MAX_SubArea     
				BEGIN

					SELECT @IdSubArea=IdSubArea      
					FROM @EncuestaSubAreaESA
					WHERE ID = @MIN_SubArea      
     
					SET @PromSubArea = NULL     
					SET @SumPromSubArea = NULL     
					SET @CtaPromSubArea = NULL     
					SET @EsAbierta = 0

					--INICIO PREGUNTA
					DELETE FROM @EncuestaPreguntaESA
					SET @MIN_Pregunta = 0
					SET @MAX_Pregunta = 0
      
					INSERT INTO @EncuestaPreguntaESA(IdPregunta)
					SELECT DISTINCT IdPregunta      
					FROM #EncuestaResumen WITH (NOLOCK)     
					WHERE IdProgramacion=@IdProgramacion      
					AND IdPromocion=@IdPromocion
					AND IdGrupo=@IdGrupo
					AND IdArea=@IdArea     
					AND ISNULL(IdSubArea,0)=@IdSubArea
   
					SELECT @MIN_Pregunta = MIN(ID), @MAX_Pregunta = MAX(ID) FROM  @EncuestaPreguntaESA
					WHILE @MIN_Pregunta <= @MAX_Pregunta       
					BEGIN

						SELECT @IdPregunta=IdPregunta      
						FROM @EncuestaPreguntaESA
						WHERE ID = @MIN_Pregunta

						SET @PromPregunta = NULL     
						SET @SumPromPregunta = NULL

						--INICIO ALTERNATIVA
						DELETE FROM @AlternativaESA
						SET @MIN_Alternativa = 0
						SET @MAX_Alternativa = 0

						SET @Valor=0     
						SET @Promediable=1     
						SET @IdTipoPregunta=0

						INSERT INTO @AlternativaESA(IdAlternativa,Valor,Promediable,IdTipoPregunta,TotAlumnosPrg,TotAlumnosEncReal)
						SELECT DISTINCT IdAlternativa,'Valor'=ISNULL(Valor,0),'Promediable'=ISNULL(Promediable,1),IdTipoPregunta
						,TotAlumnosPrg,TotAlumnosEncReal      
						FROM #EncuestaResumen WITH (NOLOCK)    
						WHERE IdProgramacion=@IdProgramacion      
						AND IdPromocion=@IdPromocion      
						AND IdGrupo=@IdGrupo     
						AND IdArea=@IdArea     
						AND ISNULL(IdSubArea,0)=@IdSubArea      
						AND IdPregunta=@IdPregunta

						SELECT @MIN_Alternativa = MIN(ID), @MAX_Alternativa = MAX(ID) FROM  @AlternativaESA
						WHILE @MIN_Alternativa <= @MAX_Alternativa       
						BEGIN
   
							SELECT @IdAlternativa=IdAlternativa,@Valor=Valor,@Promediable=Promediable,@IdTipoPregunta=IdTipoPregunta,
							@TotAlumnosPrg=TotAlumnosPrg,@TotAlumnosEncReal=TotAlumnosEncReal
							FROM @AlternativaESA
							WHERE ID = @MIN_Alternativa  
   
							IF @IdTipoPregunta=1426--ABIERTA   
							BEGIN

								SET @EsAbierta=1     

								--SE CONCATENA LAS RESPUESTAS DE LOS ALUMNOS      
								SET @Concatenar = ''     
								SELECT @Concatenar=@Concatenar+TMP.Respuesta+' / '--@10     
								FROM ( SELECT DISTINCT fa.Respuesta     
								FROM #FichaRespuestaActor fa WITH (NOLOCK)     
								INNER JOIN FichaPregunta fp WITH (NOLOCK) ON fa.IdFicha=fp.IdFicha AND fa.IdPregunta=fp.IdPregunta     
								INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle     
								WHERE fa.IdProgramacion=@IdProgramacion     
								AND fd.IdPromocion=@IdPromocion     
								AND fd.IdGrupo=@IdGrupo     
								AND fp.IdArea=@IdArea     
								AND ISNULL(fp.IdSubArea,0)=@IdSubArea     
								AND fa.IdPregunta=@IdPregunta     
								AND fd.Respondio=1     
								AND ISNULL(fa.Respuesta,'')!='')TMP     

								IF LEN(@Concatenar)>0 SET @Concatenar=SUBSTRING(@Concatenar,1,LEN(@Concatenar)-2)     

								UPDATE #EncuestaResumen     
								SET DescAlternativa=@Concatenar     
								WHERE IdProgramacion=@IdProgramacion      
								AND IdPromocion=@IdPromocion      
								AND IdGrupo=@IdGrupo     
								AND IdArea=@IdArea     
								AND ISNULL(IdSubArea,0)=@IdSubArea      
								AND IdPregunta=@IdPregunta

							END     
							ELSE     
							BEGIN

								SET @EsAbierta = 0; --@14     
  
								--se asignan variables--@6     
								IF @TotAlumnosEncReal>0      
								BEGIN

									IF @Promediable=1 SET @PtjePregunta = (@Valor * @TotAlumnosPrg) / @TotAlumnosEncReal     
									ELSE SET @PtjePregunta = NULL

								END     
								ELSE SET @PtjePregunta = NULL     
     
								IF @PtjePregunta IS NOT NULL     
								SET @SumPromPregunta = ISNULL(@SumPromPregunta,0) + @PtjePregunta     
   
								--se actualiza el total de alumnos y el puntaje por pregunta     
								UPDATE #EncuestaResumen      
								SET TotAlumnosPrg=@TotAlumnosPrg, PtjePregunta=@PtjePregunta     
								WHERE IdProgramacion=@IdProgramacion     
								AND IdPromocion=@IdPromocion     
								AND IdGrupo=@IdGrupo     
								AND IdArea=@IdArea     
								AND ISNULL(IdSubArea,0)=@IdSubArea     
								AND IdPregunta=@IdPregunta     
								AND IdAlternativa=@IdAlternativa

							END     
 
							SET @MIN_Alternativa = @MIN_Alternativa + 1

						END
  
						IF @EsAbierta = 0     
						BEGIN

							--FIN ALTERNATIVA     
							--se asignan variables     
							SET @PromPregunta = @SumPromPregunta     
							IF @PromPregunta IS NOT NULL      
							BEGIN

								SET @SumPromSubArea = ISNULL(@SumPromSubArea,0) + @PromPregunta     
								SET @CtaPromSubArea = ISNULL(@CtaPromSubArea,0) + 1       
 
								SET @SumPromArea = ISNULL(@SumPromArea,0) + @SumPromPregunta     
								SET @CtaPromArea = ISNULL(@CtaPromArea,0) + 1
       
								SET @SumPromEncuesta = ISNULL(@SumPromEncuesta,0) + @SumPromPregunta     
								SET @CtaPromEncuesta = ISNULL(@CtaPromEncuesta,0) + 1       
 
								SET @SumPromGeneral = ISNULL(@SumPromGeneral,0) + @SumPromPregunta     
								SET @CtaPromGeneral = @CtaPromGeneral + 1

							END

						END     
     
						--se actualiza el promedio de las preguntas del subarea     
						UPDATE #EncuestaResumen      
						SET PromPregunta=@PromPregunta--,     
						WHERE IdProgramacion=@IdProgramacion     
						AND IdPromocion=@IdPromocion     
						AND IdGrupo=@IdGrupo     
						AND IdArea=@IdArea    
						AND ISNULL(IdSubArea,0)=@IdSubArea    
						AND IdPregunta=@IdPregunta     
    
						SET @MIN_Pregunta = @MIN_Pregunta + 1

					END      
					--FIN PREGUNTA     

					--select @IdArea,@IdSubArea,@IdPregunta, @SumPromSubArea,@CtaPromSubArea      
					--se asignan variables     
					IF @SumPromSubArea IS NOT NULL AND @CtaPromSubArea IS NOT NULL     
					SET @PromSubArea = @SumPromSubArea / @CtaPromSubArea  
     
					--se actualiza el promedio del subarea     
					UPDATE #EncuestaResumen      
					SET PromSubArea=@PromSubArea     
					WHERE IdProgramacion=@IdProgramacion     
					AND IdPromocion=@IdPromocion     
					AND IdGrupo=@IdGrupo     
					AND IdArea=@IdArea     
					AND ISNULL(IdSubArea,0)=@IdSubArea

					SET @MIN_SubArea = @MIN_SubArea + 1    
   
				END      
				--FIN SUBAREA     
     
				--se asignan variables   
				IF @SumPromArea IS NOT NULL AND @CtaPromArea IS NOT NULL     
				SET @PromArea = @SumPromArea / @CtaPromArea     
     
				--se actualiza el promedio del area     
				UPDATE #EncuestaResumen      
				SET PromArea=@PromArea     
				WHERE IdProgramacion=@IdProgramacion     
				AND IdPromocion=@IdPromocion     
				AND IdGrupo=@IdGrupo     
				AND IdArea=@IdArea     

     
				SET @MIN_Area = @MIN_Area + 1
    
			END       
			--FIN AREA    

			--se asignan variables     
			IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL     
			SET @PromEncuesta = @SumPromEncuesta / @CtaPromEncuesta     
     
			--se actualiza el promedio de la encuesta     
			UPDATE #EncuestaResumen      
			SET PromEncuesta=@PromEncuesta     
			WHERE IdProgramacion=@IdProgramacion     
			AND IdPromocion=@IdPromocion     
			AND IdGrupo=@IdGrupo      
			END
  
			SET @MIN = @MIN + 1
     
		END       
     
		DROP TABLE #EncuestaDetalleESA   

	END
     
	--SI ES UNA ENCUESTA 360 EL RESUMEN ES POR EVALUADO (FACILITADOR),AREA, SUBAREA, PREGUNTA Y ALTERNATIVA     
	IF @Disponible1='360'--ENCUESTA 360     
	BEGIN

		--Docente     
		UPDATE t     
		SET t.NombreDocente = a.NombreCompleto,t.CodigoDocente=U.Login     
		FROM #EncuestaResumen t WITH (NOLOCK)      
		INNER JOIN Actor A WITH (NOLOCK) on (t.IdDocente=a.IdActor)     
		LEFT JOIN Usuario U WITH (NOLOCK) on (t.IdDocente=U.IdActor AND U.IdTipoUsuario=3)
     
		--total de alumno matriculados      
		UPDATE t     
		SET t.TotAlumnosMat=( SELECT COUNT(DISTINCT IdActor)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3
		AND FD.IdEmpresa=T.IdEmpresa 
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad       
		AND FD.IdDocente=T.IdDocente     
		) FROM #EncuestaResumen t WITH (NOLOCK)      
       
		--total de alumnos encuestados
		UPDATE t     
		SET t.TotAlumnosEnc=( SELECT COUNT(DISTINCT IdActor)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3
		AND FD.IdEmpresa=T.IdEmpresa 
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad      
		AND FD.IdDocente=T.IdDocente       
		AND FD.Respondio=1 
		) FROM #EncuestaResumen t WITH (NOLOCK)   
 
		--total de alumnos por pregunta
		UPDATE T
		SET t.TotAlumnosPrg=( SELECT COUNT(DISTINCT FRA.IdActor)      
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle FD  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle
		WHERE FRA.IdProgramacion=T.IdProgramacion     
		AND FD.IdDocente =T.IdDocente 
		AND FRA.IdPregunta=T.IdPregunta     
		AND FRA.IdAlternativa=T.IdAlternativa     
		AND FD.Respondio=1     
		) FROM #EncuestaResumen T WITH (NOLOCK)
 
		--total de alumnos encuestados real
		UPDATE T
		SET T.TotAlumnosEncReal=(SELECT COUNT(DISTINCT FRA.IdActor)     
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle     
		INNER JOIN PreguntaAlternativa pa WITH (NOLOCK) ON FRA.IdFicha=pa.IdFicha AND FRA.IdPregunta=PA.IdPregunta AND FRA.IdAlternativa=PA.IdAlternativa     
		WHERE FRA.IdProgramacion=T.IdProgramacion  
		and FD.IdDocente =T.IdDocente  --@23   
		AND FRA.IdPregunta=T.IdPregunta
		AND FD.Respondio=1
		AND ISNULL(PA.Promediable,1)=1
		) FROM #EncuestaResumen T WITH (NOLOCK)     

		INSERT INTO #EncuestaDetalle360
		(IdDocente,TotAlumnosEnc)
		SELECT DISTINCT IdDocente,TotAlumnosEnc      
		FROM #EncuestaResumen WITH (NOLOCK)

		SET @MIN = 0
		SET @MAX = 0
		SELECT @MIN = MIN(ID), @MAX = MAX(ID) FROM #EncuestaDetalle360 WITH (NOLOCK)

		--INICIO DETALLE     
		WHILE @MIN <= @MAX
		BEGIN

			SELECT @IdDocente=IdDocente,@TotAlumnosEnc=TotAlumnosEnc      
			FROM #EncuestaDetalle360 WITH (NOLOCK)    
			WHERE ID = @MIN
    
			IF @TotAlumnosEnc >0      
			BEGIN

			SET @PromEncuesta = NULL     
			SET @SumPromEncuesta = NULL     
			SET @CtaPromEncuesta = NULL  
   
			DELETE FROM @EncuestaArea360
			SET @MIN_Area = 0
			SET @MAX_Area = 0  
    
			INSERT INTO @EncuestaArea360(IdArea)    
			SELECT DISTINCT IdArea      
			FROM #EncuestaResumen WITH (NOLOCK)    
			WHERE IdProgramacion=@IdProgramacion      
			AND IdDocente=@IdDocente
   
			SELECT @MIN_Area = MIN(ID), @MAX_Area = MAX(ID) FROM @EncuestaArea360
			WHILE  @MIN_Area <= @MAX_Area   
			BEGIN

				SET @IdArea = NULL    
      
				SELECT @IdArea=IdArea FROM @EncuestaArea360   
				WHERE ID = @MIN  
   
				SET @PromArea = NULL     
				SET @SumPromArea = NULL     
				SET @CtaPromArea = NULL     
    
				--INICIO SUB AREA     
				DELETE FROM @EncuestaSubArea360
				SET @MIN_SubArea = 0
				SET @MAX_SubArea = 0   

				INSERT INTO @EncuestaSubArea360(IdSubArea)
				SELECT DISTINCT 'IdSubArea'=ISNULL(IdSubArea,0)     
				FROM #EncuestaResumen WITH (NOLOCK)    
				WHERE IdProgramacion=@IdProgramacion      
				AND IdDocente=@IdDocente     
				AND IdArea=@IdArea   
 
				SELECT @MIN_SubArea = MIN(ID), @MAX_SubArea = MAX(ID) FROM @EncuestaSubArea360

				WHILE @MIN_SubArea <= @MAX_SubArea  
				BEGIN

					SELECT @IdSubArea=IdSubArea      
					FROM @EncuestaSubArea360      
					WHERE ID = @MIN_SubArea 
     
					SET @PromSubArea = NULL     
					SET @SumPromSubArea = NULL     
					SET @CtaPromSubArea = NULL     
					SET @EsAbierta = 0     

					--INICIO PREGUNTA
					DELETE FROM @EncuestaPregunta360
					SET @MIN_Pregunta = 0
					SET @MAX_Pregunta = 0 
     
					INSERT INTO @EncuestaPregunta360(IdPregunta,ValorPregunta,PromediablePregunta )    
					SELECT DISTINCT IdPregunta,ValorPregunta,PromediablePregunta      
					FROM #EncuestaResumen WITH (NOLOCK)    
					WHERE IdProgramacion=@IdProgramacion      
					AND IdDocente=@IdDocente     
					AND IdArea=@IdArea     
					AND ISNULL(IdSubArea,0)=@IdSubArea
 
					SELECT @MIN_Pregunta = MIN(ID), @MAX_Pregunta = MAX(ID) FROM @EncuestaPregunta360
					WHILE @MIN_Pregunta <= @MAX_Pregunta
					BEGIN
    
						SELECT @IdPregunta=IdPregunta,
						@ValorPregunta=ValorPregunta,
						@PromediablePregunta=PromediablePregunta--@13     
						FROM @EncuestaPregunta360
						WHERE ID = @MIN_Pregunta

						SET @PromPregunta = NULL     
						SET @SumPromPregunta = NULL     
     
						--INICIO ALTERNATIVA
						DELETE FROM @Alternativa360
						SET @MIN_Alternativa = 0
						SET @MAX_Alternativa = 0 
 
						SET @Valor=0     
						SET @Promediable=1     
						SET @IdTipoPregunta=0     

						INSERT INTO @Alternativa360(IdAlternativa,Valor,Promediable,IdTipoPregunta,TotAlumnosPrg,TotAlumnosEncReal)
						SELECT DISTINCT IdAlternativa,'Valor'=ISNULL(Valor,0),'Promediable'=ISNULL(Promediable,1),IdTipoPregunta,
						TotAlumnosPrg,TotAlumnosEncReal
						FROM #EncuestaResumen WITH (NOLOCK)     
						WHERE IdProgramacion=@IdProgramacion      
						AND IdDocente=@IdDocente     
						AND IdArea=@IdArea 
						AND ISNULL(IdSubArea,0)=@IdSubArea      
						AND IdPregunta=@IdPregunta
  
						SELECT @MIN_Alternativa = MIN(ID), @MAX_Alternativa = MAX(ID) FROM @Alternativa360
						WHILE @MIN_Alternativa <= @MAX_Alternativa      
						BEGIN
   
							SELECT @IdAlternativa=IdAlternativa,@Valor=Valor,@Promediable=Promediable,@IdTipoPregunta=IdTipoPregunta,
							@TotAlumnosPrg=TotAlumnosPrg,@TotAlumnosEncReal=TotAlumnosEncReal
							FROM @Alternativa360   
							WHERE ID = @MIN_Alternativa 
   
							IF @IdTipoPregunta=1426--ABIERTA   
							BEGIN

								SET @EsAbierta=1     
								--SE CONCATENA LAS RESPUESTAS DE LOS ALUMNOS      
								SET @Concatenar = ''
       
								SELECT @Concatenar=@Concatenar+TMP.Respuesta+' / '--@10     
								FROM ( SELECT DISTINCT fa.Respuesta     
								FROM #FichaRespuestaActor fa WITH (NOLOCK)     
								INNER JOIN FichaPregunta fp WITH (NOLOCK) ON fa.IdFicha =fp.IdFicha AND fa.IdPregunta=fp.IdPregunta     
								INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle     
								WHERE fa.IdProgramacion=@IdProgramacion     
								AND fd.IdDocente=@IdDocente     
								AND fp.IdArea=@IdArea     
								AND ISNULL(fp.IdSubArea,0)=@IdSubArea     
								AND fa.IdPregunta=@IdPregunta     
								AND fd.Respondio=1     
								AND ISNULL(fa.Respuesta,'')!='')TMP  
     
								IF LEN(@Concatenar)>0 SET @Concatenar=SUBSTRING(@Concatenar,1,LEN(@Concatenar)-2)

								UPDATE #EncuestaResumen     
								SET DescAlternativa=@Concatenar     
								WHERE IdProgramacion=@IdProgramacion      
								AND IdDocente=@IdDocente     
								AND IdArea=@IdArea     
								AND ISNULL(IdSubArea,0)=@IdSubArea      
								AND IdPregunta=@IdPregunta

							END     
							ELSE     
							BEGIN

								SET @EsAbierta = 0; --@14
       
								--se asignan variables--@6     
								IF @TotAlumnosEncReal>0      
								BEGIN

									IF @Promediable=1 SET @PtjePregunta = (@Valor * @TotAlumnosPrg) / @TotAlumnosEncReal     
									ELSE SET @PtjePregunta = NULL

								END     
								ELSE SET @PtjePregunta = NULL     
     
								IF @PtjePregunta IS NOT NULL     
								SET @SumPromPregunta = ISNULL(@SumPromPregunta,0) + @PtjePregunta     
   
								--se actualiza el total de alumnos y el puntaje por pregunta     
								UPDATE #EncuestaResumen      
								SET TotAlumnosPrg=@TotAlumnosPrg, PtjePregunta=@PtjePregunta     
								WHERE IdProgramacion=@IdProgramacion     
								AND IdDocente=@IdDocente     
								AND IdArea=@IdArea     
								AND ISNULL(IdSubArea,0)=@IdSubArea     
								AND IdPregunta=@IdPregunta     
								AND IdAlternativa=@IdAlternativa

							END     
       
							SET @MIN_Alternativa = @MIN_Alternativa + 1

						END
  
						IF @EsAbierta = 0     
						BEGIN

							--FIN ALTERNATIVA     
							--se asignan variables     
							SET @PromPregunta = @SumPromPregunta     
							IF @PromPregunta IS NOT NULL      
							BEGIN

								SET @SumPromSubArea = ISNULL(@SumPromSubArea,0) + @PromPregunta     
								SET @CtaPromSubArea = ISNULL(@CtaPromSubArea,0) + 1       
 
								SET @SumPromArea = ISNULL(@SumPromArea,0) + @SumPromPregunta     
								SET @CtaPromArea = ISNULL(@CtaPromArea,0) + 1
     
      
								IF @PromediablePregunta = 1 --@13     
								BEGIN

									SET @SumPromEncuesta = (ISNULL(@SumPromPregunta,0) * (@ValorPregunta/100)) + ISNULL(@SumPromEncuesta,0)

								END
								ELSE     
								BEGIN

									SET @SumPromEncuesta = ISNULL(@SumPromEncuesta,0) + @SumPromPregunta

								END     
     
								SET @CtaPromEncuesta = ISNULL(@CtaPromEncuesta,0) + 1
								SET @SumPromGeneral = ISNULL(@SumPromGeneral,0) + @SumPromPregunta     
								SET @CtaPromGeneral = @CtaPromGeneral + 1

							END

						END     
     
						--se actualiza el promedio de las preguntas del subarea     
						UPDATE #EncuestaResumen      
						SET PromPregunta=@PromPregunta--,     
						WHERE IdProgramacion=@IdProgramacion     
						AND IdDocente=@IdDocente     
						AND IdArea=@IdArea    
						AND ISNULL(IdSubArea,0)=@IdSubArea    
						AND IdPregunta=@IdPregunta 
   
						SET @MIN_Pregunta = @MIN_Pregunta + 1

					END      
					--FIN PREGUNTA     
     
					--se asignan variables     
					IF @SumPromSubArea IS NOT NULL AND @CtaPromSubArea IS NOT NULL     
					SET @PromSubArea = @SumPromSubArea / @CtaPromSubArea  
     
					--se actualiza el promedio del subarea     
					UPDATE #EncuestaResumen      
					SET PromSubArea=@PromSubArea     
					WHERE IdProgramacion=@IdProgramacion     
					AND IdDocente=@IdDocente     
					AND IdArea=@IdArea     
					AND ISNULL(IdSubArea,0)=@IdSubArea     
       
 
					SET @MIN_SubArea = @MIN_SubArea + 1
      
				END      
				--FIN SUBAREA     
     
				--se asignan variables   
				IF @SumPromArea IS NOT NULL AND @CtaPromArea IS NOT NULL     
				SET @PromArea = @SumPromArea / @CtaPromArea     
     
				--se actualiza el promedio del area     
				UPDATE #EncuestaResumen      
				SET PromArea=@PromArea     
				WHERE IdProgramacion=@IdProgramacion     
				AND IdDocente=@IdDocente     
				AND IdArea=@IdArea     
   
				SET @MIN_Area = @MIN_Area + 1

			END       
			--FIN AREA    

			--se asignan variables     
			--@13     
			IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL     
			SET @PromEncuesta = @SumPromEncuesta     
			--IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL     
			-- SET @PromEncuesta = @SumPromEncuesta / @CtaPromEncuesta     
			--@13     
     
			--se actualiza el promedio de la encuesta     
			UPDATE #EncuestaResumen      
			SET PromEncuesta=@PromEncuesta     
			WHERE IdProgramacion=@IdProgramacion     
			AND IdDocente=@IdDocente      
			END

			SET @MIN = @MIN + 1

		END       
     
		DROP TABLE #EncuestaDetalle360
		
	END
     
	--@11 
	--SI ES UNA ENCUESTA 360 EL RESUMEN ES POR EVALUADO (FACILITADOR),AREA, SUBAREA, PREGUNTA Y ALTERNATIVA     
	IF @Disponible1='AEP'--ENCUESTA 360     
	BEGIN

		--Docente     
		UPDATE t     
		SET t.NombreDocente = a.NombreCompleto,t.CodigoDocente=F.CodigoAnterior     
		FROM #EncuestaResumen t WITH (NOLOCK)  
		INNER JOIN Actor a WITH (NOLOCK) on (t.IdDocente=a.IdActor)     
		INNER JOIN Facilitador F WITH (NOLOCK) on (t.IdDocente=F.IdFacilitador)       

		--total de alumno matriculados      
		UPDATE t     
		SET t.TotAlumnosMat=( SELECT COUNT(DISTINCT IdDocente)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3
		AND FD.IdEmpresa=T.IdEmpresa 
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad       
		AND FD.IdDocente=T.IdDocente     
		) FROM #EncuestaResumen t WITH (NOLOCK)     
       
		--total de alumnos encuestados
		UPDATE t     
		SET t.TotAlumnosEnc=( SELECT COUNT(DISTINCT IdDocente)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3
		AND FD.IdEmpresa=T.IdEmpresa 
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad      
		AND FD.IdDocente=T.IdDocente       
		AND FD.Respondio=1 
		) FROM #EncuestaResumen t WITH (NOLOCK)

		--total de alumnos por pregunta
		UPDATE T
		SET t.TotAlumnosPrg=( SELECT COUNT(DISTINCT FRA.IdActor)      
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle FD  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle
		WHERE FRA.IdProgramacion=T.IdProgramacion     
		AND FD.IdDocente =T.IdDocente  --@23
		AND FRA.IdPregunta=T.IdPregunta     
		AND FRA.IdAlternativa=T.IdAlternativa     
		AND FD.Respondio=1     
		) FROM #EncuestaResumen T WITH (NOLOCK)  
       
		--total de alumnos encuestados real
		UPDATE T
		SET T.TotAlumnosEncReal=(SELECT COUNT(DISTINCT FRA.IdActor)     
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle     
		INNER JOIN PreguntaAlternativa pa WITH (NOLOCK) ON FRA.IdFicha=PA.IdFicha AND FRA.IdPregunta=PA.IdPregunta AND FRA.IdAlternativa=PA.IdAlternativa
		WHERE FRA.IdProgramacion=T.IdProgramacion  
		and FD.IdDocente =T.IdDocente  --@23   
		AND FRA.IdPregunta=T.IdPregunta
		AND FD.Respondio=1
		AND ISNULL(PA.Promediable,1)=1
		) FROM #EncuestaResumen T WITH (NOLOCK)     
 
		INSERT INTO #EncuestaDetalleAEP
		(IdDocente,TotAlumnosEnc)
		SELECT DISTINCT IdDocente,TotAlumnosEnc      
		FROM #EncuestaResumen WITH (NOLOCK)
 
		SET @MIN = 0
		SET @MAX = 0 

		SELECT @MIN = MIN(ID), @MAX = MAX(id) FROM #EncuestaDetalleAEP WITH (NOLOCK)      
		--INICIO DETALLE     
		WHILE @MIN <= @MAX
		BEGIN

			SELECT @IdDocente=IdDocente,@TotAlumnosEnc=TotAlumnosEnc      
			FROM #EncuestaDetalleAEP WITH (NOLOCK)     
			WHERE ID =  @MIN      
 
			IF @TotAlumnosEnc >0      
			BEGIN

				SET @PromEncuesta = NULL     
				SET @SumPromEncuesta = NULL     
				SET @CtaPromEncuesta = NULL     

				--INICIO AREA
				DELETE FROM @EncuestaAreaAEP
				SET @MIN_Area = 0
				SET @MAX_Area = 0

				INSERT INTO @EncuestaAreaAEP(IdArea)
				SELECT DISTINCT IdArea      
				FROM #EncuestaResumen WITH (NOLOCK)    
				WHERE IdProgramacion=@IdProgramacion      
				AND IdDocente=@IdDocente

				SELECT @MIN_Area = MIN(ID), @MAX_Area = MAX(id) FROM @EncuestaAreaAEP
				WHILE @MIN_Area <= @MAX_Area  --EXISTS (SELECT IdArea FROM #EncuestaAreaAEP)
				BEGIN

					SELECT @IdArea=IdArea      
					FROM @EncuestaAreaAEP
					WHERE ID = @MIN_Area
     
					SET @PromArea = NULL     
					SET @SumPromArea = NULL     
					SET @CtaPromArea = NULL     
    
					--INICIO SUB AREA     
					DELETE FROM @EncuestaSubAreaAEP
					SET @MIN_SubArea = 0
					SET @MAX_SubArea = 0  
  
					INSERT INTO @EncuestaSubAreaAEP(IdSubArea)
					SELECT DISTINCT 'IdSubArea'=ISNULL(IdSubArea,0)     
					FROM #EncuestaResumen WITH (NOLOCK)    
					WHERE IdProgramacion=@IdProgramacion      
					AND IdDocente=@IdDocente     
					AND IdArea=@IdArea
  
					SELECT @MIN_SubArea = MIN(ID), @MAX_SubArea= MAX(id) FROM @EncuestaSubAreaAEP  
					WHILE @MIN_SubArea <= @MAX_SubArea
					BEGIN

						SELECT @IdSubArea=IdSubArea      
						FROM @EncuestaSubAreaAEP      
						WHERE ID = @MIN_SubArea   
     
						SET @PromSubArea = NULL     
						SET @SumPromSubArea = NULL     
						SET @CtaPromSubArea = NULL     
						SET @EsAbierta = 0     

						--INICIO PREGUNTA
						DELETE FROM @EncuestaPreguntaAEP
						SET @MIN_Pregunta = 0
						SET @MAX_Pregunta = 0  
       
						INSERT INTO @EncuestaPreguntaAEP(IdPregunta)
						SELECT DISTINCT IdPregunta      
						FROM #EncuestaResumen WITH (NOLOCK)    
						WHERE IdProgramacion=@IdProgramacion      
						AND IdDocente=@IdDocente     
						AND IdArea=@IdArea     
						AND ISNULL(IdSubArea,0)=@IdSubArea
   
						SELECT @MIN_Pregunta = MIN(ID), @MAX_Pregunta= MAX(id) FROM @EncuestaPreguntaAEP 
						WHILE @MIN_Pregunta <= @MAX_Pregunta
						BEGIN

							SELECT @IdPregunta=IdPregunta      
							FROM @EncuestaPreguntaAEP
							WHERE ID = @MIN_Pregunta

							SET @PromPregunta = NULL     
							SET @SumPromPregunta = NULL
 
							--INICIO ALTERNATIVA
							DELETE FROM @AlternativaAEP
							SET @MIN_Alternativa = 0
							SET @MAX_Alternativa = 0    
      
							SET @Valor=0     
							SET @Promediable=1     
							SET @IdTipoPregunta=0     
      
							INSERT INTO @AlternativaAEP(IdAlternativa,Valor,Promediable,IdTipoPregunta,TotAlumnosPrg,TotAlumnosEncReal)
							SELECT DISTINCT IdAlternativa,'Valor'=ISNULL(Valor,0),'Promediable'=ISNULL(Promediable,1),IdTipoPregunta,
							TotAlumnosPrg,TotAlumnosEncReal
							FROM #EncuestaResumen WITH (NOLOCK)     
							WHERE IdProgramacion=@IdProgramacion      
							AND IdDocente=@IdDocente     
							AND IdArea=@IdArea     
							AND ISNULL(IdSubArea,0)=@IdSubArea      
							AND IdPregunta=@IdPregunta
    
							SELECT @MIN_Alternativa = MIN(ID), @MAX_Alternativa= MAX(id) FROM @AlternativaAEP 
							WHILE @MIN_Alternativa <= @MAX_Alternativa       
							BEGIN

								SELECT @IdAlternativa=IdAlternativa,@Valor=Valor,@Promediable=Promediable,@IdTipoPregunta=IdTipoPregunta,
								@TotAlumnosPrg=TotAlumnosPrg,@TotAlumnosEncReal=TotAlumnosEncReal
								FROM @AlternativaAEP      
								WHERE ID = @MIN_Alternativa      
   
								IF @IdTipoPregunta=1426--ABIERTA   
								BEGIN

									SET @EsAbierta=1     
									--SE CONCATENA LAS RESPUESTAS DE LOS ALUMNOS      
									SET @Concatenar = ''

									SELECT @Concatenar=@Concatenar+TMP.Respuesta+' / '--@10     
									FROM ( SELECT DISTINCT fa.Respuesta     
									FROM #FichaRespuestaActor fa WITH (NOLOCK)     
									INNER JOIN FichaPregunta fp WITH (NOLOCK) ON fa.IdFicha=fp.IdFicha AND fa.IdPregunta=fp.IdPregunta     
									INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle     
									WHERE fa.IdProgramacion=@IdProgramacion     
									AND fd.IdDocente=@IdDocente     
									AND fp.IdArea=@IdArea     
									AND ISNULL(fp.IdSubArea,0)=@IdSubArea     
									AND fa.IdPregunta=@IdPregunta     
									AND fd.Respondio=1     
									AND ISNULL(fa.Respuesta,'')!='')TMP     
     
									IF LEN(@Concatenar)>0 SET @Concatenar=SUBSTRING(@Concatenar,1,LEN(@Concatenar)-2)     
     
									UPDATE #EncuestaResumen     
									SET DescAlternativa=@Concatenar     
									WHERE IdProgramacion=@IdProgramacion      
									AND IdDocente=@IdDocente     
									AND IdArea=@IdArea     
									AND ISNULL(IdSubArea,0)=@IdSubArea      
									AND IdPregunta=@IdPregunta
 
								END     
								ELSE     
								BEGIN

									SET @EsAbierta = 0; --@14     

									--se asignan variables--@6     
									IF @TotAlumnosEncReal>0      
									BEGIN

										IF @Promediable=1 SET @PtjePregunta = (@Valor * @TotAlumnosPrg) / @TotAlumnosEncReal     
										ELSE SET @PtjePregunta = NULL     
									END
									ELSE SET @PtjePregunta = NULL     
     
									IF @PtjePregunta IS NOT NULL     
									SET @SumPromPregunta = ISNULL(@SumPromPregunta,0) + @PtjePregunta     
   
									--se actualiza el total de alumnos y el puntaje por pregunta     
									UPDATE #EncuestaResumen      
									SET TotAlumnosPrg=@TotAlumnosPrg, PtjePregunta=@PtjePregunta     
									WHERE IdProgramacion=@IdProgramacion     
									AND IdDocente=@IdDocente     
									AND IdArea=@IdArea     
									AND ISNULL(IdSubArea,0)=@IdSubArea     
									AND IdPregunta=@IdPregunta     
									AND IdAlternativa=@IdAlternativa

								END     

								SET @MIN_Alternativa = @MIN_Alternativa + 1

							END
  
							IF @EsAbierta = 0     
							BEGIN

								--FIN ALTERNATIVA     
								--se asignan variables     
								SET @PromPregunta = @SumPromPregunta     
								IF @PromPregunta IS NOT NULL      
								BEGIN

									SET @SumPromSubArea = ISNULL(@SumPromSubArea,0) + @PromPregunta     
									SET @CtaPromSubArea = ISNULL(@CtaPromSubArea,0) + 1       
 
									SET @SumPromArea = ISNULL(@SumPromArea,0) + @SumPromPregunta     
									SET @CtaPromArea = ISNULL(@CtaPromArea,0) + 1
       
									SET @SumPromEncuesta = ISNULL(@SumPromEncuesta,0) + @SumPromPregunta     
									SET @CtaPromEncuesta = ISNULL(@CtaPromEncuesta,0) + 1       
 
									SET @SumPromGeneral = ISNULL(@SumPromGeneral,0) + @SumPromPregunta     
									SET @CtaPromGeneral = @CtaPromGeneral + 1     
								END
							
							END     
     
							--se actualiza el promedio de las preguntas del subarea     
							UPDATE #EncuestaResumen      
							SET PromPregunta=@PromPregunta--,     
							WHERE IdProgramacion=@IdProgramacion     
							AND IdDocente=@IdDocente     
							AND IdArea=@IdArea    
							AND ISNULL(IdSubArea,0)=@IdSubArea    
							AND IdPregunta=@IdPregunta     
    
							SET @MIN_Pregunta = @MIN_Pregunta + 1
 
						END
						--FIN PREGUNTA     
     
						--se asignan variables     
						IF @SumPromSubArea IS NOT NULL AND @CtaPromSubArea IS NOT NULL     
						SET @PromSubArea = @SumPromSubArea / @CtaPromSubArea  
     
						--se actualiza el promedio del subarea     
						UPDATE #EncuestaResumen      
						SET PromSubArea=@PromSubArea     
						WHERE IdProgramacion=@IdProgramacion     
						AND IdDocente=@IdDocente     
						AND IdArea=@IdArea     
						AND ISNULL(IdSubArea,0)=@IdSubArea
   
						SET @MIN_SubArea = @MIN_SubArea + 1

					END      
					--FIN SUBAREA     
     
					--se asignan variables   
					IF @SumPromArea IS NOT NULL AND @CtaPromArea IS NOT NULL     
					SET @PromArea = @SumPromArea / @CtaPromArea     
     
					--se actualiza el promedio del area     
					UPDATE #EncuestaResumen      
					SET PromArea=@PromArea     
					WHERE IdProgramacion=@IdProgramacion     
					AND IdDocente=@IdDocente     
					AND IdArea=@IdArea
  
					SET @MIN_Area = @MIN_Area + 1
  
				END       
				--FIN AREA    

				--se asignan variables     
				IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL     
				SET @PromEncuesta = @SumPromEncuesta / @CtaPromEncuesta     
     
				--se actualiza el promedio de la encuesta     
				UPDATE #EncuestaResumen      
				SET PromEncuesta=@PromEncuesta     
				WHERE IdProgramacion=@IdProgramacion     
				AND IdDocente=@IdDocente      
				END      
     
			SET @MIN = @MIN + 1 

		END       
     
		DROP TABLE #EncuestaDetalleAEP

	END
     
	--SI ES UNA ENCUESTA GENERICA (NO PROMOCION, SECCION, HORARIO Y DOCENTE) EL RESUMEN ES POR AREA, SUBAREA, PREGUNTA Y ALTERNATIVA     
	IF @Disponible1='EPG'--ENCUESTA ACADEMICA     
	BEGIN

		----total de personas programadas para rendir la encuesta     
		UPDATE t     
		SET t.TotAlumnosMat=( SELECT COUNT(DISTINCT IdActor)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3       
		AND FD.IdEmpresa=T.IdEmpresa  
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad      
		) FROM #EncuestaResumen t WITH (NOLOCK)
       
		--total de alumnos encuestados
		UPDATE t     
		SET t.TotAlumnosEnc=( SELECT COUNT(DISTINCT IdActor)     
		FROM #FichaProgramacionDetalle fd WITH (NOLOCK)     
		WHERE FD.IdProgramacion=T.IdProgramacion--@3       
		AND FD.IdEmpresa=T.IdEmpresa  
		AND FD.IdSede=T.IdSede      
		AND FD.IdFacultad=T.IdFacultad
		AND FD.Respondio=1 
		) FROM #EncuestaResumen t WITH (NOLOCK)  
 
		--total de alumnos por pregunta
		UPDATE T
		SET t.TotAlumnosPrg=( SELECT COUNT(DISTINCT FRA.IdActor)      
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle FD  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle
		WHERE FRA.IdProgramacion=T.IdProgramacion     
		AND FRA.IdPregunta=T.IdPregunta     
		AND FRA.IdAlternativa=T.IdAlternativa     
		AND FD.Respondio=1     
		) FROM #EncuestaResumen T WITH (NOLOCK) 
       
		--total de alumnos encuestados real
		UPDATE T
		SET T.TotAlumnosEncReal=(SELECT COUNT(DISTINCT FRA.IdActor)     
		FROM #FichaRespuestaActor FRA WITH (NOLOCK)     
		INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON FRA.IdProgramacion=FD.IdProgramacion AND FRA.IdProgramacionDetalle=FD.IdProgramacionDetalle     
		WHERE FRA.IdProgramacion=T.IdProgramacion  
		AND FRA.IdPregunta=T.IdPregunta
		AND FD.Respondio=1
		) FROM #EncuestaResumen T WITH (NOLOCK)     

    
		SET @PromEncuesta = NULL     
		SET @SumPromEncuesta = NULL     
		SET @CtaPromEncuesta = NULL

		--INICIO AREA
		DELETE FROM @EncuestaAreaEPG
		SET @MIN_Area = 0
		SET @MAX_Area = 0
  
		INSERT INTO @EncuestaAreaEPG (IdArea)  
		SELECT DISTINCT IdArea      
		FROM #EncuestaResumen WITH (NOLOCK)     
		WHERE IdProgramacion=@IdProgramacion
   
		SELECT @MIN_Area = MIN(ID), @MAX_Area = MAX(ID) FROM @EncuestaAreaEPG   
		WHILE @MIN_Area <= @MAX_Area     
		BEGIN

			SELECT @IdArea=IdArea      
			FROM @EncuestaAreaEPG      
			WHERE ID = @MIN_Area
     
			SET @PromArea = NULL     
			SET @SumPromArea = NULL     
			SET @CtaPromArea = NULL     
    
			--INICIO SUB AREA     
			DELETE FROM @EncuestaSubAreaEPG
			SET @MIN_SubArea = 0
			SET @MAX_SubArea = 0
   
			INSERT INTO @EncuestaSubAreaEPG(IdSubArea)     
			SELECT DISTINCT IdSubArea      
			FROM #EncuestaResumen WITH (NOLOCK)     
			WHERE IdProgramacion=@IdProgramacion      
			AND IdArea=@IdArea

			SELECT @MIN_SubArea = MIN(ID), @MAX_SubArea = MAX(ID) FROM @EncuestaSubAreaEPG   
			WHILE @MIN_SubArea <= @MAX_SubArea     
			BEGIN

				SELECT @IdSubArea=IdSubArea      
				FROM @EncuestaSubAreaEPG      
				WHERE ID = @MIN_SubArea       

				SET @PromSubArea = NULL     
				SET @SumPromSubArea = NULL     
				SET @CtaPromSubArea = NULL     
				SET @EsAbierta = 0     

				--INICIO PREGUNTA
				DELETE FROM @EncuestaPreguntaEPG
				SET @MIN_Pregunta = 0
				SET @MAX_Pregunta = 0

				INSERT INTO @EncuestaPreguntaEPG (IdPregunta,ValorPregunta,PromediablePregunta) --@13    
				SELECT DISTINCT IdPregunta,ValorPregunta,PromediablePregunta     
				FROM #EncuestaResumen WITH (NOLOCK)     
				WHERE IdProgramacion=@IdProgramacion      
				AND IdArea=@IdArea     
				AND IdSubArea=@IdSubArea
 
				SELECT @MIN_Pregunta = MIN(ID), @MAX_Pregunta = MAX(ID) FROM @EncuestaPreguntaEPG  
				WHILE @MIN_Pregunta <= @MAX_Pregunta      
				BEGIN

					SELECT @IdPregunta=IdPregunta,
					@ValorPregunta=ValorPregunta,
					@PromediablePregunta=PromediablePregunta--@13     
					FROM @EncuestaPreguntaEPG
					WHERE ID = @MIN_Pregunta     
      
					SET @PromPregunta = NULL     
					SET @SumPromPregunta = NULL     
      
					--INICIO ALTERNATIVA
					DELETE FROM @AlternativaEPG 
					SET @MIN_Alternativa = 0
					SET @MAX_Alternativa = 0
    
					SET @Valor=0     
					SET @Promediable=1     
					SET @IdTipoPregunta=0

					INSERT INTO @AlternativaEPG(IdAlternativa,Valor,Promediable,IdTipoPregunta,TotAlumnosPrg,TotAlumnosEncReal)
					SELECT DISTINCT IdAlternativa,'Valor'=ISNULL(Valor,0),'Promediable'=ISNULL(Promediable,1),IdTipoPregunta,
					TotAlumnosPrg,TotAlumnosEncReal
					FROM #EncuestaResumen WITH (NOLOCK)    
					WHERE IdProgramacion=@IdProgramacion      
					AND IdArea=@IdArea     
					AND IdSubArea=@IdSubArea      
					AND IdPregunta=@IdPregunta
  
					SELECT @MIN_Alternativa = MIN(ID), @MAX_Alternativa = MAX(ID) FROM @AlternativaEPG   
					WHILE @MIN_Alternativa <= @MAX_Alternativa      
					BEGIN
   
						SELECT @IdAlternativa=IdAlternativa,@Valor=Valor,@Promediable=Promediable,@IdTipoPregunta=IdTipoPregunta ,
						@TotAlumnosPrg=TotAlumnosPrg,@TotAlumnosEncReal=TotAlumnosEncReal
						FROM @AlternativaEPG      
						WHERE ID = @MIN_Alternativa     
 
						IF @IdTipoPregunta=1426--ABIERTA   
						BEGIN

							SET @EsAbierta=1     
							--SE CONCATENA LAS RESPUESTAS DE LOS ALUMNOS      
							SET @Concatenar = ''  
       
							SELECT @Concatenar=@Concatenar+TMP.Respuesta+' / '--@10     
							FROM ( SELECT DISTINCT fa.Respuesta     
							FROM #FichaRespuestaActor fa WITH (NOLOCK)     
							INNER JOIN FichaPregunta fp WITH (NOLOCK) ON fa.IdFicha=fp.IdFicha AND fa.IdPregunta=fp.IdPregunta     
							INNER JOIN #FichaProgramacionDetalle fd  WITH (NOLOCK) ON fd.IdProgramacion=fa.IdProgramacion AND fd.IdProgramacionDetalle=fa.IdProgramacionDetalle     
							WHERE fa.IdProgramacion=@IdProgramacion     
							AND fp.IdArea=@IdArea     
							AND fp.IdSubArea=@IdSubArea     
							AND fa.IdPregunta=@IdPregunta     
							AND fd.Respondio=1     
							AND ISNULL(fa.Respuesta,'')!='')TMP

							IF LEN(@Concatenar)>0 SET @Concatenar=SUBSTRING(@Concatenar,1,LEN(@Concatenar)-2) 

							UPDATE #EncuestaResumen     
							SET DescAlternativa=@Concatenar     
							WHERE IdProgramacion=@IdProgramacion      
							AND IdArea=@IdArea     
							AND IdSubArea=@IdSubArea      
							AND IdPregunta=@IdPregunta

						END     
						ELSE     
						BEGIN

							Set @EsAbierta = 0; --@14
      
							--se asignan variables--@6     
							IF @TotAlumnosEncReal>0      
							BEGIN     
							IF @Promediable=1 SET @PtjePregunta = (@Valor * @TotAlumnosPrg) / @TotAlumnosEncReal     
							ELSE SET @PtjePregunta = NULL     
							END     
							ELSE SET @PtjePregunta = NULL     
   
							IF @PtjePregunta IS NOT NULL     
							SET @SumPromPregunta = ISNULL(@SumPromPregunta,0) + @PtjePregunta     
   
							--se actualiza el total de alumnos y el puntaje por pregunta     
							UPDATE #EncuestaResumen      
							SET TotAlumnosPrg=@TotAlumnosPrg, PtjePregunta=@PtjePregunta     
							WHERE IdProgramacion=@IdProgramacion     
							AND IdArea=@IdArea     
							AND IdSubArea=@IdSubArea     
							AND IdPregunta=@IdPregunta     
							AND IdAlternativa=@IdAlternativa 

						END     
   
						SET @MIN_Alternativa = @MIN_Alternativa + 1

					END

					IF @EsAbierta = 0     
					BEGIN

						--FIN ALTERNATIVA     
						--se asignan variables     
						SET @PromPregunta = @SumPromPregunta
						
						IF @PromPregunta IS NOT NULL

						BEGIN
							SET @SumPromSubArea = ISNULL(@SumPromSubArea,0) + @PromPregunta     
							SET @CtaPromSubArea = ISNULL(@CtaPromSubArea,0) + 1     
   
							SET @SumPromArea = ISNULL(@SumPromArea,0) + @SumPromPregunta     
							SET @CtaPromArea = ISNULL(@CtaPromArea,0) + 1     
   
							IF @PromediablePregunta = 1 --@13     
							BEGIN --@13     
								--SET @SumPromEncuesta = ISNULL(@SumPromEncuesta,0) + @SumPromPregunta     
								SET @SumPromEncuesta = (ISNULL(@SumPromPregunta,0) * (@ValorPregunta/100)) + ISNULL(@SumPromEncuesta,0)     
								SET @CtaPromEncuesta = ISNULL(@CtaPromEncuesta,0) + 1     
							END --@13

							SET @SumPromGeneral = ISNULL(@SumPromGeneral,0) + @SumPromPregunta     
							SET @CtaPromGeneral = @CtaPromGeneral + 1

						END 

					END     
   
					--se actualiza el promedio de las preguntas del subarea     
					UPDATE #EncuestaResumen      
					SET PromPregunta=@PromPregunta--,     
					WHERE IdProgramacion=@IdProgramacion     
					AND IdArea=@IdArea     
					AND IdSubArea=@IdSubArea     
					AND IdPregunta=@IdPregunta     
  
					SET @MIN_Pregunta = @MIN_Pregunta + 1

				END     
				--FIN PREGUNTA     
     
				--select @IdArea,@IdSubArea,@IdPregunta, @SumPromSubArea,@CtaPromSubArea      
				--se asignan variables     
				IF @SumPromSubArea IS NOT NULL AND @CtaPromSubArea IS NOT NULL     
					SET @PromSubArea = @SumPromSubArea / @CtaPromSubArea  
     
				--se actualiza el promedio del subarea     
				UPDATE #EncuestaResumen      
				SET PromSubArea=@PromSubArea     
				WHERE IdProgramacion=@IdProgramacion     
				AND IdArea=@IdArea     
				AND IdSubArea=@IdSubArea

				SET @MIN_SubArea = @MIN_SubArea + 1
 
			END      
			--FIN SUBAREA     
     
			--se asignan variables   
			IF @SumPromArea IS NOT NULL AND @CtaPromArea IS NOT NULL     
			SET @PromArea = @SumPromArea / @CtaPromArea     
     
			--se actualiza el promedio del area     
			UPDATE #EncuestaResumen      
			SET PromArea=@PromArea     
			WHERE IdProgramacion=@IdProgramacion     
			AND IdArea=@IdArea

			SET @MIN_Area = @MIN_Area + 1
  
		END   
		--FIN AREA    

		--se asignan variables     
		--@13     
		IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL     
		SET @PromEncuesta = @SumPromEncuesta     
		--IF @SumPromEncuesta IS NOT NULL AND @CtaPromEncuesta IS NOT NULL     
		-- SET @PromEncuesta = @SumPromEncuesta / @CtaPromEncuesta     
		--@13     
     
		--se actualiza el promedio de la encuesta      
		UPDATE  #EncuestaResumen     
		SET PromEncuesta=@PromEncuesta     
		WHERE IdProgramacion=@IdProgramacion     
     
	END

	--Fin @27
    
	--se asignan variables     
	IF @SumPromGeneral IS NOT NULL AND @CtaPromGeneral IS NOT NULL     
	SET @PromGeneral = @SumPromGeneral / @CtaPromGeneral     
     
	--se actualiza el promedio general de toda la programacion    
	UPDATE #EncuestaResumen      
	SET PromGeneral=@PromGeneral     
	WHERE IdProgramacion=@IdProgramacion   
	--FIN DETALLE      

	INSERT INTO FichaProgramacionResumen     
	(IdProgramacionDetalle,IdProgramacion,IdFicha,IdEmpresa,IdSede,IdFacultad,IdUnidadNegocio,IdUnidadAcademica,IdPeriodo,IdProducto     
	,IdSemestre,IdPromocion,IdGrupo,IdSeccion,IdCurso,IdActor,IdDocente,IdPregunta,IdTipoPregunta,IdAlternativa,IdArea     
	,IdSubArea,IdTipoEncuesta,IdEstado,IdSistema,FechaInicio,FechaFin,Respondio,FechaRespuesta,CodigoSede,NombreSede     
	,CodigoPeriodo,NombrePeriodo,CodigoDivicion,NombreDivicion,CodigoPrograma,NombrePrograma,CodigoProducto,NombreProducto,CodigoSemestre,NombreSemestre     
	,CodigoCurso,NombreCurso,CodigoSeccion,CodigoDocente,NombreDocente,CodigoArea,NombreArea,CodigoSubArea,NombreSubArea,DesEncuesta     
	,Valor,TipoEncuesta,Dsp1TipoEncuesta,Dsp2TipoEncuesta,Dsp3TipoEncuesta,Dsp4TipoEncuesta,Dsp5TipoEncuesta,OrdenPregunta,OrdenAlternativa,DescPregunta     
	,Opcion,DescAlternativa,TipoPregunta,TipoControl,PtjeMinimo,TotAlumnosMat,TotAlumnosEnc,TotAlumnosPrg,PtjePregunta,PromPregunta     
	,PromSubArea,PromArea,PromEncuesta,PromGeneral,Respuesta,Vigente,TipoCodSistema,CabEstado,DetEstado,EncEstado     
	,UsuarioCreacion,FechaCreacion,UsuarioModIFicacion,FechaModIFicacion)
	SELECT IdProgramacionDetalle,IdProgramacion,IdFicha,IdEmpresa,IdSede,IdFacultad,IdUnidadNegocio,IdUnidadAcademica,IdPeriodo,IdProducto     
	,IdSemestre,IdPromocion,ISNULL(IdGrupo,0),ISNULL(IdSeccion,0),ISNULL(IdCurso,0),IdActor,ISNULL(IdDocente,0),IdPregunta,IdTipoPregunta,IdAlternativa,IdArea     
	,ISNULL(IdSubArea,0),IdTipoEncuesta,IdEstado,IdSistema,FechaInicio,FechaFin,Respondio,FechaRespuesta,CodigoSede,NombreSede     
	,CodigoPeriodo,NombrePeriodo,CodigoDivicion,NombreDivicion,CodigoPrograma,NombrePrograma,CodigoProducto,NombreProducto,CodigoSemestre,NombreSemestre     
	,CodigoCurso,NombreCurso,LEFT(REPLACE(CodigoSeccion,' ',''),15)/*@5*/,CodigoDocente,LTRIM(NombreDocente),CodigoArea,NombreArea,CodigoSubArea,NombreSubArea,DesEncuesta     
	,Valor,TipoEncuesta,Dsp1TipoEncuesta,Dsp2TipoEncuesta,Dsp3TipoEncuesta,Dsp4TipoEncuesta,Dsp5TipoEncuesta,OrdenPregunta,OrdenAlternativa,DescPregunta     
	,Opcion,DescAlternativa,TipoPregunta,TipoControl,PtjeMinimo,TotAlumnosMat,TotAlumnosEnc,TotAlumnosPrg,PtjePregunta,PromPregunta     
	,PromSubArea,PromArea,PromEncuesta,PromGeneral,Respuesta,Vigente,TipoCodSistema,CabEstado,DetEstado,EncEstado     
	,UsuarioCreacion,FechaCreacion,UsuarioModIFicacion,FechaModIFicacion     
	FROM #EncuestaResumen WITH (NOLOCK)     
   
	--SELECT FPR.PromEncuesta,FPR.IdPregunta,* FROM FichaProgramacionResumen FPR	--@32
	--INNER JOIN #EncuestaResumen ER ON FPR.IdProgramacion = ER.IdProgramacion  

	IF OBJECT_ID('tempdb..#FichaProgramacionDetalle','u') IS NOT NULL      
	DROP TABLE #FichaProgramacionDetalle
	IF OBJECT_ID('tempdb..#FichaRespuestaActor','u') IS NOT NULL      
	DROP TABLE #FichaRespuestaActor    
	IF OBJECT_ID('tempdb..#EncuestaResumen','u') IS NOT NULL      
	DROP TABLE #EncuestaResumen    
	IF OBJECT_ID('tempdb..#EncuestaResumenSinAlternativas','u') IS NOT NULL      
	DROP TABLE #EncuestaResumenSinAlternativas
	IF OBJECT_ID('tempdb..#EncuestaDetalleEAA','u') IS NOT NULL
	DROP TABLE #EncuestaDetalleEAA     
	IF OBJECT_ID('tempdb..#EncuestaDetalleESA','u') IS NOT NULL
	DROP TABLE #EncuestaDetalleESA     
	IF OBJECT_ID('tempdb..#EncuestaDetalle360','u') IS NOT NULL
	DROP TABLE #EncuestaDetalle360     
	IF OBJECT_ID('tempdb..#EncuestaDetalleAEP','u') IS NOT NULL
	DROP TABLE #EncuestaDetalleAEP     
	IF OBJECT_ID('tempdb..#EncuestaAreaEAA','u') IS NOT NULL      
	DROP TABLE #EncuestaAreaEAA     
	IF OBJECT_ID('tempdb..#EncuestaAreaESA','u') IS NOT NULL      
	DROP TABLE #EncuestaAreaESA     
	IF OBJECT_ID('tempdb..#EncuestaArea360','u') IS NOT NULL      
	DROP TABLE #EncuestaArea360     
	IF OBJECT_ID('tempdb..#EncuestaAreaAEP','u') IS NOT NULL      
	DROP TABLE #EncuestaAreaAEP     
	IF OBJECT_ID('tempdb..#EncuestaSubAreaEAA','u') IS NOT NULL      
	DROP TABLE #EncuestaSubAreaEAA     
	IF OBJECT_ID('tempdb..#EncuestaSubAreaESA','u') IS NOT NULL      
	DROP TABLE #EncuestaSubAreaESA     
	IF OBJECT_ID('tempdb..#EncuestaSubArea360','u') IS NOT NULL      
	DROP TABLE #EncuestaSubArea360     
	IF OBJECT_ID('tempdb..#EncuestaSubAreaAEP','u') IS NOT NULL      
	DROP TABLE #EncuestaSubAreaAEP     
	IF OBJECT_ID('tempdb..#EncuestaPreguntaEAA','u') IS NOT NULL      
	DROP TABLE #EncuestaPreguntaEAA     
	IF OBJECT_ID('tempdb..#EncuestaPreguntaESA','u') IS NOT NULL      
	DROP TABLE #EncuestaPreguntaESA     
	IF OBJECT_ID('tempdb..#EncuestaPregunta360','u') IS NOT NULL      
	DROP TABLE #EncuestaPregunta360     
	IF OBJECT_ID('tempdb..#EncuestaPreguntaAEP','u') IS NOT NULL      
	DROP TABLE #EncuestaPreguntaAEP     
	IF OBJECT_ID('tempdb..#AlternativaEAA','u') IS NOT NULL      
	DROP TABLE #AlternativaEAA     
	IF OBJECT_ID('tempdb..#AlternativaESA','u') IS NOT NULL      
	DROP TABLE #AlternativaESA     
	IF OBJECT_ID('tempdb..#Alternativa360','u') IS NOT NULL      
	DROP TABLE #Alternativa360     
	IF OBJECT_ID('tempdb..#AlternativaAEP','u') IS NOT NULL      
	DROP TABLE #AlternativaAEP     
    IF OBJECT_ID('tempdb..#MaestroTablaRegistro','u') IS NOT NULL      
	DROP TABLE #MaestroTablaRegistro     
	SET @RetVal = 1     
     
	SET NOCOUNT OFF
    
END