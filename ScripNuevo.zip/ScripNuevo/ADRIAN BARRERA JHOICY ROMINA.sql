--SELECT TipoCondicion,*FROM Matricula 
----UPDATE Matricula SET TipoCondicion='CC'
--where IdMatricula=740973
----RE(PROMOVIDO)

--SELECT TipoCondicion,*FROM AlumnoCurso 
UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=740973 AND EsMatricula=1 


------RP(PROMOVIDO + CURSO)
------CC(CURSO REPITENCIA)
------RT(REPITENCIA)
------RE(PROMOVIDO)
--SELECT*FROM AlumnoCursoNomina WHERE IdMatricula=740973