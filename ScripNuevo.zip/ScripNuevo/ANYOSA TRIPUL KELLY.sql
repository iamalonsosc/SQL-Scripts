--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='RE'
where IdMatricula=674276


--SELECT TipoCondicion,*FROM AlumnoCurso 
--where IdMatricula=674276 AND EsMatricula=1

----RP(PROMOVIDO + CURSO)
----CC(CURSO REPITENCIA)
----RT(REPITENCIA)
----RE(PROMOVIDO)
