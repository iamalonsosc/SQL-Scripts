SELECT CU.CursoNombreCorto,AC.IdPromocion,PR.IdModulo,PR.ServicioCodigo,AC.EsMatricula FROM AlumnoCurso AC
INNER JOIN Curso CU ON CU.IdCurso=AC.IdCurso
INNER JOIN Promocion PR ON PR.IdPromocion=AC.IdPromocion
WHERE AC.IdMatricula=503253