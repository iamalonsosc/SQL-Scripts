---CORTEZ LLALLAHUI EVELYN MARISOL
UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40116,Promediofinal=18, PromedioReal=18, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51714', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1271784 and  idcurricula=5608 and idcurso in (9856,9921,9799,9863)
--(1 row affected)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40116,Promediofinal=20, PromedioReal=20, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51714', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1271784 and  idcurricula=5608 and idcurso in (10060)
--(1 row affected)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40116,Promediofinal=19, PromedioReal=19, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51714', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1271784 and  idcurricula=5608 and idcurso in (9857,10063,11358,10066)
--(1 row affected)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40116,Promediofinal=17, PromedioReal=17, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51714', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1271784 and  idcurricula=5608 and idcurso in (10064)
--(1 row affected)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40116,Promediofinal=15, PromedioReal=15, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51714', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1271784 and  idcurricula=5608 and idcurso in (10058)
--(1 row affected)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40116,Promediofinal=14, PromedioReal=14, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51714', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1271784 and  idcurricula=5608 and idcurso in (9833)
--(1 row affected)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=40116,Promediofinal=16, PromedioReal=16, PromedioCondicion='A',TipoCondicion='CO', 
								Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 51714', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1271784 and  idcurricula=5608 and idcurso in (9876)
--(1 row affected)
