--select estado,* from Matricula 
UPDATE Matricula SET Estado='R'
where numero = '25006058' --  actualizar a estado = 'R'
--(1 row affected)