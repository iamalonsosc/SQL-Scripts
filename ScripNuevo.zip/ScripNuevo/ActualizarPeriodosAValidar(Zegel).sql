--Select Valor,* from Parametro WITH(NOLOCK) where Nombre='PeriodosValidarDescuento'  AND Activo=1

--NUEVOS PERIODOS ZEGEL
--2025-IIA,2025-II,2025-IIIE,2026-IE,2026-IIA,2026-IIE (PERIODOS ANTIGUOS)
UPDATE Parametro SET Valor='2026-IIA,2026-IIE,2026-IIIA,2026-IIIE'
where Nombre='PeriodosValidarDescuento'  AND Activo=1