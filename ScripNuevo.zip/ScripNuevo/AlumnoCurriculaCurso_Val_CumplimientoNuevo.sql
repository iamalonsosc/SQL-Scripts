--����������������������������������������������������������������������������          
--Creado por      : Luis Perales (10/07/2012)          
--Funcionalidad   : Verifica el cumplimiento del alumno de acuerdo a las equivalencias            
--Utilizado por   :            
--����������������������������������������������������������������������������       
/*            
-----------------------------------------------------------------------------            
Nro  FECHA   USUARIO   DESCRIPCION            
-----------------------------------------------------------------------------            
@1  20.09.2019  Hmora   Se agrego Validacion Secuencial        
@2  13.03.2024  JQuenta   Se agrega IN y dentro del IN Tipo 2 para que registre en la Tabla Temporal las Equivalencias de Egresados    
          para solucionar casuisticas de carga habil que genera pre matriculas para I semestre    
@3  26/09/2025  JQuenta   Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil    
@4  01/09/2026  Valvarado Se agrega tipo 4 para extension  
*/    
    
--CREATE   PROCEDURE [dbo].[AlumnoCurriculaCurso_Val_CumplimientoNuevo]    
DECLARE
@pIdAlumno INT,    
@pIdRegistro INT,    
@pIdCurriculaNueva INT,    
@pIdCurriculaAntigua INT,    
@pIdCurso INT,    
@pForma VARCHAR(2),    
@pCumple INT ,    
@pTipoAprobacion VARCHAR(2) ,          
@pPromedioFinal VARCHAR(5) ,          
@pPromedioReal VARCHAR(5)         
--As    
BEGIN    
    SELECT @pIdAlumno=1737779, @pIdRegistro=1,@pIdCurriculaNueva=6169,@pIdCurriculaAntigua=5568,@pIdCurso=10385,@pForma='NO'
 --Inicio --@3    
 SET NOCOUNT ON    
     
 /*    
  Tipos de verificacion de cumplimiento academico:    
  AP: Aprobado directamente    
  EQ: Equivalencia    
  CO: Convalidacion    
 */    
    
 ---Declaramos las variables    
 DECLARE     
 @pIdPaquete INT,    
 @CurIdCurso INT,    
 @Verif INT,          
 @CantCursos INT,          
 @pPromedioFinalTotal DECIMAL(4,2),          
 @pPromedioRealTotal DECIMAL(4,2)          
               
 SET @pCumple = 0    
 SET @pPromedioFinal = ''          
 SET @pPromedioReal = ''          
           
 --Verificamos si ha aprobado el curso directamente    
 SELECT    
  @pPromedioFinal = ISNULL(PromedioFinal,''),    
  @pPromedioReal = ISNULL(PromedioReal,'')          
 FROM AlumnoCurriculaCurso WITH (NOLOCK)             
 WHERE IdAlumno = @pIdAlumno    
 AND IdCurso = @pIdCurso    
 AND IdRegistro = @pIdRegistro    
 AND IdCurricula = @pIdCurriculaNueva    
 AND PromedioCondicion = 'A'    
 AND TipoCondicion = 'RE'    
    
 --Aprobo el curso    
 IF @pPromedioFinal <> ''     
 BEGIN    
    
  SET @pCumple = 1    
  SET @pTipoAprobacion = 'AP'         
  RETURN    
    
 END    
    
 SET @pPromedioFinal = ''          
 SET @pPromedioReal = ''            
     
 --Verificamos si ha aprobado el curso convalidandolo    
 SELECT    
  @pPromedioFinal = ISNULL(PromedioFinal,''),    
  @pPromedioReal = ISNULL(PromedioReal,'')          
 FROM AlumnoCurriculaCurso WITH (NOLOCK) --@3    
 WHERE IdAlumno = @pIdAlumno    
 AND IdCurso = @pIdCurso    
 AND IdRegistro = @pIdRegistro    
 AND IdCurricula = @pIdCurriculaNueva    
 AND PromedioCondicion = 'A'    
 AND TipoCondicion = 'CO'    
     
 --Aprobo el curso convalidandolo    
 IF @pPromedioFinal <> ''    
 BEGIN    
    
  SET @pCumple = 1    
  SET @pTipoAprobacion = 'CO'                  
  RETURN    
    
 END    
 --Verificamos si por Equivalencia    
 ELSE     
 BEGIN    
    
  DECLARE @CurPaquetes AS TABLE --@3    
  (    
   Id INT IDENTITY(1,1), --@3    
   IdPaquete INT    
  )    
    
  --Declaramos el cursor para sacar los paquetes de las equivalencias    
  INSERT INTO @CurPaquetes    
  SELECT    
   IdPaquete     
  FROM PaqCursoEquivalencia WITH (NOLOCK) --@3    
  WHERE IdEquivalencia IN    
  (    
   SELECT    
    IdEquivalencia    
   FROM CursoEquivalencia WITH (NOLOCK) --@3    
   WHERE IdCurso = @pIdCurso            
  --@1            
   AND IdCurricula = @pIdCurriculaNueva    
  )      
  AND Vigencia = 1    
  AND IdTipo IN (1,2,4) --@2 @4   
  --@1            
          SELECT *FROM @CurPaquetes
  SET @CantCursos = 0           
  SET @pPromedioFinalTotal = 0         
  SET @pPromedioRealTotal = 0    
      
  WHILE EXISTS (SELECT * FROM @CurPaquetes)    
  BEGIN    
    
   SET @pIdPaquete = NULL --@3    
            
   SELECT TOP 1    
    @pIdPaquete = IdPaquete    
   FROM @CurPaquetes     
   ORDER BY Id ASC    
           
   SET @pForma = 'RE'    
            
   DECLARE @CurCursosPaquetes AS TABLE --@3    
   (    
    Id INT IDENTITY(1,1), --@3    
    IdCurso INT    
   )    
    
   --Declaramos el cursor para sacar los cursos de cada paquete    
   INSERT INTO @CurCursosPaquetes    
   SELECT    
    IdCurso    
   FROM PaqCursoEquivalenciaDet WITH (NOLOCK) --@3    
   WHERE IdPaquete = @pIdPaquete    
   AND IdCurricula = @pIdCurriculaAntigua --@1    
   
      SELECT*FROM @CurCursosPaquetes

   WHILE EXISTS (SELECT * FROM @CurCursosPaquetes)    
   BEGIN    
    
    SET @CurIdCurso = NULL --@3    
    
    SELECT TOP 1    
     @CurIdCurso = IdCurso    
    FROM @CurCursosPaquetes     
    ORDER BY Id ASC          
           
    SET @CantCursos = @CantCursos + 1    
      
    IF NOT EXISTS     
    (    
     SELECT    
      1    
     FROM TempValidaCumplimiento WITH (NOLOCK) --@3    
     WHERE idcurso = @CurIdCurso             
     AND idsesion = @@SPID    
    )            
    BEGIN    
    
     INSERT INTO TempValidaCumplimiento    
     --Inicio --@3    
     (    
      idcurso,    
      idsesion    
     )    
     --Fin --@3    
     VALUES    
     (    
      @CurIdCurso,    
      @@SPID    
     )            
        
     EXEC AlumnoCurriculaCurso_Val_CumplimientoNuevo    
     @pIdAlumno,    
     @pIdRegistro,    
     @pIdCurriculaAntigua,    
     @pIdCurriculaAntigua,    
     @CurIdCurso,    
     @pForma,    
     @pCumple OUTPUT,    
     @pTipoAprobacion OUTPUT,          
     @pPromedioFinal OUTPUT,          
     @pPromedioReal OUTPUT    
    
    END            
            
    IF @pCumple = 0     
    BEGIN    
    
     --No cumplio como minimo 1 curso del paquete    
     DELETE FROM @CurCursosPaquetes --@3    
    
    END    
    ELSE    
    BEGIN    
    
     SET @pPromedioFinalTotal = @pPromedioFinalTotal + CONVERT(DECIMAL,@pPromedioFinal)    
     SET @pPromedioRealTotal = @pPromedioRealTotal + CONVERT(DECIMAL,@pPromedioReal)    
    
     DELETE FROM TempValidaCumplimiento --@3           
     WHERE idcurso = @CurIdCurso            
     AND idsesion = @@SPID    
    
    END            
           
    DELETE N FROM @CurCursosPaquetes N    
    WHERE N.Id =    
    (    
     SELECT TOP 1    
      Id     
     FROM @CurCursosPaquetes     
     ORDER BY Id ASC --@3    
    )    
    
   END    
    
   IF @CantCursos >  0      
   BEGIN    
    
    SET @pPromedioFinal = CONVERT(VARCHAR,@pPromedioFinalTotal / @CantCursos)    
    SET @pPromedioReal = CONVERT(VARCHAR,@pPromedioRealTotal / @CantCursos)    
    
   END      
   ELSE      
   BEGIN    
    
    SET @pPromedioFinal = CONVERT(VARCHAR,@pPromedioFinalTotal / 1)    
    SET @pPromedioReal = CONVERT(VARCHAR,@pPromedioRealTotal / 1)    
    
   END    
    
   DELETE N FROM @CurPaquetes N    
   WHERE N.Id =    
   (    
    SELECT TOP 1    
     Id     
    FROM @CurPaquetes     
    ORDER BY Id ASC --@3    
   )    
    
  END    
    
 END    
 --Fin --@3    
                   
END