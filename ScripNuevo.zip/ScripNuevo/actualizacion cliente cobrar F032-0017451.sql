
--select ClienteNumero, ClienteCobrarA, CompaniaSocio,Interfase_Matricula,* from CO_Documento where TipoDocumento = 'FC' and NumeroDocumento = 'F032-0017451' and CompaniaSocio='00002500';

UPDATE CO_Documento SET ClienteCobrarA = ClienteNumero WHERE TipoDocumento = 'FC' AND NumeroDocumento = 'F032-0017451' and CompaniaSocio='00002500';

