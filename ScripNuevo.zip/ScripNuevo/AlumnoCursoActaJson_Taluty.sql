SELECT * FROM [minedu].AlumnoCursoActaJson_Taluty where periodoCodigoMinedu in ('2020-3C')
AND
planEstudio in ('PLAN 2017-0500','PLAN 2017-0502')
AND 
seccion in ('500.III.01.2020-IIIC-III-A',
'500.IV.01.2020-IIIC-IV-A',
'500.V.01.2020-IIIC-V-A',
'500.V.01.2020-IIIC-V-B',
'500.VI.01.2020-IIIC-VI-A',
'500.VI.01.2020-IIIC-VI-B',
'502.V.01.2020-IIIC-V-A',
'502.VI.01.2020-IIIC-VI-A')
order by id