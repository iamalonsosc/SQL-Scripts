--INSERTAR LAS ASISTENCIAS PORQUE NO SE HAN TOMADO
INSERT INTO AlumnoCursoAsistencia
SELECT DISTINCT HS.IdSeccion, HS.IdHorario,HS.IdSesion,AC.IdAlumno,NULL,'A','ASISTENCIA PERFECTA 26-07-2023',1,GETDATE()
from Matricula m WITH (NOLOCK)
INNER JOIN Alumno AL WITH (NOLOCK) ON m.IdActor=al.IdAlumno
INNER JOIN AlumnoCurso ac WITH (NOLOCK) ON m.IdMatricula=ac.IdMatricula
INNER JOIN HorarioSesion HS WITH (NOLOCK) ON AC.IdSeccion=HS.IdSeccion
INNER JOIN Seccion se WITH (NOLOCK) ON hs.IdSeccion=se.IdSeccion
INNER JOIN Promocion PR WITH (NOLOCK) ON SE.IdPromocion=PR.IdPromocion
LEFT JOIN AlumnoCursoAsistencia ACA WITH (NOLOCK) ON ACA.IdSeccion=HS.IdSeccion AND ACA.IdSesion=HS.IdSesion AND ACA.IdHorario=HS.IdHorario AND ACA.IdAlumno=AC.IdAlumno 
WHERE PR.IdEmpresa=1
AND PR.IdFacultad=1
--AND PR.IdUnidadNegocio=1
AND PR.IdSede=46
AND PR.IdPeriodoAnual IN (2023)
AND ACA.IdSeccion IS NULL 
--AND CONVERT(VARCHAR,HS.Fecha,112) BETWEEN '20230206' AND '20230227'
AND M.EsMatricula=1
AND M.Estado='N'
AND HS.Estado!='X' 
AND HS.EsPostergado=0

--ACTUALIZAR LAS ASISTENCIAS QUE ESTAN EN FALTA
UPDATE ACA 
SET ACA.Valor='A',
ACA.Observacion='ASISTENCIA PERFECTA 26-07-2023',
ACA.UsuarioModificacion=1,
ACA.FechaModificacion=GETDATE()
-- SELECT ACA.* 
from Matricula m WITH (NOLOCK)
INNER JOIN AlumnoCurso ac WITH (NOLOCK) ON m.IdMatricula=ac.IdMatricula
INNER JOIN HorarioSesion HS WITH (NOLOCK) ON AC.IdSeccion=HS.IdSeccion
INNER JOIN Seccion se WITH (NOLOCK) ON hs.IdSeccion=se.IdSeccion
INNER JOIN Promocion PR WITH (NOLOCK) ON SE.IdPromocion=PR.IdPromocion
INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo=PE.IdPeriodo
INNER JOIN AlumnoCursoAsistencia ACA WITH (NOLOCK) ON ACA.IdSeccion=HS.IdSeccion AND ACA.IdSesion=HS.IdSesion AND ACA.IdHorario=HS.IdHorario AND ACA.IdAlumno=AC.IdAlumno
WHERE PR.IdEmpresa=1
AND PR.IdFacultad=1
--AND PR.IdUnidadNegocio=1
AND PR.IdSede=46
AND PR.IdPeriodoAnual IN (2023)
--AND PE.Codigo IN ('2022-II','2022-IIA','2022-IIG','2022-IID')
--AND MONTH(HS.Fecha) in (1,2)
AND M.EsMatricula=1
AND M.Estado='N'
AND HS.Estado!='X' 
AND HS.EsPostergado=0
AND ACA.Valor='F'
--AND al.CodigoAnterior=@CodigoAlumno
--AND se.Codigo=@CodigoSeccion