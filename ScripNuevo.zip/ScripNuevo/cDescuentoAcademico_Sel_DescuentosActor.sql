--����������������������������������������������������������������������������
--Creado por	: Jimy Mota (06/06/2017)
--Funcionalidad : Permite listar los descuento validos para un actor
--Utilizado por : DescuentoAcademico.SelListarLis
--Proyecto		: Descuento academico
--����������������������������������������������������������������������������
/*
-----------------------------------------------------------------------------
Nro		FECHA			USUARIO				DESCRIPCION
-----------------------------------------------------------------------------
@1		2017.11.13		jmota				se modifica para mostrar un nombre diferente para smart
@2		2018.03.19		jmota				parametro agregado para los cupones
@3		2019.09.26		YFlores				Condici�n para no consultar la BD de Gupta para Corriente Alterna
@4		2019.10.29		YFlores				Se revierten cambios
@5		2020.08.12		jmota				se agregan campos de codigo periodo y producto clasificacion
@6		2020.10.28		jmota				se corrige error de codigo de periodo
@7		2021.05.28		jnavia				se cambia el tama�o del campo CuotaNombre
@8		2022.10.03		mbueno				se listan descuentos con codigo -1
@9		2023.11.28		alsanchez			Configuracion del periodo por difereniacion de precio
@10		2023.12.12		alsanchez			Busqueda por IdPrecioSede
@11		2024.05.01		FETORRES			Se agrega logica para que CA tome la compania socio de ZEGEL. 
@12		2024.06.05		MQUIROZ				Se agrega validacion para ITS por compania socio
@13		26/09/2025		JQuenta				Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil
*/

--CREATE PROCEDURE [dbo].[cDescuentoAcademico_Sel_DescuentosActor]
DECLARE 
@IdActor INT,
@IdEmpresa INT,
@IdSede INT,
@IdFacultad INT,
@IdUnidadNegocio INT,
@IdUnidadAcademica INT,
@IdPeriodo INT,
@IdCurricula INT,
@IdProducto INT,
@IdModulo INT,
@IdTipoTurno INT,
@IdPromocion INT,
@IdGrupo INT,
@IdSeccion INT,
@IdTipo INT,
@EsContado BIT,
@Disponible1 VARCHAR(100),
@UsuarioCreacion INT= NULL, --Usuario que consulta el descuento
@IdConvenio INT = NULL,
@IdMatricula INT = NULL,
@TipoServicio CHAR(1) = NULL,
@FechaConsulta DATE = NULL,
@Disponible4 VARCHAR(100) = NULL, --@2
@IdPrecioSede INT = NULL --@10
--AS
BEGIN
SELECT @IdActor=1591644,@IdEmpresa=1,@IdSede=50,@IdFacultad=1,@IdUnidadNegocio=1,@IdUnidadAcademica=57,@IdPeriodo=4275,@IdCurricula=6078,@IdProducto=15155,@IdModulo=2,@IdTipoTurno=46376,@IdPromocion=102076,@IdGrupo=1,@IdSeccion=NULL,@IdTipo=23952,@EsContado=0,@Disponible1=N'SECUENCIAL',@UsuarioCreacion=N'504061',@IdConvenio=NULL,@IdMatricula=810270,@TipoServicio=N'P',@Disponible4='2026-04-30',@IdPrecioSede=50



	--Inicio --@13
	SET NOCOUNT ON

	DECLARE
	@PeriodoCodigo VARCHAR(20),
	@IdClasificacionProducto INT, --@5
	@CompaniaSocio CHAR(8),
	--Inicio @3
	@Min INT,
	@Max INT,
	@IdTipoSituacionAlumno INT,
	@IdDescuentoAcademico INT,
	@Campana VARCHAR(MAX),
	@Area VARCHAR(MAX),
	@TipoMatricula VARCHAR(MAX),
	@IntReturn INT

	DECLARE @DescuentoAcademicoPoblacionDestino AS TABLE --@13
	(
		Id INT IDENTITY(1,1),
		IdDescuentoAcademico INT,
		IdTipoSituacionAlumno INT,
		Codigo INT,
		Nombre VARCHAR(800),
		Porcentaje DECIMAL(7,4),
		FechaInicio VARCHAR(10),
		FechaFin VARCHAR(10),
		NroPeriodo INT,
		EsAcumulativo BIT,
		DiasVigentes INT,
		IdTipo INT,
		TipoNombre VARCHAR(200),
		CuotaNombre VARCHAR(MAX), --@7
		Campana VARCHAR(200),
		Area VARCHAR(200),
		TipoMatricula VARCHAR(500),
		Activo BIT
	)

	SELECT
		@CompaniaSocio = CompaniaSocio
	FROM Empresa WITH (NOLOCK)
	WHERE IdEmpresa = @IdEmpresa
	--@Fin @3

	IF @Disponible1 = 'True'
	BEGIN

		SET @Disponible1 = 'CAPTACI�N'

	END
	ELSE
	BEGIN

		SET @Disponible1 = 'SECUENCIAL'

	END

	IF @Disponible1 = 'SECUENCIAL'
	BEGIN

		--Validamos que el alumno sea secuencial
		IF NOT EXISTS
		(
			SELECT 1
			FROM Matricula WITH (NOLOCK)
			WHERE IdActor = @IdActor
			AND Estado <> 'X'
			AND IdPeriodo = @IdPeriodo
		)
		BEGIN

			SET @Disponible1 = 'CAPTACI�N'

		END

	END

	IF @FechaConsulta IS NULL
	BEGIN

		SET @FechaConsulta = GETDATE()

	END

	--VALIDACION CAMBIO DE CARRERA
	--Si el alumno se matriculo en otra carrera le damos los descuentos vigentes en la fecha de su primera matricula
	IF EXISTS
	(
		SELECT
			1 
		FROM Matricula M WITH (NOLOCK)
		INNER JOIN Promocion P WITH (NOLOCK) ON P.IdPromocion = M.IdPromocion
		INNER JOIN Periodo PE WITH (NOLOCK) ON PE.IdPeriodo = P.IdPeriodo
		WHERE M.idperiodo IS NULL --Sea captacion
		AND P.IdModulo = 1 --Primer semestre
		AND M.EsMatricula = 1 --Se encuentre matriculado
		AND M.estado = 'X' --Anulado
		AND PE.IdPeriodo = @IdPeriodo --Pertencesca al mismo periodo
		AND M.IdActor = @IdActor
		AND P.IdPromocion <> @IdPromocion --Su promocion sea diferente 
	) 
	BEGIN

		IF NOT EXISTS
		(
			SELECT 1
			FROM Matricula WITH (NOLOCK)
			WHERE IdActor = @IdActor
			AND
			(
				IdPeriodo IS NOT NULL
				OR IdModulo > 1
				OR Estado NOT IN
				(
					'X',
					'N'
				)
			)
		)
		BEGIN

			SELECT TOP 1
				@FechaConsulta = ISNULL(MatriculaFecha,InscritoFecha)
			FROM Matricula WITH (NOLOCK)
			WHERE IdActor = @IdActor
			AND EsMatricula = 1
			AND Estado = 'X'
			ORDER BY
			IdMatricula DESC

		END

	END

	IF @IdTipo = 1 SET @IdTipo = 23952 --AUTOMATICO
	IF @IdTipo = 2 SET @IdTipo = 23951 --MANUAL
	IF @IdTipo = 3 SET @IdTipo = 23953 --PRONTO PAGO
	IF @IdTipo = 4 SET @IdTipo = 24957 --POR CUPON

	--OBTENEMOS EL TIPO DE TURNO POR PROMOCION GRUPIO
	SELECT TOP 1
		@IdTipoTurno = IdTipoTurno,
		@PeriodoCodigo = PE.Codigo, --@5
		@IdClasificacionProducto = PR.IdClasificacionProducto --@5
	FROM PromocionGrupo PG WITH (NOLOCK)
	INNER JOIN Turno T WITH (NOLOCK) ON PG.IdTurno = T.IdTurno
	INNER JOIN Promocion P WITH (NOLOCK) ON PG.IdPromocion = P.IdPromocion
	INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
	INNER JOIN Producto PR WITH (NOLOCK) ON P.IdProducto = PR.IdProducto
	WHERE PG.IdPromocion = @IdPromocion
	AND PG.IdGrupo = @IdGrupo

	--@9
	SELECT
		@IdPeriodo = IdPeriodo
	FROM Periodo WITH (NOLOCK) --@13
	WHERE IdSede = @IdSede
	AND Codigo = @PeriodoCodigo
	AND IdUnidadAcademica = @IdUnidadAcademica
	AND IdUnidadNegocio = @IdUnidadNegocio
	AND IdEmpresa = @IdEmpresa
	AND IdFacultad = @IdFacultad
	--@9
	select @PeriodoCodigo,@IdClasificacionProducto
	--OBTENEMOS TODOS LOS DESCUENTOS VIGENTES SEGUN FECHA Y CONFIGURACION EN DESCUENTO (sede,periodo,unidadnegocio , etc..) (DescuentoAcademicoPoblacionDestino)
	INSERT INTO @DescuentoAcademicoPoblacionDestino
	--Inicio --@13
	(
		IdDescuentoAcademico,
		IdTipoSituacionAlumno,
		Codigo,
		Nombre,
		Porcentaje,
		FechaInicio,
		FechaFin,
		NroPeriodo,
		EsAcumulativo,
		DiasVigentes,
		IdTipo,
		TipoNombre,
		CuotaNombre, --@7
		Campana,
		Area,
		TipoMatricula,
		Activo
	)
	--Fin --@13
	
	SELECT DISTINCT
		DA.IdDescuentoAcademico,
		'IdTipoSituacionAlumno' = ISNULL(DAPP.IdTipoSituacionAlumno,''),
		'Codigo' = ISNULL(DA.Codigo,-1),
		'Nombre' = ISNULL(DA.Disponible3,''), --@1 NOMBRE SOLO PARA EL SMART
		'Porcentaje' = CAST(DA.Disponible2 AS DECIMAL(7,4)), --@1 PORCENTAJE SOLO PARA EL SMART
		'FechaInicio' = CONVERT(VARCHAR(10),DA.FechaInicio ,103),
		'FechaFin' = CONVERT(VARCHAR(10),DA.FechaFin,103),
		'NroPeriodo' = ISNULL(DA.NroPeriodo,0),
		'EsAcumulativo' = ISNULL(DA.EsAcumulativo,0),
		'DiasVigentes' = ISNULL(DiasVigentes,0),
		'IdTipo' = ISNULL(DA.IdTipo,-1),
		'TipoNombre'= ISNULL(TP.Nombre,''),
		'CuotaNombre' =
		ISNULL
		(
			STUFF
			(
				( 
					SELECT 
						' / ' +
						CASE
							WHEN DAC.Cuota = 1 THEN 'MATR�CULA'
							WHEN DAC.Cuota = 2 THEN '1ra CUOTA'
							WHEN DAC.Cuota = 3 THEN '2da CUOTA'
							WHEN DAC.Cuota = 4 THEN '3ra CUOTA'
							WHEN DAC.Cuota = 5 THEN '4ta CUOTA'
							WHEN DAC.Cuota = 6 THEN '5ta CUOTA'
							WHEN DAC.Cuota = 7 THEN '6ta CUOTA'
							ELSE ''
						END + 
						CASE
							WHEN CAST(ISNULL(DAC.Codigo,-1) AS INT) > 0 THEN ' [' + CAST(DAC.Codigo AS VARCHAR) + ']' + '[' + DAC.Nombre + ']' + '[' + CAST(DAC.Porcentaje AS VARCHAR) + ']'
							ELSE ''
						END
					FROM DescuentoAcademicoCuota DAC WITH (NOLOCK)
					WHERE DAC.IdDescuentoAcademico = DA.IdDescuentoAcademico
					FOR XML PATH('')
				)
			,1,1,'')
		,'')
		,'Campana' = DA.Campana
		,'Area' = DA.Area
		,'TipoMatricula' = DA.Disponible1 
		,'Activo' = 1
	FROM DescuentoAcademicoPoblacionDestino DAP WITH (NOLOCK)
	INNER JOIN DescuentoAcademicoPoblacion DAPP WITH (NOLOCK) ON DAPP.IdDescuentoAcademico = DAP.IdDescuentoAcademico
	LEFT JOIN DescuentoAcademico DA WITH (NOLOCK) ON DA.IdDescuentoAcademico = DAP.IdDescuentoAcademico
	LEFT JOIN MaestroTablaRegistro TP WITH (NOLOCK) ON TP.IdMaestroTabla = 1904
	AND TP.IdMaestroRegistro = DA.IdTipo
	LEFT JOIN DescuentoAcademicoSede DAS WITH (NOLOCK) ON DA.IdDescuentoAcademico = DAS.IdDescuentoAcademico --@10
	WHERE DA.Activo = 1
	--AND DA.Codigo <> '-1' --@8
	AND (DA.IdTipo = @IdTipo OR ISNULL(@IdTipo,0) = 0)
	AND ISNULL(DA.EsContado,0) = @EsContado
	--AND DA.Disponible1 IN (@Disponible1,'AMBOS') 
	--AND (ISNULL(DAP.IdEmpresa,-1) = -1 OR DAP.IdEmpresa = @IdEmpresa)
	--AND (ISNULL(DAP.IdSede,-1) = -1 OR DAP.IdSede = @IdSede)
	AND DAP.IdDescuentoAcademico=6796
	--AND (ISNULL(DAP.IdFacultad ,-1) = -1 OR DAP.IdFacultad = @IdFacultad)
	--AND (ISNULL(DAP.IdUnidadNegocio,-1) = -1 OR DAP.IdUnidadNegocio = @IdUnidadNegocio)
	--AND (ISNULL(DAP.IdUnidadAcademica,-1) = -1 OR DAP.IdUnidadAcademica = @IdUnidadAcademica)
	--AND ((ISNULL(DAP.IdPeriodo,-1) = -1 OR DAP.IdPeriodo = @IdPeriodo) AND (ISNULL(DAP.PeriodoCodigo,'') = '' OR DAP.PeriodoCodigo = @PeriodoCodigo)) --@5
	--AND (ISNULL(DAP.IdClasificacionProducto,-1) = -1 OR DAP.IdClasificacionProducto = @IdClasificacionProducto) --@5
	--AND (ISNULL(DAP.IdCurricula,-1) = -1 OR DAP.IdCurricula = @IdCurricula)
	--AND (ISNULL(DAP.IdProducto,-1) = -1 OR DAP.IdProducto = @IdProducto)
	--AND (ISNULL(DAP.IdModulo,-1) = -1 OR DAP.IdModulo = @IdModulo)
	--AND (ISNULL(DAP.IdTipoTurno,-1) = -1 OR DAP.IdTipoTurno = @IdTipoTurno)
	--AND (ISNULL(DA.Disponible4,'') = '' OR DA.Disponible4 = @Disponible4) --@2
	--AND CONVERT(VARCHAR,@FechaConsulta,112) BETWEEN CONVERT(VARCHAR,DA.FechaInicio,112) AND CONVERT(VARCHAR,DA.FechaFin,112)
	--AND (ISNULL(DAS.IdSede,-1) = -1 OR DAS.IdSede = @IdPrecioSede) --@10

	--return 
	SELECT*FROM @DescuentoAcademicoPoblacionDestino
	SELECT @Min = MIN(Id), @Max = MAX(Id) FROM @DescuentoAcademicoPoblacionDestino

	WHILE @Min <= @Max
	BEGIN
	PRINT 'HOLA'
		--Inicio --@13
		SET	@IdTipoSituacionAlumno = NULL
		SET	@IdDescuentoAcademico = NULL
		SET	@Campana = NULL
		SET	@Area = NULL
		SET	@TipoMatricula = NULL
		--Fin --@13

		SELECT
			@IdTipoSituacionAlumno = IdTipoSituacionAlumno,
			@IdDescuentoAcademico = IdDescuentoAcademico,
			@Campana = Campana,
			@Area = Area,
			@TipoMatricula = TipoMatricula
		FROM @DescuentoAcademicoPoblacionDestino
		WHERE Id = @Min

		SET @IntReturn = NULL

		--@11
		IF
		(
			@CompaniaSocio = '00002600'
			OR @CompaniaSocio = '00002400' --@12
		)
		BEGIN

			SELECT 
				@CompaniaSocio = CompaniaSocioPadre
			FROM Empresa WITH (NOLOCK) --@13
			WHERE IdEmpresa = 1 --@13

		END
		--@11

		--IF @CompaniaSocio = '00002500' --@3 --@4
		--select @IdDescuentoAcademico,
		--@IdTipoSituacionAlumno,
		--@IdActor,
		--@TipoMatricula,
		--@IdPeriodo,
		--@UsuarioCreacion,
		--@IdConvenio,
		--@IdMatricula,
		--@TipoServicio
		EXEC cDescuentoAcademico_Val_PoblacionAlumno
		@IdDescuentoAcademico,
		@IdTipoSituacionAlumno,
		@IdActor,
		@TipoMatricula,
		@IdPeriodo,
		@UsuarioCreacion,
		@IdConvenio,
		@IdMatricula,
		@TipoServicio,
		@IntReturn OUTPUT,
		@CompaniaSocio

		--Si no esta dentro de la poblacion se quita
		--SELECT @IntReturn
		IF @IntReturn = 0
		BEGIN

			UPDATE @DescuentoAcademicoPoblacionDestino SET
				Activo = 0
			WHERE IdDescuentoAcademico = @IdDescuentoAcademico
			--SELECT @IdDescuentoAcademico,'@IdDescuentoAcademico'

		END

		SET @Min = @Min + 1

	END

	--SELECT '@DescuentoAcademicoPoblacionDestino',
	--	IdDescuentoAcademico,
	--	IdTipoSituacionAlumno,
	--	Codigo,
	--	Nombre,
	--	Porcentaje,
	--	FechaInicio,
	--	FechaFin,
	--	NroPeriodo,
	--	EsAcumulativo,
	--	DiasVigentes,
	--	IdTipo,
	--	TipoNombre,
	--	CuotaNombre,
	--	Campana,
	--	Area,
	--	TipoMatricula
	--FROM @DescuentoAcademicoPoblacionDestino
	--WHERE Activo = 1
	--Fin --@13

END


