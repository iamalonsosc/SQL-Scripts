﻿-----------------------------------------------------------------------------                                                                      
--Creado por      : Ren�n Galvez(06/01/2013)                                                                                      
--Funcionalidad   : Permite Generar el Proceso de Conterface                                                                  
--Utilizado por   : coIntefaseDocumento.cInterfaseDocumento_Ins_Grabar_General                                                                                      
/*                                                                      
-----------------------------------------------------------------------------                                                                      
Nro FECHA  USUARIO  DESCRIPCION                                                                      
-----------------------------------------------------------------------------                    
@01 Se modifico para considerar cursos a cargo TipoServicio='RE'                     
@02 Se agrego esto: @linea = @linea + 1 dentro del while de condicionpago='C'            
@03 Se descomento esa linea para curso a cargo          
@04 para calcular descuento desde la matricula          
@05 BGB 11-10-2016 se amplio el tama�o a 8          
@06 cambio serie CHAR 4 y adicionar B o F para facturacion electronica          
@7jmota   2018.26.06 se agrega candicion para cambiar los secuenciales a captacion           
@8jmota   2018.10.11 actualizacion por NIIF15 y precios diferenciados          
@9jmota   2018.10.27 si se matricula al contado y no tiene mat ni nor se obtiene del CON                  
@10jmota  2018.12.04 se agrega nuevo campos @Descuento por defecto = 0 en header          
@11EHUILLCA  2019.01.07 Se agrega parametros a la funci�n cCo_Precio_ObtenerTipoListaPrecio          
@12 Eloy Alva 11.01.2019 (Sigcomt) Agregar parametro CompaniaSocio.          
@13 jmota  2019.03.20 consulta para obtener precio por curso           
@14 puchuya  2019.09.10  se corrige errores para matricula por curso captacion           
@15 jmota  2019.09.16 se realiza condicion temporal para que todos los que estudiaron el 2019-IB y 2019-ID su FV sea el 2019.09.30          
@16 EHuillca 20.09.2019 Se modifica l�gica para traer precios de cursos a cargo          
@17 EHuillca 26.09.2019 Se agrega tipocliente para Header          
@18 EHuillca 01.10.2019 Se agrega validaci�n para colocar cuotas en cobrado si es colaborador.          
@19 jmota  05.05.2020 se agrega condicion para casos de producto mas curso - cobra por curso los modulos diferente a matricula (cabecera)          
@20 Hmora  28.08.2020 Se agrega PcAutomatico para Header y logica de 1 cuota Nor de FC Idat           
@21 Hmora  28.08.2020 Se agrega logica de Pago al Contado de FC Idat            
@22 jmota  2020.09.09 solo para extension idat su cuota 1 debe ser el inicio de la promocion          
@23 Hmora  2020.18.09 se modifica logica de Pago en cuota FC IDAT          
@24 Hmora  2020.20.09  se modifica logica de precio por curso IDAT tiposervicio (Curso o Producto + Curso)          
@25 Hmora  2020.18.11 se modifica logica de Pago en cuota SIDET          
@26 PUchuya  2020.26.11 se agrega variable Tiposervicio para listar cursos que no tienen curricula - programa libres          
@27 Ealva  2021.05.04 Para extensi�n se modifica la primera cuota o matricula un d�a antes del inicio de clase.          
@28 EHuillca 2021.04.22 Se agrega l�gica para SIDET (Matricula x Curso)          
@29 EHuillca 2021.04.29 Se descomenta l�nea.          
@30 PUchuya  2021.07.02 Se agrega logica multicronograma          
@31 RSamame  17.08.2021 Se agrega el NumVezCurso para que cobre los cursos de modulos menores y que son por primera vez como producto          
@32 RSamame  28.08.2021 Se Setea parametro de traslado           
@33 jmota  2021.09.20 Se agrega logica para precio de matricula por curso IDAT (tipo cliente por producto)           
@34 bgaribay 16.01.2022 parametrizar ServidorVinculado          
@35 bgaribay 21.06.2022 primera cuota zegel ca          
@36 hcachi  2022.07.14 Se setean parametros segun Compa�ia           
@37 EHuillca 2022.07.19 Se agrega validaci�n para matriculas por curso y tipo MA          
@38 Illosad  2022.12.19 Se agrega validaci�n para matriculas por curso al contado          
@39 mbueno  2023.01.11 Se agrega parametro de dias para cuotas mat en fc          
@40 mbueno  2023.01.20 Se agrega logica tiene matricula          
@41 LOrtiz  2023.01.30  Se agrega campos NombreUsuarioModificacion y FormularioProceso          
@42 JGuillen 2023.03.07  Se agrega parametro para aumentar dias a la fechavencimiento del cronograma de matriculas de zegel virtual          
@43 JCure  2023.03.10  Se agrega modificacion para que guarde otro valor distinto en Estado (Sede ITS)          
@44 LOrtiz  2023.03.14  Se agrega condicional para CDI          
@45 MBUENO  2023.05.10  Se agrega isnull para calculo de @TotalPago cuando es matricula por un curso en cuotas         
@46 FETORRES 2023.06.27 Se agrega la misma configuracion de FC IDAT de no pagar la matricula cuando el parametro @tienematricula  = 0 para ZEGEL e ITS.        
@47 SSILVA  2024.02.01  Se realizo cambio temporal para cursos de Inglés a solicitud de Jimy Contreras      
@48 FMARTINEZC 2024.01.08 Se separa logica de IDAT y Zegel para pagos de matriculas sin cuota de matricula para ITS   
@49 FMARTINEZC 2024.02.06 Se separa logica de calculo de Cuotas para Productos sin matricula de ITS  
@50 Alsanchez 2024.04.19 Se realizo cambio temporal para el ticket 57173
*/          
ALTER PROCEDURE [dbo].[cInterfaseDocumento_Ins_Grabar_General_ESE]        
@idMatricula INT ,          
@CompaniaSocio char(8) , --@12            
@parmReturn INT OUTPUT,          
@NombreUsuarioModificacion CHAR(20)=NULL, --@41          
@FormularioProceso CHAR(100) = NULL --@41                                        
AS          
BEGIN          
          
 SET @parmReturn=0           
                                   
 SET DATEFORMAT DMY                     
 SET XACT_ABORT ON          
 SET NOCOUNT ON                     
              
 -- VARIABLES          
 BEGIN          
                                                                                      
  DECLARE @TransAcction INT=1,          
  @Generado INT=0 ,          
  @GeneradoC INT=0            
                                              
  DECLARE @Descuento char(6) = '0' -- @10           
          
  --Declaromos Variables generales del sp                    
  DECLARE @Sucursal CHAR(4)          
  ,@Serie CHAR(4)   --@06                    
  ,@CodigoEstablecimiento CHAR(4)                          
  ,@ItemCodigo CHAR(20)                    
  ,@ItemCodigoCurso CHAR(20)                    
  ,@Area  CHAR(4)                        
  ,@CountCurso INT                    
  ,@CountCursoProd INT                              
  ,@IdCounter INT                        
  ,@idActorPag INT            
  ,@FlagActualizacion CHAR (1)                                   
  ,@TipoPersona CHAR(1)                        
  ,@Moneda CHAR(2)                        
  ,@lineaSP CHAR (5)                         
  ,@linea int=0                              
  ,@IdUnidadNegocio int=0            
  ,@IdModuloMatricula INT  --@19                                    
  --Recuperamos Datos Basicos de la Matricula                                  
  DECLARE @Idsede int          
  ,@idPromocion INT                     
  ,@idPromocionC INT                                                                                          
  ,@Tiposervicio CHAR(1)                      
  ,@CondicionPago CHAR(1)                     
  ,@TipoCondicion CHAR(2)                                                        
  ,@IdActorVta INT                         
  ,@idActor INT          
  ,@IdMoneda INT                                                                                          
  ,@IdPeriodo INT                                   
  ,@Campania CHAR(10)                
  ,@PeriodoFinanciero varCHAR(20)           
  ,@IdTipoCronograma INT --@30                  
  ,@NumeroCuota INT            
  ,@EsPrincipalCronograma INT = 1 --@30          
  ,@Prepago INT                                                                    
  ,@InscritoFecha DATETIME          
  ,@IdPeriodoMat int      
  ,@IdPlanPago varCHAR(10) -- PagoAdelantado          
  ,@TipoM VARCHAR(2) -- Identificador Matricula por Curso           
  --Inicio @16          
  ,@PermisoMatporCursoCaptacion BIT = 0          
  ,@PermisoMatporCursoCaptacionContado VARCHAR(20)          
  ,@IdEmpresa INT          
  ,@IdFacultad INT          
  ,@IdUnidadAcademica INT          
  --Fin @16          
  ,@TipoCliente CHAR(2) --@17          
  ,@TotalHorasC INT --@24          
  ,@MatCursoLibrexHora BIT = 0 --@24          
  ,@CondicionHoras INT          
  ,@CursoMasCondicionHoras INT --@24          
  ,@CursoMenosCondicionHoras INT --@24          
  ,@GeneraMat INT = 0          
  ,@IdEmpresaZV INT --@42          
  --Inicio Cronograma pagos                    
  DECLARE @TotalPago DECIMAL(12,2),          
  @MontoCutaIn DECIMAL(10,2),          
  @FlagCursoCargo CHAR(1),          
  @Estado CHAR(2), --@18          
  @Val INT, --@18          
  @FechaInicioPromocionGrupo datetime-- @22                
          
  -- precios          
  DECLARE           
  @MontoContadoCurso DECIMAL(10,2)=0 ,          
  @MontoContado DECIMAL(10,2)=0 ,          
  @Monto DECIMAL(10,2)=0,          
  @MontoCalculado DECIMAL(10,2)=0 ,          
  @MontoMatricula DECIMAL(10,2)=0 ,          
  @MontoOriginal DECIMAL(10,2)=0 ,          
  @MontoCuota DECIMAL(10,2)=0 ,          
  @MontoMatriculaCurso DECIMAL(10,2)=0,          
  @TotalPagoMatriculaCurso DECIMAL(10,2)=0,          
  @MontoPago money --@38          
          
  -- Creamos e Insertamos en la tabla Temporal @cronogramapago                                                                                            
  DECLARE @cronogramapago TABLE           
  (Id INT IDENTITY(1,1) NOT NULL,                                                                                                          
  CuotaNumero INT null,                                                                                                          
  FechaVencimiento DATE,                                                                                                          
  Estado CHAR(1),                    
  IdPromocion INT)             
          
  DECLARE @Ninterno INT,          
  @NumeroInterno CHAR(6),          
  @NumeroInternoINT INT,          
  @PcAutomatico CHAR(1) = 'N',   --@20                           
  @TransGratuita CHAR(1) = 'N',   --@20               
  @IdProducto INT, --@20              
  @TieneMatricula INT = 1,--@20          
  @MatCuota INT = 1, --@25            
  @diasCuotaMatriculaFC INT = -1, --@39              
  @DiasVencimientoMatZV INT = 0--@42          
              
  -- Variables                                                                                                          
  DECLARE @ultimo INT ,          
  @id INT ,          
  @ultimoC INT,          
  @idC INT,          
  @FechaVcto DATETIME,          
  @fechapreparacion DATETIME ,          
  @Condicion CHAR(3),          
  @TipoBoleta CHAR(2),          
  @Condicion2 CHAR(3),             
  @TipoDocumento INT,                        
  @Interfase_Captacion CHAR(1)='C',          
  @CantidadCuotasCronograma INT,           
  @CantidadCuotasTotalCronograma INT,          
  @TipoCondicionC CHAR(2),          
  @TipoServicioUnidadNegocio CHAR(1),  --@26            
          
  @TipoClienteFinal VARCHAR(10), --@33          
  @EsMatCursoIDAT BIT--@33          
          
  --@34 Inicio          
  DECLARE @ServidorVinculadoAcad varchar(50)          
  ,@ServidorVinculadoAcadASOC varchar(50)          
  ,@BaseDatos varchar(50)          
  ,@BaseDatosASOC varchar(50)          
            
  ,@Tsql1 nvarchar(max)          
  ,@CadSql1 nvarchar(max)          
  ,@ParamCadSql1 nvarchar(max)          
  ,@CadSql2 nvarchar(max)          
  ,@ParamCadSql2 nvarchar(max)          
  ,@CadSql3 nvarchar(max)          
  ,@ParamCadSql3 nvarchar(max)          
  ,@CadSql4 nvarchar(max)          
  ,@ParamCadSql4 nvarchar(max)          
  ,@CadSql5 nvarchar(max)          
  ,@ParamCadSql5 nvarchar(max)          
  ,@CadSql6 nvarchar(max)          
  ,@ParamCadSql6 nvarchar(max)          
  ,@CadSql7 nvarchar(max)          
  ,@ParamCadSql7 nvarchar(max)          
  ,@CadSql8 nvarchar(max)          
  ,@ParamCadSql8 nvarchar(max)        
  ,@CadSql9 nvarchar(max)          
  ,@ParamCadSql9 nvarchar(max)          
  ,@CadSql10 nvarchar(max)          
  ,@ParamCadSql10 nvarchar(max)          
  ,@SeparacionDeSpringMatriculaValor varchar(10)--@43          
  ,@SeparacionDeSpringMatriculaValor2 varchar(10)--@43          
  ,@SeparacionDeSpringMatriculaActivo bit--@43          
            
  ,@IdPrecioSede INT --@MOTA        
  ,@PrecioSedeSucursal VARCHAR(20)--@MOTA        
        
  SELECT @ServidorVinculadoAcad=Valor,@BaseDatos=valor2  FROM Parametro (NOLOCK) WHERE Nombre='ServidorVinculadoSpring'          
  SELECT @ServidorVinculadoAcadASOC=Valor,@BaseDatosASOC=valor2 FROM Parametro (NOLOCK) WHERE Nombre='ServidorVinculadoSpringASOC'          
  --@34 Fin          
          
  SELECT @SeparacionDeSpringMatriculaValor=Valor,@SeparacionDeSpringMatriculaValor2=valor2,@SeparacionDeSpringMatriculaActivo=Activo  FROM Parametro (NOLOCK) WHERE Nombre='SeparacionDeSpringMatricula'--@43          
          
  --Creamos la tabla temporal (@PromocionCursos) pra el detalle de la matricula                          
  DECLARE @PromocionCursos TABLE (          
  Id INT IDENTITY(1,1) NOT NULL,                                                               
  IdPromocion INT,                    
  TipoCondicion CHAR(2),                              
  Cantida INT,          
  ServicioCodigo VARCHAR(200) )          
            
  --Creamos tabla temporal(@CurriculaCursoHoras) para el contar las horas de cada curso          
  DECLARE @CurriculaCursoHoras TABLE (          
  Id INT IDENTITY(1,1) NOT NULL,                                                                                                          
  IdPromocion INT,          
  IdCurso INT,          
  IdModulo INT,                    
  TotalHoras INT,          
  ServicioCodigo VARCHAR(200) )                
          
  DECLARE @MIN INT, @MAX INT           
          
  DECLARE @CO_Precio TABLE           
  (TipoFacturacion VARCHAR(5),           
  Monto MONEY ,           
  ItemCodigo VARCHAR(200),          
  TipoCliente VARCHAR(10))--           
          
  DECLARE @AlumnoCurso TABLE(          
  IdMatricula INT ,           
  IdPromocion INT ,           
  IdSeccion INT,          
  IdCurso INT,          
  TipoCondicion VARCHAR(5),          
  GeneradoInterface VARCHAR(2),          
  ServicioCodigo VARCHAR(100),          
  IdModulo INT,--@19          
  Paga INT)--@31          
          
  --@31          
  DECLARE @AlumnoTraslado INT,@pIdAlumno INT,@pIdCurricula INT          
          
  DECLARE @ConvalidacionEspecial AS TABLE(          
  IdCurriculaOrigen INT,          
  IdCurriculaDestino INT           
  )          
  DECLARE @CursoMatricula AS TABLE(            
  IdCurso INT,          
  IdCurricula INT,          
  IdModulo INT)          
  --@31          
          
  DECLARE @PromocionPrecioDetalle TABLE(          
  IdPromocion INT ,           
  ItemCodigo VARCHAR(100),          
  TotalPago MONEY          
  )          
          
 END          
          
 -- SELECT PRINCIPAL DE DATOS DE MATRICULA PROMOCION           
 SELECT           
 @IdEmpresa = M.IdEmpresa           
 ,@IdFacultad = p.IdFacultad           
 ,@IdSede=P.IdSede           
 ,@IdUnidadAcademica = p.IdUnidadAcademica           
 ,@idPromocion=P.IdPromocion                         
 ,@Tiposervicio=M.TipoServicio                      
 ,@CondicionPago=CondicionPago                    
 ,@TipoCondicion=TipoCondicion                                                                                                      
 ,@IdActorVta=IdActor                           
 ,@idActor=IdActor                                        
 ,@IdMoneda=IdMoneda          
 ,@Moneda= CASE WHEN IdMoneda=236 THEN 'LO' WHEN IdMoneda=237 THEN 'EX' END                        
 ,@NumeroCuota=ISNULL(NumeroCuota,0)-- Capturamos el n�mero de cuotas de la matricula                     
 ,@InscritoFecha=InscritoFecha          
 ,@IdPeriodoMat = M.IdPeriodo          
 ,@IdPlanPago = CASE ISNULL(M.IdPlanPago,0) WHEN 1 THEN 'S' ELSE 'N' END          
 --Recuperamos IdPeriodo de la tabla promocion y Capturamos el ItemCodigo del Servicio               
 ,@IdPeriodo=P.IdPeriodo          
 ,@PeriodoFinanciero=P.PeriodoFinanciero          
 --,@ItemCodigo= CASE WHEN M.TipoServicio = 'C' THEN REPLACE(ISNULL(P.ServicioCodigo,''),'P','C') ELSE ISNULL(P.ServicioCodigo,'') END --Cuando es curso a cargo remplazamos el servicio 'C' por 'P' para traer los precios del spring            
 ,@ItemCodigo= ISNULL(P.ServicioCodigo,'')           
 ,@Area=SUBSTRING(ServicioCodigo,2,2)          
 ,@IdUnidadNegocio=P.IdUnidadNegocio           
 --Recuperamos la campa�a de la tabla periodo          
 ,@Campania=PE.Codigo          
 --Capturamos la Sucursal.          
 ,@Sucursal=SE.Sucursal          
 ,@Serie=SE.Serie          
 ,@CodigoEstablecimiento=ISNULL(SE.CodigoEstablecimiento,'')             
 ,@CompaniaSocio = e.CompaniaSocio --@12           
 ,@TipoM=M.Tipo            
 ,@IdModuloMatricula = p.IdModulo --@19         
 ,@IdProducto=P.IdProducto --@20           
 ,@FechaInicioPromocionGrupo = PG.FechaInicio -- @22            
 ,@TipoServicioUnidadNegocio = P.TipoServicio --@26           
 ,@IdTipoCronograma = ISNULL(M.IdTipoCronograma,0) --@30            
 ,@pIdAlumno=m.IdActor--@31          
 ,@pIdCurricula=m.IdCurricula --@31          
 ,@IdEmpresaZV = ISNULL(M.IdEmpresaZV,0)--@42         
 ,@IdPrecioSede = ISNULL( M.IdPrecioSede , -1)--@MOTA        
 ,@PrecioSedeSucursal =  ISNULL(s.Sucursal , '') --@MOTA        
 FROM Matricula M WITH(NOLOCK)                  
 INNER JOIN Promocion p WITH(NOLOCK) ON p.IdPromocion=m.IdPromocion           
 INNER JOIN Periodo PE WITH(NOLOCK) ON  p.IdPeriodo = PE.IdPeriodo          
 INNER JOIN Empresa E WITH(NOLOCK) ON M.IdEmpresa = E.IdEmpresa  --@12          
 INNER JOIN Sede SE WITH(NOLOCK) ON p.IdSede = SE.IdSede          
 LEFT JOIN PromocionGrupo PG WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion AND M.IdGrupo = PG.IdGrupo         
 LEFT JOIN Sede S WITH(NOLOCK) ON S.IdSede = M.IdPrecioSede--@MOTA        
 WHERE IdMatricula=@IdMatricula             
                        
 SET @Interfase_Captacion = [dbo].[cAlumnoMatriculaEsCaptacion](@IdMatricula)              
          
 --Inicio @18          
 SET @Estado = 'GE'          
 SET @Val = 0          
 If EXISTS(SELECT 1 FROM DescuentoAcademicoBase where IdMaestroRegistro = 25226 and IdSede = @Idsede AND IdFacultad = @IdFacultad AND           
 IdUnidadNegocio = @IdUnidadNegocio and IdUnidadAcademica = @IdUnidadAcademica and Activo = 1 and PeriodoCodigo = @Campania and IdActor = @idActor)          
 BEGIN          
  SET @Val = 1          
 END          
 ELSE          
 BEGIN          
  SET @Val = 0          
 END          
 --Fin @18          
          
          
 --INICIO @43          
 IF @CompaniaSocio='00002500' OR @CompaniaSocio='00002600' --@44          
 BEGIN          
  IF @SeparacionDeSpringMatriculaActivo=1          
  BEGIN          
   --si la sede es 34 ponerle it          
   IF @IdSede=@SeparacionDeSpringMatriculaValor2          
   BEGIN           
    SET @Estado = @SeparacionDeSpringMatriculaValor --jpcb          
   END          
   ELSE          
   BEGIN          
    SET @Estado = 'GE'           
   END          
  END          
  ELSE          
  BEGIN          
   SET @Estado = 'GE'           
  END           
 END          
 --FIN @43          
           
 --Inicio @31          
 INSERT INTO @CursoMatricula(IdCurricula,IdCurso,IdModulo)          
 SELECT Disponible1,Disponible2,Disponible3 FROM MaestroTablaRegistro  WITH (NOLOCK) WHERE IdMaestroTabla in (          
 SELECT IdMaestroTabla FROM MaestroTabla WHERE codigo='CurrCurModIesEest') and disponible1=@pIdCurricula and Disponible3=@IdModuloMatricula          
          
 INSERT INTO @ConvalidacionEspecial(IdCurriculaOrigen,IdCurriculaDestino)          
 SELECT Disponible1,Disponible2          
 FROM MaestroTablaRegistro MTR WITH(NOLOCK)          
 INNER JOIN MaestroTabla MT WITH(NOLOCK) ON MTR.IdMaestroTabla=MT.IdMaestroTabla          
 WHERE MT.Codigo='CurriculaConvEspTras'          
          
 SET @AlumnoTraslado =0 --@32          
 IF EXISTS(select 1 from TrasladoSede  WITH (NOLOCK) where IdAlumno=@pIdAlumno and Estado=1 and IdCurriculaNueva=@pIdCurricula           
 and Observacion='MIGRACION MASIVA DEL 2020-II AL 2021-I DE IES A EEST'          
 and IdCurriculaAnterior in (SELECT IdCurriculaOrigen FROM @ConvalidacionEspecial WHERE IdCurriculaDestino=@pIdCurricula)          
 and @CompaniaSocio = '00002500')          
 BEGIN          
  SET @AlumnoTraslado =1--@32          
 END          
 --@31 Fin          
        
 --Capturamos el counter propietario del contacto.          
 SELECT @IdCounter = ISNULL(U.IdActor,-1) FROM Contacto C WITH(NOLOCK)          
 INNER JOIN Usuario U WITH(NOLOCK) ON C.IdCounter = U.IdUsuario           
 WHERE C.IdContacto=@IdActorVta          
          
 --Inicio --@20           
 --@36          
 --IF @CompaniaSocio='00002700'          
 -- Select @TieneMatricula=TieneMatricula,@MatCuota=MatCuota from Producto where IdProducto=@IdProducto and @CompaniaSocio='00002700'           
 --ELSE IF @CompaniaSocio='00002500'          
 -- Select @TieneMatricula=TieneMatricula,@MatCuota=MatCuota from Producto where IdProducto=@IdProducto and @CompaniaSocio='00002500'          
 --ELSE          
 -- Select @TieneMatricula=TieneMatricula,@MatCuota=MatCuota from Producto where IdProducto=@IdProducto and @CompaniaSocio='00002600'          
          
 SELECT @TieneMatricula=TieneMatricula,@MatCuota=MatCuota from Producto WITH(NOLOCK) where IdProducto=@IdProducto --@40          
 --@36          
 --Fin --@20          
            
 --Inicio @24          
 SELECT @MatCursoLibrexHora = ISNULL(valor,0),@CondicionHoras = ISNULL(Valor2,0) from ParametroEmpresa WITH(NOLOCK) where Nombre='MATCURSOLIBREXHORAS'          
 --Fin    @24          
 SELECT @diasCuotaMatriculaFC = Valor, @DiasVencimientoMatZV = Valor2 from ParametroEmpresa WITH(NOLOCK) where nombre = 'DIASFECVENMAT' --@42          
          
 -- Obtenemos datos de alumnocurso          
 --Inicio @26          
 IF @TipoServicioUnidadNegocio = 'L'          
 BEGIN          
  INSERT INTO @AlumnoCurso          
  SELECT AC.IdMatricula , AC.IdPromocion, AC.IdSeccion, AC.IdCurso, AC.TipoCondicion, AC.GeneradoInterface , P.ServicioCodigo , 1 ,1--@31          
  FROM  AlumnoCurso AC WITH (NOLOCK)          
  INNER JOIN Seccion S WITH (NOLOCK) ON AC.IdSeccion = S.IdSeccion AND ISNULL(AC.IdCursoOriginal,AC.IdCurso) = S.IdCurso          
  LEFT JOIN Promocion P WITH(NOLOCK) ON AC.IdPromocion = P.IdPromocion            
  WHERE AC.IdMatricula=@idMatricula          
END          
 ELSE          
 BEGIN          
  --@31          
  IF(@AlumnoTraslado=1)          
  BEGIN          
   INSERT INTO @AlumnoCurso          
   SELECT AC.IdMatricula , AC.IdPromocion, AC.IdSeccion, AC.IdCurso, AC.TipoCondicion, AC.GeneradoInterface , P.ServicioCodigo , CC.IdModulo, --@19          
   1--@31          
   FROM  AlumnoCurso AC WITH (NOLOCK)          
   INNER JOIN CurriculaCurso CC WITH (NOLOCK) ON ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) = CC.IdCurricula  AND ISNULL(AC.IdCursoOriginal,AC.IdCurso) = CC.IdCurso          
   LEFT JOIN Promocion P WITH(NOLOCK) ON AC.IdPromocion = P.IdPromocion               
   WHERE AC.IdMatricula=@idMatricula          
          
   UPDATE AC           
   SET AC.Paga=0          
   FROM  @AlumnoCurso AC           
   INNER JOIN PROMOCION P WITH(NOLOCK) ON AC.IdPromocion = P.IdPromocion            
   INNER JOIN @CursoMatricula CM ON CM.IdCurricula=P.IdCurricula AND AC.IdCurso = CM.IdCurso           
          
  END          
  ELSE          
  BEGIN          
   INSERT INTO @AlumnoCurso          
   SELECT AC.IdMatricula , AC.IdPromocion, AC.IdSeccion, AC.IdCurso, AC.TipoCondicion, AC.GeneradoInterface , P.ServicioCodigo , CC.IdModulo,1 --@19--@31          
   FROM  AlumnoCurso AC WITH (NOLOCK)          
   INNER JOIN CurriculaCurso CC WITH (NOLOCK) ON ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) = CC.IdCurricula  AND ISNULL(AC.IdCursoOriginal,AC.IdCurso) = CC.IdCurso          
   LEFT JOIN Promocion P WITH(NOLOCK) ON AC.IdPromocion = P.IdPromocion            
   WHERE AC.IdMatricula=@idMatricula          
  END          
 END          
 --Fin @26          
          
 PRINT 'TipoCondicion matricula : ' + CAST( @TipoCondicion AS VARCHAR)           
          
 --Inicio @16          
 -- VALIDAMOS SI TIENE PERMISOS PARA MATRICULAR POR CURSO CAPTACION           
 SELECT  @PermisoMatporCursoCaptacion = CASE WHEN Valor = '' THEN 0 ELSE ISNULL(Valor,0) END ,          
 @PermisoMatporCursoCaptacionContado = ISNULL(Valor2,'')  --  el valor 2 indica que           
 FROM ParametroUnidadAcademica WITH(NOLOCK)           
 WHERE IdEmpresa = @IdEmpresa           
 AND IdSede = @Idsede            
 AND IdUnidadNegocio = @IdUnidadNegocio           
 AND IdUnidadAcademica = @IdUnidadAcademica          
 AND Nombre = 'MatriculaCursoPorCaptacion'          
 --Fin @16          
              
    --inicio @30          
    SET @EsPrincipalCronograma = 1          
    IF @IdTipoCronograma = -1 SET @IdTipoCronograma = 0          
    SELECT @EsPrincipalCronograma = CAST(Disponible1 AS INT) FROM MaestroTablaRegistro WITH(NOLOCK) WHERE IdMaestroRegistro = @IdTipoCronograma          
    IF @IdTipoCronograma = 0 SET @EsPrincipalCronograma = 1          
    --fin @30          
          
 -- CANTIDAD DE CURSOS INSCRITOS          
 -- SI ES INVICTO EL ALUMNO NO INPORTA SI LA SECCION NO ESTE LLENO PARA CONTAR EL NUMERO DE CURSOS                     
 IF  @TipoCondicion='RE'           
 BEGIN           
  SELECT @CountCurso=COUNT(1)           
  FROM  @AlumnoCurso          
  WHERE IdMatricula=@idMatricula                     
  AND IdPromocion IS NOT NULL                                       
 END              
 ELSE                    
 BEGIN           
  --@14           
  IF @TipoCondicion='CC' and @TipoM='MA' and ISNULL(@PermisoMatporCursoCaptacion,0) = 1 AND @IdPeriodoMat IS NULL  --@14 --@37          
  BEGIN          
   SELECT @CountCurso=COUNT(1) from @AlumnoCurso           
   WHERE IdMatricula=@idMatricula                     
   AND IdPromocion IS NOT NULL                 
   AND IdPromocion=@idPromocion           
  END          
  ELSE          
  BEGIN              
   SELECT @CountCurso=COUNT(1)           
   FROM  @AlumnoCurso          
   WHERE IdMatricula=@idMatricula                     
   AND IdPromocion IS NOT NULL AND IdSeccion IS NOT NULL                  
   AND IdPromocion=@idPromocion                      
  END           
  --@14                     
 END                                                                                                                   
          
    PRINT 'CANTIDAD DE CURSOS : ' + CAST( @CountCurso AS VARCHAR)           
          
    -- insertamos los itemcodigos dependiendo de las promociones en alumno curso           
    DECLARE @TB_ItemCodigo TABLE(ItemCodigo VARCHAR(100))          
    INSERT INTO @TB_ItemCodigo          
    SELECT ServicioCodigo FROM @AlumnoCurso          
                        
    -- insertamos tambien los itemcodigo de alumnocurso pero en CC curso a cargo           
    INSERT INTO @TB_ItemCodigo          
    SELECT REPLACE(ServicioCodigo,'P','C') FROM @AlumnoCurso          
          
    -- insertamos el itemcodigo de la promocion de la matricula           
    INSERT INTO @TB_ItemCodigo VALUES (@ItemCodigo)          
    -- insertamos el itemcodigo de la promocion de la matricula CC curso a cargo            
    INSERT INTO @TB_ItemCodigo VALUES (REPLACE(@ItemCodigo,'P','C') )          
          
    -- Obtenemos el tipo de lista de precio que le corresponde al alumno          
    DECLARE @TipoListaPrecio VARCHAR(3)          
          
    SET @TipoListaPrecio = dbo.cCo_Precio_ObtenerTipoListaPrecio(@idMatricula,NULL,NULL,@CompaniaSocio)            
          
 PRINT 'TIPO LISTA PRECIO : ' + CAST( @TipoListaPrecio AS VARCHAR)           
          
 --@33          
 SET @EsMatCursoIDAT = 0          
 IF @Tiposervicio = 'C' AND  @CompaniaSocio = '00002700'          
 BEGIN          
  SET @EsMatCursoIDAT = 1           
 END           
          
          
  -- Obtenemos datos del precio          
  SET @TipoCliente = (CASE WHEN CHARINDEX('C',@ItemCodigo,0)> 0 AND ISNULL(@PermisoMatporCursoCaptacion,0) = 0 THEN '01'           
     WHEN @EsMatCursoIDAT = 1 THEN '01'  ELSE  @TipoListaPrecio END)--@17 @33          
          
 INSERT INTO @CO_Precio          
 SELECT TipoFacturacion , ISNULL(Monto,0.0) , ItemCodigo , TipoCliente           
 --FROM  PLDB01.SpringUnido.dbo.CO_Precio WITH(NOLOCK)          
 FROM vw_CO_Precio WITH(NOLOCK)           
 WHERE ItemCodigo IN (SELECT ItemCodigo FROM @TB_ItemCodigo)                               
 AND UnidadNegocio= CASE WHEN @PrecioSedeSucursal = '' THEN  @Sucursal  ELSE  @PrecioSedeSucursal END --@MOTA        
 --AND TipoCliente = @TipoCliente --@17          
 AND CompaniaSocio=@CompaniaSocio --@12          
          
 PRINT 'ITEM CODIGO TABLA MATRICULA : ' + CAST( @ItemCodigo AS VARCHAR)           
                        
 -- Contado de la promocion en la cabecera matricula                                     
 SELECT  @MontoContado=Monto,@Monto=Monto           
 FROM @CO_Precio                 
 WHERE TipoFacturacion='CON'                                                                
 AND ItemCodigo = @ItemCodigo          
 AND TipoCliente = @TipoCliente --@17          
          
 -- Matricula de la promocion en la cabecera matricula          
 SELECT @MontoMatricula=Monto           
 FROM @CO_Precio                
 WHERE TipoFacturacion='MAT'          
 AND ItemCodigo = @ItemCodigo          
 AND TipoCliente = CASE WHEN @EsMatCursoIDAT = 1 THEN  @TipoListaPrecio ELSE  @TipoCliente  END  --@17  @33          
            
 -- Cuotas de la promocion en la cabecera matricula          
 SELECT @MontoCuota=Monto           
 FROM @CO_Precio                  
 WHERE TipoFacturacion='NOR'           
 AND ItemCodigo = @ItemCodigo          
 AND TipoCliente = @TipoCliente --@17          
          
 PRINT 'CONTADO : ' + CAST( @MontoContado AS VARCHAR)          
 PRINT 'MAT : ' + CAST( @MontoMatricula AS VARCHAR)          
 PRINT 'NOT : ' + CAST( @MontoCuota AS VARCHAR)          
          
 -- AGREGAMOS EL CRONOGRAMA DE PAGOS EN TEMPORAL           
 IF @EsPrincipalCronograma = 0 --@30          
 BEGIN          
  INSERT INTO @cronogramapago(IdPromocion , CuotaNumero,FechaVencimiento,Estado)           
  SELECT idPromocion , CuotaNumero, CASE           
   WHEN CuotaNumero = 1 AND @IdUnidadNegocio = 2 AND @CompaniaSocio='00002700' THEN  dateadd(day,@diasCuotaMatriculaFC,@FechaInicioPromocionGrupo)  --@39          
   WHEN CuotaNumero = 2 AND @TieneMatricula = 1 AND @IdUnidadNegocio = 2 And @CompaniaSocio='00002700' THEN  @FechaInicioPromocionGrupo  --@39 --@40          
   WHEN @IdEmpresaZV > 0 AND @CompaniaSocio='00002500' THEN  dateadd(day,@DiasVencimientoMatZV,CONVERT(date, GETDATE()))  --@42          
   ELSE  FechaVencimiento  END ,Estado          
  FROM  dbo.CronogramaPagoAlterna WITH(NOLOCK)                  
  WHERE IdPromocion =@idPromocion AND IdTipoCronograma = @IdTipoCronograma          
 END          
 ELSE          
 BEGIN          
  INSERT INTO @cronogramapago(IdPromocion , CuotaNumero,FechaVencimiento,Estado)           
  SELECT CP.idPromocion , CP.CuotaNumero, CASE           
   WHEN CuotaNumero = 1 AND @IdUnidadNegocio = 2 And @CompaniaSocio='00002700' and pro.IdProducto != 13405 THEN  dateadd(day,@diasCuotaMatriculaFC,@FechaInicioPromocionGrupo)  --@39  --@47     @50 
   WHEN CuotaNumero = 2 AND @TieneMatricula = 1 AND @IdUnidadNegocio = 2 And @CompaniaSocio='00002700' and pro.IdProducto != 13405 THEN   @FechaInicioPromocionGrupo --@39 --@40  --@47         @50
   WHEN @IdEmpresaZV > 0 AND @CompaniaSocio='00002500' THEN  dateadd(day,@DiasVencimientoMatZV,CONVERT(date, GETDATE()))  --@42          
   ELSE  FechaVencimiento  END ,CP.Estado   -- @22  --@27               
  FROM dbo.CronogramaPago CP WITH(NOLOCK) 
  INNER JOIN Promocion PRO WITH(NOLOCK) ON CP.IdPromocion= PRO.IdPromocion
  WHERE CP.IdPromocion =@idPromocion          
 END          
          
 SELECT @CantidadCuotasCronograma = COUNT(1) - 1, -- cuotas no matricula            
 @CantidadCuotasTotalCronograma = COUNT(1) -- incluye matricula y cuotas          
 FROM @cronogramapago          
          
 -- OBTENEMOS EL ACTOR PAGANTE          
 SELECT TOP 1           
 @idActorPag= CASE WHEN @idActor = af.IdActor THEN NULL  ELSE af.IdActor END, --SI EL PAGANTES ES EL MISMO ALUMNO ENTONCES PAGANTE NULL           
 @TipoDocumento=af.IdTipoDocumento          
 FROM  ActorFacturacion af WITH(NOLOCK)                  
 WHERE af.IdMatricula =@idMatricula                                                      
          
 SET @TipoBoleta=''                                           
 SET @linea=0                                   
              
 --  OBTENEMOS TIPO DE DOCUMENTO          
 SELECT @TipoDocumento=IdTipoDocumento FROM  ActorFacturacion  WITH(NOLOCK)                  
 WHERE IdActor=ISNULL(@idActorPag,@idActor) AND IdMatricula=@idMatricula                                                                  
              
 -- INF: indica que no incluye igv           
 SET @TipoBoleta= CASE WHEN @TipoDocumento=1 THEN 'FC' WHEN @TipoDocumento=2 THEN 'BV' ELSE 'BV' END                                               
 SET @fechapreparacion=GETDATE()                                            
 SET @Condicion='INF'   --- @06 FACTURACION ELECTRONICA          
                               
 SET @serie = CASE WHEN @TipoBoleta='FC' THEN 'F' + @serie ELSE 'B' + @serie END           
          
 --VALIDACIONES                    
 EXEC cInterfaseDocumento_Validacion_General @IdMatricula,@CompaniaSocio , @parmReturn output                     
          
 IF  @parmReturn >0                     
 BEGIN                    
  SET @TransAcction=0  -- FINALIZA TRANSACCION                   
  RETURN                    
 END                     
                     
 --Validamos si la matricula ya tiene su interface y guardamos el valor uno en la variable @Generado                    
 IF EXISTS( SELECT IdPromocion FROM  @AlumnoCurso WHERE IdMatricula=@idMatricula AND IdPromocion=@idPromocion AND GeneradoInterface='S')                    
 BEGIN                    
  SET @Generado=1                    
 END                                   
           
    --si la validaciones son correctas @TransAcction=1 entonces seguimos con el proceso                    
    IF  @TransAcction=1                                           
  BEGIN          
  ---------------------------------------------- PAGO AL CONTADO ----------------------------------------------                                        
  IF @CondicionPago='C'           
  BEGIN          
                                                  
     SET @Condicion2='CON'          
             
     SELECT @FechaVcto = MIN(FechaVencimiento)                     
     FROM  @cronogramapago                    
             
   -- TIPO DE SERVICIO POR PRODUCTO PRECIO MAT + (NOR * CUOTAS_CRONOGRAMA)          
   IF  (@Tiposervicio='P' OR @Tiposervicio='M') AND @Generado=0                    
   BEGIN           
          
    -- insertamos la cabecera de la en la tabla coInterfaseDocumento                    
    SET @TipoCondicion  = CASE WHEN @TipoCondicion='CC' THEN 'S' ELSE 'N' END                                          
    SET @FlagCursoCargo = CASE WHEN @TipoCondicion='CC' THEN 'S' ELSE 'N' END                   
              
    -- @33 para obtener el tipo cliente que corresponde           
    SET @TipoClienteFinal = NULL           
    SET @TipoClienteFinal = CASE WHEN @EsMatCursoIDAT = 1 AND @Condicion2 = 'MAT' THEN  @TipoListaPrecio ELSE  @TipoCliente  END          
          
    SET @CadSql1 = N' '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.usp_Interfase_P09_Header_Insert           
    @TipoBoleta, @FechaVcto, @condicion, @condicion2, @CodigoEstablecimiento,@IdActorVta,           
    @idActorPag,@PeriodoFinanciero, @Moneda, @Sucursal,@IdCounter,@fechapreparacion,          
    @Estado,''N'',NULL,@Descuento,@idMatricula,@Serie,NULL,1,NULL,NULL,@Campania,@IdPeriodo,           
    @Area,NULL,@FlagCursoCargo,@Tiposervicio,@CondicionPago,NULL,NULL,NULL,           
    NULL,NULL,@Interfase_Captacion,@IdPlanPago,@CompaniaSocio,@TipoCliente,@TransGratuita,@PcAutomatico,@NumeroInternoINT OUTPUT'          
          
    SET @ParamCadSql1 = N'@TipoBoleta CHAR(2), @FechaVcto DATETIME, @condicion CHAR(3),           
    @condicion2 CHAR(3), @CodigoEstablecimiento CHAR(4),@IdActorVta INT,           
    @idActorPag INT,@PeriodoFinanciero varCHAR(20), @Moneda CHAR(2),           
    @Sucursal CHAR(4),@IdCounter INT,@fechapreparacion DATETIME,          
    @Estado CHAR(2),@Descuento char(6),@idMatricula INT,@Serie CHAR(4),          
    @Campania CHAR(10),@IdPeriodo INT, @Area CHAR(4),          
    @FlagCursoCargo CHAR(1),@Tiposervicio CHAR(1),@CondicionPago CHAR(1),          
    @Interfase_Captacion CHAR(1),@IdPlanPago varCHAR(10),@CompaniaSocio char(8),          
    @TipoCliente CHAR(2),@TransGratuita CHAR(1),@PcAutomatico CHAR(1),@NumeroInternoINT INT OUTPUT'          
          
    EXEC sp_executesql @CadSql1, @ParamCadSql1, @TipoBoleta=@TipoBoleta, @FechaVcto=@FechaVcto, @condicion=@condicion,           
    @condicion2=@condicion2, @CodigoEstablecimiento=@CodigoEstablecimiento,@IdActorVta=@IdActorVta,           
    @idActorPag=@idActorPag,@PeriodoFinanciero=@PeriodoFinanciero, @Moneda=@Moneda,           
    @Sucursal=@Sucursal,@IdCounter=@IdCounter,@fechapreparacion=@fechapreparacion,          
    @Estado=@Estado,@Descuento=@Descuento,@idMatricula=@idMatricula,@Serie=@Serie,          
    @Campania=@Campania,@IdPeriodo=@IdPeriodo, @Area=@Area,          
    @FlagCursoCargo=@FlagCursoCargo,@Tiposervicio=@Tiposervicio,@CondicionPago=@CondicionPago,          
    @Interfase_Captacion=@Interfase_Captacion,@IdPlanPago=@IdPlanPago,@CompaniaSocio=@CompaniaSocio,          
    @TipoCliente=@TipoCliente,@TransGratuita=@TransGratuita,@PcAutomatico=@PcAutomatico,@NumeroInternoINT=@NumeroInternoINT OUTPUT;          
          
    --Capturamos el ultimo codigo generado de la tabla coInterfaseDocumento                                                                                                     
    SET @NumeroInternoInt=@NumeroInternoINT                       
          
    --@Inicio 21 Se agrega Logica de precio FC IDAT          
 --@46 Se agrega companiasocio de ZEGEL        
    IF (@CompaniaSocio='00002700'  AND @IdUnidadNegocio<>1 AND @TieneMatricula=0 )        
 OR  (@CompaniaSocio='00002500'  AND @TieneMatricula=0)              
    BEGIN             
    -- MONTO DE MATRICULA SERA IGUAL QUE EL MONTO DE LAS CUOTAS DE LA PROMOCION          
     SET @MontoMatricula = @MontoCuota                   
    END          
    --@Fin 21            
    SET @MontoPago=( ISNULL(@MontoCuota,0) * ISNULL(@CantidadCuotasCronograma,0) )          
          
    IF @MontoPago > 0 and @MontoMatricula > 0 --@38          
    BEGIN          
     SET @TotalPago = ISNULL(@MontoMatricula,0) + ( ISNULL(@MontoCuota,0) * ISNULL(@CantidadCuotasCronograma,0) )          
    END          
    ELSE          
    BEGIN          
     --@9 si el monto es 0 indica que no tiene MAT ni NOR           
     PRINT 'No obtiene MAT ni NOR. se obtene precio de CON'           
     SET @TotalPago = ISNULL(@MontoContado,0)          
    END          
                                                    
    PRINT 'TOTAL CONTADO:' + CAST(@TotalPago AS VARCHAR)          
    --@9 FIN          
          
    SET @lineaSP = RIGHT(('00000' + CAST(@linea AS VARCHAR)),5)                    
    
    SET @CadSql2 = N'INSERT INTO '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.CO_Interfase_P09_Detalle           
    (TipoDocumento,NumeroInterno,secuencia,tipodetalle,itemcodigo,cantidadpedida,descripcion,estado,Monto,          
    MontoOriginal,CantidadOriginal,CompaniaSocio,          
    UltimoUsuario,UltimaFechaModificacion,FormularioModificacion)           
    VALUES( @TipoBoleta,@NumeroInternoINT, @lineaSP,''S'',@ItemCodigo,1,'''',@Estado,ROUND(@TotalPago,0),          
    @TotalPago,@CountCurso,@CompaniaSocio,@NombreUsuarioModificacion,GETDATE(),@FormularioProceso)' --@41          
          
    SET @ParamCadSql2 = N'@TipoBoleta CHAR(2), @NumeroInternoINT INT, @lineaSP CHAR (5),          
    @ItemCodigo CHAR(20), @Estado CHAR(2), @TotalPago DECIMAL(12,2), @CountCurso INT, @CompaniaSocio char(8),          
    @NombreUsuarioModificacion CHAR(20),@FormularioProceso CHAR(100)' --@41          
          
    EXEC sp_executesql @CadSql2, @ParamCadSql2, @TipoBoleta=@TipoBoleta,@NumeroInternoINT=@NumeroInternoINT,           
    @lineaSP=@lineaSP,@ItemCodigo=@ItemCodigo,@Estado=@Estado,@TotalPago=@TotalPago,          
    @CountCurso=@CountCurso,@CompaniaSocio=@CompaniaSocio,          
    @NombreUsuarioModificacion=@NombreUsuarioModificacion,@FormularioProceso=@FormularioProceso; --@41          
          
          
              
    --Actualisamos el campo GeneradoInterface='S' para saber que ya se genero su interface con esa promocion y esa matricula                    
    UPDATE AlumnoCurso SET           
    GeneradoInterface='S'                     
    WHERE IdMatricula=@idMatricula         
    AND IdPromocion=@idPromocion          
                                              
    SET @Generado=1            
                            
   END                    
                                                       
   /*Generamos las interface de la promociones que son diferentes a la promocion que esta guardado en la matricula                    
   y ademas de TipoCondicion(CC,RP) Y que su interface aun no se aya Generado (GeneradoInterface in null)                    
   */                     
   IF  (@Tiposervicio='M' OR @Tiposervicio='C')                  
   BEGIN          
                                                             
    DELETE FROM  @PromocionCursos                     
    --Si tipo de servicio es 'C' entonces considerar CC Y RE de alumnocurso                          
    IF  @Tiposervicio='C'                    
    BEGIN           
     --@14 Condicion para Curso por diplomado          
     --Codigo agregado          
     IF @TipoCondicion='CC' and @TipoM='MA' and ISNULL(@PermisoMatporCursoCaptacion,0) = 1 AND @IdPeriodoMat IS NULL  --@14 --@37          
     BEGIN          
      INSERT INTO @PromocionCursos(IdPromocion,TipoCondicion,Cantida,ServicioCodigo)                    
      SELECT IdPromocion,TipoCondicion,Count(*),ServicioCodigo                     
      FROM @AlumnoCurso                               
      WHERE IdMatricula =@idMatricula                                    
      AND (TipoCondicion='CC' OR TipoCondicion='RE')                     
      AND GeneradoInterface IS NULL           
      GROUP BY IdPromocion ,TipoCondicion,ServicioCodigo           
          
     END          
     ELSE          
     --Codigo Original          
     BEGIN          
      INSERT INTO @PromocionCursos(IdPromocion,TipoCondicion,Cantida, ServicioCodigo)                    
      SELECT IdPromocion,TipoCondicion,COUNT(1) , ServicioCodigo                    
      FROM  @AlumnoCurso                            
      WHERE IdMatricula =@idMatricula                     
          AND (IdSeccion<>0 AND IdSeccion IS Not NULL)                     
          AND (TipoCondicion='CC' OR TipoCondicion='RE')                     
          AND GeneradoInterface IS NULL          
      GROUP BY IdPromocion ,TipoCondicion,ServicioCodigo            
     END                
    END                    
    --Si Tipo de Servicio es m entonces considerar solo CC de alumnocurso : los RE se cobra por producto                    
    IF  @Tiposervicio='M'                    
    BEGIN           
     INSERT INTO @PromocionCursos(IdPromocion,TipoCondicion,Cantida , ServicioCodigo)                         
     SELECT IdPromocion,TipoCondicion,COUNT(1) , ServicioCodigo           
     FROM @AlumnoCurso           
     WHERE IdMatricula =@idMatricula                     
         AND (IdSeccion<>0 AND IdSeccion IS Not NULL)                     
         AND (TipoCondicion='CC')                     
         AND GeneradoInterface IS NULL          
         AND IdModulo <> @IdModuloMatricula --@19 solo consutamos a los cursos que sean diferente a su modulo de cabecera para cobrarle por curso           
         AND (Paga=1) --@31          
     GROUP BY IdPromocion ,TipoCondicion ,ServicioCodigo                   
    END                                    
          
    SELECT @MIN = MIN(Id) , @MAX = MAX(Id) FROM  @PromocionCursos          
          
    --recorremos las promociones del detalle de la matricula.                    
    WHILE  @MIN <= @MAX                                                                          
    BEGIN          
     -- SI EL DOCUMENTO YA EXISTE SOLO SE AGREGA DETALLE NO CABECERA          
     IF @Generado=0                     
     BEGIN           
      SET @FlagCursoCargo = CASE WHEN @TipoCondicion='CC' THEN 'S' ELSE 'N' END                   
          
      -- @33 para obtener el tipo cliente que corresponde           
      SET @TipoClienteFinal = NULL           
      SET @TipoClienteFinal = CASE WHEN @EsMatCursoIDAT = 1 AND @Condicion2 = 'MAT' THEN  @TipoListaPrecio ELSE  @TipoCliente  END          
          
   SET @CadSql3 = N' '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.usp_Interfase_P09_Header_Insert           
    @TipoBoleta, @FechaVcto, @condicion, @condicion2, @CodigoEstablecimiento,@IdActorVta,           
    @idActorPag,@PeriodoFinanciero, @Moneda, @Sucursal,@IdCounter,@fechapreparacion,          
    @Estado,''N'',NULL,@Descuento,@idMatricula,@Serie,NULL,1,NULL,NULL,@Campania,@IdPeriodo,           
    @Area,NULL,@FlagCursoCargo,@Tiposervicio,@CondicionPago,NULL,NULL,NULL,           
    NULL,NULL,@Interfase_Captacion,@IdPlanPago,@CompaniaSocio,@TipoCliente,@TransGratuita,@PcAutomatico,@NumeroInternoINT OUTPUT'          
          
    SET @ParamCadSql3 = N'@TipoBoleta CHAR(2), @FechaVcto DATETIME, @condicion CHAR(3),           
    @condicion2 CHAR(3), @CodigoEstablecimiento CHAR(4),@IdActorVta INT,           
    @idActorPag INT,@PeriodoFinanciero varCHAR(20), @Moneda CHAR(2),           
    @Sucursal CHAR(4),@IdCounter INT,@fechapreparacion DATETIME,          
    @Estado CHAR(2),@Descuento char(6),@idMatricula INT,@Serie CHAR(4),          
    @Campania CHAR(10),@IdPeriodo INT, @Area CHAR(4),          
    @FlagCursoCargo CHAR(1),@Tiposervicio CHAR(1),@CondicionPago CHAR(1),          
    @Interfase_Captacion CHAR(1),@IdPlanPago varCHAR(10),@CompaniaSocio char(8),          
    @TipoCliente CHAR(2),@TransGratuita CHAR(1),@PcAutomatico CHAR(1),@NumeroInternoINT INT OUTPUT'          
          
    EXEC sp_executesql @CadSql3, @ParamCadSql3, @TipoBoleta=@TipoBoleta, @FechaVcto=@FechaVcto, @condicion=@condicion,           
    @condicion2=@condicion2, @CodigoEstablecimiento=@CodigoEstablecimiento,@IdActorVta=@IdActorVta,           
    @idActorPag=@idActorPag,@PeriodoFinanciero=@PeriodoFinanciero, @Moneda=@Moneda,           
    @Sucursal=@Sucursal,@IdCounter=@IdCounter,@fechapreparacion=@fechapreparacion,          
    @Estado=@Estado,@Descuento=@Descuento,@idMatricula=@idMatricula,@Serie=@Serie,          
    @Campania=@Campania,@IdPeriodo=@IdPeriodo, @Area=@Area,          
    @FlagCursoCargo=@FlagCursoCargo,@Tiposervicio=@Tiposervicio,@CondicionPago=@CondicionPago,          
    @Interfase_Captacion=@Interfase_Captacion,@IdPlanPago=@IdPlanPago,@CompaniaSocio=@CompaniaSocio,          
    @TipoCliente=@TipoCliente,@TransGratuita=@TransGratuita,@PcAutomatico=@PcAutomatico,@NumeroInternoINT=@NumeroInternoINT OUTPUT;          
          
          
          
     END                    
                          
     SELECT @idPromocionC=idPromocion,@TipoCondicionC=TipoCondicion,@CountCurso=Cantida ,  @ItemCodigoCurso=ServicioCodigo             
     FROM  @PromocionCursos WHERE id = @MIN          
               
     --Inicio @24          
     DELETE FROM  @CurriculaCursoHoras          
               
     INSERT INTO @CurriculaCursoHoras(IdPromocion,IdCurso,IdModulo,TotalHoras , ServicioCodigo)            
     SELECT ac.IdPromocion,ac.IdCurso,CC.IdModulo,ISNULL(cc.CursoPractica,0) + ISNULL(cc.CursoTeoria,0), replace(p.ServicioCodigo, 'P', 'C')          
     FROM @AlumnoCurso ac              
     INNER JOIN Promocion p                  
     ON p.IdPromocion = ac.IdPromocion            
     INNER JOIN CurriculaCurso cc              
     ON cc.IdCurricula=p.IdCurricula and cc.IdCurso=ac.IdCurso             
     WHERE ac.IdMatricula = @IdMatricula              
     AND ac.IdPromocion = @idPromocionC            
     AND (IdSeccion<>0 AND IdSeccion is not null)                       
     AND (TipoCondicion='CC' or TipoCondicion='RE')                       
     AND GeneradoInterface is null           
               
             
     Update @CurriculaCursoHoras Set TotalHoras=3 where TotalHoras=0          
               
     --Fin @24               
          
     SET @FlagCursoCargo='N'             
     SET @ItemCodigoCurso=REPLACE(@ItemCodigoCurso,'P','C')           
                                   
     SELECT @MontoContadoCurso=Monto          
     FROM @CO_Precio                 
     WHERE TipoFacturacion='CON'                                                                
     AND ItemCodigo = @ItemCodigoCurso          
     AND tipocliente = (CASE WHEN CHARINDEX('C',@ItemCodigoCurso,0)> 0 AND ISNULL(@PermisoMatporCursoCaptacion,0) = 0 THEN '01' ELSE  @TipoListaPrecio END)--@17          
               
     SET @TotalPago= 0                    
          
     --Inicio @24          
     IF @MatCursoLibrexHora = 1 AND @IdUnidadNegocio = 1          
     BEGIN          
                
      Select @CursoMasCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras > @CondicionHoras          
      Select @CursoMenosCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras <= @CondicionHoras          
          
      IF @GeneraMat = 0 AND @Tiposervicio = 'C'  --Se carga por unica vez el monto de matricula al primer detalle cuando se matricula por Curso               
      BEGIN          
       SET @TotalPago = @MontoMatricula +  (@MontoContadoCurso * @CursoMasCondicionHoras) + (@MontoContadoCurso * @CursoMenosCondicionHoras)/2                       
      END          
      ELSE          
      BEGIN          
       SET @TotalPago = @TotalPago +  (@MontoContadoCurso * @CursoMasCondicionHoras) + (@MontoContadoCurso * @CursoMenosCondicionHoras)/2           
      END          
                
     END          
     ELSE          
     BEGIN                  
                
      SET @TotalPago = ISNULL((@MontoContadoCurso * ( CASE WHEN ISNULL(@PermisoMatporCursoCaptacion,0) = 1  and           
                      ISNULL(@PermisoMatporCursoCaptacionContado,'') = @TipoListaPrecio            
                    THEN  1 ELSE @CountCurso END) ),0) -- Para C.A solo debe obtener monto al contado no multiplicarlo por los cursos          
     END          
     --Fin @24                         
     SET @linea = @linea + 1  --@2                                                                         
     SET @lineaSP = RIGHT(('00000' + CAST(@linea AS VARCHAR)),5)          
          
     SET @CadSql4 = N'INSERT INTO '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.CO_Interfase_P09_Detalle           
     (TipoDocumento,NumeroInterno,secuencia,tipodetalle,itemcodigo,cantidadpedida,descripcion,estado,Monto,          
     MontoOriginal,CantidadOriginal,CompaniaSocio,          
     UltimoUsuario,UltimaFechaModificacion,FormularioModificacion)          
     VALUES( @TipoBoleta,@NumeroInternoINT, @lineaSP,''S'',@ItemCodigo,1,'''',@Estado,ROUND(@TotalPago,0),       @TotalPago,@CountCurso,@CompaniaSocio,          
     @NombreUsuarioModificacion,GETDATE(),@FormularioProceso)' --@41          
          
     SET @ParamCadSql4 = N'@TipoBoleta CHAR(2), @NumeroInternoINT INT, @lineaSP CHAR (5),          
     @ItemCodigo CHAR(20), @Estado CHAR(2), @TotalPago DECIMAL(12,2), @CountCurso INT, @CompaniaSocio char(8),          
     @NombreUsuarioModificacion CHAR(20),@FormularioProceso CHAR(100)' --@41          
               
     EXEC sp_executesql @CadSql4, @ParamCadSql4, @TipoBoleta=@TipoBoleta,@NumeroInternoINT=@NumeroInternoINT,           
     @lineaSP=@lineaSP,@ItemCodigo=@ItemCodigo,@Estado=@Estado,@TotalPago=@TotalPago,          
     @CountCurso=@CountCurso,@CompaniaSocio=@CompaniaSocio,          
     @NombreUsuarioModificacion=@NombreUsuarioModificacion,@FormularioProceso=@FormularioProceso; --@41          
          
                                                     
     --Actualisamos el campo GeneradoInterface='S' para saber que ya se genero su interface con esa promocion y esa matricula                    
     UPDATE  AlumnoCurso                     
     SET GeneradoInterface='S'                    
     WHERE IdMatricula =@idMatricula                     
     AND IdPromocion=@idPromocionC                     
     AND (IdSeccion<>0 AND IdSeccion IS Not NULL)                     
     AND (TipoCondicion='CC' OR TipoCondicion='RE')                              
              
     SET @Generado=1   -- SOLO UNA CABECERA          
          
     SET @GeneraMat = 1 -- SOLO UN CARGO POR MATRICULA          
                                                
     SET @MIN = @MIN + 1           
    END                    
   --Fin                     
   END             
                                                                                             
  END                      
  --------------------------------------------- PAGO AL CONTADO ----------------------------------------------               
                    
  /* Validamos la diferencia en dias de la fecha de iscripcion y la fecha de inicio de la promocion                     
  entonces eliminamos las cuotas menores a la fecha de inicio y generamos las cuotas                     
  hasta la ultima fecha del cronograma de pagos en base al numero de cuotas espesificado en la matricula y que el tipo de servicio sea C*/             
  IF @IdUnidadNegocio<>1 -- si es diferente de carrera Valida Fecha de inicioinscripcion con fecha de promocion grupo           
  BEGIN           
   IF  @Tiposervicio='C'                    
   BEGIN                    
    DECLARE @FechaInicion DATETIME --primer pago                     
    DECLARE @DateDIF  INT            
                                                                           
    SELECT @FechaInicion=MIN(FechaInicio)           
    FROM  promociongrupo           
    WHERE IdPromocion=@idPromocion                    
                                                                   
    SET @DateDif=DATEDIFF(D,@InscritoFecha,@FechaInicion)                    
    IF  @DateDif>25                     
    BEGIN                    
     DELETE FROM  @cronogramapago WHERE  IdPromocion=@idPromocion AND FechaVencimiento < @FechaInicion                    
    END                    
    IF  @InscritoFecha > @FechaInicion                    
    BEGIN                    
     SET @FechaInicion=@FechaInicion                    
    END           
                          
    IF  @InscritoFecha < @FechaInicion                    
    BEGIN                    
     SET @FechaInicion=(SELECT MIN(FechaVencimiento) FROM  @cronogramapago)                    
    END                             
   END                    
  END                       
                           
  DECLARE @Numero int=0          
            
--@46        
  SET @Numero = CASE WHEN (@CompaniaSocio='00002700'  AND @IdUnidadNegocio<>1 AND @TieneMatricula=0) --@23         
  OR  (@CompaniaSocio='00002500'  AND @TieneMatricula=0 )  THEN 1 ELSE 0 END                          
              
  
  
  ---------------------------------------------- PAGO AL CREDITO ----------------------------------------------                                   
  IF  @CondicionPago = 'Q'           
  BEGIN           
          
   DECLARE @CuotaActual int=0                    
   DECLARE @Count int=0                    
   SELECT @Count = COUNT(1) FROM  @cronogramapago                  
                          
   SELECT @ultimo = MAX(id) FROM  @cronogramapago                                                                                             
   SELECT @id = MIN(id) FROM  @cronogramapago                       
   SELECT @CuotaActual =MIN(id) FROM  @cronogramapago      
    SET @CuotaActual=@CuotaActual-1       
  
 prINT 'cuotas'+  @CondicionPago                
                            
   SET @id=0--@id -1                    
                       
   IF  @idUnidadNegocio<>1                    
   BEGIN           
    IF @NumeroCuota>@Count                    
    BEGIN                    
     SET @NumeroCuota=@Count                    
    END                    
   END                    
                                                                        
   DECLARE @idCuota INT = 0            
   DECLARE @MontoSumaCuotasCC MONEY           
            DECLARE @MontoCuotaTemporal MONEY --@30          
            DECLARE @MontoSumaCuotaPPD MONEY --@30          
                                       
   PRINT 'INICIA CRONOGRAMA DE CUOTAS'          
   PRINT '<==================================>'                             
   -- @NumeroCuota DE LA MATRICULA    (RECORREMOS LAS CUOTAS)       
   WHILE(@id < @NumeroCuota)                                        
   BEGIN          
    --Se valida 1que si es colaborador se coloca todas sus cuotas en estado Cobrado menos la matr�cula.          
    --IF @id >=1 and @Val= 1  SET @Estado = 'CO' ELSE SET @Estado = 'GE' --@18 --inicio @43 se comenta          
    --Inicio @43          
    IF @CompaniaSocio='00002500' OR @CompaniaSocio='00002600' -- @44          
    BEGIN          
      IF @Estado != @SeparacionDeSpringMatriculaValor           
      --Se valida que si es colaborador se coloca todas sus cuotas en estado Cobrado menos la matr�cula.          
       IF @id >=1 and @Val= 1  SET @Estado = 'CO' ELSE SET @Estado = 'GE' --@18          
    END          
    ELSE          
    BEGIN          
     --Se valida que si es colaborador se coloca todas sus cuotas en estado Cobrado menos la matr�cula.          
     IF @id >=1 and @Val= 1  SET @Estado = 'CO' ELSE SET @Estado = 'GE' --@18          
    END          
    --fin @43          
          
          
    SET @id = @id + 1                     
    SET @CuotaActual=@CuotaActual+1          
    SET @FechaVcto=NULL                       
    SET @Numero=@Numero +1                     
  
     --Inicio @20           
  --@46           
     --IF (@CompaniaSocio='00002700' or @CompaniaSocio='00002500') AND @IdUnidadNegocio<>1 AND @TieneMatricula=0          
  IF (@CompaniaSocio='00002700' AND @IdUnidadNegocio<>1 AND @TieneMatricula=0)          
  OR  (@CompaniaSocio='00002500'  AND @TieneMatricula=0)                 
      BEGIN              
       --si es la primera cuota guardamos NOR el campo Tipo  de Facturaci�n                                                                                              
       SET @Condicion2= 'NOR'              
       SET @FlagActualizacion='M'              
      END              
     ELSE              
      BEGIN              
      --si es la primera cuota guardamos MAT el campo Tipo  de Facturacion                                                                                                                                                  
      SET @FlagActualizacion= CASE WHEN @id=1 THEN 'N' WHEN @id > 1 THEN 'M'END              
      --si es la primera cuota guardamos NOR el campo Tipo  de Facturaci�n                                                
      SET @Condicion2= CASE WHEN @id=1 THEN 'MAT' WHEN @id > 1 THEN 'NOR'END                   
      END              
      --Identificamos Pc Automatica para FC y CARRERAS         
   --@46             
   --@48    
      IF @Condicion2='NOR' AND (@CompaniaSocio='00002700')           
      BEGIN            
       IF @id = 1 AND @IdUnidadNegocio<>1 AND @MatCuota = 0  --@25          
       BEGIN            
      SET @PcAutomatico='S'            
       END              
       ELSE            
       BEGIN          
        IF @id = 2 AND @IdUnidadNegocio<>1 AND @MatCuota = 1   --@25          
        BEGIN          
       SET @PcAutomatico='S'            
        END          
        ELSE          
        BEGIN          
       IF @id = 2 AND @IdUnidadNegocio = 1           
       BEGIN            
        SET @PcAutomatico='S'            
       END            
       ELSE            
       BEGIN            
        SET @PcAutomatico='N'            
       END            
        END                   
       END            
      END            
      --Fin @20        
   --      
   IF @Condicion2='NOR' AND (@CompaniaSocio='00002500' )           
      BEGIN       
    IF @id = 1 AND @IdUnidadNegocio<>1 AND @TieneMatricula=0 and @Idsede=34  --@25          
       BEGIN            
      SET @PcAutomatico='S'            
       END       
    ELSE  
       IF @id = 1 AND @IdUnidadNegocio<>1 AND @MatCuota = 0  and @Idsede<>34 --@25          
       BEGIN            
      SET @PcAutomatico='S'            
       END              
       ELSE            
       BEGIN          
        IF @id = 2 AND @IdUnidadNegocio<>1 AND @MatCuota = 1  and @Idsede<>34           
        BEGIN       
       SET @PcAutomatico='S'            
        END       
  ELSE      
       BEGIN          
    IF @id = 1 AND @IdUnidadNegocio=1 AND @TieneMatricula=0 and @Idsede=34  --@25          
       BEGIN            
    SET @PcAutomatico='S'            
       END       
    ELSE  
        IF @id = 2 AND @IdUnidadNegocio = 1 AND @TieneMatricula=0   and @Idsede <>34       
        BEGIN          
       SET @PcAutomatico='S'            
        END       
        ELSE          
        BEGIN          
       IF @id = 2 AND @IdUnidadNegocio = 1 AND @TieneMatricula=1      and @Idsede <> 34    
       BEGIN            
        SET @PcAutomatico='S'            
       END            
       ELSE            
       BEGIN            
        SET @PcAutomatico='N'            
       END            
        END                   
       END            
      END      
   END      
   --@48     
   --      
     
      --Inicio @35          
    IF @Condicion2='NOR' AND @CompaniaSocio='00002500' AND @TieneMatricula = 1              
    BEGIN          
     IF @id = 2 AND @IdUnidadNegocio<>1 AND @MatCuota = 1       
     BEGIN          
      SET @PcAutomatico='S'          
     END          
    ELSE          
     IF @id = 2 AND @IdUnidadNegocio = 1 AND @MatCuota = 1     
     BEGIN            
      SET @PcAutomatico='S'            
     END            
    ELSE            
     BEGIN            
      SET @PcAutomatico='N'            
     END           
    END            
              
    IF @Condicion2='NOR' AND @CompaniaSocio='00002600' AND @TieneMatricula = 1              
    BEGIN          
     IF @id = 2 AND @IdUnidadNegocio<>1 AND @MatCuota = 1          
     BEGIN          
      SET @PcAutomatico='S'          
     END          
    ELSE          
     IF @id = 2 AND @IdUnidadNegocio = 1 AND @MatCuota = 1          
     BEGIN            
      SET @PcAutomatico='S'            
     END            
    ELSE            
     BEGIN            
      SET @PcAutomatico='N'            
     END           
    END         
 --Fin @35  -2          
    IF @Tiposervicio='C' AND @Numero=1 AND @idUnidadNegocio<>1           
    BEGIN                         
     SET @FechaVcto =@FechaInicion                    
    END                    
    ELSE                    
    BEGIN                                                                       
     SELECT @FechaVcto = FechaVencimiento FROM @cronogramapago WHERE id = @CuotaActual        
    END                                                                                         
    --@49 INICIO  
   
 IF @Idsede=34 and @CompaniaSocio ='00002500' and @TieneMatricula = 0   
 BEGIN  
   SET @idCuota = @id --@Numero                   
 END            
 ELSE  
 BEGIN  
  SET @idCuota = @Numero                   
 END  
    --@49 FIN  
    PRINT 'TIPO DE SERVICIO : ' + CAST( @Tiposervicio AS VARCHAR)          
    IF  (@Tiposervicio='P' OR @Tiposervicio='M') AND @Generado=0           
    BEGIN          
          
     SET @FlagCursoCargo='N'          
          
     -- @33 para obtener el tipo cliente que corresponde           
     SET @TipoClienteFinal = NULL           
     SET @TipoClienteFinal = CASE WHEN @EsMatCursoIDAT = 1 AND @Condicion2 = 'MAT' THEN  @TipoListaPrecio ELSE  @TipoCliente  END          
             
     SET @CadSql5 = N' '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.usp_Interfase_P09_Header_Insert           
     @TipoBoleta, @FechaVcto, @condicion, @condicion2, @CodigoEstablecimiento,@IdActorVta,           
     @idActorPag,@PeriodoFinanciero, @Moneda, @Sucursal,@IdCounter,@fechapreparacion,          
     @Estado,@FlagActualizacion,NULL,@Descuento,@idMatricula,@Serie,NULL,@idCuota,NULL,NULL,@Campania,@IdPeriodo,           
     @Area,NULL,@FlagCursoCargo,@Tiposervicio,@CondicionPago,NULL,NULL,NULL,           
     NULL,NULL,@Interfase_Captacion,@IdPlanPago,@CompaniaSocio,@TipoCliente,@TransGratuita,@PcAutomatico,@NumeroInternoINT OUTPUT'          
          
     SET @ParamCadSql5 = N'@TipoBoleta CHAR(2), @FechaVcto DATETIME, @condicion CHAR(3),           
     @condicion2 CHAR(3), @CodigoEstablecimiento CHAR(4),@IdActorVta INT,           
     @idActorPag INT,@PeriodoFinanciero varCHAR(20), @Moneda CHAR(2),           
     @Sucursal CHAR(4),@IdCounter INT,@fechapreparacion DATETIME,          
     @Estado CHAR(2),@FlagActualizacion char(1),@Descuento char(6),@idMatricula INT,@Serie CHAR(4),@idCuota int,          
     @Campania CHAR(10),@IdPeriodo INT, @Area CHAR(4),          
     @FlagCursoCargo CHAR(1),@Tiposervicio CHAR(1),@CondicionPago CHAR(1),          
     @Interfase_Captacion CHAR(1),@IdPlanPago varCHAR(10),@CompaniaSocio char(8),          
     @TipoCliente CHAR(2),@TransGratuita CHAR(1),@PcAutomatico CHAR(1),@NumeroInternoINT INT OUTPUT'          
          
     EXEC sp_executesql @CadSql5, @ParamCadSql5, @TipoBoleta=@TipoBoleta, @FechaVcto=@FechaVcto, @condicion=@condicion,           
     @condicion2=@condicion2, @CodigoEstablecimiento=@CodigoEstablecimiento,@IdActorVta=@IdActorVta,           
     @idActorPag=@idActorPag,@PeriodoFinanciero=@PeriodoFinanciero, @Moneda=@Moneda,           
     @Sucursal=@Sucursal,@IdCounter=@IdCounter,@fechapreparacion=@fechapreparacion,          
     @Estado=@Estado,@FlagActualizacion=@FlagActualizacion,@Descuento=@Descuento,@idMatricula=@idMatricula,@Serie=@Serie,          
     @idCuota=@Numero,@Campania=@Campania,@IdPeriodo=@IdPeriodo, @Area=@Area,        --@49  
     @FlagCursoCargo=@FlagCursoCargo,@Tiposervicio=@Tiposervicio,@CondicionPago=@CondicionPago,          
     @Interfase_Captacion=@Interfase_Captacion,@IdPlanPago=@IdPlanPago,@CompaniaSocio=@CompaniaSocio,          
     @TipoCliente=@TipoCliente,@TransGratuita=@TransGratuita,@PcAutomatico=@PcAutomatico,@NumeroInternoINT=@NumeroInternoINT OUTPUT;          
          
          
          
     --Inicio @20            
  --@46        
     IF (@CompaniaSocio='00002700'  AND @IdUnidadNegocio<>1 AND @TieneMatricula=0)         
  OR  (@CompaniaSocio='00002500'  AND @TieneMatricula=0)              
     BEGIN             
         -- MONTO DE MATRICULA Y CUOTAS ES DE LA PROMOCION REGISTRADO EN LA TABLA MATRICULA                 
      SET @TotalPago = @MontoCuota    
     END            
                    ELSE          
         BEGIN           
                        -- MONTO DE MATRICULA Y CUOTAS ES DE LA PROMOCION REGISTRADO EN LA TABLA MATRICULA                
                        --inicio @30          
                        IF @EsPrincipalCronograma = 0           
                        BEGIN          
                            --Calculamos el monto contado del monto precio lista  - multi cronogramas de pagos          
                            SET  @MontoCuotaTemporal =  (ISNULL(@MontoContado,0) - ISNULL(@MontoMatricula,0))/(@NumeroCuota-1)          
                            -- Cuando sea la ultima cuota realizamos cuadre para cobro exacto                         
                            IF @id=1           
                            BEGIN          
                    SET @TotalPago = @MontoMatricula          
                            END             
                            ELSE IF @id=@NumeroCuota          
                            BEGIN          
                                PRINT ' ULTIMA CUOTA'          
                                SELECT @MontoSumaCuotaPPD = SUM(ISNULL(TotalPago,0)) FROM @PromocionPrecioDetalle WHERE IdPromocion = @idPromocion          
                                SET @TotalPago  = ABS((@MontoCuotaTemporal * (@NumeroCuota-1)) - @MontoSumaCuotaPPD)          
                                --SELECT @MontoCuotaTemporal,@MontoSumaCuotaPPD,@NumeroCuota,@TotalPago          
                            END            
                            ELSE          
                            BEGIN          
                    SET @TotalPago = @MontoCuotaTemporal          
          
                                INSERT INTO @PromocionPrecioDetalle VALUES ( @idPromocion ,  @ItemCodigo , ROUND(@TotalPago,0) )          
                            END          
                        END          
                        ELSE                                                   
                        BEGIN          
                            SET @TotalPago = CASE WHEN @id = 1 THEN @MontoMatricula ELSE @MontoCuota END          
                        END          
                        --fin @30          
                    END          
     --Fin @20              
     -- Correlativo del detalle                                                         
     SET @linea = @linea + 1                                                                
     SET @lineaSP = RIGHT(('00000' + CAST(@linea AS VARCHAR)),5)                      
                            
     PRINT 'ITEM CODIGO :' + CAST( @ItemCodigo AS VARCHAR)          
     PRINT 'NRO CUOTA :' + CAST( @id AS VARCHAR)          
     PRINT 'TOTAL PAGAR DETALLE :' + CAST( @TotalPago AS VARCHAR)          
          
     SET @CadSql6 = N'INSERT INTO '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.CO_Interfase_P09_Detalle           
     (TipoDocumento,NumeroInterno,secuencia,tipodetalle,itemcodigo,cantidadpedida,descripcion,estado,Monto,          
     MontoOriginal,CantidadOriginal,CompaniaSocio,          
     UltimoUsuario,UltimaFechaModificacion,FormularioModificacion)           
     VALUES( @TipoBoleta,@NumeroInternoINT, @lineaSP,''S'',@ItemCodigo,1,'''',@Estado,ROUND(@TotalPago,0),          
     @TotalPago,@CountCurso,@CompaniaSocio,          
     @NombreUsuarioModificacion,GETDATE(),@FormularioProceso)' --@41          
          
     SET @ParamCadSql6 = N'@TipoBoleta CHAR(2), @NumeroInternoINT INT, @lineaSP CHAR (5),          
     @ItemCodigo CHAR(20), @Estado CHAR(2), @TotalPago DECIMAL(12,2), @CountCurso INT, @CompaniaSocio char(8),          
     @NombreUsuarioModificacion CHAR(20),@FormularioProceso CHAR(100)' --@41          
          
     EXEC sp_executesql @CadSql6, @ParamCadSql6, @TipoBoleta=@TipoBoleta,@NumeroInternoINT=@NumeroInternoINT,           
     @lineaSP=@lineaSP,@ItemCodigo=@ItemCodigo,@Estado=@Estado,@TotalPago=@TotalPago,          
     @CountCurso=@CountCurso,@CompaniaSocio=@CompaniaSocio,          
     @NombreUsuarioModificacion=@NombreUsuarioModificacion,@FormularioProceso=@FormularioProceso; --@41          
                                                               
     --Actualisamos el campo GeneradoInterface='S' para saber que ya se genero su interface con esa promocion y esa matricula                    
     UPDATE AlumnoCurso              
     SET GeneradoInterface='S'                   
     WHERE IdMatricula =@idMatricula                     
     AND IdPromocion=@idPromocion                    
     PRINT '<==================================>'           
          
    END                
          
    DECLARE @CountCursoC int=0            
                                                                         
    -- PRODUCTO MAS CURSO SOLO PARA LAS CUOTAS(solo se inserta en el detalle de cada cabecera cuota)                 
    IF (@Tiposervicio='M' AND @idCuota > 1 )  OR  (@Tiposervicio='M' AND @idsede=34 and @CompaniaSocio = '00002500' and @TieneMatricula = 0 )  --@49               
    BEGIN          
          
     DELETE FROM  @PromocionCursos                      
     -- OBTENEMOS SOLO LAS PROMOCIONES QUE LLEVA POR CURSOS           
     INSERT INTO @PromocionCursos(IdPromocion,TipoCondicion,Cantida,ServicioCodigo)           
  SELECT IdPromocion,TipoCondicion,COUNT(1) , ServicioCodigo            
     FROM  @AlumnoCurso            
     WHERE IdMatricula =@idMatricula                     
         AND (IdSeccion<>0 AND IdSeccion is not null)              
         AND (TipoCondicion='CC') -- SOLO POR CURSO A CARGO                  
         AND GeneradoInterface is null           
         AND IdModulo <> @IdModuloMatricula --@19 solo consutamos a los cursos que sean diferente a su modulo de cabecera para cobrarle por curso          
         AND (Paga=1)--@31           
     GROUP BY IdPromocion ,TipoCondicion,ServicioCodigo                    
                     
     PRINT 'BUSCAMOS CURSOS : TipoCondicion CC IdSeccion is not null '          
          
     SELECT @MIN = MIN(Id) , @MAX = MAX(Id) FROM  @PromocionCursos          
          
     PRINT  'CANTIDAD DE CURSOS : MIN '+ CAST( @MIN AS VARCHAR) + '  MAX' +CAST( @MAX AS VARCHAR)          
          
     PRINT '<===============INICIO CC M ===================>'            
          
     --INICIO recorremos las promociones por curso           
     WHILE @MIN <= @MAX                                                                         
     BEGIN           
                                                                                               
      -- obtenemos los datos de promocion por curso          
      SELECT @idPromocionC=idPromocion,@TipoCondicionC=TipoCondicion,@CountCursoC=Cantida , @ItemCodigoCurso=ServicioCodigo                        
      FROM  @PromocionCursos WHERE id = @MIN          
          
      --Inicio @24          
      DELETE FROM  @CurriculaCursoHoras          
               
      INSERT INTO @CurriculaCursoHoras(IdPromocion,IdCurso,IdModulo,TotalHoras , ServicioCodigo)            
      SELECT ac.IdPromocion,ac.IdCurso,CC.IdModulo,ISNULL(cc.CursoPractica,0) + ISNULL(cc.CursoTeoria,0), replace(p.ServicioCodigo, 'P', 'C')          
      FROM @AlumnoCurso ac              
      INNER JOIN Promocion p                  
      ON p.IdPromocion = ac.IdPromocion            
      INNER JOIN CurriculaCurso cc              
      ON cc.IdCurricula=p.IdCurricula and cc.IdCurso=ac.IdCurso             
      WHERE ac.IdMatricula = @IdMatricula              
      AND ac.IdPromocion = @idPromocionC            
      AND (IdSeccion<>0 AND IdSeccion is not null)                       
      AND (TipoCondicion='CC' or TipoCondicion='RE')                       
      AND GeneradoInterface is null           
          
      Update @CurriculaCursoHoras Set TotalHoras=3 where TotalHoras=0          
               
      --Fin @24          
                                                                                               
      PRINT  'PROMOCION DETALLE: @TipoCondicionC '+ CAST( @TipoCondicionC AS VARCHAR) +  ' @CountCursoC '+ CAST( @CountCursoC AS VARCHAR) +  ' @ItemCodigoCurso '+ CAST( @ItemCodigoCurso AS VARCHAR)           
          
      -- nos aseguramos de tener el itemcodigo del curso y no del producto                                 
      SET @ItemCodigoCurso=REPLACE(@ItemCodigoCurso,'P','C')                     
      -- por defecto todos son cursos a cargo @Tiposervicio='M' and TipoCondicion='CC'          
      SET @FlagCursoCargo='S'                         
                                  
      PRINT  'ITEM CODIGO DETALLE CC '+ CAST( @ItemCodigoCurso AS VARCHAR)           
          
      -- obtenemos el monto a contado del curso                    
      SELECT @MontoContadoCurso=Monto          
      FROM @CO_Precio          
      WHERE TipoFacturacion='CON'          
      AND ItemCodigo = @ItemCodigoCurso          
      AND tipocliente = (CASE WHEN CHARINDEX('C',@ItemCodigoCurso,0)> 0 AND ISNULL(@PermisoMatporCursoCaptacion,0) = 0 THEN '01' ELSE  @TipoListaPrecio END)--@17          
          
      PRINT  'MONTO DETALLE CC '+ CAST( @MontoContadoCurso AS VARCHAR)          
                
                 
          
      -- SELECT @MontoContado , @CountCursoC , @NumeroCuota          
      -- Cuando sea la ultima cuota realizamos cuadre para cobro exacto        
      IF @idCuota=@NumeroCuota  
      BEGIN          
       PRINT  ' ULTIMA CUOTA'          
          
       SELECT @MontoSumaCuotasCC = SUM(ISNULL(TotalPago,0)) FROM @PromocionPrecioDetalle WHERE IdPromocion = @idPromocionC          
          
       PRINT  'SUMA DE PROMCOION MONTO CC MONTO: ' + CAST( @MontoSumaCuotasCC AS VARCHAR)  +  '  PROMOCION ' + CAST( @idPromocionC AS VARCHAR)           
          
       --Inicio @24          
       IF @MatCursoLibrexHora = 1 AND @IdUnidadNegocio = 1          
       BEGIN          
        Select @CursoMasCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras > @CondicionHoras          
        Select @CursoMenosCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras <= @CondicionHoras          
          
        SET @TotalPago =  ABS((@MontoContadoCurso * @CursoMasCondicionHoras) + ((@MontoContadoCurso * @CursoMenosCondicionHoras)/2) - @MontoSumaCuotasCC)          
       END          
       ELSE          
       BEGIN          
        -- TIENE QUE CUADRAR CON EL MONTO : (MONTO CONTADO DEL CURSO * CANTIDAD DE CURSOS DE LA PROMOCION CC)          
        SET @TotalPago  = ABS((@MontoContadoCurso * @CountCursoC ) - @MontoSumaCuotasCC)          
       END          
       --Fin @24          
                                                                                                                           
      END           
      ELSE          
      BEGIN          
       --Inicio @24          
       IF @MatCursoLibrexHora = 1 AND @IdUnidadNegocio = 1          
       BEGIN          
        Select @CursoMasCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras > @CondicionHoras          
        Select @CursoMenosCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras <= @CondicionHoras          
          
        SET @TotalPago =  (@MontoContadoCurso * @CursoMasCondicionHoras)/ (@NumeroCuota - 1) + ((@MontoContadoCurso * @CursoMenosCondicionHoras)/2)/ (@NumeroCuota - 1)                
          
       END          
       ELSE          
       BEGIN          
        --NO CONSIDERAMOS LA CUOTA INICIAL   FORMULA: (MONTO CONTADO DEL CURSO * CANTIDAD DE CURSOS DE LA PROMOCION CC ) / NUMERO DE CUOTAS (NO INCLUYE MATRICULA)     
  IF (@Idsede = 34 AND @CompaniaSocio = '00002500' AND @TieneMatricula = 0)--@48  
  BEGIN  
  SET @TotalPago=((@MontoContadoCurso * @CountCursoC) / (@NumeroCuota ) )   
  END  
  ELSE    
  BEGIN  
  SET @TotalPago=((@MontoContadoCurso * @CountCursoC) / (@NumeroCuota - 1 ) ) --@49  
  END  
                 
        -- sumamos cada cuota para saber cuanto vamos para el cuadre de la ultima cuota                     
        --SET @MontoSumaCuotasCC = ISNULL(@MontoSumaCuotasCC,0) +  ROUND(@TotalPago,0)          
       END          
       --Fin @24          
          
       INSERT INTO @PromocionPrecioDetalle VALUES ( @idPromocionC ,  @ItemCodigoCurso , ROUND(@TotalPago,0) )          
          
      END           
                                                                                               
      PRINT  'TOTAL PAGAR CC '+ CAST( ROUND(@TotalPago,0) AS VARCHAR)           
                                                                                               
                                                                                                                                 
      --  correlativo                  
      SET @linea = @linea + 1                                 
      SET @lineaSP = RIGHT(('00000' + CAST(@linea AS VARCHAR)),5)                  
             
                                             
      SET @CadSql7 = N'INSERT INTO '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.CO_Interfase_P09_Detalle           
      (TipoDocumento,NumeroInterno,secuencia,tipodetalle,itemcodigo,cantidadpedida,descripcion,estado,Monto,          
      MontoOriginal,CantidadOriginal,CompaniaSocio,          
      UltimoUsuario,UltimaFechaModificacion,FormularioModificacion)           
      VALUES( @TipoBoleta,@NumeroInternoINT, @lineaSP,''S'',@ItemCodigo,1,'''',@Estado,ROUND(@TotalPago,0),          
      @TotalPago,@CountCurso,@CompaniaSocio,          
      @NombreUsuarioModificacion,GETDATE(),@FormularioProceso)' --@41          
          
      SET @ParamCadSql7 = N'@TipoBoleta CHAR(2), @NumeroInternoINT INT, @lineaSP CHAR (5),          
      @ItemCodigo CHAR(20), @Estado CHAR(2), @TotalPago DECIMAL(12,2), @CountCurso INT, @CompaniaSocio char(8),          
      @NombreUsuarioModificacion CHAR(20),@FormularioProceso CHAR(100)' --@41          
          
      EXEC sp_executesql @CadSql7, @ParamCadSql7, @TipoBoleta=@TipoBoleta,@NumeroInternoINT=@NumeroInternoINT,           
      @lineaSP=@lineaSP,@ItemCodigo=@ItemCodigo,@Estado=@Estado,@TotalPago=@TotalPago,          
      @CountCurso=@CountCurso,@CompaniaSocio=@CompaniaSocio,          
      @NombreUsuarioModificacion=@NombreUsuarioModificacion,@FormularioProceso=@FormularioProceso; --@41          
                       
      SET @MIN = @MIN + 1           
     END           
     PRINT '<===============FIN CC M ===================>'         
    --FIN del recorrido de las promociones por curso                     
    END           
          
    IF (@Tiposervicio='C')                   
    BEGIN          
                    
     SET @GeneradoC=0                                                                         
     SET @FlagCursoCargo='S'          
     DECLARE @CantidadCursosMatricula INT = 0           
     --@14 Condicion para Curso por diplomado          
     --Codigo agregado          
     DELETE FROM  @PromocionCursos           
     IF @TipoCondicion='CC' and @TipoM='MA' and ISNULL(@PermisoMatporCursoCaptacion,0) = 1 AND @IdPeriodoMat IS NULL --Inicio @28 --@37          
     BEGIN          
      INSERT INTO @PromocionCursos(IdPromocion,TipoCondicion,Cantida,ServicioCodigo)                    
      SELECT IdPromocion,TipoCondicion,Count(*),ServicioCodigo                     
      FROM @AlumnoCurso                               
      WHERE IdMatricula =@idMatricula     
      AND (TipoCondicion='CC' OR TipoCondicion='RE')                     
      AND GeneradoInterface IS NULL           
      GROUP BY IdPromocion ,TipoCondicion,ServicioCodigo           
          
     END          
     ELSE          
     --Codigo Original           
     BEGIN          
      -- OBTENEMOS LOS CURSOS DE MATRICULADOS POR CC          
      INSERT INTO @PromocionCursos(IdPromocion,TipoCondicion,Cantida,ServicioCodigo )                                       
      SELECT IdPromocion,TipoCondicion,COUNT(1),ServicioCodigo                      
      FROM  @AlumnoCurso                           
      WHERE IdMatricula =@idMatricula                     
          AND (IdSeccion<>0 AND IdSeccion is not null)  --@29                   
          AND (TipoCondicion='CC' or TipoCondicion='RE')                     
          AND GeneradoInterface is null           
      GROUP BY IdPromocion ,TipoCondicion,ServicioCodigo          
     END  --Fin @28          
               
     PRINT 'BUSCAMOS CURSOS : TipoCondicion CC IdSeccion is not null '                                      
           
     SET @TipoClienteFinal = NULL           
     SET @TipoClienteFinal = CASE WHEN @EsMatCursoIDAT = 1 AND @Condicion2 = 'MAT' THEN  @TipoListaPrecio ELSE  @TipoCliente  END          
          
     SET @CadSql8 = N' '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.usp_Interfase_P09_Header_Insert           
     @TipoBoleta, @FechaVcto, @condicion, @condicion2, @CodigoEstablecimiento,@IdActorVta,           
     @idActorPag,@PeriodoFinanciero, @Moneda, @Sucursal,@IdCounter,@fechapreparacion,          
     @Estado,@FlagActualizacion,NULL,@Descuento,@idMatricula,@Serie,NULL,@idCuota,NULL,NULL,@Campania,@IdPeriodo,           
     @Area,NULL,@FlagCursoCargo,@Tiposervicio,@CondicionPago,NULL,NULL,NULL,           
     NULL,NULL,@Interfase_Captacion,@IdPlanPago,@CompaniaSocio,@TipoCliente,@TransGratuita,@PcAutomatico,@NumeroInternoINT OUTPUT'          
          
     SET @ParamCadSql8 = N'@TipoBoleta CHAR(2), @FechaVcto DATETIME, @condicion CHAR(3),           
     @condicion2 CHAR(3), @CodigoEstablecimiento CHAR(4),@IdActorVta INT,           
     @idActorPag INT,@PeriodoFinanciero varCHAR(20), @Moneda CHAR(2),           
     @Sucursal CHAR(4),@IdCounter INT,@fechapreparacion DATETIME,          
     @Estado CHAR(2),@FlagActualizacion char(1),@Descuento char(6),@idMatricula INT,@Serie CHAR(4),@idCuota int,          
     @Campania CHAR(10),@IdPeriodo INT, @Area CHAR(4),          
     @FlagCursoCargo CHAR(1),@Tiposervicio CHAR(1),@CondicionPago CHAR(1),          
     @Interfase_Captacion CHAR(1),@IdPlanPago varCHAR(10),@CompaniaSocio char(8),          
     @TipoCliente CHAR(2),@TransGratuita CHAR(1),@PcAutomatico CHAR(1),@NumeroInternoINT INT OUTPUT'          
          
     EXEC sp_executesql @CadSql8, @ParamCadSql8, @TipoBoleta=@TipoBoleta, @FechaVcto=@FechaVcto, @condicion=@condicion,           
     @condicion2=@condicion2, @CodigoEstablecimiento=@CodigoEstablecimiento,@IdActorVta=@IdActorVta,           
     @idActorPag=@idActorPag,@PeriodoFinanciero=@PeriodoFinanciero, @Moneda=@Moneda,           
     @Sucursal=@Sucursal,@IdCounter=@IdCounter,@fechapreparacion=@fechapreparacion,          
     @Estado=@Estado,@FlagActualizacion=@FlagActualizacion,@Descuento=@Descuento,@idMatricula=@idMatricula,@Serie=@Serie,          
     @idCuota=@Numero,@Campania=@Campania,@IdPeriodo=@IdPeriodo, @Area=@Area,          
     @FlagCursoCargo=@FlagCursoCargo,@Tiposervicio=@Tiposervicio,@CondicionPago=@CondicionPago,          
     @Interfase_Captacion=@Interfase_Captacion,@IdPlanPago=@IdPlanPago,@CompaniaSocio=@CompaniaSocio,          
     @TipoCliente=@TipoCliente,@TransGratuita=@TransGratuita,@PcAutomatico=@PcAutomatico,@NumeroInternoINT=@NumeroInternoINT OUTPUT;          
          
          
     PRINT '<===============INICIO CC C ===================>'            
          
     -- registro de matricula por                  
     IF @idCuota = 1          
     BEGIN          
                
      --Inicio @24          
      IF @MatCursoLibrexHora = 1 and (@IdUnidadNegocio =1 or @IdUnidadAcademica = 50) --@28          
      BEGIN          
       SET @TotalPagoMatriculaCurso = @MontoMatricula          
       PRINT 'PRECIO DE LA MATRICULA: ' + CAST(@TotalPagoMatriculaCurso AS VARCHAR)            
      END          
      ELSE          
      BEGIN          
                 
       -- Segun la cantidad mas cursos matriculados obtiene la matricula 2 o 3 40%  y de 4 a mas 60%           
       -- obtenemos cantidad de cursos           
       SELECT @CantidadCursosMatricula = SUM(Cantida) FROM @PromocionCursos          
                                                                                            
       --40%          
       IF @CantidadCursosMatricula >= 2 AND @CantidadCursosMatricula <= 3          
       BEGIN                                                                    
        SET @TotalPagoMatriculaCurso = (@MontoMatricula * 0.40)              
        PRINT '40% @CantidadCursosMatricula' + CAST( @CantidadCursosMatricula AS VARCHAR) +' @TotalPagoMatriculaCurso '+  CAST(@TotalPagoMatriculaCurso AS VARCHAR) +'@MontoMatricula' + CAST( @MontoMatricula AS VARCHAR)          
       END           
       --60%          
       IF @CantidadCursosMatricula >= 4          
       BEGIN                                                         
        SET @TotalPagoMatriculaCurso = (@MontoMatricula * 0.60)            
        PRINT '60% @CantidadCursosMatricula' + CAST( @CantidadCursosMatricula AS VARCHAR) +' @TotalPagoMatriculaCurso '+  CAST(@TotalPagoMatriculaCurso AS VARCHAR) +'@MontoMatricula' + CAST( @MontoMatricula AS VARCHAR)              
       END                  
      END          
      --Fin @24          
          
      SET @TotalPago = @TotalPagoMatriculaCurso          
          
      -- Correlativo del detalle                                                         
      SET @linea = @linea + 1                                                   
      SET @lineaSP = RIGHT(('00000' + CAST(@linea AS VARCHAR)),5)                      
                            
      -- cambimos el item codigo a curso           
      SET @ItemCodigo = REPLACE(ISNULL(@ItemCodigo,''),'P','C')          
                
      SET @CadSql9 = N'INSERT INTO '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.CO_Interfase_P09_Detalle           
      (TipoDocumento,NumeroInterno,secuencia,tipodetalle,itemcodigo,cantidadpedida,descripcion,estado,Monto,          
      MontoOriginal,CantidadOriginal,CompaniaSocio,          
      UltimoUsuario,UltimaFechaModificacion,FormularioModificacion)           
      VALUES( @TipoBoleta,@NumeroInternoINT, @lineaSP,''S'',@ItemCodigo,1,'''',@Estado,ROUND(@TotalPago,0),          
      @TotalPago,@CountCurso,@CompaniaSocio,          
      @NombreUsuarioModificacion,GETDATE(),@FormularioProceso)' --@41          
          
      SET @ParamCadSql9 = N'@TipoBoleta CHAR(2), @NumeroInternoINT INT, @lineaSP CHAR (5),          
      @ItemCodigo CHAR(20), @Estado CHAR(2), @TotalPago DECIMAL(12,2), @CountCurso INT, @CompaniaSocio char(8),          
      @NombreUsuarioModificacion CHAR(20),@FormularioProceso CHAR(100)' --@41          
          
      EXEC sp_executesql @CadSql9, @ParamCadSql9, @TipoBoleta=@TipoBoleta,@NumeroInternoINT=@NumeroInternoINT,           
      @lineaSP=@lineaSP,@ItemCodigo=@ItemCodigo,@Estado=@Estado,@TotalPago=@TotalPago,          
      @CountCurso=@CountCurso,@CompaniaSocio=@CompaniaSocio,          
      @NombreUsuarioModificacion=@NombreUsuarioModificacion,@FormularioProceso=@FormularioProceso; --@41          
                                        
      --Actualisamos el campo GeneradoInterface='S' para saber que ya se genero su interface con esa promocion y esa matricula                    
      UPDATE AlumnoCurso                     
      SET GeneradoInterface='S'                     
      WHERE IdMatricula =@idMatricula                     
      AND IdPromocion=@idPromocion           
          
     END          
     ELSE             
     BEGIN          
      SELECT @MIN = MIN(Id) , @MAX = MAX(Id) FROM  @PromocionCursos          
          
      WHILE @MIN <= @MAX                    
      BEGIN           
                                                                                  
       SELECT @idPromocionC=idPromocion,@TipoCondicionC=TipoCondicion,@CountCursoC=Cantida,@ItemCodigoCurso=ServicioCodigo                     
       FROM  @PromocionCursos WHERE id = @MIN           
                 
       --Inicio @24          
       DELETE FROM  @CurriculaCursoHoras          
               
       INSERT INTO @CurriculaCursoHoras(IdPromocion,IdCurso,IdModulo,TotalHoras , ServicioCodigo)            
       SELECT ac.IdPromocion,ac.IdCurso,CC.IdModulo,ISNULL(cc.CursoPractica,0) + ISNULL(cc.CursoTeoria,0), replace(p.ServicioCodigo, 'P', 'C')          
          FROM @AlumnoCurso ac              
          INNER JOIN Promocion p                  
          ON p.IdPromocion = ac.IdPromocion            
          INNER JOIN CurriculaCurso cc              
          ON cc.IdCurricula=p.IdCurricula and cc.IdCurso=ac.IdCurso             
          WHERE ac.IdMatricula = @IdMatricula              
          AND ac.IdPromocion = @idPromocionC            
          AND (IdSeccion<>0 AND IdSeccion is not null)                       
          AND (TipoCondicion='CC' or TipoCondicion='RE')                       
          AND GeneradoInterface is null    
          
       Update @CurriculaCursoHoras Set TotalHoras=3 where TotalHoras=0               
       --Fin @24          
                  
       -- Item para curso          
       SET @ItemCodigoCurso=REPLACE(@ItemCodigoCurso,'P','C')          
                 
       PRINT  'PROMOCION DETALLE: @TipoCondicionC '+ CAST( @TipoCondicionC AS VARCHAR) +  ' @CountCursoC '+ CAST( @CountCursoC AS VARCHAR) +  ' @ItemCodigoCurso '+ CAST( @ItemCodigoCurso AS VARCHAR)                         
                                                                                                              
       SELECT @MontoContadoCurso= Monto           
       FROM @CO_Precio          
       WHERE TipoFacturacion='CON'          
       AND ItemCodigo = @ItemCodigoCurso          
       AND tipocliente = (CASE WHEN CHARINDEX('C',@ItemCodigoCurso,0)> 0 AND ISNULL(@PermisoMatporCursoCaptacion,0) = 0 THEN '01' ELSE  @TipoListaPrecio END)--@17          
          
       PRINT  'MONTO DETALLE CC '+ CAST( @MontoContadoCurso AS VARCHAR)          
          
       --NO CONSIDERAMOS LA CUOTA INICIAL           
       IF @idCuota=@NumeroCuota          
       BEGIN          
        -- obtenemos cantidad de cursos           
        SELECT @CantidadCursosMatricula = SUM(Cantida) FROM @PromocionCursos          
          
        SELECT @MontoSumaCuotasCC = SUM(ISNULL(TotalPago,0)) FROM @PromocionPrecioDetalle WHERE IdPromocion = @idPromocionC          
          
        --Inicio @24          
        IF @MatCursoLibrexHora = 1 AND @IdUnidadNegocio = 1          
        BEGIN          
         Select @CursoMasCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras > @CondicionHoras          
         PRINT 'TOTAL DE CURSOS DE MAS 3 HORAS :' + CAST(@CursoMasCondicionHoras AS VARCHAR)          
         Select @CursoMenosCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras <= @CondicionHoras          
         PRINT 'TOTAL DE CURSOS HASTA 3 HORAS:' + CAST(@CursoMenosCondicionHoras AS VARCHAR)            
          
         SET @TotalPago =  ABS((@MontoContadoCurso * @CursoMasCondicionHoras) + ((@MontoContadoCurso * @CursoMenosCondicionHoras)/2) - ISNULL(@MontoSumaCuotasCC, 0)) --@45          
        END          
        ELSE          
        BEGIN                                                     
         -- obtenemos cantidad de cursos           
         SET @TotalPago   = ABS( ((@MontoContadoCurso * @CountCursoC ) - ((@TotalPagoMatriculaCurso/ @CantidadCursosMatricula) * @CountCursoC ) ) - ISNULL(@MontoSumaCuotasCC,0)) --@45                   
        END          
        --Fin @24          
       END           
       ELSE          
       BEGIN          
        SELECT @CantidadCursosMatricula = SUM(Cantida) FROM @PromocionCursos          
         
        --Inicio @24          
        IF @MatCursoLibrexHora = 1 and @IdUnidadNegocio = 1          
        BEGIN          
         Select @CursoMasCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras > @CondicionHoras          
         PRINT 'TOTAL DE CURSOS DE MAS 3 HORAS :' + CAST(@CursoMasCondicionHoras AS VARCHAR)          
         Select @CursoMenosCondicionHoras = count(1) from @CurriculaCursoHoras where TotalHoras <= @CondicionHoras          
         PRINT 'TOTAL DE CURSOS HASTA 3 HORAS:' + CAST(@CursoMenosCondicionHoras AS VARCHAR)          
          
         SET @TotalPago =  (@MontoContadoCurso * @CursoMasCondicionHoras)/ (@NumeroCuota - 1) + ((@MontoContadoCurso * @CursoMenosCondicionHoras)/2)/ (@NumeroCuota - 1)                         
        END          
        ELSE          
        BEGIN          
         --NO CONSIDERAMOS LA CUOTA INICIAL                                                                        
         SET @TotalPago=( ((@MontoContadoCurso * @CountCursoC) - ((@TotalPagoMatriculaCurso/ @CantidadCursosMatricula) * @CountCursoC ) )  / (@NumeroCuota - 1) )              
        END          
        --Fin @24          
                                                                                                      
        INSERT INTO @PromocionPrecioDetalle VALUES ( @idPromocionC ,  @ItemCodigoCurso , ROUND(@TotalPago,0) )          
       END           
                                      
       -- correlativo             
       SET @linea = @linea + 1                                 
       SET @lineaSP = RIGHT(('00000' + CAST(@linea AS VARCHAR)),5)          
                 
       PRINT  'TOTAL PAGAR CC '+ CAST( ROUND(@TotalPago,0) AS VARCHAR)                            
                       
       SET @CadSql10 = N'INSERT INTO '+@ServidorVinculadoAcad+'.'+@BaseDatos+'.dbo.CO_Interfase_P09_Detalle           
       (TipoDocumento,NumeroInterno,secuencia,tipodetalle,itemcodigo,cantidadpedida,descripcion,estado,Monto,          
       MontoOriginal,CantidadOriginal,CompaniaSocio,          
       UltimoUsuario,UltimaFechaModificacion,FormularioModificacion)           
       VALUES( @TipoBoleta,@NumeroInternoINT, @lineaSP,''S'',@ItemCodigo,1,'''',@Estado,ROUND(@TotalPago,0),          
       @TotalPago,@CountCurso,@CompaniaSocio,          
       @NombreUsuarioModificacion,GETDATE(),@FormularioProceso)' --@41          
          
       SET @ParamCadSql10 = N'@TipoBoleta CHAR(2), @NumeroInternoINT INT, @lineaSP CHAR (5),          
       @ItemCodigo CHAR(20), @Estado CHAR(2), @TotalPago DECIMAL(12,2), @CountCurso INT, @CompaniaSocio char(8),          
       @NombreUsuarioModificacion CHAR(20),@FormularioProceso CHAR(100)' --@41          
          
       EXEC sp_executesql @CadSql10, @ParamCadSql10, @TipoBoleta=@TipoBoleta,@NumeroInternoINT=@NumeroInternoINT,           
       @lineaSP=@lineaSP,@ItemCodigo=@ItemCodigo,@Estado=@Estado,@TotalPago=@TotalPago,          
       @CountCurso=@CountCurso,@CompaniaSocio=@CompaniaSocio,          
       @NombreUsuarioModificacion=@NombreUsuarioModificacion,@FormularioProceso=@FormularioProceso; --@41          
                
       SET @MIN = @MIN + 1           
      END                    
     END                                                      
    END                                                          
   END                       
   --FIN BUCLE CUOTAS          
                                                               
   --Actualisamos el campo GeneradoInterface='S' para saber que ya se genero su interface con esa promocion y esa matricula                    
   update  AlumnoCurso                     
   SET GeneradoInterface='S'           
   WHERE IdMatricula =@idMatricula and (IdGrupo is not null AND (IdSeccion<>0 AND IdSeccion IS Not NULL))                     
       AND (TipoCondicion='CC' OR TipoCondicion='RE') and( @Tiposervicio='M' OR @Tiposervicio='C')  --@01                                                    
  END                   
  ---------------------------------------------- PAGO AL CREDITO ----------------------------------------------           
             
 END            
                                     
    SET XACT_ABORT ON            
                                                                                           
    SET @parmReturn = @parmReturn             
    SET STATISTICS TIME off;          
END 
