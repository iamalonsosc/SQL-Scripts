exec cPeriodoEquivalencia_Sel_Listar @IdPeriodoCabecera=4007,@IdPeriodo=3676

exec cPeriodoEquivalencia_Sel_Listar @IdPeriodoCabecera=4013,@IdPeriodo=3682
sp_helptext cPeriodoEquivalencia_Sel_Listar


Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--����������������������������������������������������������������������������    
--Creado por      : Jimy Mota(24/09/2018)    
--Funcionalidad   : Permite listar los datos de la tabla periodoequivalencia    
--Utilizado por   : PeriodoEquivalencia.SelListarLis    
--����������������������������������������������������������������������������    
/*                    
-----------------------------------------------------------------------------                    
Nro  FECHA  USUARIO  DESCRIPCION                    
-----------------------------------------------------------------------------      
@1 2020.01.19 jmota se agrega logica para periodos siguientes
@2 2021.02.2021 ealva se agrega logica de periodo  anterior  y siguiente 
*/     
ALTER PROCEDURE [dbo].[cPeriodoEquivalencia_Sel_Listar]    
@IdPeriodoCabecera INT,    
@IdPeriodo INT     
AS    
BEGIN    
    
		 SET NOCOUNT ON     
		 DECLARE @TB_Relacion TABLE (IdPeriodoCabecera INT , EsSiguiente BIT )--@1  
    
		 BEGIN   
    
			  Declare @idPeriodoCabeceraAnterior int    
			  Declare @IdPeriodoCabeceraSiguiente int   
			  Declare @IdPeriodoCabeceraTrasAnterior INT
			  Declare @IdPeriodoCabeceraPostSiguiente   INT
			  select @idPeriodoCabeceraAnterior= idPeriodoCabeceraAnterior,    
			  @IdPeriodoCabeceraSiguiente=IdPeriodoCabeceraSiguiente    
			  from PeriodoCabecera WITH(NOLOCK)    
			  where idPeriodoCabecera=@IdPeriodoCabecera    
  
			  SELECT @IdPeriodoCabeceraTrasAnterior=IdPeriodoCabeceraAnterior FROM PeriodoCabecera WHERE IdPeriodoCabecera=@idPeriodoCabeceraAnterior  --@2
			  SELECT @IdPeriodoCabeceraPostSiguiente=IdPeriodoCabeceraSiguiente FROM PeriodoCabecera WHERE IdPeriodoCabecera=@IdPeriodoCabeceraSiguiente  --@2
			  --@1  
			  INSERT INTO @TB_Relacion  
			  SELECT IdPeriodoCabecera, 0  FROM periodocabecera WITH(NOLOCK) WHERE IdPeriodoCabeceraSiguiente = @IdPeriodoCabecera    
   
			  INSERT INTO  @TB_Relacion VALUES (@IdPeriodoCabeceraSiguiente , 1 )  
			  INSERT INTO  @TB_Relacion VALUES (@idPeriodoCabeceraAnterior , 0 )  
			  --@1  
			  INSERT INTO  @TB_Relacion VALUES (@IdPeriodoCabeceraTrasAnterior , 0 )  --@2
			  INSERT INTO  @TB_Relacion VALUES (@IdPeriodoCabeceraPostSiguiente , 1 )  --@2
  
		 END    
		  --select * from @TB_Relacion  
		 BEGIN    
			  Declare @PeriodoAntSig table    
			  (IdPeriodoPadre int,    
			  Codigo varchar(20),     
			  Nombre varchar(50),    
			  IdPeriodoEquivalencia int,    
			  PeriodoEquivalenciaCodigo  varchar(20),     
			  PeriodoEquivalenciaNombre varchar(50),    
			  EsSiguiente bit,    
		  Sel bit)    
		 END    
    
		 BEGIN   
     
			  Insert into @PeriodoAntSig      
			  (IdPeriodoPadre,    
			  Codigo,     
			  Nombre,    
			  IdPeriodoEquivalencia,    
			  PeriodoEquivalenciaCodigo,     
			  PeriodoEquivalenciaNombre,    
			  EsSiguiente,    
			  Sel)    
			  Select  'IdPeriodoPadre' = ISNULL(PC.IdPeriodoCabecera,-1) ,     
			  'Codigo'=ISNULL(PC.Codigo,-1) ,     
			  'Nombre'=ISNULL(PC.Nombre,-1) ,     
			  'IdPeriodoEquivalencia' = IdPeriodo,    
			  'PeriodoEquivalenciaCodigo' = P.Codigo,    
			  'PeriodoEquivalenciaNombre'= P.Nombre,    
			  'EsSiguiente'= 0,     
			  'Sel' = 0     
			  from Periodo P WITH(NOLOCK)    
			  INNER JOIN PeriodoCabecera PC WITH(NOLOCK) ON P.IdPeriodoCabecera=PC.IdPeriodoCabecera
			  where P.IdPeriodoCabecera IN (SELECT IdPeriodoCabecera  FROM @TB_Relacion WHERE EsSiguiente = 0)    
  
			  Insert into @PeriodoAntSig      
			  (IdPeriodoPadre,    
			  Codigo,     
			  Nombre,    
			  IdPeriodoEquivalencia,    
			  PeriodoEquivalenciaCodigo,     
			  PeriodoEquivalenciaNombre,    
			  EsSiguiente,    
			  Sel)    
			  Select  'IdPeriodoPadre' = ISNULL(PC.IdPeriodoCabecera,-1) ,     
			  'Codigo'=ISNULL(PC.Codigo,-1) ,     
			  'Nombre'=ISNULL(PC.Nombre,-1) ,    
			  'IdPeriodoEquivalencia' = IdPeriodo,    
			  'PeriodoEquivalenciaCodigo' = P.Codigo,    
			  'PeriodoEquivalenciaNombre'= P.Nombre,    
			  'EsSiguiente'= 1,     
			  'Sel' = 0     
			  from Periodo P WITH(NOLOCK)   
			  INNER JOIN PeriodoCabecera PC WITH(NOLOCK) ON P.IdPeriodoCabecera=PC.IdPeriodoCabecera
			  where P.IdPeriodoCabecera IN (SELECT IdPeriodoCabecera FROM @TB_Relacion WHERE EsSiguiente = 1)    
  
		 END    
    
    
		 IF EXISTS(    
		 Select 1 from PeriodoEquivalencia WITH(NOLOCK)    
		 where IdPeriodoPadre = @IdPeriodo )    
		 BEGIN    
        
			  UPDATE PAS SET Sel=1,    
			  IdPeriodoPadre =PE.IdPeriodoPadre ,    
			  Codigo =PP.Codigo,    
			  Nombre=PP.Nombre    
			  From PeriodoEquivalencia PE WITH (NOLOCK)     
			  INNER JOIN Periodo PP  WITH (NOLOCK) ON PE.IdPeriodoPadre = PP.IdPeriodo    
			  INNER JOIN Periodo PH  WITH (NOLOCK) ON PE.IdPeriodoEquivalencia = PH.IdPeriodo    
			  LEFT JOIN @PeriodoAntSig PAS ON PAS.IdPeriodoEquivalencia = PE.IdPeriodoEquivalencia    
			  WHERE PE.IdPeriodoPadre = @IdPeriodo    
    
		 END     
    
		 SELECT * FROM @PeriodoAntSig ORDER BY EsSiguiente,IdPeriodoPadre DESC     --@2
    
END   
