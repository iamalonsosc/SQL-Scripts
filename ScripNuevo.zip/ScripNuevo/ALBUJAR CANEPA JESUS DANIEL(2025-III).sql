--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=742716


--SELECT TipoCondicion,*FROM AlumnoCurso 
UPDATE AlumnoCurso SET TipoCondicion='CC'
where IdMatricula=742716 AND EsMatricula=1 


----RP(PROMOVIDO + CURSO)
------CC(CURSO REPITENCIA)
------RT(REPITENCIA)
------RE(PROMOVIDO)
--SELECT*FROM AlumnoCursoNomina WHERE IdMatricula=713661