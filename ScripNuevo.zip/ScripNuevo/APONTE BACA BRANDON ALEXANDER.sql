SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=639646


SELECT TipoCondicion,*FROM AlumnoCurso 
where IdMatricula=639646 AND EsMatricula=1

--SELECT DISTINCT TipoCondicion  FROM Matricula