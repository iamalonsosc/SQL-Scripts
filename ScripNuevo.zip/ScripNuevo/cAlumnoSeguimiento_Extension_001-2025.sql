--����������������������������������������������������������������������������                                                      
--Creado por      : Jimy Mota (14/08/2024)                                                          
--Funcionalidad   : Reporte para monitoreo de alumnos en FC
--Utilizado por   : Equipo de formacion continua        
--����������������������������������������������������������������������������           
/*    
-----------------------------------------------------------------------------    
Nro FECHA  USUARIO  DESCRIPCION    
-----------------------------------------------------------------------------  
@1	2025.02.19	ALSANCHEZ	Se cambia de fecha de documento a fecha de creacion
*/    
ALTER PROCEDURE [dbo].cAlumnoSeguimiento_Extension_001
AS 
BEGIN

DECLARE @prioridades table (Prioridades Char(2), inicio money, fin money, semaforo char(1))

DECLARE @MIN INT
,@MAX INT
,@IdMatricula INT
,@Idseccion INT
,@IdAlumnoCurso INT
,@IdAlumno  INT
,@FechaMaxAsistencia  VARCHAR(100)
,@UsuarioRegistroAsist VARCHAR(100)
,@NroSesionesAsistidas INT
,@NroSesionesDictadas INT
,@MontoDeuda  VARCHAR(100)
,@CuotasVencidas INT
,@CompaniaSocio VARCHAR(8)

DECLARE @Deuda table (idmatricula int , CuotaNumero int, Monto money )
CREATE TABLE #AlumnoCursoAsistencia (IdAlumno INT ,IdSeccion INT,IdHorario INT,IdSesion INT,valor VARCHAR(100),FechaModificacion VARCHAR(100),UsuarioModificacion VARCHAR(100))
CREATE TABLE #TempSesiones (
    IdSeccion INT,
    Contador INT
);

INSERT INTO @prioridades values ('P1',	0.00 , 50.00	,'R')
INSERT INTO @prioridades values ('P2',	51.00 , 74.00	,'A')
INSERT INTO @prioridades values ('P3',	75.00 , 99.00	,'V')
INSERT INTO @prioridades values ('P4',	100.00 , 100.00	, 'V')

SELECT  @CompaniaSocio=CompaniaSocio  FROM Empresa  WITH(NOLOCK) WHERE IdEmpresa = 1

DECLARE @TABLE TABLE (
ID INT IDENTITY(1,1) PRIMARY KEY
,IdMatricula INT
,IdPromocion INT
,IdGrupo INT
,Idseccion INT
,IdAlumnoCurso INT
,IdAlumno  INT
,GRADO VARCHAR(100)
,NumeroIdentidad VARCHAR(100)
,SedeCodigo VARCHAR(100)
,AlumnoCodigo VARCHAR(100)
,NombreCompleto VARCHAR(100)
,EmailInstitucion VARCHAR(500)
,CorreoPersonal VARCHAR(500)
,Telefono VARCHAR(500)
,FechaMatricula VARCHAR(100)
,PeriodoCodigo VARCHAR(100) 
,PromocionNombre VARCHAR(100) 
,PromocionCodigo VARCHAR(100) 
,SeccionCodigo VARCHAR(100) 
,SeccionFechaInicio VARCHAR(100) 
,SeccionFechaFin VARCHAR(100) 
,PeriodoModulo VARCHAR(50)
,Frecuencia VARCHAR(500) 
,CursoNombre VARCHAR(100) 
,FacilitadorCodigo VARCHAR(80)
,FacilitadorNombre VARCHAR(500)
,OrdenCurso INT
,ModuloFechaInicio VARCHAR(100) 
,ModuloFechaFin VARCHAR(100) 
,NotaPromedioModulo  VARCHAR(100) 
,MontoDeuda  VARCHAR(100) 
,CuotasVencidas INT 
,EstadoMatricula VARCHAR(100) 
,RetiroTipo VARCHAR(100) 
,RetiroFecha VARCHAR(100) 
,MotivoRetiro VARCHAR(100) 
,SubMotivoRetiro VARCHAR(100) 
,FechaMaxAsistencia  VARCHAR(100) 
,UsuarioRegistroAsist VARCHAR(100) 
,NroSesiones INT
,NroSesionesDictadas INT
,NroSesionesAsistidas INT
,PorcentajeAsistencia FLOAT)


CREATE TABLE #DatosSeccion (IdPromocion INT,IdPeriodo INT,IdUnidadAcademica INT,IdUnidadNegocio INT,IdSede INT,IdGrupo INT,IdSeccion INT,IdCurso INT,CodigoAnterior VARCHAR(150),NombreCompletoFacilitador VARCHAR(300),CursoNombre VARCHAR(300),CursoSesion VARCHAR(150),PromocionNombre VARCHAR(300),PromocionCodigo VARCHAR(300) ,CodigoPeriodo VARCHAR(20),GrupoCodigo VARCHAR(100),FechaInicio VARCHAR(12),FechaFin VARCHAR(12),FechaInicioSEC VARCHAR(12),FechaFinSEC VARCHAR(12))

INSERT INTO #DatosSeccion
SELECT P.IdPromocion,P.IdPeriodo,P.IdUnidadAcademica,P.IdUnidadNegocio,P.IdSede,SEC.IdGrupo,SEC.Idseccion,c.IdCurso,f.CodigoAnterior,af.NombreCompleto,c.CursoNombre,SEC.CursoSesion,P.PromocionNombre,P.PromocionCodigo,PE.Codigo,PGS.GrupoCodigo,CONVERT(VARCHAR,PGS.FechaInicio,103),CONVERT(VARCHAR,PGS.FechaFin,103),CONVERT(VARCHAR,SEC.FechaInicio,103),CONVERT(VARCHAR,SEC.FechaFin,103)  FROM Periodo PE
INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPeriodo = PE.IdPeriodo 
INNER JOIN Seccion SEC  WITH(NOLOCK) ON SEC.IdPromocion = P.IdPromocion
INNER JOIN Curso C  WITH(NOLOCK)  ON C.IdCurso = SEC.IdCurso 
INNER JOIN PromocionGrupo PGS  WITH(NOLOCK) ON P.IdPromocion = PGS.IdPromocion AND  SEC.IdGrupo = PGS.IdGrupo 
LEFT JOIN SeccionProfesor SP WITH(NOLOCK)  ON  SP.IdSeccion = SEC.Idseccion AND SP.EsResponsable = 1 
LEFT JOIN Facilitador F WITH(NOLOCK) ON F.IdFacilitador = SP.IdActor 
LEFT JOIN Actor AF WITH(NOLOCK) ON AF.IdActor = F.IdFacilitador 
WHERE P.IdUnidadNegocio = 2 
AND P.IdUnidadAcademica  IN (48,2,54)
AND CONVERT(VARCHAR, SEC.FechaInicio ,112) >= CONVERT(VARCHAR,DATEADD(MONTH, -6 , GETDATE() ) , 112)
AND PE.CODIGO NOT LIKE '%MINEDU'

CREATE INDEX idx_IdPromocion ON #DatosSeccion (IdPromocion,IdGrupo,IdSeccion);

INSERT INTO @TABLE
SELECT DISTINCT  M.IdMatricula
,DS.IdPromocion
,DS.IdGrupo 
,DS.Idseccion 
,ALC.IdAlumnoCurso
,AL.IdAlumno
,'GRADO' = UA.Nombre
,'NumeroIdentidad' = AC.NumeroIdentidad ,
'SedeCodigo' = S.Codigo ,
'AlumnoCodigo' = AL.CodigoAnterior ,
'NombreCompleto' = ac.NombreCompleto , 
'EmailInstitucion' = AL.EmailInstitucion ,
'CorreoPersonal' = DBO.cActorEmailStr(AC.IdActor ),
'Telefono' = DBO.cActorTelefonoStr(AC.IdActor ),
'FechaMatricula' = CONVERT(VARCHAR,M.MatriculaFecha,103), 
'PeriodoCodigo' = DS.CodigoPeriodo ,
'PromocionNombre' = DS.PromocionNombre , 
'PromocionCodigo' = DS.PromocionCodigo , 
'SeccionCodigo' = DS.GrupoCodigo, 
'SeccionFechaInicio' = DS.FechaInicio  ,
'SeccionFechaFin' =  DS.FechaFin   ,
'PeriodoModulo' = DS.CodigoPeriodo ,
'Frecuencia' = DBO.gFrecuenciaSeccionHorario(DS.IdSeccion ),
'CursoNombre' = DS.CursoNombre , 
'FacilitadorCodigo' = ISNULL( DS.CodigoAnterior,'') ,
'FacilitadorNombre' = ISNULL( DS.NombreCompletoFacilitador ,'') ,
'OrdenCurso' = 0,
'ModuloFechaInicio' =  DS.FechaInicioSEC   , 
'ModuloFechaFin' =  DS.FechaFinSEC   ,
'NotaPromedioModulo' = isnull(ALC.PromedioFinal,'') ,
'MontoDeuda' = 0,
'CuotasVencidas' = 0 ,
'EstadoMatricula' = M.Estado  ,
'RetiroTipo' = isnull(MTR.Nombre,'') ,
'RetiroFecha' = isnull(CONVERT(VARCHAR, mr.FechaCreacion , 103),'') , --@1
'MotivoRetiro' =  isnull( MTRM.Nombre ,''),
'SubMotivoRetiro' =  isnull( MTRSM.Nombre ,''),
'FechaMaxAsistencia' = '', 
'UsuarioRegistroAsist' = '',  
'NroSesiones' = DS.CursoSesion,
'NroSesionesDictadas' = 0, 
'NroSesionesAsistidas' = 0,
'PorcentajeAsistencia' = 0  
FROM #DatosSeccion DS WITH(NOLOCK)
INNER JOIN AlumnoCurso ALC  WITH(NOLOCK)  ON ALC.IdPromocion=DS.IdPromocion AND ALC.IdGrupo=DS.IdGrupo AND ALC.IdSeccion=DS.IdSeccion
INNER JOIN Matricula M   ON M.IdMatricula = ALC.IdMatricula
INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = M.IdPromocion 
INNER JOIN Periodo PE  WITH(NOLOCK) ON PE.IDPERIODO = P.IDPERIODO
INNER JOIN UnidadAcademica UA WITH(NOLOCK) ON UA.IdUnidadAcademica = P.IdUnidadAcademica 
INNER JOIN Sede S  WITH(NOLOCK) ON S.IdSede = P.IdSede 
INNER JOIN Actor AC  WITH(NOLOCK) ON AC.IdActor = M.IdActor 
INNER JOIN Alumno AL  WITH(NOLOCK)  ON AL.IdAlumno = AC.IdActor 
LEFT JOIN MatriculaRetiro MR  WITH(NOLOCK)  ON  MR.IdMatricula = M.IdMatricula and MR.estado = 'R' AND MR.Tipo = 'RC'
LEFT JOIN MaestroTablaRegistro MTR  WITH(NOLOCK)  ON MTR.IdMaestroRegistro = MR.IdTipo 
LEFT JOIN MaestroTablaRegistro MTRM  WITH(NOLOCK)  ON MTRM.IdMaestroRegistro = MR.IdMotivo  
LEFT JOIN MaestroTablaRegistro MTRSM  WITH(NOLOCK)  ON MTRSM.IdMaestroRegistro = MR.IdSubMotivo 
WHERE ALC.EsMatricula=1 
AND M.EsMatricula=1 
AND M.Estado <> 'X' 

--CREATE INDEX idx_EstadoDiario ON HorarioSesion (IdSeccion,EstadoDiario,Estado);

INSERT INTO #AlumnoCursoAsistencia
SELECT  DISTINCT ACA.IdAlumno, ACA.IdSeccion , ACA.IdHorario , ACA.IdSesion ,valor , CONVERT(VARCHAR, aca.FechaModificacion, 103) ,u.Login        
FROM @TABLE T 
INNER JOIN HorarioSesion HS  WITH(NOLOCK) ON HS.IdSeccion = T.IdSeccion AND HS.EstadoDiario = 'A' AND HS.Estado = 'P'  
INNER JOIN AlumnoCursoAsistencia ACA  WITH(NOLOCK) ON ACA.IdSeccion = HS.Idseccion AND HS.IdHorario = ACA.IdHorario AND HS.IdSesion = ACA.IdSesion  AND ACA.IdAlumno = T.IdAlumno 
INNER JOIN Usuario u  WITH(NOLOCK) on u.IdUsuario = aca.UsuarioModificacion 

CREATE INDEX idx_Idseccion ON #AlumnoCursoAsistencia (IdSeccion,IdAlumno,valor);

--CREATE INDEX idx_Interfase_Matricula ON CO_Documento (Interfase_Matricula,CompaniaSocio,TipoDocumento,Estado);

INSERT INTO  @Deuda
SELECT DISTINCT  T.IdMatricula , C.Interfase_Cuota , c.MontoTotal
FROM @TABLE T  
INNER JOIN CO_Documento C WITH(NOLOCK) ON  C.Interfase_Matricula=T.IdMatricula  
AND C.CompaniaSocio = @CompaniaSocio 
AND C.TipoDocumento  IN ('PC','BV','FC') 
AND C.Estado = 'PR' 
AND CONVERT(VARCHAR,FechaVencimiento,112) <= CONVERT(VARCHAR,GETDATE(),112) -- FECHA ACTUAL PORQUE SE TRABAJA CON DATA PRUEBA DEL DIA ANTERIOR

		UPDATE B SET B.OrdenCurso = C.Orden  
		 From @TABLE B
		INNER JOIN (
		select T.IDPROMOCION, T.IDGRUPO, t.IDSECCION , ROW_NUMBER() OVER(PARTITION BY T.IDPROMOCION, T.IDGRUPO ORDER BY t.FechaInicio ASC) AS Orden
		from (
		SELECT  
		distinct T.IDPROMOCION, T.IDGRUPO, S.IDSECCION , S.FechaInicio
		FROM @TABLE T 
		INNER JOIN SECCION S ON S.IdPromocion = T.IdPromocion  AND S.IdGrupo = T.IdGrupo
		INNER JOIN SeccionProfesor SP ON SP.IdSeccion = S.Idseccion ) t
		) C ON C.IdPromocion = B.IdPromocion AND C.IdGrupo = B.IdGrupo AND C.Idseccion = B.Idseccion 
	
		INSERT INTO #TempSesiones (IdSeccion, Contador)
		SELECT 
			HS.IdSeccion, 
			COUNT(1) AS Contador
		FROM HorarioSesion HS
		WHERE EXISTS (SELECT 1 FROM @TABLE T WHERE T.IdSeccion = HS.IdSeccion)
		AND HS.EstadoDiario = 'A' AND HS.Estado = 'P'
		GROUP
 BY HS.IdSeccion;

		CREATE INDEX IDX_TempSesiones_IdSeccion ON #TempSesiones(IdSeccion);

		UPDATE T
		SET T.NroSesionesDictadas = TS.Contador
		FROM @TABLE T
		INNER JOIN #TempSesiones TS ON T.IdSeccion = TS.IdSeccion;
		
		UPDATE T SET MontoDeuda = D.Monto  FROM (
		select IdMatricula , SUM( Monto ) Monto
		from @Deuda
		GROUP BY IdMatricula ) D 
		INNER JOIN @TABLE T ON T.IdMatricula = D.idmatricula  
		
		UPDATE T SET T.CuotasVencidas  = D.CuotasVencidas FROM (
		select  IdMatricula ,  COUNT( distinct CuotaNumero ) CuotasVencidas 
		from @Deuda
		GROUP BY IdMatricula ) D 
		INNER JOIN @TABLE T ON T.IdMatricula = D.idmatricula  
		
		SELECT @MIN = MIN (ID) ,@MAX =  MAX(ID) FROM @TABLE

		PRINT CONVERT(VARCHAR, @MIN) 
		PRINT CONVERT(VARCHAR, @MAX)   

WHILE @MIN <= @MAX 
BEGIN

PRINT 'RECORRE: ' + CONVERT(VARCHAR, @MIN) 

	SET @IdMatricula = NULL
	SET @Idseccion = NULL
	SET @IdAlumnoCurso = NULL 
	SET @IdAlumno  = NULL
	set @FechaMaxAsistencia = null 
	set @UsuarioRegistroAsist = null 
	set @NroSesionesAsistidas = null 

	SELECT @IdMatricula =  IdMatricula , 
	@Idseccion = Idseccion ,  
	@IdAlumnoCurso  = IdAlumnoCurso  , 
	@IdAlumno = IdAlumno  
	FROM @TABLE WHERE ID = @MIN
 
	SELECT TOP 1 @UsuarioRegistroAsist =  UsuarioModificacion , 
	@FechaMaxAsistencia = FechaModificacion
	FROM #AlumnoCursoAsistencia aca
	WHERE IdSeccion = @Idseccion AND IdAlumno = @IdAlumno AND valor in ('A','J','T')

	SELECT @NroSesionesAsistidas = COUNT(1) FROM #AlumnoCursoAsistencia
	WHERE IdSeccion = @Idseccion AND IdAlumno = @IdAlumno 	AND valor in ('A','J','T')

	UPDATE @TABLE SET  
	UsuarioRegistroAsist = isnull(@UsuarioRegistroAsist,''), 
	FechaMaxAsistencia = isnull(@FechaMaxAsistencia,'') , 
	NroSesionesAsistidas = isnull(@NroSesionesAsistidas,0)
	WHERE ID = @MIN 

	SET @MIN = @MIN + 1
END 

UPDATE @TABLE SET PorcentajeAsistencia  =  ( case when EstadoMatricula = 'R' then 0 
													  else case when isnull( NroSesionesDictadas,0) = 0 then 0.00 
														 else convert(money, ( convert(money,isnull(NroSesionesAsistidas,0) )/convert(money, isnull( NroSesionesDictadas,0))) ) 
														 end  end ) * 100

SELECT DISTINCT  --t.IdMatricula  ,--t.IdPromocion , t.IdGrupo  , t.Idseccion  ,
T.GRADO				 
,T.NumeroIdentidad		
,T.SedeCodigo			
,T.AlumnoCodigo			
,T.NombreCompleto		
,T.EmailInstitucion		
,T.CorreoPersonal		
,T.Telefono		
,T.FechaMatricula
,T.PeriodoCodigo			
,T.PromocionNombre
--,T.PromocionCodigo		
,T.SeccionCodigo			
,T.SeccionFechaInicio	
,T.SeccionFechaFin	
,t.PeriodoModulo 	
,T.Frecuencia		
,T.CursoNombre
,t.FacilitadorCodigo 
,t.FacilitadorNombre 			
,T.OrdenCurso			
,T.ModuloFechaInicio		
,T.ModuloFechaFin		
,T.NotaPromedioModulo	
,T.MontoDeuda			
,T.CuotasVencidas		
,T.EstadoMatricula		
,T.RetiroTipo			
,T.RetiroFecha			
,T.MotivoRetiro			
,T.SubMotivoRetiro		
,T.FechaMaxAsistencia	
,T.UsuarioRegistroAsist
,T.NroSesiones			
,T.NroSesionesDictadas
,T.NroSesionesAsistidas
,'PorcentajeAsistencia' =  Round( PorcentajeAsistencia  , 2 ) 
,'Prioridades' = CASE WHEN T.NroSesionesDictadas  = 0 or EstadoMatricula = 'R' THEN ' - ' ELSE ISNULL( P.Prioridades, '-') END 
,'semaforo' = CASE WHEN T.NroSesionesDictadas = 0 or EstadoMatricula = 'R' THEN ' - ' ELSE ISNULL(P.semaforo,'-')  END
 FROM @TABLE T
 LEFT JOIN @prioridades P ON Round( PorcentajeAsistencia  , 2 )  BETWEEN inicio AND fin 



DROP TABLE #DatosSeccion
DROP TABLE #AlumnoCursoAsistencia
DROP TABLE #TempSesiones

END
