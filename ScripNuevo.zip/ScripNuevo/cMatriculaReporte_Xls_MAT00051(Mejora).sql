-----------------------------------------------------------------------------                  
--Creado por      :Rosa Elena Zacarias(31/05/2012)                        
--Modificado por  :Rosa Zacarias(06/08/2012)                                                           
--Funcionalidad   :Muestra el listado de alumnos matriculados Ventas-@EsMatricula=1.                                                                           
--Utilizado por   :MatriculaReporte.XlsMAT00051                                                                                                              
--  cMatriculaReporte_Xls_MAT00051 1,1,1,1,1,444,10597,-1                            
/*                                                                        
-----------------------------------------------------------------------------                                                                        
Nro		FECHA		USUARIO			DESCRIPCION                                                                        
-----------------------------------------------------------------------------                    
@1		26/06/2018	jnavia			Se cambia el formato a los campos fecha.                    
@2		31.05.2019	LeandroOrdo		ez(Sigcomt) Modificar el TipoCondici n                  
@3		05.09.2019  JRAVICHAGUA		Cambios en SELECT se remplaza funcion fecha por convert en matriculafecha                  
@4		27.02.2020	Pdesarrollo		(Gonzalo Pedro) se agrega un campo Periodo                  
@5		19.03.2020	JRAVICHAGUA		Se agrega parametros de entrada Fechas inicio y fin.                  
@6		01.04.2020	JRAVICHAGUA		Se comenta parametros fecha inicio y fin                  
@7		22.11.2021	RSamame			Se quita el campo de EmailAlumno                
@8		02.02.2023	FETORRES		Se agrega columna para saber si se le envio correo de bienvenida al alumno                
@9		29.08.2023	ROTORRES		Se agrega filtro para incluir envio de correos de Virtuales              
@10		15.09.2023	ROTORRES		Se agrega motivo en caso no se envie el correo FC             
@11		24.01.2024	FETORRES		Se agrega distinct para no listar duplicados por el tema de envio de correos.             
@12		27.02.2024	FETORRES		Se coementa campo MatriculaFecha porque ya existe esa columna ademas que trae informacion de inscritofecha.     
@13		07.03.2024	SSILVA			Se aumento en cada variable la cantidad de caracteres.    
@14		27.05.2024	MBUENO			Se aumenta longitud de la variable para que equivalga al retorno de la funcion.     
@15		14.11.2024	JCURE			Se agrega columna ImporteDeuda, se agrega setnocount    
@16		30.01.2025	FETORRES		Se agrega IdMatricula,Idactor  
@17		17.02.2025	ALSANCHEZ		Se agrega el departamento,provincia y distrito por separado  
@18		25.03.2025	ROTORRES		Se agrega columna para saber si se realizo el envio de SMS preventivos
@19		25.04.2025	APORRAS			Se modifica la relacion con la tabla ActorDireccion y Ubigeo a left join porque el departamento, provincia y distrito no son obligados.
@20		18.08.2025	JCURE			Se agrega join con curricula y nuevo campo
@21		29.09.2025	alsanchez		Se modifica la informacion del reporte en base a los correos de bienvenida
@22		28.11.2025	APORRAS			Se agrega periodo de Egreso
@23		24.08.2026	ALSANCHEZ		Se retira la condicion Disponible2, porque no hay necesidad de usarlo con el servicio actual
*/                    
ALTER PROCEDURE [dbo].[cMatriculaReporte_Xls_MAT00051]                    
	--DECLARE                                                                               
	@IdEmpresa INT,                                                                                  
	@IdSede INT,                                                                                  
	@IdFacultad INT,                                                                    
	@IdUnidadNegocio INT,                                                                    
	@IdUnidadAcademica INT,                                                                    
	@IdPeriodo INT,                                        
	@IdProducto INT,                                                                    
	@IdTipoModulo INT,                    
	@IdUsuario INT               
	--@FechaInicio varchar(100),--@5--@6                  
	--@FechaFin varchar(100) --@5  --@6                                                                                              
AS  
BEGIN
	--select @IdEmpresa=1,@IdSede=-1,@IdFacultad=1,@IdUnidadNegocio=2,@IdUnidadAcademica=48,@IdPeriodo=5152,@IdProducto=-1,@IdTipoModulo=-1,@IdUsuario=192744            

	SET DATEFORMAT DMY        
	SET NOCOUNT ON --@15    
        
	CREATE TABLE #TEMP (         
		PromocionCodigo VARCHAR(4000),    --@13    
		Sede VARCHAR(4000),               --@13    
		GrupoCodigo VARCHAR(4000),        --@13    
		ProductoNombre VARCHAR(4000),     --@13    
		SemestreNombre VARCHAR(4000),     --@13    
		HorarioNombre VARCHAR(4000),      --@13    
		TipoTurnoCodigo VARCHAR(100),        
		FechaInicio VARCHAR(100),        
		Ambiente VARCHAR(100),        
		Coordinador VARCHAR(100),         
		--MatriculaFecha VARCHAR(100),        
		Codigo VARCHAR(100),        
		NombreCompleto VARCHAR(100),        
		Telefonos VARCHAR(1000), --@14      
		Emails VARCHAR(1000), --@14        
		DireccionCompleta VARCHAR(1000),--@14       
		TipoDocumentoNombre  VARCHAR(100),        
		NumeroDocumento VARCHAR(100),        
		FechaNacimiento VARCHAR(100),        
		ActorGenero VARCHAR(100),        
		CounterPropietario VARCHAR(100),        
		InscritoFecha VARCHAR(100),  
		FechaEnvioSMS Varchar(100),
		TipoCondicion VARCHAR(100),        
		EstadoMatricula VARCHAR(100),        
		FechaMatricula VARCHAR(100),
		UsuarioNombre VARCHAR(100),        
		UltimoPeriodo VARCHAR(100),        
		Periodo VARCHAR(100),        
		PeriodoCodigo VARCHAR(100),        
		CorreoBienvenida VARCHAR(100),  
		EnvioSMS varchar(100), --@18
		IdMatricula INT,    
		ImporteDeuda VARCHAR(100),--@15     
		Idactor INT,--@16  
		Departamento VARCHAR(100), --@17   
		Provincia VARCHAR(100),  --@17   
		Distrito VARCHAR(100)  --@17  
		,Curricula VARCHAR(100)--@20 
		, PeriodoCodigoEgreso VARCHAR(100)	-- @22
	)            
        
                   
	DECLARE @CodigoPeriodo varchar(10) --@5                  
	SELECT @CodigoPeriodo=Codigo FROM Periodo WHERE IdPeriodo=@IdPeriodo --@5                  
                  
	IF @IdSede=-1 SET @IdSede=0 --@5                  
             
	INSERT INTO #TEMP                                                                                                           
	SELECT DISTINCT  'PromocionCodigo'=P.PromocionCodigo     --@11          
		,SED.NOMBRE AS Sede                                           
		,PG.GrupoCodigo                                                                            
		,'ProductoNombre'=PR.ProductoNombre                                                             
		,'SemestreNombre'=ISNULL(CM.Nombre,P.PromocionNombre)                     
		,'HorarioNombre'=PG.DiaClaseTexto+' '+dbo.gHhMmStr(PG.HoraInicio)+' - '+dbo.gHhMmStr(PG.HoraFin)  +  ISNULL(CASE RIGHT(DiaClaseTexto,3) WHEN 'Sab' THEN ' - ' + RIGHT(T.Nombre,10)  END,'')                                           
		,'TipoTurnoCodigo'=TT.Codigo   --se cambio a turno cod                                            
		,'FechaInicio'= CONVERT(VARCHAR(10),PG.FechaInicio, 102)--dbo.gFechaStr(PG.FechaInicio) --@1                                                                                                                         
		,'Ambiente'=ISNULL(A.Nombre,'')                                   
		,'Coordinador'= isnull(ACT.NombreCompleto,'') -- ISNULL(USU.Login,'') + ' - '  + ISNULL( USU.Nombres,'')                               
		--,'MatriculaFecha' = ISNULL(rtrim(CONVERT(VARCHAR,M.InscritoFecha,112)),' '),--@3                  
		--, 'MatriculaFecha' = ISNULL(rtrim(dbo.gFecha112Str(M.InscritoFecha)),' '),--M.MatriculaFecha,--@12                                          
		,'Codigo'=ISNULL(AL.CodigoAnterior,''),          
		'NombreCompleto'=ISNULL(AC.NombreCompleto,' '),                                          
		'Telefonos' = ISNULL(dbo.cActorTelefonoStrDilo(AC.idactor,@IdUsuario),' '),   
		'Emails' = ISNULL(dbo.cActorEmailStr(AC.idactor),' '),                                           
		'DireccionCompleta'= ISNULL(dbo.cActorDireccionStr(AC.idactor),' '),                                          
		'TipoDocumentoNombre'= ISNULL(TD.Nombre,' '),                     
		'NumeroDocumento'= ISNULL(AC.NumeroIdentidad,' '),                                           
		'FechaNacimiento'= ISNULL(CONVERT(VARCHAR(10),AC.FechaNacimiento, 102),' '),--ISNULL(dbo.gFechaStr(AC.FechaNacimiento),' '), --@1                                        
		'ActorGenero'=CASE AC.Genero                               
		WHEN 0 THEN 'F'                                            
		ELSE 'M'                                           
		END  ,      
		'CounterPropietario'=dbo.cContacto_Sel_CounterPropietario(M.IDACTOR),                                      
		'InscritoFecha'= CONVERT(VARCHAR(10),M.InscritoFecha, 102),--dbo.gFechaStr(M.InscritoFecha), --@1 
		'FechaEnvioSMS' = '',
		'TipoCondicion'= ISNULL(   CASE  WHEN M.TipoCondicion ='RP' THEN 'Promovido + Curso' --@2                               
		WHEN M.TipoCondicion ='RT' THEN 'Repitencia'                         
		WHEN M.TipoCondicion ='CC' THEN 'Curso Repitencia'  --@2          
		WHEN M.TipoCondicion ='RE' THEN 'Promovido' END,'') ,                            
		'EstadoMatricula'= ISNULL(   CASE  WHEN M.Estado ='X' THEN 'Anulado'                               
		WHEN M.Estado ='R' THEN 'Retiro Ciclo'                                    
		WHEN M.Estado ='N' THEN 'Normal'                                    
		END,'')                           
		--,'EmailAlumno'=AL.EmailInstitucion    --@7                     
		,'FechaMatricula' = CONVERT(VARCHAR(10),M.MatriculaFecha, 102)--dbo.fecha(M.MatriculaFecha) --@1                    
		,'UsuarioNombre'= ISNULL( U.Nombre   ,'')                      
		,'UltimoPeriodo'=''--dbo.cMatricula_Sel_UltimaMatricula_Periodo(M.IdActor,PE.Codigo)                      
		--,'Deuda' = [dbo].[cAlumno_MontoDeudas](AC.IdActor)                    
		, PE.Nombre as Periodo    --@4                  
		,pe.codigo as PeriodoCodigo                  
		,'CorreoBienvenida' = CASE WHEN M.IdPeriodo IS NULL AND P.IdModulo=1 THEN  'NO'  ELSE 'Es secuencial' END   
		,'EnvioSMS' = 'NO'  --@18
		,M.IdMatricula  
		,ISNULL(DeudaTotal.TotalDeudaTotal,0)    
		,M.IdActor --@16  
		,ISNULL(PARSENAME(REPLACE(ISNULL( UB.NombreUnido,''), '-', '.'), 3), SPACE(0)) AS Departamento	--@17   --@19
		,ISNULL(PARSENAME(REPLACE(ISNULL( UB.NombreUnido,''), '-', '.'), 2), SPACE(0)) AS Provincia		--@17   --@19
		,ISNULL(PARSENAME(REPLACE(ISNULL( UB.NombreUnido,''), '-', '.'), 1), SPACE(0)) AS Distrito		--@17   --@19
		,'Curricula'=CU.Codigo--@20
		, ISNULL(PRD.Codigo, '') AS [PeriodoCodigoEgreso]	-- @22
	FROM Matricula M  WITH(nolock)                      
		LEFT JOIN Usuario U WITH(nolock)                      
			ON M.MatriculaIdUsuario=U.IdUsuario                                     
		INNER JOIN PromocionGrupo PG  WITH(nolock)  --@1                                                                        
			ON PG.IdPromocion=M.IdPromocion  --@1                                          
				and pg.IdGrupo = M.IdGrupo                                
		INNER JOIN Actor AC   WITH(nolock)                                                           
			ON M.idActor = AC.IdActor                   
		INNER JOIN SEDE SED WITH(nolock) --@5                  
			ON SED.IDSEDE=M.IDSEDE  --@5                                      
		LEFT JOIN MaestroTablaRegistro TD   WITH(nolock)                                                 
			ON AC.IdDocumentoTipo=TD.IdMaestroRegistro                                              
		LEFT JOIN Alumno AL  WITH(nolock)                                        
			ON AL.IdAlumno = M.IdActor                                        
		INNER JOIN Promocion P WITH(nolock)                   
			ON P.IdPromocion=M.IdPromocion                                                                          
		INNER JOIN Producto PR WITH(nolock) 
			ON P.IdProducto=PR.IdProducto                                                                                  
		LEFT JOIN ambiente A   WITH(nolock)                                                                                                 
			ON PG.idambiente=A.idambiente                                                                               
		LEFT JOIN CurriculaModulo CM  WITH(nolock)                                                                          
			ON CM.IdCurricula=P.IdCurricula                                                                            
				AND CM.IdModulo=P.IdModulo                                                                                             
		LEFT JOIN Turno T  WITH(nolock)                                                                        
			ON PG.IdTurno=T.IdTurno                                                                            
		INNER JOIN MaestroTablaRegistro TT  WITH(nolock)                                                                          
			ON T.IdTipoTurno=TT.IdMaestroRegistro                                                               
		INNER JOIN Periodo PE  WITH(nolock)                       
			ON P.IdPeriodo=PE.IdPeriodo                      
		LEFT join Actor ACT WITH(nolock)                       
			ON PG.IdCoordinador=ACT.IdActor  
		LEFT JOIN ActorDireccion AD WITH(nolock)    --@19
			ON AD.Principal=1 AND AD.Activo=1 AND  M.IdActor=AD.IdActor --@17  
		LEFT JOIN Ubigeo UB WITH(nolock)      --@19
			ON AD.IdUbigeoResidencia = UB.IdUbigeo --@17  
		--LEFT JOIN BDSMTP.dbo.EnvioCorreo EC WITH (NOLOCK)--@8                
			--ON EC.IDMATRICULA = M.IDMATRICULA --@8               
		--LEFT  JOIN Usuario USU                                
			--ON PG.IdCoordinador=USU.IdUsuario         
		----inicio @15    
		LEFT JOIN Curricula CU WITH (NOLOCK)  on CM.IdCurricula=CU.IdCurricula--@20
		LEFT JOIN Egresados EG WITH (NOLOCK) ON M.IdActor = EG.IdAlumno AND M.IdRegistro = EG.IdRegistro AND M.IdCurricula = EG.IdCurricula	-- @22
		LEFT JOIN Periodo PRD ON EG.IdPeriodoEgreso = PRD.IdPeriodo	-- @22
		CROSS APPLY        
		(        
			SELECT SUM(DeudaTotal) AS TotalDeudaTotal        
			FROM (        
			    SELECT SUM(CO.MontoTotal) as DeudaTotal        
			    FROM CO_Documento CO WITH (NOLOCK)                                      
					INNER JOIN PersonaMast AS pe WITH (NOLOCK) ON CO.ClienteNumero = pe.persona         
			    WHERE CO.TipoDocumento NOT IN ('PE', 'NC', 'PC')                                
			      AND ROUND(CO.MontoTotal, 2) <> ROUND(CO.MontoPagado, 2)               
			      AND ROUND(CO.MontoTotal, 2) > 0                               
			      AND CO.Estado = 'PR'          
			      AND CO.Sucursal <> 'SEIS'          
			      AND CO.Interfase_Matricula = ISNULL(M.IdMatricula, '')                
			      AND CONVERT(VARCHAR, CO.FechaVencimiento, 112) < CONVERT(VARCHAR, GETDATE(), 112)            
			    UNION ALL            
			    SELECT SUM(CO.MontoTotal) as DeudaTotal        
			    FROM CO_Documento_ASOC CO WITH (NOLOCK)                                      
					INNER JOIN PersonaMast_ASOC AS pe WITH (NOLOCK) ON CO.ClienteNumero = pe.persona         
			    WHERE CO.TipoDocumento NOT IN ('PE', 'NC', 'PC')                                
			      AND ROUND(CO.MontoTotal, 2) <> ROUND(CO.MontoPagado, 2)               
			      AND ROUND(CO.MontoTotal, 2) > 0                               
			      AND CO.Estado = 'PR'          
			      AND CO.Sucursal <> 'SEIS'          
			      AND CO.Interfase_Matricula = ISNULL(M.IdMatricula, '')                
			      AND CONVERT(VARCHAR, CO.FechaVencimiento, 112) < CONVERT(VARCHAR, GETDATE(), 112)            
			) AS DeudaTotal
		) DeudaTotal    --fin @15    
	WHERE P.IdEmpresa=@IdEmpresa                                                                         
		AND (P.IdSede=@IdSede OR @IdSede=0)  --@5                   
		AND P.IdUnidadAcademica=@IdUnidadAcademica                                   
		AND P.IdUnidadNegocio = @IdUnidadNegocio                                                                    
		AND P.IdFacultad = @IdFacultad                                                                    
		--AND P.IdPeriodo = @IdPeriodo                   
		and (PE.Codigo=@CodigoPeriodo or @CodigoPeriodo IS NULL) --@5                                                                
		AND (P.IdProducto = @IdProducto OR  @IdProducto = -1)                                                                       
		AND (CM.IdTipoModulo=@IdTipoModulo OR @IdTipoModulo=-1)                              
		AND M.EsMatricula=1               
		AND m.Estado <> 'X'  
        
        
	UPDATE M  SET M.CorreoBienvenida= 'SI' 
	FROM #TEMP M        
		INNER JOIN BDSMTP.dbo.EnvioCorreo EC WITH (NOLOCK)--@8                
			ON EC.IDMATRICULA = M.IDMATRICULA        
	WHERE          
		(--EC.CodigoRemitente = 'PROVEEDOR_ITB'           
			EC.estado = 1           
			AND EC.Asunto IN ('Bienvenido a Zegel', 'Bienvenido a IDAT')--@21
			--AND EC.Disponible3 IN ('Bienvenida', 'Bienvenida Diplomados')           
			--AND EC.Disponible2 NOT LIKE '[a-zA-Z]%' --@23
		)       
 
	--INICIO @18
	UPDATE M  SET M.EnvioSMS= 'SI',M.FechaEnvioSMS = convert(varchar,ES.FechaCreacion,102) 
	FROM #TEMP M        
		INNER JOIN BDSMTP.dbo.EnvioSMS ES WITH (NOLOCK)                
			ON ES.Disponible5 = M.IDMATRICULA        
	WHERE          
		ES.NombrePerfil = 'ITBSMS'
		AND Es.Estado = 1
		AND ES.Disponible3 is not null
		--FIN @18
        
	SELECT PromocionCodigo, Sede, GrupoCodigo, ProductoNombre ,SemestreNombre ,HorarioNombre,         
		TipoTurnoCodigo, FechaInicio ,Ambiente ,Coordinador  ,Codigo,        
		NombreCompleto, Telefonos, Emails, DireccionCompleta,Departamento,Provincia,Distrito, TipoDocumentoNombre ,NumeroDocumento,  --@17      
		FechaNacimiento, ActorGenero, CounterPropietario, InscritoFecha ,TipoCondicion,        
		EstadoMatricula, FechaMatricula,FechaEnvioSMS, UsuarioNombre, UltimoPeriodo, Periodo, PeriodoCodigo,        
		CorreoBienvenida,EnvioSMS ,IdMatricula,ImporteDeuda,Idactor   --@15  --@16  
		,Curricula --@20
		, PeriodoCodigoEgreso	-- @22
	FROM #TEMP            
        
	DROP TABLE #TEMP              
	--AND CONVERT(VARCHAR(8),M.MatriculaFecha,112) between @FechaInicio AND @FechaFin --@5 --@6                               
	--ORDER BY   CM.IdTipoModulo

END