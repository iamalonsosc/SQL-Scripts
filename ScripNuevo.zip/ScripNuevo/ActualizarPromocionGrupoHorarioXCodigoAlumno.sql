DECLARE @Min INT, @Max INT, @IdAlumno INT, @IdPromocionMAT INT, @IdPromocionAC INT, @IdGrupoAC INT, @IdMatricula INT,
@CodigoAlumno VARCHAR(50),@PromocionCodigoMat VARCHAR(50), @PromocionCodigoAC VARCHAR(50), @SeccionCodigoAC VARCHAR(50),
@MinAC INT, @MaxAC INT, @IdAlumnoCurso INT, @IdRegistro INT, @IdCurso INT, @IdSeccion INT,@Resultado CHAR(2), @Observacion VARCHAR(200)

DECLARE @AlumnoCurso AS TABLE
(
	Id INT IDENTITY,
	IdAlumnoCurso INT,
	IdRegistro INT,
	IdCurso INT
)

DECLARE @Table AS TABLE
(
	Id INT IDENTITY,
	CodigoAlumno VARCHAR(50),
	PromocionCodigoMat VARCHAR(50),
	PromocionCodigoAC VARCHAR(50),
	SeccionCodigoAC VARCHAR(50),
	Resultado CHAR(2),
	Observacion VARCHAR(200)
)
INSERT INTO @Table (CodigoAlumno,PromocionCodigoMat,PromocionCodigoAC,SeccionCodigoAC) VALUES
('WI42429652','PT.0214.I.2023-IIK','SV.0214.I.2023-IIK','I.06.2023-IIK'),
('PT47874759','PT.0214.I.2023-IIK','SV.0214.I.2023-IIK','I.06.2023-IIK'),
('SM76314801','SM.0217.I.2023-IIK','SV.0217.I.2023-IIK','I.10.2023-IIK'),
('CH72669719','CH.0208.I.2023-IIK','SV.0208.I.2023-IIK','I.24.2023-IIK'),
('CH74592602','CH.0212.I.2023-IIK','SV.0212.I.2023-IIK','I.13.2023-IIK'),
('AT003580585','AT.0215.I.2023-IIK','SV.0215.I.2023-IIK','I.07.2023-IIK'),
('PT73376390','PT.0210.I.2023-IIK','SV.0210.I.2023-IIK','I.03.2023-IIK'),
('AT72450134','AT.0211.I.2023-IIK','SV.0211.I.2023-IIK','I.01.2023-IIK'),
('PT07494345','PT.0215.I.2023-IIK','SV.0215.I.2023-IIK','I.07.2023-IIK'),
('A17001427','AT.0208.I.2023-IIK','SV.0208.I.2023-IIK','I.07.2023-IIK'),
('AT72126756','AT.0215.I.2023-IIK','SV.0215.I.2023-IIK','I.07.2023-IIK'),
('LN43172358','LN.0209.I.2023-IIK','SV.0209.I.2023-IIK','I.02.2023-IIK'),
('LN46648187','LN.0209.I.2023-IIK','SV.0209.I.2023-IIK','I.02.2023-IIK'),
('LN72284822','LN.0208.I.2023-IIK','SV.0208.I.2023-IIK','I.07.2023-IIK'),
('LN73983498','LN.0209.I.2023-IIK','SV.0209.I.2023-IIK','I.02.2023-IIK'),
('LN76502928','LN.0217.I.2023-IIK','SV.0217.I.2023-IIK','I.10.2023-IIK'),
('PI48281079','PI.0208.I.2023-IIK','SV.0208.I.2023-IIK','I.07.2023-IIK'),
('PT70873673','PT.0210.I.2023-IIK','SV.0210.I.2023-IIK','I.17.2023-IIK'),
('SM47499021','SM.0208.I.2023-IIK','SV.0208.I.2023-IIK','I.07.2023-IIK'),
('SM61960255','SM.0210.I.2023-IIK','SV.0210.I.2023-IIK','I.03.2023-IIK'),
('AT70317919','AT.0208.I.2023-IIK','SV.0208.I.2023-IIK','I.35.2023-IIK'),
('SM62169329','PT.0217.I.2023-IIK','SV.0217.I.2023-IIK','I.10.2023-IIK'),
('A19107076','SM.0215.I.2023-IIK','SV.0215.I.2023-IIK','I.21.2023-IIK')





--SELECT * FROM @Table RETURN 

SELECT @Min = MIN(Id), @Max = MAX(Id) FROM @Table

UPDATE @Table SET
Resultado = 'OK',
Observacion = 'Procesado'

WHILE @Min <= @Max 
BEGIN
	
	SET @CodigoAlumno = NULL
	SET @PromocionCodigoMat = NULL
	SET @PromocionCodigoAC = NULL
	SET @SeccionCodigoAC = NULL
	SET @IdMatricula = NULL
	SET @IdPromocionAC = NULL
	SET @IdPromocionMAT = NULL
	SET @IdAlumno = NULL
	SET @IdGrupoAC = NULL
	SET @Resultado = NULL
	SET @Observacion = NULL

	SELECT	@CodigoAlumno = CodigoAlumno,
			@PromocionCodigoMat = PromocionCodigoMat,
			@PromocionCodigoAC = PromocionCodigoAC,
			@SeccionCodigoAC = SeccionCodigoAC
	FROM @Table
	WHERE Id =@Min
	
	IF NOT EXISTS(SELECT DISTINCT 1 FROM Usuario WITH(NOLOCK) WHERE Login = @CodigoAlumno)
	BEGIN
		SET @Resultado = 'KO'
		SET @Observacion = 'No existe Alumno ' + @CodigoAlumno
	END
	ELSE 
	BEGIN
		SET @IdAlumno = (SELECT IdActor FROM Usuario WITH(NOLOCK) WHERE Login = @CodigoAlumno)
	END
	
	IF NOT EXISTS(SELECT DISTINCT 1 FROM Promocion WITH(NOLOCK) WHERE PromocionCodigo = @PromocionCodigoMat)
	BEGIN
		SET @Resultado = 'KO'
		SET @Observacion = 'No existe promoci�n Cabecera ' + @PromocionCodigoMat
	END
	ELSE 
	BEGIN
		SET @IdPromocionMAT = (SELECT IdPromocion FROM Promocion WITH(NOLOCK) WHERE PromocionCodigo = @PromocionCodigoMat)
	END

	IF NOT EXISTS(SELECT DISTINCT 1 FROM Matricula WITH(NOLOCK) WHERE IdActor = @IdAlumno AND IdPromocion= @IdPromocionMAT AND Estado != 'X')
	BEGIN
		SET @Resultado = 'KO'
		SET @Observacion = 'No existe matricula de alumno ' + @CodigoAlumno + ' '+ @PromocionCodigoMat
	END
	ELSE 
	BEGIN
		SELECT @IdMatricula = IdMatricula FROM Matricula WITH(NOLOCK) WHERE IdActor = @IdAlumno AND IdPromocion= @IdPromocionMAT AND Estado != 'X'
	END

	IF NOT EXISTS(SELECT DISTINCT 1 FROM Promocion WITH(NOLOCK) WHERE PromocionCodigo = @PromocionCodigoAC)
	BEGIN
		SET @Resultado = 'KO'
		SET @Observacion = 'No existe promoci�n Detalle ' + @PromocionCodigoAC
	END
	ELSE 
	BEGIN
		SELECT @IdPromocionAC = IdPromocion FROM Promocion WITH(NOLOCK) WHERE PromocionCodigo = @PromocionCodigoAC
	END

	IF NOT EXISTS(SELECT DISTINCT 1 FROM PromocionGrupo WITH(NOLOCK) WHERE IdPromocion = @IdPromocionAC AND GrupoCodigo = @SeccionCodigoAC)
	BEGIN
		SET @Resultado = 'KO'
		SET @Observacion = 'No existe seccion ' + @SeccionCodigoAC
	END
	ELSE
	BEGIN
		SET @IdGrupoAC = (SELECT IdGrupo FROM PromocionGrupo WITH(NOLOCK) WHERE IdPromocion = @IdPromocionAC AND GrupoCodigo = @SeccionCodigoAC)
	END

	IF NOT EXISTS(SELECT DISTINCT 1 FROM Seccion WITH(NOLOCK) WHERE IdPromocion = @IdPromocionAC AND IdGrupo= @IdGrupoAC)
	BEGIN
		SET @Resultado = 'KO'
		SET @Observacion = 'No existe Horario ' + @PromocionCodigoAC + ' ' + @SeccionCodigoAC
	END
	
	IF @Resultado IS NOT NULL
	BEGIN
		UPDATE @Table SET
		Resultado = @Resultado,
		Observacion =@Observacion
		WHERE Id = @Min
	END
	ELSE
	BEGIN

		DELETE FROM @AlumnoCurso
		INSERT INTO @AlumnoCurso 
		SELECT IdAlumnoCurso, IdRegistro,IdCurso  FROM AlumnoCurso WITH(NOLOCK) WHERE IdMatricula =@IdMatricula

		SELECT @MinAC = MIN(Id), @MaxAC = MAX(Id) FROM @AlumnoCurso
		WHILE @MinAC <= @MaxAC
		BEGIN
			SET @IdAlumnoCurso = NULL
			SET @IdRegistro = NULL
			SET @IdCurso = NULL
			SET @IdSeccion = NULL

			SELECT	@IdAlumnoCurso =IdAlumnoCurso,
					@IdRegistro = IdRegistro,
					@IdCurso = IdCurso 
			FROM @AlumnoCurso
			WHERE Id = @MinAC

			SET @IdSeccion = (SELECT TOP 1 IdSeccion FROM Seccion WITH(NOLOCK) WHERE IdPromocion = @IdPromocionAC AND IdGrupo = @IdGrupoAC AND IdCurso = @IdCurso AND IdTipoModalidad =29690)

			EXEC cAlumnoCurso_Upd_Actualizar @IdAlumno,@IdRegistro,@IdAlumnoCurso,NULL,NULL,NULL,@IdPromocionAC,@IdGrupoAC,@IdSeccion,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL

			SET @MinAC = @MinAC + 1
		END 
	END
	SET @Min = @Min + 1
END

SELECT T.CodigoAlumno, A.NombreCompleto,MTR.Nombre AS NombreTipoTurno,MTR.Codigo AS CodigoTipoTurno, TU.Codigo AS CodigoTurno,
T.PromocionCodigoMat PromocionCabecera,T.PromocionCodigoAC PromocionDetalle,SeccionCodigoAC SeccionDetalle,Resultado,T.Observacion FROM @Table T
LEFT JOIN Usuario U WITH(NOLOCK) ON  T.CodigoAlumno = U.Login
LEFT JOIN Actor A WITH(NOLOCK) ON U.IdActor = A.IdActor
LEFT JOIN Promocion P WITH(NOLOCK) ON T.PromocionCodigoAC = P.PromocionCodigo
LEFT JOIN PromocionGrupo PG WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion AND T.SeccionCodigoAC = PG.GrupoCodigo
LEFT JOIN Turno TU WITH(NOLOCK)ON PG.IdTurno = TU.IdTurno
LEFT JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON TU.IdTipoTurno = MTR.IdMaestroRegistro
