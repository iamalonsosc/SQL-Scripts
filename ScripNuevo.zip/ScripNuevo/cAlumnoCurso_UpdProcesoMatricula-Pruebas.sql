--����������������������������������������������������������������������������                          
--Creado por      : Carlos Huallpa(29/10/2009)                          
--Funcionalidad   : Permite actualizar un registro en la tabla facilitador                          
--Utilizado por   : Facilitador.UpdActualizar                          
--����������������������������������������������������������������������������                          
/*                      
-----------------------------------------------------------------------------                      
Nro  FECHA  USUARIO  DESCRIPCION                      
-----------------------------------------------------------------------------                      
@1  06.10.2011 jvilla  se agrego el campo IdUsuario                   
@2  22.03.2012 rgalvez  se agrego el la ejecuci�n del sp SP_SincronizacionBiblioteca              
@3  06.08.2013 lperales mejora en el proceso de matricula         
@4  21.07.2014 lperales se agrega validacion de asistencia al examen de admision     
@5  11.01.2019  Eloy Alva (Sigcomt) Agregar parametro Compania.    
@6  27.01.2020  PUchuya  Se modifica logica para cursos libres.    
@7  07.07.2020  PUchuya  Se quita isnull para cursos libres    
@8 15.12.2023 mbueno  Se agregan validaciones secciones y envio correo    
@9 22.02.2024 mbueno  Se quita la restriccion del envio de correo    
@10 11.12.2024 rotorres Se validan aforos para migracion de seccion comercial a normal  
*/                           
--CREATE PROCEDURE [dbo].[cAlumnoCurso_UpdProcesoMatricula]    
declare 
@IdEmpresa INT,                    
@IdSede INT,                    
@IdFacultad INT,                    
@IdUnidadNegocio INT,                    
@IdUnidadAcademica INT,                   
@IdPeriodo INT,                    
@IdProducto INT,                    
@IdPromocion INT,                    
@IdGrupo INT,                    
@IdAlumno INT,                    
@IdUsuario INT                  
--AS                    
BEGIN                  
 SET NOCOUNT ON       
                select @IdEmpresa=1,@IdSede=50,@IdFacultad=1,@IdUnidadNegocio=1,@IdUnidadAcademica=57,@IdPeriodo=4276,@IdProducto=11883,@IdPromocion=101881,@IdGrupo=5,@IdAlumno=1847489,@IdUsuario=446639
 -- @5 inicio     
 DECLARE @CompaniaSocio CHAR(8)    
 SELECT @CompaniaSocio = CompaniaSocio  FROM Empresa e WITH(NOLOCK)    
 WHERE E.IdEmpresa=@IdEmpresa     
 -- @5 fin              
    
 CREATE TABLE #Matricula (                  
  Id INT IDENTITY,                  
  IdMatricula int,                  
  PromocionIdEmpresa INT,                    
  PromocionIdSede INT,                    
  PromocionIdFacultad INT,                    
  PromocionIdUnidadNegocio INT,                    
  PromocionIdUnidadAcademica INT,                   
  PromocionIdPeriodo INT,                    
  PromocionIdProducto INT,                    
  ProductoNombre VARCHAR(250),                    
  IdPromocion INT,                    
  IdRegistro INT,                    
  PromocionNombre VARCHAR(250),                    
  IdGrupo INT,                    
  GrupoCodigo VARCHAR(250),               
  CodigoAlumno VARCHAR(20),                       
  ActorIdActor INT,                  
  ActorNombreCompleto VARCHAR(250),                  
  IdDocumentoTipo INT,                
  NumeroIdentidad VARCHAR(20),                
  Observacion VARCHAR(8000),                
  InscritoFecha date,               
  IdProcedencia INT,               
  Estado VARCHAR(100),              
  Orden INT,    
  IdTipoTurno INT --@Max    
  )                  
                 
 --SE CARGA TODA LA POBLACI�N DE ALUMNOS MATRICULADOS SEGUN LOS CRITERIOS                  
 --si el proceso no es por secci�n, se va a la cabecera de matricula                  
 BEGIN                  
  INSERT INTO #Matricula                  
  (InscritoFecha,PromocionIdEmpresa,PromocionIdSede,PromocionIdFacultad,PromocionIdUnidadNegocio, PromocionIdUnidadAcademica,    
  PromocionIdPeriodo,PromocionIdProducto,IdPromocion,IdGrupo,ActorIdActor,IdMatricula,IdRegistro,IdProcedencia,Orden)                  
  SELECT M.InscritoFecha,P.IdEmpresa,P.IdSede,P.IdFacultad,P.IdUnidadNegocio,P.IdUnidadAcademica,P.IdPeriodo,               
  P.IdProducto,M.IdPromocion,M.IdGrupo,M.IdActor,M.IdMatricula, M.IdRegistro, ISNULL(M.IdProcedencia,0),ISNULL(CM.Orden,1)  --@6  --@7           
  FROM Matricula M with(nolock)                  
  INNER JOIN Promocion P  with(nolock)            
  ON M.IdPromocion=P.IdPromocion                  
  LEFT JOIN CurriculaModulo CM with(nolock)  --@6             
  ON M.IdCurricula = CM.IdCurricula              
  AND M.IdModulo = CM.IdModulo              
  WHERE P.IdEmpresa=@IdEmpresa        
  AND P.IdSede=@IdSede                   
  AND P.IdFacultad=@IdFacultad        
  AND P.IdUnidadNegocio=@IdUnidadNegocio                   
  AND P.IdUnidadAcademica=@IdUnidadAcademica                   
  AND P.IdPeriodo=@IdPeriodo                  
  AND (P.IdProducto=@IdProducto OR @IdProducto=0)                   
  AND (M.IdPromocion=@IdPromocion OR @IdPromocion=0)                   
  AND (M.IdGrupo=@IdGrupo OR @IdGrupo=0)                  
  AND (M.IdActor=@IdAlumno OR @IdAlumno=0)                  
  AND M.Estado<>'X'                  
  AND M.IdPeriodo is null            
  --AND M.EsMatricula=0            
  --and m.IdActor = 611768        
  ORDER BY M.InscritoFecha ASC                
 END                  
                  
 --SE CARGAN LAS DESCRIPCIONES DE CADA ALUMNO-CURSO                  
 UPDATE M                  
 SET M.ProductoNombre= RTRIM(P.ProductoCodigo)+'-'+ RTRIM(P.ProductoNombre) ,                    
 M.PromocionNombre = RTRIM(PR.PromocionCodigo)+'-'+ RTRIM(PR.PromocionNombre) ,                      
 M.GrupoCodigo = RTRIM(PG.GrupoCodigo), --@6  --@7                  
 M.ActorNombreCompleto =RTRIM(A.NombreCompleto),                
 M.IdDocumentoTipo=isnull(A.IdDocumentoTipo,''),                
 M.NumeroIdentidad=isnull(A.NumeroIdentidad,''),               
 M.CodigoAlumno = isnull(AL.CodigoAnterior,''),       
 M.IdTipoTurno = isnull(T.IdTipoTurno, 0) --@8    
 FROM #Matricula M                  
 LEFT OUTER JOIN Producto P with(nolock) ON M.PromocionIdProducto=P.IdProducto                  
 LEFT OUTER JOIN Promocion PR with(nolock) ON M.IdPromocion=PR.IdPromocion                  
 LEFT OUTER JOIN PromocionGrupo PG with(nolock) ON  M.IdPromocion=PG.IdPromocion AND M.IdGrupo=PG.IdGrupo                  
 LEFT OUTER JOIN Actor A with(nolock) ON M.ActorIdActor=A.IdActor                  
 LEFT OUTER JOIN Alumno AL with(nolock) ON AL.IdAlumno=A.IdActor    
 LEFT JOIN Turno T with(nolock) ON T.IdTurno=PG.IdTurno       
             
 --se carga el parametro que Define lo que se va a validar por unidad acad�mica                
 -- valor = 1 valida pago, en caso contrario no se valida pago                
 -- valor2 = 1 valida documentos, en caso contrario no se valida documentos      
 -- valor3 = 1 valida que haya asistido al examen de admision              
 DECLARE @ValidaPago INT,      
   @ValidaDocumentos INT,                
   @ValidaExamen INT,    
   @IdTipoTurno INT --@8    
                 
 SELECT @ValidaPago=isnull(PUA.Valor,1),     
 @ValidaDocumentos=isnull(PUA.Valor2,0),    
 @ValidaExamen=isnull(PUA.Valor3,0)              
 FROM ParametroUnidadAcademica PUA WITH (NOLOCK)                    
 WHERE PUA.IdEmpresa=@IdEmpresa                    
 AND PUA.IdSede=@IdSede                    
 AND PUA.IdFacultad=@IdFacultad                
 AND PUA.IdUnidadNegocio=@IdUnidadNegocio                    
 AND PUA.IdUnidadAcademica=@IdUnidadAcademica                    
 AND PUA.Nombre='ProcesoMatricula'                    
                   
 DECLARE @ERRORCODIGO INT,                
   @DESCRIPCIONERROR VARCHAR(8000),                
   @CurIdGrupo INT,                 
   @CurIdAlumno INT,                 
   @CurIdPromocion INT,                
   @CurIdMatricula INT,                
   @CurIdRegistro INT,                
   @CurCodigoAlumno VARCHAR(20),              
   @EstadoMatricula VARCHAR(100) ,               
   @CurNumeroDocumento VARCHAR(20),              
   @CurID INT,                 
   @MaxID INT,              
   @pLogin VARCHAR(20),    
   @CodigoAlumno VARCHAR(20),              
   @CurIdProcedencia INT,              
   @CurOrden INT,          
   @IdDocumentoTipo INT,      
   @CodigoSede varchar(2),      
   @Count int ,      
   @Login VARCHAR(25)           
                   
 SELECT @CurID=1, @MaxID=Max(Id) FROM #Matricula                  
               
 WHILE  @CurID <= @MaxID                
 BEGIN                  
  SET @CodigoAlumno=''      
  SET @IdTipoTurno = NULL --@8    
            
  --sacamos los datos por cada alumno        
  SELECT @CurIdGrupo=IdGrupo,@CurIdAlumno=ActorIdActor,               
  @CurIdPromocion=IdPromocion, @CurIdMatricula = IdMatricula,                
  @CurIdRegistro = idRegistro , @CurCodigoAlumno = CodigoAlumno ,               
  @CurNumeroDocumento = NumeroIdentidad,               
  @CurIdProcedencia = IdProcedencia, @CurOrden = Orden ,          
  @IdDocumentoTipo = IdDocumentoTipo,    
  @IdTipoTurno = IdTipoTurno --@8        
  FROM #Matricula                  
  WHERE Id=@CurID                  
    
  --SE REINICIA LA VARIABLE ERROR                   
  SET @DESCRIPCIONERROR='Ok'                  
  SET @ERRORCODIGO=0                
  SET @EstadoMatricula = 'Matricula Completa'              
                  
  -- validamos que tenga numero de documento                     
  IF (@IdDocumentoTipo = 25 AND (ISNUMERIC(@CurNumeroDocumento)=0 OR LEN(@CurNumeroDocumento)<>8))        
   BEGIN          
      SET @DESCRIPCIONERROR='La Persona '+ convert(varchar(50),@CurIdAlumno)+' no tiene registrado n�mero de documento v�lido o debe actualizar el documento (' + @CurNumeroDocumento + ')'                  
      SET @EstadoMatricula = 'No Matriculado'              
   END          
  ELSE IF  (@IdDocumentoTipo=27 AND (isnull(@CurNumeroDocumento,'') = '' OR  ISNUMERIC(SUBSTRING(@CurNumeroDocumento,1,2))=0 ))       
    BEGIN              
      SET @DESCRIPCIONERROR='La Persona '+ convert(varchar(50),@CurIdAlumno)+' no tiene registrado n�mero de documento o debe actualizar el documento (' + @CurNumeroDocumento + ')'                  
      SET @EstadoMatricula = 'No Matriculado'              
    END           
  ELSE IF  (@IdDocumentoTipo=357 AND (isnull(@CurNumeroDocumento,'') = '' OR  ISNUMERIC(SUBSTRING(@CurNumeroDocumento,1,2))=0 ))      
    BEGIN              
      SET @DESCRIPCIONERROR='La Persona '+ convert(varchar(50),@CurIdAlumno)+' no tiene registrado n�mero de documento o debe actualizar el documento (' + @CurNumeroDocumento + ')'                  
      SET @EstadoMatricula = 'No Matriculado'              
    END              
ELSE              
 BEGIN              
      -- NO DEBE VALIDAR DEUDAS DE ESTE ALUMNO LA PROCEDENCIA = 1              
      IF @CurIdProcedencia = 0               
  BEGIN              
    ----SE VALIDA QUE EL ALUMNO NO TENGA DEUDAS                
    IF @ValidaPago=1                 
      BEGIN                  
       -- PERMISO DE MATRICULA PARA PODER MATRICULARSE CON DEUDAS              
        IF dbo.cAutorizacionAlumno_Val_Existe(@IdEmpresa,@IdSede,@IdFacultad,@IdUnidadNegocio,@IdUnidadAcademica,                   
          @IdPeriodo,@CurIdAlumno,1035) = 0              
       BEGIN              
         -- Llamar a la funci�n que valida si el alumno tiene deudas con la instituci�n de spring              
         IF dbo.cMatricula_Val_Pago_Cuota(@CurIdMatricula,@CompaniaSocio) = 0  --@5              
         BEGIN              
          SET @ERRORCODIGO = 1                 
          SET @EstadoMatricula = 'No Matriculado'                
          SET @DESCRIPCIONERROR='No ha cancelado su cuota de matr�cula'               
         END               
         ELSE              
         BEGIN              
          SET @ERRORCODIGO=0                
         END               
       END                 
      END               
  END                  
                   
    --SE VALIDA QUE EL ALUMNO HAYA ENTREGADO TODOS LOS DOCUMENTOS                  
      IF @ERRORCODIGO=0 AND @ValidaDocumentos=1                 
  BEGIN                  
     -- SI ES DE PRIMER CICLO SOLO SE DEBE VALIDAR ESTO              
     IF @CurOrden = 1               
   BEGIN              
      -- PERMISO DE MATRICULA PARA PODER MATRICULARSE CON DOCUMENTOS PENDIENTES              
    IF dbo.cAutorizacionAlumno_Val_Existe(@IdEmpresa,@IdSede,@IdFacultad,@IdUnidadNegocio,@IdUnidadAcademica,                   
         @IdPeriodo,@CurIdAlumno,1036) = 0              
     BEGIN              
     EXEC cRegistroProductoRequisito_Val_Pendientes @CurIdAlumno,@CurIdRegistro, @ERRORCODIGO OUT                
                          
     IF @ERRORCODIGO = 1 -- tienen documentos pendientes                
      BEGIN        
      SET @DESCRIPCIONERROR = 'Tiene documentos pendientes'                  
      SET @EstadoMatricula = 'No Matriculado'                
      END                
     END              
   END       
    END        
      
     --SE VALIDA QUE EL ALUMNO HAYA asistido al examen de admision               
      IF @ERRORCODIGO=0 AND @ValidaExamen=1                 
  BEGIN                  
     -- SI ES DE PRIMER CICLO SOLO SE DEBE VALIDAR ESTO              
     IF @CurOrden = 1               
   BEGIN              
             
     EXEC cAlumnoAsistenciaAdmision_Val_Asistencia @CurIdAlumno,@IdPeriodo, @ERRORCODIGO OUT                
                          
     IF @ERRORCODIGO = 1 -- el alumno no ha asistido al examen de admision programado                
      BEGIN                
      SET @DESCRIPCIONERROR = 'El alumno no ha asistido al examen de admisi�n programado'                  
      SET @EstadoMatricula = 'No Matriculado'                
      END                
            
   END                 
    END        
          
       --  validamos si existe un usuario ya registrado con otro contacto            
     IF @ERRORCODIGO=0                  
  BEGIN          
    SET @Count =  0      
        
   SELECT @Count = COUNT(1)      
   FROM Usuario WITH(NOLOCK)                  
   WHERE IdActor = @CurIdAlumno       
   AND IdTipoUsuario = 1  -- usuario de tipo alumno          
              
   If  @Count = 0      
      BEGIN         
      --  validamos si existe un usuario ya registrado con otro contacto      
     SET @CodigoSede = (SELECT CODIGO FROM Sede WITH(NOLOCK) WHERE IdSede = @IdSede)          
     SET @Login = @CodigoSede+@CurNumeroDocumento      
         
     SELECT @Count = COUNT(1)        
     FROM Usuario WITH(NOLOCK)                  
     WHERE LOGIN=   @Login      
     AND IdTipoUsuario = 1  -- usuario de tipo alumno       
            
     If  @Count > 0      
       BEGIN                
        SET @DESCRIPCIONERROR = 'Ya existe un c�digo de usuario asignado a otra persona '    +@Login              
        SET @EstadoMatricula = 'No Matriculado'          
        SET @ERRORCODIGO = 1                
     END                  
    END      
  END    
    
 --Inicio @8    
 IF @ERRORCODIGO = 0    
 BEGIN    
  DECLARE @TipoSeccion Varchar(20)= '',    
    @vTipoSeccion VARCHAR(1),    
    @IdTipoSeccionNormal INT,            
    @IdTipoSeccionComercial INT,            
    @IdTipoSeccionBeca INT,    
    @ListaBecaAmerica VARCHAR(200),     
    @FechaLimiteBeca VARCHAR(20)    
       
  SELECT @vTipoSeccion=ISNULL(Valor,'0') FROM Parametro  WITH(NOLOCK) WHERE Nombre='MatriculaTipoSeccion'    
  SET @IdTipoSeccionNormal=(SELECT IdMaestroRegistro FROM MaestroTablaRegistro  WITH(NOLOCK) WHERE IdMaestroTabla=2060 and Codigo='Normal')            
  SET @IdTipoSeccionBeca=(SELECT IdMaestroRegistro FROM MaestroTablaRegistro  WITH(NOLOCK) WHERE IdMaestroTabla=2060 and Codigo='BECA')    
  SELECT @ListaBecaAmerica=ISNULL(Valor,'0'),@FechaLimiteBeca=ISNULL(Valor2,'0') FROM Parametro WITH(NOLOCK) WHERE Nombre='GrupoBecaAmerica'    
            
  IF @vTipoSeccion='1' AND @IdUnidadNegocio=1   --TipoSeccion Solo carreras            
  BEGIN              
   IF EXISTS (SELECT  1 FROM DescuentoAlumnoResultado DAR WITH(NOLOCK) WHERE IdMatricula=@CurIdMatricula             
    AND GrupoDescuento IN ( SELECT DISTINCT txt_value FROM dbo.uf_Parse(@ListaBecaAmerica,',') ))              
   AND EXISTS (Select  1 FROM Periodo P WITH(NOLOCK)              
    WHERE IdPeriodo=@IdPeriodo AND convert(varchar,inicio,112)< @FechaLimiteBeca)                  
                  
   BEGIN               
    --Seccion BECA                
    SET @CurIdGrupo= (SELECT  Top 1 IdGrupo From PromocionGrupo PG WITH(NOLOCK)            
    INNER JOIN Turno T WITH(NOLOCK) ON T.IdTurno=PG.IdTurno WHERE PG.IdPromocion=@CurIdPromocion             
    AND ISNULL(PG.IdTipoSeccion,@IdTipoSeccionNormal)=@IdTipoSeccionBeca AND T.IdTipoTurno=@IdTipoTurno )            
             
    SET @TipoSeccion='BECA'            
   END            
   ELSE            
   BEGIN            
  
   --@10 INICIO  
    --Seccion Normal               
    --SET @CurIdGrupo= (SELECT  Top 1 IdGrupo From PromocionGrupo PG WITH(NOLOCK)            
    --INNER JOIN Turno T WITH(NOLOCK) ON T.IdTurno=PG.IdTurno            
    --WHERE PG.IdPromocion=@CurIdPromocion             
    --AND ISNULL(PG.IdTipoSeccion,@IdTipoSeccionNormal)=@IdTipoSeccionNormal            
    --AND T.IdTipoTurno=@IdTipoTurno )       
   
   SET @CurIdGrupo = (  
    SELECT TOP 1  
     TEMP.IdGrupo  
    FROM (  
     SELECT   
      PG.IdPromocion,  
      PG.IdGrupo,  
      SC.IdSeccion,  
      SC.IdCurso,  
      dbo.cMatricula_Val_VacantePromocionGrupoSeccion(PG.IdPromocion,PG.IdGrupo,SC.IdSeccion,SC.IdCurso) AS VacanteDisponible  
     FROM PromocionGrupo PG WITH (NOLOCK)  
     INNER JOIN Seccion SC WITH (NOLOCK) ON PG.IdPromocion = SC.IdPromocion AND PG.IdGrupo = SC.IdGrupo  
     INNER JOIN Turno TR WITH (NOLOCK) ON TR.IdTurno = PG.IdTurno  
     WHERE   
      PG.IdPromocion = @CurIdPromocion  
      AND ISNULL(PG.IdTipoSeccion, @IdTipoSeccionNormal) = @IdTipoSeccionNormal  
      AND TR.IdTipoTurno = @IdTipoTurno  
    ) AS TEMP  
    WHERE   
     TEMP.VacanteDisponible = 1  
    GROUP BY   
     TEMP.IdGrupo  
   )  
  
   --@10 FIN  
    SET @TipoSeccion='NORMAL'            
   END              
              
   IF ISNULL(@CurIdGrupo,0)=0            
   BEGIN            
    SET @DESCRIPCIONERROR = 'No se encuentra el tipo de Seccion '+ @TipoSeccion+' del Alumno'            
    SET @EstadoMatricula = 'No Matriculado'             
    SET @ERRORCODIGO=1            
   END            
  END          
    
 END    
 --Fin @8    
                      
      IF @ERRORCODIGO=0                  
   BEGIN       
      
   -- procesa cada alumno      
   select @CurIdMatricula,@CurIdPromocion,@CurIdGrupo,@IdUsuario,'datos'
   EXEC cMatricula_ProcesoxAlumno @CurIdMatricula,@CurIdPromocion,@CurIdGrupo,@IdUsuario,@ERRORCODIGO OUT, @DESCRIPCIONERROR OUT                
               
    
   IF @ERRORCODIGO = 0               
     SET @EstadoMatricula = 'No Matriculado'                
   IF @ERRORCODIGO = 1               
     SET @EstadoMatricula = 'Matricula Completa'                
   IF @ERRORCODIGO =5           
     SET @EstadoMatricula = 'Matricula Completa'         
   IF @ERRORCODIGO = 2               
     SET @EstadoMatricula = 'Matricula Incompleta'                
                            
   IF @ERRORCODIGO <> 0 or @ERRORCODIGO <> 5 --and ISNULL(@CurCodigoAlumno,'') = ''                
   BEGIN                
       --creamos al alumno, usuario                
       --select 'entro'              
       EXEC cUsuario_Alumno_Ins_Grabar @CurIdAlumno,@IdSede,@IdUsuario,@CodigoAlumno OUT          
           
       --Inicio @8 --@9    
       EXEC cAlumnoCurso_UpdProcesoMatriculaEnvioCorreo @CurIdAlumno, @CurIdMatricula, @CodigoAlumno        
       --Fin @8 --@9    
         
       --select @CurCodigoAlumno         
       --IF LEN(@CodigoAlumno)<=10      
       --BEGIN           
       --EXEC SP_SincronizacionBiblioteca @CurIdAlumno,@CodigoAlumno,1,@IdUnidadAcademica             
       -- END       
   END    
                   
   END        
    
   END              
              
  UPDATE #Matricula                  
  SET Observacion=@DESCRIPCIONERROR,                
  Estado =  @EstadoMatricula,              
  CodigoAlumno = @CodigoAlumno              
  WHERE Id=@CurID              
      
        
    SET @CurID = @CurID +1                  
 END -- while                   
                
  --SE DEVUELVEN LOS RESULTADOS                  
  SELECT --Id,              
  IdMatricula ,                    
  PromocionIdEmpresa ,                    
  PromocionIdSede ,                    
  PromocionIdFacultad ,                    
  PromocionIdUnidadNegocio ,                    
  PromocionIdUnidadAcademica ,                   
  PromocionIdPeriodo ,                 
  PromocionIdProducto ,                    
  ProductoNombre ,                    
  IdPromocion ,                 
  PromocionNombre ,                  
  IdGrupo ,                    
  GrupoCodigo ,                
  ActorIdActor ,                  
  'ActorNombreCompleto'=ISNULL(CodigoAlumno,'')+'-'+ActorNombreCompleto ,    
  Observacion ,                 
  Estado--,  IdRegistro              
  FROM #Matricula                  
      
  insert into ResultadoMatricula(IdMatricula,IdSede,IdUnidadNegocio,IdUnidadAcademica,IdPeriodo,IdProducto,ProductoNombre,                      
        IdPromocion,PromocionNombre,IdGrupo,GrupoCodigo,IdActor,NombreCompleto,Observacion,Estado)    
  SELECT --Id,              
  IdMatricula ,                                 
  PromocionIdSede ,                                 
  PromocionIdUnidadNegocio ,                    
  PromocionIdUnidadAcademica ,                   
  PromocionIdPeriodo ,                    
  PromocionIdProducto ,                    
  ProductoNombre ,                    
  IdPromocion ,                    
  PromocionNombre ,                  
  IdGrupo ,                    
  GrupoCodigo ,                  
  ActorIdActor ,                  
  ISNULL(CodigoAlumno,'')+'-'+ActorNombreCompleto ,           
  Observacion ,                 
  Estado--,  IdRegistro     
  FROM #Matricula     
                    
  DROP TABLE #Matricula                  
                   
  SET NOCOUNT OFF                  
END  -- FIN DEL PROCEDIMIENTO     
    