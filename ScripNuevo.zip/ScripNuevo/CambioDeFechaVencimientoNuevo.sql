UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001016  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001038  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001139  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001170  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001409  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001443  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001485  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001502  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001522  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001529  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001616  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001731  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0001900  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002058  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002245  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002328  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002343  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002365  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002421  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002637  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002703  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002735  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0002825  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003010  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003020  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003023  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003045  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003047  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003084  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003092  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003094  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003120  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003155  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003160  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003180  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003214  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003222  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003283  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003287  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003325  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003335  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003346  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003349  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003370  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003404  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003419  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003426  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003448  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003519  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003572  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003598  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003623  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003625  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003641  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003696  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003698  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003754  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003797  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0003860  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004006  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004022  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004107  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004223  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004227  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004251  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004259  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004329  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004398  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004504  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004533  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004542  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004543  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0004984  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B690-0005126  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B691-0000066  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B691-0000093  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B691-0002751  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('CO')   AND NumeroDocumento = 'B691-0002792  '
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622381
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622389
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622393
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622509
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622514
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622532
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622656
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622683
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623043
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623104
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623105
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623172
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623361
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623522
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623700
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623850
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625054
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625268
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625272
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625571
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625669
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625687
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625690
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625694
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625732
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625742
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625750
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625782
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625788
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625821
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625829
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625850
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625870
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625891
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625893
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625896
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625906
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625924
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625927
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625989
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625995
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625998
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626026
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626070
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626076
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626484
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626526
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627158
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627179
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627181
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627185
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627188
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627191
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627208
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627212
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627504
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627511
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627845
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 628015
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 628152
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 628993
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 628994
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 629722
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 629880
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 629964
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 630190
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 630195
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 630208
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 630211
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 633515
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 633723
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 633749
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 633836
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 635199
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 637380
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 638413
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 638739
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 638758


UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B690-0005008  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002719  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002720  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002721  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002722  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002723  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002724  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002725  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002726  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002727  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002728  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002729  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002730  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002731  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002732  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002733  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002734  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002735  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002736  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002737  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002738  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002739  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002740  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002741  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002742  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002743  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002744  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002745  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002746  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002747  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002748  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002749  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002750  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002752  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002753  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002754  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002755  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002756  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002757  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002758  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002759  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002760  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002761  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002762  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002763  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002764  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002765  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002766  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002767  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002768  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002769  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002770  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002771  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002772  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002773  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002775  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002776  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002777  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002778  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002779  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002780  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002781  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002782  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002783  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002784  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002785  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002786  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002787  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002788  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002789  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002790  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002791  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002793  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002794  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002795  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002796  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002797  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002798  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002799  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002800  '
UPDATE CO_Documento SET FechaVencimiento = '20241118', UltimaFechaModif = GETDATE()   WHERE CompaniaSocio = '00002700'   AND TipoDocumento IN ('BV')   AND Estado IN ('PR')   AND NumeroDocumento = 'B691-0002801  '
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622351
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622368
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622370
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622471
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622480
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622515
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622529
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 622590
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623023
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623064
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623094
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623159
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623435
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623586
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623654
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623830
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 623863
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 624059
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625678
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625695
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625698
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625704
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625705
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625729
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625735
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625748
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625757
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625764
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625768
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625784
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625786
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625802
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625819
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625831
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625853
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625854
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625914
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625925
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625946
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625947
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625948
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625953
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625958
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625980
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625982
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 625996
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626018
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626036
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626038
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626049
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626234
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626411
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626426
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626514
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626520
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626811
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626859
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626888
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 626973
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627165
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627169
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627177
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627196
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627202
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627223
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627512
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 627788
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 628688
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 628957
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 629190
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 629871
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 630189
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 630199
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 630215
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 633768
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 636075
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 637388
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 638405
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 638521
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 639063
UPDATE CO_Interfase_P09_Header SET FechaVencimiento = '20241118',FechaModificacion=GETDATE()    WHERE CompaniaSocio = '00002700' AND CuotaNumero = 2 AND IdMatricula = 645520