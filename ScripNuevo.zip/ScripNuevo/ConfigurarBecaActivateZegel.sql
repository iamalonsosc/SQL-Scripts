--SELECT*FROM MaestroTablaRegistro WHERE IdMaestroTabla=1905 AND Codigo IN ('TIP0000014','TIP0000017','TIP0000056','TIP0000053','TIP0000052','TIP0000047','TIP0000058','TIP0000051','TIP0000062','TIP0000063')



--SELECT * FROM MaestroTablaRegistro WITH(NOLOCK) WHERE  Activo = 1 AND EsPDT = 1 AND Disponible10='ACTIVATE'
--SELECT*FROM MaestroTablaRegistro WHERE ESPDT=1

--select*from MaestroTablaRegistro where Codigo='DESMONTO'

--select*from DescuentoAlumnoEvidencia where IdMatricula=769834

--select*from DescuentoAcademicoBase 

----UPDATE DescuentoAcademicoBase SET PeriodoCodigo='2026-I'
--where NumeroIdentidad='42876450' AND IdMaestroRegistro=47314


--select*from MaestroTablaRegistro where IdMaestroRegistro in (47314,47236)
--select*from Actor where NumeroIdentidad='42876450'


--SELECT*FROM DescuentoAcademicoPoblacion WHERE IdTipoSituacionAlumno=47314
--SELECT*FROM DescuentoAcademico WHERE IdDescuentoAcademico IN (6555
--,6434
--,6872)

UPDATE MaestroTablaRegistro SET Disponible10='ACTIVATE',EsPDT=1
--select*from MaestroTablaRegistro
WHERE IdMaestroTabla=1905 AND Codigo IN ('TIP0000014','TIP0000017','TIP0000037','TIP0000047','TIP0000049','TIP0000050',
                  'TIP0000051','TIP0000052','TIP0000053','TIP0000056','TIP0000058','TIP0000059','TIP0000060','TIP0000062','TIP0000063')
--(8 filas afectadas)

--UPDATE MaestroTablaRegistro
--SET EsPDT = 1
--WHERE Codigo IN ('TIP0000014','TIP0000017','TIP0000037','TIP0000047','TIP0000049','TIP0000050',
--                  'TIP0000051','TIP0000052','TIP0000053','TIP0000056','TIP0000058','TIP0000059','TIP0000060')

/*==============================================================
Disponible1 = PromedioBeca  SI 
Disponible2 = ValidaRetiroCiclo SI
Disponible3 = ValidaCambioModalidad NO A NINGUNO
Disponible4 = ValidaCambioSede NO A NINGUNO
Disponible5 = IdModuloBecaValidar 
Disponible6 = ValidaTipoCondicion NO A NINGUNO
Disponible7 = ValidaPagoPuntual SI
Disponible8 = ValidaSecuencialidad 
Disponible9 = ValidaCambioCarrera NO A NINGUNO
Disponible10 = Indicador de la beca ACTIVATE
==============================================================*/


/*==============================================================
TIP0000014
BECA ACTIVATE 25% 
Promedio 13
==============================================================*/
UPDATE MaestroTablaRegistro
SET --Disponible1 = 13,   -- promedio m�nimo
    Disponible2 = 0,    -- retiro
    Disponible3 = 0,    -- cambio modalidad
    Disponible4 = 1,    -- cambio sede
    Disponible5 = 1,    -- evaluar desde cuota 2
    Disponible6 = 0,    -- tipo condicion
    Disponible7 = 1,    -- pago puntual
    Disponible8 = 0,    -- secuencialidad
    Disponible9 = 1     --Cambio Carrera
    --cambio de turno falta
WHERE Codigo = 'TIP0000014'


/*==============================================================
TIP0000017
BECA CONTIGO 50% - TC OP3
Promedio 13
==============================================================*/
UPDATE MaestroTablaRegistro
SET 
    --Disponible1 = 18.00,
    Disponible2 = 1,-- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1, -- cambio sede
    Disponible5 = 1, -- evaluar desde cuota 2
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0,-- secuencialidad
    Disponible9 = 0--Cambio Carrera
WHERE Codigo = 'TIP0000017'


/*==============================================================
TIP0000056
BECA CONTIGO 25% - TC OP3
Promedio 13
==============================================================*/
UPDATE MaestroTablaRegistro
SET 
    Disponible1 = 13,
    Disponible2 = 1,-- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1, -- cambio sede
    Disponible5 = 1,    -- evaluar desde cuota 2
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0,-- secuencialidad
    Disponible9 = 0--Cambio Carrera
WHERE Codigo = 'TIP0000056'


/*==============================================================
TIP0000053
BECA CONTIGO 50% 
==============================================================*/
UPDATE MaestroTablaRegistro
SET 
    Disponible1 = 13,-- no valida promedio
    Disponible2 = 1,-- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,    -- evaluar desde cuota 2
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 1,-- secuencialidad
    Disponible9= 0--Cambio Carrera
WHERE Codigo = 'TIP0000053'


/*==============================================================
TIP0000052
50% BECA CONTIGO X4
==============================================================*/
UPDATE MaestroTablaRegistro
SET Disponible1 = 13, -- no valida promedio
    Disponible2 = 1, --  retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,-- evaluar desde cuota 2
    Disponible6 = 1,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 1-- secuencialidad
    ,Disponible9= 0--Cambio Carrera
WHERE Codigo = 'TIP0000052'


/*==============================================================
TIP0000047
BECA 50% SUPERMERCADOS SECUENCIALES
==============================================================*/
UPDATE MaestroTablaRegistro
SET Disponible1 = 13, -- promedio
    Disponible2 = 1,  -- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,-- evaluar desde cuota 2
    Disponible6 = 1,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0 -- secuencialidad
    ,Disponible9= 0--Cambio Carrera
WHERE Codigo = 'TIP0000047'

/*==============================================================
TIP0000058
50% BECA NO HAY SIN SUERTE
==============================================================*/
UPDATE MaestroTablaRegistro
SET Disponible1 = 0, -- promedio
    Disponible2 = 1,-- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,-- evaluar desde cuota 2
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 1 -- secuencialidad
    ,Disponible9= 0--Cambio Carrera
WHERE Codigo = 'TIP0000058'

/*==============================================================
TIP0000051
BECA CONTIGO TC (TODA LA CARRERA) 50%
==============================================================*/
UPDATE MaestroTablaRegistro
SET Disponible1 = 13, -- promedio
    Disponible2 = 1,  -- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,-- evaluar desde cuota 2
    Disponible6 = 1,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0 -- secuencialidad
    ,Disponible9= 0--Cambio Carrera
WHERE Codigo = 'TIP0000051'
/*==============================================================
TIP0000062
BECA 25% NOTA 15 PRESENCIAL TODA LA CARRERA
==============================================================*/
UPDATE MaestroTablaRegistro
SET Disponible1 = 15, -- promedio
    Disponible2 = 1,  -- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,-- evaluar desde cuota 2
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0 -- secuencialidad
    ,Disponible9= 0--Cambio Carrera
WHERE Codigo = 'TIP0000062'
/*==============================================================
TIP0000063
BECA 50% NOTA 13 PRESENCIAL TODA LA CARRERA
==============================================================*/
UPDATE MaestroTablaRegistro
SET Disponible1 = 13, -- promedio
    Disponible2 = 1,  -- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,-- evaluar desde cuota 2
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0 -- secuencialidad
    ,Disponible9= 0--Cambio Carrera
WHERE Codigo = 'TIP0000063'