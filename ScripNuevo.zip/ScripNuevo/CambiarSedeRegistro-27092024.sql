UPDATE Registro SET IdSede=38
WHERE IdRegistro=1
AND IdActor=1491040
--(1 row affected)