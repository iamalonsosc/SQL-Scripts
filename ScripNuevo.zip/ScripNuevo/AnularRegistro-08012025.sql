--SELECT*FROM Registro 
UPDATE Registro SET Estado='X'
WHERE IdActor=1588884 AND IdRegistro=4
--(1 row affected)

UPDATE AlumnoCurricula SET Activo=0
WHERE IdAlumno=1588884 AND IdRegistro=4
--(1 row affected)