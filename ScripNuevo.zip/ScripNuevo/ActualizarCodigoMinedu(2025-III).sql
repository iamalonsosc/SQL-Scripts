--SELECT*FROM Periodo 
UPDATE Periodo SET CodigoMinedu='2025-3'
WHERE Codigo='2025-III' and IdSede=34 AND IdUnidadAcademica=60
--select*from sede