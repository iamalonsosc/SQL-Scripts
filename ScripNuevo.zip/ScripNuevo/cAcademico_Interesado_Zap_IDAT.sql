  
-- =============================================        
-- Author:  MBUENO        
-- Create date: 24/05/2022        
-- Description: Procedimiento usado en JOB para insertar en el linked server SMARTBDIDAT         
-- =============================================        
/*        
-----------------------------------------------------------------------------                  
Nro  FECHA   USUARIO   DESCRIPCION                  
-----------------------------------------------------------------------------        
@1  27.05.2022  MBUENO   Se comenta UPDATE SMARTBDIDAT.AcademicoIDAT.dbo.Log_Lead_Web, no se usa        
@2  08.09.2022  MBUENO   Se agrega DISTINCT para evitar duplicados        
@3  28.11.2022  MBUENO   Se agrega isnull cuando venga del formulario carga contactos        
@4  16.12.2022  MBUENO   Se agrega tabla temporal para enviar progresivamente los leads        
@5  05.09.2023  EHUILLCA  Se agrega PATINDEX para Nullar NumeroDocumento si contiene valores excluidos por par�metro.      
@6  09.04.2024  FETORRES  Se agregan disponibles del 17 al 19.      
@7  29.05.2024  MBUENO   Se cambia la validacion del NumeroDocumento      
@8  06.06.2024  JQuenta   Se agregan los siguientes campos: UsuarioCreacionCargaLead, FechaRealCargaLead, ObservacionAtencionCargaLead y TipoAtencionCargaLead      
*/        
CREATE PROCEDURE cAcademico_Interesado_Zap_IDAT     
AS        
BEGIN        
        
 --@4        
 DECLARE @tabla_leads AS TABLE(        
   IdInteresadoIntermedia INT, ApellidoPaterno VARCHAR(200), ApellidoMaterno VARCHAR(200), Nombres VARCHAR(200),         
   genero VARCHAR(200), NumeroDocumento VARCHAR(200), FechaNacimiento DATE,MedioDifusion VARCHAR(200),        
   EmailPersonal VARCHAR(200),EmailTrabajo VARCHAR(200),Telefono VARCHAR(200),Celular VARCHAR(200),        
   TelefonoTrabajo VARCHAR(200),ProductoInteres VARCHAR(200),Sede VARCHAR(200),Disponible1 VARCHAR(200),        
   Disponible2 VARCHAR(200),Disponible3 VARCHAR(200),Disponible4 VARCHAR(200),Disponible5 VARCHAR(200),        
   Disponible6 VARCHAR(200),Disponible7 VARCHAR(200),Disponible8 VARCHAR(200),Disponible9 VARCHAR(200),        
   Disponible10 VARCHAR(200),Disponible11 VARCHAR(200),Disponible12 VARCHAR(200),Disponible13 VARCHAR(200),         
   Disponible14 VARCHAR(200),Disponible15 VARCHAR(200),IdPagina VARCHAR(20), idFormulario VARCHAR(20), IdLead VARCHAR(20),        
   FechaCreacion DATETIME,Disponible17 VARCHAR(200),Disponible18 VARCHAR(200) --@6          
   ,Disponible19 VARCHAR(200)  --@6          
   ,UsuarioCreacionCargaLead INT, FechaRealCargaLead DATETIME, ObservacionAtencionCargaLead VARCHAR(200), TipoAtencionCargaLead CHAR(4) --@8       
 )        
 --@4        
        
 DECLARE @ValoresExcluidos AS VARCHAR(MAX) = '' --@7      
 SET @ValoresExcluidos = (SELECT TOP 1 Valor FROM Parametro WITH(NOLOCK) WHERE Nombre = 'CaracterExcluido')  --@7      
         
 --Se inserta a la tabla        
 INSERT INTO @tabla_leads --@4        
 SELECT DISTINCT TOP 100 IdInteresadoIntermedia, ApellidoPaterno ,ApellidoMaterno , Nombres,genero, --@2        
   --CASE WHEN PATINDEX('%['+@ValoresExcluidos+']%',NumeroDocumento)= 1 THEN NULL ELSE NumeroDocumento END,      
   dbo.gEliminaCharInvalidosNumero(NumeroDocumento, @ValoresExcluidos), --@7      
   FechaNacimiento,MedioDifusion,        
   EmailPersonal,EmailTrabajo,Telefono,Celular,        
   TelefonoTrabajo,ProductoInteres,Sede,Disponible1,        
   UPPER(Disponible2),UPPER(Disponible3) ,UPPER(Disponible4),UPPER(Disponible5),        
   UPPER(Disponible6),UPPER(Disponible7),UPPER(Disponible8) ,UPPER(Disponible9),        
   UPPER(Disponible10),UPPER(Disponible11),UPPER(Disponible12),'N',         
   ISNULL(Disponible14,'ZAPIER'),'I' ,IdPagina, idFormulario, IdLead, FechaCreacion, --@3 --@4       
   ISNULL(Disponible17,''),ISNULL(Disponible18,'')--@6        
   ,ISNULL(Disponible19,'') --@6       
   --Inicio --@8      
   ,ISNULL(UsuarioCreacionCargaLead,'')      
   ,ISNULL(FechaRealCargaLead,'')      
   ,ISNULL(ObservacionAtencionCargaLead,'')      
   ,ISNULL(TipoAtencionCargaLead,'')      
   --Fin --@8         
   FROM InteresadoIntermediaIDAT WITH(NOLOCK)        
   WHERE ISNULL(Disponible15,'N') = 'N' --@4 igual al valor N (No Insertado)        
   AND ISNUMERIC(Sede) = 1        
   AND ISNUMERIC(ProductoInteres) = 1        
        
        
 --Se actualiza el Disponible15 al valor N (No Insertado)        
 UPDATE InteresadoIntermediaIDAT SET Disponible15='N'         
 WHERE ISNULL(Disponible15,'N') ='N' AND IdInteresadoIntermedia IN (SELECT IdInteresadoIntermedia FROM @tabla_leads); --@4        
        
 --Se Inserta en la tabla InteresadoIntermedia al linked server de AcademicoIDAT        
 INSERT INTO [SMARTBDIDAT].AcademicoIDAT.DBO.[InteresadoIntermedia](ApellidoPaterno ,ApellidoMaterno , Nombres,Genero,        
    NumeroDocumento,FechaNacimiento,MedioDifusion,        
    EmailPersonal,EmailTrabajo,Telefono,Celular,        
    TelefonoTrabajo,ProductoInteres,Sede,Disponible1,        
    Disponible2,Disponible3 ,Disponible4,Disponible5,        
    Disponible6,Disponible7,Disponible8 ,Disponible9,        
    Disponible10,Disponible11,Disponible12,Disponible13,        
    Disponible14,Disponible15,IdPagina, idFormulario,idLead      
 ,Disponible17,Disponible18,Disponible19  --@6        
 ,UsuarioCreacionCargaLead,FechaRealCargaLead,ObservacionAtencionCargaLead,TipoAtencionCargaLead --@8      
 )        
 SELECT DISTINCT ApellidoPaterno ,ApellidoMaterno , Nombres,genero,        
    NumeroDocumento,FechaNacimiento,MedioDifusion,        
    EmailPersonal,EmailTrabajo,Telefono,Celular,        
    TelefonoTrabajo,ProductoInteres,Sede,Disponible1,        
    UPPER(Disponible2),UPPER(Disponible3) ,UPPER(Disponible4),UPPER(Disponible5),        
    UPPER(Disponible6),UPPER(Disponible7),UPPER(Disponible8) ,UPPER(Disponible9),        
    UPPER(Disponible10),UPPER(Disponible11),UPPER(Disponible12),'N',         
    ISNULL(Disponible14,'ZAPIER'),'I' ,IdPagina, idFormulario, IdLead,      
 Disponible17,Disponible18,Disponible19  --@6       
 ,UsuarioCreacionCargaLead,FechaRealCargaLead,ObservacionAtencionCargaLead,TipoAtencionCargaLead --@8      
 FROM @tabla_leads --@4        
        
 --Despues de insertar se actualiza el Disponible15 al valor I (Insertado)        
 UPDATE InteresadoIntermediaIDAT SET Disponible15 = 'I'         
 WHERE Disponible15 = 'N' AND IdInteresadoIntermedia IN (SELECT IdInteresadoIntermedia FROM @tabla_leads); --@4        
         
END 
