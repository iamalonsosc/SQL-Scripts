UPDATE Registro SET Estado='N'
WHERE IdActor=1636416 AND IdRegistro IN (1,3)