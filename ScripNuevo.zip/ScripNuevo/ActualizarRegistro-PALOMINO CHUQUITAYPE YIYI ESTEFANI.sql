UPDATE Registro SET IdSede=32
WHERE IdActor=1433555 AND IdRegistro=2
--(1 row affected)