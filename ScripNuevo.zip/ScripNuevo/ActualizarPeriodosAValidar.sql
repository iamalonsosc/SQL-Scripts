--Select Valor,* from Parametro WITH(NOLOCK) where Nombre='PeriodosValidarDescuento'  AND Activo=1

--NUEVOS PERIODOS IDAT
--2025-III,2025-IIIA,2025-IIIB,2026-I,2026-IIA (PERIODOS ANTIGUOS)
UPDATE Parametro SET Valor='2026-II,2026-IIA,2026-III,2026-IIIA'
where Nombre='PeriodosValidarDescuento'  AND Activo=1
--(1 fila afectada)