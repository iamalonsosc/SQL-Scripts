use AcademicoCA
go
--89205

UPDATE DescuentoAcademicoBase 
SET Activo = 0  
WHERE IdActor = 1775623 and NumeroIdentidad = '73187309' 

 