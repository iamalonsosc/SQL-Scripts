--����������������������������������������������������������������������������    
--Creado por      : Luis Perales Tenorio (21/06/2012)  
--Modificado por  : Rosa Zacarias (24/09/2012)  
--Funcionalidad   : Genera la carga habil para los alumnos de extension  
--Utilizado por   :  
--------------------------------------------------------------  
--Modificado por  : Alan Aurora (20/08/2015)  
--Funcionalidad   : Validacion de solo S�lo se pueden subsanar 2 modulos desaprobados.  
--------------------------------------------------------------  
/*  
-----------------------------------------------------------------------------  
Nro  FECHA   USUARIO     DESCRIPCION  
-----------------------------------------------------------------------------  
@1            Cambiamos la ejecucion del sp para generar cointerfase con importes  
@2  01.02.2014  ilopez     Proyecto SEE  
@3  11.01.2019  Eloy Alva (Sigcomt)  Agregar parametro CompaniaSocio.  
@4  29.09.2020  RSamame     Se agrego parametro idcurricula a la funcion   
@5  18.02.2021  JLEO     Se agrega variables EsInlearning, IdTipoCOnvalidacion  
@6  15.11.2023  Alsanchez    se agregado idprecio sede   
@7  08/08/2024  JQuenta     Se setean campos en NULL como parte del Proyecto de Progresion Curricular  
*/  
  
DECLARE  
--CREATE PROCEDURE [dbo].[cMatricula_Pro_CargaHabilExtension]  
--(  
 @pIdEmpresa INT,  
 @pIdSedeOrigen INT,  
 @pIdSedeDestino INT,  
 @pIdPeriodo INT,  
 @pIdMatricula INT,    
 @pIdProducto int,  
 @pIdCurricula int,  
 @pIdUsuario INT,  
 @Estado VARCHAR(2) ,  
 @Resultado VARCHAR(1000) ,  
 @intMatriculaGenerada INT ,  
 @Observacion VARCHAR(500),  
 @pIdAutorizacion INT  
--)  
--AS  
BEGIN  
  SET NOCOUNT ON     
    
  SELECT @pIdEmpresa=1,@pIdSedeOrigen=38,@pIdSedeDestino=38,@pIdPeriodo=4207,@pIdMatricula=633984,@pIdUsuario=446639,@pIdProducto=15737,@pIdCurricula=6169--,@Estado=@p9 salida,@Resultado=@p10 salida,@intMatriculaGenerada=@p11 salida,@Observacion=N'',@pIdAutorizacion=0
  
  DECLARE                            
   @IdProducto INT,  
   @IdPeriodo INT,  
   @IdPromocion INT,  
   @IdRegistro INT,  
   @IdCurricula INT,  
   @IdModulo INT,                            
   @IdActor INT,  
   @wIdPromocion INT,                            
   @NumeroMatricula VARCHAR(20),                            
   @IdMatriculaNew INT,                            
   @IdCurso INT,                            
   @NumVezCurso INT,                            
   @Res INT,                            
   @NumeroIdentidad VARCHAR(20),                                  
   @Direccion VARCHAR(500),                                  
   @NombreCompleto VARCHAR(150),                                 
   @Telefonos  VARCHAR(150) ,              
   @val INT,              
   @ret int,    
   @cCursosProducto INT,    
   @cCursosMat INT,    
   @TipoServicio VARCHAR(1),               
   @TipoCondicion VARCHAR(2),  
   @IdProcedencia INT,  
   @Deudas INT,  
   @Numerocuota INT,  
   @IdUnidadNegocio INT,  
   @IdFacultad INT,  
   @xIdRegistro int, -- nuevo registro creado si es una curricula diferente  
   @CurIdCurso int,  
   @IdConvalidacion int,  
   @Cumple int,  
   @TipoAprobacion varchar(2),  
   @PromFinal varchar(10),  
   @PromReal varchar(10),  
   @Existe int,  
   @anno int,  
   @fecha varchar(10),  
   @NumeroConv varchar(10),  
   @CompaniaSocio CHAR(8), --@3  
   @IdPrecioSede INT = NULL, --@6  
   --Inicio --@7  
   @IdModuloReal INT = NULL,  
   @TipoCondicionNueva CHAR(2) = NULL  
   --Fin --@7  
  
 -- sacamos los cursos que tiene pendientes                      
 DECLARE @CurDes TABLE (Id INT IDENTITY,                   
  IdCurso INT,  
  NumVezCurso INT  
 )        
                                
  --sacamos los datos de la matricula del alumno                            
  SELECT @IdProducto =PR.IdProducto,                             
   @IdPeriodo = PR.IdPeriodo,                             
   @IdPromocion = MA.IdPromocion,                            
   @IdRegistro = MA.IdRegistro,                             
   @IdCurricula = MA.IdCurricula,                         
   @IdModulo = MA.IdModulo,                            
   @IdActor = ma.IdActor,  
   @IdUnidadNegocio = pr.idUnidadNegocio,  
   @IdFacultad  = pr.IdFacultad                         
  FROM MATRICULA MA with(nolock)                             
   INNER JOIN PROMOCION PR with(nolock)                            
   ON MA.IdPromocion = PR.IdPromocion                            
  WHERE IdMatricula =@pIdMatricula                            
   AND ma.EsMatricula = 1                            
   and ma.Estado <> 'X'    
       
  SELECT @CompaniaSocio = CompaniaSocio  FROM Empresa e WITH(NOLOCK) WHERE E.IdEmpresa=@pIdEmpresa    --@3   
  
  SET @Deudas = 0    
    
  --verificamos si tiene deudas pendientes  
  EXEC cAlumno_Valida_Deudas @IdActor,null,@Deudas OUTPUT  
    
  IF @Deudas > 0 -- tiene deudas  
  BEGIN     
    -- verificamos si tiene permiso para generar carga con deuda   
  IF dbo.cAutorizacionAlumno_Val_Existe(@pIdEmpresa,@pIdSedeDestino,1,1,1,@pIdPeriodo,@IdActor,1035) = 0        
   BEGIN          
    SELECT @Estado = 'KO'          
    SELECT @Resultado = 'El alumno tiene deudas pendientes con la institucion.'         
    SELECT @intMatriculaGenerada= ISNULL(@IdMatriculaNew,0)                            
    RETURN   
   END      
  END                      
     
  DECLARE @IDMatricula int  
  DECLARE @Retorno INT  
    
  SELECT @IDMatricula = dbo.cMatricula_Sel_AlumnoMatricula(@pIdEmpresa,              
                 @pIdSedeDestino,              
                 @pIdPeriodo, -- este es el nuevo periodo              
                 @IdActor,  
                 @pIdCurricula) --@4  
  if  @IDMatricula>0  
  begin  
  --Si no pago entonces eliminamos cointerfase.  
  if not exists(select 1 from vw_co_Interfase_p09_header with(nolock)--@2  
       where IdMatricula=@IDMatricula   
        AND CompaniaSocio=@CompaniaSocio --@3  
       and Estado='CO')  
   EXEC cInterfaseDocumento_Ins_Borrar_General @idMatricula,@Retorno output  
   --select 'hola'  
  else  
   BEGIN   
    SELECT @Estado = 'KO'              
    SELECT @Resultado = 'El alumno ya pag�.'          
    SELECT @intMatriculaGenerada= ISNULL(@IdMatriculaNew,0)                            
    RETURN         
   END    
  end  
                  
  SET @val = 0   
  -- verificamos si esta matriculado ya en el periodo seleccionado              
  select @val = DBO.cMatricula_Val_AlumnoMatriculadoExtension(@pIdEmpresa,@pIdSedeDestino,@pIdPeriodo,@IdProducto,@IdActor)              
                
  IF @val = 1              
   BEGIN              
   SELECT @Estado = 'KO'                                  
   SELECT @Resultado = 'Error: El alumno ya se encuentra matriculado.'                             
   SELECT @intMatriculaGenerada= ISNULL(@IdMatriculaNew,0)                   
   END              
  ELSE              
  BEGIN                
  -- eliminamos la carga generada              
  exec cMatricula_Eli_CargaHabilExtension @pIdEmpresa,@pIdSedeDestino,@IdActor,@pIdPeriodo,@IdProducto,@ret output              
  
  if @ret = 1              
  BEGIN           
   SELECT @Estado = 'KO'                                  
   SELECT @Resultado = 'Error al eliminar la carga anterior.'                             
   SELECT @intMatriculaGenerada= ISNULL(@IdMatriculaNew,0)                 
   RETURN                
  END      
    
    
     
  --  
  --  
  --debemos verificar si es el mismo producto y curricula  
  if @IdProducto = @pIdProducto and   @IdCurricula = @pIdCurricula                   
  begin  
                          
   select @xIdRegistro = @IdRegistro  
  
   INSERT INTO @CurDes                    
   SELECT IdCurso,                             
   'NumVezCurso' = dbo.cAlumnoCurso_Pro_NumeroVez(@IdActor,@IdRegistro,@IdCurricula,IdCurso)                           
   FROM AlumnoCurriculaCurso AC  with(nolock)                           
   WHERE IdAlumno = @IdActor                            
   AND IdRegistro = @IdRegistro                            
   AND IdCurricula = @IdCurricula                    
   AND IdModulo = @IdModulo                            
   AND isnull(PromedioCondicion,'D') <> 'A'                            
   AND TipoCondicion = 'RE'  
        
        
   IF @pIdAutorizacion = 1  
   begin        
    delete from @CurDes  
  
    INSERT INTO @CurDes  
    SELECT IdCurso,  
    'NumVezCurso' = 1  
    FROM AlumnoCurriculaCurso AC with(nolock)   
    WHERE IdAlumno = @IdActor  
    AND IdRegistro = @IdRegistro  
    AND IdCurricula = @IdCurricula                            
    AND IdModulo = @IdModulo                            
    --AND isnull(PromedioCondicion,'D') <> 'A'                            
    --AND TipoCondicion = 'RE'  
      
    UPDATE AlumnoCurriculaCurso       
    SET IdConvalidacion = null,    
     TipoCondicion = 'RE',    
     PromedioFinal = null,    
     PromedioReal = null,    
     PromedioCondicion = null ,  
     Glosa= null ,--@1       
     UsuarioModificacion=@pIdUsuario, --@1  
     FechaModificacion=GETDATE()--@1        
    WHERE IdAlumno = @IdActor  
     AND IdRegistro = @xIdRegistro  
     AND IdCurricula = @pIdCurricula  
     AND IdModulo = @IdModulo      
   end  
                                                          
   -- VERIFICAMOS SI HAY LA PROMOCION REGISTRADA QUE LE CORRESPONDE AL ALUMNO                                
   SELECT @wIdPromocion = IdPromocion                                
   FROM Promocion   WITH (NOLOCK)                                
   WHERE IdEmpresa = @pIdEmpresa                                
   AND IdSede = @pIdSedeDestino                                
   AND IdPeriodo = @pIdPeriodo                    
   and IdProducto =  @IdProducto                    
   AND IdCurricula = @IdCurricula                                
   --AND IdModulo = @IdModulo                                
   AND Estado = 'A'           
                 
   -- sacamos la cantidad de cursos del producto    
   select @cCursosProducto = COUNT(1)    
   from CurriculaCurso with(nolock)   
   where IdCurricula = @IdCurricula    
  
   -- sacamos la cantidad de cursos en los que se va a matricular    
   select @cCursosMat = COUNT(1)    
   from @CurDes    
  
   IF @cCursosProducto = @cCursosMat    
    BEGIN    
     SET @TipoServicio = 'P'    
     SET @TipoCondicion = 'RE'    
    END    
   ELSE    
    BEGIN    
     SET @TipoServicio = 'C'    
     SET @TipoCondicion = 'CC'    
    END    
  end -- fin if @IdProducto = @pIdProducto and   @IdCurricula = @pIdCurricula    
  else  
  begin  
   -- tenemos que crear un registro nuevo y todos sus hijos     
   -- primero verificamos que no cree nuevamente el registro  
   if not exists (select 1   
    from AlumnoCurricula with(nolock)   
    where idalumno = @IdActor   
    and IdCurricula = @pIdCurricula   
    and Activo = 1)  
    begin  
     select @xIdRegistro = max(idregistro)+1 from Registro with(nolock) where idactor = @IdActor  
  
     insert into Registro(IdActor,IdRegistro,IdEmpresa,IdSede,IdFacultad,IdUnidadNegocio,IdProducto,TipoServicio,  
          Estado,UsuarioCreacion,FechaCreacion,UsuarioModificacion,FechaModificacion)  
     values(@IdActor,@xIdRegistro,@pIdEmpresa,@pIdSedeDestino,@IdFacultad,@IdUnidadNegocio,  
       @IdProducto,'P','N',@pIdUsuario,getdate(),@pIdUsuario,getdate())  
  
     insert into AlumnoCurricula(IdAlumno,IdRegistro,IdCurricula,Activo,UsuarioCreacion,FechaCreacion)  
     values(@IdActor,@xIdRegistro,@pIdCurricula,1,@pIdUsuario,getdate())    
  
     insert into AlumnoCurriculaModulo(IdAlumno,IdRegistro,IdCurricula,IdModulo)  
     select @IdActor,@xIdRegistro,IdCurricula,IdModulo   
     from CurriculaModulo WITH(NOLOCK)  
     where IdCurricula = @pIdCurricula  
  
     insert into AlumnoCurriculaCurso (IdAlumno,IdRegistro,IdCurricula,IdCurso,IdAlumnoCurso,IdModulo,TipoCondicion,  
        Glosa,UsuarioCreacion,FechaCreacion,UsuarioModificacion,FechaModificacion)  
     select @IdActor,@xIdRegistro,IdCurricula,IdCurso,null,IdModulo,'RE','Desde Carga Habil Extension',@pIdUsuario,GETDATE(),@pIdUsuario,GETDATE()  
     from CurriculaCurso WITH(NOLOCK)  
     where IdCurricula = @pIdCurricula  
    end  
   else  
    begin  
     select @xIdRegistro = IdRegistro   
     from AlumnoCurricula with(nolock)   
     where idalumno = @IdActor   
      and IdCurricula = @pIdCurricula   
      and Activo = 1  
    end  
         
   -- sacamos lA CURRICULACURSO DE Los cursos del nuevo producto  
   DECLARE @CurCursos TABLE(  
    Id INT IDENTITY,   
    IdCurso INT)  
  
   INSERT INTO @CurCursos  
   SELECT IdCurso  
   FROM AlumnoCurriculaCurso WITH (NOLOCK)    
   WHERE IdRegistro = @xIdRegistro  
   AND IdAlumno = @IdActor  
   AND IdCurricula = @pIdCurricula  
   ORDER BY IdModulo ASC;  
  
   SET @Val = 0  
   SET @IdConvalidacion = 0  
           
   WHILE EXISTS (SELECT * FROM @CurCursos)      
   BEGIN   
          
      SELECT TOP 1 @CurIdCurso=IdCurso  
      FROM @CurCursos       
      ORDER BY Id     
  
      SET @Cumple = 0    
      SET @TipoAprobacion = ''    
  SELECT @IdActor,     
                  @IdRegistro,     
                  @pIdCurricula,    
                  @IdCurricula,  
                  @CurIdCurso,'COCHINADA'
      EXEC AlumnoCurriculaCurso_Val_CumplimientoNuevo @IdActor,     
                  @IdRegistro,     
                  @pIdCurricula,    
                  @IdCurricula,  
                  @CurIdCurso,     
                  'NO',     
                  @Cumple OUTPUT,     
                  @TipoAprobacion OUTPUT,  
                  @PromFinal OUTPUT,  
                  @PromReal OUTPUT  
                  SELECT @Cumple
      IF @Cumple = 1    
      BEGIN     
        -- si es la primera vez crea la convalidacion    
        SET @Val = @Val + 1    
          
        IF @Val = 1    
        BEGIN    
  
          -- debemos verificar si ya se realizo una convalidacion    
          -- en el periodo    
          SET @Existe = dbo.cConvalidacion_Val_ExisteCI(@pIdEmpresa,    
                      @pIdSedeDestino,    
                      @IdActor,    
                      @xIdRegistro,    
                      @pIdCurricula,  --@LPERALES  
                      @pIdPeriodo)    
  
          IF @Existe = 0    
          BEGIN               
  
             -- aca tenemos que hacer la convalidacion interna por cada curso aprobado    
             set @anno = YEAR(getdate())    
             set @fecha = dbo.gFechaStr(GETDATE())      
                     
             EXEC cConvalidacion_Gen_Codigo @anno,@NumeroConv OUTPUT    
  
             EXEC cConvalidacion_Ins_Grabar @pIdEmpresa,    
                     @pIdSedeDestino,    
                     @IdActor,    
                     @xIdRegistro,    
                     @pIdCurricula,    
                     @IdCurricula,    
                     @NumeroConv,    
                     @pIdPeriodo,    
                     @pIdUsuario,    
                     NULL,    
                     @fecha,    
                     'CONVALIDACION INTERNA - CAMBIO CARRERA',    
                     'CI',    
                     'R',    
                     @pIdUsuario,   
                     '',--@InstitutoProcedencia  
                     '',--@InstProcedenciaNombreCarrera  
                     '',--@UltimoPeriodo  
                     null,--@5  
                     null,--@5   
                     @IdConvalidacion OUTPUT    
                       
          END      
          ELSE    
          BEGIN    
           SET @IdConvalidacion = @Existe    
          END             
  
        END -- FIN DEL VAL =1   
             
            
        if convert(decimal(5,2),@PromFinal) < 11  
         begin  
          If @pIdCurricula in (27,28)  
           begin  
            set @PromFinal = ROUND(@PromFinal,0)  
            set @PromReal = ROUND(@PromReal,0)  
           end   
          else  
           begin  
            set @PromFinal = 13  
            set @PromReal = 13  
           end   
         end   
        else  
         begin  
          set @PromFinal = ROUND(@PromFinal,0)  
          set @PromReal = ROUND(@PromReal,0)  
         end   
                           
        -- ACTUALIZAMOS EL ALUMNOCURRICULACURSO    
        UPDATE AlumnoCurriculaCurso    
        SET IdConvalidacion = @IdConvalidacion,    
        TipoCondicion = 'CO',    
        PromedioFinal = @PromFinal,    
        PromedioReal = @PromReal,    
        PromedioCondicion = 'A' ,  
        Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula' ,--@1       
        UsuarioModificacion=@pIdUsuario, --@1  
        FechaModificacion=GETDATE()--@1            
        WHERE IdAlumno = @IdActor   
        AND IdRegistro = @xIdRegistro  
        AND IdCurricula = @pIdCurricula  
        AND IdCurso = @CurIdCurso    
      END  -- FIN CUMPLE @Cumple = 1    
                   
      -- borramos la temporal  
      DELETE N FROM @CurCursos N      
      WHERE N.Id =(SELECT TOP 1 Id       
          FROM @CurCursos       
          ORDER BY Id)        
   END -- while  
  
   INSERT INTO @CurDes                    
   SELECT IdCurso,                             
   'NumVezCurso' = dbo.cAlumnoCurso_Pro_NumeroVez(@IdActor,@IdRegistro,@IdCurricula,IdCurso)                           
   FROM AlumnoCurriculaCurso AC with(nolock)                          
   WHERE IdAlumno = @IdActor                            
   AND IdRegistro = @xIdRegistro                            
   AND IdCurricula = @pIdCurricula                            
   AND IdModulo = @IdModulo                            
   AND isnull(PromedioCondicion,'D') <> 'A'                            
   AND TipoCondicion = 'RE'                            
     
     
   IF @pIdAutorizacion=1  
   begin  
        
    delete from @CurDes  
  
    INSERT INTO @CurDes                    
    SELECT IdCurso,                             
    'NumVezCurso' = 1  
    FROM AlumnoCurriculaCurso AC with(nolock)  
    WHERE IdAlumno = @IdActor  
    AND IdRegistro = @xIdRegistro  
    AND IdCurricula = @pIdCurricula  
    AND IdModulo = @IdModulo  
    --AND isnull(PromedioCondicion,'D') <> 'A'  
    --AND TipoCondicion = 'RE'  
      
    UPDATE AlumnoCurriculaCurso       
    SET IdConvalidacion = null,    
     TipoCondicion = 'RE',    
     PromedioFinal = null,    
     PromedioReal = null,    
     PromedioCondicion = null ,  
     Glosa= null ,--@1       
     UsuarioModificacion=@pIdUsuario, --@1  
     FechaModificacion=GETDATE()--@1        
    WHERE IdAlumno = @IdActor  
     AND IdRegistro = @xIdRegistro  
     AND IdCurricula = @pIdCurricula  
     AND IdModulo = @IdModulo    
   end  
  
   -- VERIFICAMOS SI HAY LA PROMOCION REGISTRADA QUE LE CORRESPONDE AL ALUMNO  
   SELECT @wIdPromocion = IdPromocion                                
   FROM Promocion   WITH (NOLOCK)                                
   WHERE IdEmpresa = @pIdEmpresa                                
   AND IdSede = @pIdSedeDestino                                
   AND IdPeriodo = @pIdPeriodo                    
   and IdProducto =  @pIdProducto                    
   AND IdCurricula = @pIdCurricula                                
   --AND IdModulo = @IdModulo                                
   AND Estado = 'A'           
                             
   -- sacamos la cantidad de cursos del producto    
   select @cCursosProducto = COUNT(1)    
   from CurriculaCurso  with(nolock)     
   where IdCurricula = @pIdCurricula    
  
   -- sacamos la cantidad de cursos en los que se va a matricular    
   select @cCursosMat = COUNT(1)    
   from @CurDes    
  
   IF @cCursosProducto = @cCursosMat    
    BEGIN    
     SET @TipoServicio = 'P'    
     SET @TipoCondicion = 'RE'    
    END    
   ELSE    
    BEGIN    
     SET @TipoServicio = 'C'    
     SET @TipoCondicion = 'CC'    
    END          
  
       
  end -- fin else if @IdProducto = @pIdProducto and   @IdCurricula = @pIdCurricula  
  
      
  select @IdRegistro = @xIdRegistro                             
  SET @wIdPromocion = ISNULL(@wIdPromocion,-1)                                
  ---           
  
  -- si no hay promocion no se registra nada en matricula ni alumno curso                                 
  IF  @wIdPromocion <> -1                                
  BEGIN    
    -- validar si tiene cronograma de pagos registrados  
    select @NumeroCuota = isnull(MAX(cuotanumero),0)   
    from CronogramaPago with(nolock)     
    where IdPromocion=@wIdPromocion   
  
    IF @NumeroCuota = 0  
     BEGIN          
  
        SELECT @Estado = 'KO'          
        SELECT @Resultado = 'No se ha registrado cronograma de pagos de la promocion.'+convert(varchar(10),@wIdPromocion)  
        SELECT @intMatriculaGenerada= ISNULL(@IdMatriculaNew,0)          
        RETURN  
     END                                 
    -- generamos el numero de matricula                              
    exec cMatricula_Gen_Numero @NumeroMatricula output                              
  
    if isnull(@Observacion,'')<>''  
       SET @IdProcedencia = 1  
    else  
     SET @IdProcedencia = 0       
                            
    EXECUTE cMatricula_Ins_Grabar_CargaHabil @pIdEmpresa, --@IdEmpresa    
               @pIdSedeDestino, --@IdSede    
               -1 , --@IdCampana    
               @IdActor, --@IdActor    
               @IdRegistro, --@IdRegistro                        
               @pIdCurricula, --@IdCurricula    
               @IdModulo, --@IdModulo    
               @wIdPromocion, --@IdPromocion    
               -1, --@IdGrupo    
               -1, --@IdSeccion    
               -1, --@IdAutorizacion    
               @NumeroMatricula, --@Numero    
               @pIdUsuario, --@InscritoIdUsuario    
               -1, --@InscritoIdEquipo    
               1, --@InscritoNo    
               null,  --@MatriculaFecha    
               -1, --@MatriculaIdUsuario    
               0, --@EsMatricula    
               0, --@EsComision    
               0, --@EsCerrado    
               -1, --@IdDescuento    
               -1, --@IdTipoMedio    
               -1, --@IdMedio    
               @IdProcedencia, --@IdProcedencia    
               -1, --@IdSocio    
               -1, --@IdConvenio    
               -1, --@IdEntidad    
               -1, --@IdBeca    
               -1, --@IdPlanPago    
               236,  --@IdMoneda    
               NULL, --@MontoMoneda    
               'I', --@TipoInscripcion                   
               @TipoCondicion, --@TipoCondicion    
               @TipoServicio,  --@TipoServicio    
               'MA', --@Tipo    
               null, -- @Observacion    
               'N', --@Estado    
               @pIdUsuario, --@UsuarioCreacion    
               'Q', --@CondicionPago    
               @pIdPeriodo, --@IdPeriodo    
               @Observacion,  
               @Numerocuota,  
               @IdPrecioSede,--@6  
               --Inicio --@7  
               @IdModuloReal,  
               @TipoCondicionNueva,  
               --Fin --@7  
               @IdMatriculaNew OUTPUT --@RetVal    
                 
          
    --SET @intMatriculaGenerada=@IdMatriculaNew                          
                                             
    WHILE EXISTS (SELECT * FROM @CurDes)                    
    BEGIN                        
  
      SELECT TOP 1 @IdCurso = IdCurso,                  
      @NumVezCurso =NumVezCurso                  
      from @CurDes                  
      ORDER BY Id                    
                                             
      EXEC cAlumnoCurso_Ins_Grabar   
           @IdActor, --@IdAlumno    
           @IdRegistro, --@IdRegistro    
           -1, --@IdAlumnoCurso    
           @pIdCurricula, --@IdCurricula                     
           @IdCurso, --@IdCurso    
           @IdMatriculaNew, --@IdMatricula    
           @wIdPromocion, --@IdPromocion    
           -1, --@IdGrupo    
           -1, --@IdSeccion    
           -1, --@IdMoneda    
           NULL, --@MontoMoneda    
           '', --@PromedioFinal    
           '', --@PromedioReal    
           -1, --@IdDecreto    
           '', --@PromedioNuevo    
           '', --@PromedioCondicion    
           -1, -- @SesionAsiste    
           -1,  --@SesionJustifica    
           -1, --@SesionTarde    
           -1, --@SesionFalta    
           0, --@EsMatricula    
           @TipoCondicion, --@TipoCondicion    
           @pIdUsuario,  --@UsuarioCreacion    
           @NumVezCurso   --@NumVezCurso    
                                    
      DELETE N FROM @CurDes N                    
      WHERE N.Id = ( SELECT TOP 1 Id                
      FROM @CurDes                     
  
      ORDER BY Id)          
    END;  -- end WHILE                                        
  
     
    --RZM (24/08/2012) ACTUALIZA OBSERVACION PREPAGO DE CARGA  
    if isnull(@IdProcedencia,0) = 0   
      UPDATE Matricula SET ObservacionPrepago =@Observacion  where IdMatricula=@IdMatriculaNew  
                                    
    -- registramos matricula pagante individual                                  
    exec cMatriculaPagante_Ins_Grabar @IdMatriculaNew,@IdActor,'N',236,0,0,null,1,'R',@pIdUsuario                                  
                                            
    -- sacamos los datos personales del alumno                                  
    SELECT @NumeroIdentidad = NumeroIdentidad,                                  
     @Direccion = DireccionCompleta,                                  
     @NombreCompleto = NombreCompleto,                                  
     @Telefonos = SUBSTRING(dbo.cActorTelefonoStr(IdActor),1,20)                                      
    FROM Actor  WITH (NOLOCK)                                    
    WHERE IdActor = @IdActor                                  
                                       
    -- registramos actor facturacion individual                                    
    exec cActorFacturacion_Ins_Grabar @IdMatriculaNew,@IdActor,2,@NumeroIdentidad,@NombreCompleto,@Direccion,-1,@Telefonos,0,0,0,@pIdUsuario                                  
                                     
    SET @intMatriculaGenerada = ISNULL(@IdMatriculaNew,0)                        
                                                            
    BEGIN               
     SELECT @Estado = 'OK'                                  
     SELECT @Resultado = 'Se genero correctamente la carga habil.'                            
     SELECT  @intMatriculaGenerada =ISNULL(@IdMatriculaNew,0)                                   
    END                                 
  END -- fin @wIdPromocion <> -1   
  ELSE -- NO HAY PROMOCION GENERADA                                 
    BEGIN  
      SELECT @Estado = 'KO'                          
      SELECT @Resultado = 'No se ha generado la promocion para el producto ' + dbo.cCurricula_Sel_Producto(@IdCurricula) + ' modulo '+ cast(@IdModulo AS varchar(5)) +' ,curricula ' + cast(@IdCurricula AS varchar(5))                                 
      SELECT @intMatriculaGenerada   =ISNULL(@IdMatriculaNew,0)                          
    END  
  END --- ELSE@val = 1   
END -- fin de todo