----Consolidaci�n de encuestas de cierre 2024-III IDAT  ---Reporte 10 - Nuevas encuestas de EVA 360 docente
declare @p22 int
set @p22=0
EXEC cFichaProgramacionResumen_Ins_Grabar @IdProgramacion=30155,@UsuarioCreacion=1,@RetVal=@p22 output
select�@p22