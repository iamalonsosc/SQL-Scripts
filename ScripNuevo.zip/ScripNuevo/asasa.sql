exec cSituacionAcademica_Sel_Listar @IdAlumno=1239552

SELECT TipoCondicion,*FROM MATRICULA 

UPDATE MATRICULA SET TipoCondicion='RP'
WHERE IDMATRICULA=653343

SELECT  *FROM PromocionGrupo WHERE IDPROMOCION=95473
SELECT top 10 *FROM AlumnoCursoNominaJson

exec AlumnoCursoActa_List @IdSede=34,@IdUnidadAcademica=57,@IdUnidadNegocio=1,@IdPeriodo=3816,@IdProducto=13721
exec cActaConsolidada_Sel @IdEmpresa=1,@IdSede=34,@IdFacultad=1,@IdUnidadNegocio=1,@IdUnidadAcademica=57,@IdPeriodo=3816,@IdProducto=13721,@usuario=446639

SELECT*FROM AlumnoCursoNomina WHERE SeccionNomina='0454.01.I.02.2024-III-I-A'
select TurnoNombre,FechaCreacion, *from ActaConsolidada where seccion='0454.01.I.02.2024-III-I-A' and IdSede=34

SELECT * FROM AlumnoCursoNomina WHERE IdMatricula=653343 AND IdCurso=14132
SELECT*FROM AlumnoCurso WHERE IdMatricula=653343 --AND IdCurso=14132


exec cAlumnoCurso_Con_CursosPeriodos @IdAlumno=1624315,@IdMatricula=653343

exec cAlumnoCursoAsistencia_Sel_Todos @IdSeccion=635904,@IdAlumno=1624315

exec cAlumnoCurso_Sel_CurriculaOficial @IdAlumno=1624315,@IdCurricula=5688,@IdCurso=14132

exec cAlumnoCursoAsistencia_Sel_Todos @IdSeccion=635904,@IdAlumno=1624315

exec cSistemaSuceso_Ins_Grabar @IdSistema=60,@Login=N'DESIDAT',@Formulario=N'FrmHistNotas',@Mensaje=N'Form: FrmHistNotas.cboUnidadAcademica_SelectionChangeCommitted Number line: 249 / Form: FrmHistNotas.sCargarComboProducto Number line: 677 / Form: FrmHistNotas.sMostrarMatricula Number line: 1027 / Form: FrmHistNotas.sCargarDatosCursos Number line: 568 / Form: DataRowCollection.Add Number line: 0 / Form: DataTable.InsertRow Number line: 0 / Form: DataTable.SetNewRecordWorker Number line: 0 / Form: DataTable.RaiseRowChanging Number line: 0 / Description: Column ''IdCurso'' is constrained to be unique.  Value ''14132'' is already present.'



SELECT 'SedeGeneral'=s.Nombre,'EmpresaNombre'=E.NombreOficial,
	'DireccionRegional'=ISNULL(S.DireccionRegional,''),
	'Departamento'=UU.Nombre,
	'Provincia'=UUU.Nombre,
	'Distrito'=U.Nombre,
	'Direccion'=S.Direccion,
	'Telefono'=ISNULL(s.Telefono ,'')
	FROM EmpresaSede ES WITH (NOLOCK)
	INNER JOIN Empresa E WITH (NOLOCK) ON ES.IdEmpresa=E.IdEmpresa
	INNER JOIN Sede S WITH (NOLOCK) ON ES.IdSede=S.IdSede
	INNER JOIN Ubigeo U WITH (NOLOCK) ON S.IdUbigeo=U.IdUbigeo
	INNER JOIN Ubigeo UU WITH (NOLOCK) ON U.IdDepartamento=UU.IdDepartamento
		AND UU.IdProvincia='00'
		AND UU.IdDistrito='00'
	INNER JOIN Ubigeo UUU WITH (NOLOCK) ON U.IdDepartamento=UUU.IdDepartamento
		AND U.IdProvincia=UUU.IdProvincia
		AND UUU.IdDistrito='00'
	WHERE ES.IdEmpresa=1