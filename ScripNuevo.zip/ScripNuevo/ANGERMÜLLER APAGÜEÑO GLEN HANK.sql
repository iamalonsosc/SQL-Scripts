--select*from Actor where NombreCompleto='ANGERM�LLER APAG�E�O GLEN HANK'
--select*from Usuario where IdActor=1442263


SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1442263 
--AND AC.IdCurso=9934 
--AND AC.IdCursoOriginal=9934 
--AND AC.EsMatricula=1
AND AC.IdMatricula=640117 
order by ac.idregistro,ac.IdAlumnoCurso desc


INSERT INTO AlumnoCurso VALUES (1442263,3,57,5604,9934,640117,96872,3,616224,null,null,'20.00','20.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)




DELETE FROM AlumnoCurso
where IdMatricula=597548 AND TipoCondicion='CC'

--select*from AlumnoCurso 

DELETE FROM AlumnoCurso
where IdMatricula=640117 AND TipoCondicion='CC'




UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL,PromedioFinal='20.00',PromedioReal= '20.00',IdAlumnoCurso=57,TipoCondicion='RE'
--select*from AlumnoCurriculaCurso 
where IdAlumno=1442263 and IdCurso=9934 AND IdRegistro=3

select*from AlumnoCurriculaCurso 
where IdAlumno=1445195 and IdCurso=9937