UPDATE Registro SET IdSede=33
WHERE IdActor=1280035
AND IdRegistro=1
AND IdProducto=9504
AND Estado='N'