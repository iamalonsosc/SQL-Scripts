
--SELECT*FROM ParametroUnidadAcademica 
--SJM
update ParametroUnidadAcademica set Valor8='L'
WHERE IdSede=34 AND Nombre='ParametroNomina2' AND IdProducto=13481


--SELECT*FROM ParametroUnidadAcademica 
--SJL
update ParametroUnidadAcademica set Valor8='L'
WHERE IdSede=33 AND Nombre='ParametroNomina2' AND IdProducto=13481


--SELECT*FROM ParametroUnidadAcademica 
--ATE
update ParametroUnidadAcademica set Valor8='L'
WHERE IdSede=36 AND Nombre='ParametroNomina2' AND IdProducto=13481


--LIMA NORTE
update ParametroUnidadAcademica set Valor8='L'
where  Nombre='ParametroNomina2' AND IdProducto=13481 AND IdSede=32

--CHICLAYO
update ParametroUnidadAcademica set Valor8='F'
where  Nombre='ParametroNomina2' AND IdProducto=13481 AND IdSede=35

--PIURA
update ParametroUnidadAcademica set Valor8='F'
where  Nombre='ParametroNomina2' AND IdProducto=13481 AND IdSede=37
--SELECT*FROM Sede