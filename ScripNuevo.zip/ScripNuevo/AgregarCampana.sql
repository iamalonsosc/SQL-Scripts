INSERT INTO CampanaVentaProducto VALUES (3,11548,-1,1,GETDATE(),1,GETDATE())
--(1 row affected)