-----------------------------------------------------------------------------    
--Creado por      : Jimy Mota          
--Funcionalidad   :    
--Utilizado por   :    
/*  
-----------------------------------------------------------------------------                                
Nro		FECHA		USUARIO			DESCRIPCION                                
-----------------------------------------------------------------------------          
@1		03/07/2018	JNAVIA			se agrega validaciones para tramites de carne de medio pasaje          
@2		09/05/2019	JLEO			se agrega validaciones de retiro de alumno y fecha vigencia        
@3		13/05/2019	JLEO			se agrega validaciones para alumnos en condici�n de retiro        
@4		20/05/2019	JLEO			se agrega validaciones para tramites de justificaci�n inasistencias  
@5		05/06/2019	JLEO			se elimina validaci�n para extenciones
@6		22/07/2019	JLEO			se agrega validaci�n para Alunnos en retiro de asignatura
@7		07/01/2020	JLEO			se mejora la validaci�n en el conteo de tr�mites para justificaci�n de inasistencias, se retira el punto @5
@8		09/12/2020	RSamame			Validacion por Baja Acad�mica    
@9		07/05/2021	JLEO			Se realiza mejoras en validaci�n en tramite de Justitificaci�n de inasistencia
@10		26.11.2021	EHuillca		Se coloca tildes faltantes a mensajes.	
@11		07.10.2022	EHuillca		Se agrega nueva validaci�n para Productos Desactivados Idat
@12		26.10.2022	JQuenta			Se agrega nueva validaci�n para Productos Desactivados Zegel
@13		02.02.2023	MBUENO			Se agrega la validacion de produtos desactivados dos tramites
@14		03.02.2023	MBUENO			Se realiza conversion del IdTramite a Varchar
@15		08.06.2023	MBUENO			Se agrega logica en IDAT para excluir el acarnet a los que no son secuenciales
@16		12.06.2023	MBUENO			Se corrige filtro de logica en IDAT
@17		26.03.2024	MBUENO			Se corrige logica secuenciales para carnet medio pasaje
@18		02.04.2024	MBUENO			Se agrega logica para los alumnos captacion
@19		15.04.2024	Alsanchez		Nueva logica carnet de medio pasaje 
*/
--DECLARE --@12
ALTER PROCEDURE [dbo].[cWFTramite_Val_WFTramiteSolicitud] 
@IdActor INT,
@IdTramite INT,
@RetVal VARCHAR(800) OUTPUT
AS
BEGIN
    SET DATEFORMAT DMY
    SET NOCOUNT ON;

	--SELECT @IdActor=1606956,@IdTramite=75,@RetVal='' --@12

	DECLARE @CompaniaSocio VARCHAR(8)=(SELECT CompaniaSocio FROM Empresa WITH(NOLOCK) WHERE IdEmpresa=1)--@8
	DECLARE @Codigo VARCHAR(8)=(SELECT mt.Codigo FROM MaestroTablaRegistro MTR WITH(NOLOCK)
								INNER JOIN MaestroTabla MT WITH(NOLOCK) ON MT.IdMaestroTabla=MTR.IdMaestroTabla
								INNER JOIN  WFTramite WFT WITH(NOLOCK) ON MTR.Codigo=WFT.Codigo
								WHERE WFT.IdTramite=@IdTramite	)--@8

	DECLARE @CodigoTramite VARCHAR(20) =(Select Codigo FROM WFTramite WHERE IdTramite = @IdTramite)
	
	DECLARE @IdProducto VARCHAR(500) --@12

    DECLARE @NombreCompleto VARCHAR(500)
    SET @RetVal = '1'

    /*VALIDACIONES DE REINGRESO*/
    IF(@IdTramite = 21) 
    BEGIN 
        IF EXISTS(
            SELECT 1  
			FROM
                WFTramiteSolicitud WITH(NOLOCK)
            WHERE
                IdActor = @IdActor
                AND IdEstado IN (1)
        ) 
        BEGIN
            SET @RetVal = '' 
        END 
    END

    /*VALIDACIONES*/
    IF(@IdTramite in (4, 18, 82)) 
    BEGIN 
        IF EXISTS(
            Select  1
            From
                Matricula M WITH(NOLOCK)
                Inner Join Promocion P WITH(NOLOCK) On M.IdPromocion = P.IdPromocion
                Inner Join Periodo PER WITH(NOLOCK) On P.IdPeriodo = PER.IdPeriodo
                Inner Join WFTramiteSolicitud SOL WITH(NOLOCK) On SOL.IdActor = M.IdActor
                Inner Join WFTramiteSede S WITH(NOLOCK) ON S.IdTramiteSede = SOL.IdTramiteSede
                Inner Join WFTramitePoblacion TP WITH(NOLOCK) On TP.IdTramiteSede = S.IdTramiteSede
                And TP.IdPeriodo = PER.IdPeriodo
                And TP.IdUnidadAcademica = P.IdUnidadAcademica
                And TP.IdUnidadNegocio = P.IdUnidadNegocio
            Where
                M.IdActor = @IdActor
                AND S.IdTramite = @IdTramite
                AND SOL.IdEstado IN (1, 8, 11)
                And Rtrim(Ltrim(TP.Disponible2)) <> ''
                And Rtrim(Ltrim(SOL.Fecha)) <> ''
                And Convert(datetime, SOL.Fecha) between TP.FechaInicio
                And TP.FechaFin
                And (
                        SUBSTRING(TP.Disponible2, 7, 4) 
                        + SUBSTRING(TP.Disponible2, 4, 2) 
                        + SUBSTRING(TP.Disponible2, 1, 2)
                    ) >= Convert(varchar, GETDATE(), 112)
        ) 
        BEGIN
            SET @RetVal = 'Ya has tramitado un carn� de medio pasaje y aun est� en vigencia, debes tramitar un duplicado' 
        END 
    
        IF Exists(
            Select 1
            From
                Matricula M WITH(NOLOCK)
                INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = M.IdPromocion
                INNER JOIN Periodo PER WITH(NOLOCK) On PER.IdPeriodo = P.IdPeriodo
				INNER JOIN WFTramiteSede TS WITH(NOLOCK) ON TS.IdSede = M.IdSede
                INNER Join WFTramitePoblacion TP WITH(NOLOCK) On TP.IdTramiteSede = TS.IdTramiteSede
                And TP.IdPeriodo = PER.IdPeriodo
                And TP.IdUnidadAcademica = P.IdUnidadAcademica
                And TP.IdUnidadNegocio = P.IdUnidadNegocio
                INNER JOIN MatriculaRetiro MR WITH(NOLOCK) On M.IdMatricula = MR.IdMatricula
            WHERE
                Convert(varchar, GETDATE(), 112) BETWEEN Convert(varchar, TP.FechaInicio, 112)
                AND Convert(varchar, TP.FechaFin, 112)
                AND M.IdActor = @IdActor
                And MR.Estado = 'R'
				AND MR.Tipo = 'RC'--@6
                And TS.IdTramite = @IdTramite
        ) -- @3 
        BEGIN
            SET @RetVal = 'Tu estado actual es retirado. No es posbile generar el carn� de medio pasaje.' 
        END 

		--@15 Inicio

		--Inicio @17
		--Alumno con matr�cula activa en carreras (seg�n la habilitaci�n del tr�mite)
		--No se habilitara para alumnos con cursos de repitencia en su cabecera 
		
		IF @CompaniaSocio = '00002700' --@19
				BEGIN
					DECLARE 
					@IdMatricula INT,
					@TipoCondicion varchar(20)
 
					SELECT TOP 1 @IdMatricula = IdMatricula , @TipoCondicion =  m.TipoCondicion
					FROM Matricula M WITH (NOLOCK)                   
					INNER JOIN Promocion P WITH (NOLOCK) ON M.IdPromocion = P.IdPromocion               
					WHERE M.IdActor = @IdActor  
					AND M.Estado = 'N'   
					AND M.EsMatricula = 1  
					AND P.IdUnidadNegocio = 1 
					ORDER BY ISNULL(M.MatriculaFecha, M.InscritoFecha) DESC
 
					IF @TipoCondicion = 'CC'
					BEGIN
						SET @RetVal = 'El tr�mite seleccionado no est� disponible para usted. Favor de comunicarse con SAE.'
					END
				END
		--@15 Fin

    END

    /*VALIDACIONES*/
    IF(@IdTramite in (5)) 
    BEGIN 
        IF NOT EXISTS(
            Select
                1
            from
                Matricula M WITH(NOLOCK)
                Inner Join Promocion P WITH(NOLOCK) On M.IdPromocion = P.IdPromocion
                Inner Join Periodo PER WITH(NOLOCK) On P.IdPeriodo = PER.IdPeriodo
                Inner Join WFTramiteSolicitud SOL WITH(NOLOCK) On SOL.IdActor = M.IdActor
                Inner Join WFTramiteSede S WITH(NOLOCK) ON S.IdTramiteSede = SOL.IdTramiteSede
                Inner Join WFTramitePoblacion TP WITH(NOLOCK) On TP.IdTramiteSede = S.IdTramiteSede
                And TP.IdPeriodo = PER.IdPeriodo
                And TP.IdUnidadAcademica = P.IdUnidadAcademica
                And TP.IdUnidadNegocio = P.IdUnidadNegocio
            Where
                M.IdActor = @IdActor
                AND S.IdTramite = @IdTramite
                AND SOL.IdEstado IN (1, 8, 11)
                And Rtrim(Ltrim(TP.Disponible2)) <> ''
                And Rtrim(Ltrim(SOL.Fecha)) <> ''
                And Convert(datetime, SOL.Fecha) between TP.FechaInicio
                And TP.FechaFin
                And (
                    SUBSTRING(TP.Disponible2, 7, 4) + SUBSTRING(TP.Disponible2, 4, 2) + SUBSTRING(TP.Disponible2, 1, 2)
                ) >= Convert(varchar, GETDATE(), 112)
        ) 
        BEGIN
            SET @RetVal = 'Si a�n no tienes un carn� de medio pasaje, no puedes pedir un duplicado.' --@10
        END 
    
        IF Exists(
            Select
                1
            From
                Matricula M WITH(NOLOCK)
                INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = M.IdPromocion
                INNER JOIN Periodo PER WITH(NOLOCK) On PER.IdPeriodo = P.IdPeriodo
                INNER JOIN WFTramiteSede TS WITH(NOLOCK) ON TS.IdSede = M.IdSede
                INNER Join WFTramitePoblacion TP WITH(NOLOCK) On TP.IdTramiteSede = TS.IdTramiteSede
                And TP.IdPeriodo = PER.IdPeriodo
                And TP.IdUnidadAcademica = P.IdUnidadAcademica
                And TP.IdUnidadNegocio = P.IdUnidadNegocio
                INNER JOIN MatriculaRetiro MR WITH(NOLOCK) On M.IdMatricula = MR.IdMatricula
            WHERE
                Convert(varchar, GETDATE(), 112) BETWEEN Convert(varchar, TP.FechaInicio, 112)
                AND Convert(varchar, TP.FechaFin, 112)
                AND M.IdActor = @IdActor
                And MR.Estado = 'R'
				AND MR.Tipo = 'RC'--@6
                AND TS.IdTramite = @IdTramite
        ) -- @3 
        BEGIN
            SET @RetVal = 'Tu estado actual es retirado. No es posible generar el carn� de medio pasaje.' 
        END 
    END

    /*Justificaci�n de inasistencias*/
    -- @4 
    IF(@IdTramite in (23)) 
    BEGIN
		--@9
		Declare @TABMATRICULACURSOGRUPO
		TABLE (
			IdTramiteSolicitud INT, 
			IdMatricula INT, 
			IdUnidadNegocio INT, 
			IdSede INT, 
			NumeroVecesTramite INT)

		Declare @TABMATRICULACURSO 
		TABLE (
			Id INT Identity(1,1), 
			ValidaTramite INT, 
			NumeroDeTramite INT, 
			IdMatricula INT, 
			IdUnidadNegocio INT, 
			IdSede INT, 
			NumeroVecesTramite INT)

		Declare @TABVALIDATRAMITE
			TABLE (
				Id INT Identity(1,1), 
				NumeroDeTramite INT, 
				IdUnidadNegocio INT, 
				NumeroVecesTramite INT)

		Declare @MinID INT = 1, @MaxID INT, @NumeroDeTramite INT, @IdUnidadNegocio INT, @NumeroVecesTramite INT

		INSERT INTO @TABMATRICULACURSOGRUPO
		SELECT  SOL.IdTramiteSolicitud,
				AC.IdMatricula, 
				PRO.IdUnidadNegocio, 
				PRO.IdSede, 
				ISNULL(PUA.Valor4,3)
			 FROM WFTramiteSolicitud SOL WITH(NOLOCK)
				 Inner Join WFTramiteSede WFTS WITH(NOLOCK) On SOL.IdTramiteSede = WFTS.IdTramiteSede
				 Inner join WFTramiteSolicitudAsistenciaDetalle WFTSAD WITH(NOLOCK) On WFTSAD.IdTramiteSolicitud = SOl.IdTramiteSolicitud
				 Inner Join AlumnoCurso AC WITH(NOLOCK)On AC.IdAlumno = SOl.IdActor AND AC.IdSeccion = WFTSAD.IdSeccion
				 Inner Join Seccion SE WITH(NOLOCK) On SE.IdSeccion = AC.IdSeccion
				 Inner join Promocion PRO WITH(NOLOCK) On PRO.IdPromocion = SE.IdPromocion
				 Inner Join Periodo PER WITH(NOLOCK) On PER.IdPeriodo = PRO.IdPeriodo
				 Left Join ParametroUnidadAcademica PUA  WITH(NOLOCK) ON PUA.IdUnidadNegocio = PRO.IdUnidadNegocio 
																		AND PUA.IdUnidadAcademica = PRO.IdUnidadAcademica
																		AND PUA.Nombre = 'PctMaxFaltas'
																		AND PUA.IdSede = PRO.IdSede
			 WHERE SOL.IdActor = @IdActor
				 And IdTramite =@IdTramite
				 And AC.EsMatricula = 1
				 And AC.Estado = 'NO'
				 And SOL.IdEstado not in (14)
				 And CONVERT(VARCHAR(8), GETDATE(), 112) BETWEEN CONVERT(VARCHAR(8), PER.Inicio, 112) And CONVERT(VARCHAR(8), PER.Fin, 112)
			 GROUP BY SOL.IdTramiteSolicitud,AC.IdMatricula, PRO.IdUnidadNegocio, PRO.IdSede, PUA.Valor4

		INSERT INTO @TABMATRICULACURSO
		SELECT  CASE WHEN COUNT(IdTramiteSolicitud) >= ISNULL(NumeroVecesTramite,3) THEN 1 ELSE 0 END As 'ValidaTramite',COUNT(IdTramiteSolicitud),IdMatricula,IdUnidadNegocio,IdSede,NumeroVecesTramite
		FROM @TABMATRICULACURSOGRUPO
		GROUP BY IdMatricula,IdUnidadNegocio,IdSede,NumeroVecesTramite

		IF Exists (Select 1 from @TABMATRICULACURSO)
		BEGIN
	
			INSERT INTO @TABVALIDATRAMITE
			SELECT NumeroDeTramite,IdUnidadNegocio,NumeroVecesTramite FROM @TABMATRICULACURSO WHERE ValidaTramite = 0

			IF Exists (Select 1 from @TABVALIDATRAMITE)
			BEGIN
				Select @MaxId = Max(Id) from @TABVALIDATRAMITE 

				WHILE @MinID <= @MaxID
				BEGIN

					Select 
						@NumeroDeTramite = NumeroDeTramite, 
						@IdUnidadNegocio = IdUnidadNegocio,
						@NumeroVecesTramite = NumeroVecesTramite 
					FROM @TABVALIDATRAMITE 
					Where Id = @MinID

					If @IdUnidadNegocio = 1
					BEGIN
						IF @NumeroDeTramite >= @NumeroVecesTramite
						BEGIN
							SET @RetVal = 'No es posible generar m�s justificaciones debido a que se ha superado el l�mite de solicitudes.' --@10
						END
					END

					SET @MinID = @MinID + 1
				END
			END
			ELSE
			BEGIN
				SET @RetVal = 'No es posible generar m�s justificaciones debido a que se ha superado el l�mite de solicitudes.' --@10
			END
		END
		--@9
    END
	--@8
	/*Validacion por CompaniaSocio*/
	IF (@CompaniaSocio='00002500')
	BEGIN
		/*Tr�mite Gen�rico*/
		IF (@Codigo='Tramites')
		BEGIN
			/*Validacion por Baja Acad�mica*/
			IF EXISTS (SELECT DISTINCT 1 FROM Matricula ma WITH(NOLOCK)
			inner join Promocion pr WITH(NOLOCK) on ma.IdPromocion=pr.IdPromocion 
			inner join Registro re WITH(NOLOCK) on ma.IdActor=re.IdActor WHERE ma.IdActor=@IdActor and re.Estado='B' and pr.IdUnidadAcademica in (1,57))
			BEGIN
				SET  @RetVal='Tiene Baja Acad�mica. No es posible generar el tr�mite.'
			END	
		END	
		--Inicio @12
		IF EXISTS(SELECT DISTINCT 1 FROM MaestroTablaRegistro WITH(NOLOCK) 
			where IdMaestroTabla = 2053 AND IdMaestroRegistroTipo = 29675 AND Disponible5 ='0' AND Disponible1 = CONVERT(VARCHAR, @IdTramite) --@14
			OR @CodigoTramite in ('SOLCORNOTA' , 'SOLJUSINA' ) ) --@13
		BEGIN
			--DECLARE @IdProducto VARCHAR(500) --@12
			SET @IdProducto = (Select Valor from Parametro where Nombre = 'ProductoDesactivado')

			IF Exists(
				Select
                1
				From
					Matricula M WITH(NOLOCK)
					INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = M.IdPromocion
					INNER JOIN Periodo PER WITH(NOLOCK) On PER.IdPeriodo = P.IdPeriodo
				WHERE
					M.IdActor = @IdActor
					AND M.Estado != 'X'
					AND M.EsMatricula = 1
					AND CHARINDEX(CONVERT(VARCHAR(500),P.IdProducto),@IdProducto)>0
			) -- @3 
			BEGIN
				SET @RetVal = 'El tr�mite seleccionado no est� disponible para usted.' 
				--SELECT @RetVal
				--RETURN
			END 
			ELSE
			BEGIN
				SET @RetVal = '1'
				--SELECT @RetVal
				--RETURN
			END

		END
		--Fin @12
	END
	--@8
	--Inicio @11
	IF @CompaniaSocio = '00002700'
	BEGIN
		IF EXISTS(SELECT DISTINCT 1 FROM MaestroTablaRegistro WITH(NOLOCK) 
			WHERE IdMaestroTabla = 2038 AND IdMaestroRegistroTipo = 29617 AND Disponible5 ='0' AND Disponible1 = CONVERT(VARCHAR, @IdTramite) --@14
			OR @CodigoTramite in ('SOLCORNOTA' , 'SOLJUSINA' )  ) --@13
		BEGIN
			--DECLARE @IdProducto VARCHAR(500) --@12
			SET @IdProducto = (Select Valor from Parametro where Nombre = 'ProductoDesactivado')

			IF Exists(
				Select
 1
				From
					Matricula M WITH(NOLOCK)
					INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = M.IdPromocion
					INNER JOIN Periodo PER WITH(NOLOCK) On PER.IdPeriodo = P.IdPeriodo
				WHERE
					M.IdActor = @IdActor
					AND M.Estado != 'X'
					AND M.EsMatricula = 1
					AND CHARINDEX(CONVERT(VARCHAR(500),P.IdProducto),@IdProducto)>0
			) -- @3 
			BEGIN
				SET @RetVal = 'El tr�mite seleccionado no est� disponible para usted.' 
			END 

		END
	END
	--Fin @11


    SET NOCOUNT OFF;
END
