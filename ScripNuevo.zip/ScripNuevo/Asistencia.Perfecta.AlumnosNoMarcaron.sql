--INSERTAR LAS ASISTENCIAS ENVIADAS EN EXCEL QUE NO SE HAN MARCADO
DECLARE @Asistencia AS TABLE (
	id int identity,
	CodigoAlumno varchar(20),
	CodigoSeccion VARCHAR(20),
	observacion varchar(255)
)
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('AT43187021','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('AT72478888','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A19103363','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A19202343','0448.23.00768')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A19202343','0743.23.00641')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A19202343','0453.23.00131')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A19202343','0530.23.03045')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A19202343','0263.23.05995')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A19202343','0157.23.04234')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('CH70389594','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('CH75803838','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT75166032','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('LN70474102','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('LN04015466','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT72294695','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT74971793','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT76845101','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT77279660','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT42144413','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('LN76602690','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT70912543','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT76165225','0448.23.00722')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT76165225','0743.23.00589')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT76165225','0453.23.00175')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT76165225','0530.23.02809')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT76165225','0263.23.06002')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('PT76165225','0157.23.04468')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SM61123589','0712.23.01340')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SM61123589','0157.23.04209')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SM61123589','0263.23.05073')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SM61123589','0530.23.02747')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV72326920','0432.23.01249')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV72326920','0712.23.01512')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV72326920','0157.23.04238')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV72326920','0530.23.02770')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A17202698','0432.23.01256')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A17202698','0488.23.00584')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A17202698','0712.23.01522')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A17202698','0157.23.04496')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A17202698','0263.23.05984')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A17202698','0530.23.03072')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV70115632','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('A20100399','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV72646231','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV47491106','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV40845634','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV44148698','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV48351720','0447.23.00267')
INSERT INTO @Asistencia (CodigoAlumno,CodigoSeccion) VALUES ('SV72199569','0447.23.00267')

DECLARE  @MIN INT, @MAX INT, @CodigoAlumno VARCHAR(20), @CodigoSeccion VARCHAR(20), @Observacion VARCHAR(255), @nroAsistencias INT 

SELECT @MIN=MIN(ID), @MAX=MAX(ID) FROM @Asistencia

WHILE @MIN <= @MAX
BEGIN
	SET @CodigoAlumno = NULL
	SET @nroAsistencias = NULL
	SET @Observacion = 'ASISTENCIA PERFECTA - Ticket #45531'

	SELECT @CodigoAlumno = CodigoAlumno, @CodigoSeccion = CodigoSeccion FROM @Asistencia WHERE ID=@MIN

	INSERT INTO AlumnoCursoAsistencia
	SELECT DISTINCT HS.IdSeccion, HS.IdHorario,HS.IdSesion,AC.IdAlumno,NULL,'A',@Observacion,1,GETDATE()
	from Matricula m WITH (NOLOCK)
	INNER JOIN Alumno AL WITH (NOLOCK) ON m.IdActor=al.IdAlumno
	INNER JOIN AlumnoCurso ac WITH (NOLOCK) ON m.IdMatricula=ac.IdMatricula
	INNER JOIN HorarioSesion HS WITH (NOLOCK) ON AC.IdSeccion=HS.IdSeccion
	INNER JOIN Seccion se WITH (NOLOCK) ON hs.IdSeccion=se.IdSeccion
	INNER JOIN Promocion PR WITH (NOLOCK) ON SE.IdPromocion=PR.IdPromocion
	LEFT JOIN AlumnoCursoAsistencia ACA WITH (NOLOCK) ON ACA.IdSeccion=HS.IdSeccion AND ACA.IdSesion=HS.IdSesion AND ACA.IdHorario=HS.IdHorario AND ACA.IdAlumno=AC.IdAlumno 
	WHERE PR.IdEmpresa=1
	AND PR.IdFacultad=1
	--AND PR.IdUnidadNegocio=1
	--AND PR.IdSede=46
	AND PR.IdPeriodoAnual IN (2023)
	AND ACA.IdSeccion IS NULL 
	--AND CONVERT(VARCHAR,HS.Fecha,112) BETWEEN '20230206' AND '20230227'
	AND M.EsMatricula=1
	AND M.Estado='N'
	AND HS.Estado!='X' 
	AND HS.EsPostergado=0
	AND AL.CodigoAnterior = @CodigoAlumno
	AND SE.Codigo = @CodigoSeccion

	SELECT @nroAsistencias=count(Observacion) FROM AlumnoCursoAsistencia aca
	INNER JOIN Alumno AL WITH (NOLOCK) ON aca.IdAlumno=al.IdAlumno
	INNER JOIN Seccion se WITH (NOLOCK) ON aca.IdSeccion=se.IdSeccion
	WHERE  AL.CodigoAnterior = @CodigoAlumno
	AND SE.Codigo = @CodigoSeccion
	AND ACA.Observacion = @Observacion

	UPDATE @Asistencia SET observacion=CONCAT('Asistencias Registradas: ',@nroAsistencias) WHERE id= @MIN

	SET @MIN = @MIN+1
END
SELECT * FROM @Asistencia