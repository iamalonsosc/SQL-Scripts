BEGIN
	--SET DATEFORMAT DMY
	--SET DATEFIRST 1 
	SET NOCOUNT ON

	DECLARE 
	@CurID INT, 
	@MaxID INT,
	@IdSeccion INT,
	@Minutos INT,
	@IdTurno INT,
	@HoraInicio INT,
	@HoraFin INT,
	@IdFacilitador INT,
	@LoginFacilitador VARCHAR(20)='fpprofesor'

	DECLARE @DatosSeccion AS TABLE 
	(Id INT IDENTITY, 
	Idseccion INT,
	IdTurno INT,
	Minutos INT)

	SELECT @IdFacilitador=IdFacilitador
	FROM Facilitador WITH(NOLOCK) 
	WHERE CodigoAnterior=@LoginFacilitador

	--se seleccionan todas las secciones de la promocion
	INSERT INTO @DatosSeccion
	SELECT SE.Idseccion,SE.IdTurno, CASE WHEN CC.CursoSesion>0 THEN(CC.CursoTeoria+CC.CursoPractica)/CC.CursoSesion*45
	ELSE 90 END AS MINUTOS  FROM Promocion PRO
	INNER JOIN Periodo PE ON PE.IdPeriodo = PRO.IdPeriodo
	INNER JOIN PromocionGrupo PG ON PG.IdPromocion=PRO.IdPromocion
	INNER JOIN Seccion SE ON SE.IdPromocion=PRO.IdPromocion
	INNER JOIN CurriculaCurso CC WITH(NOLOCK) ON PRO.IdCurricula=CC.IdCurricula AND ISNULL(PRO.IdModulo,1)=CC.IdModulo AND SE.IdCurso=CC.IdCurso
	INNER JOIN Curso CR WITH(NOLOCK) ON CC.IdCurso=CR.IdCurso
	WHERE PRO.IdUnidadAcademica=50
	AND PRO.IdUnidadNegocio=26
	AND PE.Codigo IN ('2024-II','2024-III')
	AND PRO.Estado='A' 
	AND PG.Estado='A'
	AND SE.Estado='A'
	
	

	--se recorre todas las secciones de la promocion
	SELECT @CurID=Min(Id), @MaxID=Max(Id) FROM @DatosSeccion  
	WHILE @MaxID >= @CurID
	BEGIN

	SELECT @IdSeccion=IdSeccion,
		@IdTurno=IdTurno,
		@Minutos=Minutos
		FROM @DatosSeccion 
		WHERE Id=@CurID

			--se calcula la hora de inicio y fin de la seccion 
			SELECT @HoraInicio=MIN(HoraInicio)
			FROM TurnoHorario WITH(NOLOCK)
			WHERE IdTurno=@IdTurno
			SELECT @HoraFin = CAST(REPLACE(SUBSTRING(CONVERT(VARCHAR,DATEADD(MINUTE,@Minutos,CONVERT(DATETIME,dbo.gHhMmStr(@HoraInicio),108)),108),1,5),':','') AS INT)

			--se inserta el horario de la seccion
			EXEC cSeccionHorario_Ins_Grabar @IdSeccion,1,@HoraInicio,@HoraFin,NULL,'',NULL,NULL,NULL

			--se inserta el profesor ficticio
			--EXEC cSeccionProfesor_Ins_Grabar @IdSeccion,@IdFacilitador,1,1,1

		SET @CurID = @CurID +1
	END

	SET NOCOUNT OFF
END
