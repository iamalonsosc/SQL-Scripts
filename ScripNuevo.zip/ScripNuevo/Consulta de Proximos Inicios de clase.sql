
-- CADA INICIO DE DEBE ENVIAR MONITOREO, AHORA SE DEBE ENVIAR REPORTE DE LINK X SECCIONES REPORTE YA EXISTENTE EN SMART 

declare @inicio int = convert(varchar,dateadd(day,-160,getdate()),112)
declare @fin int = 20261231

select Programa , periodo , MesInicio , InicioClase , mesfin, FinClase  ,sum(CantPreMatriculados) PreMatriculados , sum(CantMatriculados) Matriculados ,  'Modulos' = ISNULL ( STUFF((    
     
	 SELECT ' ' + IDMODULO  FROM (
	  SELECT  DISTINCT CONVERT(VARCHAR(100),P2.IDMODULO) IDMODULO
      FROM promocion P2 WITH(NOLOCK)  
	  INNER JOIN PERIODO PE2 ON PE2.IDPERIODO = P2.IDPERIODO
      WHERE PE2.CODIGO = PERIODO AND PE2.idunidadnegocio = 1 ) T
      FOR XML PATH('')  
      ),1,1,'') , '' )   ,
	  
	  sum(cantSecciones ) CantidadSecciones 
	  
	   from (
select distinct  ua.nombre Programa , pe.codigo Periodo,
datename(MONTH , case when p.idunidadnegocio = 1 then convert(varchar, pe.inicio, 112) else convert(varchar, p.FechaInicioPeriodo, 112) end ) MesInicio,
case when p.idunidadnegocio = 1 then convert(varchar, pe.inicio, 112) else convert(varchar, p.FechaInicioPeriodo, 112) end InicioClase,
datename(MONTH , case when p.idunidadnegocio = 1 then convert(varchar, pe.fin, 112) else convert(varchar, p.FechaFinPeriodo, 112) end ) MesFin,
case when p.idunidadnegocio = 1 then convert(varchar, pe.Fin, 112) else convert(varchar, p.FechaFinPeriodo , 112) end FinClase,
(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 1 and pe.IdPeriodo = p2.IdPeriodo  ) CantMatriculados,
(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 0 and pe.IdPeriodo = p2.IdPeriodo  ) CantPreMatriculados,
(select count(1) from Seccion s join PromocionGrupo pg2 on pg2.IdPromocion = s.IdPromocion and pg2.IdGrupo = s.IdGrupo 
 where s.IdPromocion = p.idpromocion and pg2.idtiposeccion = 28819 and s.Estado = 'A' and s.EsAsincronico = 0 ) cantSecciones
from periodo pe 
inner join promocion p on pe.idperiodo = p.idperiodo
inner join unidadacademica ua on pe.idunidadacademica = ua.idunidadacademica 
where case when p.idunidadnegocio = 1 then convert(varchar, pe.inicio, 112) else convert(varchar, p.FechaInicioPeriodo, 112) end between  @inicio and @fin 
and p.idunidadnegocio = 1 ) t
group by Programa , periodo , MesInicio , InicioClase , mesfin , FinClase 
order by 4


GO

-- ============================================================================

--declare @inicio int = convert(varchar,dateadd(day,-120,getdate()),112)
--declare @fin int = 20241231

--select Programa , periodo , MesInicio , InicioClase , mesfin, FinClase , ModulosProgramados  ,
--sum(CantPreMatriculados) PreMatriculados , sum(CantMatriculados) Matriculados, SUM(CantMatriculadosCaptacion)MatriculadosCaptacion,SUM(CantPreMatriculadosCaptacion)PreMatriculadosCaptacion,
--SUM(CantMatriculadosSecuencial)MatriculadosSecuencial,SUM(CantPreMatriculadosSecuencial)PreMatriculadosSecuencial    from (
--select distinct  ua.nombre Programa , pe.codigo Periodo,
--datename(MONTH , case when p.idunidadnegocio = 1 then convert(varchar, pe.inicio, 112) else convert(varchar, p.FechaInicioPeriodo, 112) end ) MesInicio,
--case when p.idunidadnegocio = 1 then convert(varchar, pe.inicio, 112) else convert(varchar, p.FechaInicioPeriodo, 112) end InicioClase,
--datename(MONTH , case when p.idunidadnegocio = 1 then convert(varchar, pe.fin, 112) else convert(varchar, p.FechaFinPeriodo, 112) end ) MesFin,
--case when p.idunidadnegocio = 1 then convert(varchar, pe.fin, 112) else convert(varchar, p.FechafinPeriodo, 112) end FinClase,
--(
--SELECT STUFF((
--              SELECT ','+ cast(p2.IdModulo AS nvarchar(255))
--from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 1 and pe.IdPeriodo = p2.IdPeriodo
--group by p2.IdModulo 
--              FOR XML PATH('')),1,1,'') 
--)ModulosProgramados,
--(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 1 and pe.IdPeriodo = p2.IdPeriodo  ) CantMatriculados,
--(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 0 and pe.IdPeriodo = p2.IdPeriodo  ) CantPreMatriculados,
--(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 1 and M.Tipo = 'MA' AND M.IdPeriodo IS NULL AND pe.IdPeriodo = p2.IdPeriodo  ) CantMatriculadosCaptacion,
--(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 0 AND M.Tipo = 'MA' AND M.IdPeriodo IS NULL AND pe.IdPeriodo = p2.IdPeriodo  ) CantPreMatriculadosCaptacion,
--(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 1 and M.Tipo != 'MA' AND M.IdPeriodo IS NOT NULL AND pe.IdPeriodo = p2.IdPeriodo  ) CantMatriculadosSecuencial,
--(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 0 AND M.Tipo != 'MA' AND M.IdPeriodo IS NOT NULL AND pe.IdPeriodo = p2.IdPeriodo  ) CantPreMatriculadosSecuencial
-- from periodo pe 
--inner join promocion p on pe.idperiodo = p.idperiodo
--inner join unidadacademica ua on pe.idunidadacademica = ua.idunidadacademica 
--where case when p.idunidadnegocio = 1 then convert(varchar, pe.inicio, 112) else convert(varchar, p.FechaInicioPeriodo, 112) end between  @inicio and @fin 
--and p.idunidadnegocio = 1 ) t
--group by Programa , periodo , MesInicio , InicioClase , mesfin , FinClase , ModulosProgramados 
--order by 4

--GO

--declare @inicio int = 20211020
--declare @fin int = 20211030

--select distinct s.codigo,s.idsede, p.idunidadnegocio , ua.nombre , ua.idunidadacademica, pe.codigo,
--case when p.idunidadnegocio = 1 then convert(varchar, pe.inicio, 112) else convert(varchar, p.FechaInicioPeriodo, 112) end InicioClase,
----case when p.idunidadnegocio = 1 then convert(varchar, pe.fin, 112) else convert(varchar, p.FechaFinPeriodo, 112) end Fin,
--(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 1 
--and  p2.IdUnidadNegocio = pe.IdUnidadNegocio and p2.IdUnidadAcademica = pe.IdUnidadAcademica and p2.IdSede = pe.IdSede and pe.IdPeriodo = p2.IdPeriodo  ) CantMatriculados,
--(select count(1) from Matricula m inner join promocion p2 on p2.idpromocion = m.idpromocion where m.estado = 'N' and m.esmatricula = 0 
--and  p2.IdUnidadNegocio = pe.IdUnidadNegocio and p2.IdUnidadAcademica = pe.IdUnidadAcademica and p2.IdSede = pe.IdSede and pe.IdPeriodo = p2.IdPeriodo  ) CantPreMatriculados
-- from periodo pe 
--inner join promocion p on pe.idperiodo = p.idperiodo
--inner join sede s on pe.idsede = s.idsede 
--inner join unidadacademica ua on pe.idunidadacademica = ua.idunidadacademica 
--where case when p.idunidadnegocio = 1 then convert(varchar, pe.inicio, 112) else convert(varchar, p.FechaInicioPeriodo, 112) end between  @inicio and @fin
--order by p.idunidadnegocio
