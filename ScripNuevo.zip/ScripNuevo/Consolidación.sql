DECLARE @idSede INT = 38
update EmpresaSedeParametro set Valor = '0.01' WHERE Nombre= 'PcjeRptaEncAca' and IdSede = @idSede

--select * from sede where idsede=38
 
--- PROCESAR ENCUESTAS IDAT 
declare @table table (id int identity(1,1), Idprograma int)

insert into @table values(6139)
insert into @table values(6200)
insert into @table values(6201)
insert into @table values(6203)
insert into @table values(6204)
insert into @table values(6207)
insert into @table values(6208)
insert into @table values(6209)
insert into @table values(6211)
insert into @table values(6213)
insert into @table values(6214)
insert into @table values(6224)
insert into @table values(6234)
insert into @table values(6235)
insert into @table values(6236)
insert into @table values(6237)
insert into @table values(6250)
insert into @table values(6251)
insert into @table values(6252)
insert into @table values(6253)
insert into @table values(6254)
insert into @table values(6255)
insert into @table values(6256)
insert into @table values(6265)
insert into @table values(6266)
insert into @table values(6267)


declare @min int, @max int , 	@IdProgramacion INT,  @UsuarioCreacion INT, @RetVal INT

select @min = min(id), @max=max(id) from @table

while @min <= @max 
begin

	set @IdProgramacion = null 
	set @UsuarioCreacion = 1
	set @RetVal = null

	select @IdProgramacion = Idprograma from @table where id = @min 

	execute [dbo].[cFichaProgramacionResumen_Ins_Grabar]  
	@IdProgramacion,  
	@UsuarioCreacion ,  
	@RetVal OUTPUT

	select @RetVal

	set @min = @min + 1
end 

update EmpresaSedeParametro set Valor = '0.15' WHERE Nombre= 'PcjeRptaEncAca' and IdSede = @idSede