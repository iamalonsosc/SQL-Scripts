--����������������������������������������������������������������������������            
--Creado por      : Jose Leo (24/09/2019)            
--Funcionalidad   : Permite insertar un registro de la tabla EnvioCorreo            
--����������������������������������������������������������������������������            
/*                       
-----------------------------------------------------------------------------                   
Nro  FECHA   USUARIO   DESCRIPCION                        
-----------------------------------------------------------------------------                    
@1  26.05.2021  JLEO   Se agrega validaciones para registro de correos            
@2      05.07.2022  AFLORESI  Se adiciona CodigoRemitente para unificar proceso con EVA            
@3      28.09.2022  PUCHUYA   Se agrega parametro CodigoRemitente- y disponible6   
@4      05.01.2022  FETORRES  Se agrega el parametro IdMatricula       
@5      09.02.2023  JQuenta   Se agrega parametro Disponible7         
*/              
CREATE PROCEDURE [dbo].[cEnvioCorreo_Ins_Grabar]            
@profile_name VARCHAR(256),            
@recipients VARCHAR(MAX),            
@copy_recipients VARCHAR(MAX) = NULL,             
@blind_copy_recipients VARCHAR(MAX) = NULL,            
@subject VARCHAR(510),            
@body VARCHAR(MAX),             
@body_format VARCHAR(20),            
@Estado INT = 0,              
@Usuario VARCHAR(20) = 1,            
@FechaEnvio DATETIME = NULL,            
@Disponible1 VARCHAR(MAX) = NULL,            
@Disponible2 VARCHAR(MAX) = NULL,            
@Disponible3 VARCHAR(MAX) = NULL,            
@Disponible4 VARCHAR(MAX) = NULL,            
@Disponible5 VARCHAR(MAX) = NULL,            
@Disponible6 VARCHAR(MAX) = NULL,            
@CodigoRemitente VARCHAR(MAX) = NULL, --@3 ,          
@IdMatricula INT = NULL,      
@Disponible7 VARCHAR(MAX) = NULL --@5   
AS            
BEGIN            
            
 --@1            
 DECLARE             
  @str VARCHAR(max) = '',             
  @strFinal VARCHAR(max)            
            
 IF ISNULL(@CodigoRemitente,'') = '' SET @CodigoRemitente = 'SMART' --@3            
            
 IF LEN(RTRIM(LTRIM(ISNULL(@body,'')))) = 0 SET @Estado = -1            
            
 IF @Estado <> -1            
 BEGIN            
  DECLARE @TemporalRecipients TABLE (Id INT IDENTITY(1,1), Correo VARCHAR(250))            
            
  INSERT INTO @TemporalRecipients            
  SELECT DATA FROM dbo.Split(@recipients,';')            
             
  SELECT @str =  COALESCE((CASE WHEN dbo.ValidarEmail(Correo) = 1 THEN ISNULL(@str,'') + Correo ELSE @str + '' END)  + '; ', '')            
  FROM  @TemporalRecipients            
             
  Select @strFinal = COALESCE(@strFinal + '; ','') + DATA             
  FROM dbo.split(@str,';')             
  WHERE DATA <> ''            
            
  IF LEN(RTRIM(LTRIM(ISNULL(@strFinal,'')))) > 0            
  BEGIN            
   SET @recipients = @strFinal            
  END            
  ELSE            
  BEGIN            
   SET @Estado = -1            
  END            
 END            
 --@1            
             
 INSERT INTO BDSMTP.[dbo].[EnvioCorreo]            
           ([NombrePerfil]            
           ,[Enviado]            
           ,[Copia]            
           ,[CopiaOculta]            
           ,[Asunto]            
           ,[Mensaje]            
           ,[FormatoMensaje]            
           ,[Estado]            
           ,[FechaEnvio]            
           ,[UsuarioEnvio]            
           ,[FechaModificacion]            
           ,[UsuarioModificacion]            
           ,[Disponible1]            
           ,[Disponible2]            
           ,[Disponible3]            
           ,[Disponible4]            
           ,[Disponible5]            
     ,[Disponible6] --@3            
     ,[CodigoRemitente]--@2          
  ,IdMatricula -- @4    
  ,[Disponible7]) --@5   
     VALUES            
           (@profile_name            
           ,@recipients            
           ,@copy_recipients            
           ,@blind_copy_recipients            
           ,@subject            
           ,@body            
           ,@body_format            
           ,@Estado            
           ,GETDATE()            
           ,@Usuario            
           ,GETDATE()            
           ,@Usuario            
           ,@Disponible1            
           ,@Disponible2        
           ,@Disponible3            
           ,@Disponible4            
           ,@Disponible5            
     ,@Disponible6 --@3            
     ,@CodigoRemitente --@2 --@3            
  ,@IdMatricula -- @4   
  ,@Disponible7) --@5            
            


END 

select * from EnvioCorreo where NombrePerfil = 'Smart' and year(fechamodificacion) = 2023
and Asunto = 'Errores Proceso'