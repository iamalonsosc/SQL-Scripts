--------
declare  
@IdIdentity INT=(select max(grupo) from CargaConvalidacionMigra where convert(varchar,FechaCreacion,112)=convert(varchar,getdate(),112) and FlagCarga=0)
BEGIN
	  
	DECLARE @Dnialumno VARCHAR(200),
			@CodigoCurriculaOrigen VARCHAR(200),
			@CodigoCursoOrigen VARCHAR(200),
			@CodigoCurriculaDestino VARCHAR(200),
			@CodigoCursoDestino VARCHAR(200),
			@PromocionCodigoDestino VARCHAR(200),
			@Promedio VARCHAR(200),
			@PromedioReal DECIMAL(5,2),
			@Grupo INT,
			@Min INT,
			@Max INT,
			@IdCarga INT,
			@IdActor INT,
			@IdRegistro INT,
			@IdCurriculaOrigen INT,
			@IdCurriculaDestino INT,
			@IdCursoOrigen INT,
			@IdCursoDestino INT,
			@IdModulo INT,
			@PromedioCondicion VarChar(20),
			@ExisteConvalidacion INT,
			@Validar INT,
			@IdEmpresa INT = 1,
			@IdSede INT,
			@IdPeriodo INT,
			@IdProducto INT,
			@IdTipo INT,
			@IdUsuario INT,
			@Resultado VARCHAR(200),
			@Observacion VARCHAR(200),
			@TablaInfo VARCHAR(200),
			@IdPromocion INT,
			@ExisteMatricula INT,
			@ExistePromocion INT,
			@IdMatricula INT, --@4
			@CodigoCurriculaAnterior VARCHAR(20),
			@CodigoCurriculaNueva VARCHAR(20),
			@Tipoc CHAR(2),
			@Observacionc VARCHAR(200),
			@CompaniaSocio VARCHAR(8),
			@TKT VARCHAR(20)

			SET @CompaniaSocio = (Select CompaniaSocio FROM Empresa WHERE Activo = 1)
	
	DECLARE @CargaConvalidacion AS TABLE
	(
		Id INT IDENTITY,
		IdCarga INT,
		DniAlumno VARCHAR(200),
		CodigoCurriculaOrigen VARCHAR(200),
		CodigoCursoOrigen VARCHAR(200),
		CodigoCurriculaDestino VARCHAR(200),
		CodigoCursoDestino VARCHAR(200),
		Semestre VARCHAR(200),
		Promedio VARCHAR(200),
		UsuarioCreacion INT,
		PromocionCodigoDestino VARCHAR(50),
		Observacion VARCHAR(200)
	)
	INSERT INTO @CargaConvalidacion
	SELECT IdCarga,DniAlumno,CodigoCurriculaAnterior,CodigoCursoAnterior,CodigoCurriculaNueva,CodigoCursoNuevo,Semestre,Promedio,UsuarioCreacion,PromocionCodigo,Observacion
	FROM CargaConvalidacionMigra WITH (NOLOCK)
	WHERE Grupo = @IdIdentity AND FlagCarga=0

	SELECT @Min = MIN(Id), @Max = MAX(ID) FROM @CargaConvalidacion

	WHILE @Min <= @Max
	BEGIN
		SET	@IdCarga = NULL 
		SET @Dnialumno= NULL
		SET @CodigoCurriculaOrigen = NULL
		SET @CodigoCursoOrigen = NULL
		SET @CodigoCurriculaDestino = NULL
		SET @CodigoCursoDestino = NULL
		SET @Promedio = NULL
		SET @IdUsuario = NULL
		SET @PromocionCodigoDestino = NULL
		SET @TKT=NULL
		SET @Observacion= NULL
		SET @Resultado = NULL

		SELECT	@IdCarga = IdCarga, 
				@Dnialumno= DniAlumno,
				@CodigoCurriculaOrigen = CodigoCurriculaOrigen,
				@CodigoCursoOrigen = CodigoCursoOrigen,
				@CodigoCurriculaDestino = CodigoCurriculaDestino,
				@CodigoCursoDestino = CodigoCursoDestino,
				@Promedio = Promedio,
				@IdUsuario = UsuarioCreacion,
				@PromocionCodigoDestino = PromocionCodigoDestino,
				@TKT=Observacion
		FROM @CargaConvalidacion
		WHERE Id = @Min

		SET @Validar = 0
	
		SET @IdCurriculaDestino = (Select IdCurricula FROM Curricula WITH (NOLOCK) where Codigo = @CodigoCurriculaDestino)

		SET @IdActor = (Select IdActor FROM Actor WITH (NOLOCK) Where NumeroIdentidad = @Dnialumno)

		SET @IdCurriculaOrigen = (Select IdCurricula FROM Curricula WITH (NOLOCK) where Codigo = @CodigoCurriculaOrigen)

		SET @IdCursoOrigen = (SELECT IdCurso FROM Curso WITH (NOLOCK) where CursoCodigo = @CodigoCursoOrigen)

		SET @IdCursoDestino = (SELECT IdCurso FROM Curso WITH (NOLOCK) where CursoCodigo = @CodigoCursoDestino)

		SELECT @IdActor,@IdCurriculaDestino,@PromocionCodigoDestino
		IF NOT EXISTS(Select distinct 1 from Matricula M WITH (NOLOCK) INNER JOIN Promocion P WITH (NOLOCK) ON P.IdPromocion = M.IdPromocion  --Inicio @3
		WHERE M.IdActor = @IdActor AND M.IdCurricula = @IdCurriculaDestino AND P.PromocionCodigo = @PromocionCodigoDestino AND M.Estado = 'N' ) --@5
		BEGIN
			Select @IdSede = IdSede, @IdPeriodo = IdPeriodoTraslado from TrasladoSede WITH (NOLOCK)	Where idalumno=@IdActor and IdCurriculaNueva =@IdCurriculaDestino and Estado=1
		END
		ELSE 
		BEGIN
		IF @IdSede is NULL
			BEGIN
				select @IdSede= IdSede,@IdPeriodo=IdPeriodoAnual from Convalidacion where idalumno=@IdActor AND tipo='AM' and Estado='R'
			END
		END
		--select @IdSede,left (@PromocionCodigoDestino,2)
		--RETURN
		SELECT @IdRegistro = (Select Distinct IdRegistro from AlumnoCurriculaCurso WITH (NOLOCK) WHERE IdAlumno = @IdActor and IdCurricula = @IdCurriculaDestino) --@1

		DECLARE @PromedioFinal Decimal(5, 2) = ROUND(convert(decimal(5,2),@Promedio),0)
		SET @PromedioReal = CONVERT(decimal(5,2),@Promedio)

		IF @PromedioReal >= 0 AND @PromedioReal <= 12.4
		BEGIN
			SET @PromedioCondicion = 'D'
		END
		ELSE IF @PromedioReal >=12.5  AND @PromedioReal <= 20
		BEGIN
			SET @PromedioCondicion = 'A'
		END

		IF @PromedioCondicion NOT IN('A','D') SET @PromedioCondicion = NULL
		
		IF @IdCurriculaDestino IS NULL OR @IdCurriculaDestino = ''
		BEGIN
			
			SET @Resultado = 'KO'  
			SET @Observacion = 'No existe Curricula Nueva ' + @CodigoCurriculaDestino
			SET @TablaInfo = 'CurriculaNueva'      
			UPDATE CargaConvalidacionMigra SET FlagCarga = 1, Resultado = @Resultado, Observacion = @Observacion, TablaInfo = @TablaInfo  
			WHERE IdCarga = @IdCarga
			SET @Validar = 1  
		END

		IF @IdCursoDestino IS NULL OR @IdCursoDestino = ''   
		BEGIN
			
			SET @Resultado = 'KO'  
			SET @Observacion = 'No existe Curso Nuevo ' + @CodigoCursoDestino
			SET @TablaInfo = 'CursoNuevo'      
			UPDATE CargaConvalidacionMigra SET FlagCarga = 1, Resultado = @Resultado, Observacion = @Observacion, TablaInfo = @TablaInfo  
			WHERE IdCarga = @IdCarga
			SET @Validar = 1  
		END

		IF @IdActor IS NULL OR @IdActor = ''
		BEGIN
			
			SET @Resultado = 'KO'  
			SET @Observacion = 'No existe Persona registrada con numerodocumento '  + @Dnialumno 
			SET @TablaInfo = 'Actor'      
			UPDATE CargaConvalidacionMigra SET FlagCarga = 1, Resultado = @Resultado, Observacion = @Observacion, TablaInfo = @TablaInfo  
			WHERE IdCarga = @IdCarga
			SET @Validar = 1  
		END

		IF @Promedio = '' OR @Promedio >'20.00' OR @Promedio <'0'
		BEGIN
			
			SET @Resultado = 'KO'  
			SET @Observacion = 'Promedio ingresado incorrecto'
			SET @TablaInfo = 'Promedio'      
			UPDATE CargaConvalidacionMigra SET FlagCarga = 1, Resultado = @Resultado, Observacion = @Observacion, TablaInfo = @TablaInfo  
			WHERE IdCarga = @IdCarga
			SET @Validar = 1  
		END
		--Inicio @2
		IF @PromedioCondicion IS NULL OR @PromedioCondicion = 'D'
		BEGIN
			SET @Resultado = 'KO'  
			SET @Observacion = 'No se puede convalidar curso con nota desaprobatoria'
			SET @TablaInfo = 'Promedio'      
			UPDATE CargaConvalidacionMigra SET FlagCarga = 1, Resultado = @Resultado, Observacion = @Observacion, TablaInfo = @TablaInfo  
			WHERE IdCarga = @IdCarga
			SET @Validar = 1  
		END

		SET @CodigoCurriculaNueva = (Select Codigo FROM Curricula WITH(NOLOCK) WHERE IdCurricula = @IdCurriculaDestino)
		--SELECT @CodigoCurriculaNueva,'@CodigoCurriculaNueva'
		--RETURN
		SET @Tipoc = 'CI'
		SET @Observacionc = 'Regularizacion-Migracion'
		SET @ExisteConvalidacion =dbo.cConvalidacion_Val_ExisteCI(@IdEmpresa,  
																  @IdSede,  
																  @IdActor,  
																  @IdRegistro,  
																  @IdCurriculaDestino,
																  @IdPeriodo)   --@1
		IF --PATINDEX('%[ABCDEFGHIJKLMNOPQRSTUVWXYZ]%', @CodigoCurriculaAnterior) = 1 AND 
		PATINDEX('%[ABCDEFGHIJKLMNOPQRSTUVWXYZ]%', @CodigoCurriculaNueva) = 0 AND @CompaniaSocio = '00002700'
		BEGIN
			SET @Tipoc = 'AM'
			SET @Observacionc = 'Actualizaci�n de Malla'

			SELECT @IdEmpresa,  
																  @IdSede,  
																  @IdActor,  
																  @IdRegistro,  
																  @IdCurriculaDestino,
																  @IdPeriodo

			SET @ExisteConvalidacion = dbo.cConvalidacion_Val_ExisteAM(@IdEmpresa,  
																  @IdSede,  
																  @IdActor,  
																  @IdRegistro,  
																  @IdCurriculaDestino,
																  @IdPeriodo) 
		END
		--RETURN
		IF @ExisteConvalidacion=0
		BEGIN
			PRINT CONCAT(@IDACTOR,'-',@IDREGISTRO)
			SET @ExisteConvalidacion=ISNULL((SELECT DISTINCT IDCONVALIDACION FROM AlumnoCurriculaCurso WHERE IdAlumno=@IdActor AND IdRegistro=@IdRegistro AND TipoCondicion='CO'),0)
			--IF @ExisteConvalidacion>1
			--BEGIN
			--	SELECT * FROM AlumnoCurriculaCurso WHERE IdAlumno=@IdActor AND IdRegistro=@IdRegistro
			--	RETURN
			--END
		END
		--Fin @6
		IF @ExisteConvalidacion = 0 AND @Validar = 0
		BEGIN  
		print 'conva'
			IF @IdCurriculaOrigen IS NULL OR @IdCurriculaOrigen = ''
			BEGIN
			
				SET @Resultado = 'KO'  
				SET @Observacion = 'No existe Convalidacion ni Curricula Anterior ' + @CodigoCurriculaOrigen  
				SET @TablaInfo = 'CurriculaAnterior'      
				UPDATE CargaConvalidacionMigra SET FlagCarga = 1, Resultado = @Resultado, Observacion = @Observacion, TablaInfo = @TablaInfo  
				WHERE IdCarga = @IdCarga
				SET @Validar = 1  
			END
			ELSE
			BEGIN 
			print 'convalidacion'
				DECLARE @NumeroConv VARCHAR(10),@anno INT,@Ret INT,@fecha VARCHAR(10)  
				SET @anno = YEAR(getdate())  
				SET @fecha = dbo.gFechaStr(GETDATE())    
							  
				EXEC cConvalidacion_Gen_Codigo @anno,@NumeroConv OUTPUT  
			
				EXEC cConvalidacion_Ins_Grabar  
				@IdEmpresa = @IdEmpresa,  
				@IdSede = @IdSede,  
				@IdAlumno =@IdActor,  
				@IdRegistro = @IdRegistro,  
				@IdCurricula = @IdCurriculaDestino,  
				@AnteriorIdCurricula = @IdCurriculaOrigen,  
				@Numero = @NumeroConv,  
				@IdPeriodoAnual = @IdPeriodo,  
				@IdUsuario   =@IdUsuario,  
				@DocumentoNumero = NULL,  
				@DocumentoFecha = @fecha,  
				@Observacion = @Observacionc,  
				@Tipo  = @Tipoc,  
				@Estado = 'R',  
				@UsuarioCreacion = 1,  
				@InstitutoProcedencia ='',  
				@InstProcedenciaNombreCarrera = '',  
				@UltimoPeriodo  = '',  
				@RetVal = @Ret OUTPUT  
			
				IF @Ret IS NULL OR @Ret = 0 OR @Ret = ''
				BEGIN
					SET @Ret = (Select IdConvalidacion from Convalidacion WITH (NOLOCK) where IdAlumno = @IdActor AND AnteriorIdCurricula = @IdCurriculaOrigen and
																							  IdCurricula = @IdCurriculaDestino and IdRegistro = @IdRegistro)--@1
				END  
			END
		END 
		ELSE
		BEGIN
			SET @Ret = @ExisteConvalidacion--@1
		END
		--DECLARE @IdAlumno INT
		--SELECT DISTINCT @IdAlumno=IdAlumnoCurso  FROM AlumnoCurriculaCurso 
		--WHERE IdAlumno=@IdActor AND IdRegistro=@IdRegistro AND TipoCondicion='RE' AND PromedioCondicion='A'
		IF @Validar = 0-- AND @IdAlumno IS NULL
		BEGIN
			UPDATE AlumnoCurriculaCurso SET
				PromedioCondicion = @PromedioCondicion,
				PromedioFinal = @PromedioFinal,
				PromedioReal = @PromedioReal,
				IdConvalidacion = @Ret,
				TipoCondicion = 'CO',
				UsuarioModificacion=1,
				FechaModificacion=GETDATE(),
				Subsanacion=0,
				Observacion=CONCAT('Actualizado segun ',@TKT, '- DE ACUERDO A LAS ACTAS ENVIADAS POR SG')
			WHERE IdAlumno = @IdActor AND IdRegistro = @IdRegistro and IdCurricula = @IdCurriculaDestino and IdCurso = @IdCursoDestino
			
			SET @Observacion = ISNULL(@Observacion,'')

			UPDATE CargaConvalidacionMigra SET
			FlagCarga = 1,
			Resultado = isnull(@Resultado,'OK'),
			Observacion = Observacion + @Observacion --@4
			WHERE IdCarga = @IdCarga
		END
		--ELSE
		--BEGIN
		--SET @Resultado = 'KO'  
		--SET @Observacion = 'Alumno ya se encuentra como aprobado'
		--UPDATE CargaConvalidacionMigra SET
		--	FlagCarga = 1,
		--	Resultado = @Resultado,
		--	Observacion =  @Observacion
		--	WHERE IdCarga = @IdCarga
		--END
	
		SET @Min = @Min + 1
	END	
END
--exec cCargasMigraKO_Sel_Listar @MaxGrupo = @IdCarga, @Opcion = 18, @Fecha  = ''
