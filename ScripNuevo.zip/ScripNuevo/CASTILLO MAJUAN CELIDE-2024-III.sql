--DECLARE @IdMatriculaAntigua INT=648024,@IdAlumno INT=1258368,@IdMatriculaNueva INT

UPDATE Matricula SET Estado='X'
WHERE IdMatricula IN (647325--2024-III
,699051
,751058)
--UPDATE Registro SET IdSede=40
--WHERE IdActor=1254944 AND IdRegistro=1


SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1258368 
--AND AC.IdMatricula=788379
AND AC.IdCurso=9807
order by ac.idregistro,ac.IdAlumnoCurso desc


--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=47
WHERE IdMatricula=788379 AND IdCurso=9807
--(1 fila afectada)



--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=5,IdAlumnoCurso=2,IdcurriculaOriginal=5607
WHERE IdMatricula=647325 AND IdCurso=9807
--(1 fila afectada)




--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='14.00',PromedioReal='14.08',IdAlumnoCurso=2,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1258368 AND IdRegistro=5 AND IdCurso=9807 AND IdCurricula=5607


--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=5,IdCurricula=5607
WHERE IdMatricula=647325

UPDATE Matricula SET Estado='N'
WHERE IdMatricula IN (699051
,751058)


-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO
UPDATE Matricula SET Estado='X'
WHERE IdMatricula=788379