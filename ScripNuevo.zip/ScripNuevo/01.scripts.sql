 

 

-- CABRERA CAMPOS LUIS FERNANDO
UPDATE Matricula SET TipoCondicion='RE'
where IdMatricula=750002  
-- 
-- AGUILAR GIRON FIORELLA ANGELICA

UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=722682 AND EsMatricula=1 

-- 
-- AMBROSIO COAQUIRA ANDY CRISTOPHER

UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=745401 AND EsMatricula=1 

-- ZACONETTA CARHUAVILCA ANGELA DEL ROSARIO


UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=743398  


-- VEGA MENDOZA PIERO JAIR

UPDATE Matricula SET TipoCondicion='RE'
where IdMatricula=748864  


-- MAMANI TTITO FIORELA LISBETH

UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=748051  

--CONDOY LIMPE RICHARD

UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=738811 AND EsMatricula=1 
--
-- SAAVEDRA BUIZA EDWIN JOSUÉ 9917

UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=743406  


--
-- BAUTISTA ROJAS KAROL STACY

UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=749771 AND EsMatricula=1 

--ARRIETA TINEO YBIS YULLIANA
UPDATE Matricula SET TipoCondicion='RE'
where IdMatricula=743393  


-- MAYTA SALAS AVIGAIL SATIA 'RE' -> 'RP'

UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=743068  



-- ALFARO HUACHO CHRISTIAN DENYS

UPDATE Matricula SET TipoCondicion='RE'
where IdMatricula=750790  


-- PALACIOS ENCALADA GABRIELA SALOME
 
UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=737369 AND EsMatricula=1 


-- PACHERRES GONZALES ALLISON PAULINA

UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=739004 AND EsMatricula=1 


-- CAFFO VALLE DIEGO ANDRES

UPDATE Matricula SET TipoCondicion='RE'
where IdMatricula=745455  


-- GIL SURICHAQUI MILAGRITOS GERALDINE



UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=745459 AND EsMatricula=1 


-- HINOSTROZA VIZCARDO VALERIA

UPDATE Matricula SET TipoCondicion='RE'
where IdMatricula=735601  



-- NAVARRO HIDALGO ALISSA MADELEINE
 
UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=738860 AND EsMatricula=1 


--GARCES BAMBAREN ANGELLO SEBASTIAN

UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=743064  


-- AÑANGA BENITES JHON FRANCO

UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=744518 AND EsMatricula=1 


-- CANTO PACORI RICARDO ENRIQUE
 
UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=743551 AND EsMatricula=1 


-- ANTICONA ATAYUPANQUI SAMUEL YHOSUE
 
UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=743324 AND EsMatricula=1 




-- PAUCAR ESPINOZA ALDAIR GEOVANNY  SEBASTIAN
 
UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=742776  

-- CARHUANCHO ROJAS ANGIE FLOR

 
UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=743404  

-- GUTIERREZ ROJAS CAMILA
 
UPDATE Matricula SET TipoCondicion='RE'
where IdMatricula=749380  



-- PABLO VALENCIA ALEXIS HALDAIR
  

UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=734777 AND EsMatricula=1 


-- FERRER CASTRO NERIO RICARDO
 

UPDATE AlumnoCurso SET TipoCondicion='RE'
where IdMatricula=731562 AND EsMatricula=1 
