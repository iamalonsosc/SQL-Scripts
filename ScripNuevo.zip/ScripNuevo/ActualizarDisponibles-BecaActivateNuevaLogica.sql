SELECT*FROM MaestroTablaRegistro WHERE IdMaestroTabla=1905 AND Codigo IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019','TIP0000037','TIP0000043','TIP0000049','TIP0000050','TIP0000059','TIP0000060')

UPDATE MaestroTablaRegistro SET Disponible10='ACTIVATE'
WHERE IdMaestroTabla=1905 AND Codigo IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019','TIP0000037','TIP0000043','TIP0000049','TIP0000050','TIP0000059','TIP0000060')

/*==============================================================
CONFIGURACION DEFINITIVA SEGUN MAPA REAL
(Respetando Disponible1 = Promedio)

MAPA FINAL

Disponible1 = PromedioBeca
Disponible2 = ValidaRetiroCiclo
Disponible3 = ValidaCambioModalidad
Disponible4 = ValidaCambioSede
Disponible5 = IdModuloBecaValidar
Disponible6 = ValidaTipoCondicion
Disponible7 = ValidaPagoPuntual
Disponible8 = ValidaSecuencialidad

==============================================================*/


/*==============================================================
TIP0000037
50% hasta maximo 2 ciclos
Promedio 13
==============================================================*/
UPDATE MaestroTablaRegistro
SET --Disponible1 = 13,   -- promedio m�nimo
    Disponible2 = 1,    -- retiro
    Disponible3 = 1,    -- cambio modalidad
    Disponible4 = 1,    -- cambio sede
    --Disponible5 = 1,    -- evaluar desde cuota 2
    Disponible6 = 1,    -- tipo condicion
    Disponible7 = 1,    -- pago puntual
    Disponible8 = 1,    -- secuencialidad
    Disponible9 = null
WHERE Codigo = 'TIP0000037'


/*==============================================================
TIP0000017
50% toda la carrera
Promedio 18
==============================================================*/
UPDATE MaestroTablaRegistro
SET 
    Disponible1 = 18.00,
    Disponible2 = 1,-- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1, -- cambio sede
    --Disponible5 = 2,
    Disponible6 = 1,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0,-- secuencialidad
    Disponible9 = null
WHERE Codigo = 'TIP0000017'


/*==============================================================
TIP0000050
25% toda la carrera
Promedio 13
==============================================================*/
UPDATE MaestroTablaRegistro
SET 
--Disponible1 = 13,
    Disponible2 = 1,-- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1, -- cambio sede
    --Disponible5 = 2,
    Disponible6 = 1,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0,-- secuencialidad
    Disponible9 = null
WHERE Codigo = 'TIP0000050'


/*==============================================================
TIP0000049
50% toda la carrera
NO promedio
NO tipo condicion
==============================================================*/
UPDATE MaestroTablaRegistro
SET 
    --Disponible1 = 0,    -- no valida promedio
    Disponible2 = 1,-- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    --Disponible5 = 2,
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0,-- secuencialidad
    Disponible9 = null
WHERE Codigo = 'TIP0000049'


/*==============================================================
TIP0000059
50% maximo 2 ciclos
NO promedio
Secuencialidad SI
==============================================================*/
UPDATE MaestroTablaRegistro
SET Disponible1 = 0, -- no valida promedio
    Disponible2 = 1, --  retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 1-- secuencialidad
WHERE Codigo = 'TIP0000059'


/*==============================================================
TIP0000060
Presencial 25% toda la carrera
Promedio 15
==============================================================*/
UPDATE MaestroTablaRegistro
SET Disponible1 = 15.00, -- promedio
    Disponible2 = 1,  -- retiro
    Disponible3 = 1,-- cambio modalidad
    Disponible4 = 1,-- cambio sede
    Disponible5 = 1,
    Disponible6 = 0,-- tipo condicion
    Disponible7 = 1,-- pago puntual
    Disponible8 = 0 -- secuencialidad
WHERE Codigo = 'TIP0000060'