WITH CursosDesaprobados2024III AS (
    SELECT 
        MAT.IdActor AS IdAlumno,
        MAT.IdCurricula,
        PRO.PromocionCodigo AS Promocion2024III
        --COUNT(CASE WHEN ACC.PromedioCondicion = 'D' THEN 1 END) AS CantCursosDesaModulo
    FROM 
        Matricula MAT WITH(nolock)
    INNER JOIN Promocion PRO WITH(nolock) ON PRO.IdPromocion = MAT.IdPromocion
    INNER JOIN Periodo PER WITH(nolock) ON PER.IdPeriodo = PRO.IdPeriodo
    INNER JOIN alumnocurriculacurso ACC WITH(nolock) 
        ON MAT.IdActor = ACC.IdAlumno 
        AND MAT.IdCurricula = ACC.IdCurricula 
        AND MAT.IdRegistro = ACC.IdRegistro
    WHERE 
        PER.Codigo like '%2024-IIIA%'
        AND MAT.Estado <> 'X'
		
        --AND PRO.IdUnidadAcademica = 57
    GROUP BY 
        MAT.IdActor, MAT.IdCurricula, PRO.PromocionCodigo
)
SELECT  
	MA.IdMatricula,
    ACC.IdAlumno,
    AC.NombreCompleto,
    CD2024.Promocion2024III AS PromocionAnterior,
    PRO.PromocionCodigo AS PromocionActual,
   -- CD2024.CantCursosDesaModulo AS CantCursosDesaPrevios,
	MA.FechaCreacion AS FechaDeLaMatricula2025
   -- COUNT(CASE WHEN ACC.PromedioCondicion = 'D' THEN 1 END) AS CantCursosDesaModuloActual
FROM   
    alumnocurriculacurso ACC WITH(nolock) 
    INNER JOIN Matricula MA WITH(nolock) ON MA.IdActor=ACC.IdAlumno AND MA.IdRegistro=ACC.IdRegistro AND MA.IdCurricula=ACC.IdCurricula
    INNER JOIN Promocion PRO WITH(nolock) ON PRO.IdPromocion=MA.IdPromocion
    INNER JOIN Periodo PE WITH(nolock) ON PE.IdPeriodo=PRO.IdPeriodo
    INNER JOIN Actor AC WITH(nolock) ON AC.IdActor = ACC.IdAlumno
    LEFT JOIN CursosDesaprobados2024III CD2024 
        ON CD2024.IdAlumno = ACC.IdAlumno 
        AND CD2024.IdCurricula = ACC.IdCurricula
WHERE  
    PE.Codigo = '2025-I'
    AND PRO.IdUnidadAcademica = 60
    AND MA.Estado <> 'X'
	AND MA.EsMatricula=1
	AND CD2024.Promocion2024III IS NOT NULL
	--AND CONVERT(varchar,MA.FechaCreacion,112)='20241228'
GROUP BY 
	MA.IdMatricula,
    ACC.IdAlumno,
    AC.NombreCompleto,
    CD2024.Promocion2024III,
    PRO.PromocionCodigo,
    --CD2024.CantCursosDesaModulo,
	MA.FechaCreacion
ORDER BY 
    AC.NombreCompleto;

	--2024-12-28 11:30:53.183
	--SELECT FechaCreacion,IdMatricula,IdActor, *FROM Matricula WHERE IdMatricula=672587