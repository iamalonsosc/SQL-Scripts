--SELECT*FROM WFTramiteSede WHERE idtramite = 20--(11 rows affected)

UPDATE WFTramiteSede SET Correos='',IdUsuarios=''
WHERE idtramite = 20
--(11 rows affected)