----------------------------------------------------------------------------      
--Creado por      :Alonso Sanchez (05/05/2024)            
--Funcionalidad   :
--Utilizado por   :
--------------------------------------------------------------         
/*      
-----------------------------------------------------------------------------      
Nro		FECHA			USUARIO					DESCRIPCION      
-----------------------------------------------------------------------------      
*/   
CREATE PROCEDURE cAsignacion_BecaPeruVirtual
@IdMatricula INT ,
@CodigoBase VARCHAR(100),
@Retorno BIT OUTPUT,
@pDescripcion varchar(500) OUTPUT
AS  
BEGIN 
--@IdMatricula2 INT = 460487
/*
GLOSARIO:
	RE -> Promovido
	RP -> Promovido + Curso
	RT -> Repitencia
	CC -> Curso�Repitencia
*/
	DECLARE @IdActor INT,
	@IdSedeActual INT,
	@IdSedeAnterior INT,
	@CodigoPeriodo VARCHAR(10),
	@IdUnidadAcademica INT,
	@IdUnidadNegocio INT,
	@TipoTurnoActual VARCHAR(15),
	@TipoCondicionActual VARCHAR(10),
	@CambioCarreraBeca INT,
	@CompaniaSocio VARCHAR(10),
	@PromedioBeca REAl,
	@PeriodosAnterioresConcatenados VARCHAR(MAX),
	@IdModuloBecaValidar INT,
	@IdProductoActual INT,
	@IdProductoAnterior INT,
	@IdMatriculaAnterior INT,
	@IdModuloPagoAnterior INT,
	@IdModuloActual INT,
	@IdTipoConsulta INT,
	@PeriodoCodigoBase VARCHAR(20),
	@TurnoAnterior varchar(50),
	@ProductoAnterior varchar(100),
	@ProductoActual varchar(100),
	@SedeActual VARCHAR(50),
	@SedeNombreAnterior VARCHAR(50),
	@PeriodoCodigoMatriculaAnterior VARCHAR(50),
	@PromedioReal real,
	@IdDescuentoAcademicoBase INT,
	@CodigoDescuento VARCHAR(50);
	-- DECLARAMOS TODAS LAS VARIABLES DE VALIDACI�N
	DECLARE 
	@ValidaTipoTurno BIT = 1,
	@ValidaTipoCondicion BIT = 1 ,
	@ValidaRetiro BIT= 1  ,
	@ValidaCambioSede BIT= 1 ,
	@ValidaPagoPuntualBeca BIT= 1 , 
	@ValidaReingreso BIT= 1 ,
	@Validacion2024 BIT=0,
	@ValidaCambioDeModalidad BIT=0;
	--DECLARAMOS TODAS LAS VARIABLES DE EXLUCI�N
	DECLARE 
	@ExcluidoPorPromedio BIT = 0 ,
	@ExcluidoPorTurno BIT = 0 ,
	@ExcluidoPorCondicion BIT = 0 ,
	@ExcluidoPorRetiro BIT = 0 , 
	@ExcluidoPorCambioSede BIT = 0 , 
	@ExcluidoPorCambioCarrera BIT = 0 ,
	@ExcluidoPorPagoPuntual INT = 0 ,
	@ExcluidoPorPeriodoAnterior BIT = 0,
	@ExcluidoPorReingresante BIT = 0 ,
	@ExcluidoPorNoTenerMatricula BIT = 0 ,
	@ExcluidoPorBeca BIT = 0,
	@ExcluidoPorNoTenerMatriculaAProcesar BIT = 0,
	@ExcluidoPorCambioDeModalidad BIT = 0 ;
	--DECLARAMOS LA TABLA DE LOS PERIODOS ANTERIORES
	DECLARE @PeriodosAnteriores table    
	(CodigoPeriodoPadre varchar(20),    
	CodigoPeriodoAnterior varchar(20),     
	IdPeriodoPadre int,    
	IdPeriodoAnterior int) 
	--DECLARAMOS LA TABLA EN DONDE GUARDAREMOS LA MATRICULA ANTERIOR
	DECLARE @MatriculaAnterior TABLE (
	IdActor INT,
	IdMatricula INT,
	PromocionCodigo VARCHAR(50),
	PromocionNombre VARCHAR(100),
	IdSede INT,
	SedeNombreAnterior varchar(50),
	IdPeriodo INT,
	Codigo VARCHAR(50),
	IdProducto INT,
	ProductoNombre VARCHAR(100),
	GrupoCodigo VARCHAR(50),
	IdGrupo INT,
	IdTurno INT,
	TurnoNombre VARCHAR(100),
	IdTipoTurno INT,
	TipoTurnoDispo5 VARCHAR(50),
	TipoCondicion VARCHAR(50),
	Estado VARCHAR(50),
	MatriculaTipo VARCHAR(50),
	PromedioReal REAL,
	IdModulo INT,
	PeriodoCodigoBase VARCHAR(20),
	NombreDescuento VARCHAR(100),
	CodigoDescuento VARCHAR(50),
	IdTipoConsulta INT,
	MantieneBeca BIT,
	IdDescuentoAcademicoBase INT);

	--Selecionamos la empresa a la que pertenece 
	SELECT @CompaniaSocio= CompaniaSocio FROM Empresa

	SET @IdMatriculaAnterior = NULL 
	SET @IdModuloPagoAnterior = NULL 
	--TIP0000031
END 


	-- obtenener los datos de su ultima matricula del alumno
	--Obtenemos el periodo  actual del alumno
	SELECT @CodigoPeriodo=PE.Codigo,
	@IdUnidadAcademica=PE.IdUnidadAcademica,
	@IdUnidadNegocio=PE.IdUnidadNegocio,
	@IdActor=MA.IdActor
	FROM Matricula MA WITH (NOLOCK)
	INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
	INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
	INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON P.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo -- PARA VALIDAR QUE LA MATRICULA SE ENCUENTRE COMPLETA
	WHERE MA.IdMatricula = @IdMatricula AND P.IdUnidadNegocio = 1   AND  MA.Estado <> 'X'

	IF  @CodigoPeriodo is null
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'ERROR - NO OBTIENE MATRICULA O PRE , EN EL PERIODO A PROCESAR ' 
		RETURN
	END

	--obtenemos los periodos anteriores
	INSERT INTO @PeriodosAnteriores (CodigoPeriodoPadre,CodigoPeriodoAnterior, IdPeriodoPadre,IdPeriodoAnterior) 
	SELECT  DISTINCT PE.Codigo AS 'PADRE',PE2.Codigo AS 'ANTERIOR',PE.IdPeriodo,PE2.IdPeriodo 
	FROM PeriodoEquivalencia PEE WITH (NOLOCK)
	INNER JOIN Periodo PE WITH (NOLOCK) ON PEE.IdPeriodoPadre = PE.IdPeriodo
	INNER JOIN Periodo PE2 WITH (NOLOCK) ON PEE.IdPeriodoEquivalencia = PE2.IdPeriodo
	WHERE PE.Codigo=@CodigoPeriodo  
	AND PEE.EsSiguiente=0
	AND PE.IdUnidadAcademica=@IdUnidadAcademica 
	AND PE.IdUnidadNegocio=@IdUnidadNegocio

	-- VALIDAMOS QUE EXISTA PERIODO ANTERIOR --  EN EQUIVALENCIA  - FALTA
	IF NOT EXISTS(SELECT 1 FROM @PeriodosAnteriores)
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'ERROR - NO SE OBTIENE INFOMRACI�N SOBRE EL PERIODO ANTERIOR DEL ALUMNO (VALIDAR CONFIGURACI�N DE PERIODO)' 
		RETURN
	END

	--OBTENEMOS DATOS DE LA MATRICULA ANTERIOR DEL ALUMNO
	INSERT INTO  @MatriculaAnterior     
	(IdActor,IdMatricula,PromedioReal) 
	SELECT DISTINCT MA.IdActor, MA.IdMatricula, PGC.PromedioReal
	FROM Matricula MA WITH (NOLOCK)
	INNER JOIN Promocion P WITH (NOLOCK) ON MA.IdPromocion = P.IdPromocion
	INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
	INNER JOIN PeriodoCabecera PC WITH(NOLOCK) ON PE.IdPeriodoCabecera=PC.IdPeriodoCabecera
	LEFT JOIN PromocionGrupoCierre PGC WITH(NOLOCK) ON MA.IdMatricula = PGC.IdMatricula 
	WHERE MA.IdActor=@IdActor  
	AND P.IdUnidadNegocio =@IdUnidadNegocio 
	AND P.IdUnidadAcademica=@IdUnidadAcademica
	AND MA.Estado <> 'X'
	AND PE.IdPeriodo IN (SELECT IdPeriodoAnterior FROM @PeriodosAnteriores)

	UPDATE MA SET 
	MA.IdDescuentoAcademicoBase=DAB.IdDescuentoAcademicoBase
	FROM @MatriculaAnterior AS MA
	INNER JOIN DescuentoAcademicoBase AS DAB WITH(NOLOCK) ON DAB.IdActor = MA.IdActor
	INNER JOIN MaestroTablaRegistro AS MTR2  WITH(NOLOCK) ON MTR2.IdMaestroRegistro = DAB.IdMaestroRegistro 
	WHERE MTR2.Codigo = @CodigoBase AND DAB.Activo=1
	
	--Validamos Pago puntual en su carrera
	-- Cuando es primer ciclo, se valida apartir de la segunda cuota
	SELECT TOP 1 @IdMatriculaAnterior = IdMatricula , 
	@IdModuloPagoAnterior = CASE WHEN IdModulo = 1 THEN 2 ELSE 1 END,
	@PromedioReal= ISNULL(PromedioReal,0),
	@IdDescuentoAcademicoBase = IdDescuentoAcademicoBase
	FROM @MatriculaAnterior 

	--  FALTA AGREGAR EN LA TABLA
	SELECT @PromedioBeca = Disponible1,
	@IdModuloBecaValidar=Disponible5
	FROM MaestroTablaRegistro WITH(NOLOCK) 
	WHERE  IdmaestroRegistro = @IdTipoConsulta
	
	SELECT @PeriodosAnterioresConcatenados = COALESCE(@PeriodosAnterioresConcatenados + ', ', '') + CAST(CodigoPeriodoAnterior AS VARCHAR(50))
	FROM (SELECT DISTINCT CodigoPeriodoAnterior FROM @PeriodosAnteriores) AS Temp

BEGIN
	

	-- Validamos que la matricula actual tenga una matricula anterior
	IF  NOT EXISTS(SELECT 1 FROM @MatriculaAnterior)
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'ERROR - NO TIENE MATRICULA ANTERIOR PARA EVALUAR : ' + @PeriodosAnterioresConcatenados
		RETURN
	END

	-- Validamos el descuento BECA PERU VIRTUAL PROVINCIAS NSE W 
	IF  @CodigoDescuento='TIP0000031'
	BEGIN
		SET @Retorno = 'OK'
		SET @pDescripcion= 'SI LE CORRESPONDE LA BECA' 
		RETURN
	END

	--Validamos el ciclo de la beca con el de su matricula
	--IF @IdModuloActual>@IdModuloBecaValidar
	IF   @PromedioReal<@PromedioBeca
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'EXCLUIDO POR PROMEDIO, EL PROMEDIO DEL ALUMNO ES : '+ convert(varchar,@PromedioReal) --EXLUCIDO POR PROMEDIO INCLUIR EL PROMEDIO ACTUAL QUE TIENE
		
		UPDATE DescuentoAcademicoBase SET Motivo=@pDescripcion,Activo=0,FechaModificacion=GETDATE() , UsuarioModificacion=1 
		WHERE IdDescuentoAcademicoBase  =  @IdDescuentoAcademicoBase 
		 
		SET @ExcluidoPorPromedio = 1

		RETURN
	END
	
	SET @ExcluidoPorPagoPuntual=ISNULL((SELECT dbo.cPagoPuntual (@IdActor,@CompaniaSocio,@IdMatriculaAnterior, @IdModuloPagoAnterior)),0)
	IF @ExcluidoPorPagoPuntual = 1 
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion= 'EXCLUIDO POR PAGO PUNTUAL EN EL PERIODO: ' + @PeriodoCodigoMatriculaAnterior

		UPDATE DescuentoAcademicoBase SET Motivo=@pDescripcion,Activo=0,FechaModificacion=GETDATE() , UsuarioModificacion=1 
		WHERE IdDescuentoAcademicoBase  =  @IdDescuentoAcademicoBase 

		RETURN
	END

	IF @ExcluidoPorPagoPuntual = 0 AND @ExcluidoPorPromedio = 0 
	BEGIN
		SET @Retorno = 1
		SET @pDescripcion = 'SI LE CORRESPONDE LA BECA'
		RETURN	
	END 
	ELSE
	BEGIN
		SET @Retorno = 0
		SET @pDescripcion = 'ERROR AL REALIZAR EVALUACION'
		RETURN
	END 

END