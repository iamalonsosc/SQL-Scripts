UPDATE PersonaMast SET Estado='A'
WHERE Persona=11838