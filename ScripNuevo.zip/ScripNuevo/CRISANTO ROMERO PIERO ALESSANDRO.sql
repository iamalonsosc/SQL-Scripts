--select*from Matricula 
UPDATE Matricula SET IdPromocion=100198
where IdMatricula=742254

--select*from AlumnoCurso where IdMatricula=742254 and EsMatricula=1


--select*from Promocion where IdPromocion=100198
----select*from CurriculaCurso
----where IdCurricula=5803 and IdCurso in (9800
----,9857
----,10402
----,10571
----,10572
----,10573
----,13437)
--select*From AlumnoCursoNomina where IdMatricula=742254