SELECT*FROM AlumnoCurso 
--UPDATE AlumnoCurso SET EsMatricula=1
WHERE IdMatricula=610370 AND IdCurso IN (9863
,9876
,10063,11358)