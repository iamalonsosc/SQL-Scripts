--EJEMPLO
--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula=655114 AND CuotaNumero=4

--ELIMINAMOS LA MATRICULA DE TODOS ESOS ALUMNOS
DELETE FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647859,647863,647950,647969,648081,648146)AND TIPOFACTURACION='MAT' )
DELETE FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647859,647863,647950,647969,648081,648146) AND TIPOFACTURACION='MAT'

--AHORA INSERTAMOS EN LA TABLA HEADER DE LOS ALUMNOS

INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20241216','INF','NOR','0002',1742942,NULL,'202410FC','LO','IDWI',NULL,'20240916','GE','N',NULL,0,647859,'B610',NULL,4,NULL,NULL,'2024-10',3901,54,NULL,'N','P','Q','20240916',1,NULL,NULL,'N',null,null,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20241216','INF','NOR','0001',1743032,NULL,'202410FC','LO','IDTV',NULL,'20240916','GE','N',NULL,0,647863,'B640',NULL,4,NULL,NULL,'2024-10',3873,54,NULL,'N','P','Q','20240916',1,NULL,NULL,'N',null,null,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20241216','INF','NOR','0001',1743072,NULL,'202410FC','LO','IDTV',NULL,'20240916','GE','N',NULL,0,647950,'B640',NULL,4,NULL,NULL,'2024-10',3873,54,NULL,'N','P','Q','20240916',3,NULL,NULL,'N',null,null,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20241216','INF','NOR','0002',1743100,NULL,'202410FC','LO','IDWI',NULL,'20240916','GE','N',NULL,0,647969,'B610',NULL,4,NULL,NULL,'2024-10',3901,54,NULL,'N','P','Q','20240916',3,NULL,NULL,'N',null,null,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20241216','INF','NOR','0002',1743185,NULL,'202410FC','LO','IDWI',NULL,'20240917','GE','N',NULL,0,648081,'B610',NULL,4,NULL,NULL,'2024-10',3901,54,NULL,'N','P','Q','20240917',3,NULL,NULL,'N',null,null,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')
INSERT INTO CO_Interfase_P09_Header VALUES ('BV','20241216','INF','NOR','0001',1425398,NULL,'202410FC','LO','IDTV',NULL,'20240917','GE','N',NULL,0,648146,'B640',NULL,4,NULL,NULL,'2024-10',3873,54,NULL,'N','P','Q','20240917',3,NULL,NULL,'N',null,null,NULL,'C','N',NULL,'00002700',NULL,'01','N','S')

DECLARE @NumeroInterno1 INT,@NumeroInterno2 INT,@NumeroInterno3 INT,@NumeroInterno4 INT,@NumeroInterno5 INT,@NumeroInterno6 INT

SELECT @NumeroInterno1 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647859) AND CuotaNumero=4
SELECT @NumeroInterno2 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647863) AND CuotaNumero=4
SELECT @NumeroInterno3 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647950) AND CuotaNumero=4
SELECT @NumeroInterno4 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647969) AND CuotaNumero=4
SELECT @NumeroInterno5 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (648081) AND CuotaNumero=4
SELECT @NumeroInterno6 = NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula IN (648146) AND CuotaNumero=4

INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno1,4,'S','Y54P148900','1.00','','GE','349.00','349.00',4,NULL,'00002700','DESIDAT',GETDATE(),'')
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno2,4,'S','Y54P148900','1.00','','GE','349.00','349.00',4,NULL,'00002700','DESIDAT',GETDATE(),'')
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno3,4,'S','Y54P148900','1.00','','GE','349.00','349.00',4,NULL,'00002700','DESIDAT',GETDATE(),'')
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno4,4,'S','Y54P148900','1.00','','GE','349.00','349.00',4,NULL,'00002700','DESIDAT',GETDATE(),'')
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno5,4,'S','Y54P148900','1.00','','GE','349.00','349.00',4,NULL,'00002700','DESIDAT',GETDATE(),'')
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',@NumeroInterno6,4,'S','Y54P148900','1.00','','GE','349.00','349.00',4,NULL,'00002700','DESIDAT',GETDATE(),'')

--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647859)
--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647863)
--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647950)
--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (647969)
--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (648081)
--SELECT*FROM CO_Interfase_P09_Header WHERE IdMatricula IN (648146)

--SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=647859 AND CompaniaSocio='00002700')
--SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=647863 AND CompaniaSocio='00002700')
--SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=647950 AND CompaniaSocio='00002700')
--SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=647969 AND CompaniaSocio='00002700')
--SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=648081 AND CompaniaSocio='00002700')
--SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=648146 AND CompaniaSocio='00002700')