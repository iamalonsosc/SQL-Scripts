--����������������������������������������������������������������������������                              
--Creado por      : MBUENO 15.12.2023                              
--Funcionalidad   : Envio Correos                 
--Utilizado por   : Proceso Matricula Manual           
--����������������������������������������������������������������������������                              
/*                          
-----------------------------------------------------------------------------                          
Nro  FECHA  USUARIO  DESCRIPCION                          
-----------------------------------------------------------------------------                          
@01  21.02.2024		MBUENO   Se corrige error esmatricula        
@02  20.05.2024		LPARIONA Se agrega logica para obtener la contrase�a robusta       
@03  06.12.2024		Fetorres Se habilita el envio de correos en CA.         
@04  07.01.2025		mquiroz  Se agrega logica para its     
@05  13.01.2025		Fetorres Se corrige el cuerpo del correo en CA,se agrega compania socio de ZEGEL cuando unidad academica sea 64 y se agrega isnull en las variables de envio de correo.    
@06  05.02.2025		FETORRES  Se cambia la logica de fechas para todas las marcas.  
@07  2025.02.26		jmota    en coordinacion con flescano (Z e IDAT), zorka (CA) y vanessa uresti(its) se vio correcto que el inicio de las clases extesion debe ser se la seccion (promociongrupo)       
@08  2025.02.28		ALSANCHEZ	Traer el ultimo correo registrado y que no este en blanco
*/            
ALTER PROCEDURE [dbo].[cAlumnoCurso_UpdProcesoMatriculaEnvioCorreo]        
--DECLARE        
 @CurIdAlumno INT,        
 @CurIdMatricula INT,        
 @CodigoAlumno VARCHAR(20)        
AS        
BEGIN        
  SET�NOCOUNT on;      
      
 DECLARE @CompaniaSocio char(8),                    
   @NombreEmpresa varchar(50),                    
   @WebPrincipal varchar(50),                    
   @WebZoom varchar(50),                    
   @WebSmart varchar(50),                  
   @CorreoPrincipal varchar(max),                      
   @UrlImagenes varchar(max),                    
   @Subject varchar(max),                   
   @pNombreCorreoUA varchar(50),        
   @Usuario Varchar(50),                  
   @clave Varchar(50),        
   @ListaCopiaCorreo VARCHAR(500),        
   @FechaInicio VARCHAR(10),        
   @CodigoSedeNuevo VARCHAR(20),        
   @CorreoSaeDip varchar(max),              
   @CorreoSaeCur varchar(max),        
   @profile_name_empresa VARCHAR(20),        
   @TipoCorreo varchar(100),        
   @IdSede int,        
   @IdEmpresa int,        
   @IdUnidadAcademica int,        
   @IdUnidadNegocio int,        
   @ValHorario int,        
   @IdPeriodo int,        
   @IdProducto int,        
   @CurNumeroDocumento varchar(20),        
   @passwdGenericas varchar(50)--@02        
        
 DECLARE @mjs varchar(MAX),            
   @uEmail varchar(200),                    
   @pieMensaje VARCHAR(5000),                    
   @uNombres varchar(200),                
   @EsMatricula INT,              
   @Dominio VARCHAR(200)  ,  
   @TipoServicio VARCHAR(5)  --@06      
        
 DECLARE @nombreSp varchar(50) = 'cAlumnoCurso_UpdProcesoMatriculaEnvioCorreo'         
        
 --Obtiene la data        
 SET @IdSede = 0        
 SET @IdEmpresa = 0        
 SET @IdPeriodo = 0        
 SET @IdProducto = 0        
 SET @IdUnidadAcademica = 0        
 SET @IdUnidadNegocio = 0        
 SET @CurNumeroDocumento = ''        
 SET @ValHorario = 0 --Matricula sin horarios, enviado desde el proceso automatico        
         
        
 SELECT @IdSede = PR.IdSede, @IdEmpresa = PR.IdEmpresa, @IdPeriodo = PR.IdPeriodo, @IdProducto = PR.IdProducto,         
   @IdUnidadAcademica = PR.IdUnidadAcademica, @IdUnidadNegocio = PR.IdUnidadNegocio, @CurNumeroDocumento = A.NumeroIdentidad,        
   @EsMatricula = MA.EsMatricula,@TipoServicio=UN.TipoServicio --@01    --@06        
 FROM Matricula MA with (nolock)        
 INNER JOIN Promocion PR with (nolock) ON MA.IdPromocion = PR.IdPromocion        
 INNER JOIN Actor A with (nolock) ON MA.IdActor = A.IdActor      
 INNER JOIN UnidadNegocio UN (NOLOCK)ON UN.IdUnidadNegocio=PR.IdUnidadNegocio  --@06        
 WHERE MA.IdActor = @CurIdAlumno        
 AND MA.IdMatricula = @CurIdMatricula        
 AND MA.Estado = 'N'        
 --AND MA.EsMatricula = 0 --@01        
 AND ISNULL(PR.IdModulo, 1) = 1        
 AND MA.Tipo = 'MA'        
        
 --Inicio @01        
 IF @EsMatricula = 0        
 BEGIN        
          
  PRINT 'Error'        
        
  EXEC [dbo].[cSistemaSuceso_Ins_Grabar]              
      @IdSistema = 3,              
      @Login = 'EnvioCorreo',              
      @Formulario = 'ProcesoDeMatriculaManual',              
      @Mensaje = 'No se envio el correo por EsMatricula 0'          
  RETURN        
 END        
        
 --Fin @01        
                
 SELECT @CodigoSedeNuevo= codigo         
 FROM sede with (nolock) where IdSede = @IdSede        
                
 SELECT @CompaniaSocio = E.CompaniaSocio         
 FROM Empresa E WITH (NOLOCK)                    
 WHERE E.IdEmpresa = @IdEmpresa                    
                    
 IF @CodigoSedeNuevo = 'IT'  OR @CodigoSedeNuevo = 'CD'        
 BEGIN        
  SELECT            
  @NombreEmpresa = Valor,                    
  @WebPrincipal = Valor2,                    
  @WebZoom = Valor3,                    
  @WebSmart = Valor4                    
  FROM ParametroEmpresa WITH (NOLOCK)--Dominios de  Principal ,zoom , smart                    
  WHERE Nombre = 'EMPRESANOMBRE2'        
 END        
 ELSE        
 BEGIN        
  SELECT            
  @NombreEmpresa = Valor,                    
  @WebPrincipal = Valor2,                    
  @WebZoom = Valor3,                    
  @WebSmart = Valor4                    
  FROM ParametroEmpresa WITH (NOLOCK)--Dominios de  Principal ,zoom , smart                    
  WHERE Nombre = 'EMPRESANOMBRE'            
 END        
            
 IF @CodigoSedeNuevo = 'IT'        
 BEGIN        
  SELECT                    
  @CorreoPrincipal = Valor,                  
  @CorreoSaeDip = Valor3,                
  @CorreoSaeCur = Valor4            
  FROM ParametroEmpresa WITH (NOLOCK)              
  WHERE Nombre = 'CORREOVRA3'         
 END        
 ELSE IF @CodigoSedeNuevo = 'CD'        
 BEGIN        
  SELECT @CorreoPrincipal = Valor,                  
    @CorreoSaeDip = Valor3,                   
    @CorreoSaeCur = Valor4                     
  FROM ParametroEmpresa WITH (NOLOCK)--Dominios de Principal ,zoom , smart                    
  WHERE Nombre = 'CORREOVRA2'           
 END        
 ELSE        
 BEGIN        
  SELECT @CorreoPrincipal = Valor,                  
    @CorreoSaeDip = Valor3,                  
    @CorreoSaeCur = Valor4                     
  FROM ParametroEmpresa WITH (NOLOCK)--Dominios de Principal ,zoom , smart                    
  WHERE Nombre = 'CORREOVRA'                         
 END            
         
 IF @IdUnidadNegocio = 2              
 BEGIN                
  UPDATE Usuario SET EsUsuarioAD = 0 WHERE IdActor = @CurIdAlumno AND IdTipoUsuario = 1                
 END        
                       
	--   SELECT @uEmail = AE.Descripcion         
	--FROM ActorEmail AE WITH(NOLOCK)                    
	--   INNER JOIN Matricula MAT WITH(NOLOCK) ON AE.IdActor = MAT.IdActor                    
	--   WHERE MAT.IdMatricula = @CurIdMatricula AND AE.principal = 1                    

		SELECT  @uEmail = T.Descripcion  FROM (
		SELECT TOP 1 AE.Descripcion,ae.IdActor,ISNULL(AE.Principal,0) as principal ,AE.FechaModificacion
		FROM ActorEmail AE WITH(NOLOCK)
		INNER JOIN MATRICULA MAT WITH(NOLOCK)
		ON AE.IdActor = MAT.IdActor
		WHERE MAT.IdMatricula = @CurIdMatricula
		AND AE.Descripcion <> ''
		ORDER BY principal DESC,AE.FechaModificacion desc) T 

                        
    SELECT @uNombres = Nombres FROM Usuario WITH(NOLOCK) WHERE Login = @CodigoAlumno                    
    SELECT @Dominio = Valor FROM parametro WITH(NOLOCK) WHERE nombre = 'CorreoIpae2' and valor2 = @CodigoSedeNuevo        
        
 IF @Dominio IS NULL        
 BEGIN        
  SELECT @Dominio = Valor FROM parametro WITH(NOLOCK) WHERE nombre = 'CorreoIpae'        
 END        
               
    SET  @pNombreCorreoUA = ISNULL(CASE @IdUnidadAcademica                    
            When 2 Then 'cEnvioBienvenidaDIP'                    
            When 48 Then 'cEnvioBienvenidaVIR'                    
            When 1 Then 'cEnvioBienvenidaCAR'                    
            When 57 Then 'cEnvioBienvenidaCAR'               
            When 59 Then 'cEnvioBienvenidaCAR'  --CGT IDAT               
            When 60 Then 'cEnvioBienvenidaCAR'  --CCM IDAT           
            Else ''                    
            End,'')             
        
 IF @IdUnidadAcademica = 64 SET @pNombreCorreoUA = NULL        
           
 IF @CodigoSedeNuevo = 'IT'        
 BEGIN        
  IF @IdUnidadNegocio = 1 --Division: Carrera Profesional        
  BEGIN        
    SET @pNombreCorreoUA = 'cEnvioBienvenidaCAR2'        
  END        
  ELSE IF @IdUnidadNegocio = 2 --Division: Extension        
  BEGIN        
    SET @pNombreCorreoUA = 'cEnvioBienvenidaDIP2'        
  END        
  ELSE        
  BEGIN        
    SET @pNombreCorreoUA = NULL        
  END        
 END        
      
  IF @CompaniaSocio='00002600'  --@03    
  BEGIN      
        
   IF @IdUnidadNegocio = 1 --Division: Carrera Profesional      
   BEGIN      
     SET @pNombreCorreoUA = 'cEnvioBienvenidaCAR'      
   END      
   ELSE IF @IdUnidadNegocio in (2,26) --Division: Extension,talleres      
   BEGIN      
     SET @pNombreCorreoUA = 'cEnvioBienvenidaCUR'      
   END      
   --Fin --@40      
   ELSE      
   BEGIN      
     SET @pNombreCorreoUA = 'cEnvioBienvenidaCAR'     
  END      
      
 END      
            
    IF LEN(@pNombreCorreoUA) > 0 AND @ValHorario = 0 AND @EsMatricula = 1 --@01              
    BEGIN 
	                   
	  SELECT @Subject = AsuntoMensaje,                    
		@UrlImagenes = IsNull(CabeceraMensaje,''),                    
		@mjs = CuerpoMensaje,                    
		@pieMensaje = IsNull(PieMensaje,''),              
		@ListaCopiaCorreo = IsNull(ListaCorreoUno,'')                
	  FROM Correo WITH(NOLOCK)                    
	  WHERE IdTipo = 6 AND Nombre = @pNombreCorreoUA                    
        
   --Division: Carrera Profesional      --@06 INICIO    
   IF @TipoServicio = 'C'          --@06      
   BEGIN            
    --Fecha de Inicio del Periodo            
    SELECT @FechaInicio=CONVERT(VARCHAR(10),Inicio,103) FROM Periodo WITH (NOLOCK) WHERE IdPeriodo=@IdPeriodo            
   END                      
   ELSE            
   BEGIN            
  --Division: Extension    
     --Fecha de Inicio de la Seccion            
     SELECT @FechaInicio= CONVERT(VARCHAR(10),PG.FechaInicio,103)    -- @55  
     FROM Matricula MAT WITH (NOLOCK)            
	 INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON PG.IdPromocion = MAT.IdPromocion AND PG.IdGrupo = MAT.IdGrupo     --   @55        
     WHERE MAT.IdMatricula = @CurIdMatricula --Fin @46           
   END                    --@06   FIN  
   
           
  SET @Usuario = ISNULL(@CodigoAlumno, 'No encontrado')                    
  --SET @clave ='inicio12'--@2        
  --inicio @02        
  --SELECT @clave = Clave from Usuario WITH (NOLOCK) WHERE IdActor = @CurIdAlumno AND IdTipoUsuario = 1        
  --select @passwdGenericas=Valor from Parametro WITH (NOLOCK) where Nombre='PASSWORDGENERICAS'        
  IF EXISTS(select 1 from Usuario WITH (NOLOCK) where IdActor = @CurIdAlumno and ISNULL(ClaveRobusta,'') = '' AND IdTipoUsuario = 1)        
  BEGIN        
   IF @CompaniaSocio = '00002700'        
   BEGIN        
    DECLARE @ApePaterno CHAR(1)                    
    SELECT @ApePaterno = SUBSTRING(ApellidoPaterno, 1, 1) From Usuario With(Nolock) where Login = @CodigoAlumno AND IdTipoUsuario = 1                  
    SET @clave = @CurNumeroDocumento + @ApePaterno        
   END        
   ELSE        
   BEGIN        
   SET @clave ='inicio12'        
   END        
  END        
  ELSE        
  BEGIN        
   SELECT @clave = dbo.cDesencriptaCadenaNumericaPwdAlumno(ClaveRobusta) from Usuario WITH (NOLOCK) WHERE IdActor = @CurIdAlumno AND IdTipoUsuario = 1        
  END        
  --fin @02        
          
  SET @Subject = REPLACE(@Subject, '[NombreEmpresa]', ISNULL(@NombreEmpresa, ''))    --@05            
        SET @mjs = REPLACE(@mjs, '[NombreAlumno]', ISNULL(@uNombres, ''))    --@05       
        SET @mjs = REPLACE(@mjs, '[CorreoPrincipal]', ISNULL(@CorreoPrincipal, ''))--@05        
        SET @mjs = REPLACE(@mjs, '[NombreEmpresa]', ISNULL(@NombreEmpresa, '')) --@05            
  SET @mjs = REPLACE(@mjs, '[FechaInicio]', ISNULL(@FechaInicio, '')) --@05            
        SET @mjs = REPLACE(@mjs, '[WebPrincipal]',ISNULL( @WebPrincipal, '')) --@05       
        SET @mjs = REPLACE(@mjs, '[URLIMAGENES]',ISNULL( @UrlImagenes, '')) --@05       
        SET @mjs = REPLACE(@mjs, '[ZoomUrlWeb]', ISNULL(@WebZoom, ''))   --@05       
  SET @mjs = REPLACE(@mjs, '[Usuario]', ISNULL(@Usuario, ''))    --@05       
          
  SET @pieMensaje = REPLACE(@pieMensaje, '[WebPrincipal]', ISNULL(@WebPrincipal, ''))--@05                 
        
  SET @mjs = @mjs + @pieMensaje               
          
  --SELECT @CompaniaSocio        
                      
  IF @CompaniaSocio = '00002500' or @CompaniaSocio = '00002400' --@04      
  BEGIN                    
   SET @mjs = REPLACE(@mjs, '[Clave]', @clave)                    
   SET @mjs = REPLACE(@mjs, '[CorreoCorporativoAlumno]', @Usuario + @Dominio)        
        
   IF @CodigoSedeNuevo = 'IT'        
   BEGIN        
    SET @profile_name_empresa = 'Avisos Smart ITS'        
   END        
   ELSE        
   BEGIN        
    SET @profile_name_empresa = 'Avisos Smart'        
   END        
        
   IF @pNombreCorreoUA = 'cEnvioBienvenidaVIR' and   @IdUnidadAcademica=48        
   BEGIN        
    DECLARE @IdCorreo INT = NULL              
      ,@jsonReturn VARCHAR(250) = ''              
      ,@retorno VARCHAR(250) = ''              
      ,@Url VARCHAR(5000) = ''         
      ,@IdCorreoEnvio INT = NULL              
      ,@CodigoEnvio INT = NULL              
      ,@NumeroEnvio BIGINT = NULL              
      ,@MensajeRespuesta VARCHAR(5000) = ''              
      ,@Excepcion VARCHAR(5000) = ''        
        
    EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar          
      @profile_name  ='Avisos Smart',          
      @recipients =@uEmail,                   
      @subject = @Subject,                   
      @body = @mjs,                    
      @body_format = 'HTML',          
      @Estado=0,          
      @Usuario='1'     ,          
      @Disponible1 = @nombreSp,               
      @Disponible3 = 'Bienvenida Diplomados',            
      @CodigoRemitente =   'PROVEEDOR_ITB',          
      @IdMatricula=  @CurIdMatricula;          
                              
                  
    SELECT @IdCorreo = @@IDENTITY               
                
    IF @IdCorreo IS NULL                
    BEGIN               
     SET @Excepcion = @CodigoAlumno + ': No se gener� registro de correo'              
                    
     EXEC [dbo].[cSistemaSuceso_Ins_Grabar]              
     @IdSistema = 57,              
     @Login = 'EnvioCorreoITB',              
     @Formulario = 'EnvioCorreoBienvenida',              
     @Mensaje = @Excepcion              
    END              
    ELSE              
    BEGIN              
                
     SELECT @Url = Valor FROM Parametro WITH(NOLOCK) WHERE Nombre = 'EnvioCorreosProveedor_DIPLOMADOS_ITB'          
         
     SET @Url = REPLACE(@Url, '[IdCorreo]', CONVERT(VARCHAR(20),@IdCorreo))               
     SET @Url = REPLACE(@Url, '[mailDestination]',@uEmail)               
     SET @Url = REPLACE(@Url, '[nombre]', @uNombres)        
     SET @Url = REPLACE(@Url, '[fechaInicio]', @FechaInicio)               
     SET @Url = REPLACE(@Url, '[usuarioAlumno]', @CodigoAlumno)               
     SET @Url = REPLACE(@Url, '[passwordAlumno]', @clave)               
     SET @Url = REPLACE(@Url, '[emailAlumno]', @Usuario + @Dominio)                 
                
     SELECT @retorno = dbo.GetHttp(@Url)               
                
     SET @jsonReturn = LEFT(@retorno, LEN(@retorno)-1);              
     SET @jsonReturn = RIGHT(@jsonReturn, LEN(@jsonReturn)-1)               
     SET @jsonReturn = REPLACE(@jsonReturn,'\','')              
                
     SELECT @IdCorreoEnvio  = idCorreo              
       ,@CodigoEnvio  = code              
       ,@NumeroEnvio  = requestId              
       ,@MensajeRespuesta = [message]              
     FROM OPENJSON(@jsonReturn)      
     WITH(              
      idCorreo INT 'strict $.idCorreo',              
      code INT 'strict $.code',              
      requestId BIGINT 'strict $.requestId',            
      [message] NVARCHAR(250) 'strict $.message'              
     )              
        
     IF @CodigoEnvio = 0              
     BEGIN              
      UPDATE BDSMTP.dbo.EnvioCorreo              
      SET Estado = 1,              
      Disponible2 = CONVERT(varchar,@NumeroEnvio),           
      Disponible5 = @Url,        
      UsuarioModificacion = '1',              
      FechaModificacion = GETDATE()              
      WHERE IdCorreo = @IdCorreoEnvio          
     END              
     ELSE              
     BEGIN               
                      
      SET @Excepcion = 'IdCorreo: ' + CONVERT(VARCHAR(20),@IdCorreoEnvio) + '. ' + @MensajeRespuesta              
                
      EXEC [dbo].[cSistemaSuceso_Ins_Grabar]              
      @IdSistema = 57,              
      @Login = 'EnvioCorreoITB',              
      @Formulario = 'EnvioCorreoBienvenida',              
      @Mensaje = @Excepcion              
                
      UPDATE BDSMTP.dbo.EnvioCorreo              
      SET Estado = -1,              
      Disponible2 = @Excepcion,          
      Disponible5 = @Url,        
      UsuarioModificacion = '1',              
      FechaModificacion = GETDATE()              
      WHERE IdCorreo = @IdCorreoEnvio              
                    
     END              
    END        
   END        
   ELSE        
   BEGIN        
    EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar             
    @recipients = @uEmail,                    
    @blind_copy_recipients = @CorreoPrincipal,                        
    @profile_name = @profile_name_empresa,                   
    @subject = @Subject,                    
   @body = @mjs,                    
    @body_format = 'HTML',               
    @Disponible1 = @nombreSp,             
    @Disponible3 = @CurIdMatricula,                   
    @IdMatricula=  @CurIdMatricula;          
   END        
  END         
        
  IF @CompaniaSocio = '00002600' AND    
    NOT EXISTS(select TOP 1 1 from Matricula WITH(NOLOCK)     
   where IdActor=@CurIdAlumno AND IdMatricula<>@CurIdMatricula AND EsMatricula=1 )  --CORRIENTE ALTERNA  --@05    
 BEGIN      
 SET @mjs = REPLACE(@mjs, '[Clave]', @clave)      
 SET @mjs = REPLACE(@mjs, '[CorreoCorporativoAlumno]', @Usuario + @Dominio)--@28         
        
         
 SET @profile_name_empresa = 'Avisos Smart'      
      
 EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar             
 @recipients = @uEmail,                    
 @blind_copy_recipients = @CorreoPrincipal,                        
 @profile_name = @profile_name_empresa,                   
 @subject = @Subject,                    
 @body = @mjs,                    
 @body_format = 'HTML',               
 @Disponible1 = @nombreSp,             
 @Disponible3 = @CurIdMatricula,                   
 @IdMatricula=  @CurIdMatricula;       
  END                   
                    
                       
  IF @CompaniaSocio = '00002700'                    
  BEGIN                    
   --DECLARE @ApePaterno CHAR(1)--@2                   
   --SELECT @ApePaterno = SUBSTRING(ApellidoPaterno, 1, 1) From Usuario With(Nolock) where Login = @CodigoAlumno--@2                 
   --SET @clave = @CurNumeroDocumento + @ApePaterno--@2        
        
   SET @mjs = REPLACE(@mjs, '[Clave]', @clave)                    
   SET @mjs = REPLACE(@mjs, '[CorreoCorporativoAlumno]', @Usuario + @Dominio)               
   DECLARE @CopiaOculta VARCHAR(500) =  @ListaCopiaCorreo  + ';' + @CorreoPrincipal                     
        
   IF @pNombreCorreoUA in ('cEnvioBienvenidaCAR','cEnvioBienvenidaVIR')             
   BEGIN              
                     
    SET @IdCorreo  = NULL              
    SET @jsonReturn  = ''              
    SET @retorno = ''              
    SET @Url  = ''              
    SET @IdCorreoEnvio = NULL              
    SET @CodigoEnvio  = NULL       
    SET @NumeroEnvio  = NULL              
    SET @MensajeRespuesta  = ''              
    SET @Excepcion  = ''             
    SET @TipoCorreo =  CASE @IdUnidadAcademica WHEN 48 THEN 'Bienvenida Diplomados' ELSE 'Bienvenida' END        
        
    EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar          
     @profile_name  ='Avisos Smart',          
     @recipients =@uEmail,                   
     @blind_copy_recipients = @CopiaOculta,                                  
     @subject = @Subject,                   
     @body = @mjs,                    
     @body_format = 'HTML',          
     @Estado=0,          
     @Usuario='1'     ,          
     @Disponible1 = @nombreSp,              
     @Disponible3 = @TipoCorreo,           
     @CodigoRemitente =   'PROVEEDOR_ITB',          
     @IdMatricula=  @CurIdMatricula;          
                    
    SELECT @IdCorreo = @@IDENTITY               
                
    IF @IdCorreo IS NULL                
    BEGIN        
     SET @Excepcion = @CodigoAlumno + ': No se gener� registro de correo'              
                    
     EXEC [dbo].[cSistemaSuceso_Ins_Grabar]              
     @IdSistema = 57,              
     @Login = 'EnvioCorreoITB',              
     @Formulario = 'EnvioCorreoBienvenida',              
     @Mensaje = @Excepcion              
    END              
    ELSE              
    BEGIN              
     IF @IdUnidadAcademica=48         
     BEGIN        
      SELECT @Url =  Valor FROM Parametro WITH(NOLOCK) WHERE Nombre = 'EnvioCorreosProveedor_DIPLOMADOS_ITB'         
        
      SET @Url = REPLACE(@Url, '[IdCorreo]', CONVERT(VARCHAR(20),@IdCorreo))               
      SET @Url = REPLACE(@Url, '[mailDestination]', @uEmail)               
      SET @Url = REPLACE(@Url, '[nombre]', @uNombres)              
      SET @Url = REPLACE(@Url, '[fechaInicio]', @FechaInicio)               
      SET @Url = REPLACE(@Url, '[usuarioAlumno]', @CodigoAlumno)               
      SET @Url = REPLACE(@Url, '[passwordAlumno]', @clave)               
      SET @Url = REPLACE(@Url, '[emailAlumno]', @Usuario + @Dominio)            
     END        
     ELSE        
     BEGIN              
      SELECT @Url = Valor FROM Parametro WITH(NOLOCK) WHERE Nombre = 'EnvioCorreoProveedor_ITB'              
                
      SET @Url = REPLACE(@Url, '[IdCorreo]', CONVERT(VARCHAR(20),@IdCorreo))               
      SET @Url = REPLACE(@Url, '[CorreoDestinatario]', @uEmail)               
      SET @Url = REPLACE(@Url, '[Asunto]', @Subject)               
      SET @Url = REPLACE(@Url, '[Nombre]', @uNombres)              
      SET @Url = REPLACE(@Url, '[FechaInicio]', @FechaInicio)               
      SET @Url = REPLACE(@Url, '[UsuarioAlumno]', @CodigoAlumno)               
      SET @Url = REPLACE(@Url, '[ClaveAlumno]', @clave)               
   SET @Url = REPLACE(@Url, '[EmailAlumno]', @Usuario + @Dominio)               
     END        
                
     SELECT @retorno = dbo.GetHttp(@Url)          
             
     --SELECT @retorno             
        
     SET @jsonReturn = LEFT(@retorno, LEN(@retorno)-1);              
     SET @jsonReturn = RIGHT(@jsonReturn, LEN(@jsonReturn)-1)               
     SET @jsonReturn = REPLACE(@jsonReturn,'\','')              
                
     SELECT @IdCorreoEnvio  = idCorreo              
       ,@CodigoEnvio  = code              
       ,@NumeroEnvio  = requestId              
       ,@MensajeRespuesta = [message]              
     FROM OPENJSON(@jsonReturn)              
     WITH(              
      idCorreo INT 'strict $.idCorreo',              
      code INT 'strict $.code',              
      requestId BIGINT 'strict $.requestId',            
      [message] NVARCHAR(250) 'strict $.message'              
     )              
                
     IF @CodigoEnvio = 0              
     BEGIN              
      UPDATE BDSMTP.dbo.EnvioCorreo              
      SET Estado = 1,              
      Disponible2 = CONVERT(varchar,@NumeroEnvio),            
      Disponible5=@Url,        
      UsuarioModificacion = '1',              
      FechaModificacion = GETDATE()              
      WHERE IdCorreo = @IdCorreoEnvio              
     END              
     ELSE              
     BEGIN               
                      
      SET @Excepcion = 'IdCorreo: ' + CONVERT(VARCHAR(20),@IdCorreoEnvio) + '. ' + @MensajeRespuesta              
                
      EXEC [dbo].[cSistemaSuceso_Ins_Grabar]              
      @IdSistema = 57,              
      @Login = 'EnvioCorreoITB',              
      @Formulario = 'EnvioCorreoBienvenida',              
      @Mensaje = @Excepcion              
                
      UPDATE BDSMTP.dbo.EnvioCorreo              
      SET Estado = -1,              
      Disponible2 = @Excepcion,          
      Disponible5=@Url,        
      UsuarioModificacion = '1',              
      FechaModificacion = GETDATE()              
      WHERE IdCorreo = @IdCorreoEnvio              
                    
     END              
    END              
   END               ELSE              
   BEGIN             
   EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar                    
     @recipients = @uEmail,                    
     @blind_copy_recipients = @CopiaOculta,                    
     @profile_name = 'Avisos Smart',                    
     @subject = @Subject,                    
     @body = @mjs,                    
     @body_format = 'HTML',              
     @Disponible1 = @nombreSp,              
     @Disponible3 =  'Bienvenida' ,          
     @IdMatricula= @CurIdMatricula;                   
   END           
  END                    
         
 END        
        
END 
