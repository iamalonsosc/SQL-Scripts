ALTER Procedure [dbo].[COp_InterfaseImportarDoc]
/*  
'**********************************************************************************      
'* Importaci�n de Documentos 
'* Output : Resultado de la importaci�n 
'* Creado por : Joel Chaccha C.      
'* Fec Creaci�n : 
'* Fec Actualizaci�n : 08/01/2019 Responsable : Giovani Polar 
'* Motivo : Se incluye la compa��a en las tablas de input para su importaci�n en las tablas de Spring 
'* 04-04-2019 bgaribay  se cambio el correo de ipae.edu.pe a zegelipae.edu.pe
'* 20-05-2019 giovani polar cambio de correlativo de pedidos
'@1		10.04.2020 jmota	se agrega opcion para separacion de vacantes (Pago Adelantado/reserva)
'@2		10.04.2020 jmota	fechas solo temporal
'@3		16.04.2020 jmota	separacion de vacantes por item detalle
'@4		17.08.2021 bgaribay se adiciona correo de Jcure y Jmota
'@5		16.09.2021 Joel chaccha se adciona with nolock a lo que falta y se separo correo de error por compa�ia
'@6		24.01.2022 EHuillca - Se comenta env�o de correos.
'@7		14.02.2022 EHuillca - Se descomenta correo y se cambia destinatario de idat
'@7		08-04-2022 Joel Chaccha - Inclusi�n de parametro de Cliente
'@8		15.12.2022	Illosad		Se agrega parametro SeparacionVacante
'@9 	16.12.2022	Illosad		Se cambia tipo de dato y se comenta seteo de variables
'@10	16.12.2022	Illosad		Se descomenta fecha de vencimiento de Separacion de Vacante
'@11	2024.05.17	jmota		se actualiza asunto de envio de correo para identificar el origen
'**********************************************************************************      
*/
(
   @pCliente varchar(15) = ''
)
As
Begin
   Set NoCount On
    
   Declare @w_rows int, @w_persona int   
   Declare @w_rows_detail int, @m int, @w_vendedor int, @w_items int, @w_clientenumero int, @w_vendedor_spring int, @w_count int
   Declare @w_error bit
   Declare @w_archivoheader varchar, @w_archivodetail varchar, @w_direcciondummy varchar, @w_documentoidentidad varchar
   Declare @w_Clienteruc varchar(15), @w_clientenombre varchar(50), @w_clientedireccion varchar(50), @w_cliente varchar(15)
   Declare @w_texto varchar(100), @w_codigo varchar(20), @w_CompaniaSocio varchar(8), @w_formadepago varchar, @w_formadepago_par varchar
   Declare @w_tc Decimal, @w_afecto Decimal, @w_noafecto Decimal, @w_cantidad Decimal
   Declare @w_errorFlag varchar, @w_vendedor_str varchar(20), @w_sql varchar, @w_estado varchar
   Declare @w_fechavencimientodesde datetime, @w_fechavencimientohasta datetime
   Declare @w_p61dctodat datetime
   Declare @w_factorventa real
   Declare @vBodyEmail varchar(max)
   Declare @vMensaje varchar(400)   
   Declare @vFagDosPedidos bit
   Declare @vFilasConsultadas int
   Declare @vFila int      
   Declare @vFilaCompania int   
   Declare @vCompaniaSocio char(8)
   Declare @vCorreo varchar(100)
   Declare @vCondicionMatricula char(20)
   Declare @vTipoFacturacion varchar(3)
   Declare @vGrupodescuento int
   Declare @vSeparacion real --@9
   
   Set @vFilasConsultadas = 0
   Set @vFila = 1
   Set @vBodyEmail = ''
   Set @vMensaje = ''   
   Set @vFagDosPedidos = 0

   Create Table #tmpdw_header
   (
      Id_Registro int identity(1,1),
	   CompaniaSocio char(8) Collate DataBase_Default,
      TipoDocumento char(2) Collate DataBase_Default,
      NumeroInterno int,
      FechaVencimiento datetime,
      TipoVenta char(3) Collate DataBase_Default,
      TipoFacturacion char(3) Collate DataBase_Default,
      Vendedor int,
      Monedacodigo char(2) Collate DataBase_Default,
      Sucursal char(4) Collate DataBase_Default,
      NotaCreditoDocumento char(17) Collate DataBase_Default,
      Cliente char(15) Collate DataBase_Default,
      ClienteCobrarA char(15) Collate DataBase_Default,
      Estado char(2) Collate DataBase_Default,
      EstablecimientoCodigo char(4) Collate DataBase_Default,
      Criteria char(20) Collate DataBase_Default,
      FechaPreparacion datetime,
      Descuento char(6) Collate DataBase_Default,
      FlagActualizacion char(1) Collate DataBase_Default,
      Clasificacion char(2) Collate DataBase_Default,
      Serie char(4) Collate DataBase_Default,
 ClienteNombre char(50) Collate DataBase_Default,
      ClienteRUC char(15) Collate DataBase_Default,
      ClienteDireccion char(50) Collate DataBase_Default,
      ClienteNumero money,
      IdMatricula int,
      CuotaNumero int,
      NumeroDocumento char(15) Collate DataBase_Default,
      Campania char(10) Collate DataBase_Default,
      Area char(2) Collate DataBase_Default,
      Periodo int,
      CondicionMatricula varchar(20) Collate DataBase_Default,
      ErrorFlag char(1) Collate DataBase_Default,
      Grupodescuento int,
      GrupoTipo int,
      Captacion char(1) Collate DataBase_Default null
   )   

   Create Table #tmpdw_detail
   (
	   CompaniaSocio char(8) Collate DataBase_Default,
      TipoDocumento char(2) Collate DataBase_Default,
      NumeroInterno int,
      secuencia int,
      TipoDetalle char(1) Collate DataBase_Default,
      ItemCodigo varchar(20) Collate DataBase_Default,
      Descripcion char(50) Collate DataBase_Default,
      CantidadPedida money,
      Estado char(2) Collate DataBase_Default,
      MontoOriginal money,
      Monto	money
   )

   Create Table #tmpdw_detailResumen
   (
      Id_Registro int identity(1,1),
	   CompaniaSocio char(8) Collate DataBase_Default,
      TipoDocumento char(2) Collate DataBase_Default,
      NumeroInterno int,
      secuencia int,
      TipoDetalle char(1) Collate DataBase_Default,
      ItemCodigo varchar(20) Collate DataBase_Default,
      Descripcion char(50) Collate DataBase_Default,
      CantidadPedida money,
      Estado char(2) Collate DataBase_Default,
      MontoOriginal money,
      Monto	money
   )   
   
   Create Table #tmpErroresDocumento
   (
      Id_Registro int identity(1,1),
      Documento varchar(100) Collate DataBase_Default,
      Linea int,
      Descripcion varchar(350) Collate DataBase_Default,
      CompaniaSocio char(8) Collate DataBase_Default
   )

   Create Table #tmpCompanias
   (
      Id_Registro int identity(1,1),      
      CompaniaSocio char(8) Collate DataBase_Default,
      Correo varchar(100) Collate DataBase_Default
   )

   BEGIN TRANSACTION;   
   BEGIN TRY

      Set @vFilasConsultadas = 0
      Set @vFila = 1

      --Set @w_CompaniaSocio = '00002500'
      Set @w_fechavencimientodesde = GetDate() 
      Set @w_fechavencimientohasta = GetDate()
      Set @w_estado = 'GE'
      
      --Obtenemos el tipo de cambio
      Select @w_factorventa = tc.FactorVenta
      From TipoCambioMast tc With  (NoLock)
      Where ( tc.MonedaCodigo = 'EX' ) and          
         ( tc.MonedaCambioCodigo = 'LO' ) and          
         ( tc.FechaCambioString = Convert(varchar(8), GetDate(), 112) )       

      Select @w_vendedor = ParametrosMast.Numero 
      From ParametrosMast With (NoLock) 
      Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
            ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
            ( ParametrosMast.ParametroClave ='DOCVENDEDO' ) 

      Select @w_formadepago_par = Texto
      From ParametrosMast With (NoLock) 
      Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
            ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
            ( ParametrosMast.ParametroClave ='DOCFORPAGO' ) 

      Select @w_p61dctodat = ParametrosMast.Fecha 
      From ParametrosMast With (NoLock) 
      Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
            ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
            ( ParametrosMast.ParametroClave ='P61DCTODAT' ) 

      Insert Into #tmpCompanias
      (
         CompaniaSocio, Correo
      )
      Select '00002500', 'jcure@inlearning.pe' Union All
      Select '00002700', 'mejoracontinuaidat@inlearning.pe' --@7 @11

      --inserta la cabecera en el temporal
      Insert Into #tmpdw_header
      (
         CompaniaSocio, TipoDocumento, NumeroInterno, FechaVencimiento, TipoVenta, TipoFacturacion, Vendedor, Monedacodigo, Sucursal, NotaCreditoDocumento, Cliente, ClienteCobrarA,
         Estado, EstablecimientoCodigo, Criteria, FechaPreparacion,  Descuento, FlagActualizacion, Clasificacion, Serie, ClienteNombre, ClienteRUC, ClienteDireccion,
         ClienteNumero, IdMatricula, CuotaNumero, NumeroDocumento, Campania, Area, Periodo, CondicionMatricula, ErrorFlag, Grupodescuento, GrupoTipo,
         Captacion
      )
      Select a.CompaniaSocio, a.TipoDocumento, a.NumeroInterno, a.FechaVencimiento, a.TipoVenta, a.TipoFacturacion, a.Vendedor, a.MonedaCodigo, a.Sucursal, a.NotaCreditoDocumento,
             a.Cliente, a.ClienteCobrarA, a.Estado, a.EstablecimientoCodigo, a.Criteria, a.FechaPreparacion, a.Descuento, a.FlagActualizacion, b.Clasificacion,
             a.Serie, c.Descripcion01 as 'ClienteNombre', c.Codigo01 as 'ClienteRUC', c.Descripcion01 as 'ClienteDireccion', c.Monto01 as 'ClienteNumero', a.IdMatricula,
             a.cuotanumero, a.NumeroDocumento, a.Campania, a.Area, a.Periodo, a.CondicionMatricula, c.Flag01 as 'ErrorFlag', a.Grupodescuento, a.GrupoTipo,
             IsNull(a.Interfase_Captacion, '')
      From CO_Interfase_P09_Header a With (NoLock), 
           CO_TipoDocumento b With (NoLock), 
           SY_CampoCalculado c With (NoLock)   
      Where a.Cliente = Case When @pCliente = '' Then Cliente Else @pCliente End And 
            (a.TipoDocumento = b.TipoDocumento) and   
            ((a.Estado = 'GE') and (c.RegistroNumero = 1)) And
            ((a.TipoFacturacion = 'MAT') or (a.TipoFacturacion = 'CON'))            

      Set @vFilasConsultadas = @@RowCount      
      
      --Inserta el detalle en el temporal
      Insert Into #tmpdw_detail
      (
         CompaniaSocio, TipoDocumento, NumeroInterno, Secuencia, TipoDetalle, ItemCodigo, CantidadPedida, Estado, Descripcion, MontoOriginal, Monto
      )
      Select c.CompaniaSocio, c.TipoDocumento, c.NumeroInterno, c.Secuencia, c.TipoDetalle, c.ItemCodigo, c.CantidadPedida, c.Estado, c.Descripcion,     
             c.MontoOriginal, c.Monto
      From CO_Interfase_P09_Detalle c With (NoLock) ,
           CO_Interfase_P09_Header a  With (NoLock)     
      Where (a.CompaniaSocio = c.CompaniaSocio) and 
			(a.TipoDocumento = c.TipoDocumento) and (a.NumeroInterno = c.NumeroInterno) and 
			a.Cliente = Case When @pCliente = '' Then Cliente Else @pCliente End And
			(a.Estado = 'GE' ) 

      --Validar que los datos consultados no presenten inconsistencias
      While (@vFila <= @vFilasConsultadas)
      Begin    
         Set @w_errorFlag = 'N'
         Set @w_error = 0
         Set @w_vendedor = Null
         Set @w_vendedor_str = ''
         Set @w_vendedor_spring = Null
         Set @w_cliente = ''
         Set @w_clientenumero = Null
         Set @w_Clienteruc = '' 
         Set @w_clientenombre  = ''
         Set @w_clientedireccion = ''
         Set @w_clientenumero = Null
         Set @w_items = Null
         Set @w_afecto = 0.00
         Set @w_noafecto = 0.00
         Set @w_rows_detail = Null
         Set @m = 1
         Set @vGrupoDescuento = Null

         --Validar la cabecera
         Select @w_texto = CompaniaSocio + '-' + TipoDocumento + '-' + Replicate('0', 8 - Len(Convert(Varchar(8), NumeroInterno))) + Convert(Varchar(8), NumeroInterno)
         From #tmpdw_header
         Where Id_Registro = @vFila
         
         --Validar el numero del documento
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And NumeroInterno Is Null) > 0
         Begin
            Update #tmpdw_header
            Set ErrorFlag = 'S'
            Where Id_Registro = @vFila

            --Registrar el error
            Insert Into #tmpErroresDocumento
            (
                Documento, Linea, Descripcion, CompaniaSocio
            )
            Select @w_texto, Id_Registro, 'Debe indicar el Numero del Documento', CompaniaSocio
            From #tmpdw_header
   Where Id_Registro = @vFila

            Set @w_errorFlag = 'S'
         End

--Validar establecimiento 
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And EstablecimientoCodigo Is Null) > 0
         Begin            
            Update #tmpdw_header
            Set ErrorFlag = 'S'
            Where Id_Registro = @vFila
           
            --Registrar el error
            Insert Into #tmpErroresDocumento
            (
                Documento, Linea, Descripcion, CompaniaSocio
            )
            Select @w_texto, Id_Registro, 'No existe establecimiento fiscal para la serie y compa�ia del documento', CompaniaSocio
            From #tmpdw_header
            Where Id_Registro = @vFila

            Set @w_errorFlag = 'S'
         End

         --Validar Fecha de Preparaci�n
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And FechaPreparacion Is Null) > 0
         Begin
            Update #tmpdw_header
            Set ErrorFlag = 'S'
            Where Id_Registro = @vFila
           
            --Registrar el error
            Insert Into #tmpErroresDocumento
            (
                Documento, Linea, Descripcion, CompaniaSocio
            )
            Select @w_texto, Id_Registro, 'Debe de indicar la fecha de emisi�n', CompaniaSocio
            From #tmpdw_header
            Where Id_Registro = @vFila
            
            Set @w_errorFlag = 'S'
         End
         
         --Validar Fecha de Vencimiento
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And FechaVencimiento Is Null) > 0
         Begin
            Update #tmpdw_header
            Set ErrorFlag = 'S'
            Where Id_Registro = @vFila
            
            --Registrar el error
            Insert Into #tmpErroresDocumento
            (
                Documento, Linea, Descripcion, CompaniaSocio
            )
            Select @w_texto, Id_Registro, 'Debe de indicar la fecha de vencimiento', CompaniaSocio
            From #tmpdw_header
            Where Id_Registro = @vFila
            
            Set @w_errorFlag = 'S'
         End
         
          --Validar Serie 
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And (Serie Is Null Or RTrim(Serie) = '')) > 0
         Begin
            Update #tmpdw_header
            Set ErrorFlag = 'S'
            Where Id_Registro = @vFila
            
            --Registrar el error
            Insert Into #tmpErroresDocumento
            (
               Documento, Linea, Descripcion, CompaniaSocio
            )
            Select @w_texto, Id_Registro, 'Debe de indicar la serie', CompaniaSocio
            From #tmpdw_header
            Where Id_Registro = @vFila
           
            Set @w_errorFlag = 'S'
         End
        
         ----Validar el vendedor
         --Select @w_vendedor = Vendedor
         --From #tmpdw_header
         --Where Id_Registro = @vFila 
         
         --If (Select Count(*) 
         --    From PersonaMast 
         --    Where PersonaAnt = Convert(varchar(15), @w_vendedor) And Estado = 'A') = 0
         --Begin
         --      --No se reporta como error solo es un mensaje de advertencia
               
         --      --Registrar el Warning
         --      Insert Into #tmpErroresDocumento
         --      (
         --          Documento, Linea, Descripcion, CompaniaSocio
         --      )
         --      Select 'Aviso:' + @w_texto, Id_Registro, 'El vendedor no es valido: ' + Convert(varchar(15), IsNull(Vendedor, '')), CompaniaSocio
         --      From #tmpdw_header
         --      Where Id_Registro = @vFila
               
         --      Set @w_errorFlag = 'S'
         --End
      
         --Extraemos el codigo de Vendedor del Spring
         Set @w_vendedor_str = Convert(varchar(15), @w_vendedor)
 
         Select @w_vendedor_spring = MAX(Persona) 
         From PersonaMast With (NoLock) 
         Where PersonaAnt = @w_vendedor_str 
       
         --Actualizamos el codigo del vendedor en el header
         Update #tmpdw_header
         Set Vendedor = @w_vendedor_spring
         Where Id_Registro = @vFila
         
         --Validar el cliente
         Select @w_cliente = RTrim(Cliente)
         From #tmpdw_header
         Where Id_Registro = @vFila 
         
         --Actualizmos los datos del Cliente a Cobrar
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And (ClienteCobrarA Is Null Or RTrim(ClienteCobrarA) = '')) > 0
         Begin
            Update #tmpdw_header
            Set ClienteCobrarA = Convert(Varchar(15), @w_cliente)
            Where Id_Registro = @vFila
         End
         
         --Traemos datos del cliente de PersonaMast
         Select @w_clientenombre = PersonaMast.NombreCompleto , 
                @w_Clienteruc = PersonaMast.Documento , 
                @w_clientedireccion = PersonaMast.Direccion , 
                @w_clientenumero = Persona
         From PersonaMast With (NoLock) 
         Where PersonaAnt = Rtrim(Convert(varchar(15), @w_cliente))
         
         --Validamos si el cliente existe
         If (@w_clientenumero Is Null)
         Begin
            If (Select Count(*)
                From PersonaMast a With (NoLock) 
                Inner Join Persona_inter b With (NoLock) On a.Documento = b.Documento And b.PersonaCodigo = @w_cliente) = 0
            Begin 
               Update #tmpdw_header
               Set ErrorFlag = 'S'
               Where Id_Registro = @vFila
               
               --Registrar el error
               Insert Into #tmpErroresDocumento
               (
                   Documento, Linea, Descripcion, CompaniaSocio
               )
               Select @w_texto, Id_Registro, 'El Cliente no existe: ' + @w_cliente, CompaniaSocio
               From #tmpdw_header
               Where Id_Registro = @vFila
               
               Set @w_errorFlag = 'S'
            End
            Else
            Begin
               --Se actualiza el PersonaAnt de PersonaMast
               Update PersonaMast
               Set PersonaAnt = Convert(varchar(20), b.PersonaCodigo)
               From PersonaMast a 
               Inner Join Persona_inter b On a.Documento = b.Documento And b.PersonaCodigo = @w_cliente
               
               --Traemos datos del cliente de PersonaMast
               Select @w_clientenombre = PersonaMast.NombreCompleto , 
                      @w_Clienteruc = PersonaMast.Documento , 
                      @w_clientedireccion = PersonaMast.Direccion , 
                      @w_clientenumero = Persona
               From PersonaMast With (NoLock) 
               Where PersonaAnt = Rtrim(Convert(varchar(15), @w_cliente))
               
               --Actualizos datos del cliente en la cabecera
               Update #tmpdw_header
               Set ClienteNombre = @w_clientenombre,
                   ClienteDireccion = @w_clientedireccion,
                   ClienteRUC = @w_Clienteruc,
                   ClienteNumero = @w_clientenumero
               Where Id_Registro = @vFila
            End
         End
         Else
         Begin
            --Actualizos datos del cliente en la cabecera
            Update #tmpdw_header
            Set ClienteNombre = @w_clientenombre,
                ClienteDireccion = @w_clientedireccion,
                ClienteRUC = @w_Clienteruc,
                ClienteNumero = @w_clientenumero
            Where Id_Registro = @vFila
         End


         --Validar el cliente A Cobrar
         Select @w_cliente = RTrim(ClienteCobrarA)
         From #tmpdw_header
         Where Id_Registro = @vFila 
         
         Set @w_clientenumero = Null
      Set @w_Clienteruc = ''
         
         --Traer datos del cliente a cobrar
         Select @w_clientenumero = Persona, 
                @w_Clienteruc = Documento 
         From PersonaMast With (NoLock) 
         Where PersonaMast.PersonaAnt = RTrim(@w_cliente )
         
         --Validamos del Cliente a cobrar
         If (@w_clientenumero Is Null)
         Begin
            If (Select Count(*)
                From PersonaMast a With (NoLock) 
                Inner Join Persona_inter b  With (NoLock)  On a.Documento = b.Documento And b.PersonaCodigo = @w_cliente) = 0
            Begin
               Update #tmpdw_header
               Set ErrorFlag = 'S'
               Where Id_Registro = @vFila
               
               --Registrar el error
               Insert Into #tmpErroresDocumento
               (
                   Documento, Linea, Descripcion, CompaniaSocio
               )
               Select @w_texto, Id_Registro, 'El Cliente Cobrar A no existe: ' + IsNull(@w_cliente, ''), CompaniaSocio
               From #tmpdw_header
               Where Id_Registro = @vFila
               
               Set @w_errorFlag = 'S'
            End
            Else
            Begin
               --Se actualiza el PersonaAnt de PersonaMast
               Update PersonaMast
               Set PersonaAnt = Convert(varchar(20), b.PersonaCodigo)
               From PersonaMast a
               Inner Join Persona_inter b On a.Documento = b.Documento And b.PersonaCodigo = @w_cliente
               
               --Traemos datos del cliente de PersonaMast
               Select @w_Clienteruc = Documento,
                      @w_clientenumero = Persona
               From PersonaMast With (NoLock) 
               Where PersonaAnt = Rtrim(Convert(varchar(15), @w_cliente))
               
               --Actualizos datos del cliente en la cabecera
               Update #tmpdw_header
               Set ClienteCobrarA = @w_clientenumero
               Where Id_Registro = @vFila
            End
         End
         Else
         Begin
            --Actualizamos datos del Cliente a Cobrar
            Update #tmpdw_header
            Set ClienteCobrarA = @w_clientenumero
            Where Id_Registro = @vFila
         End

         --Validando tipo de venta
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And (Not TipoVenta Is Null Or RTrim(TipoVenta) <> '')) > 0
         Begin
            If (Select Count(*)
                From CO_TipoVenta  With (NoLock) 
                Where TipoVenta In (Select TipoVenta From #tmpdw_header Where Id_Registro = @vFila)) = 0
            Begin
               Update #tmpdw_header
               Set ErrorFlag = 'S'
               Where Id_Registro = @vFila
               
               --Registrar el error
               Insert Into #tmpErroresDocumento
               (
                  Documento, Linea, Descripcion, CompaniaSocio
               )
               Select @w_texto, Id_Registro, 'El tipo de venta no es v�lido: ' + TipoVenta, CompaniaSocio
               From #tmpdw_header
               Where Id_Registro = @vFila
               
               Set @w_errorFlag = 'S'
            End
         End

         --Validando tipo de Facturaci�n
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And (Not TipoFacturacion Is Null Or RTrim(TipoFacturacion) <> '')) > 0
         Begin
            If (Select Count(*)
                From CO_TipoFacturacion With (NoLock) 
                Where TipoFacturacion In (Select TipoFacturacion From #tmpdw_header Where Id_Registro = @vFila)) = 0
            Begin
               Update #tmpdw_header
               Set ErrorFlag = 'S'
               Where Id_Registro = @vFila
   
               --Registrar el error
               Insert Into #tmpErroresDocumento
               (
                   Documento, Linea, Descripcion, CompaniaSocio
               )
               Select @w_texto, Id_Registro, 'El tipo de facturaci�n no es v�lido: ' + TipoFacturacion, CompaniaSocio
               From #tmpdw_header
               Where Id_Registro = @vFila                

               Set @w_errorFlag = 'S'
            End
         End
                 
         --Validando Sucursal
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And (Not Sucursal Is Null Or RTrim(Sucursal) <> '')) > 0
         Begin
            If (Select Count(*)
                From AC_Sucursal With (NoLock) 
                Where Sucursal In (Select Sucursal From #tmpdw_header Where Id_Registro = @vFila)) = 0
            Begin
               Update #tmpdw_header
               Set ErrorFlag = 'S'
               Where Id_Registro = @vFila
               
               --Registrar el error
               Insert Into #tmpErroresDocumento
               (
                   Documento, Linea, Descripcion, CompaniaSocio
               )
               Select @w_texto, Id_Registro, 'La sucursal no es v�lida: ' + Sucursal, CompaniaSocio
               From #tmpdw_header
               Where Id_Registro = @vFila
               
               Set @w_errorFlag = 'S'
            End
         End
         
         --Validando Compa�ia
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And (Not CompaniaSocio Is Null Or RTrim(CompaniaSocio) <> '')) > 0
         Begin
            If (Select Count(*)
                From companyowner With (NoLock) 
                Where companyowner In (Select CompaniaSocio From #tmpdw_header Where Id_Registro = @vFila)) = 0
            Begin
               Update #tmpdw_header
               Set ErrorFlag = 'S'
               Where Id_Registro = @vFila
               
               --Registrar el error
               Insert Into #tmpErroresDocumento
               (
                   Documento, Linea, Descripcion, CompaniaSocio
               )
               Select @w_texto, Id_Registro, 'La compa��a no es v�lida: ' + CompaniaSocio, CompaniaSocio
               From #tmpdw_header
               Where Id_Registro = @vFila
               
               Set @w_errorFlag = 'S'
            End
         End

         --Validando el tipo de documento
         If (Select Count(*)
             From #tmpdw_header
             Where Id_Registro = @vFila And TipoDocumento In ('NC', 'ND')) > 0
         Begin
            If (Select Count(*)
                From #tmpdw_header 
                Where Id_Registro = @vFila And (NotaCreditoDocumento Is Null Or RTrim(NotaCreditoDocumento) = '')) > 0
            Begin
               Update #tmpdw_header
               Set ErrorFlag = 'S'
               Where Id_Registro = @vFila
              
               --Registrar el error
               Insert Into #tmpErroresDocumento
               (
                   Documento, Linea, Descripcion, CompaniaSocio
               )
               Select @w_texto, Id_Registro, 'Debe de ingresar el Doc Original para una Nota de Cr�dito', CompaniaSocio
               From #tmpdw_header
               Where Id_Registro = @vFila
               
               Set @w_errorFlag = 'S'
            End
            Else
            Begin
               --TODO: DOCUMENTO
               --If (Select Count(*)
               --    From AC_Sucursal 
               --    Where Sucursal In (Select Sucursal From #tmpdw_header Where Id_Registro = @vFila)) = 0
               --Begin
                  Update #tmpdw_header
                  Set ErrorFlag = 'S'
                  Where Id_Registro = @vFila
                  
                  --Registrar el error
                  Insert Into #tmpErroresDocumento
                  (
                      Documento, Linea, Descripcion, CompaniaSocio
                  )
                  Select @w_texto, Id_Registro, 'El Doc Original dela NC/ND no es v�lido: ' + IsNull(NotaCreditoDocumento, ''), CompaniaSocio
                  From #tmpdw_header
                  Where Id_Registro = @vFila
                  
                  Set @w_errorFlag = 'S'
               --End
            End
         End

         ---VALIDANDO EL DETALLE       

         --Extraemos la cantidad de registros
         Select @w_rows_detail = Count(*)
         From #tmpdw_detail a
         Inner Join #tmpdw_header b On a.CompaniaSocio = b.CompaniaSocio and a.TipoDocumento = b.TipoDocumento And a.NumeroInterno = b.NumeroInterno
         Where b.Id_Registro = @vFila
         
         --Verificamos si tiene detalle
         If (@w_rows_detail = 0)
         Begin
            Update #tmpdw_header
            Set ErrorFlag = 'S'
            Where Id_Registro = @vFila
            
            --Registrar el error
            Insert Into #tmpErroresDocumento
            (
                Documento, Linea, Descripcion, CompaniaSocio
            )
            Select @w_texto, Id_Registro, 'El documento no tiene detalle', CompaniaSocio
            From #tmpdw_header
            Where Id_Registro = @vFila
            
            Set @w_errorFlag = 'S'
         End
         Else
         Begin
            --Extraemos en un detalle resumen todo el detalle
            Insert Into #tmpdw_detailResumen
            (
               CompaniaSocio, TipoDocumento, NumeroInterno, secuencia, TipoDetalle, ItemCodigo, Descripcion, CantidadPedida, Estado, MontoOriginal,Monto
  )
            Select a.CompaniaSocio, a.TipoDocumento, a.NumeroInterno, a.secuencia, a.TipoDetalle, a.ItemCodigo, a.Descripcion, a.CantidadPedida, a.Estado, 
                   a.MontoOriginal, a.Monto
            From #tmpdw_detail a
            Inner Join #tmpdw_header b On a.CompaniaSocio = b.CompaniaSocio And  a.TipoDocumento = b.TipoDocumento And a.NumeroInterno = b.NumeroInterno
            Where b.Id_Registro = @vFila

            --Validar cada detalle del documento
            While (@m <= @w_rows_detail)
            Begin
               Set @w_codigo = ''
               
               Select @w_texto = 'Error Detalle: ' + a.CompaniaSocio + '-' + a.TipoDocumento + '-' + 
                                 Replicate('0', 8 - Len(Convert(Varchar(8), a.NumeroInterno))) + Convert(Varchar(8), a.NumeroInterno) + 
                                 ' - Linea ' + Convert(varchar(15), @m)
               From #tmpdw_header a
               Inner Join #tmpdw_detailResumen b On a.CompaniaSocio = b.CompaniaSocio And a.TipoDocumento = b.TipoDocumento And a.NumeroInterno = b.NumeroInterno
               Where a.Id_Registro = @vFila And b.Id_Registro = @m

               Select @w_codigo = ItemCodigo
               From #tmpdw_detailResumen
               Where Id_Registro = @m
               
               --Validar si el detalle es un servicio
               If (Select Count(*)
                   From #tmpdw_detailResumen
                   Where Id_Registro = @m And TipoDetalle = 'S') > 0
               Begin
                  If (@w_codigo = '')
                  Begin
                     Update #tmpdw_header
                     Set ErrorFlag = 'S'
                     Where Id_Registro = @vFila
                     
                     --Registrar el error
                     Insert Into #tmpErroresDocumento
                     (
                         Documento, Linea, Descripcion, CompaniaSocio
                     )
                     Select @w_texto, Id_Registro, 'Llenar el c�digo del servicio', CompaniaSocio
                     From #tmpdw_header
         Where Id_Registro = @vFila
                     
                    Set @w_errorFlag = 'S'
                  End
           Else
                  Begin
                     If (Select Count(*)  
                         From CO_ServicioClasificacion  With (NoLock)
                         Where (ServicioClasificacion = @w_codigo)) = 0 
                     Begin
                        Update #tmpdw_header
                        Set ErrorFlag = 'S'
                        Where Id_Registro = @vFila
                        
                   --Registrar el error
                        Insert Into #tmpErroresDocumento
                        (
                            Documento, Linea, Descripcion, CompaniaSocio
                        )
                        Select @w_texto, Id_Registro, 'El servicio no es valido: ' + @w_codigo, CompaniaSocio
                        From #tmpdw_header
                        Where Id_Registro = @vFila
                       
                        Set @w_errorFlag = 'S'
                     End
                  End
               End
               Else
               Begin
                  If (@w_codigo = '')
                  Begin
                     Update #tmpdw_header
                     Set ErrorFlag = 'S'
                     Where Id_Registro = @vFila
                     
                     --Registrar el error
                     Insert Into #tmpErroresDocumento
                     (
                         Documento, Linea, Descripcion, CompaniaSocio
                     )
                     Select @w_texto, Id_Registro, 'Llenar el c�digo del item', CompaniaSocio
                     From #tmpdw_header
                     Where Id_Registro = @vFila
                     
                     Set @w_errorFlag = 'S'
                  End
                  Else
                  Begin
                 --Validar CATALOGO
                     If (Select Count(*)
                         From WH_ItemMast With (NoLock)
                         Where Item = @w_codigo) = 0 
                     Begin
                        Update #tmpdw_header
                        Set ErrorFlag = 'S'
                        Where Id_Registro = @vFila

                        --Registrar el error
                        Insert Into #tmpErroresDocumento
                        (
                            Documento, Linea, Descripcion, CompaniaSocio
                        )
                        Select @w_texto, Id_Registro, 'El Item no es valido: ' + @w_codigo, CompaniaSocio
                        From #tmpdw_header
                        Where Id_Registro = @vFila

                        Set @w_errorFlag = 'S'
                     End
                  End
               End
  
               --Validar el monto original
               If (Select Count(*)
                   From #tmpdw_detailResumen
                   Where Id_Registro = @m And (MontoOriginal Is Null Or MontoOriginal = 0)) > 0
               Begin
                  Update #tmpdw_header
                  Set ErrorFlag = 'S'
                  Where Id_Registro = @vFila
                  
                  --Registrar el error
                  Insert Into #tmpErroresDocumento
                  (
                      Documento, Linea, Descripcion, CompaniaSocio
                  )
                  Select @w_texto, Id_Registro, 'No se ha indicado el Monto Original', CompaniaSocio
                  From #tmpdw_header
                  Where Id_Registro = @vFila
                  
                  Set @w_errorFlag = 'S'
               End
               
               --Validar el monto
               If (Select Count(*)
                   From #tmpdw_detailResumen
                   Where Id_Registro = @m And (Monto Is Null Or Monto = 0)) > 0
               Begin
                  --Registrar la advertencia
                  Insert Into #tmpErroresDocumento
            (
                      Documento, Linea, Descripcion, CompaniaSocio
                  )
                  Select 'Aviso: '+ @w_texto, Id_Registro, 'No ha indicado el monto a facturar', CompaniaSocio
                  From #tmpdw_header
                  Where Id_Registro = @vFila
               End
               
               Set @m = @m + 1
            End
         End
        
         Truncate Table #tmpdw_detailResumen
         Set @vFila = @vFila + 1
      End
      
      --Se verifica si existen registros sin errores
      If (Select Count(*)
          From #tmpdw_header
          Where ErrorFlag = 'N') > 0 
      Begin
         --Se procede al proceso de importaci�n
         Declare @w_nuevo int, @w_rows_header int
         Declare @w_cobranza int, @w_clienteINT int, @w_linea int, @w_line int, @k int, @w_total_registros int
         Declare @w_vouingcash varchar(20), @w_proceso varchar(6), @w_igvcode varchar(20), @w_afectodescuentoflag varchar
         Declare @w_cobstatap varchar(20), @w_docforfact varchar, @w_moneda varchar, @w_almacen varchar, @w_comentario varchar, @w_docconcept varchar(20), @w_docforpag varchar(20), @w_itemcodigo varchar(20), @w_proyecto varchar
         Declare @w_signo int
         Declare @w_descuento varchar, @w_documentoreferencia varchar, @w_unidadnegocio varchar, @w_tipodocumento varchar(2), @w_serie varchar
         Declare @w_preciounitario decimal, @w_monto decimal, @w_descuentoporcentaje decimal, @w_monto2 decimal, @w_codigoantven decimal
         Declare @w_tipodecambio decimal
         Declare @w_today datetime,	@w_fechacobranza datetime
         Declare @w_tiposerie varchar(20)
         Declare @w_numero int, @w_found int, @p int, @w_array_no int, @w_vendedornumero int
         Declare @w_centrocosto varchar, @w_flujodecaja varchar, @w_descripcion varchar,@w_codigoant varchar, @w_tipo varchar
         Declare @w_Number int
         Declare @w_NumeroDocumento varchar(20), @w_work varchar(20)
         Declare @vNumeroDocumentoGen varchar(20)
         Declare @vEstado char(2)
         Declare @vAprobadorPor int
         Declare @vFechaAprobacion datetime
         Declare @vMontoPagado money
         Declare @vMontoOriginal money
         Declare @vCentroCosto varchar(10)
         Declare @vProyecto varchar(15)
         Declare @vFlujodeCaja varchar(4)
         Declare @vDescripcionLocal varchar(100)
         Declare @vNumeroInterno int
         
         Create Table #wa_tipodocumento
         (
            Id_Registro int identity(1,1),
            Valor varchar(20) Collate DataBase_Default
         )
         
         Create Table #wa_numero
         (
            Id_Registro int identity(1,1),
            Valor int
         )
         
         Set @w_rows_detail = 0
         Set @w_clientenumero = Null
         Set @w_p61dctodat = Null
         Set @w_Number = Null
         Set @w_total_registros = 0
       
         --Se extrae los valores de los parametros
         Select @w_vouingcash = Texto
         From ParametrosMast With (NoLock)
         Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
               ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
               ( ParametrosMast.ParametroClave ='VOUINGCASH' ) 
         
         Select @w_igvcode = Texto
         From ParametrosMast With (NoLock)
         Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
               ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
               ( ParametrosMast.ParametroClave ='IGVCODE' ) 
         
         Select @w_cobstatap = Texto
         From ParametrosMast With (NoLock)
         Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
               ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
               ( ParametrosMast.ParametroClave ='COBSTATAP' ) 
         
         Select @w_docconcept = Texto
        From ParametrosMast With (NoLock)
         Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
               ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
               ( ParametrosMast.ParametroClave ='DOCCONCEPT' ) 
         
         Select @w_docforpag = Texto
         From ParametrosMast With (NoLock)
         Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
               ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
               ( ParametrosMast.ParametroClave ='DOCFORPAGO' ) 

         Select @w_p61dctodat = ParametrosMast.Fecha 
         From ParametrosMast With (NoLock)
         Where ( ParametrosMast.CompaniaCodigo ='999999' ) AND 
               ( ParametrosMast.AplicacionCodigo ='CO' ) AND 
               ( ParametrosMast.ParametroClave ='P61DCTODAT' ) 
         
         Set @w_today = GetDate()    
         
         ----Determina el numero para el grupo Batch del proceso
         --Select @w_number = CorrelativoNumero
         --From CorrelativosMast
         --Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND 
         --      ( CorrelativosMast.TipoComprobante = 'SY' ) AND 
         --      ( CorrelativosMast.Serie = 'COFB' ) 

         --Update CorrelativosMast 
         --Set CorrelativoNumero = @w_number,
         --    UltimoUsuario = 'MISESF',
         --    UltimaFechaModif = GetDate()
         --Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND 
         --      ( CorrelativosMast.TipoComprobante = 'SY' ) AND 
         --      ( CorrelativosMast.Serie = 'COFB')
               
         --Set @w_proceso = Replicate('0', 6 - Len(Convert(Varchar(6), @w_number))) + Convert(Varchar(6), @w_number)

         Set @vFila = 1
         Set @vNumeroInterno = Null
         Set @w_array_no = 0

         Truncate Table #tmpdw_detailResumen

         --Validar que los datos consultados no presenten inconsistencias
         While (@vFila <= @vFilasConsultadas)
         Begin
            Set @w_cliente = ''

            --Obtenemos la serie
            Select @w_serie = Serie,
                   @vNumeroInterno = NumeroInterno,
                   @vCondicionMatricula = CondicionMatricula,
                   @vTipoFacturacion = TipoFacturacion,
				   @w_CompaniaSocio = CompaniaSocio,
                   @w_cliente = Cliente
            From #tmpdw_header
            Where Id_Registro = @vFila

            --Verifica si el registro no tiene errores
            If (Select Count(*)
                From #tmpdw_header
                Where Id_Registro = @vFila And ErrorFlag = 'N') > 0 And
               (Select COUNT(*)
                From CO_Interfase_P09_Header With (NoLock)    
                Where Cliente = @w_cliente And Estado = 'GE') > 0
            Begin
               Set @w_NumeroDocumento = ''
               Set @w_work = ''
               Set @vNumeroDocumentoGen = ''
               Set @vEstado = ''
               Set @vAprobadorPor = Null
               Set @vFechaAprobacion = Null
               Set @vMontoPagado = 0.00
               Set @vMontoOriginal = 0.00
               Set @vCentroCosto  = ''
               Set @vProyecto = ''
               Set @w_rows_detail = 0
               Set @w_itemcodigo = ''
               Set @m = 1
               Set @vFlujodeCaja = ''
               Set @vDescripcionLocal = ''
               Set @vFagDosPedidos = 0
               --Set @vCondicionMatricula = ''	--@9
               --Set @vTipoFacturacion = ''		--@9
                              
               --Obtenemos el signo
               If (Select Count(*)
                   From #tmpdw_header
                   Where Id_Registro = @vFila And Clasificacion = 'DP') > 0
                  Set @w_signo = -1
               Else
                  Set @w_signo = 1
               
               --Obtenemos el tipo de documento
               If (Select Count(*)
         From #tmpdw_header
                   Where Id_Registro = @vFila And FlagActualizacion = 'N') > 0
                  Set @w_TipoDocumento = 'PE'
               Else
               Begin
                  Select @w_TipoDocumento = TipoDocumento
                  From #tmpdw_header
                  Where Id_Registro = @vFila And Clasificacion = 'DP'
               End      
               
               --Obtenemos el tipo de serie
               If (@w_TipoDocumento = 'PE')
                  Set @w_TipoSerie = @w_TipoDocumento
               Else
                  Set @w_TipoSerie = @w_TipoDocumento + @w_serie
                  
               --Determina el numero para el grupo Batch del proceso
				 Select @w_number = CorrelativoNumero
				 From CorrelativosMast 
				 Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND 
					   ( CorrelativosMast.TipoComprobante = 'SY' ) AND 
					   ( CorrelativosMast.Serie = 'COFB' ) 

				 Update CorrelativosMast 
				 Set CorrelativoNumero = @w_number,
					 UltimoUsuario = 'MISESF',
					 UltimaFechaModif = GetDate()
				 Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND 
					   ( CorrelativosMast.TipoComprobante = 'SY' ) AND 
					   ( CorrelativosMast.Serie = 'COFB')
               
				 Set @w_proceso = Replicate('0', 6 - Len(Convert(Varchar(6), @w_number))) + Convert(Varchar(6), @w_number)

               Set @w_found = 0
               
               If (@w_found = 0)
               Begin
                  Set @w_array_no = @w_array_no + 1
                  Set @w_found = @w_array_no
                  
                  Insert Into #wa_tipodocumento
                  (
                   Valor
                  )
                  Select @w_TipoSerie
                  
                  If (@w_TipoDocumento = 'PE')
                  Begin
                     Declare @vFechaActual datetime
                     
                     Set @vFechaActual = GetDate()
                     
                     Update CorrelativosMast 
                     SET CorrelativoNumero = CorrelativoNumero + 1, 
                         UltimoUsuario = 'MISESF' , 
                         UltimaFechaModif = @vFechaActual
                     Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND 
                        ( CorrelativosMast.TipoComprobante ='SY' ) AND 
                           ( CorrelativosMast.Serie ='COPE' ) 
                           
                     Select @w_numero = CorrelativoNumero - 1
                     From CorrelativosMast With (NoLock)
                     Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND 
                           ( CorrelativosMast.TipoComprobante ='SY' ) AND 
                           ( CorrelativosMast.Serie ='COPE' ) And
                           UltimaFechaModif = @vFechaActual
                                          
                     Set @w_NumeroDocumento = Replicate('0', 10 - Len(Convert(varchar(10), @w_numero))) + Convert(varchar(10), @w_numero)
                     
            --         Select @w_work = max(CO_Documento.NumeroDocumento ) 
            --         From CO_Documento With (NoLock)
            --         Where ( CO_Documento.CompaniaSocio = @w_CompaniaSocio ) AND 
					       --( CO_Documento.NumeroDocumento NOT LIKE "I%") AND
					       --( CO_Documento.TipoDocumento ='PE' ) 
                
            --         If (@w_work <> @w_NumeroDocumento)
            --         Begin
            --            Declare @vMensajeImp varchar(150)
                        
            --            Set @vMensajeImp = 'El correlativo COPE esta errado. El �ltimo correlativo es ' + @w_work + ' Cia:'+@w_CompaniaSocio
                                                
            --            Insert Into #tmpErroresDocumento
            --   (
           --                Documento, Linea, Descripcion
         --            )
            --            Select 'IMPORTACION', Id_Registro, @vMensajeImp
            --            From #tmpdw_header
            --            Where Id_Registro = @vFila
                        
            --            RaisError(@vMensajeImp, 16, 1)
            --         End
                  End
                  Else
                  Begin
                     Declare @vFechaActual2 datetime
                     
                     Set @vFechaActual2 = GetDate()
                     
                     Update CorrelativosMast 
                     SET CorrelativoNumero = CorrelativoNumero + 1, 
                         UltimoUsuario = 'MISESF' , 
                         UltimaFechaModif = @vFechaActual2
                     Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND 
                           ( CorrelativosMast.TipoComprobante =@w_TipoDocumento ) AND 
                           ( CorrelativosMast.Serie =@w_serie ) 
                     
                     Select @w_numero = CorrelativoNumero
                     From CorrelativosMast With (NoLock)
                     Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND 
                           ( CorrelativosMast.TipoComprobante = @w_TipoDocumento ) AND 
                           ( CorrelativosMast.Serie = @w_serie) And
                           UltimaFechaModif = @vFechaActual2                                          
                  End                     
                  
                  Insert Into #wa_numero
                  (
                     Valor
                  )
                  Select @w_numero
                  
                  Update #wa_numero
                  Set Valor = Valor + 1
                  Where Id_Registro = @w_found
               End

               --CREACION DE UN DOCUMENTO CON SU DETALLE
               Set @w_total_registros = @w_total_registros + 1
               
               If (@w_TipoDocumento = 'PE')
               Begin
                  Select @vNumeroDocumentoGen = Replicate('0', 10 - Len(Convert(Varchar(10), Valor))) + Convert(Varchar(10), Valor)
                  From #wa_numero 
                  Where Id_Registro = @w_found
                  
                  Set @vEstado = 'AP'
                  Set @vAprobadorPor = 0
                  Set @vFechaAprobacion = GetDate()
               End
               Else
               Begin
                  Select @vNumeroDocumentoGen = @w_serie + '-' + Replicate('0', 10 - Len(Convert(Varchar(10), Valor))) + Convert(Varchar(10), Valor)
                  From #wa_numero 
                  Where Id_Registro = @w_found
                  
                  Set @vEstado = 'PR'               
               End
               
               Truncate Table #tmpdw_detailResumen
                             
               --Extraemos en un detalle resumen todo el detalle
               Insert Into #tmpdw_detailResumen
               (
                  CompaniaSocio, TipoDocumento, NumeroInterno, secuencia, TipoDetalle, ItemCodigo, Descripcion, CantidadPedida, Estado, MontoOriginal,Monto
               )
               Select a.CompaniaSocio, a.TipoDocumento, a.NumeroInterno, a.secuencia, a.TipoDetalle, a.ItemCodigo, a.Descripcion, a.CantidadPedida, a.Estado, 
                      a.MontoOriginal, a.Monto
               From #tmpdw_detail a
               Inner Join #tmpdw_header b On a.CompaniaSocio = b.CompaniaSocio And a.TipoDocumento = b.TipoDocumento And a.NumeroInterno = b.NumeroInterno
               Where b.Id_Registro = @vFila
               
               Set @w_rows_detail = @@RowCount
               
               --Sacamos los totales               
               Select @vMontoPagado = Sum(Monto), @vMontoOriginal = Sum(MontoOriginal)
               From #tmpdw_detailResumen

   --Extraemos el centro de costo y proyecto
               Select @w_itemcodigo = ItemCodigo
               From #tmpdw_detailResumen
               Where Id_Registro = @w_rows_detail

               Select @vCentroCosto = CentroCosto, 
                      @vProyecto = Proyecto 
               From CO_ServicioClasificacion With (NoLock)
               Where ServicioClasificacion = @w_itemcodigo
               
               If (@w_TipoDocumento = 'PE' And LTrim(RTrim(@vCondicionMatricula)) = 'S' And @vTipoFacturacion = 'MAT')
                  Set @vFagDosPedidos = 1

               --Volvemos a consultar el Grupo de Descuento
               Select @vGrupoDescuento = GrupoDescuento
               From CO_Interfase_P09_Header With (NoLock)
               Where NumeroInterno In (Select NumeroInterno
                                       From #tmpdw_header                   
                                       Where Id_Registro = @vFila)
                  
               --Actualiamos el Grupo de Desuento en la temporal
               Update #tmpdw_header
               Set GrupoDescuento = @vGrupoDescuento
               Where Id_Registro = @vFila

               If (@vFagDosPedidos = 0)
               Begin
                  --Insertamos un nuevo documento
                  Insert Into CO_Documento
                  (
                     CompaniaSocio, TipoDocumento, LetraAvalRUC, NumeroDocumento, NumeroInterno, EstablecimientoCodigo, FechaDocumento, ComercialPedidoFechaRequerida, 
                     FechaVencimiento, TipoVenta, TipoFacturacion, ConceptoFacturacion, ClienteNumero, ClienteNombre, ClienteRUC, ClienteCobrarA, ClienteDireccion,
                     Sucursal, UnidadNegocio, TipodeCambio, MonedaDocumento, Vendedor, MontoAfecto, MontoNoAfecto, MontoImpuestoVentas, MontoDescuentos, MontoRedondeo,
                     MontoTotal, MontoAdelantoSaldo, MontoImpuestos, MontoPagado, Interfase_MontoOriginal, Estado, AprobadoPor, FechaAprobacion, Interfase_Matricula, 
                     Interfase_Campana, Interfase_Periodo, Interfase_Cuota, Interfase_Area, Interfase_CondicionMatricula, Interfase_Descuento, VoucherPeriodo, 
                     ContabilizacionPendienteFlag, ImpresionPendienteFlag, DocumentoMoraFlag, ComentariosImprimirFlag, LetraCarteraFlag, APTransferidoFlag,  TipoCanjeFactura, 
                     CobranzaDudosaEstado, LetraDescuentoVoucherFlag, FormaFacturacion, FormadePago, PreparadoPor, UltimoUsuario, UltimaFechaModif, FechaPreparacion, 
                     LetraDescuentoIntereses, ComentariosMonto, UnidadReplicacion, AlmacenCodigo, ProcesoImportacion, ProcesoImportacionFecha, ReprogramacionPuntoPartida, 
                     NotaCreditoDocumento, ReprogramacionMotivo, CentroCosto, Proyecto, Interfase_grupodescuento, GrupoTipo, Interfase_Captacion
                  )
                  Select @w_CompaniaSocio, @w_TipoDocumento, TipoDocumento, @vNumeroDocumentoGen, Replicate('0', 10 - Len(Convert(varchar(10), NumeroInterno))) + Convert(varchar(10), NumeroInterno),
                         EstablecimientoCodigo, GetDate(), GetDate(), FechaVencimiento, TipoVenta, TipoFacturacion, @w_docconcept, ClienteNumero, ClienteNombre, ClienteRUC,
                         ClienteCobrarA, ClienteDireccion, Sucursal, Sucursal, @w_factorventa, MonedaCodigo, Vendedor, 0.00, @vMontoPagado, 0.00, 0.00, 0.00, @vMontoPagado, 0.00, 0.00, 
                         0.00, @vMontoOriginal, @vEstado, @vAprobadorPor, @vFechaAprobacion, IdMatricula, Campania, Periodo, CuotaNumero, Area, CondicionMatricula, Descuento, 
                         Convert(varchar(6), GetDate(), 112), 'S', 'S', 'N', 'N', 'S', 'N', 'NO', 'NO', 'N', 'F', @w_docforpag, 0, 'MISESF', GetDate(), GetDate(),
                         0.00, 0.00, 'LIMA', 'LIMA', @w_proceso, GetDate(), Criteria, NotaCreditoDocumento, Convert(Varchar(50), Descuento), @vCentroCosto, @vProyecto,
                         Grupodescuento, GrupoTipo, Captacion
                  From #tmpdw_header 
                  Where Id_Registro = @vFila
               
                  Set @m = 1
                  --Generamos el detalle del documento
                  While (@m <= @w_rows_detail)
                  Begin
                     Select @vCentroCosto = CentroCosto, 
                            @vFlujodeCaja = Flujodecaja, 
                            @vDescripcionLocal = DescripcionLocal, 
                            @vProyecto = Proyecto 
                     From CO_ServicioClasificacion With (NoLock)
                     Where ServicioClasificacion In (Select ItemCodigo
                     From #tmpdw_detailResumen
                                                     Where Id_Registro = @m) 
                  
                     --Insertamos un nuevo detalle
                     Insert Into CO_DocumentoDetalle
                     (
                        CompaniaSocio, TipoDocumento, NumeroDocumento, Linea, TipoDetalle, ItemCodigo, Condicion, Lote, Descripcion, UnidadCodigo, PrecioUnitario, 
                        PrecioUnitarioOriginal, Interfase_MontoOriginal, CantidadPedida, Monto, CantidadPedidaDoble, PrecioUnitarioFinal, MontoFinal, ImprimirPUFlag, 
                        CantidadEntregada, CantidadEntregadaDoble, IGVExoneradoFlag,  DespachoUnidadEquivalenteFlag, AlmacenCodigo, Estado, UltimoUsuario, UltimaFechaModif, 
                        TransferenciaGratuitaFlag, PrecioUnitarioGratuito, FlujodeCaja, Proyecto, CentroCosto
                     )
                     Select @w_CompaniaSocio, @w_TipoDocumento, @vNumeroDocumentoGen, @m, b.TipoDetalle, b.ItemCodigo, '0', '00', @vDescripcionLocal, 'UNI', b.Monto, b.Monto, 
                            b.MontoOriginal, b.CantidadPedida * @w_Signo, (b.CantidadPedida * @w_Signo) * b.Monto, 0.00, 0.00, 0.00, 'S', 0.00, 0.00, 'S', 'N', 'LIMA', 'PR', 
                            'MISESF', GetDate(), 'N', 0.0000, @vFlujodeCaja, @vProyecto, @vCentroCosto
                     From #tmpdw_header a
                     Inner Join #tmpdw_detailResumen b On a.TipoDocumento = b.TipoDocumento And a.NumeroInterno = b.NumeroInterno
                     Where a.Id_Registro = @vFila And b.Id_Registro = @m
                     
                     Set @m = @m + 1
                  End
                  
                  --Actualizamos la tabla cabecera de la interfaz
                  If (@w_TipoDocumento = 'PE')               
                     Update CO_Interfase_P09_Header 
                     SET Estado = 'PF', 
                         NumeroDocumento = @w_TipoDocumento + '-' +  @vNumeroDocumentoGen,
                         FechaProcesoImp = GetDate()
                     Where NumeroInterno = @vNumeroInterno 
                  Else
                     Update CO_Interfase_P09_Header 
                     SET Estado = 'PR', 
                         NumeroDocumento = @w_TipoDocumento + '-' +  @vNumeroDocumentoGen,
                         FechaProcesoImp = GetDate()
                     Where NumeroInterno = @vNumeroInterno 
               End
               Else
               Begin
					
					DECLARE @vPorcentajePagoAdelantado money
					
					Select @vSeparacion=Disponible1 From MaestroTablaRegistro With (NoLock) where Codigo='SeparacionVacante' and CompaniaSocio=@w_CompaniaSocio	--@8
					SET @vPorcentajePagoAdelantado=isnull(@vSeparacion,0.3) --@8
					--@1
					DECLARE @vMontoInicio money = 0.00,@vMontoFin money = 0.00 , @vMontoOriginalInicio money=0.00, @vMontoOriginalFin money=0.00

					SET @vMontoInicio = ROUND(@vMontoPagado * @vPorcentajePagoAdelantado,0)		--@8

					SET @vMontoFin = @vMontoPagado - @vMontoInicio
					SET @vMontoOriginalInicio = ROUND(@vMontoOriginal * @vPorcentajePagoAdelantado,0)
					SET @vMontoOriginalFin = @vMontoOriginal - @vMontoOriginalInicio
					--@1
					
					--@3
					DECLARE @vMontoDetalleInicio money,@vMontoOriginalDetalleInicio money, @vAcumuladoDetalleInicio money = 0.00 ,@vAcumuladoOriginalDetalleInicio money = 0.00 
					DECLARE @vMontoDetalleFin money,@vMontoOriginalDetalleFin money, @vAcumuladoDetalleFin  money = 0.00 ,@vAcumuladoOriginalDetalleFin money  = 0.00
					--@3

          --Se inserta dos pedidos
                  --Insertamos un nuevo documento
                  Insert Into CO_Documento
                  (
                     CompaniaSocio, TipoDocumento, LetraAvalRUC, NumeroDocumento, NumeroInterno, EstablecimientoCodigo, FechaDocumento, ComercialPedidoFechaRequerida, 
                     FechaVencimiento, TipoVenta, TipoFacturacion, ConceptoFacturacion, ClienteNumero, ClienteNombre, ClienteRUC, ClienteCobrarA, ClienteDireccion,
                     Sucursal, UnidadNegocio, TipodeCambio, MonedaDocumento, Vendedor, MontoAfecto, MontoNoAfecto, MontoImpuestoVentas, MontoDescuentos, MontoRedondeo,
                     MontoTotal, MontoAdelantoSaldo, MontoImpuestos, MontoPagado, Interfase_MontoOriginal, Estado, AprobadoPor, FechaAprobacion, Interfase_Matricula, 
                     Interfase_Campana, Interfase_Periodo, Interfase_Cuota, Interfase_Area, Interfase_CondicionMatricula, Interfase_Descuento, VoucherPeriodo, 
                     ContabilizacionPendienteFlag, ImpresionPendienteFlag, DocumentoMoraFlag, ComentariosImprimirFlag, LetraCarteraFlag, APTransferidoFlag,  TipoCanjeFactura, 
                     CobranzaDudosaEstado, LetraDescuentoVoucherFlag, FormaFacturacion, FormadePago, PreparadoPor, UltimoUsuario, UltimaFechaModif, FechaPreparacion, 
                     LetraDescuentoIntereses, ComentariosMonto, UnidadReplicacion, AlmacenCodigo, ProcesoImportacion, ProcesoImportacionFecha, ReprogramacionPuntoPartida, 
                     NotaCreditoDocumento, ReprogramacionMotivo, CentroCosto, Proyecto, Interfase_grupodescuento, GrupoTipo, Interfase_Captacion
                  )
                  Select @w_CompaniaSocio, @w_TipoDocumento, TipoDocumento, @vNumeroDocumentoGen, Replicate('0', 10 - Len(Convert(varchar(10), NumeroInterno))) + Convert(varchar(10), NumeroInterno),
                         EstablecimientoCodigo, GetDate(), GetDate(), FechaVencimiento,--CONVERT(DATETIME,'20201116'), --@2	--@10
						 TipoVenta, TipoFacturacion, @w_docconcept, ClienteNumero, ClienteNombre, ClienteRUC,
                         ClienteCobrarA, ClienteDireccion, Sucursal, Sucursal, @w_factorventa, MonedaCodigo, Vendedor, 0.00, 
                         @vMontoInicio,	--Case When @vMontoPagado % 2 = 1 Then Round(@vMontoPagado / 2 - 0.6, 0) Else Round(@vMontoPagado / 2, 0) End, --@1
                         0.00, 0.00, 0.00, 
                         @vMontoInicio,	--Case When @vMontoPagado % 2 = 1 Then Round(@vMontoPagado / 2 - 0.6, 0) Else Round(@vMontoPagado / 2, 0) End, --@1
                         0.00, 0.00, 0.00, 
                         @vMontoOriginalInicio,	--Case When @vMontoOriginal % 2 = 1 Then Round(@vMontoOriginal / 2 - 0.6, 0) Else Round(@vMontoOriginal / 2, 0) End, --@1
                         @vEstado, @vAprobadorPor, @vFechaAprobacion, IdMatricula, Campania, Periodo, CuotaNumero, Area, CondicionMatricula, Descuento, 
                         Convert(varchar(6), GetDate(), 112), 'S', 'S', 'N', 'N', 'S', 'N', 'NO', 'NO', 'N', 'F', @w_docforpag, 0, 'MISESF', GetDate(), GetDate(),
                         0.00, 0.00, 'LIMA', 'LIMA', @w_proceso, GetDate(), Criteria, NotaCreditoDocumento, Convert(Varchar(50), Descuento), @vCentroCosto, @vProyecto,
                         Grupodescuento, GrupoTipo, Captacion
                  From #tmpdw_header 
                  Where Id_Registro = @vFila
               
                  Set @m = 1
                  --Generamos el detalle del documento
                  While (@m <= @w_rows_detail)
                  Begin

                     Select @vCentroCosto = CentroCosto, 
                            @vFlujodeCaja = Flujodecaja, 
                            @vDescripcionLocal = 'RESERVA - ' + IsNull(DescripcionLocal, ''), --@1
                            @vProyecto = Proyecto 
                     From CO_ServicioClasificacion With (NoLock)
                     Where ServicioClasificacion In (Select ItemCodigo
                                                     From #tmpdw_detailResumen
                                                     Where Id_Registro = @m) 

					--@3									
					IF @m = @w_rows_detail
					BEGIN
						SET @vMontoDetalleInicio = 0 
						SET @vMontoDetalleInicio = 	ROUND(@vMontoInicio - @vAcumuladoDetalleInicio,0)

						SET @vMontoOriginalDetalleInicio = 0 
						SET @vMontoOriginalDetalleInicio = 	ROUND(@vMontoOriginalInicio - @vAcumuladoOriginalDetalleInicio,0)
					END
					ELSE
					BEGIN
						SET @vMontoDetalleInicio = 0
						SET @vMontoDetalleInicio = ROUND(@vMontoInicio /  @w_rows_detail,0)
						SET @vAcumuladoDetalleInicio = @vAcumuladoDetalleInicio + @vMontoDetalleInicio

						SET @vMontoOriginalDetalleInicio = 0 
						SET @vMontoOriginalDetalleInicio = ROUND(@vMontoOriginalInicio/@w_rows_detail,0)
						SET @vAcumuladoOriginalDetalleInicio = @vAcumuladoOriginalDetalleInicio + @vMontoOriginalDetalleInicio
					END 
                    --@3

                     --Insertamos un nuevo detalle
                     Insert Into CO_DocumentoDetalle
                     (
                        CompaniaSocio, TipoDocumento, NumeroDocumento, Linea, TipoDetalle, ItemCodigo, Condicion, Lote, Descripcion, UnidadCodigo, PrecioUnitario, 
                        PrecioUnitarioOriginal, Interfase_MontoOriginal, CantidadPedida, Monto, CantidadPedidaDoble, PrecioUnitarioFinal, MontoFinal, ImprimirPUFlag, 
                        CantidadEntregada, CantidadEntregadaDoble, IGVExoneradoFlag,  DespachoUnidadEquivalenteFlag, AlmacenCodigo, Estado, UltimoUsuario, UltimaFechaModif, 
                        TransferenciaGratuitaFlag, PrecioUnitarioGratuito, FlujodeCaja, Proyecto, CentroCosto
                     )
                     Select @w_CompaniaSocio, @w_TipoDocumento, @vNumeroDocumentoGen, @m, b.TipoDetalle, b.ItemCodigo, '0', '00', @vDescripcionLocal, 'UNI', 
                            @vMontoDetalleInicio,	--Case When b.Monto % 2 = 1 Then Round(b.Monto / 2 - 0.6, 0) Else Round(b.Monto / 2, 0) End,--@1
                            @vMontoDetalleInicio,	--Case When b.Monto % 2 = 1 Then Round(b.Monto / 2 - 0.6, 0) Else Round(b.Monto / 2, 0) End,--@1
                            @vMontoOriginalDetalleInicio,	--Case When b.MontoOriginal % 2 = 1 Then Round(b.MontoOriginal / 2 - 0.6, 0) Else Round(b.MontoOriginal / 2, 0) End,--@1
                            b.CantidadPedida * @w_Signo, 
                            (b.CantidadPedida * @w_Signo) *  @vMontoDetalleInicio,	--(Case When b.Monto % 2 = 1 Then Round(b.Monto / 2 - 0.6, 0) Else Round(b.Monto / 2, 0) End), --@1
                            0.00, 0.00, 0.00, 'S', 0.00, 0.00, 'S', 'N', 'LIMA', 'PR', 
                            'MISESF', GetDate(), 'N', 0.0000, @vFlujodeCaja, @vProyecto, @vCentroCosto
                     From #tmpdw_header a
                     Inner Join #tmpdw_detailResumen b On a.TipoDocumento = b.TipoDocumento And a.NumeroInterno = b.NumeroInterno
                     Where a.Id_Registro = @vFila And b.Id_Registro = @m
                     
                     Set @m = @m + 1
                  End

                  
                  Select @w_numero = CorrelativoNumero  
                  From CorrelativosMast With (NoLock)
                  Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND   
                        ( CorrelativosMast.TipoComprobante ='SY' ) AND   
                        ( CorrelativosMast.Serie = 'COPE' )   
                    
                  Update CorrelativosMast   
						SET CorrelativoNumero = @w_numero + 1, 
                      UltimoUsuario = 'MISESF' ,   
                      UltimaFechaModif = GetDate()  
                  Where ( CorrelativosMast.CompaniaCodigo = Left(@w_CompaniaSocio, 6) ) AND   
                        ( CorrelativosMast.TipoComprobante ='SY' ) AND   
           ( CorrelativosMast.Serie = 'COPE' )   
                                                   
                  Set @vNumeroDocumentoGen = Replicate('0', 10 - Len(Convert(varchar(10), @w_numero + 1))) + Convert(varchar(10), @w_numero + 1)
                  

                  Insert Into CO_Documento
                  (
                     CompaniaSocio, TipoDocumento, LetraAvalRUC, NumeroDocumento, NumeroInterno, EstablecimientoCodigo, FechaDocumento, ComercialPedidoFechaRequerida, 
                     FechaVencimiento, TipoVenta, TipoFacturacion, ConceptoFacturacion, ClienteNumero, ClienteNombre, ClienteRUC, ClienteCobrarA, ClienteDireccion,
                     Sucursal, UnidadNegocio, TipodeCambio, MonedaDocumento, Vendedor, MontoAfecto, MontoNoAfecto, MontoImpuestoVentas, MontoDescuentos, MontoRedondeo,
                     MontoTotal, MontoAdelantoSaldo, MontoImpuestos, MontoPagado, Interfase_MontoOriginal, Estado, AprobadoPor, FechaAprobacion, Interfase_Matricula, 
                     Interfase_Campana, Interfase_Periodo, Interfase_Cuota, Interfase_Area, Interfase_CondicionMatricula, Interfase_Descuento, VoucherPeriodo, 
                     ContabilizacionPendienteFlag, ImpresionPendienteFlag, DocumentoMoraFlag, ComentariosImprimirFlag, LetraCarteraFlag, APTransferidoFlag,  TipoCanjeFactura, 
                     CobranzaDudosaEstado, LetraDescuentoVoucherFlag, FormaFacturacion, FormadePago, PreparadoPor, UltimoUsuario, UltimaFechaModif, FechaPreparacion, 
                     LetraDescuentoIntereses, ComentariosMonto, UnidadReplicacion, AlmacenCodigo, ProcesoImportacion, ProcesoImportacionFecha, ReprogramacionPuntoPartida, 
                     NotaCreditoDocumento, ReprogramacionMotivo, CentroCosto, Proyecto, Interfase_grupodescuento, GrupoTipo, Interfase_Captacion
                  )
                  Select @w_CompaniaSocio, @w_TipoDocumento, TipoDocumento, @vNumeroDocumentoGen, Replicate('0', 10 - Len(Convert(varchar(10), NumeroInterno))) + Convert(varchar(10), NumeroInterno),
                         EstablecimientoCodigo, GetDate(), GetDate(), DateAdd(Day, 1, FechaVencimiento), --CONVERT(DATETIME,'20201117'), -- @10
						 TipoVenta, TipoFacturacion, @w_docconcept, ClienteNumero, ClienteNombre, ClienteRUC,
                         ClienteCobrarA, ClienteDireccion, Sucursal, Sucursal, @w_factorventa, MonedaCodigo, Vendedor, 0.00, 
                         @vMontoFin,	--Case When @vMontoPagado % 2 = 1 Then Round(@vMontoPagado / 2 + 0.5, 0) Else Round(@vMontoPagado / 2, 0) End, --@1
                         0.00, 0.00, 0.00, 
                         @vMontoFin,	--Case When @vMontoPagado % 2 = 1 Then Round(@vMontoPagado / 2 + 0.5, 0) Else Round(@vMontoPagado / 2, 0) End, --@1
                         0.00, 0.00, 0.00, 
                         @vMontoOriginalFin,	--Case When @vMontoOriginal % 2 = 1 Then Round(@vMontoOriginal / 2 + 0.5, 0) Else Round(@vMontoOriginal / 2, 0) End,--@1
                         @vEstado, @vAprobadorPor, @vFechaAprobacion, IdMatricula, Campania, Periodo, CuotaNumero, Area, CondicionMatricula, Descuento, 
                         Convert(varchar(6), GetDate(), 112), 'S', 'S', 'N', 'N', 'S', 'N', 'NO', 'NO', 'N', 'F', @w_docforpag, 0, 'MISESF', GetDate(), GetDate(),
                         0.00, 0.00, 'LIMA', 'LIMA', @w_proceso, GetDate(), Criteria, NotaCreditoDocumento, Convert(Varchar(50), Descuento), @vCentroCosto, @vProyecto,
                         Grupodescuento, GrupoTipo, Captacion
                  From #tmpdw_header 
                  Where Id_Registro = @vFila
               
                  Set @m = 1
       --Generamos el detalle del documento
                  While (@m <= @w_rows_detail)
                  Begin
                     Select @vCentroCosto = CentroCosto, 
                            @vFlujodeCaja = Flujodecaja, 
                            @vDescripcionLocal = IsNull(DescripcionLocal, ''), --@1
                            @vProyecto = Proyecto 
                     From CO_ServicioClasificacion With (NoLock)
                     Where ServicioClasificacion In (Select ItemCodigo
                                                     From #tmpdw_detailResumen
                                                     Where Id_Registro = @m) 
                  
				    --@3
				  	IF @m = @w_rows_detail
					BEGIN
						SET @vMontoDetalleFin = 0 
						SET @vMontoDetalleFin = 	ROUND(@vMontoFin - @vAcumuladoDetalleFin,0)

						SET @vMontoOriginalDetalleFin = 0 
						SET @vMontoOriginalDetalleFin = 	ROUND(@vMontoOriginalFin - @vAcumuladoOriginalDetalleFin,0)
					END
					ELSE
					BEGIN
						SET @vMontoDetalleFin = 0
						SET @vMontoDetalleFin = ROUND(@vMontoFin /  @w_rows_detail,0)
						SET @vAcumuladoDetalleFin = @vAcumuladoDetalleFin + @vMontoDetalleFin

						SET @vMontoOriginalDetalleFin = 0 
						SET @vMontoOriginalDetalleFin = ROUND(@vMontoOriginalFin /  @w_rows_detail,0)
						SET @vAcumuladoOriginalDetalleFin = @vAcumuladoOriginalDetalleFin + @vMontoOriginalDetalleFin
					END 
					--@3

                     --Insertamos un nuevo detalle
                     Insert Into CO_DocumentoDetalle
                     (
                        CompaniaSocio, TipoDocumento, NumeroDocumento, Linea, TipoDetalle, ItemCodigo, Condicion, Lote, Descripcion, UnidadCodigo, PrecioUnitario, 
                        PrecioUnitarioOriginal, Interfase_MontoOriginal, CantidadPedida, Monto, CantidadPedidaDoble, PrecioUnitarioFinal, MontoFinal, ImprimirPUFlag, 
                        CantidadEntregada, CantidadEntregadaDoble, IGVExoneradoFlag,  DespachoUnidadEquivalenteFlag, AlmacenCodigo, Estado, UltimoUsuario, UltimaFechaModif, 
                        TransferenciaGratuitaFlag, PrecioUnitarioGratuito, FlujodeCaja, Proyecto, CentroCosto
                     )
                     Select @w_CompaniaSocio, @w_TipoDocumento, @vNumeroDocumentoGen, @m, b.TipoDetalle, b.ItemCodigo, '0', '00', @vDescripcionLocal, 'UNI', 
                            @vMontoDetalleFin,	--Case When b.Monto % 2 = 1 Then Round(b.Monto / 2 + 0.5, 0) Else Round(b.Monto / 2, 0) End,--@1
                            @vMontoDetalleFin,	--Case When b.Monto % 2 = 1 Then Round(b.Monto / 2 + 0.5, 0) Else Round(b.Monto / 2, 0) End,--@1
                            @vMontoOriginalDetalleFin,	--Case When b.MontoOriginal % 2 = 1 Then Round(b.MontoOriginal / 2 + 0.5, 0) Else Round(b.MontoOriginal / 2, 0) End,--@1
                            b.CantidadPedida * @w_Signo, 
                            (b.CantidadPedida * @w_Signo) * @vMontoDetalleFin,	--(Case When b.Monto % 2 = 1 Then Round(b.Monto / 2 + 0.5, 0) Else Round(b.Monto / 2, 0) End), --@1
                            0.00, 0.00, 0.00, 'S', 0.00, 0.00, 'S', 'N', 'LIMA', 'PR', 
                            'MISESF', GetDate(), 'N', 0.0000, @vFlujodeCaja, @vProyecto, @vCentroCosto
                     From #tmpdw_header a
                     Inner Join #tmpdw_detailResumen b On a.TipoDocumento = b.TipoDocumento And a.NumeroInterno = b.NumeroInterno
                     Where a.Id_Registro = @vFila And b.Id_Registro = @m
                     
                     Set @m = @m + 1
                  End
                  
                  --Actualizamos la tabla cabecera de la interfaz        
                  Update CO_Interfase_P09_Header 
                  SET Estado = 'PF', 
                      NumeroDocumento = @w_TipoDocumento + '-' +  @vNumeroDocumentoGen,
                      FechaProcesoImp = GetDate()
                  Where NumeroInterno = @vNumeroInterno 
               End
     End
            
            Set @vFila = @vFila + 1
         End
         
         Drop Table #wa_numero 
         Drop Table #wa_tipodocumento
      End
      
      --Se lista todos los registros
      Select * From #tmpdw_header
      
      --Se lista todos los errores
      Select * From #tmpErroresDocumento
      Set @vFilasConsultadas = @@RowCount      


      --Declare @vFilaCompania int   
      --Declare @vCompaniaSocio char(8)
      --Declare @vCorreo varchar(100)
      
      Declare @vFilaDetalle int   

     --Se verifica si existen errores para el envio del correo
      If (@vFilasConsultadas > 0)
      Begin 
         Set @vFilaCompania = 1

         While (@vFilaCompania <= 3)
         Begin
            Select @vCompaniaSocio = CompaniaSocio, @vCorreo = Correo 
            From #tmpCompanias
            Where Id_Registro = @vFilaCompania

            --Verificamos si hay errores por la empresa evaluada
            If (Select Count(*) From #tmpErroresDocumento Where CompaniaSocio = @vCompaniaSocio) > 0
            Begin
               --Se devuelve todos los registros con errores
               Set @vFila = 1
               Set @vBodyEmail = ''
               Set @vFilaDetalle = 1

               Set @vBodyEmail = @vBodyEmail + '<html>'
                  Set @vBodyEmail = @vBodyEmail + '<head>'            
                     Set @vBodyEmail = @vBodyEmail + '<style type="text/css">'
                     Set @vBodyEmail = @vBodyEmail + '.headGrid {'
                     Set @vBodyEmail = @vBodyEmail + '	font-weight: bold;'
                     Set @vBodyEmail = @vBodyEmail + '	font-size: 11px; '
                     Set @vBodyEmail = @vBodyEmail + '	color: #FFFFFF; '
                     Set @vBodyEmail = @vBodyEmail + '	font-family: Tahoma, Microsoft Sans Serif; '    
                     Set @vBodyEmail = @vBodyEmail + '	background-color: #539AC8;         '            
                     Set @vBodyEmail = @vBodyEmail + '}'
                     Set @vBodyEmail = @vBodyEmail + '.itemGrid {'
                     Set @vBodyEmail = @vBodyEmail + '	background-color: #F8F8F8;'
                     Set @vBodyEmail = @vBodyEmail + '	font-size: 8pt; color: #000000; font-family: Arial, Microsoft Sans Serif;'
                     Set @vBodyEmail = @vBodyEmail + '}'
                     Set @vBodyEmail = @vBodyEmail + '.titulo {'
                     Set @vBodyEmail = @vBodyEmail + '	font-weight: bold;'
                     Set @vBodyEmail = @vBodyEmail + '	font-size: 12pt; color: #000000; font-family: Arial, Microsoft Sans Serif;'
                     Set @vBodyEmail = @vBodyEmail + '}'
                     Set @vBodyEmail = @vBodyEmail + '</style>'
                  Set @vBodyEmail = @vBodyEmail + '</head>'
                  Set @vBodyEmail = @vBodyEmail + '<body>'
                     Set @vBodyEmail = @vBodyEmail + '<table style="width: 100%">'
                           Set @vBodyEmail = @vBodyEmail + '<tr style="height: 20pt">'
                              Set @vBodyEmail = @vBodyEmail + '<td class="titulo">&nbsp;'
                                 Set @vBodyEmail = @vBodyEmail + 'Lista de errores de importaci�n de Documentos(PE) (COp_InterfaseImportarDoc)'                
                              Set @vBodyEmail = @vBodyEmail + '</td>'
                           Set @vBodyEmail = @vBodyEmail + '</tr>'
                     Set @vBodyEmail = @vBodyEmail + '</table>'
                     Set @vBodyEmail = @vBodyEmail + '<br>'
                     Set @vBodyEmail = @vBodyEmail + '<table border="1" style="width: 100%;" cellpadding="0" cellspacing="0">'
                     Set @vBodyEmail = @vBodyEmail + '<tr>'
                     Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Id</td>'
                     Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Documento</td>'
                Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">L�nea</td>'
                     Set @vBodyEmail = @vBodyEmail + '<td align="center" class="headGrid" style="height: 17pt;">Descripci�n</td>'
                     Set @vBodyEmail = @vBodyEmail + '</tr>'
                     

                     While (@vFila <= @vFilasConsultadas)
                     Begin
                        If Exists (Select *
                                   From #tmpErroresDocumento
                                   Where Id_Registro = @vFila And CompaniaSocio = @vCompaniaSocio)
                        Begin                           
                           Set @vBodyEmail = @vBodyEmail + '<tr>'
          
                           Select @vBodyEmail = @vBodyEmail + 
                                  '<td align="center" class="itemGrid">' + Convert(varchar(7), @vFilaDetalle) + '</td>' + 
                                  '<td class="itemGrid">' + IsNull(Documento, '') + '</td>' + 
                                  '<td align="center" class="itemGrid">' + Convert(varchar(7), Linea) + '</td>' + 
                                  '<td class="itemGrid">' + IsNull(Descripcion, '') + '</td>'
                           From #tmpErroresDocumento
                           Where Id_Registro = @vFila And CompaniaSocio = @vCompaniaSocio

                           Set @vBodyEmail = @vBodyEmail + '</tr>'

                           Set @vFilaDetalle = @vFilaDetalle + 1
                        End

                        Set @vFila = @vFila + 1
                     End              

                     Set @vBodyEmail = @vBodyEmail + '</table>'
                     Set @vBodyEmail = @vBodyEmail + '<br>'
                     Set @vBodyEmail = @vBodyEmail + '<table style="width: 100%">'
                           Set @vBodyEmail = @vBodyEmail + '<tr style="height: 20pt">'
                              Set @vBodyEmail = @vBodyEmail + '<td style="font-size:  9pt;font-family: Tahoma, Microsoft Sans Serif; color: red;">&nbsp;'
                                 Set @vBodyEmail = @vBodyEmail + 'SEE'                
                              Set @vBodyEmail = @vBodyEmail + '</td>'
                           Set @vBodyEmail = @vBodyEmail + '</tr>'
                     Set @vBodyEmail = @vBodyEmail + '</table>'
                  Set @vBodyEmail = @vBodyEmail + '</body>'
               Set @vBodyEmail = @vBodyEmail + '</html>'

               --Envio de correo      'jcure@inlearning.edu.pe;jmota@inlearning.edu.pe; pablo.uchuya@inlearning.edu.pe'   --@7
               EXEC msdb.dbo.sp_send_dbmail   
                        @recipients = @vCorreo,                         
                        @profile_name = 'Interfase SEE',          
                        @subject = 'Errores de importaci�n de Documentos(PE)(COp_InterfaseImportarDoc)',   --  @11        
                        @body = @vBodyEmail,            
                        @body_format = 'HTML'
            End         

            Set @vFilaCompania = @vFilaCompania + 1            
         End
      End
   END TRY
   BEGIN CATCH
      Declare @vErrorNumber int
      Declare @vErrorLine int
      Declare @vErrorMessage varchar(300)
      Declare @vStoredProcedure varchar(300)

      --Se genero un error
      SELECT ERROR_NUMBER() AS ErrorNumber,
             ERROR_SEVERITY() AS ErrorSeverity,
             ERROR_STATE() AS ErrorState,
             ERROR_PROCEDURE() AS ErrorProcedure,
             ERROR_LINE() AS ErrorLine,
             ERROR_MESSAGE() AS ErrorMessage;
      
      Select ''    

      Set @vErrorNumber = ERROR_NUMBER()
      Set @vErrorLine = ERROR_LINE()
      Set @vErrorMessage = ERROR_MESSAGE()
      Set @vStoredProcedure = ERROR_PROCEDURE()
      Set @vMensaje = 'Numero de error: ' + Convert(varchar(15), @vErrorNumber) +  '  Linea de Error: ' + Convert(varchar(15), @vErrorLine) + ' Mensaje: ' + @vErrorMessage + '  Stored Procedure: ' + @vStoredProcedure

      IF @@TranCount > 0
         RollBack Transaction;
   END CATCH;
   
   IF @@TRANCOUNT > 0
      COMMIT TRANSACTION;

   Drop Table #tmpdw_header
   Drop Table #tmpdw_detail
   Drop Table #tmpErroresDocumento
   Drop Table #tmpdw_detailResumen
   Drop Table #tmpCompanias
   
   If Len(@vMensaje) > 0
   Begin
      EXEC msdb.dbo.sp_send_dbmail   
	         @recipients = 'bgaribay@inlearning.pe;mejoracontinuaidat@inlearning.pe',    
            @profile_name = 'Interfase SEE',            
            @subject = 'Error de ejecuci�n de importaci�n de Documentos - 2 - (COp_InterfaseImportarDoc) ',   --  @11      
            @body = @vMensaje,   
            @body_format = 'HTML'
   End
         
   Set NoCount Off
End


