--����������������������������������������������������������������������������                                                      
--Creado por      :Miguel Gargurevich(11/12/2012)                                                                          
--Funcionalidad   :Proceso de Unificaci�n      
--Utilizado por   :Actor.cUnificarActores      
--����������������������������������������������������������������������������           
/*      
-----------------------------------------------------------------------------      
Nro  FECHA		USUARIO		DESCRIPCION      
-----------------------------------------------------------------------------      
@1  25.09.2013	ilopez		se agrega campos de auditoria a la tabla AlumnoCurriculaCurso.      
@2  01.02.2014	ilopez		Proyecto SEE  
@3	20.05.2019	EHuillca	Se optimiza el stored seg�n los cambios en campos de tablas y nuevas tablas relacionadas creadas.  
@4	26.06.2019	EHuillca	Se crea una nueva linea de eliminaci�n de tabla InteresadoAgenda.
@5	15.10.2019	EHuillca	Se crea lineas de eliminaci�n de tablas relacionales
@6	11.09.2023	MBUENO		Se agrega columna Estado por ser requerido en MatriculaSeguimiento
@7	28.09.2023	Alsanchez	Se agrega la eliminacion de la tabla EVA_InformacionActorDetalle
@8	05.12.2023	Alsanchez	Se comenta los delete de interesado y se realizao los update por idactor
@9	15.03.2024	ALSANCHEZ	Se agrega los delete ha las tablas de eva y asignacion ficha matricula
*/                
ALTER PROCEDURE [dbo].[cUnificarActores]               
@IdProceso VARCHAR(50),        
@IdActorOrigen VARCHAR(100),        
@IdActorDestino VARCHAR(100),        
@Login VARCHAR(100),        
@Error INT OUTPUT,        
@Mensaje VARCHAR(MAX) OUTPUT        
AS        
BEGIN 
         
/**********************************************************************************************************/        
-- SE DESHABILITAN TODOS LOS TRIGGERS DE ACTOR        
/**********************************************************************************************************/        
        
	ALTER TABLE Actor        
	DISABLE TRIGGER personamast_Update ;        
          
	ALTER TABLE Actor        
	DISABLE TRIGGER Tr_Actor_del;        
          
	ALTER TABLE Actor        
	DISABLE TRIGGER Tr_Actor_ins ;        
          
	ALTER TABLE Actor        
	DISABLE TRIGGER Tr_Actor_upd;        
          
	ALTER TABLE ActorDireccion        
	DISABLE TRIGGER Tr_ActorDireccion_Del;        
          
	ALTER TABLE ActorDireccion        
	DISABLE TRIGGER Tr_ActorDireccion_Upd;        
          
	ALTER TABLE ActorEmail        
	DISABLE TRIGGER Tr_ActorEmail_Upd;        
          
	ALTER TABLE ActorEmail        
	DISABLE TRIGGER Tr_ActorEmail_Del;        
          
	ALTER TABLE ActorTelefono        
	DISABLE TRIGGER Tr_ActorTelefono_Upd;        
          
	ALTER TABLE ActorTelefono        
	DISABLE TRIGGER Tr_ActorTelefono_Del;        
        
	ALTER TABLE ActorDireccion        
	DISABLE TRIGGER TR_ActorDireccion_INS        
        
	ALTER TABLE ActorEmail        
	DISABLE TRIGGER TR_ActorEmail_INS        
        
	ALTER TABLE ActorTelefono        
	DISABLE TRIGGER TR_ActorTelefono_INS        
         
	SET @Error = 0        
	SET @Mensaje = ''        
         
	DECLARE @ContRegistro INT        
	SET @ContRegistro = (SELECT COUNT(IdRegistro) FROM Registro WITH(NOLOCK) WHERE IdActor = @IdActorOrigen)        
          
	DECLARE @IdCounter INT         
	SET @IdCounter = (SELECT top 1 IdCounter FROM ContactoAtencion WITH(NOLOCK) WHERE IdContacto IN (@IdActorOrigen,@IdActorDestino)         
						AND IdAtencion=(SELECT MAX(IdAtencion)         
						FROM ContactoAtencion WITH(NOLOCK)        
						WHERE IdContacto IN (@IdActorOrigen,@IdActorDestino)))        
          
	--INSERTS        
	BEGIN        
		--Registro        
		IF @ContRegistro > 0         
		BEGIN        
           
			--Alumno----------------------------------------------------------------------------------------------------------------------   
			BEGIN        
				BEGIN TRY        
					IF NOT EXISTS (SELECT 1 FROM Alumno WITH(NOLOCK) WHERE IdAlumno = @IdActorDestino)        
					INSERT INTO Alumno (Activo, CodigoAnterior, EmailInstitucion, FechaCreacion, FechaModificacion, IdAlumno, IdUsuario, UsuarioCreacion, UsuarioModificacion)         
					SELECT Activo, CodigoAnterior, EmailInstitucion, FechaCreacion, FechaModificacion, @IdActorDestino, IdUsuario, UsuarioCreacion, UsuarioModificacion         
					FROM Alumno WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen         
        
					INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
					SELECT @IdProceso,'Alumno',        
					CONVERT(VARCHAR,@IdActorOrigen),        
					CONVERT(VARCHAR,@IdActorDestino),        
					@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Alumno WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
				END TRY        
				BEGIN CATCH        
					SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
					INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
					SELECT @IdProceso,'Alumno',        
					CONVERT(VARCHAR,@IdActorOrigen),        
					CONVERT(VARCHAR,@IdActorDestino),        
					@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Alumno WITH(NOLOCK) where IdAlumno=@IdActorOrigen            
				END CATCH        
			END        
           
			--Registro----------------------------------------------------------------------------------------------------------------------        
			DECLARE @VarTablaRegistro TABLE (Id int, DocumentoFecha datetime, DocumentoNumero varchar(20), Estado char(1), FechaCreacion datetime, FechaModificacion datetime, IdActor int, IdEmpresa int, IdFacultad int, IdMoneda int, IdPlantilla int,         
			IdProducto int, IdRegistro int, IdSede int, IdUnidadNegocio int, IdUsuario int, Observacion varchar(500), TipoServicio char(1), UsuarioCreacion int, UsuarioModificacion int)        
			INSERT INTO @VarTablaRegistro (Id, DocumentoFecha, DocumentoNumero, Estado, FechaCreacion, FechaModificacion, IdActor, IdEmpresa, IdFacultad, IdMoneda, IdPlantilla, IdProducto, IdRegistro, IdSede, IdUnidadNegocio, IdUsuario,         
			Observacion, TipoServicio, UsuarioCreacion, UsuarioModificacion)         
			SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), DocumentoFecha, DocumentoNumero, Estado, FechaCreacion, FechaModificacion, @IdActorDestino, IdEmpresa, IdFacultad, IdMoneda, IdPlantilla, IdProducto, IdRegistro, IdSede, IdUnidadNegocio,         
			IdUsuario, Observacion, TipoServicio, UsuarioCreacion, UsuarioModificacion         
			FROM Registro WITH(NOLOCK) WHERE IdActor = @IdActorOrigen        
           
			DECLARE @oCurIdRegistro INT, @oMaxIdRegistro INT        
			SELECT @oCurIdRegistro=1, @oMaxIdRegistro=Max(Id) FROM @VarTablaRegistro        
			WHILE @oMaxIdRegistro >= @oCurIdRegistro         
			BEGIN         
				DECLARE @IdRegistroOld INT, @IdRegistroNew INT, @IdProducto INT        
				SET @IdRegistroOld = (SELECT IdRegistro FROM @VarTablaRegistro WHERE ID=@oCurIdRegistro)        
				SET @IdRegistroNew = (SELECT IdRegistro+(select ISNULL(MAX(IdRegistro),0) from Registro  with(nolock)  WHERE   IdActor = @IdActorDestino) FROM @VarTablaRegistro  WHERE   ID=@oCurIdRegistro)        
				SET @IdProducto = (SELECT IdProducto FROM @VarTablaRegistro  WHERE   ID=@oCurIdRegistro)        
            
				BEGIN TRY         
					INSERT INTO Registro (DocumentoFecha, DocumentoNumero, Estado, FechaCreacion, FechaModificacion, IdActor, IdEmpresa, IdFacultad, IdMoneda, IdPlantilla, IdProducto, IdRegistro, IdSede, IdUnidadNegocio, IdUsuario, Observacion,         
					TipoServicio, UsuarioCreacion, UsuarioModificacion)         
					SELECT DocumentoFecha, DocumentoNumero, Estado, FechaCreacion, FechaModificacion, @IdActorDestino, IdEmpresa, IdFacultad, IdMoneda, IdPlantilla, IdProducto, @IdRegistroNew, IdSede,         
					IdUnidadNegocio, IdUsuario, Observacion, TipoServicio, UsuarioCreacion, UsuarioModificacion         
					FROM @VarTablaRegistro     
					WHERE Id = @oCurIdRegistro         
            
					INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
					SELECT @IdProceso,'Registro',        
					CONVERT(VARCHAR,IdActor)+','+CONVERT(VARCHAR,IdRegistro),        
					CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdRegistro),        
					@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
					FROM @VarTablaRegistro         
					WHERE Id = @oCurIdRegistro         
				END TRY        
				BEGIN CATCH         
					SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
					INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
					SELECT @IdProceso,'Registro',        
					CONVERT(VARCHAR,IdActor)+','+CONVERT(VARCHAR,IdRegistro),        
					CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdRegistro),        
					@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
					FROM @VarTablaRegistro         
					WHERE Id = @oCurIdRegistro         
				END CATCH        
            
				--AlumnoCurricula----------------------------------------------------------------------------------------------------------------------        
				DECLARE @IdCurricula INT        
				DECLARE @VarTablaAlumnoCurricula TABLE (Id int, Activo bit, FechaCreacion datetime, IdAlumno int, IdCurricula int, IdRegistro int, UsuarioCreacion int)        
				delete @VarTablaAlumnoCurricula        
				INSERT INTO @VarTablaAlumnoCurricula (Id, Activo, FechaCreacion, IdAlumno, IdCurricula, IdRegistro, UsuarioCreacion)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), Activo, FechaCreacion, @IdActorDestino, IdCurricula, @IdRegistroOld, UsuarioCreacion         
				FROM AlumnoCurricula WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld         
            
				DECLARE @oCurIdAlumnoCurricula INT, @oMaxIdAlumnoCurricula INT        
				SELECT @oCurIdAlumnoCurricula=1, @oMaxIdAlumnoCurricula=Max(Id) FROM @VarTablaAlumnoCurricula        
				WHILE @oMaxIdAlumnoCurricula >= @oCurIdAlumnoCurricula         
				BEGIN        
					BEGIN TRY        
						SET @IdCurricula = (SELECT IdCurricula FROM @VarTablaAlumnoCurricula WHERE id = @oCurIdAlumnoCurricula)        
						INSERT INTO AlumnoCurricula (Activo, FechaCreacion, IdAlumno, IdCurricula, IdRegistro, UsuarioCreacion)         
						SELECT Activo, FechaCreacion, @IdActorDestino, IdCurricula, @IdRegistroNew, UsuarioCreacion         
						FROM @VarTablaAlumnoCurricula         
						WHERE Id = @oCurIdAlumnoCurricula         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'AlumnoCurricula',        
						CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdRegistro),        
						CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdRegistro),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaAlumnoCurricula         
						WHERE Id = @oCurIdAlumnoCurricula         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'AlumnoCurricula',        
						CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdRegistro),      
						CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdRegistro),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaAlumnoCurricula         
						WHERE Id = @oCurIdAlumnoCurricula         
					END CATCH        
             
						--AlumnoCurriculaModulo----------------------------------------------------------------------------------------------------------------------        
					DECLARE @IdModulo INT         
					DECLARE @VarTablaAlumnoCurriculaModulo TABLE (Id int, IdAlumno int, IdCurricula int, IdModulo int, IdRegistro int)        
					DELETE @VarTablaAlumnoCurriculaModulo        
					INSERT INTO @VarTablaAlumnoCurriculaModulo (Id, IdAlumno, IdCurricula, IdModulo, IdRegistro)        
					SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), @IdActorDestino, IdCurricula, IdModulo, @IdRegistroNew        
					FROM AlumnoCurriculaModulo WITH(NOLOCK)     
					WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld AND IdCurricula = @IdCurricula        
             
					DECLARE @oCurIdAlumnoCurriculaModulo INT, @oMaxIdAlumnoCurriculaModulo INT        
					SELECT @oCurIdAlumnoCurriculaModulo=1, @oMaxIdAlumnoCurriculaModulo=Max(Id) FROM @VarTablaAlumnoCurriculaModulo        
					WHILE @oMaxIdAlumnoCurriculaModulo >= @oCurIdAlumnoCurriculaModulo              
					BEGIN        
						BEGIN TRY        
							SET @IdModulo = (SELECT IdModulo FROM @VarTablaAlumnoCurriculaModulo WHERE id = @oCurIdAlumnoCurriculaModulo)        
							INSERT INTO AlumnoCurriculaModulo (IdAlumno, IdCurricula, IdModulo, IdRegistro)         
							SELECT @IdActorDestino, IdCurricula, IdModulo, @IdRegistroNew        
							FROM @VarTablaAlumnoCurriculaModulo         
							WHERE Id = @oCurIdAlumnoCurriculaModulo         
        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'AlumnoCurriculaModulo',        
							CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdModulo)+','+CONVERT(VARCHAR,IdRegistro),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdModulo)+','+CONVERT(VARCHAR,IdRegistro),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaAlumnoCurriculaModulo         
							WHERE Id = @oCurIdAlumnoCurriculaModulo         
						END TRY        
						BEGIN CATCH         
							SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'AlumnoCurriculaModulo',        
							CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdModulo)+','+CONVERT(VARCHAR,IdRegistro),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdModulo)+','+CONVERT(VARCHAR,IdRegistro),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaAlumnoCurriculaModulo         
							WHERE Id = @oCurIdAlumnoCurriculaModulo         
						END CATCH        
              
						--AlumnoCurriculaCurso----------------------------------------------------------------------------------------------------------------------        
						DECLARE @IdCurso INT        
						DECLARE @VarTablaAlumnoCurriculaCurso TABLE (Id int, IdAlumno int, IdAlumnoCurso int, IdConvalidacion int, IdCurricula int, IdCurso int,        
						IdModulo int, IdRegistro int, PromedioCondicion varchar(20), PromedioFinal varchar(10), PromedioReal varchar(10), TipoCondicion char(2),      
						[Glosa] VARCHAR(500) ,[UsuarioCreacion] INT ,[FechaCreacion] DATETIME ,[UsuarioModificacion] INT , [FechaModificacion] DATETIME )        
						DELETE @VarTablaAlumnoCurriculaCurso         
						INSERT INTO @VarTablaAlumnoCurriculaCurso (Id, IdAlumno,IdRegistro,IdCurricula,IdCurso,IdAlumnoCurso,IdModulo,IdConvalidacion,PromedioFinal,PromedioReal,PromedioCondicion,TipoCondicion)        
						SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), @IdActorDestino, @IdRegistroNew, IdCurricula,IdCurso,IdAlumnoCurso,IdModulo,IdConvalidacion,PromedioFinal,PromedioReal,PromedioCondicion,TipoCondicion        
						FROM AlumnoCurriculaCurso WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld AND IdCurricula = @IdCurricula and IdModulo = @IdModulo         
                
						DECLARE @oCurIdAlumnoCurriculaCurso INT, @oMaxIdAlumnoCurriculaCurso INT        
						SELECT @oCurIdAlumnoCurriculaCurso=1, @oMaxIdAlumnoCurriculaCurso=Max(Id) FROM @VarTablaAlumnoCurriculaCurso        
						WHILE @oMaxIdAlumnoCurriculaCurso >= @oCurIdAlumnoCurriculaCurso           
						BEGIN        
							BEGIN TRY        
								SET @IdCurso = (SELECT IdCurso FROM @VarTablaAlumnoCurriculaCurso WHERE id = @oCurIdAlumnoCurriculaCurso)        
								INSERT INTO AlumnoCurriculaCurso (IdAlumno,IdRegistro,IdCurricula,IdCurso,IdAlumnoCurso,IdModulo,IdConvalidacion,PromedioFinal,PromedioReal,PromedioCondicion,TipoCondicion,Glosa,UsuarioCreacion,FechaCreacion,UsuarioModificacion,FechaModificacion)




--@1        
								SELECT @IdActorDestino, @IdRegistroNew, IdCurricula,IdCurso,IdAlumnoCurso,IdModulo,IdConvalidacion,PromedioFinal,PromedioReal,PromedioCondicion,TipoCondicion,Glosa,UsuarioCreacion,FechaCreacion,UsuarioModificacion,FechaModificacion  --@1      
								FROM @VarTablaAlumnoCurriculaCurso         
								WHERE Id = @oCurIdAlumnoCurriculaCurso        
        
								INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
								SELECT @IdProceso,'AlumnoCurriculaCurso',        
								CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,IdRegistro),        
								CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,IdRegistro),        
								@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
								FROM @VarTablaAlumnoCurriculaCurso         
								WHERE Id = @oCurIdAlumnoCurriculaCurso        
							END TRY        
							BEGIN CATCH         
								SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
								INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
								SELECT @IdProceso,'AlumnoCurriculaCurso',        
								CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,IdRegistro),        
								CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,IdRegistro),        
								@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
								FROM @VarTablaAlumnoCurriculaCurso         
								WHERE Id = @oCurIdAlumnoCurriculaCurso        
							END CATCH        
               
							--AlumnoCurriculaConvalida----------------------------------------------------------------------------------------------------------------------        
							DECLARE @VarTablaAlumnoCurriculaConvalida TABLE (Id int, ConvalidaIdCurricula int, ConvalidaIdCurso int, ConvalidaIdRegistro int,         
							CursoNombreExterno varchar(200), IdAlumno int, IdConvalida int, IdConvalidacion int, IdCurricula int, IdCurso int, IdRegistro int,         
							ProcedenciaExterno varchar(200), PromedioCondicion varchar(20), PromedioFinal varchar(10), PromedioReal varchar(10))        
							DELETE @VarTablaAlumnoCurriculaConvalida         
							INSERT INTO @VarTablaAlumnoCurriculaConvalida (Id, ConvalidaIdCurricula, ConvalidaIdCurso, ConvalidaIdRegistro, CursoNombreExterno,         
							IdAlumno, IdConvalida, IdConvalidacion, IdCurricula, IdCurso, IdRegistro, ProcedenciaExterno, PromedioCondicion, PromedioFinal, PromedioReal)        
							SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), ConvalidaIdCurricula, ConvalidaIdCurso, ConvalidaIdRegistro, CursoNombreExterno, @IdActorDestino,         
							IdConvalida, IdConvalidacion, IdCurricula, IdCurso, @IdRegistroNew, ProcedenciaExterno, PromedioCondicion, PromedioFinal, PromedioReal 
							FROM AlumnoCurriculaConvalida WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld AND IdCurricula = @IdCurricula and IdCurso = @IdCurso         
               
							DECLARE @oCurIdAlumnoCurriculaConvalida INT, @oMaxIdAlumnoCurriculaConvalida INT        
							SELECT @oCurIdAlumnoCurriculaConvalida=1, @oMaxIdAlumnoCurriculaConvalida=Max(Id) FROM @VarTablaAlumnoCurriculaConvalida         
							WHILE @oMaxIdAlumnoCurriculaConvalida >= @oCurIdAlumnoCurriculaConvalida
							BEGIN        
								BEGIN TRY        
									INSERT INTO AlumnoCurriculaConvalida (ConvalidaIdCurricula, ConvalidaIdCurso, ConvalidaIdRegistro, CursoNombreExterno, IdAlumno, IdConvalida,         
									IdConvalidacion, IdCurricula, IdCurso, IdRegistro, ProcedenciaExterno, PromedioCondicion, PromedioFinal, PromedioReal)        
									SELECT ConvalidaIdCurricula, ConvalidaIdCurso, ConvalidaIdRegistro, CursoNombreExterno, @IdActorDestino, IdConvalida, IdConvalidacion, IdCurricula,         
									IdCurso, @IdRegistroNew, ProcedenciaExterno, PromedioCondicion, PromedioFinal, PromedioReal       
									FROM @VarTablaAlumnoCurriculaConvalida WHERE Id = @oCurIdAlumnoCurriculaConvalida        
        
									INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
									SELECT @IdProceso,'AlumnoCurriculaCurso',        
									CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,IdRegistro),        
									CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,IdRegistro),        
									@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
									FROM @VarTablaAlumnoCurriculaCurso        
									WHERE Id = @oCurIdAlumnoCurriculaConvalida        
								END TRY        
								BEGIN CATCH         
									SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
									INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
									SELECT @IdProceso,'AlumnoCurriculaCurso',        
									CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,IdRegistro),        
									CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurricula)+','+CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,IdRegistro),        
									@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
									FROM @VarTablaAlumnoCurriculaCurso         
									WHERE Id = @oCurIdAlumnoCurriculaConvalida        
								END CATCH        
							END        
               
							SET @oCurIdAlumnoCurriculaCurso = @oCurIdAlumnoCurriculaCurso+1        
               
						END         
              
						SET @oCurIdAlumnoCurriculaModulo = @oCurIdAlumnoCurriculaModulo+1        
              
					END        
        
					--Convalidacion----------------------------------------------------------------------------------------------------------------------        
					DECLARE @VarTablaConvalidacion TABLE (Id int, IdEmpresa int, IdSede int, IdAlumno int, IdRegistro int, IdCurricula int, AnteriorIdCurricula int, IdPeriodoAnual int, IdUsuario int,         
					UsuarioCreacion int, UsuarioModificacion int, DocumentoFecha datetime, FechaCreacion datetime, FechaModificacion datetime, Numero varchar(20), DocumentoNumero varchar(20), Observacion varchar(500),         
					Tipo char(2), Estado char(1))        
					DELETE @VarTablaConvalidacion        
					INSERT INTO @VarTablaConvalidacion (Id, IdEmpresa, IdSede, IdAlumno, IdRegistro, IdCurricula, AnteriorIdCurricula, Numero, IdPeriodoAnual, IdUsuario, DocumentoNumero, DocumentoFecha,         
					Observacion, Tipo, Estado, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion)        
					SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), IdEmpresa, IdSede, @IdActorDestino, @IdRegistroNew, @IdCurricula, AnteriorIdCurricula, Numero, IdPeriodoAnual, IdUsuario, DocumentoNumero,         
					DocumentoFecha, Observacion, Tipo, Estado, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion        
					FROM Convalidacion WITH(NOLOCK)        
					WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld AND IdCurricula = @IdCurricula        
             
					DECLARE @oCurIdConvalidacion INT, @oMaxIdConvalidacion INT        
					SELECT @oCurIdConvalidacion=1, @oMaxIdConvalidacion=Max(Id) FROM @VarTablaConvalidacion        
					WHILE @oMaxIdConvalidacion >= @oCurIdConvalidacion         
					BEGIN        
						BEGIN TRY        
							INSERT INTO Convalidacion (IdEmpresa, IdSede, IdAlumno, IdRegistro, IdCurricula, AnteriorIdCurricula, Numero, IdPeriodoAnual, IdUsuario, DocumentoNumero, DocumentoFecha,         
							Observacion, Tipo, Estado, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion)         
							SELECT IdEmpresa, IdSede, @IdActorDestino, @IdRegistroNew, @IdCurricula, AnteriorIdCurricula, Numero, IdPeriodoAnual, IdUsuario, DocumentoNumero, DocumentoFecha, Observacion, Tipo,         
							Estado, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion        
							FROM @VarTablaConvalidacion         
							WHERE Id = @oCurIdConvalidacion         
        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'Convalidacion',        
							CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdRegistro)+','+CONVERT(VARCHAR,IdCurricula),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdRegistro)+','+CONVERT(VARCHAR,IdCurricula),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaConvalidacion         
							WHERE Id = @oCurIdConvalidacion         
						END TRY        
						BEGIN CATCH         
							SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'Convalidacion',        
							CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdRegistro)+','+CONVERT(VARCHAR,IdCurricula),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdRegistro)+','+CONVERT(VARCHAR,IdCurricula),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaConvalidacion         
							WHERE Id = @oCurIdConvalidacion         
						END CATCH        
              
						SET @oCurIdConvalidacion = @oCurIdConvalidacion+1         
              
					END        
             
					SET @oCurIdAlumnoCurricula = @oCurIdAlumnoCurricula+1         
             
				END        
				--Matricula----------------------------------------------------------------------------------------------------------------------        
				DECLARE @IdMatriculaMax INT        
				SET @IdMatriculaMax = (SELECT max(IdMatricula) FROM Matricula WITH(NOLOCK))            
            
				DECLARE @VarTablaMatricula TABLE (Id int, CondicionPago char(1), EsCerrado bit, EsComision bit, EsMatricula bit, Estado char(1), FechaCreacion datetime, FechaModificacion datetime,         
				IdActor int, IdAutorizacion int, IdBeca int, IdCampana int, IdConvenio int, IdCurricula int, IdDescuento int, IdEmpresa int, IdEntidad int, IdGrupo int, IdMatricula int, IdMedio int,         
				IdModulo int, IdMoneda int, IdPeriodo int, IdPlanPago int, IdProcedencia int, IdPromocion int, IdRegistro int, IdSeccion int, IdSede int, IdSocio int, IdTipoMedio int, InscritoFecha datetime,         
				InscritoIdEquipo int, InscritoIdUsuario int, InscritoNo int, MatriculaFecha datetime, MatriculaIdUsuario int, MontoMoneda real, Numero varchar(50), Observacion varchar(500), ObservacionPrePago varchar(500),         
				seccion varchar(50), Tipo char(2), TipoCondicion char(2), TipoInscripcion char(1), TipoServicio char(1), UsuarioCreacion int, UsuarioModificacion int, IdMatriculaOld int)        
				delete @VarTablaMatricula        
				INSERT INTO @VarTablaMatricula (Id, CondicionPago, EsCerrado, EsComision, EsMatricula, Estado, FechaCreacion, FechaModificacion, IdActor, IdAutorizacion, IdBeca, IdCampana, IdConvenio, IdCurricula, IdDescuento,         
				IdEmpresa, IdEntidad, IdGrupo, IdMatricula, IdMedio, IdModulo, IdMoneda, IdPeriodo, IdPlanPago, IdProcedencia, IdPromocion, IdRegistro, IdSeccion, IdSede, IdSocio, IdTipoMedio, InscritoFecha, InscritoIdEquipo,         
				InscritoIdUsuario, InscritoNo, MatriculaFecha, MatriculaIdUsuario, MontoMoneda, Numero, Observacion, ObservacionPrePago, seccion, Tipo, TipoCondicion, TipoInscripcion, TipoServicio, UsuarioCreacion, UsuarioModificacion, IdMatriculaOld)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), CondicionPago, EsCerrado, EsComision, EsMatricula, Estado, FechaCreacion, FechaModificacion, @IdActorDestino, IdAutorizacion, IdBeca, IdCampana, IdConvenio, IdCurricula,         
				IdDescuento, IdEmpresa, IdEntidad, IdGrupo, IdMatricula, IdMedio, IdModulo, IdMoneda, IdPeriodo, IdPlanPago, IdProcedencia, IdPromocion, @IdRegistroNew, IdSeccion, IdSede, IdSocio, IdTipoMedio, InscritoFecha, InscritoIdEquipo,         
				InscritoIdUsuario, InscritoNo, MatriculaFecha, MatriculaIdUsuario, MontoMoneda, Numero, Observacion, ObservacionPrePago, seccion, Tipo, TipoCondicion, TipoInscripcion, TipoServicio, UsuarioCreacion, UsuarioModificacion, IdMatricula        
				FROM Matricula  with(nolock)  WHERE   IdActor = @IdActorOrigen AND IdRegistro = @IdRegistroOld         
            
				UPDATE @VarTablaMatricula SET IdMatricula = @IdMatriculaMax+Id        
            
				DECLARE @oCurIdMatricula INT, @oMaxIdMatricula INT        
				SELECT @oCurIdMatricula=1, @oMaxIdMatricula=Max(Id) FROM @VarTablaMatricula        
				WHILE @oMaxIdMatricula >= @oCurIdMatricula         
				BEGIN        
					BEGIN TRY        
						DECLARE @IdMatriculaNew INT, @IdMatriculaOld INT        
						SET @IdMatriculaNew = (SELECT IdMatricula FROM @VarTablaMatricula WHERE id = @oCurIdMatricula)        
						SET @IdMatriculaOld = (SELECT IdMatriculaOld FROM @VarTablaMatricula WHERE id = @oCurIdMatricula)        
              
						INSERT INTO Matricula (CondicionPago, EsCerrado, EsComision, EsMatricula, Estado, FechaCreacion, FechaModificacion, IdActor, IdAutorizacion, IdBeca, IdCampana, IdConvenio, IdCurricula, IdDescuento,         
						IdEmpresa, IdEntidad, IdGrupo, IdMatricula, IdMedio, IdModulo, IdMoneda, IdPeriodo, IdPlanPago, IdProcedencia, IdPromocion, IdRegistro, IdSeccion, IdSede, IdSocio, IdTipoMedio, InscritoFecha, InscritoIdEquipo,   
						InscritoIdUsuario, InscritoNo, MatriculaFecha, MatriculaIdUsuario, MontoMoneda, Numero, Observacion, ObservacionPrePago, seccion, Tipo, TipoCondicion, TipoInscripcion, TipoServicio, UsuarioCreacion, UsuarioModificacion)         
						SELECT CondicionPago, EsCerrado, EsComision, EsMatricula, Estado, FechaCreacion, FechaModificacion, @IdActorDestino, IdAutorizacion, IdBeca, IdCampana, IdConvenio, IdCurricula, IdDescuento,         
						IdEmpresa, IdEntidad, IdGrupo, IdMatricula, IdMedio, IdModulo, IdMoneda, IdPeriodo, IdPlanPago, IdProcedencia, IdPromocion, IdRegistro, IdSeccion, IdSede, IdSocio, IdTipoMedio, InscritoFecha, InscritoIdEquipo,         
						InscritoIdUsuario, InscritoNo, MatriculaFecha, MatriculaIdUsuario, MontoMoneda, Numero, Observacion, ObservacionPrePago, seccion, Tipo, TipoCondicion, TipoInscripcion, TipoServicio, UsuarioCreacion, UsuarioModificacion        
						FROM @VarTablaMatricula         
						WHERE   Id = @oCurIdMatricula         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'Matricula',        
						CONVERT(VARCHAR,@IdMatriculaOld),        
						CONVERT(VARCHAR,@IdMatriculaNew),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatricula         
						WHERE Id = @oCurIdMatricula         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'Matricula',        
						CONVERT(VARCHAR,@IdMatriculaOld),        
						CONVERT(VARCHAR,@IdMatriculaNew),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatricula         
						WHERE   Id = @oCurIdMatricula         
					END CATCH        
                
					--AlumnoCurso----------------------------------------------------------------------------------------------------------------------        
					DECLARE @IdAlumnoCurso INT        
					DECLARE @VarTablaAlumnoCurso TABLE (Id int, EsMatricula bit, estado char(2), FechaCreacion datetime, FechaModificacion datetime, IdAlumno int,         
					IdAlumnoCurso int, IdCurricula int, IdCurso int, IdDecreto int, IdGrupo int, IdMatricula int, IdMoneda int, IdPromocion int, IdRecuperacion int,         
					IdRegistro int, IdSeccion int, idtipoautorizacion int, MontoMoneda real, NumVezCurso int, PromedioCondicion varchar(20), PromedioFinal varchar(10),         
					PromedioNuevo varchar(10), PromedioReal varchar(10), SesionAsiste int, SesionFalta int, SesionJustifica int, SesionTarde int, TipoCondicion char(2),         
					UsuarioCreacion int, UsuarioModificacion int)        
					DELETE @VarTablaAlumnoCurso        
					INSERT INTO @VarTablaAlumnoCurso (Id, EsMatricula, estado, FechaCreacion, FechaModificacion, IdAlumno, IdAlumnoCurso, IdCurricula, IdCurso, IdDecreto,         
					IdGrupo, IdMatricula, IdMoneda, IdPromocion, IdRecuperacion, IdRegistro, IdSeccion, idtipoautorizacion, MontoMoneda, NumVezCurso, PromedioCondicion,         
					PromedioFinal, PromedioNuevo, PromedioReal, SesionAsiste, SesionFalta, SesionJustifica, SesionTarde, TipoCondicion, UsuarioCreacion, UsuarioModificacion)         
					SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), EsMatricula, estado, FechaCreacion, FechaModificacion, @IdActorDestino, IdAlumnoCurso, IdCurricula, IdCurso,         
					IdDecreto, IdGrupo, @IdMatriculaNew, IdMoneda, IdPromocion, IdRecuperacion, @IdRegistroNew, IdSeccion, idtipoautorizacion, MontoMoneda, NumVezCurso, PromedioCondicion,         
					PromedioFinal, PromedioNuevo, PromedioReal, SesionAsiste, SesionFalta, SesionJustifica, SesionTarde, TipoCondicion, UsuarioCreacion, UsuarioModificacion         
					FROM AlumnoCurso WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld  AND IdMatricula = @IdMatriculaOld         
             
					DECLARE @oCurIdAlumnoCurso INT, @oMaxIdAlumnoCurso INT        
					SELECT @oCurIdAlumnoCurso=1, @oMaxIdAlumnoCurso=Max(Id) FROM @VarTablaAlumnoCurso        
					WHILE @oMaxIdAlumnoCurso >= @oCurIdAlumnoCurso         
					BEGIN        
						BEGIN TRY        
							SET @IdAlumnoCurso = (SELECT IdAlumnoCurso FROM @VarTablaAlumnoCurso WHERE id = @oCurIdAlumnoCurso)        
							INSERT INTO AlumnoCurso (EsMatricula, estado, FechaCreacion, FechaModificacion, IdAlumno, IdAlumnoCurso, IdCurricula, IdCurso, IdDecreto, IdGrupo, IdMatricula, IdMoneda, IdPromocion, IdRecuperacion,         
							IdRegistro, IdSeccion, idtipoautorizacion, MontoMoneda, NumVezCurso, PromedioCondicion, PromedioFinal, PromedioNuevo, PromedioReal, SesionAsiste, SesionFalta, SesionJustifica, SesionTarde, TipoCondicion,         
							UsuarioCreacion, UsuarioModificacion)         
							SELECT EsMatricula, estado, FechaCreacion, FechaModificacion, @IdActorDestino, IdAlumnoCurso, IdCurricula, IdCurso, IdDecreto, IdGrupo, IdMatricula, IdMoneda, IdPromocion, IdRecuperacion, @IdRegistroNew,         
							IdSeccion, idtipoautorizacion, MontoMoneda, NumVezCurso, PromedioCondicion, PromedioFinal, PromedioNuevo, PromedioReal, SesionAsiste, SesionFalta, SesionJustifica, SesionTarde, TipoCondicion, UsuarioCreacion,         
							UsuarioModificacion         
							FROM @VarTablaAlumnoCurso         
							WHERE Id = @oCurIdAlumnoCurso        
        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'AlumnoCurso',        
							CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdAlumnoCurso)+','+CONVERT(VARCHAR,IdRegistro),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdAlumnoCurso)+','+CONVERT(VARCHAR,IdRegistro),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaAlumnoCurso         
							WHERE Id = @oCurIdAlumnoCurso        
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'AlumnoCurso',        
						CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdAlumnoCurso)+','+CONVERT(VARCHAR,IdRegistro),        
						CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdAlumnoCurso)+','+CONVERT(VARCHAR,IdRegistro),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaAlumnoCurso         
						WHERE Id = @oCurIdAlumnoCurso        
					END CATCH        
					--AlumnoCursoRecuperacion----------------------------------------------------------------------------------------------------------------------        
					DECLARE @VarTablaAlumnoCursoRecuperacion TABLE (Id int, IdAlumno int, IdAlumnoCurso int, IdRecuperacion int, IdRegistro int, PromedioCondicion varchar(20), PromedioFinal varchar(10), PromedioReal varchar(10))        
					DELETE @VarTablaAlumnoCursoRecuperacion        
					INSERT INTO @VarTablaAlumnoCursoRecuperacion (Id, IdAlumno, IdAlumnoCurso, IdRecuperacion, IdRegistro, PromedioCondicion, PromedioFinal, PromedioReal)         
					SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), @IdActorDestino, IdAlumnoCurso, IdRecuperacion, @IdRegistroNew, PromedioCondicion, PromedioFinal, PromedioReal        
					FROM AlumnoCursoRecuperacion WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld AND IdAlumnoCurso = @IdAlumnoCurso        
              
					DECLARE @oCurIdAlumnoCursoRecuperacion INT, @oMaxIdAlumnoCursoRecuperacion INT        
					SELECT @oCurIdAlumnoCursoRecuperacion=1, @oMaxIdAlumnoCursoRecuperacion=Max(Id) FROM @VarTablaAlumnoCursoRecuperacion        
					WHILE @oMaxIdAlumnoCursoRecuperacion >= @oCurIdAlumnoCursoRecuperacion         
					BEGIN        
						BEGIN TRY        
							INSERT INTO AlumnoCursoRecuperacion (IdAlumno, IdAlumnoCurso, IdRecuperacion, IdRegistro, PromedioCondicion, PromedioFinal, PromedioReal)         
							SELECT @IdActorDestino, IdAlumnoCurso, IdRecuperacion, @IdRegistroNew, PromedioCondicion, PromedioFinal, PromedioReal        
							FROM @VarTablaAlumnoCursoRecuperacion         
							WHERE Id = @oCurIdAlumnoCursoRecuperacion         
        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'AlumnoCursoRecuperacion',        
							CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdAlumnoCurso)+','+CONVERT(VARCHAR,IdRecuperacion)+','+CONVERT(VARCHAR,IdRegistro),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdAlumnoCurso)+','+CONVERT(VARCHAR,IdRecuperacion)+','+CONVERT(VARCHAR,IdRegistro),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaAlumnoCursoRecuperacion         
							WHERE Id = @oCurIdAlumnoCursoRecuperacion         
						END TRY        
						BEGIN CATCH         
							SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'AlumnoCursoRecuperacion',        
							CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,IdAlumnoCurso)+','+CONVERT(VARCHAR,IdRecuperacion)+','+CONVERT(VARCHAR,IdRegistro),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdAlumnoCurso)+','+CONVERT(VARCHAR,IdRecuperacion)+','+CONVERT(VARCHAR,IdRegistro),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaAlumnoCursoRecuperacion         
							WHERE Id = @oCurIdAlumnoCursoRecuperacion         
						END CATCH        
               
						SET @oCurIdAlumnoCursoRecuperacion = @oCurIdAlumnoCursoRecuperacion+1         
               
					END        
              
					--CargoAlumno----------------------------------------------------------------------------------------------------------------------        
					DECLARE @VarTablaCargoAlumno TABLE (Id int, IdCargo int, IdAlumno int, IdRegistro int, IdAlumnoCurso int, IdSeccion int, UsuarioCreacion int, UsuarioModificacion int,         
					FechaCreacion datetime, FechaModificacion datetime, Asistio bit, Nota varchar(10))        
					DELETE @VarTablaCargoAlumno        
					INSERT INTO @VarTablaCargoAlumno (Id, IdCargo, IdAlumno, IdRegistro, IdAlumnoCurso, IdSeccion, Asistio, Nota, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion)         
					SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), IdCargo, @IdActorDestino, @IdRegistroNew, @IdAlumnoCurso, IdSeccion, Asistio, Nota, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion        
					FROM CargoAlumno WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld AND IdAlumnoCurso = @IdAlumnoCurso        
              
					DECLARE @oCurIdCargoAlumno INT, @oMaxIdCargoAlumno INT        
					SELECT @oCurIdCargoAlumno=1, @oMaxIdCargoAlumno=Max(Id) FROM @VarTablaCargoAlumno        
					WHILE @oMaxIdCargoAlumno >= @oCurIdCargoAlumno         
					BEGIN        
						BEGIN TRY        
							INSERT INTO CargoAlumno (IdCargo, IdAlumno, IdRegistro, IdAlumnoCurso, IdSeccion, Asistio, Nota, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion)         
							SELECT IdCargo, @IdActorDestino, @IdRegistroNew, @IdAlumnoCurso, IdSeccion, Asistio, Nota, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion        
							FROM @VarTablaCargoAlumno         
							WHERE Id = @oCurIdCargoAlumno         
        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'CargoAlumno',        
							CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,@IdAlumnoCurso)+','+CONVERT(VARCHAR,IdCargo)+','+CONVERT(VARCHAR,@IdRegistroOld),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAlumnoCurso)+','+CONVERT(VARCHAR,IdCargo)+','+CONVERT(VARCHAR,@IdRegistroNew),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaCargoAlumno         
							WHERE Id = @oCurIdCargoAlumno         
						END TRY        
						BEGIN CATCH         
							SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
							INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
							SELECT @IdProceso,'CargoAlumno',        
							CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,@IdAlumnoCurso)+','+CONVERT(VARCHAR,IdCargo)+','+CONVERT(VARCHAR,@IdRegistroOld),        
							CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAlumnoCurso)+','+CONVERT(VARCHAR,IdCargo)+','+CONVERT(VARCHAR,@IdRegistroNew),        
							@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
							FROM @VarTablaCargoAlumno         
							WHERE Id = @oCurIdCargoAlumno         
						END CATCH        
               
						SET @oCurIdCargoAlumno = @oCurIdCargoAlumno+1         
               
					END        
              
					-----------------        
					----AlumnoCursoNota, AlumnoCursoAsistencia         
					----PK IdSeccion, IdCalificacion, IdAlumno        
					----AlumnoCursoNota----------------------------------------------------------------------------------------------------------------------        
					--DECLARE @VarTablaAlumnoCursoNota TABLE (Id int, IdCargo int, IdAlumno int, IdRegistro int, IdAlumnoCurso int, IdSeccion int, UsuarioCreacion int, UsuarioModificacion int,         
					--FechaCreacion datetime, FechaModificacion datetime, Asistio bit, Nota varchar(10))        
					--DELETE @VarTablaAlumnoCursoNota        
					--INSERT INTO @VarTablaAlumnoCursoNota (Id, IdCargo, IdAlumno, IdRegistro, IdAlumnoCurso, IdSeccion, Asistio, Nota, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion)         
					--SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), IdCargo, @IdActorDestino, @IdRegistroNew, @IdAlumnoCurso, IdSeccion, Asistio, Nota, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion        
					--FROM AlumnoCursoNota WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen AND IdRegistro = @IdRegistroOld AND IdAlumnoCurso = @IdAlumnoCurso        
              
					--DECLARE @oCurIdAlumnoCursoNota INT, @oMaxIdAlumnoCursoNota INT        
					--SELECT @oCurIdAlumnoCursoNota=1, @oMaxIdAlumnoCursoNota=Max(Id) FROM @VarTablaAlumnoCursoNota        
					--WHILE @oMaxIdAlumnoCursoNota >= @oCurIdAlumnoCursoNota         
             
					--BEGIN        
					-- BEGIN TRY        
					--  INSERT INTO AlumnoCursoNota (IdCargo, IdAlumno, IdRegistro, IdAlumnoCurso, IdSeccion, Asistio, Nota, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion)         
					--  SELECT IdCargo, @IdActorDestino, @IdRegistroNew, @IdAlumnoCurso, IdSeccion, Asistio, Nota, UsuarioCreacion, FechaCreacion, UsuarioModificacion, FechaModificacion        
					--  FROM @VarTablaAlumnoCursoNota         
					--  WHERE Id = @oCurIdAlumnoCursoNota         
        
					--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
					--  SELECT @IdProceso,'AlumnoCursoNota',        
					--  CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,@IdAlumnoCurso)+','+CONVERT(VARCHAR,IdCargo)+','+CONVERT(VARCHAR,@IdRegistroOld),        
					--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAlumnoCurso)+','+CONVERT(VARCHAR,IdCargo)+','+CONVERT(VARCHAR,@IdRegistroNew),        
					--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
					--  FROM @VarTablaAlumnoCursoNota         
					--  WHERE Id = @oCurIdAlumnoCursoNota         
					-- END TRY        
					-- BEGIN CATCH         
					--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
					--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
					--  SELECT @IdProceso,'AlumnoCursoNota',        
					--  CONVERT(VARCHAR,IdAlumno)+','+CONVERT(VARCHAR,@IdAlumnoCurso)+','+CONVERT(VARCHAR,IdCargo)+','+CONVERT(VARCHAR,@IdRegistroOld),        
					--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAlumnoCurso)+','+CONVERT(VARCHAR,IdCargo)+','+CONVERT(VARCHAR,@IdRegistroNew),        
					--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
					--  FROM @VarTablaAlumnoCursoNota         
					--  WHERE Id = @oCurIdAlumnoCursoNota         
					-- END CATCH        
               
					-- SET @oCurIdAlumnoCursoNota = @oCurIdAlumnoCursoNota+1         
               
					--END        
					-------------        
              
             
					SET @oCurIdAlumnoCurso = @oCurIdAlumnoCurso+1         
              
				END        
             
				--MatriculaSeguimiento----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaMatriculaSeguimiento TABLE (Id int, ApellidoMaterno varchar(50), ApellidoPaterno varchar(50), Aula varchar(20), CantidadSesiones int, CodigoAlumno varchar(20), Coordinador varchar(100), CorreoInstituto varchar(200),         
				CorreoPersonal varchar(200), CursosConDPI varchar(20), Deuda real, Edad int, EstadoActual varchar(20), EstadoInicial varchar(20), FechaCreacion datetime, FechaInicio datetime, FechaModificacion datetime, FechaNacimiento datetime,         
				FormaInscripcion varchar(100), IdAlumno int, IdCurriculo int, IdEmpresa int, IdFacultad int, IdGrupo int, IdMatricula int, IdMatriculaSeguimiento int, IdModulo int, IdPeriodo int, IdProducto int, IdPromocion int, IdSede int,             
				IdUnidadAcademica int, IdUnidadNegocio int, InanUltimaFecha varchar(20), Inasistenca int, InasistenciaConsecutiva int, LogMatricula varchar(10), MotivoRetiro varchar(100), NombrePagante varchar(100), Nombres varchar(50),   
				Pagante varchar(50), Producto varchar(100), PromedioPonderado varchar(20), Retiro varchar(100), Seccion varchar(100), Semestre varchar(100), SubMotivoRetiro varchar(100), Telefonos varchar(200), TipoCondicion varchar(200),   
				Turno varchar(100), Tutor varchar(100), UltFechaAsistencia datetime, UsuarioCreacion int, UsuarioModificacion int, Estado int) --@6        
				DELETE @VarTablaMatriculaSeguimiento    
				
				INSERT INTO @VarTablaMatriculaSeguimiento (Id, ApellidoMaterno, ApellidoPaterno, Aula, CantidadSesiones, CodigoAlumno, Coordinador, CorreoInstituto, CorreoPersonal, CursosConDPI, Deuda, Edad, EstadoActual, EstadoInicial,         
				FechaCreacion, FechaInicio,FechaModificacion, FechaNacimiento, FormaInscripcion, IdAlumno, IdCurriculo, IdEmpresa, IdFacultad, IdGrupo, IdMatricula, IdMatriculaSeguimiento, IdModulo, IdPeriodo, IdProducto, IdPromocion, IdSede,         
				IdUnidadAcademica, IdUnidadNegocio, InanUltimaFecha, Inasistenca, InasistenciaConsecutiva, LogMatricula, MotivoRetiro, NombrePagante, Nombres, Pagante, Producto, PromedioPonderado, Retiro, Seccion, Semestre, SubMotivoRetiro,         
				Telefonos, TipoCondicion, Turno, Tutor, UltFechaAsistencia, UsuarioCreacion, UsuarioModificacion, Estado)--@6        
				SELECT ROW_NUMBER() OVER (ORDER BY IdMatriculaSeguimiento), ApellidoMaterno, ApellidoPaterno, Aula, CantidadSesiones, CodigoAlumno, Coordinador, CorreoInstituto, CorreoPersonal, CursosConDPI, Deuda, Edad, EstadoActual,      
				EstadoInicial, FechaCreacion,       
				FechaInicio, FechaModificacion, FechaNacimiento, FormaInscripcion, @IdActorDestino, IdCurriculo, IdEmpresa, IdFacultad, IdGrupo, @IdMatriculaNew, IdMatriculaSeguimiento, IdModulo, IdPeriodo,         
				IdProducto, IdPromocion, IdSede, IdUnidadAcademica, IdUnidadNegocio, InanUltimaFecha, Inasistenca, InasistenciaConsecutiva, LogMatricula, MotivoRetiro, NombrePagante, Nombres, Pagante, Producto, PromedioPonderado, Retiro, Seccion, Semestre,         








				SubMotivoRetiro, Telefonos, TipoCondicion, Turno, Tutor, UltFechaAsistencia, UsuarioCreacion, UsuarioModificacion, Estado --@6       
				FROM MatriculaSeguimiento with(nolock)  WHERE IdAlumno = @IdActorOrigen AND IdMatricula = @IdMatriculaOld         
				

				DECLARE @oCurIdMatriculaSeguimiento INT, @oMaxIdMatriculaSeguimiento INT        
				SELECT @oCurIdMatriculaSeguimiento=1, @oMaxIdMatriculaSeguimiento=Max(Id) FROM @VarTablaMatriculaSeguimiento        
				WHILE @oMaxIdMatriculaSeguimiento >= @oCurIdMatriculaSeguimiento         
				BEGIN        
					BEGIN TRY        
						INSERT INTO MatriculaSeguimiento (ApellidoMaterno, ApellidoPaterno, Aula, CantidadSesiones, CodigoAlumno, Coordinador, CorreoInstituto, CorreoPersonal, CursosConDPI, Deuda, Edad, EstadoActual, EstadoInicial, FechaCreacion, FechaInicio,         
						FechaModificacion, FechaNacimiento, FormaInscripcion, IdAlumno, IdCurriculo, IdEmpresa, IdFacultad, IdGrupo, IdMatricula, IdModulo, IdPeriodo, IdProducto, IdPromocion, IdSede, IdUnidadAcademica, IdUnidadNegocio,         
						InanUltimaFecha, Inasistenca, InasistenciaConsecutiva, LogMatricula, MotivoRetiro, NombrePagante, Nombres, Pagante, Producto, PromedioPonderado, Retiro, Seccion, Semestre, SubMotivoRetiro, Telefonos, TipoCondicion, Turno, Tutor,         
						UltFechaAsistencia, UsuarioCreacion, UsuarioModificacion, Estado) --@6         
						SELECT ApellidoMaterno, ApellidoPaterno, Aula, CantidadSesiones, CodigoAlumno, Coordinador, CorreoInstituto, CorreoPersonal, CursosConDPI, Deuda, Edad, EstadoActual, EstadoInicial, FechaCreacion, FechaInicio, FechaModificacion,         
						FechaNacimiento, FormaInscripcion, @IdActorDestino, IdCurriculo, IdEmpresa, IdFacultad, IdGrupo, @IdMatriculaNew, IdModulo, IdPeriodo, IdProducto, IdPromocion, IdSede, IdUnidadAcademica, IdUnidadNegocio,         
						InanUltimaFecha, Inasistenca, InasistenciaConsecutiva, LogMatricula, MotivoRetiro, NombrePagante, Nombres, Pagante, Producto, PromedioPonderado, Retiro, Seccion, Semestre, SubMotivoRetiro, Telefonos, TipoCondicion, Turno, Tutor,         
						UltFechaAsistencia, UsuarioCreacion, UsuarioModificacion,Estado   --@6   
						FROM @VarTablaMatriculaSeguimiento         
						WHERE   Id = @oCurIdMatriculaSeguimiento         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'MatriculaSeguimiento',        
						CONVERT(VARCHAR,IdMatriculaSeguimiento),        
						CONVERT(VARCHAR,IdMatriculaSeguimiento),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatriculaSeguimiento         
						WHERE   Id = @oCurIdMatriculaSeguimiento         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE() + '_1') --@6       
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'MatriculaSeguimiento',        
						CONVERT(VARCHAR,IdMatriculaSeguimiento),        
						CONVERT(VARCHAR,IdMatriculaSeguimiento),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatriculaSeguimiento         
						WHERE   Id = @oCurIdMatriculaSeguimiento         
					END CATCH        
              
					SET @oCurIdMatriculaSeguimiento = @oCurIdMatriculaSeguimiento+1         
              
				END --MATRICULASEGUIMIENTO        
				

				--PromocionGrupoCierre----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaPromocionGrupoCierre TABLE (Id int, CursosMatriculados int, FechaModificacion datetime, IdActor int, IdCierre int, IdGrupo int, IdMatricula int,         
				IdPromocion int, OrdenMerito int, OrdenMeritoProducto int, OrdenMeritoPromocion int, PromedioAsiste real, PromedioReal real, PromedioRealAcumulado real, TipoCondicion char(2), UsuarioModificacion int)        
				DELETE @VarTablaPromocionGrupoCierre        
				INSERT INTO @VarTablaPromocionGrupoCierre (Id, CursosMatriculados, FechaModificacion, IdActor, IdCierre, IdGrupo, IdMatricula, IdPromocion, OrdenMerito, OrdenMeritoProducto, OrdenMeritoPromocion, PromedioAsiste,         
				PromedioReal, PromedioRealAcumulado, TipoCondicion, UsuarioModificacion)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdCierre), CursosMatriculados, FechaModificacion, @IdActorDestino, IdCierre, IdGrupo, @IdMatriculaNew, IdPromocion, OrdenMerito, OrdenMeritoProducto, OrdenMeritoPromocion,         
				PromedioAsiste, PromedioReal, PromedioRealAcumulado, TipoCondicion, UsuarioModificacion        
				FROM PromocionGrupoCierre         
				with(nolock)  WHERE   IdActor = @IdActorOrigen AND IdMatricula = @IdMatriculaOld         
             
				DECLARE @IdCierreNew INT = (select max(IdCierre) from PromocionGrupoCierre)        
                  
				DECLARE @oCurIdPromocionGrupoCierre INT, @oMaxIdPromocionGrupoCierre INT        
				SELECT @oCurIdPromocionGrupoCierre=1, @oMaxIdPromocionGrupoCierre=Max(Id) FROM @VarTablaPromocionGrupoCierre        
				WHILE @oMaxIdPromocionGrupoCierre >= @oCurIdPromocionGrupoCierre         
				BEGIN        
					BEGIN TRY        
						INSERT INTO PromocionGrupoCierre (CursosMatriculados, FechaModificacion, IdActor, IdCierre, IdGrupo, IdMatricula, IdPromocion, OrdenMerito, OrdenMeritoProducto, OrdenMeritoPromocion, PromedioAsiste, PromedioReal,       
						PromedioRealAcumulado, TipoCondicion, UsuarioModificacion)         
						SELECT CursosMatriculados, FechaModificacion, @IdActorDestino, @IdCierreNew+Id, IdGrupo, @IdMatriculaNew, IdPromocion, OrdenMerito, OrdenMeritoProducto, OrdenMeritoPromocion, PromedioAsiste, PromedioReal, PromedioRealAcumulado,         
						TipoCondicion, UsuarioModificacion        
						FROM @VarTablaPromocionGrupoCierre         
						WHERE   Id = @oCurIdPromocionGrupoCierre         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'PromocionGrupoCierre',        
						CONVERT(VARCHAR,IdCierre),        
						CONVERT(VARCHAR,IdCierre),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaPromocionGrupoCierre         
						WHERE   Id = @oCurIdPromocionGrupoCierre         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'PromocionGrupoCierre',        
						CONVERT(VARCHAR,IdCierre),        
						CONVERT(VARCHAR,IdCierre),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()       
						FROM @VarTablaPromocionGrupoCierre         
						WHERE   Id = @oCurIdPromocionGrupoCierre         
					END CATCH        
              
					SET @oCurIdPromocionGrupoCierre = @oCurIdPromocionGrupoCierre+1         
              
				END --PromocionGrupoCierre        
             
				--CompromisoPago----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaCompromisoPago TABLE (Id int, Estado bit, FechaCreacion datetime, FechaModificacion datetime, FechaSolicitud datetime, IdActor int, IdCompromiso int, IdEmpresa int, IdMatricula int, IdSede int,         
				Observacion varchar(500), UsuarioCreacion int, UsuarioModificacion int)        
				DELETE @VarTablaCompromisoPago        
				INSERT INTO @VarTablaCompromisoPago (Id, Estado, FechaCreacion, FechaModificacion, FechaSolicitud, IdActor, IdCompromiso, IdEmpresa, IdMatricula, IdSede, Observacion, UsuarioCreacion, UsuarioModificacion)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdCompromiso), Estado, FechaCreacion, FechaModificacion, FechaSolicitud, @IdActorDestino, IdCompromiso, IdEmpresa, @IdMatriculaNew, IdSede, Observacion, UsuarioCreacion, UsuarioModificacion        
				FROM CompromisoPago with(nolock)  WHERE   IdActor = @IdActorOrigen AND IdMatricula = @IdMatriculaOld         
             
				DECLARE @oCurIdCompromisoPago INT, @oMaxIdCompromisoPago INT        
				SELECT @oCurIdCompromisoPago=1, @oMaxIdCompromisoPago=Max(Id) FROM @VarTablaCompromisoPago        
				WHILE @oMaxIdCompromisoPago >= @oCurIdCompromisoPago         

				BEGIN        
					BEGIN TRY        
						INSERT INTO CompromisoPago (Estado, FechaCreacion, FechaModificacion, FechaSolicitud, IdActor, IdEmpresa, IdMatricula, IdSede, Observacion, UsuarioCreacion, UsuarioModificacion)         
						SELECT Estado, FechaCreacion, FechaModificacion, FechaSolicitud, @IdActorDestino, IdEmpresa, @IdMatriculaNew, IdSede, Observacion, UsuarioCreacion, UsuarioModificacion        
						FROM @VarTablaCompromisoPago         
						WHERE   Id = @oCurIdCompromisoPago         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'CompromisoPago',        
						CONVERT(VARCHAR,IdCompromiso),        
						CONVERT(VARCHAR,IdCompromiso),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaCompromisoPago         
						WHERE   Id = @oCurIdCompromisoPago         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'CompromisoPago',        
						CONVERT(VARCHAR,IdCompromiso),        
						CONVERT(VARCHAR,IdCompromiso),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaCompromisoPago         
						WHERE   Id = @oCurIdCompromisoPago         
					END CATCH        
              
					SET @oCurIdCompromisoPago = @oCurIdCompromisoPago+1         
              
				END --CompromisoPago        
             
				--ConstanciaPagos----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaConstanciaPagos TABLE (Id int, Estado bit, FechaCreacion datetime, FechaModificacion datetime, FechaSolicitud datetime, IdActor int, IdConstancia int, IdEmpresa int, IdMatricula int, IdSede int,         
				Observacion varchar(500), UsuarioCreacion int, UsuarioModificacion int)        
				DELETE @VarTablaConstanciaPagos        
				INSERT INTO @VarTablaConstanciaPagos (Id, Estado, FechaCreacion, FechaModificacion, FechaSolicitud, IdActor, IdConstancia, IdEmpresa, IdMatricula, IdSede, Observacion, UsuarioCreacion, UsuarioModificacion)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdConstancia), Estado, FechaCreacion, FechaModificacion, FechaSolicitud, @IdActorDestino, IdConstancia, IdEmpresa, @IdMatriculaNew, IdSede, Observacion, UsuarioCreacion, UsuarioModificacion        
				FROM ConstanciaPagos         
				with(nolock)  WHERE   IdActor = @IdActorOrigen AND IdMatricula = @IdMatriculaOld         
             
				DECLARE @oCurIdConstanciaPagos INT, @oMaxIdConstanciaPagos INT        
				SELECT @oCurIdConstanciaPagos=1, @oMaxIdConstanciaPagos=Max(Id) FROM @VarTablaConstanciaPagos        
				WHILE @oMaxIdConstanciaPagos >= @oCurIdConstanciaPagos         
				BEGIN        
					BEGIN TRY        
						INSERT INTO ConstanciaPagos (Estado, FechaCreacion, FechaModificacion, FechaSolicitud, IdActor, IdEmpresa, IdMatricula, IdSede, Observacion, UsuarioCreacion, UsuarioModificacion)         
						SELECT Estado, FechaCreacion, FechaModificacion, FechaSolicitud, @IdActorDestino, IdEmpresa, @IdMatriculaNew, IdSede, Observacion, UsuarioCreacion, UsuarioModificacion        
						FROM @VarTablaConstanciaPagos         
						WHERE   Id = @oCurIdConstanciaPagos         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'ConstanciaPagos',        
						CONVERT(VARCHAR,IdConstancia),        
						CONVERT(VARCHAR,IdConstancia),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaConstanciaPagos         
						WHERE   Id = @oCurIdConstanciaPagos         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'ConstanciaPagos',        
						CONVERT(VARCHAR,IdConstancia),        
						CONVERT(VARCHAR,IdConstancia),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaConstanciaPagos         
						WHERE   Id = @oCurIdConstanciaPagos         
					END CATCH        
              
					SET @oCurIdConstanciaPagos = @oCurIdConstanciaPagos+1         
              
				END --ConstanciaPagos        
             
				----AlumnoSeguimiento----------------------------------------------------------------------------------------------------------------------        
				--DECLARE @VarTablaAlumnoSeguimiento TABLE (Id int, ApellidoMaterno varchar(50), ApellidoPaterno varchar(50), Aula varchar(20), CantidadSesiones int, CodigoAlumno varchar(20), Coordinador varchar(200), CorreoInstituto varchar(200),         
				--CorreoPersonal varchar(200), CursosConDPI varchar(20), Deuda varchar(500), Edad int, EstadoActual varchar(20), EstadoInicial varchar(20), FechaCreacion datetime, FechaInicio datetime, FechaModificacion datetime, FechaNacimiento datetime,         
				--FormaInscripcion varchar(100), IdAlumno int, IdAlumnoSeguimiento int, IdCurriculo int, IdEmpresa int, IdFacultad int, IdGrupo int, IdMatricula int, IdModulo int, IdPeriodo int, IdProducto int, IdPromocion int, IdSede int, IdUnidadAcademica int,    





    
				--IdUnidadNegocio int, Inasistenca int, InasistenciaConsecutiva int, MotivoRetiro varchar(100), NombrePagante varchar(100), Nombres varchar(50), Pagante varchar(50), Producto varchar(100), PromedioPonderado varchar(20), Retiro varchar(100),         
				--Seccion varchar(100), Semestre varchar(100), SubMotivoRetiro varchar(100), Telefonos varchar(200), TipoCondicion varchar(20), Turno varchar(100), Tutor varchar(200), UltFechaAsistencia datetime, UltimaMatricula varchar(100),         
				--UsuarioCreacion int, UsuarioModificacion int)        
				--DELETE @VarTablaAlumnoSeguimiento        
				--INSERT INTO @VarTablaAlumnoSeguimiento (Id, ApellidoMaterno, ApellidoPaterno, Aula, CantidadSesiones, CodigoAlumno, Coordinador, CorreoInstituto, CorreoPersonal, CursosConDPI, Deuda, Edad, EstadoActual, EstadoInicial, FechaCreacion,         
				--FechaInicio, FechaModificacion, FechaNacimiento, FormaInscripcion, IdAlumno, IdAlumnoSeguimiento, IdCurriculo, IdEmpresa, IdFacultad, IdGrupo, IdMatricula, IdModulo, IdPeriodo, IdProducto, IdPromocion, IdSede, IdUnidadAcademica, IdUnidadNegocio,   








				--Inasistenca, InasistenciaConsecutiva, MotivoRetiro, NombrePagante, Nombres, Pagante, Producto, PromedioPonderado, Retiro, Seccion, Semestre, SubMotivoRetiro, Telefonos, TipoCondicion, Turno, Tutor, UltFechaAsistencia, UltimaMatricula,         
				--UsuarioCreacion, UsuarioModificacion)        
				--SELECT ROW_NUMBER() OVER (ORDER BY IdAlumnoSeguimiento), ApellidoMaterno, ApellidoPaterno, Aula, CantidadSesiones, CodigoAlumno, Coordinador, CorreoInstituto, CorreoPersonal, CursosConDPI, Deuda, Edad, EstadoActual, EstadoInicial,         
				--FechaCreacion, FechaInicio, FechaModificacion,         
				--FechaNacimiento, FormaInscripcion, @IdActorDestino, IdAlumnoSeguimiento, IdCurriculo, IdEmpresa, IdFacultad, IdGrupo, @IdMatriculaNew, IdModulo, IdPeriodo, IdProducto, IdPromocion, IdSede, IdUnidadAcademica, IdUnidadNegocio, Inasistenca,         
				--InasistenciaConsecutiva, MotivoRetiro, NombrePagante, Nombres, Pagante, Producto, PromedioPonderado, Retiro, Seccion, Semestre, SubMotivoRetiro, Telefonos, TipoCondicion, Turno, Tutor, UltFechaAsistencia, UltimaMatricula, UsuarioCreacion,         
				--UsuarioModificacion        
				--FROM AlumnoSeguimiento         
				-- with(nolock)  WHERE   IdAlumno = @IdActorOrigen AND IdMatricula = @IdMatriculaOld             
				--DECLARE @IdAlumnoSeguimientoOld INT, @IdMaxAlumnoSeguimiento INT        
				--SET @IdMaxAlumnoSeguimiento = (SELECT MAX(IdAlumnoSeguimiento)FROM AlumnoSeguimiento)                      
				--DECLARE @oCurIdAlumnoSeguimiento INT, @oMaxIdAlumnoSeguimiento INT, @IdAlumnoSeguimientoNew INT        
				--SELECT @oCurIdAlumnoSeguimiento=1, @oMaxIdAlumnoSeguimiento=Max(Id) FROM @VarTablaAlumnoSeguimiento        
				--WHILE @oMaxIdAlumnoSeguimiento >= @oCurIdAlumnoSeguimiento                      
				--BEGIN        
				-- BEGIN TRY        
				--  SET @IdAlumnoSeguimientoNew = (SELECT (@IdMaxAlumnoSeguimiento+Id) FROM @VarTablaAlumnoSeguimiento WHERE id = @oCurIdAlumnoSeguimiento)        
				--  SET @IdAlumnoSeguimientoOld = (SELECT IdAlumnoSeguimiento FROM @VarTablaAlumnoSeguimiento WHERE id = @oCurIdAlumnoSeguimiento)        
				--  INSERT INTO AlumnoSeguimiento (ApellidoMaterno, ApellidoPaterno, Aula, CantidadSesiones, CodigoAlumno, Coordinador, CorreoInstituto, CorreoPersonal, CursosConDPI, Deuda, Edad, EstadoActual, EstadoInicial, FechaCreacion, FechaInicio,         
				--  FechaModificacion, FechaNacimiento, FormaInscripcion, IdAlumno, IdAlumnoSeguimiento, IdCurriculo, IdEmpresa, IdFacultad, IdGrupo, IdMatricula, IdModulo, IdPeriodo, IdProducto, IdPromocion, IdSede, IdUnidadAcademica, IdUnidadNegocio,         
				--  Inasistenca, InasistenciaConsecutiva, MotivoRetiro, NombrePagante, Nombres, Pagante, Producto, PromedioPonderado, Retiro, Seccion, Semestre, SubMotivoRetiro, Telefonos, TipoCondicion, Turno, Tutor, UltFechaAsistencia, UltimaMatricula,         
				--  UsuarioCreacion, UsuarioModificacion)         
				--  SELECT ApellidoMaterno, ApellidoPaterno, Aula, CantidadSesiones, CodigoAlumno, Coordinador, CorreoInstituto, CorreoPersonal, CursosConDPI, Deuda, Edad, EstadoActual, EstadoInicial, FechaCreacion, FechaInicio, FechaModificacion,         
				--  FechaNacimiento, FormaInscripcion, @IdActorDestino, @IdAlumnoSeguimientoNew, IdCurriculo, IdEmpresa, IdFacultad, IdGrupo, @IdMatriculaNew, IdModulo, IdPeriodo, IdProducto, IdPromocion, IdSede, IdUnidadAcademica, IdUnidadNegocio, Inasistenca,    
				--  InasistenciaConsecutiva, MotivoRetiro, NombrePagante, Nombres, Pagante, Producto, PromedioPonderado, Retiro, Seccion, Semestre, SubMotivoRetiro, Telefonos, TipoCondicion, Turno, Tutor, UltFechaAsistencia, UltimaMatricula,         
				--  UsuarioCreacion, UsuarioModificacion        
				--  FROM @VarTablaAlumnoSeguimiento         
				--  WHERE   Id = @oCurIdAlumnoSeguimiento         
				--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				--  SELECT @IdProceso,'AlumnoSeguimiento',        
				--  CONVERT(VARCHAR,@IdAlumnoSeguimientoOld),        
				--  CONVERT(VARCHAR,IdAlumnoSeguimiento),        
				--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				--  FROM @VarTablaAlumnoSeguimiento         
				--  WHERE   Id = @oCurIdAlumnoSeguimiento         
				-- END TRY        
				-- BEGIN CATCH         
				--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				--  SELECT @IdProceso,'AlumnoSeguimiento',        
				--  CONVERT(VARCHAR,@IdAlumnoSeguimientoOld),        
				--  CONVERT(VARCHAR,IdAlumnoSeguimiento),        
				--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				--  FROM @VarTablaAlumnoSeguimiento         
				--  WHERE   Id = @oCurIdAlumnoSeguimiento         
				-- END CATCH        
				-- --AlumnoSeguimientoInasistencia----------------------------------------------------------------------------------------------------------------------        
				-- DECLARE @VarTablaAlumnoSeguimientoInasistencia TABLE (Id int, FechaCreacion datetime, FechaFin datetime, FechaInicio datetime, FechaModificacion datetime, IdAlumnoSeguimiento int, IdSemana int, PorcentajeAsistencia real,         
				-- PromedioPonderado varchar(20), Semana varchar(20), TotalInasistencias int, TotalSesiones int, UsuarioCreacion int, UsuarioModificacion int)        
				-- DELETE @VarTablaAlumnoSeguimientoInasistencia        
				-- INSERT INTO @VarTablaAlumnoSeguimientoInasistencia (Id, FechaCreacion, FechaFin, FechaInicio, FechaModificacion, IdAlumnoSeguimiento, IdSemana, PorcentajeAsistencia, PromedioPonderado, Semana, TotalInasistencias,         
				-- TotalSesiones, UsuarioCreacion, UsuarioModificacion)        
				-- SELECT ROW_NUMBER() OVER (ORDER BY IdAlumnoSeguimiento), FechaCreacion, FechaFin, FechaInicio, FechaModificacion, IdAlumnoSeguimiento, IdSemana, PorcentajeAsistencia, PromedioPonderado, Semana, TotalInasistencias,         
				-- TotalSesiones, UsuarioCreacion, UsuarioModificacion        
				-- FROM AlumnoSeguimientoInasistencia         
				--  with(nolock)  WHERE  IdAlumnoSeguimiento = @IdAlumnoSeguimientoOld         
				-- DECLARE @IdSemana INT        
				-- DECLARE @oCurIdAlumnoSeguimientoInasistencia INT, @oMaxIdAlumnoSeguimientoInasistencia INT        
				-- SELECT @oCurIdAlumnoSeguimientoInasistencia=1, @oMaxIdAlumnoSeguimientoInasistencia=Max(Id) FROM @VarTablaAlumnoSeguimientoInasistencia        
				-- WHILE @oMaxIdAlumnoSeguimientoInasistencia >= @oCurIdAlumnoSeguimientoInasistencia         
				-- BEGIN        
				--  BEGIN TRY        
				--   SET @IdSemana = (SELECT IdSemana FROM @VarTablaAlumnoSeguimientoInasistencia WHERE id = @oCurIdAlumnoSeguimientoInasistencia)        
				--   INSERT INTO AlumnoSeguimientoInasistencia (FechaCreacion, FechaFin, FechaInicio, FechaModificacion, IdAlumnoSeguimiento, IdSemana, PorcentajeAsistencia, PromedioPonderado, Semana, TotalInasistencias, TotalSesiones,         
				--   UsuarioCreacion, UsuarioModificacion)         
				--   SELECT FechaCreacion, FechaFin, FechaInicio, FechaModificacion, @IdAlumnoSeguimientoNew, IdSemana, PorcentajeAsistencia, PromedioPonderado, Semana, TotalInasistencias, TotalSesiones, UsuarioCreacion, UsuarioModificacion        
				--   FROM @VarTablaAlumnoSeguimientoInasistencia         
				--   WHERE   Id = @oCurIdAlumnoSeguimientoInasistencia         
				--   INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				--   SELECT @IdProceso,'AlumnoSeguimientoInasistencia',        
				--   CONVERT(VARCHAR,@IdAlumnoSeguimientoOld)+', '+CONVERT(VARCHAR,IdSemana),        
				--   CONVERT(VARCHAR,@IdAlumnoSeguimientoNew)+', '+CONVERT(VARCHAR,IdSemana),        
				--   @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				--   FROM @VarTablaAlumnoSeguimientoInasistencia         
				--   WHERE   Id = @oCurIdAlumnoSeguimientoInasistencia         
				--  END TRY        
				--  BEGIN CATCH         
				--   SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				--   INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				--   SELECT @IdProceso,'AlumnoSeguimientoInasistencia',        
				--   CONVERT(VARCHAR,@IdAlumnoSeguimientoOld)+', '+CONVERT(VARCHAR,IdSemana),        
				--   CONVERT(VARCHAR,@IdAlumnoSeguimientoNew)+', '+CONVERT(VARCHAR,IdSemana),        
				--   @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				--   FROM @VarTablaAlumnoSeguimientoInasistencia         
				--   WHERE   Id = @oCurIdAlumnoSeguimientoInasistencia         
				--  END CATCH  
				--  --AlumnoSeguimientoInasistenciaDetalle----------------------------------------------------------------------------------------------------------------------        
				--  DECLARE @VarTablaAlumnoSeguimientoInasistenciaDetalle TABLE (Id int, IdAlumnoSeguimiento int, IdSemana int, IdSeccion int, IdCurso int, TotalInasistencias int, TotalSesiones int, EsDPI int, UsuarioCreacion int,         
				--  UsuarioModificacion int, PorcentajeAsistencia real, FechaInicio datetime, FechaFin datetime, FechaCreacion datetime, FechaModificacion datetime, Semana varchar(20), PromedioPonderado varchar(20))        
				--  DELETE @VarTablaAlumnoSeguimientoInasistenciaDetalle        
				--  INSERT INTO @VarTablaAlumnoSeguimientoInasistenciaDetalle (Id, IdAlumnoSeguimiento, IdSemana, IdSeccion, IdCurso, TotalInasistencias, TotalSesiones, EsDPI,         
				--  UsuarioCreacion, UsuarioModificacion, PorcentajeAsistencia, FechaInicio, FechaFin, FechaCreacion, FechaModificacion, Semana, PromedioPonderado)        
				--  SELECT ROW_NUMBER() OVER (ORDER BY IdAlumnoSeguimiento), @IdAlumnoSeguimientoNew, IdSemana, IdSeccion, IdCurso, TotalInasistencias, TotalSesiones, EsDPI,         
				--  UsuarioCreacion, UsuarioModificacion, PorcentajeAsistencia, FechaInicio, FechaFin, FechaCreacion, FechaModificacion, Semana, PromedioPonderado        
				--  FROM AlumnoSeguimientoInasistenciaDetalle         
				--   with(nolock)  WHERE  IdAlumnoSeguimiento = @IdAlumnoSeguimientoOld and IdSemana = @IdSemana        
				--  DECLARE @oCurIdAlumnoSeguimientoInasistenciaDetalle INT, @oMaxIdAlumnoSeguimientoInasistenciaDetalle INT        
				--  SELECT @oCurIdAlumnoSeguimientoInasistenciaDetalle=1, @oMaxIdAlumnoSeguimientoInasistenciaDetalle=Max(Id) FROM @VarTablaAlumnoSeguimientoInasistenciaDetalle        
				--  WHILE @oMaxIdAlumnoSeguimientoInasistenciaDetalle >= @oCurIdAlumnoSeguimientoInasistenciaDetalle    
				--  BEGIN        
				--   BEGIN TRY        
				--    INSERT INTO AlumnoSeguimientoInasistenciaDetalle (IdAlumnoSeguimiento, IdSemana, IdSeccion, IdCurso, TotalInasistencias, TotalSesiones, EsDPI,         
				--    UsuarioCreacion, UsuarioModificacion, PorcentajeAsistencia, FechaInicio, FechaFin, FechaCreacion, FechaModificacion, Semana, PromedioPonderado)         
				--    SELECT IdAlumnoSeguimiento, IdSemana, IdSeccion, IdCurso, TotalInasistencias, TotalSesiones, EsDPI,         
				--    UsuarioCreacion, UsuarioModificacion, PorcentajeAsistencia, FechaInicio, FechaFin, FechaCreacion, FechaModificacion, Semana, PromedioPonderado        
				--    FROM @VarTablaAlumnoSeguimientoInasistenciaDetalle         
				--    WHERE   Id = @oCurIdAlumnoSeguimientoInasistenciaDetalle         
				--    INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				--    SELECT @IdProceso,'AlumnoSeguimientoInasistenciaDetalle',        
				--    CONVERT(VARCHAR,@IdAlumnoSeguimientoNew)+', '+CONVERT(VARCHAR,IdSemana),        
				--    CONVERT(VARCHAR,@IdAlumnoSeguimientoOld)+', '+CONVERT(VARCHAR,IdSemana),        
				--    @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				--    FROM @VarTablaAlumnoSeguimientoInasistenciaDetalle         
				--    WHERE   Id = @oCurIdAlumnoSeguimientoInasistenciaDetalle         
				--   END TRY        
				--   BEGIN CATCH         
				--    SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				--    INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				--    SELECT @IdProceso,'AlumnoSeguimientoInasistenciaDetalle',        
				--    CONVERT(VARCHAR,@IdAlumnoSeguimientoNew)+', '+CONVERT(VARCHAR,IdSemana),        
				--    CONVERT(VARCHAR,@IdAlumnoSeguimientoOld)+', '+CONVERT(VARCHAR,IdSemana),        
				--    @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				--    FROM @VarTablaAlumnoSeguimientoInasistenciaDetalle         
				--    WHERE   Id = @oCurIdAlumnoSeguimientoInasistenciaDetalle         
				--   END CATCH        
				--   SET @oCurIdAlumnoSeguimientoInasistenciaDetalle = @oCurIdAlumnoSeguimientoInasistenciaDetalle+1         
				--  END        
				--  SET @oCurIdAlumnoSeguimientoInasistencia = @oCurIdAlumnoSeguimientoInasistencia+1         
				-- END             
				-- SET @oCurIdAlumnoSeguimiento = @oCurIdAlumnoSeguimiento+1         
				--END --AlumnoSeguimiento        
				--MatriculaAutorizacion----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaMatriculaAutorizacion TABLE (Id int,Estado char(1), FechaCreacion datetime, FechaModificacion datetime, IdActor int, IdAutorizacion int, IdCierre int, IdConvalidacion int, IdCurricula int, IdEmpresa int, IdGrupo int,         
				IdMatricula int, IdModulo int, IdMoneda int, IdPeriodoAnual int, IdPlanPago int, IdProducto int, IdPromocion int, IdRegistro int, IdSede int, MontoMoneda real, Numero varchar(20), Observacion varchar(500), TipoCondicion char(2),     
				TipoServicio char(1), UsuarioCreacion int, UsuarioModificacion int)        
				DELETE @VarTablaMatriculaAutorizacion        
				INSERT INTO @VarTablaMatriculaAutorizacion (Id, Estado, FechaCreacion, FechaModificacion, IdActor, IdAutorizacion, IdCierre, IdConvalidacion, IdCurricula, IdEmpresa, IdGrupo, IdMatricula, IdModulo, IdMoneda, IdPeriodoAnual,         
				IdPlanPago, IdProducto, IdPromocion, IdRegistro, IdSede, MontoMoneda, Numero, Observacion, TipoCondicion, TipoServicio, UsuarioCreacion, UsuarioModificacion)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdAutorizacion), Estado, FechaCreacion, FechaModificacion, @IdActorDestino, IdAutorizacion, IdCierre, IdConvalidacion, IdCurricula, IdEmpresa, IdGrupo, @IdMatriculaNew, IdModulo, IdMoneda,         
				IdPeriodoAnual, IdPlanPago, IdProducto, IdPromocion, IdRegistro, IdSede, MontoMoneda, Numero, Observacion, TipoCondicion, TipoServicio, UsuarioCreacion, UsuarioModificacion        
				FROM MatriculaAutorizacion         
				with(nolock)  WHERE   IdActor = @IdActorOrigen AND IdMatricula = @IdMatriculaOld         
             
				DECLARE @oCurIdMatriculaAutorizacion INT, @oMaxIdMatriculaAutorizacion INT        
				SELECT @oCurIdMatriculaAutorizacion=1, @oMaxIdMatriculaAutorizacion=Max(Id) FROM @VarTablaMatriculaAutorizacion        
				WHILE @oMaxIdMatriculaAutorizacion >= @oCurIdMatriculaAutorizacion         
             
				BEGIN        
					BEGIN TRY        
						INSERT INTO MatriculaAutorizacion (Estado, FechaCreacion, FechaModificacion, IdActor, IdAutorizacion, IdCierre, IdConvalidacion, IdCurricula, IdEmpresa, IdGrupo, IdMatricula, IdModulo, IdMoneda, IdPeriodoAnual, IdPlanPago, IdProducto,         
						IdPromocion, IdRegistro, IdSede, MontoMoneda, Numero, Observacion, TipoCondicion, TipoServicio, UsuarioCreacion, UsuarioModificacion)         
						SELECT Estado, FechaCreacion, FechaModificacion, @IdActorDestino, IdAutorizacion, IdCierre, IdConvalidacion, IdCurricula, IdEmpresa, IdGrupo, @IdMatriculaNew, IdModulo, IdMoneda, IdPeriodoAnual, IdPlanPago, IdProducto, IdPromocion,         
						IdRegistro, IdSede, MontoMoneda, Numero, Observacion, TipoCondicion, TipoServicio, UsuarioCreacion, UsuarioModificacion        
						FROM @VarTablaMatriculaAutorizacion         
						WHERE   Id = @oCurIdMatriculaAutorizacion         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'MatriculaAutorizacion',        
						CONVERT(VARCHAR,IdAutorizacion),        
						CONVERT(VARCHAR,IdAutorizacion),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatriculaAutorizacion         
						WHERE   Id = @oCurIdMatriculaAutorizacion         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'MatriculaAutorizacion',        
						CONVERT(VARCHAR,IdAutorizacion),        
						CONVERT(VARCHAR,IdAutorizacion),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatriculaAutorizacion         
						WHERE   Id = @oCurIdMatriculaAutorizacion         
					END CATCH        
              
					SET @oCurIdMatriculaAutorizacion = @oCurIdMatriculaAutorizacion+1         
              
				END --MatriculaAutorizacion        
             
				--MatriculaRetiro----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaMatriculaRetiro TABLE (Id int, DocumentoFecha datetime, DocumentoNumero varchar(20), EsFacturacion bit, Estado char(1), FechaCreacion datetime, FechaMaxAsistencia datetime, FechaModificacion datetime, IdActor int,         
				IdEmpresa int, IdFacultad int, IdMatricula int, IdMotivo int, IdPeriodo int, IdProducto int, IdRegistro int, IdRetiro int, IdSede int, IdSubMotivo int, IdUnidadAcademica int, IdUnidadNegocio int, Numero varchar(20),         
				Observacion varchar(500), ObservacionAnulacion varchar(500), Tipo char(2), UsuarioCreacion int, UsuarioModificacion int)        
				DELETE @VarTablaMatriculaRetiro        
				INSERT INTO @VarTablaMatriculaRetiro (Id, DocumentoFecha, DocumentoNumero, EsFacturacion, Estado, FechaCreacion, FechaMaxAsistencia, FechaModificacion, IdActor, IdEmpresa, IdFacultad, IdMatricula, IdMotivo, IdPeriodo, IdProducto, 
				IdRegistro, IdRetiro, IdSede, IdSubMotivo, IdUnidadAcademica, IdUnidadNegocio,         
				Numero, Observacion, ObservacionAnulacion, Tipo, UsuarioCreacion, UsuarioModificacion)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdRetiro), DocumentoFecha, DocumentoNumero, EsFacturacion, Estado, FechaCreacion, FechaMaxAsistencia, FechaModificacion, @IdActorDestino, IdEmpresa, IdFacultad, @IdMatriculaNew, IdMotivo, IdPeriodo,         
				IdProducto, IdRegistro, IdRetiro, IdSede, IdSubMotivo, IdUnidadAcademica, IdUnidadNegocio,         
				Numero, Observacion, ObservacionAnulacion, Tipo, UsuarioCreacion, UsuarioModificacion        
				FROM MatriculaRetiro with(nolock)  WHERE   IdActor = @IdActorOrigen AND IdMatricula = @IdMatriculaOld         
             
				declare @IdRetiroMax int = (select max(IdRetiro) from MatriculaRetiro WITH(NOLOCK))        
				DECLARE @oCurIdMatriculaRetiro INT, @oMaxIdMatriculaRetiro INT        
				SELECT @oCurIdMatriculaRetiro=1, @oMaxIdMatriculaRetiro=Max(Id) FROM @VarTablaMatriculaRetiro        
				WHILE @oMaxIdMatriculaRetiro >= @oCurIdMatriculaRetiro           
				BEGIN        
					BEGIN TRY        
						INSERT INTO MatriculaRetiro (DocumentoFecha, DocumentoNumero, EsFacturacion, Estado, FechaCreacion, FechaMaxAsistencia, FechaModificacion, IdActor, IdEmpresa, IdFacultad, IdMatricula, IdMotivo, IdPeriodo, IdProducto,         
						IdRegistro, IdRetiro, IdSede, IdSubMotivo, IdUnidadAcademica, IdUnidadNegocio,         
						Numero, Observacion, ObservacionAnulacion, Tipo, UsuarioCreacion, UsuarioModificacion)         
						SELECT DocumentoFecha, DocumentoNumero, EsFacturacion, Estado, FechaCreacion, FechaMaxAsistencia, FechaModificacion, @IdActorDestino, IdEmpresa, IdFacultad, @IdMatriculaNew, IdMotivo, IdPeriodo, IdProducto, IdRegistro,         
						@IdRetiroMax+Id, IdSede, IdSubMotivo, IdUnidadAcademica, IdUnidadNegocio, Numero, Observacion, ObservacionAnulacion, Tipo, UsuarioCreacion, UsuarioModificacion        
						FROM @VarTablaMatriculaRetiro         
						WHERE   Id = @oCurIdMatriculaRetiro         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'MatriculaRetiro',        
						CONVERT(VARCHAR,IdRetiro),        
						CONVERT(VARCHAR,IdRetiro),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatriculaRetiro         
						WHERE   Id = @oCurIdMatriculaRetiro         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'MatriculaRetiro',        
						CONVERT(VARCHAR,IdRetiro),        
						CONVERT(VARCHAR,IdRetiro),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatriculaRetiro         
						WHERE   Id = @oCurIdMatriculaRetiro         
					END CATCH        
              
					SET @oCurIdMatriculaRetiro = @oCurIdMatriculaRetiro+1         
              
				END --MatriculaRetiro        
            
				--MatriculaPagante----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaMatriculaPagante TABLE (Id int, EsContado bit, Estado char(1), FacturaPorCupon bit, FechaModificacion datetime, IdActor int, IdMatricula int, IdMoneda int, Monto real,             
				Porcentaje real, TipoPersona char(1), UsuarioModificacion int)          
				DELETE @VarTablaMatriculaPagante        
				INSERT INTO @VarTablaMatriculaPagante (Id, EsContado, Estado, FacturaPorCupon, FechaModificacion, IdActor, IdMatricula, IdMoneda, Monto, Porcentaje, TipoPersona, UsuarioModificacion)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdMatricula), EsContado, Estado, FacturaPorCupon, FechaModificacion, @IdActorDestino, @IdMatriculaNew, IdMoneda, Monto, Porcentaje, TipoPersona, UsuarioModificacion        
				FROM MatriculaPagante         
				with(nolock)  WHERE   IdActor = @IdActorOrigen AND IdMatricula = @IdMatriculaOld         
             
				DECLARE @oCurIdMatriculaPagante INT, @oMaxIdMatriculaPagante INT        
				SELECT @oCurIdMatriculaPagante=1, @oMaxIdMatriculaPagante=Max(Id) FROM @VarTablaMatriculaPagante        
				WHILE @oMaxIdMatriculaPagante >= @oCurIdMatriculaPagante  
				BEGIN        
					BEGIN TRY        
						INSERT INTO MatriculaPagante (EsContado, Estado, FacturaPorCupon, FechaModificacion, IdActor, IdMatricula, IdMoneda, Monto, Porcentaje, TipoPersona, UsuarioModificacion)         
						SELECT EsContado, Estado, FacturaPorCupon, FechaModificacion, @IdActorDestino, @IdMatriculaNew, IdMoneda, Monto, Porcentaje, TipoPersona, UsuarioModificacion        
						FROM @VarTablaMatriculaPagante         
						WHERE   Id = @oCurIdMatriculaPagante         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'MatriculaPagante',        
						CONVERT(VARCHAR,@IdMatriculaOld)+', '+CONVERT(VARCHAR,@IdActorOrigen),        
						CONVERT(VARCHAR,@IdMatriculaNew)+', '+CONVERT(VARCHAR,@IdActorDestino),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatriculaPagante         
						WHERE   Id = @oCurIdMatriculaPagante         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'MatriculaPagante',        
						CONVERT(VARCHAR,@IdMatriculaOld)+', '+CONVERT(VARCHAR,@IdActorOrigen),        
						CONVERT(VARCHAR,@IdMatriculaNew)+', '+CONVERT(VARCHAR,@IdActorDestino),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaMatriculaPagante         
						WHERE   Id = @oCurIdMatriculaPagante         
					END CATCH        
              
					SET @oCurIdMatriculaPagante = @oCurIdMatriculaPagante+1         
              
				END --MatriculaPagante        
            
				--ActorFacturacion----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaActorFacturacion TABLE (Id int, DireccionCompleta varchar(200), EsOtroIngreso bit, FechaDocumento datetime, FechaModificacion datetime, IdActor int, IdFacturacion int, IdMatricula int, IdTipoDocumento int, IdUbigeo int,         
				Monto real, NoDocumento varchar(20), NoSerie varchar(20), Porcentaje real, RazonSocial varchar(100), RucDni varchar(20), Telefono varchar(20), TipoCambio real, TipoCambioFinanciero real, UsuarioModificacion int)        
				DELETE @VarTablaActorFacturacion        
				INSERT INTO @VarTablaActorFacturacion (Id, DireccionCompleta, EsOtroIngreso, FechaDocumento, FechaModificacion, IdActor, IdFacturacion, IdMatricula, IdTipoDocumento, IdUbigeo, Monto, NoDocumento, NoSerie, Porcentaje, RazonSocial,         
				RucDni, Telefono, TipoCambio, TipoCambioFinanciero, UsuarioModificacion)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdFacturacion), DireccionCompleta, EsOtroIngreso, FechaDocumento, FechaModificacion, @IdActorDestino, IdFacturacion, @IdMatriculaNew, IdTipoDocumento, IdUbigeo, Monto, NoDocumento, NoSerie, Porcentaje, RazonSocial,






				RucDni, Telefono, TipoCambio, TipoCambioFinanciero, UsuarioModificacion        
				FROM ActorFacturacion         
				with(nolock)  WHERE   IdActor = @IdActorOrigen AND IdMatricula = @IdMatriculaOld         
             
				UPDATE @VarTablaActorFacturacion set IdFacturacion = IdFacturacion+(select ISNULL(MAX(IdFacturacion),1) from ActorFacturacion WITH(NOLOCK) where IdActor = @IdActorDestino)        
                  
				DECLARE @oCurIdActorFacturacion INT, @oMaxIdActorFacturacion INT        
				SELECT @oCurIdActorFacturacion=1, @oMaxIdActorFacturacion=Max(Id) FROM @VarTablaActorFacturacion        
				WHILE @oMaxIdActorFacturacion >= @oCurIdActorFacturacion         
				BEGIN        
					BEGIN TRY        
						INSERT INTO ActorFacturacion (DireccionCompleta, EsOtroIngreso, FechaDocumento, FechaModificacion, IdActor, IdFacturacion, IdMatricula, IdTipoDocumento, IdUbigeo, Monto, NoDocumento, NoSerie, Porcentaje, RazonSocial, RucDni,         
						Telefono, TipoCambio, TipoCambioFinanciero, UsuarioModificacion)         
						SELECT DireccionCompleta, EsOtroIngreso, FechaDocumento, FechaModificacion, IdActor, IdFacturacion, IdMatricula, IdTipoDocumento, IdUbigeo, Monto, NoDocumento, NoSerie, Porcentaje, RazonSocial, RucDni, Telefono, TipoCambio,         
						TipoCambioFinanciero, UsuarioModificacion        
						FROM @VarTablaActorFacturacion         
						WHERE   Id = @oCurIdActorFacturacion         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'ActorFacturacion',        
						CONVERT(VARCHAR,@IdMatriculaOld)+', '+CONVERT(VARCHAR,IdFacturacion),        
						CONVERT(VARCHAR,@IdMatriculaNew)+', '+CONVERT(VARCHAR,IdFacturacion),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaActorFacturacion         
						WHERE   Id = @oCurIdActorFacturacion         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'ActorFacturacion',        
						CONVERT(VARCHAR,@IdMatriculaOld)+', '+CONVERT(VARCHAR,IdFacturacion),        
						CONVERT(VARCHAR,@IdMatriculaNew)+', '+CONVERT(VARCHAR,IdFacturacion),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaActorFacturacion         
						WHERE   Id = @oCurIdActorFacturacion         
					END CATCH        
              
					SET @oCurIdActorFacturacion = @oCurIdActorFacturacion+1         
              
				END --ActorFacturacion        
             
				SET @oCurIdMatricula = @oCurIdMatricula+1        
             
			END        
        
				--RegistroProductoRequisito----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaRegistroProductoRequisito TABLE (Id int, Entregado bit, FechaEntrega datetime, IdActor int, IdPlantilla int, IdProducto int, IdRegistro int, IdRequisito int)        
				INSERT INTO @VarTablaRegistroProductoRequisito (Id, Entregado, FechaEntrega, IdActor, IdPlantilla, IdProducto, IdRegistro, IdRequisito)         
				SELECT ROW_NUMBER() OVER (ORDER BY IdRegistro), Entregado, FechaEntrega, @IdActorDestino, IdPlantilla, IdProducto, @IdRegistroNew, IdRequisito         
				FROM RegistroProductoRequisito WITH(NOLOCK) WHERE IdActor = @IdActorOrigen and IdRegistro = @IdRegistroOld         
            
				DECLARE @oCurIdRegistroProductoRequisito INT, @oMaxIdRegistroProductoRequisito INT        
				SELECT @oCurIdRegistroProductoRequisito=1, @oMaxIdRegistroProductoRequisito=Max(Id) FROM @VarTablaRegistroProductoRequisito        
				WHILE @oMaxIdRegistroProductoRequisito >= @oCurIdRegistroProductoRequisito         
				BEGIN        
					BEGIN TRY        
						INSERT INTO RegistroProductoRequisito (Entregado, FechaEntrega, IdActor, IdPlantilla, IdProducto, IdRegistro, IdRequisito)         
						SELECT top 1 Entregado, FechaEntrega, @IdActorDestino, IdPlantilla, IdProducto, @IdRegistroNew, IdRequisito         
						FROM @VarTablaRegistroProductoRequisito         
						WHERE Id = @oCurIdRegistroProductoRequisito and IdProducto = @IdProducto         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'RegistroProductoRequisito',        
						CONVERT(VARCHAR,IdActor)+','+CONVERT(VARCHAR,IdPlantilla)+','+CONVERT(VARCHAR,IdProducto)+','+CONVERT(VARCHAR,IdRegistro)+','+CONVERT(VARCHAR,IdRequisito),        
						CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdPlantilla)+','+CONVERT(VARCHAR,IdProducto)+','+CONVERT(VARCHAR,IdRegistro)+','+CONVERT(VARCHAR,IdRequisito),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaRegistroProductoRequisito         
						WHERE Id = @oCurIdRegistroProductoRequisito        
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'RegistroProductoRequisito',        
						CONVERT(VARCHAR,IdActor)+','+CONVERT(VARCHAR,IdPlantilla)+','+CONVERT(VARCHAR,IdProducto)+','+CONVERT(VARCHAR,IdRegistro)+','+CONVERT(VARCHAR,IdRequisito),        
						CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdPlantilla)+','+CONVERT(VARCHAR,IdProducto)+','+CONVERT(VARCHAR,IdRegistro)+','+CONVERT(VARCHAR,IdRequisito),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaRegistroProductoRequisito         
						WHERE Id = @oCurIdRegistroProductoRequisito        
					END CATCH        
             
					SET @oCurIdRegistroProductoRequisito = @oCurIdRegistroProductoRequisito+1         
       
				END        
                      
				SET @oCurIdRegistro = @oCurIdRegistro+1         
           
			END        
           
		END        
          
		--Interesado----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				--IF NOT EXISTS (SELECT 1 FROM Interesado WITH(NOLOCK) WHERE idactor=@IdActorDestino) --@8  
				--BEGIN
				--	INSERT INTO Interesado (IdInteresado,  IdCounter, IdTipoMedioDifusion, IdMedioDifusion)   --@3  
				--	SELECT @IdActorDestino, IdCounter, IdTipoMedioDifusion, IdMedioDifusion  
				--	FROM Interesado WITH(NOLOCK) WHERE idactor = @IdActorOrigen  --@8
				--END

				--INICIO @8
				IF EXISTS (SELECT 1 FROM Interesado WITH(NOLOCK) WHERE idactor=@IdActorOrigen)
				BEGIN
					DECLARE @IdInt INT
					Select @IdInt = (SELECT IdInteresado FROM Interesado WITH(NOLOCK) where IdActor = @IdActorOrigen)

					UPDATE InteresadoTelefono SET IdActor=@IdActorDestino where IdInteresado = @IdInt
					UPDATE InteresadoResultadoAtencion SET IdActor=@IdActorDestino where IdInteresado = @IdInt
					UPDATE InteresadoEmail SET IdActor=@IdActorDestino where IdInteresado = @IdInt
					UPDATE InteresadoDireccion SET IdActor=@IdActorDestino where IdInteresado = @IdInt
					UPDATE Interesado SET IdActor=@IdActorDestino Where IdInteresado = @IdInt 
				END
				--FIN @8
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Interesado',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Interesado where idactor=@IdActorOrigen    -- @8    
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Interesado',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Interesado where idactor=@IdActorOrigen -- @8       
			END CATCH        
		END          
          
		--ActorRol----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				IF NOT EXISTS (SELECT 1 FROM ActorRol WITH(NOLOCK) WHERE IdActor = @IdActorDestino)         
				INSERT INTO ActorRol (Estado, EstadoMotivo, IdActor, IdRol)         
				SELECT Estado, EstadoMotivo, @IdActorDestino, IdRol         
				FROM ActorRol WITH(NOLOCK) WHERE IdActor = @IdActorOrigen        
            
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorRol',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdRol),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdRol),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorRol where IdActor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorRol',    
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdRol),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdRol),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorRol where IdActor=@IdActorOrigen        
			END CATCH        
		END          
		--fk--ActorExperienciaLaboral----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				declare @varTablaActorExperienciaLaboral table (Cargo varchar(100), Descripcion varchar(500), EsActual bit, FechaCreacion datetime, FechaModificacion datetime, IdActor int, IdArchivoConstancia int, IdCargo int, IdCategoriaAcademica int,         
				IdExperiencia int, IdTipoInstitucion int, InstitucionCiudadLaboral varchar(100), InstitucionDireccion varchar(100), InstitucionIdPais int,         
				InstitucionIdUbigeo int, InstitucionMotivoSalida varchar(100), InstitucionNombre varchar(100), InstitucionTelefono varchar(50), PeriodoAnnoFin char(4),         
				PeriodoAnnoInicio char(4), PeriodoMesFin char(2), PeriodoMesInicio char(2), ReferenciaPersonal varchar(200), Sector char(1), TipoExperiencia char(1), UsuarioCreacion int, UsuarioModificacion int, IdExperienciaOld int)        
				insert into @varTablaActorExperienciaLaboral        
				SELECT Cargo, Descripcion, EsActual, FechaCreacion, FechaModificacion, @IdActorDestino, IdArchivoConstancia, IdCargo, IdCategoriaAcademica, IdExperiencia,  
				IdTipoInstitucion, InstitucionCiudadLaboral, InstitucionDireccion, InstitucionIdPais, InstitucionIdUbigeo, InstitucionMotivoSalida, InstitucionNombre,         
				InstitucionTelefono, PeriodoAnnoFin, PeriodoAnnoInicio, PeriodoMesFin, PeriodoMesInicio, ReferenciaPersonal, Sector, TipoExperiencia, UsuarioCreacion, UsuarioModificacion, IdExperiencia         
				FROM ActorExperienciaLaboral WITH(NOLOCK) WHERE IdActor = @IdActorOrigen          
				UPDATE @varTablaActorExperienciaLaboral set IdExperiencia = IdExperiencia+(select ISNULL(MAX(IdExperiencia),1) from ActorExperienciaLaboral where IdActor = @IdActorDestino)        
              
				INSERT INTO ActorExperienciaLaboral (Cargo, Descripcion, EsActual, FechaCreacion, FechaModificacion, IdActor, IdArchivoConstancia, IdCargo,         
				IdCategoriaAcademica, IdExperiencia, IdTipoInstitucion, InstitucionCiudadLaboral, InstitucionDireccion, InstitucionIdPais, InstitucionIdUbigeo,         
				InstitucionMotivoSalida, InstitucionNombre, InstitucionTelefono, PeriodoAnnoFin, PeriodoAnnoInicio, PeriodoMesFin, PeriodoMesInicio, ReferenciaPersonal, Sector, TipoExperiencia, UsuarioCreacion, UsuarioModificacion)         
				SELECT Cargo, Descripcion, EsActual, FechaCreacion, FechaModificacion, @IdActorDestino, IdArchivoConstancia, IdCargo, IdCategoriaAcademica,         
				IdExperiencia, IdTipoInstitucion, InstitucionCiudadLaboral, InstitucionDireccion, InstitucionIdPais, InstitucionIdUbigeo,         
				InstitucionMotivoSalida, InstitucionNombre, InstitucionTelefono, PeriodoAnnoFin, PeriodoAnnoInicio, PeriodoMesFin, PeriodoMesInicio, ReferenciaPersonal, Sector, TipoExperiencia, UsuarioCreacion, UsuarioModificacion         
				FROM @varTablaActorExperienciaLaboral        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorExperienciaLaboral',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdExperienciaOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdExperiencia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorExperienciaLaboral        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorExperienciaLaboral',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdExperienciaOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdExperiencia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorExperienciaLaboral        
			END CATCH            
		END        
		--fk--ActorFamilia----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				declare @varTablaActorFamilia table (CargoLaboral varchar(100), Celular varchar(50), CentroEstudio varchar(100), CiudadNacimiento varchar(50),         
				CiudadResidencia varchar(50), Completado bit, CondicionDomicilio bit, Direccion varchar(200), Email varchar(100), EmailLaboral varchar(50),         
				EmpresaLaboral varchar(100), EsDerechoHabiente bit, FechaAlta datetime, FechaBaja datetime, FechaCreacion datetime, FechaModificacion datetime,         
				FechaNacimiento datetime, Genero char(1), IdActor int, IdDocumentoTipo int, IdEstadoCivil int, IdFamilia int, IdGradoInstruccion int, IdMotivoBaja int,         
				IdPaisNacimiento int, IdPaisResidencia int, IdSituacionFamiliar int, IdTipoDocumentoPaternidad int, IdUbigeoNacimiento int, IdUbigeoResidencia int,         
				IdVia int, IdVinculoFamiliar int, IdZona int, Incapacidad bit, InteriorVia varchar(10), Materno varchar(50), NombreCompleto varchar(100),         
				Nombres varchar(100), NombreVia varchar(100), NombreZona varchar(100), NumeroDocumento varchar(20), NumeroDocumentoPaternidad varchar(50),         
				NumeroVia varchar(10), Paterno varchar(50), ProfesionOcupacion varchar(100), Referencia varchar(200), ResolucionDirectoral varchar(50), Telefono varchar(50),         
				TelefonoLaboral varchar(50), UsuarioCreacion int, UsuarioModificacion int, Vive bit, IdFamiliaOld int)        
				insert into @varTablaActorFamilia        
				SELECT CargoLaboral, Celular, CentroEstudio, CiudadNacimiento, CiudadResidencia, Completado, CondicionDomicilio, Direccion, Email, EmailLaboral,         
				EmpresaLaboral, EsDerechoHabiente, FechaAlta, FechaBaja, FechaCreacion, FechaModificacion, FechaNacimiento, Genero, @IdActorDestino, IdDocumentoTipo,         
				IdEstadoCivil, IdFamilia, IdGradoInstruccion, IdMotivoBaja, IdPaisNacimiento, IdPaisResidencia, IdSituacionFamiliar, IdTipoDocumentoPaternidad,         
				IdUbigeoNacimiento, IdUbigeoResidencia, IdVia, IdVinculoFamiliar, IdZona, Incapacidad, InteriorVia, Materno, NombreCompleto, Nombres, NombreVia,         
				NombreZona, NumeroDocumento, NumeroDocumentoPaternidad, NumeroVia, Paterno, ProfesionOcupacion, Referencia, ResolucionDirectoral, Telefono, TelefonoLaboral,         
				UsuarioCreacion, UsuarioModificacion, Vive, IdFamilia         
				FROM ActorFamilia WITH(NOLOCK) WHERE IdActor = @IdActorOrigen          
				UPDATE @varTablaActorFamilia set IdFamilia = IdFamilia+(select ISNULL(MAX(IdFamilia),1) from ActorFamilia where IdActor = @IdActorDestino)        
           
				INSERT INTO ActorFamilia (CargoLaboral, Celular, CentroEstudio, CiudadNacimiento, CiudadResidencia, Completado, CondicionDomicilio, Direccion,         
				Email, EmailLaboral, EmpresaLaboral, EsDerechoHabiente, FechaAlta, FechaBaja, FechaCreacion, FechaModificacion, FechaNacimiento, Genero, IdActor,         
				IdDocumentoTipo, IdEstadoCivil, IdFamilia, IdGradoInstruccion, IdMotivoBaja, IdPaisNacimiento, IdPaisResidencia, IdSituacionFamiliar,         
				IdTipoDocumentoPaternidad, IdUbigeoNacimiento, IdUbigeoResidencia, IdVia, IdVinculoFamiliar, IdZona, Incapacidad, InteriorVia, Materno,         
				NombreCompleto, Nombres, NombreVia, NombreZona, NumeroDocumento, NumeroDocumentoPaternidad, NumeroVia, Paterno, ProfesionOcupacion, Referencia,         
				ResolucionDirectoral, Telefono, TelefonoLaboral, UsuarioCreacion, UsuarioModificacion, Vive)         
				SELECT CargoLaboral, Celular, CentroEstudio, CiudadNacimiento, CiudadResidencia, Completado, CondicionDomicilio, Direccion, Email, EmailLaboral,         
				EmpresaLaboral, EsDerechoHabiente, FechaAlta, FechaBaja, FechaCreacion, FechaModificacion, FechaNacimiento, Genero, @IdActorDestino, IdDocumentoTipo,         
				IdEstadoCivil, IdFamilia, IdGradoInstruccion, IdMotivoBaja, IdPaisNacimiento, IdPaisResidencia, IdSituacionFamiliar, IdTipoDocumentoPaternidad,         
				IdUbigeoNacimiento, IdUbigeoResidencia, IdVia, IdVinculoFamiliar, IdZona, Incapacidad, InteriorVia, Materno, NombreCompleto, Nombres, NombreVia,         
				NombreZona, NumeroDocumento, NumeroDocumentoPaternidad, NumeroVia, Paterno, ProfesionOcupacion, Referencia, ResolucionDirectoral, Telefono, TelefonoLaboral,         
				UsuarioCreacion, UsuarioModificacion, Vive         
				FROM @varTablaActorFamilia        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorFamilia',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdFamiliaOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdFamilia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorFamilia        
			END TRY  
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorFamilia',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdFamiliaOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdFamilia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorFamilia        
			END CATCH        
		END        
        
		--ActorMedica----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO ActorMedica (AlimentoNombre, AutorizacionHospitalizacion, EsAlergicoAlimento, EsAlergicoMedicamento, EsAlergicoOtro, EsAlergicoPlanta,         
				EsAsegurado, FechaCreacion, FechaModificacion, HospitalDireccion, HospitalNombre, IdActor, IdSeguro, IdTipoSangre, IndicacionMedica, IntervencionMedica,         
				LlamarEmergencia, MedicamentoNombre, MedicamentoProhibido, NumeroSeguro, OtroNombre, PlantaNombre, TelefonoEmergencia, TieneIntervencion,         
				UsuarioCreacion, UsuarioModificacion)         
				SELECT AlimentoNombre, AutorizacionHospitalizacion, EsAlergicoAlimento, EsAlergicoMedicamento, EsAlergicoOtro, EsAlergicoPlanta, EsAsegurado,         
				FechaCreacion, FechaModificacion, HospitalDireccion, HospitalNombre, @IdActorDestino, IdSeguro, IdTipoSangre, IndicacionMedica, IntervencionMedica,         
				LlamarEmergencia, MedicamentoNombre, MedicamentoProhibido, NumeroSeguro, OtroNombre, PlantaNombre, TelefonoEmergencia, TieneIntervencion,         
				UsuarioCreacion, UsuarioModificacion         
				FROM ActorMedica WITH(NOLOCK) WHERE IdActor = @IdActorOrigen        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorMedica',        
				CONVERT(VARCHAR,IdActor),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorMedica where IdActor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorMedica',      
				CONVERT(VARCHAR,IdActor),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorMedica where IdActor=@IdActorOrigen           
			END CATCH        
		END        
          
		--fk--ActorDireccion----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			DECLARE @ColNameActorDireccion VARCHAR(MAX)        
			SELECT @ColNameActorDireccion = COALESCE(@ColNameActorDireccion + ', ' + NombreVia, NombreVia) FROM (SELECT NombreVia FROM ActorDireccion WHERE IdActor = @IdActorDestino) as #TMP        
			BEGIN TRY        
				declare @varTablaActorDireccion table (Activo bit, CiudadResidencia varchar(100), CodigoPostal varchar(10), FechaCreacion datetime, FechaModificacion datetime, IdActor int,         
				IdDireccion int, IdPaisResidencia int, IdUbigeoResidencia int, IdVia int, IdZona int, InteriorVia varchar(10), NombreVia varchar(200), NombreZona varchar(200), NumeroVia varchar(10),         
				Principal bit, Referencia varchar(200), UsuarioModificacion varchar(50), IdDireccionOld int)        
				insert into @varTablaActorDireccion        
				SELECT Activo, CiudadResidencia, CodigoPostal, FechaCreacion, FechaModificacion, IdActor, IdDireccion, IdPaisResidencia, IdUbigeoResidencia, IdVia, IdZona, InteriorVia, NombreVia,         
				NombreZona, NumeroVia, Principal, Referencia,null, IdDireccion         
				FROM ActorDireccion WITH(NOLOCK) WHERE IdActor = @IdActorOrigen          
				UPDATE @varTablaActorDireccion set IdDireccion = IdDireccion+(select ISNULL(MAX(IdDireccion),1) from ActorDireccion where IdActor = @IdActorDestino), Principal = 0        
           
				INSERT INTO ActorDireccion (Activo, CiudadResidencia, CodigoPostal, FechaCreacion, FechaModificacion, IdActor, IdDireccion, IdPaisResidencia, IdUbigeoResidencia, IdVia, IdZona,         
				InteriorVia, NombreVia, NombreZona, NumeroVia, Principal, Referencia, UsuarioModificacion)         
				SELECT Activo, CiudadResidencia, CodigoPostal, FechaCreacion, FechaModificacion, @IdActorDestino, IdDireccion, IdPaisResidencia, IdUbigeoResidencia, IdVia, IdZona,         
				InteriorVia, NombreVia, NombreZona, NumeroVia, Principal, Referencia, UsuarioModificacion        
				FROM @varTablaActorDireccion         
				WHERE IdActor = @IdActorOrigen         
				--AND NombreVia NOT IN (@ColNameActorDireccion)        
				AND LTRIM(RTRIM(NombreVia)) NOT LIKE '%'+LTRIM(RTRIM(@ColNameActorDireccion))+'%'        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorDireccion',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdDireccionOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdDireccion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorDireccion        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorDireccion',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdDireccionOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdDireccion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorDireccion        
			END CATCH        
		END        
		--fk--ActorDistincion----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				declare @varTablaActorDistincion table (IdActor int, IdArchivo int, IdDistincion int, InstitucionNombre varchar(100), PeriodoAnno char(4),         
				PeriodoMes char(2), TituloObtenido varchar(100), IdDistincionOld int)        
				insert into @varTablaActorDistincion (IdActor, IdArchivo, IdDistincion, InstitucionNombre, PeriodoAnno, PeriodoMes, TituloObtenido, IdDistincionOld)        
				SELECT @IdActorDestino, IdArchivo, IdDistincion, InstitucionNombre, PeriodoAnno, PeriodoMes, TituloObtenido, IdDistincion         
				FROM ActorDistincion WITH(NOLOCK) WHERE IdActor = @IdActorOrigen          
				UPDATE @varTablaActorDistincion set IdDistincion = IdDistincion+(select ISNULL(MAX(IdDistincion),1) from ActorDistincion where IdActor = @IdActorDestino)        
              
				INSERT INTO ActorDistincion (IdActor, IdArchivo, IdDistincion, InstitucionNombre, PeriodoAnno, PeriodoMes, TituloObtenido)         
				SELECT @IdActorDestino, IdArchivo, IdDistincion, InstitucionNombre, PeriodoAnno, PeriodoMes, TituloObtenido         
				FROM @varTablaActorDistincion WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorDistincion',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdDistincionOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdDistincion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorDistincion         
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorDistincion',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdDistincionOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdDistincion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorDistincion         
			END CATCH        
		END        
		--fk--ActorEmail----------------------------------------------------------------------------------------------------------------------        
		BEGIN         
			BEGIN TRY        
				DECLARE @ColNameActorEmail VARCHAR(MAX)        
				SELECT @ColNameActorEmail = COALESCE(@ColNameActorEmail + ', ' + Descripcion, Descripcion) FROM (SELECT Descripcion FROM ActorEmail WHERE IdActor = @IdActorDestino) as #TMP        
            
				declare @varTablaActorEmail table (Descripcion varchar(100), FechaCreacion datetime, FechaModificacion datetime, IdActor int, IdEmail int, IdTipoEmail int, Principal bit, UsuarioCreacion int, UsuarioModificacion int, IdEmailOld int)        
				insert into @varTablaActorEmail (Descripcion, FechaCreacion, FechaModificacion, IdActor, IdEmail, IdTipoEmail, Principal, UsuarioCreacion, UsuarioModificacion, IdEmailOld)        
     
				SELECT Descripcion, FechaCreacion, FechaModificacion, @IdActorDestino, IdEmail, IdTipoEmail, Principal, UsuarioCreacion, UsuarioModificacion, IdEmail        
				FROM ActorEmail WITH(NOLOCK) WHERE IdActor = @IdActorOrigen          
				UPDATE @varTablaActorEmail set IdEmail = IdEmail+(select ISNULL(MAX(IdEmail),1) from ActorEmail where IdActor = @IdActorDestino), Principal = 0        
               
				INSERT INTO ActorEmail (Descripcion, FechaCreacion, FechaModificacion, IdActor, IdEmail, IdTipoEmail, Principal, UsuarioCreacion, UsuarioModificacion)         
				SELECT Descripcion, FechaCreacion, FechaModificacion, @IdActorDestino, IdEmail, IdTipoEmail, Principal, UsuarioCreacion, UsuarioModificacion         
				FROM @varTablaActorEmail        
				--WHERE Descripcion NOT IN (@ColNameActorEmail)        
				WHERE LTRIM(RTRIM(Descripcion)) NOT LIKE '%'+ LTRIM(RTRIM(@ColNameActorEmail))+'%'        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorEmail',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmailOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmail),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorEmail        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorEmail',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmailOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmail),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorEmail        
			END CATCH        
		END        
		--fk--ActorEstudioOtro----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				declare @varTablaActorEstudioOtro table (Desde varchar(10), EstudioCentro varchar(100), EstudioNombre varchar(100), Hasta varchar(10),         
				IdActor int, IdEstudio int, IdEstudioOld int)        
				insert into @varTablaActorEstudioOtro        
				SELECT Desde, EstudioCentro, EstudioNombre, Hasta, @IdActorDestino, IdEstudio, IdEstudio          
				FROM ActorEstudioOtro WITH(NOLOCK) WHERE IdActor = @IdActorOrigen          
				UPDATE @varTablaActorEstudioOtro set IdEstudio = IdEstudio+(select ISNULL(MAX(IdEstudio),1) from ActorEstudioOtro where IdActor = @IdActorDestino)        
            
				INSERT INTO ActorEstudioOtro (Desde, EstudioCentro, EstudioNombre, Hasta, IdActor, IdEstudio)         
				SELECT Desde, EstudioCentro, EstudioNombre, Hasta, @IdActorDestino, IdEstudio         
				FROM @varTablaActorEstudioOtro WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorEstudioOtro',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEstudioOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEstudio),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorEstudioOtro        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorEstudioOtro',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEstudioOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEstudio),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorEstudioOtro        
			END CATCH        
		END        
		--ActorFoto----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				IF NOT EXISTS (SELECT 1 FROM ActorFoto WITH(NOLOCK) WHERE IdActor=@IdActorDestino)         
				INSERT INTO ActorFoto (Foto, IdActor)         
				SELECT Foto, @IdActorDestino         
				FROM ActorFoto WITH(NOLOCK)        
				WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorFoto',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorFoto WITH(NOLOCK) where IdActor=@IdActorOrigen           
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorFoto',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorFoto WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END        
		--fk--ActorHabilidad----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				declare @varTablaActorHabilidad table (IdActor int, IdHabilidad int, Tipo char(1), IdHabilidadOld int)        
				insert into @varTablaActorHabilidad (IdActor, IdHabilidad, Tipo,IdHabilidadOld)        
				SELECT @IdActorDestino, IdHabilidad, Tipo, IdHabilidad          
				FROM ActorHabilidad WITH(NOLOCK) WHERE IdActor = @IdActorOrigen          
				UPDATE @varTablaActorHabilidad set IdHabilidad = IdHabilidad+(select ISNULL(MAX(IdHabilidad),1) from ActorHabilidad WITH(NOLOCK) where IdActor = @IdActorDestino)        
           
				INSERT INTO ActorHabilidad (IdActor, IdHabilidad, Tipo)         
				SELECT @IdActorDestino, IdHabilidad, Tipo          
				FROM @varTablaActorHabilidad        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorHabilidad',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdHabilidadOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdHabilidad),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorHabilidad        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorHabilidad',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdHabilidadOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdHabilidad),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorHabilidad        
			END CATCH        
		END        
		--fk--ActorParticipacion----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				declare @varTablaActorParticipacion table (CiudadPublicacion varchar(100), Descripcion varchar(200), EditorialPublicacion varchar(50),         
				IdActor int, IdFormaParticipacion int, IdParticipacion int, IdTipoParticipacion int, IdTipoPublicacion int, PeriodoAnno char(4), PeriodoMes char(2), IdParticipacionOld int)        
				insert into @varTablaActorParticipacion (CiudadPublicacion, Descripcion, EditorialPublicacion, IdActor, IdFormaParticipacion, IdParticipacion, IdTipoParticipacion, IdTipoPublicacion, PeriodoAnno, PeriodoMes, IdParticipacionOld)        
				SELECT CiudadPublicacion, Descripcion, EditorialPublicacion, @IdActorDestino, IdFormaParticipacion, IdParticipacion, IdTipoParticipacion, IdTipoPublicacion, PeriodoAnno, PeriodoMes, IdParticipacion          
				FROM ActorParticipacion WITH(NOLOCK) WHERE IdActor = @IdActorOrigen          
				UPDATE @varTablaActorParticipacion set IdParticipacion = IdParticipacion+(select ISNULL(MAX(IdParticipacion),1) from ActorParticipacion WITH(NOLOCK) where IdActor = @IdActorDestino)        
           
				INSERT INTO ActorParticipacion (CiudadPublicacion, Descripcion, EditorialPublicacion, IdActor, IdFormaParticipacion, IdParticipacion, IdTipoParticipacion, IdTipoPublicacion, PeriodoAnno, PeriodoMes)         
				SELECT CiudadPublicacion, Descripcion, EditorialPublicacion, @IdActorDestino, IdFormaParticipacion, IdParticipacion, IdTipoParticipacion, IdTipoPublicacion, PeriodoAnno, PeriodoMes         
				FROM @varTablaActorParticipacion        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorParticipacion',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdParticipacionOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdParticipacion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorParticipacion        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorParticipacion',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdParticipacionOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdParticipacion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorParticipacion        
			END CATCH        
		END        
		--fk--ActorTelefono----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				DECLARE @ColNameActorTelefono VARCHAR(MAX)        
				SELECT @ColNameActorTelefono = COALESCE(@ColNameActorTelefono + ', ' + Descripcion, Descripcion) FROM (SELECT Descripcion FROM ActorTelefono WITH(NOLOCK) WHERE IdActor = @IdActorDestino) as #TMP        
            
				declare @varTablaActorTelefono table (Anexo varchar(20), Descripcion varchar(100), FechaCreacion datetime, FechaModificacion datetime, IdActor int, IdTelefono int, IdTipoMovil int,         
				IdTipoTelefono int, Principal bit, UsuarioCreacion int, UsuarioModificacion int, IdTelefonoOld int)        
				insert into @varTablaActorTelefono (Anexo, Descripcion, FechaCreacion, FechaModificacion, IdActor, IdTelefono, IdTipoMovil, IdTipoTelefono, Principal, UsuarioCreacion,         
				UsuarioModificacion, IdTelefonoOld)        
				SELECT Anexo, Descripcion, FechaCreacion, FechaModificacion, @IdActorDestino, IdTelefono, IdTipoMovil, IdTipoTelefono, Principal, UsuarioCreacion, UsuarioModificacion,IdTelefono        
				FROM ActorTelefono WITH(NOLOCK) WHERE IdActor = @IdActorOrigen         
				UPDATE @varTablaActorTelefono set IdTelefono = IdTelefono+(select ISNULL(MAX(IdTelefono),1) from ActorTelefono where IdActor = @IdActorDestino), Principal = 0        
           
				INSERT INTO ActorTelefono (Anexo, Descripcion, FechaCreacion, FechaModificacion, IdActor, IdTelefono, IdTipoMovil, IdTipoTelefono, Principal, UsuarioCreacion, UsuarioModificacion)         
				SELECT Anexo, Descripcion, FechaCreacion, FechaModificacion, @IdActorDestino, IdTelefono, IdTipoMovil, IdTipoTelefono, Principal, UsuarioCreacion, UsuarioModificacion        
				FROM @varTablaActorTelefono        
				--WHERE Descripcion NOT IN (@ColNameActorTelefono)        
				WHERE LTRIM(RTRIM(Descripcion)) NOT LIKE '%'+ LTRIM(RTRIM(@ColNameActorTelefono)) +'%'        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorTelefono',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdTelefonoOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdTelefono),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorTelefono        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorTelefono',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdTelefonoOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdTelefono),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorTelefono        
			END CATCH        
		END        
		--fk--ActorTrabajo----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				declare @varTablaActorTrabajo table (Anexo varchar(20), CargoNombre varchar(100), EsActual bit, Fax varchar(100), Horario varchar(100), IdActor int,         
				IdAreaLaboral int, IdCargo int, IdEntidad int, IdTrabajo int, Observacion varchar(500), PeriodoAnnoFin char(4), PeriodoAnnoInicio char(4),         
				PeriodoMesFin char(3), PeriodoMesInicio char(3), Principal char(1), Representante char(1), Telefono varchar(100), IdTrabajoOld int)        
				insert into @varTablaActorTrabajo (Anexo, CargoNombre, EsActual, Fax, Horario, IdActor, IdAreaLaboral, IdCargo, IdEntidad, IdTrabajo, Observacion,         
				PeriodoAnnoFin, PeriodoAnnoInicio, PeriodoMesFin, PeriodoMesInicio, Principal, Representante, Telefono, IdTrabajoOld)        
				SELECT Anexo, CargoNombre, EsActual, Fax, Horario, @IdActorDestino, IdAreaLaboral, IdCargo, IdEntidad, IdTrabajo, Observacion, PeriodoAnnoFin, PeriodoAnnoInicio, PeriodoMesFin, PeriodoMesInicio, Principal, Representante, Telefono, IdTrabajo         








				FROM ActorTrabajo WITH(NOLOCK) WHERE IdActor = @IdActorOrigen         
				UPDATE @varTablaActorTrabajo set IdTrabajo = IdTrabajo+(select ISNULL(MAX(IdTrabajo),1) from ActorTrabajo where IdActor = @IdActorDestino), Principal = 0        
           
				INSERT INTO ActorTrabajo (Anexo, CargoNombre, EsActual, Fax, Horario, IdActor, IdAreaLaboral, IdCargo, IdEntidad, IdTrabajo, Observacion, PeriodoAnnoFin, PeriodoAnnoInicio, PeriodoMesFin, PeriodoMesInicio, Principal, Representante, Telefono)         











				SELECT Anexo, CargoNombre, EsActual, Fax, Horario, @IdActorDestino, IdAreaLaboral, IdCargo, IdEntidad, IdTrabajo, Observacion, PeriodoAnnoFin, PeriodoAnnoInicio, PeriodoMesFin, PeriodoMesInicio, Principal, Representante, Telefono         
				FROM @varTablaActorTrabajo        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorTrabajo',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdTrabajoOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdTrabajo),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorTrabajo        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorTrabajo',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdTrabajoOld),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdTrabajo),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from @varTablaActorTrabajo        
			END CATCH        
		END        
		--Lector----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO Lector (Activo, CargoNombre, CarreraNombre, CentroLaboralNombre, FechaInscripcion, IdLector, IdTipoLector, ProcedenciaNombre, TemaInteresNombre)         
				SELECT Activo, CargoNombre, CarreraNombre, CentroLaboralNombre, FechaInscripcion, @IdActorDestino, IdTipoLector, ProcedenciaNombre, TemaInteresNombre         
				FROM Lector WITH(NOLOCK) WHERE IdLector = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Lector',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Lector where IdLector=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Lector',     
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Lector where IdLector=@IdActorOrigen           
			END CATCH        
		END        
		--IntegranteComite----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO IntegranteComite (IdIntegrante, Tipo)         
				SELECT IdIntegrante, Tipo         
				FROM IntegranteComite WITH(NOLOCK) WHERE IdIntegrante = @IdActorOrigen        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'IntegranteComite',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from IntegranteComite where IdIntegrante=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'IntegranteComite',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from IntegranteComite where IdIntegrante=@IdActorOrigen           
			END CATCH        
		END        
		--F----Facilitador----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  IF NOT EXISTS (SELECT 1 FROM Facilitador WHERE IdFacilitador = @IdActorDestino)        
		--  INSERT INTO Facilitador (Activo, CodigoAnterior, CodigoEmpleado, EmailInstitucion, EsEmpleado, FechaCreacion, FechaModificacion, IdCategoria, IdFacilitador, IdUsuario, Observacion, UsuarioCreacion, UsuarioModificacion)         
		--  SELECT Activo, CodigoAnterior, CodigoEmpleado, EmailInstitucion, EsEmpleado, FechaCreacion, FechaModificacion, IdCategoria, @IdActorDestino, IdUsuario, Observacion, UsuarioCreacion, UsuarioModificacion         
		--  FROM Facilitador WHERE IdFacilitador = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Facilitador',        
		--  CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Facilitador where IdFacilitador=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH        
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Facilitador',        
		--  CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Facilitador where IdFacilitador=@IdActorOrigen            
		-- END CATCH        
		--END        
		----Entidad----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  IF NOT EXISTS (SELECT 1 FROM Entidad WHERE IdEntidad=@IdActorDestino)        
		--  INSERT INTO Entidad (Activo, CodigoAnterior, FechaFundacion, IdEntidad, IdFormaEmpresa, IdRangoEmpleado, IdTamanoEmpresa, IdTipoEntidad, IdTipoGiro, NombreComercial, Siglas, SitioWeb)         
		--  SELECT Activo, CodigoAnterior, FechaFundacion, @IdActorDestino, IdFormaEmpresa, IdRangoEmpleado, IdTamanoEmpresa, IdTipoEntidad, IdTipoGiro, NombreComercial, Siglas, SitioWeb         
		--  FROM Entidad WHERE IdEntidad = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Entidad',        
		--  CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Entidad where IdEntidad=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH        
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Entidad',        
		--  CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Entidad where IdEntidad=@IdActorOrigen            
		-- END CATCH        
		--END        
          
		--Empleado----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO Empleado (Activo, Brevete, CarnetFondoPension, Codigo, CodigoAnterior, DeseaAfiliacionAFP, EmailInstitucion, Especialidad, FechaAfiliacion, FichaAcademica, FichaCapacitacion, FichaConocimiento, FichaExperienciaLaboral,         
				FichaFamiliar, FichaPersonal, IdEmpleado, IdFondoPension, IdNivelEducativo, IdRegimenPension, IdTipoBrevete, LibretaMilitar, NumeroLegajo, Pasaporte)         
				SELECT Activo, Brevete, CarnetFondoPension, Codigo, CodigoAnterior, DeseaAfiliacionAFP, EmailInstitucion, Especialidad, FechaAfiliacion, FichaAcademica, FichaCapacitacion, FichaConocimiento, FichaExperienciaLaboral,         
				FichaFamiliar, FichaPersonal, @IdActorDestino, IdFondoPension, IdNivelEducativo, IdRegimenPension, IdTipoBrevete, LibretaMilitar, NumeroLegajo, Pasaporte         
				FROM Empleado WITH(NOLOCK) WHERE IdEmpleado = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Empleado',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Empleado WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Empleado',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Empleado WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END CATCH        
		END        
		--Donador----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO Donador (Activo, Codigo, IdDonador, RazonSocial, TipoPersona)         
				SELECT Activo, Codigo, @IdActorDestino, RazonSocial, TipoPersona         
				FROM Donador WITH(NOLOCK) WHERE IdDonador = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Donador',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Donador WITH(NOLOCK) where IdDonador=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Donador',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Donador WITH(NOLOCK) where IdDonador=@IdActorOrigen        
			END CATCH        
		END        
		--Cliente----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO Cliente (Activo, Codigo, CodigoAnterior, DireccionCobranza, IdCalificacionCobranza, IdCliente, NombreComercial, NombreGiro, RazonSocial, SitioWeb, TipoPersona)         
				SELECT Activo, Codigo, CodigoAnterior, DireccionCobranza, IdCalificacionCobranza, @IdActorDestino, NombreComercial, NombreGiro, RazonSocial, SitioWeb, TipoPersona         
				FROM Cliente WITH(NOLOCK) WHERE IdCliente = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Donador',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Donador WITH(NOLOCK) where IdDonador=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Donador',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Donador WITH(NOLOCK) where IdDonador=@IdActorOrigen        
			END CATCH        
		END        
		--Proveedor----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO Proveedor (Activo, Codigo, EsHunting, IdEstadoContribuyente, IdProveedor, NombreComercial, NombreGiro, RazonSocial, SitioWeb, TipoPersona)         
				SELECT Activo, Codigo, EsHunting, IdEstadoContribuyente, @IdActorDestino, NombreComercial, NombreGiro, RazonSocial, SitioWeb, TipoPersona         
				FROM Proveedor WITH(NOLOCK)        
				WHERE IdProveedor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Proveedor',        
				CONVERT(VARCHAR,@IdActorOrigen),    
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Proveedor WITH(NOLOCK) where IdProveedor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Proveedor',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Proveedor WITH(NOLOCK) where IdProveedor=@IdActorOrigen        
			END CATCH        
		END        
		--ProveedorTemporal----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO ProveedorTemporal (IdProveedor, RazonSocial, TipoPersona)         
				SELECT @IdActorDestino, RazonSocial, TipoPersona         
				FROM ProveedorTemporal WITH(NOLOCK)        
				WHERE IdProveedor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ProveedorTemporal',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ProveedorTemporal WITH(NOLOCK) where IdProveedor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ProveedorTemporal',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ProveedorTemporal WITH(NOLOCK) where IdProveedor=@IdActorOrigen            
			END CATCH        
		END        
		--WorkFlowEntidad----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO WorkFlowEntidad (Activo, Codigo, IdWfEntidad, IdWfTipoEntidad, NombreComercial, RazonSocial)         
				SELECT Activo, Codigo, @IdActorDestino, IdWfTipoEntidad, NombreComercial, RazonSocial         
				FROM WorkFlowEntidad WITH(NOLOCK)         
				WHERE IdWfEntidad = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'WorkFlowEntidad',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from WorkFlowEntidad WITH(NOLOCK) where IdWfEntidad=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'WorkFlowEntidad',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from WorkFlowEntidad WITH(NOLOCK) where IdWfEntidad=@IdActorOrigen        
			END CATCH        
		END        
		--WorkFlowPersona----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO WorkFlowPersona (Activo, Codigo, EsEmpleado, IdCargoPrincipal, IdWfPersona, NombreCompleto)         
				SELECT Activo, Codigo, EsEmpleado, IdCargoPrincipal, @IdActorDestino, NombreCompleto         
				FROM WorkFlowPersona WITH(NOLOCK) WHERE IdWfPersona = @IdActorOrigen        
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'WorkFlowPersona',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from WorkFlowPersona WITH(NOLOCK) where IdWfPersona=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'WorkFlowPersona',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from WorkFlowPersona WITH(NOLOCK) where IdWfPersona=@IdActorOrigen            
			END CATCH        
		END        
		-- --Socio----------------------------------------------------------------------------------------------------------------------        
		-- BEGIN        
		--  BEGIN TRY      
		--IF NOT EXISTS (SELECT 1 FROM Socio WHERE IdSocio=@IdActorDestino)   
		--BEGIN  
		-- INSERT INTO Socio (Activo, CodigoAnterior, IdCategoria, IdSocio)         
		-- SELECT Activo, CodigoAnterior, IdCategoria, @IdActorDestino          
		-- FROM Socio WITH(NOLOCK) WHERE IdSocio = @IdActorOrigen         
         
		-- INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		-- SELECT @IdProceso,'Socio',        
		-- CONVERT(VARCHAR,@IdActorOrigen),        
		-- CONVERT(VARCHAR,@IdActorDestino),        
		-- @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Socio WITH(NOLOCK) where IdSocio=@IdActorOrigen        
		--END  
      
		--  END TRY        
		--  BEGIN CATCH        
		--   SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--   INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--   SELECT @IdProceso,'Socio',        
		--   CONVERT(VARCHAR,@IdActorOrigen),        
		--   CONVERT(VARCHAR,@IdActorDestino),        
		--   @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Socio WITH(NOLOCK) where IdSocio=@IdActorOrigen            
		--  END CATCH        
		-- END 
		--ActorFamiliaEnfermedad----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO ActorFamiliaEnfermedad (IdActor, IdEnfermedad, IdFamilia)         
				SELECT @IdActorDestino, IdEnfermedad, IdFamilia        
				FROM ActorFamiliaEnfermedad WITH(NOLOCK) WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorFamiliaEnfermedad',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEnfermedad)+','+CONVERT(VARCHAR,IdFamilia),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEnfermedad)+','+CONVERT(VARCHAR,IdFamilia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				from ActorFamiliaEnfermedad WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorFamiliaEnfermedad',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEnfermedad)+','+CONVERT(VARCHAR,IdFamilia),      
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEnfermedad)+','+CONVERT(VARCHAR,IdFamilia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				from ActorFamiliaEnfermedad WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END        
		--Inicio @3
		--InteresadoPreferencia----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  INSERT INTO InteresadoPreferencia (IdInteresado, IdPreferencia)         
		--  SELECT @IdActorDestino, IdPreferencia        
		--  FROM InteresadoPreferencia WITH(NOLOCK) WHERE IdInteresado = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'InteresadoPreferencia',        
		--  CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdPreferencia),        
		--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdPreferencia),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from InteresadoPreferencia WITH(NOLOCK) where IdInteresado=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH        
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'InteresadoPreferencia',        
		--  CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdPreferencia),        
		--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdPreferencia),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from InteresadoPreferencia WITH(NOLOCK) where IdInteresado=@IdActorOrigen        
		-- END CATCH        
		--END      
		--Fin @3  
		--ComiteCreditoIntegrante----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO ComiteCreditoIntegrante (IdComiteCredito, IdIntegrante)         
				SELECT IdComiteCredito, @IdActorDestino        
				FROM ComiteCreditoIntegrante WITH(NOLOCK) WHERE IdIntegrante = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ComiteCreditoIntegrante',        
				CONVERT(VARCHAR,IdComiteCredito)+','+CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,IdComiteCredito)+','+CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,        
				@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ComiteCreditoIntegrante WITH(NOLOCK) where IdIntegrante=@IdActorOrigen        
			END TRY        
			BEGIN CATCH        
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ComiteCreditoIntegrante',        
				CONVERT(VARCHAR,IdComiteCredito)+','+CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,IdComiteCredito)+','+CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,        
				@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ComiteCreditoIntegrante WITH(NOLOCK) where IdIntegrante=@IdActorOrigen        
			END CATCH        
		END        
          
		--F--FacilitadorCurso----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  IF NOT EXISTS (SELECT 1 FROM FacilitadorCurso where IdFacilitador=@IdActorDestino)        
		--  INSERT INTO FacilitadorCurso (IdCurso, IdFacilitador, IdNivel)         
		--  SELECT IdCurso, @IdActorDestino, IdNivel        
		--  FROM FacilitadorCurso WHERE IdFacilitador = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FacilitadorCurso',        
		--  CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FacilitadorCurso where IdFacilitador=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH        
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FacilitadorCurso',        
		--  CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FacilitadorCurso where IdFacilitador=@IdActorOrigen        
		-- END CATCH        
		--END        
		--F--FacilitadorEstructura----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  INSERT INTO FacilitadorEstructura (IdEmpresa, IdEstructura, IdFacilitador, IdFacultad, IdSede, IdUnidadAcademica, IdUnidadNegocio)         
		--  SELECT IdEmpresa, IdEstructura, @IdActorDestino, IdFacultad, IdSede, IdUnidadAcademica, IdUnidadNegocio        
		--  FROM FacilitadorEstructura WHERE IdFacilitador = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FacilitadorEstructura',   --  CONVERT(VARCHAR,IdEstructura)+','+CONVERT(VARCHAR,@IdActorOrigen),   --  CONVERT(VARCHAR,IdEstructura)+','+CONVERT(VARCHAR,@IdActorDestino),         
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FacilitadorEstructura where IdFacilitador=@IdActorOrigen   -- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FacilitadorEstructura',        
		--  CONVERT(VARCHAR,IdEstructura)+','+CONVERT(VARCHAR,@IdActorOrigen),   --  CONVERT(VARCHAR,IdEstructura)+','+CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FacilitadorEstructura where IdFacilitador=@IdActorOrigen        
		-- END CATCH        
		--END        
		--F--FacilitadorNegocio----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  INSERT INTO FacilitadorNegocio (FechaCreacion, FechaModificacion, IdEmpresa, IdFacilitador, IdFacultad, IdSede, IdUnidadNegocio, UsuarioCreacion, UsuarioModificacion)         
		--  SELECT FechaCreacion, FechaModificacion, IdEmpresa, @IdActorDestino, IdFacultad, IdSede, IdUnidadNegocio, UsuarioCreacion, UsuarioModificacion        
		--  FROM FacilitadorNegocio WHERE IdFacilitador = @IdActorOrigen         
     
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FacilitadorNegocio',        
		--  CONVERT(VARCHAR,IdEmpresa)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdFacultad)+','+CONVERT(VARCHAR,IdSede)+','+CONVERT(VARCHAR,IdUnidadNegocio),        
		--  CONVERT(VARCHAR,IdEmpresa)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdFacultad)+','+CONVERT(VARCHAR,IdSede)+','+CONVERT(VARCHAR,IdUnidadNegocio),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
		--  from FacilitadorNegocio where IdFacilitador=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FacilitadorNegocio',        
		--  CONVERT(VARCHAR,IdEmpresa)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdFacultad)+','+CONVERT(VARCHAR,IdSede)+','+CONVERT(VARCHAR,IdUnidadNegocio),        
		--  CONVERT(VARCHAR,IdEmpresa)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdFacultad)+','+CONVERT(VARCHAR,IdSede)+','+CONVERT(VARCHAR,IdUnidadNegocio),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
		--  from FacilitadorNegocio where IdFacilitador=@IdActorOrigen        
		-- END CATCH        
		--END        
		--F--FacilitadorTarifario----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  INSERT INTO FacilitadorTarifario (Activo, FechaCreacion, FechaModificacion, IdFacilitador, IdTarifa, IdTarifario, Observacion, UsuarioCreacion, UsuarioModificacion)         
		--  SELECT Activo, FechaCreacion, FechaModificacion, @IdActorDestino, IdTarifa, IdTarifario, Observacion, UsuarioCreacion, UsuarioModificacion        
		--  FROM FacilitadorTarifario WHERE IdFacilitador = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FacilitadorTarifario',        
		--  CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdTarifario),        
		--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdTarifario),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FacilitadorTarifario where IdFacilitador=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FacilitadorTarifario',        
		--  CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdTarifario),        
		--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdTarifario),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FacilitadorTarifario where IdFacilitador=@IdActorOrigen        
		-- END CATCH        
		--END        
		--EntidadContacto----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO EntidadContacto (IdContacto, IdEntidad)         
				SELECT IdContacto, @IdActorDestino        
				FROM EntidadContacto WITH(NOLOCK) WHERE IdEntidad = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EntidadContacto',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEntidad),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEntidad),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EntidadContacto WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EntidadContacto',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEntidad),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEntidad),        @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EntidadContacto WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
			END CATCH        
		END        
		--EntidadRepresentante----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  INSERT INTO EntidadRepresentante (IdEntidad, IdRepresentante, Principal)         
		--  SELECT @IdActorDestino, IdRepresentante, Principal        
		--  FROM EntidadRepresentante WITH(NOLOCK) WHERE IdEntidad = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'EntidadRepresentante',        
		--  CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdRepresentante),        
		--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdRepresentante),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EntidadRepresentante WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'EntidadRepresentante',        
		--  CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdRepresentante),        
		--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdRepresentante),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EntidadRepresentante WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
		-- END CATCH        
		--END        
		----ConvenioEntidad----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  INSERT INTO ConvenioEntidad (Activo, FechaModificacion, IdConvenio, IdEntidad, UsuarioModificacion)         
		--  SELECT Activo, FechaModificacion, IdConvenio, @IdActorDestino, UsuarioModificacion        
		--  FROM ConvenioEntidad WITH(NOLOCK) WHERE IdEntidad = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'ConvenioEntidad',        
		--  CONVERT(VARCHAR,IdConvenio)+','+CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,IdConvenio)+','+CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ConvenioEntidad WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'ConvenioEntidad',        
		--  CONVERT(VARCHAR,IdConvenio)+','+CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,IdConvenio)+','+CONVERT(VARCHAR,@IdActorDestino),     
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ConvenioEntidad WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
		-- END CATCH        
		--END        
		--EmpleadoEmpresa----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO EmpleadoEmpresa (AfiliadoEPS, AnexoOficina, EsBaja, EsDocente, EsPlanilla, FechaBaja, FechaCreacion, FechaModificacion, IdAreaLaboral,         
				IdCargo, IdCategoriaLaboral, IdContratoAdendaPrimero, IdContratoAdendaUltimo, IdEmpleado, IdEmpresa, IdEmpresaLaboral, IdEPS, IdJefeInmediato,         
				IdMotivoBaja, IdOcupacion, IdPeriodicidadIngreso, IdSctrPension, IdSctrSalud, IdSedeLaboral, IdSituacionEspecial, IdSituacionLaboral, InformaIngresosQuinta,         
				Sindicalizado, TelefonoOficina, TieneRentaExoneradas, UsuarioCreacion, UsuarioModificacion)         
				SELECT AfiliadoEPS, AnexoOficina, EsBaja, EsDocente, EsPlanilla, FechaBaja, FechaCreacion, FechaModificacion, IdAreaLaboral,         
				IdCargo, IdCategoriaLaboral, IdContratoAdendaPrimero, IdContratoAdendaUltimo, @IdActorDestino, IdEmpresa, IdEmpresaLaboral, IdEPS, IdJefeInmediato,         
				IdMotivoBaja, IdOcupacion, IdPeriodicidadIngreso, IdSctrPension, IdSctrSalud, IdSedeLaboral, IdSituacionEspecial, IdSituacionLaboral, InformaIngresosQuinta,         
				Sindicalizado, TelefonoOficina, TieneRentaExoneradas, UsuarioCreacion, UsuarioModificacion        
				FROM EmpleadoEmpresa WITH(NOLOCK) WHERE IdEmpleado = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoEmpresa',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpresa),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpresa),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoEmpresa WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoEmpresa',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpresa),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpresa),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoEmpresa WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END CATCH        
		END        
		--SustitutorioAlumno----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO SustitutorioAlumno (Asistio, FechaCreacion, FechaModificacion, IdAlumno, IdCalificacion, IdSeccion, IdSustitutorio, Nota, UsuarioCreacion, UsuarioModificacion)         
				SELECT Asistio, FechaCreacion, FechaModificacion, @IdActorDestino, IdCalificacion, IdSeccion, IdSustitutorio, Nota, UsuarioCreacion, UsuarioModificacion        
				FROM SustitutorioAlumno WITH(NOLOCK) WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'SustitutorioAlumno',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdSustitutorio),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdSustitutorio),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from SustitutorioAlumno WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'SustitutorioAlumno',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdSustitutorio),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdSustitutorio),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from SustitutorioAlumno WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END CATCH        
		END        
          
		--EmpleadoAreaAcademica----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO EmpleadoAreaAcademica (IdArea, IdEmpleado, IdEmpresa)         
				SELECT IdArea, @IdActorDestino, IdEmpresa        
				FROM EmpleadoAreaAcademica WITH(NOLOCK) WHERE IdEmpleado = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoAreaAcademica',        
				CONVERT(VARCHAR,IdArea)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpresa),        
				CONVERT(VARCHAR,IdArea)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpresa),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoAreaAcademica WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoAreaAcademica',        
				CONVERT(VARCHAR,IdArea)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpresa),        
				CONVERT(VARCHAR,IdArea)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpresa),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoAreaAcademica WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END CATCH        
		END        
		--EmpleadoCurso----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO EmpleadoCurso (IdCurso, IdEmpleado, IdEmpresa)         
				SELECT IdCurso, @IdActorDestino, IdEmpresa        
				FROM EmpleadoCurso WITH(NOLOCK) WHERE IdEmpleado = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoCurso',        
				CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpresa),        
				CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpresa),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoCurso WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoCurso',        
				CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpresa),        
				CONVERT(VARCHAR,IdCurso)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpresa),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoCurso WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END CATCH        
		END        
		----Permiso----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  IF NOT EXISTS (SELECT 1 FROM Permiso P INNER JOIN Usuario U ON U.IdUsuario = P.IdUsuario WHERE U.IdActor=@IdActorDestino)        
		--  INSERT INTO Permiso (IdSistema, IdRol, IdUsuario)         
		--  SELECT P.IdSistema, P.IdRol, P.IdUsuario        
		--  FROM Permiso P        
		--  INNER JOIN Usuario U ON U.IdUsuario = P.IdUsuario         
		--  WHERE U.IdActor=@IdActorOrigen        
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Permiso',        
		--  CONVERT(VARCHAR,P.IdSistema)+', '+CONVERT(VARCHAR,P.IdRol)+', '+CONVERT(VARCHAR,P.IdUsuario),        
		--  CONVERT(VARCHAR,P.IdSistema)+', '+CONVERT(VARCHAR,P.IdRol)+', '+CONVERT(VARCHAR,P.IdUsuario),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
		--  FROM Permiso P         
		--  INNER JOIN Usuario U ON U.IdUsuario = P.IdUsuario         
		--  WHERE U.IdActor=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Permiso',        
		--  CONVERT(VARCHAR,P.IdSistema)+', '+CONVERT(VARCHAR,P.IdRol)+', '+CONVERT(VARCHAR,P.IdUsuario),        
		--  CONVERT(VARCHAR,P.IdSistema)+', '+CONVERT(VARCHAR,P.IdRol)+', '+CONVERT(VARCHAR,P.IdUsuario),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
		--  FROM Permiso P         
		--  INNER JOIN Usuario U ON U.IdUsuario = P.IdUsuario         
		--  WHERE U.IdActor=@IdActorOrigen        
		-- END CATCH        
		--END         
          
		--Contacto ----------------------------------------------------------------------------------------------------------------------            
		BEGIN         
			BEGIN TRY        
				IF NOT EXISTS (SELECT * FROM Contacto WITH(NOLOCK) WHERE IdContacto = @IdActorDestino)        
				INSERT INTO CONTACTO        
				(IdContacto,IdEmpresa,IdSede,CodigoAnterior,IdCounter,EsIndependiente,EsNegocioPropio,EsEmpresaFamiliar,EsProfesionalIndependiente,Activo,IdImportacion,UsuarioCreacion,FechaCreacion,UsuarioModificacion,FechaModificacion)        
				SELECT @IdActorDestino,IdEmpresa,IdSede,CodigoAnterior,IdCounter,EsIndependiente,EsNegocioPropio,EsEmpresaFamiliar,EsProfesionalIndependiente,Activo,IdImportacion,UsuarioCreacion,FechaCreacion,UsuarioModificacion,FechaModificacion        
				FROM Contacto WITH(NOLOCK)        
				WHERE IdContacto = @IdActorOrigen          
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Contacto',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Contacto WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Contacto',        
				CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Contacto WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END CATCH        
           
		END         
          
		--ContactoReferido----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO ContactoReferido (IdContacto, IdReferido)        
				SELECT @IdActorDestino, IdReferido         
				FROM ContactoReferido WITH(NOLOCK)         
				WHERE IdContacto = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ContactoReferido',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdReferido),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdReferido),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ContactoReferido WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ContactoReferido',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdReferido),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdReferido),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ContactoReferido WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END CATCH        
		END        
		--CorreoDirectoContacto----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO CorreoDirectoContacto (IdContacto, IdCorreoDirecto)        
				SELECT @IdActorDestino, IdCorreoDirecto         
				FROM CorreoDirectoContacto WITH(NOLOCK)         
				WHERE IdContacto = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'CorreoDirectoContacto',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdCorreoDirecto),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCorreoDirecto),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from CorreoDirectoContacto WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'CorreoDirectoContacto',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdCorreoDirecto),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCorreoDirecto),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from CorreoDirectoContacto WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END CATCH        
		END        
		--ContactoCurso----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY  
				INSERT INTO ContactoCurso (IdAtencion, IdContacto, IdCurso)        
				SELECT IdAtencion, @IdActorDestino, IdCurso        
				FROM ContactoCurso WITH(NOLOCK)        
				WHERE IdContacto = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ContactoCurso',        
				CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdCurso),        
				CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurso),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ContactoCurso WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)  
				SELECT @IdProceso,'ContactoCurso',        
				CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdCurso),        
				CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCurso),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ContactoCurso WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END CATCH        
		END        
		--ContactoFrecuencia----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				INSERT INTO ContactoFrecuencia (IdAtencion, IdContacto, IdFrecuencia)        
				SELECT IdAtencion, @IdActorDestino, IdFrecuencia        
				FROM ContactoFrecuencia WITH(NOLOCK)        
				WHERE IdContacto = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ContactoFrecuencia',        
				CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdFrecuencia),        
				CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdFrecuencia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ContactoFrecuencia WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ContactoFrecuencia',        
				CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdFrecuencia),        
				CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdFrecuencia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ContactoFrecuencia WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END CATCH        
		END        
          
		--ContactoAtencion----------------------------------------------------------------------------------------------------------------------           
		BEGIN        
			DECLARE @VarTablaContactoAtencion TABLE (Id int, Asistio bit, AtencionDuracion int, AtencionFecha datetime, Atendido varchar(10), Confirmo bit,         
			Falto bit, FechaCreacion datetime, FechaModificacion datetime, IdAtencion int, IdBeneficio int, IdCampana int, IdContacto int,         
			IdContactoAtencion int, IdCorreoDirecto int, IdCounter int, IdEmpresa int, IdEmpresaInteres int, IdEstadoAtencion int, IdEvento int,         
			IdFichaInteresado int, IdMatricula int, IdMedioDifusion int, IdMensaje int, IdObjecion int, IdResultadoAtencion int, IdSede int,         
			IdSedeInteres int, IdTipoAtencion int, IdTipoMedioDifusion int, Invito bit, NoAcompanante int, NoPadre int, Observacion varchar(500),         
			UsuarioCreacion int, UsuarioModificacion int, IdAtencionOld int)        
			INSERT INTO @VarTablaContactoAtencion (Id, Asistio, AtencionDuracion, AtencionFecha, Atendido, Confirmo, Falto, FechaCreacion, FechaModificacion,         
			IdAtencion, IdBeneficio, IdCampana, IdContacto, IdContactoAtencion, IdCorreoDirecto, IdCounter, IdEmpresa, IdEmpresaInteres, IdEstadoAtencion,         
			IdEvento, IdFichaInteresado, IdMatricula, IdMedioDifusion, IdMensaje, IdObjecion, IdResultadoAtencion, IdSede, IdSedeInteres, IdTipoAtencion,         
			IdTipoMedioDifusion, Invito, NoAcompanante, NoPadre, Observacion, UsuarioCreacion, UsuarioModificacion, IdAtencionOld)         
			SELECT ROW_NUMBER() OVER (ORDER BY IdContactoAtencion), Asistio, AtencionDuracion, AtencionFecha, Atendido, Confirmo, Falto, FechaCreacion, FechaModificacion,         
			IdAtencion, IdBeneficio, IdCampana, @IdActorDestino, IdContactoAtencion, IdCorreoDirecto, IdCounter, IdEmpresa, IdEmpresaInteres, IdEstadoAtencion,         
			IdEvento, IdFichaInteresado, IdMatricula, IdMedioDifusion, IdMensaje, IdObjecion, IdResultadoAtencion, IdSede, IdSedeInteres, IdTipoAtencion,         
			IdTipoMedioDifusion, Invito, NoAcompanante, NoPadre, Observacion, UsuarioCreacion, UsuarioModificacion, IdAtencion        
			FROM ContactoAtencion WITH(NOLOCK)         
			WHERE IdContacto = @IdActorOrigen          
           
			DECLARE @IdAtencionMax INT = (select max(IdAtencion) from ContactoAtencion)        
           
			DECLARE @oCurIdContactoAtencion INT, @oMaxIdContactoAtencion INT        
			SELECT @oCurIdContactoAtencion=1, @oMaxIdContactoAtencion=Max(Id) FROM @VarTablaContactoAtencion        
			WHILE @oMaxIdContactoAtencion >= @oCurIdContactoAtencion         
			BEGIN         
				DECLARE @IdAtencion INT        
				SET @IdAtencion = (SELECT IdAtencion FROM @VarTablaContactoAtencion  WHERE   ID=@oCurIdContactoAtencion)        
            
				BEGIN TRY         
					DECLARE @IdAtencionNew Int = @IdAtencionMax + @oCurIdContactoAtencion        
             
					INSERT INTO ContactoAtencion (Asistio, AtencionDuracion, AtencionFecha, Atendido, Confirmo, Falto, FechaCreacion, FechaModificacion,         
					IdAtencion, IdBeneficio, IdCampana, IdContacto, IdContactoAtencion, IdCorreoDirecto, IdCounter, IdEmpresa, IdEmpresaInteres,         
					IdEstadoAtencion, IdEvento, IdFichaInteresado, IdMatricula, IdMedioDifusion, IdMensaje, IdObjecion, IdResultadoAtencion, IdSede,         
					IdSedeInteres, IdTipoAtencion, IdTipoMedioDifusion, Invito, NoAcompanante, NoPadre, Observacion, UsuarioCreacion, UsuarioModificacion)         
					SELECT Asistio, AtencionDuracion, AtencionFecha, Atendido, Confirmo, Falto, FechaCreacion, FechaModificacion, @IdAtencionNew, IdBeneficio,         
					IdCampana, @IdActorDestino, IdContactoAtencion, IdCorreoDirecto, IdCounter, IdEmpresa, IdEmpresaInteres, IdEstadoAtencion, IdEvento,         
					IdFichaInteresado, IdMatricula, IdMedioDifusion, IdMensaje, IdObjecion, IdResultadoAtencion, IdSede, IdSedeInteres, IdTipoAtencion,         
					IdTipoMedioDifusion, Invito, NoAcompanante, NoPadre, Observacion, UsuarioCreacion, UsuarioModificacion         
					FROM @varTablaContactoAtencion        
					WHERE Id = @oCurIdContactoAtencion         
             
					INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
					SELECT @IdProceso,'ContactoAtencion',        
					CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdAtencion),        
					CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAtencionNew),        
					@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
					FROM @VarTablaContactoAtencion         
					WHERE Id = @oCurIdContactoAtencion         
				END TRY        
				BEGIN CATCH         
					SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
					INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
					SELECT @IdProceso,'ContactoAtencion',        
					CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdAtencion),        
					CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAtencionNew),        
					@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
					FROM @VarTablaContactoAtencion         
					WHERE Id = @oCurIdContactoAtencion         
				END CATCH        
            
				--ContactoInteresado----------------------------------------------------------------------------------------------------------------------        
				DECLARE @VarTablaContactoInteresado TABLE (Id int, IdAtencion int, IdContacto int, IdInteresado int)        
				delete @VarTablaContactoInteresado        
				INSERT INTO @VarTablaContactoInteresado (Id, IdAtencion, IdContacto, IdInteresado)        
				SELECT ROW_NUMBER() OVER (ORDER BY IdContacto), IdAtencion, @IdActorDestino, IdInteresado        
				FROM ContactoInteresado WITH(NOLOCK) WHERE IdContacto = @IdActorOrigen AND IdAtencion = @IdAtencion         
            
				DECLARE @oCurIdContactoInteresado INT, @oMaxIdContactoInteresado INT        
				SELECT @oCurIdContactoInteresado=1, @oMaxIdContactoInteresado=Max(Id) FROM @VarTablaContactoInteresado        
				WHILE @oMaxIdContactoInteresado >= @oCurIdContactoInteresado         
				BEGIN        
					BEGIN TRY        
						INSERT INTO ContactoInteresado (IdAtencion, IdContacto, IdInteresado)         
						SELECT @IdAtencionNew, IdContacto, IdInteresado        
						FROM @VarTablaContactoInteresado         
						WHERE Id = @oCurIdContactoInteresado         
        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'ContactoInteresado',        
						CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,IdInteresado),        
						CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAtencionNew)+','+CONVERT(VARCHAR,IdInteresado),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaContactoInteresado         
						WHERE Id = @oCurIdContactoInteresado         
					END TRY        
					BEGIN CATCH         
						SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
						INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
						SELECT @IdProceso,'ContactoInteresado',        
						CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,@IdAtencion)+','+CONVERT(VARCHAR,IdInteresado),        
						CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAtencionNew)+','+CONVERT(VARCHAR,IdInteresado),        
						@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
						FROM @VarTablaContactoInteresado         
						WHERE Id = @oCurIdContactoInteresado         
					END CATCH        
            
					SET @oCurIdContactoInteresado = @oCurIdContactoInteresado+1         
             
				END        
            
				----ContactoTurno----------------------------------------------------------------------------------------------------------------------        
				--DECLARE @VarTablaContactoTurno TABLE (Id int, IdAtencion int, IdContacto int, IdTipoTurno int)        
				--delete @VarTablaContactoTurno        
				--INSERT INTO @VarTablaContactoTurno (Id, IdAtencion, IdContacto, IdTipoTurno)        
				--SELECT ROW_NUMBER() OVER (ORDER BY IdContacto), @IdAtencionNew, @IdActorDestino, IdTipoTurno        
				--FROM ContactoTurno WHERE IdContacto = @IdActorOrigen AND IdAtencion = @IdAtencion         
            
				--DECLARE @oCurIdContactoTurno INT, @oMaxIdContactoTurno INT        
				--SELECT @oCurIdContactoTurno=1, @oMaxIdContactoTurno=Max(Id) FROM @VarTablaContactoTurno        
				--WHILE @oMaxIdContactoTurno >= @oCurIdContactoTurno         
				--BEGIN        
				-- BEGIN TRY        
				--  INSERT INTO ContactoTurno (IdAtencion, IdContacto, IdTipoTurno)         
				--  SELECT IdAtencion, IdContacto, IdTipoTurno        
				--  FROM @VarTablaContactoTurno         
				--  WHERE Id = @oCurIdContactoTurno         
        
				--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				--  SELECT @IdProceso,'ContactoTurno',        
				--  CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,IdTipoTurno),        
				--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAtencionNew)+','+CONVERT(VARCHAR,IdTipoTurno),        
				--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				--  FROM @VarTablaContactoTurno         
				--  WHERE Id = @oCurIdContactoTurno         
				-- END TRY        
				-- BEGIN CATCH         
				--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				--  SELECT @IdProceso,'ContactoTurno',        
				--  CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdAtencion)+','+CONVERT(VARCHAR,IdTipoTurno),        
				--  CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,@IdAtencionNew)+','+CONVERT(VARCHAR,IdTipoTurno),        
				--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
				--  FROM @VarTablaContactoTurno         
				--  WHERE Id = @oCurIdContactoTurno         
				-- END CATCH        
            
				-- SET @oCurIdContactoTurno = @oCurIdContactoTurno+1         
             
				--END        
                   
				SET @oCurIdContactoAtencion = @oCurIdContactoAtencion+1         
           
			END        
           
		END          
          
		--F--CapacitacionFacilitador----------------------------------------------------------------------------------------------------------------------           
		--BEGIN        
		-- DECLARE @VarTablaCapacitacionFacilitador TABLE (Id int, FechaCreacion datetime, FechaModificacion datetime, IdCapacitacion int, IdFacilitador int, UsuarioCreacion int, UsuarioModificacion int)        
		-- INSERT INTO @VarTablaCapacitacionFacilitador (Id, FechaCreacion, FechaModificacion, IdCapacitacion, IdFacilitador, UsuarioCreacion, UsuarioModificacion)         
		-- SELECT ROW_NUMBER() OVER (ORDER BY IdFacilitador), FechaCreacion, FechaModificacion, IdCapacitacion, @IdActorDestino, UsuarioCreacion, UsuarioModificacion        
		-- FROM CapacitacionFacilitador WHERE IdFacilitador = @IdActorOrigen          
           
		-- DECLARE @oCurIdCapacitacionFacilitador INT, @oMaxIdCapacitacionFacilitador INT        
		-- SELECT @oCurIdCapacitacionFacilitador=1, @oMaxIdCapacitacionFacilitador=Max(Id) FROM @VarTablaCapacitacionFacilitador        
		-- WHILE @oMaxIdCapacitacionFacilitador >= @oCurIdCapacitacionFacilitador       -- BEGIN         
		--  DECLARE @IdCapacitacion INT        
		--  SET @IdCapacitacion = (SELECT IdCapacitacion FROM @VarTablaCapacitacionFacilitador WHERE ID=@oCurIdCapacitacionFacilitador)        
            
		--  BEGIN TRY         
		--   INSERT INTO CapacitacionFacilitador (FechaCreacion, FechaModificacion, IdCapacitacion, IdFacilitador, UsuarioCreacion, UsuarioModificacion)         
		--   SELECT FechaCreacion, FechaModificacion, IdCapacitacion, @IdActorDestino, UsuarioCreacion, UsuarioModificacion        
		--   FROM @varTablaCapacitacionFacilitador        
		--   WHERE Id = @oCurIdCapacitacionFacilitador         
            
		--   INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--   SELECT @IdProceso,'CapacitacionFacilitador',        
		--   CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdCapacitacion),        
		--   CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCapacitacion),        
		--   @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
		--   FROM @VarTablaCapacitacionFacilitador         
		--   WHERE Id = @oCurIdCapacitacionFacilitador         
		--  END TRY        
		--  BEGIN CATCH         
		--   SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--   INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--   SELECT @IdProceso,'CapacitacionFacilitador',        
		--   CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdCapacitacion),        
		--   CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCapacitacion),        
		--   @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
		--   FROM @VarTablaCapacitacionFacilitador         
		--   WHERE Id = @oCurIdCapacitacionFacilitador         
		--  END CATCH        
            
		--  F--CapacitacionAsistencia----------------------------------------------------------------------------------------------------------------------        
		--  DECLARE @VarTablaCapacitacionAsistencia TABLE (Id int, Asistio char(1), FechaCreacion datetime, FechaModificacion datetime, IdCapacitacion int, IdFacilitador int, IdSesion int,         
		--  Justificacion varchar(500), UsuarioCreacion int, UsuarioModificacion int)        
		--  delete @VarTablaCapacitacionAsistencia        
		--  INSERT INTO @VarTablaCapacitacionAsistencia (Id, Asistio, FechaCreacion, FechaModificacion, IdCapacitacion, IdFacilitador, IdSesion, Justificacion, UsuarioCreacion, UsuarioModificacion)        
		--  SELECT ROW_NUMBER() OVER (ORDER BY IdFacilitador), Asistio, FechaCreacion, FechaModificacion, IdCapacitacion, @IdActorDestino, IdSesion, Justificacion, UsuarioCreacion, UsuarioModificacion        
		--  FROM CapacitacionAsistencia WHERE IdFacilitador = @IdActorOrigen AND IdCapacitacion = @IdCapacitacion         
            
		--  DECLARE @oCurIdCapacitacionAsistencia INT, @oMaxIdCapacitacionAsistencia INT        
		--  SELECT @oCurIdCapacitacionAsistencia=1, @oMaxIdCapacitacionAsistencia=Max(Id) FROM @VarTablaCapacitacionAsistencia        
		--  WHILE @oMaxIdCapacitacionAsistencia >= @oCurIdCapacitacionAsistencia         
		--  BEGIN        
		--   BEGIN TRY        
		--    INSERT INTO CapacitacionAsistencia (Asistio, FechaCreacion, FechaModificacion, IdCapacitacion, IdFacilitador, IdSesion, Justificacion, UsuarioCreacion, UsuarioModificacion)         
		--    SELECT Asistio, FechaCreacion, FechaModificacion, IdCapacitacion, @IdActorDestino, IdSesion, Justificacion, UsuarioCreacion, UsuarioModificacion        
		--    FROM @VarTablaCapacitacionAsistencia         
		--    WHERE Id = @oCurIdCapacitacionAsistencia         
        
		--    INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--    SELECT @IdProceso,'CapacitacionAsistencia',        
		--    CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdCapacitacion)+','+CONVERT(VARCHAR,IdSesion),        
		--    CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCapacitacion)+','+CONVERT(VARCHAR,IdSesion),        
		--    @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
		--    FROM @VarTablaCapacitacionAsistencia         
		--    WHERE Id = @oCurIdCapacitacionAsistencia         
		--   END TRY        
		--   BEGIN CATCH         
		--    SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--    INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--    SELECT @IdProceso,'CapacitacionAsistencia',        
		--    CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdCapacitacion)+','+CONVERT(VARCHAR,IdSesion),        
		--    CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdCapacitacion)+','+CONVERT(VARCHAR,IdSesion),        
		--    @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE()         
		--    FROM @VarTablaCapacitacionAsistencia         
		--    WHERE Id = @oCurIdCapacitacionAsistencia    
		--   END CATCH        
            
		--   SET @oCurIdCapacitacionAsistencia = @oCurIdCapacitacionAsistencia+1         
             
		--  END        
               
		--  SET @oCurIdCapacitacionFacilitador = @oCurIdCapacitacionFacilitador+1     
           
		-- END        
           
		--END          
          
		--END         
		--UPDATES        
		--BEGIN        
            
		--F--CapacitacionProgramacion----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE CapacitacionProgramacion SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'CapacitacionProgramacion',        
		--  CONVERT(VARCHAR,IdCapacitacion)+','+CONVERT(VARCHAR,IdSesion),        
		--  CONVERT(VARCHAR,IdCapacitacion)+','+CONVERT(VARCHAR,IdSesion),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from CapacitacionProgramacion where IdActor=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'CapacitacionProgramacion',        
		--  CONVERT(VARCHAR,IdCapacitacion)+','+CONVERT(VARCHAR,IdSesion),        
		--  CONVERT(VARCHAR,IdCapacitacion)+','+CONVERT(VARCHAR,IdSesion),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from CapacitacionProgramacion where IdActor=@IdActorOrigen        
		-- END CATCH        
		--END         
		--F--PostulanteFacilitador----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE PostulanteFacilitador SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'PostulanteFacilitador',        
		--  CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitador where IdActor=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'PostulanteFacilitador',        
		--  CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitador where IdActor=@IdActorOrigen            
		-- END CATCH        
		--END         
		--F--Consejerias----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE Consejerias SET IdConsejero=@IdActorDestino WHERE IdConsejero = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Consejerias',        
		--  CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Consejerias where IdConsejero=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Consejerias',        
		--  CONVERT(VARCHAR,@IdActorOrigen),        
		--  CONVERT(VARCHAR,@IdActorDestino),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Consejerias where IdConsejero=@IdActorOrigen        
		-- END CATCH        
		--END         
		--F--Incidencia----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE Incidencia SET IdResponsable=@IdActorDestino WHERE IdResponsable = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Incidencia',        
		--  CONVERT(VARCHAR,IdIncidencia),        
		--  CONVERT(VARCHAR,IdIncidencia),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Incidencia where IdResponsable=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Incidencia',        
		--  CONVERT(VARCHAR,IdIncidencia),        
		--  CONVERT(VARCHAR,IdIncidencia),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Incidencia where IdResponsable=@IdActorOrigen        
		-- END CATCH        
		--END         
		--Usuario----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE Usuario SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Usuario',        
				CONVERT(VARCHAR,IdUsuario),        
				CONVERT(VARCHAR,IdUsuario),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Usuario WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Usuario',        
				CONVERT(VARCHAR,IdUsuario),        
				CONVERT(VARCHAR,IdUsuario),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Usuario WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END         
               
		--ProgramacionConcepto----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE ProgramacionConcepto SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ProgramacionConcepto',        
				CONVERT(VARCHAR,IdProgramacion),        
				CONVERT(VARCHAR,IdProgramacion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ProgramacionConcepto WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ProgramacionConcepto',        
				CONVERT(VARCHAR,IdProgramacion),    
				CONVERT(VARCHAR,IdProgramacion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ProgramacionConcepto WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END        
		--RegistroDocumento----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE RegistroDocumento SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'RegistroDocumento',        
				CONVERT(VARCHAR,IdRegistroDocumento),        
				CONVERT(VARCHAR,IdRegistroDocumento),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from RegistroDocumento WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'RegistroDocumento',        
				CONVERT(VARCHAR,IdRegistroDocumento),        
				CONVERT(VARCHAR,IdRegistroDocumento),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from RegistroDocumento WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END          
		--ActorReferencia----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE ActorReferencia SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorReferencia',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdReferencia),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdReferencia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorReferencia WITH(NOLOCK) where IdActor=@IdActorOrigen        
				END TRY        
				BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorReferencia',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdReferencia),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdReferencia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorReferencia WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END          
		--F--Incidencia----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE Incidencia SET IdFacilitador=@IdActorDestino WHERE IdFacilitador = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)       
		--  SELECT @IdProceso,'Incidencia',        
		--  CONVERT(VARCHAR,IdIncidencia),        
		--  CONVERT(VARCHAR,IdIncidencia),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Incidencia where IdFacilitador=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'Incidencia',        
		--  CONVERT(VARCHAR,IdIncidencia),        
		--  CONVERT(VARCHAR,IdIncidencia),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Incidencia where IdFacilitador=@IdActorOrigen         
		-- END CATCH        
		--END          
		--F--FichaRespuestaFacilitador----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE FichaRespuestaFacilitador SET IdFacilitador=@IdActorDestino WHERE IdFacilitador = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FichaRespuestaFacilitador',        
		--  CONVERT(VARCHAR,IdRespuesta),        
		--  CONVERT(VARCHAR,IdRespuesta),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FichaRespuestaFacilitador where IdFacilitador=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'FichaRespuestaFacilitador',        
		--  CONVERT(VARCHAR,IdRespuesta),        
		--  CONVERT(VARCHAR,IdRespuesta),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FichaRespuestaFacilitador where IdFacilitador=@IdActorOrigen        
		-- END CATCH        
		--END          
		--ActorTrabajo----------------------------------------------------------------------------------------------------------------------        
		BEGIN     
			BEGIN TRY        
				UPDATE ActorTrabajo SET IdEntidad=@IdActorDestino WHERE IdEntidad = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorTrabajo',        
				CONVERT(VARCHAR,IdActor)+','+CONVERT(VARCHAR,IdTrabajo),        
				CONVERT(VARCHAR,IdActor)+','+CONVERT(VARCHAR,IdTrabajo),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorTrabajo WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ActorTrabajo',        
				CONVERT(VARCHAR,IdActor)+','+CONVERT(VARCHAR,IdTrabajo),        
				CONVERT(VARCHAR,IdActor)+','+CONVERT(VARCHAR,IdTrabajo),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ActorTrabajo WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
			END CATCH        
		END          
		--F--PostulanteFacilitadorAdicional----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE PostulanteFacilitadorAdicional SET IdEntidad=@IdActorDestino WHERE IdEntidad = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'PostulanteFacilitadorAdicional',        
		--  CONVERT(VARCHAR,IdAdicional)+','+CONVERT(VARCHAR,IdPostulanteFacilitador),        
		--  CONVERT(VARCHAR,IdAdicional)+','+CONVERT(VARCHAR,IdPostulanteFacilitador),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitadorAdicional where IdEntidad=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'PostulanteFacilitadorAdicional',        
		--  CONVERT(VARCHAR,IdAdicional)+','+CONVERT(VARCHAR,IdPostulanteFacilitador),        
		--  CONVERT(VARCHAR,IdAdicional)+','+CONVERT(VARCHAR,IdPostulanteFacilitador),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitadorAdicional where IdEntidad=@IdActorOrigen            
		-- END CATCH        
		--END          
		--F--PostulanteFacilitadorEstudios----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE PostulanteFacilitadorEstudios SET IdEntidad=@IdActorDestino WHERE IdEntidad = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'PostulanteFacilitadorEstudios',        
		--  CONVERT(VARCHAR,IdEstudioRealizado)+','+CONVERT(VARCHAR,IdPostulanteFacilitador),        
		--  CONVERT(VARCHAR,IdEstudioRealizado)+','+CONVERT(VARCHAR,IdPostulanteFacilitador),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitadorEstudios where IdEntidad=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'PostulanteFacilitadorEstudios',        
		--  CONVERT(VARCHAR,IdEstudioRealizado)+','+CONVERT(VARCHAR,IdPostulanteFacilitador),        
		--  CONVERT(VARCHAR,IdEstudioRealizado)+','+CONVERT(VARCHAR,IdPostulanteFacilitador),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitadorEstudios where IdEntidad=@IdActorOrigen           
		-- END CATCH        
		--END         
		--F--PostulanteFacilitadorExperiencia----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE PostulanteFacilitadorExperiencia SET IdEntidad=@IdActorDestino WHERE IdEntidad = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'PostulanteFacilitadorExperiencia',        
		--  CONVERT(VARCHAR,IdExperienciaLaboral)+','+CONVERT(VARCHAR,IdPostulanteFacilitador)+','+CONVERT(VARCHAR,TipoExperiencia),        
		--  CONVERT(VARCHAR,IdExperienciaLaboral)+','+CONVERT(VARCHAR,IdPostulanteFacilitador)+','+CONVERT(VARCHAR,TipoExperiencia),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitadorExperiencia where IdEntidad=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'PostulanteFacilitadorExperiencia',        
		--  CONVERT(VARCHAR,IdExperienciaLaboral)+','+CONVERT(VARCHAR,IdPostulanteFacilitador)+','+CONVERT(VARCHAR,TipoExperiencia),        
		--  CONVERT(VARCHAR,IdExperienciaLaboral)+','+CONVERT(VARCHAR,IdPostulanteFacilitador)+','+CONVERT(VARCHAR,TipoExperiencia),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitadorExperiencia where IdEntidad=@IdActorOrigen            
		-- END CATCH        
		--END         
		--WorkFlowExpediente----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE WorkFlowExpediente SET IdWfEntidad=@IdActorDestino WHERE IdWfEntidad = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'WorkFlowExpediente',        
				CONVERT(VARCHAR,IdWfExpediente),        
				CONVERT(VARCHAR,IdWfExpediente),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from WorkFlowExpediente WITH(NOLOCK) where IdWfEntidad=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'WorkFlowExpediente',        
				CONVERT(VARCHAR,IdWfExpediente),        
				CONVERT(VARCHAR,IdWfExpediente),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from WorkFlowExpediente WITH(NOLOCK) where IdWfEntidad=@IdActorOrigen            
			END CATCH        
		END         
		--Matricula----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE Matricula SET IdSocio=@IdActorDestino WHERE IdSocio = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Matricula',        
				CONVERT(VARCHAR,IdMatricula),        
				CONVERT(VARCHAR,IdMatricula),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Matricula WITH(NOLOCK) where IdSocio=@IdActorOrigen        
			END TRY        
			BEGIN CATCH     
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Matricula',        
				CONVERT(VARCHAR,IdMatricula),        
				CONVERT(VARCHAR,IdMatricula),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Matricula WITH(NOLOCK) where IdSocio=@IdActorOrigen            
			END CATCH        
		END         
		--MatriculaSeguimiento----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE MatriculaSeguimiento SET IdAlumno=@IdActorDestino WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'MatriculaSeguimiento',        
				CONVERT(VARCHAR,IdMatriculaSeguimiento),        
				CONVERT(VARCHAR,IdMatriculaSeguimiento),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from MatriculaSeguimiento  WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())       
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'MatriculaSeguimiento',        
				CONVERT(VARCHAR,IdMatriculaSeguimiento),        
				CONVERT(VARCHAR,IdMatriculaSeguimiento),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from MatriculaSeguimiento WITH(NOLOCK) where IdAlumno=@IdActorOrigen            
			END CATCH        
		END         
		--AlumnoBaja----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE MatriculaSeguimiento SET IdAlumno=@IdActorDestino WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoBaja',        
				CONVERT(VARCHAR,IdBaja),        
				CONVERT(VARCHAR,IdBaja),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoBaja WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoBaja',        
				CONVERT(VARCHAR,IdBaja),        
				CONVERT(VARCHAR,IdBaja),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoBaja WITH(NOLOCK) where IdAlumno=@IdActorOrigen           
			END CATCH        
		END         
		--AlumnoCartaPermanencia----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE AlumnoCartaPermanencia SET IdAlumno=@IdActorDestino WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoCartaPermanencia',        
				CONVERT(VARCHAR,IdCartaPermanencia),        
				CONVERT(VARCHAR,IdCartaPermanencia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoCartaPermanencia WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoCartaPermanencia',        
				CONVERT(VARCHAR,IdCartaPermanencia),        
				CONVERT(VARCHAR,IdCartaPermanencia),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoCartaPermanencia WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END CATCH        
		END         
		--Consejerias----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE Consejerias SET IdAlumno=@IdActorDestino WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Consejerias',        
				CONVERT(VARCHAR,IdConsejeria),        
				CONVERT(VARCHAR,IdConsejeria),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Consejerias WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Consejerias',        
				CONVERT(VARCHAR,IdConsejeria),        
				CONVERT(VARCHAR,IdConsejeria),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Consejerias WITH(NOLOCK) where IdAlumno=@IdActorOrigen            
			END CATCH        
		END         
		--Justificacion----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE Justificacion SET IdAlumno=@IdActorDestino WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Justificacion',        
				CONVERT(VARCHAR,IdJustificacion),        
				CONVERT(VARCHAR,IdJustificacion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Justificacion WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Justificacion',        
				CONVERT(VARCHAR,IdJustificacion),        
				CONVERT(VARCHAR,IdJustificacion),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Justificacion WITH(NOLOCK) where IdAlumno=@IdActorOrigen            
			END CATCH        
		END         
          
		--Matricula----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE Matricula SET IdEntidad=@IdActorDestino WHERE IdEntidad = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Matricula',        
				CONVERT(VARCHAR,IdMatricula),        
				CONVERT(VARCHAR,IdMatricula),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Matricula WITH(NOLOCK) where IdEntidad=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'Matricula',        
				CONVERT(VARCHAR,IdMatricula),        
				CONVERT(VARCHAR,IdMatricula),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from Matricula WITH(NOLOCK) where IdEntidad=@IdActorOrigen           
			END CATCH        
		END         
		--EmpleadoNivelEstructural----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE EmpleadoNivelEstructural SET IdEmpleado=@IdActorDestino WHERE IdEmpleado = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoNivelEstructural',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpleadoNivelEstructural),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpleadoNivelEstructural),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoNivelEstructural WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoNivelEstructural',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpleadoNivelEstructural),   
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpleadoNivelEstructural),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoNivelEstructural WITH(NOLOCK) where IdEmpleado=@IdActorOrigen           
			END CATCH        
		END         
		--EmpleadoTarifa----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE EmpleadoTarifa SET IdEmpleado=@IdActorDestino WHERE IdEmpleado = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoTarifa',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpleadoTarifa),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpleadoTarifa),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoTarifa WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END TRY       
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoTarifa',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpleadoTarifa),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpleadoTarifa),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoTarifa WITH(NOLOCK) where IdEmpleado=@IdActorOrigen            
			END CATCH        
		END  
		--EmpleadoDisponibilidad----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE EmpleadoDisponibilidad SET IdEmpleado=@IdActorDestino WHERE IdEmpleado = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoDisponibilidad',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpleadoDisponibilidad),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpleadoDisponibilidad),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoDisponibilidad WITH(NOLOCK) where IdEmpleado=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'EmpleadoDisponibilidad',        
				CONVERT(VARCHAR,@IdActorOrigen)+','+CONVERT(VARCHAR,IdEmpleadoDisponibilidad),        
				CONVERT(VARCHAR,@IdActorDestino)+','+CONVERT(VARCHAR,IdEmpleadoDisponibilidad),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from EmpleadoDisponibilidad WITH(NOLOCK) where IdEmpleado=@IdActorOrigen            
			END CATCH        
		END         
        
		--ContactoAtencion IdCounter----------------------------------------------------------------------------------------------------------------------            
		BEGIN         
			UPDATE ContactoAtencion Set IdCounter = @IdCounter WHERE IdContacto = @IdActorDestino          
		END         
		--Contacto IdCounter----------------------------------------------------------------------------------------------------------------------            
		BEGIN        
			IF NOT EXISTS (SELECT * FROM Contacto WITH(NOLOCK) WHERE IdContacto = @IdActorDestino)         
			UPDATE Contacto Set IdCounter = @IdCounter WHERE IdContacto = @IdActorDestino          
		END                   
		--F--HorarioSesion----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE HorarioSesion SET IdActorProgramado=@IdActorDestino WHERE IdActorProgramado = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'HorarioSesion',        
		--  CONVERT(VARCHAR,IdSeccion)+','+CONVERT(VARCHAR,IdHorario)+CONVERT(VARCHAR,IdSesion),        
		--  CONVERT(VARCHAR,IdSeccion)+','+CONVERT(VARCHAR,IdHorario)+CONVERT(VARCHAR,IdSesion),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from HorarioSesion where IdActorProgramado=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'HorarioSesion',        
		--  CONVERT(VARCHAR,IdSeccion)+','+CONVERT(VARCHAR,IdHorario)+CONVERT(VARCHAR,IdSesion),        
		--  CONVERT(VARCHAR,IdSeccion)+','+CONVERT(VARCHAR,IdHorario)+CONVERT(VARCHAR,IdSesion),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from HorarioSesion where IdActorProgramado=@IdActorOrigen        
		-- END CATCH        
		--END         
          
		--F--HorarioSesion----------------------------------------------------------------------------------------------------------------------        
		--BEGIN        
		-- BEGIN TRY        
		--  UPDATE HorarioSesion SET IdActorReemplazo=@IdActorDestino WHERE IdActorReemplazo = @IdActorOrigen         
        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'HorarioSesion',        
		--  CONVERT(VARCHAR,IdSeccion)+','+CONVERT(VARCHAR,IdHorario)+CONVERT(VARCHAR,IdSesion),        
		--  CONVERT(VARCHAR,IdSeccion)+','+CONVERT(VARCHAR,IdHorario)+CONVERT(VARCHAR,IdSesion),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from HorarioSesion where IdActorReemplazo=@IdActorOrigen        
		-- END TRY        
		-- BEGIN CATCH         
		--  SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
		--  INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
		--  SELECT @IdProceso,'HorarioSesion',        
		--  CONVERT(VARCHAR,IdSeccion)+','+CONVERT(VARCHAR,IdHorario)+CONVERT(VARCHAR,IdSesion),        
		--  CONVERT(VARCHAR,IdSeccion)+','+CONVERT(VARCHAR,IdHorario)+CONVERT(VARCHAR,IdSesion),        
		--  @IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from HorarioSesion where IdActorReemplazo=@IdActorOrigen        
		-- END CATCH        
		--END         
          
		--AlumnoSeguimiento----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE AlumnoSeguimiento SET IdAlumno=@IdActorDestino WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoSeguimiento',        
				CONVERT(VARCHAR,IdAlumnoSeguimiento),        
				CONVERT(VARCHAR,IdAlumnoSeguimiento),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoSeguimiento WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoSeguimiento',        
				CONVERT(VARCHAR,IdAlumnoSeguimiento),        
				CONVERT(VARCHAR,IdAlumnoSeguimiento),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoSeguimiento WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END CATCH        
		END         
          
		--AlumnoCursoNota----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE AlumnoCursoNota SET IdAlumno=@IdActorDestino WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoCursoNota',        
				CONVERT(VARCHAR,IdSeccion)+', '+CONVERT(VARCHAR,IdCalificacion)+', '+CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,IdSeccion)+', '+CONVERT(VARCHAR,IdCalificacion)+', '+CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoCursoNota WITH(NOLOCK) where  IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoCursoNota',        
				CONVERT(VARCHAR,IdSeccion)+', '+CONVERT(VARCHAR,IdCalificacion)+', '+CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,IdSeccion)+', '+CONVERT(VARCHAR,IdCalificacion)+', '+CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoCursoNota WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END CATCH        
		END         
          
		--AlumnoCursoAsistencia----------------------------------------------------------------------------------------------------------------------        
		BEGIN        
			BEGIN TRY        
				UPDATE AlumnoCursoAsistencia SET IdAlumno=@IdActorDestino WHERE IdAlumno = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoCursoAsistencia',   
				CONVERT(VARCHAR,IdSeccion)+', '+CONVERT(VARCHAR,IdHorario)+', '+CONVERT(VARCHAR,IdSesion)+', '+CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,IdSeccion)+', '+CONVERT(VARCHAR,IdHorario)+', '+CONVERT(VARCHAR,IdSesion)+', '+CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoCursoAsistencia WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'AlumnoCursoAsistencia',        
				CONVERT(VARCHAR,IdSeccion)+', '+CONVERT(VARCHAR,IdHorario)+', '+CONVERT(VARCHAR,IdSesion)+', '+CONVERT(VARCHAR,@IdActorOrigen),        
				CONVERT(VARCHAR,IdSeccion)+', '+CONVERT(VARCHAR,IdHorario)+', '+CONVERT(VARCHAR,IdSesion)+', '+CONVERT(VARCHAR,@IdActorDestino),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from AlumnoCursoAsistencia WITH(NOLOCK) where IdAlumno=@IdActorOrigen        
			END CATCH        
		END         
    
		--PostulanteFacilitador----------------------------------------------------------------------------------------------------------------------    
		BEGIN        
			BEGIN TRY        
				UPDATE PostulanteFacilitador SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'PostulanteFacilitador',        
				IdPostulanteFacilitador,IdPostulanteFacilitador,        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitador WITH(NOLOCK) where idactor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'PostulanteFacilitador',        
				IdPostulanteFacilitador,IdPostulanteFacilitador,              
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from PostulanteFacilitador WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END         
    
		--ContactoAgenda----------------------------------------------------------------------------------------------------------------------      
		BEGIN        
			BEGIN TRY        
				UPDATE ContactoAgenda SET IdContacto=@IdActorDestino WHERE IdContacto = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ContactoAgenda',        
				CONVERT(VARCHAR,IdAgenda)+','+CONVERT(VARCHAR,IdCounter),        
				CONVERT(VARCHAR,IdAgenda)+','+CONVERT(VARCHAR,IdCounter),       
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ContactoAgenda WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ContactoAgenda',        
				CoNVERT(VARCHAR,IdAgenda)+','+CONVERT(VARCHAR,IdCounter),        
				CONVERT(VARCHAR,IdAgenda)+','+CONVERT(VARCHAR,IdCounter),        
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ContactoAgenda WITH(NOLOCK) where IdContacto=@IdActorOrigen        
			END CATCH        
		END               
     
		--FichaProgramacionDetalle-----------------------------------------------------------------------------------------------------------      
		BEGIN        
			BEGIN TRY        
				UPDATE FichaProgramacionDetalle SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'FichaProgramacionDetalle',        
				CONVERT(VARCHAR,IdProgramacion)+','+CONVERT(VARCHAR,IdProgramacionDetalle),        
				CONVERT(VARCHAR,IdProgramacion)+','+CONVERT(VARCHAR,IdProgramacionDetalle),   
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FichaProgramacionDetalle WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'FichaProgramacionDetalle',        
				CONVERT(VARCHAR,IdProgramacion)+','+CONVERT(VARCHAR,IdProgramacionDetalle),        
				CONVERT(VARCHAR,IdProgramacion)+','+CONVERT(VARCHAR,IdProgramacionDetalle),       
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FichaProgramacionDetalle WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END   
    
		--FichaProgramacionDetalle-----------------------------------------------------------------------------------------------------------      
		BEGIN        
			BEGIN TRY        
				UPDATE FichaProgramacionDetalle SET IdDocente=@IdActorDestino WHERE IdDocente = @IdActorOrigen         
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'FichaProgramacionDetalle',        
				CONVERT(VARCHAR,IdProgramacion)+','+CONVERT(VARCHAR,IdProgramacionDetalle),        
				CONVERT(VARCHAR,IdProgramacion)+','+CONVERT(VARCHAR,IdProgramacionDetalle),   
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FichaProgramacionDetalle WITH(NOLOCK) where IdDocente=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'FichaProgramacionDetalle',        
				CONVERT(VARCHAR,IdProgramacion)+','+CONVERT(VARCHAR,IdProgramacionDetalle),        
				CONVERT(VARCHAR,IdProgramacion)+','+CONVERT(VARCHAR,IdProgramacionDetalle),       
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from FichaProgramacionDetalle WITH(NOLOCK) where IdDocente=@IdActorOrigen        
			END CATCH        
		END        
        
		--ficharespuestaactor-----------------------------------------------------------------------------------------------------------      
		BEGIN        
			BEGIN TRY        
				UPDATE ficharespuestaactor SET IdActor=@IdActorDestino WHERE IdActor = @IdActorOrigen         
        
					--select * from ficharespuestaactor where IdActor = 702396  
        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ficharespuestaactor',        
				CONVERT(VARCHAR,IdRespuesta),        
				CONVERT(VARCHAR,IdRespuesta),      
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ficharespuestaactor WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END TRY        
			BEGIN CATCH         
				SET @Error=1 SET @Mensaje=(SELECT ERROR_MESSAGE())        
				INSERT INTO SY_ProcesoUnificacion_Log (IdProceso,Tabla,Pk,Pk_Destino,PersonaAntigua,PersonaNueva,Resultado,DescripcionError,Usuario,FechaProceso)        
				SELECT @IdProceso,'ficharespuestaactor',        
				CONVERT(VARCHAR,IdRespuesta),        
				CONVERT(VARCHAR,IdRespuesta),          
				@IdActorOrigen,@IdActorDestino,@@ERROR,(SELECT ERROR_MESSAGE()),@Login,GETDATE() from ficharespuestaactor WITH(NOLOCK) where IdActor=@IdActorOrigen        
			END CATCH        
		END   
        
	END        
         
	--DELETES        
	BEGIN 
		DELETE ActorParticipacion WHERE IdActor = @IdActorOrigen         
		DELETE ActorHabilidad WHERE IdActor = @IdActorOrigen         
		DELETE ActorEstudioOtro WHERE IdActor = @IdActorOrigen         
		DELETE ActorDistincion WHERE IdActor = @IdActorOrigen         
		DELETE ActorMedica WHERE IdActor = @IdActorOrigen         
		DELETE ActorFamilia WHERE IdActor = @IdActorOrigen         
		DELETE ActorExperienciaLaboral WHERE IdActor = @IdActorOrigen         
		--DELETE EmpleadoCurso WHERE IdEmpleado = @IdActorOrigen         
		--DELETE EmpleadoAreaAcademica WHERE IdEmpleado = @IdActorOrigen         
		DELETE CapacitacionAsistencia WHERE IdFacilitador = @IdActorOrigen         
		DELETE AlumnoCursoRecuperacion WHERE IdAlumno = @IdActorOrigen         
		--DELETE EmpleadoEmpresa WHERE IdEmpleado = @IdActorOrigen         
		--DELETE ConvenioEntidad WHERE IdEntidad = @IdActorOrigen         
		--DELETE EntidadRepresentante WHERE IdEntidad = @IdActorOrigen         
		--DELETE EntidadContacto WHERE IdEntidad = @IdActorOrigen         
		DELETE FacilitadorTarifario WHERE IdFacilitador = @IdActorOrigen         
		DELETE FacilitadorNegocio WHERE IdFacilitador = @IdActorOrigen         
		DELETE FacilitadorEstructura WHERE IdFacilitador = @IdActorOrigen         
		DELETE CapacitacionFacilitador WHERE IdFacilitador = @IdActorOrigen         
		--delete from ContactoInteresado where IdContacto = @IdActorOrigen        
		--DELETE ContactoInteresado WHERE IdContacto = @IdActorOrigen        
		--delete from ContactoAtencion where IdMatricula in (select IdMatricula from matricula where IdActor = @IdActorOrigen)        
		--DELETE ContactoAtencion WHERE IdContacto = @IdActorOrigen        
		--DELETE InteresadoPreferencia WHERE IdInteresado = @IdActorOrigen         
		DELETE ActorFamiliaEnfermedad WHERE IdActor = @IdActorOrigen         
		DELETE Socio WHERE IdSocio = @IdActorOrigen         
		DELETE WorkFlowPersona WHERE IdWfPersona = @IdActorOrigen       
		DELETE WorkFlowEntidad WHERE IdWfEntidad = @IdActorOrigen        
		DELETE ProveedorTemporal WHERE IdProveedor = @IdActorOrigen         
		DELETE Proveedor WHERE IdProveedor = @IdActorOrigen         
		DELETE Cliente WHERE IdCliente = @IdActorOrigen         
		DELETE Donador WHERE IdDonador = @IdActorOrigen         
		DELETE Empleado WHERE IdEmpleado = @IdActorOrigen         
		DELETE Entidad WHERE IdEntidad = @IdActorOrigen         
		DELETE IntegranteComite WHERE IdIntegrante = @IdActorOrigen
		--Inicio @3
		--DECLARE @IdInt INT @8
		--Select @IdInt = (Select IdInteresado from Interesado where IdActor = @IdActorOrigen) @8
		--DELETE InteresadoTelefono where IdInteresado = @IdInt @8
		--DELETE InteresadoResultadoAtencion where IdInteresado = @IdInt @8
		--DELETE InteresadoProductoContacto where IdInteresado = @IdInt @8
		--DELETE InteresadoEmail where IdInteresado = @IdInt @8
		--DELETE InteresadoDireccion where IdInteresado = @IdInt @8
		--DELETE InteresadoContactoAtencion where IdInteresado  = @IdInt @8
		--DELETE InteresadoAgenda Where IdInteresado = @IdInt --@4  @8
		--Fin @3      
		--DELETE Interesado WHERE IdActor = @IdActorOrigen    @8      
		DELETE Lector WHERE IdLector = @IdActorOrigen         
		DELETE ContactoFrecuencia WHERE IdContacto = @IdActorOrigen         
		DELETE ContactoCurso WHERE IdContacto = @IdActorOrigen         
		DELETE CorreoDirectoContacto WHERE IdContacto = @IdActorOrigen         
		DELETE ContactoReferido WHERE IdContacto = @IdActorOrigen         
		DELETE ConstanciaPagos WHERE IdActor = @IdActorOrigen         
		---        
		DELETE ActorTrabajo WHERE IdActor = @IdActorOrigen         
		DELETE ActorEmail WHERE IdActor = @IdActorOrigen        
		DELETE ActorTelefono WHERE IdActor = @IdActorOrigen        
		DELETE ActorDireccion WHERE IdActor = @IdActorOrigen        
		--DELETE CargoAlumno WHERE IdAlumno = @IdActorOrigen        
		DELETE p FROM Permiso p         
		INNER JOIN usuario u ON u.IdUsuario = p.IdUsuario         
		INNER JOIN Actor a  ON a.IdActor = u.IdActor         
		AND a.IdActor = @IdActorOrigen        
		DELETE Justificacion WHERE IdAlumno = @IdActorOrigen          
		--DELETE ContactoAgenda WHERE IdContacto = @IdActorOrigen          
		--DELETE q FROM AlumnoSeguimientoInasistenciaDetalle q        
		-- INNER JOIN AlumnoSeguimientoInasistencia a ON a.IdAlumnoSeguimiento = q.IdAlumnoSeguimiento and a.IdSemana = q.idsemana         
		-- INNER JOIN AlumnoSeguimiento b ON B.IdAlumnoSeguimiento = a.IdAlumnoSeguimiento AND B.IdAlumno  = @IdActorOrigen        
		--DELETE A FROM AlumnoSeguimientoInasistencia A        
		-- INNER JOIN AlumnoSeguimiento b ON B.IdAlumnoSeguimiento = a.IdAlumnoSeguimiento AND B.IdAlumno  = @IdActorOrigen        
		--DELETE A FROM AlumnoSeguimientoDetalle A        
		-- INNER JOIN AlumnoSeguimiento b ON B.IdAlumnoSeguimiento = a.IdAlumnoSeguimiento AND B.IdAlumno  = @IdActorOrigen --        
		--DELETE AlumnoSeguimiento WHERE IdAlumno = @IdActorOrigen        
        DECLARE @IdAsignacionFichaMatricula INT--@9
		SELECT @IdAsignacionFichaMatricula=IdAsignacionFichaMatricula FROM AsignacionFichaMatricula WHERE IdMatricula=@IdMatriculaOld--@9

        DELETE AsignacionFichaMatricula WHERE IdMatricula=@IdMatriculaOld--@9

		DELETE LogAsignacionFichaMatriculaGenerarMail WHERE IdAsignacionFichaMatricula=@IdAsignacionFichaMatricula--@9

		DELETE EVA FROM EVA_InformacionActor EVA--@9
		INNER JOIN Usuario U on EVA.IdUsuario = U.IdUsuario WHERE U.IdActor = @IdActorOrigen  
        DELETE EVA_InformacionActorDetalle WHERE IdMatricula=@IdMatriculaOld--@7
		DELETE PromocionGrupoCierre WHERE IdActor = @IdActorOrigen        
		DELETE MatriculaRetiro WHERE IdActor = @IdActorOrigen        
		DELETE ActorFacturacion WHERE IdActor = @IdActorOrigen        
		DELETE MatriculaPagante WHERE IdActor = @IdActorOrigen        
		DELETE ContactoTurno WHERE IdContacto = @IdActorOrigen        
		DELETE EnlaceReferido WHERE IdAlumno = @IdActorOrigen --@5
		DELETE AlumnoCurso WHERE IdAlumno = @IdActorOrigen        
            
        
		DELETE SustitutorioAlumno WHERE IdAlumno = @IdActorOrigen   
		DELETE FROM FER_Agenda WHERE IdAlumno = @IdActorOrigen --@8
		DELETE Alumno WHERE IdAlumno = @IdActorOrigen         
		DELETE UF FROM UsuarioFacultad UF        
		INNER JOIN Usuario U on UF.IdUsuario = U.IdUsuario WHERE U.IdActor = @IdActorOrigen         
		DELETE US FROM UsuarioSede US         
		INNER JOIN Usuario U on US.IdUsuario = U.IdUsuario WHERE U.IdActor = @IdActorOrigen        
		DELETE UE FROM UsuarioEmpresa UE        
		INNER JOIN Usuario U on UE.IdUsuario = U.IdUsuario WHERE U.IdActor = @IdActorOrigen        
		DELETE FacilitadorCurso where IdFacilitador = @IdActorOrigen        
		DELETE Facilitador where IdFacilitador = @IdActorOrigen           
		DELETE Usuario WHERE IdActor = @IdActorOrigen           
		DELETE RegistroProductoRequisito WHERE IdActor = @IdActorOrigen         
		DELETE AlumnoCurriculaConvalida WHERE IdAlumno = @IdActorOrigen          
		DELETE AlumnoCurriculaCurso WHERE IdAlumno = @IdActorOrigen        
		DELETE AlumnoCurriculaModulo WHERE IdAlumno = @IdActorOrigen        
		--DELETE Convalidacion WHERE IdAlumno = @IdActorOrigen
		DELETE PlanillaComercialMatricula where IdMatricula = @IdMatriculaOld --@5
		DELETE AlumnoCurricula WHERE IdAlumno = @IdActorOrigen        
		DELETE D FROM DetalleCompromisoPago D         
		INNER JOIN CompromisoPago C ON C.IdCompromiso = D.IdCompromiso AND C.IdActor = @IdActorOrigen         
		DELETE CompromisoPago WHERE IdActor = @IdActorOrigen         
		DELETE Matricula WHERE IdActor = @IdActorOrigen        
		DELETE Registro WHERE IdActor = @IdActorOrigen        
		DELETE ActorRol WHERE IdActor = @IdActorOrigen         
		DELETE ActorFoto WHERE IdActor = @IdActorOrigen           
	           
		--ActorEliminado        
		BEGIN        
			--IF NOT EXISTS (SELECT * FROM ActorEliminado WHERE IdActor = @IdActorOrigen)        
			INSERT INTO ActorEliminado (IdActor,Paterno,Materno,Nombres,NombreCorto,NombreCompleto,NombreSoloBusqueda,IdTenor,Genero,IdDocumentoTipo,        
			NumeroIdentidad,IdEstadoCivil,IdNacionalidad,FechaMatrimonio,FechaNacimiento,IdPaisNacimiento,IdUbigeoNacimiento,CiudadNacimiento,Ruc,        
			IdSituacionDomicilio,DireccionCompleta,EsHomonimo,Trabaja,Tipo,UsuarioCreacion,FechaCreacion,UsuarioModificacion,FechaModificacion,        
			IdPaisProcedencia,IdDptoProcedencia,IdMedioDifusion,IdActorNuevo)        
			SELECT IdActor,Paterno,Materno,Nombres,NombreCorto,NombreCompleto,NombreSoloBusqueda,IdTenor,Genero,IdDocumentoTipo,NumeroIdentidad,        
			IdEstadoCivil,IdNacionalidad,FechaMatrimonio,FechaNacimiento,IdPaisNacimiento,IdUbigeoNacimiento,CiudadNacimiento,Ruc,IdSituacionDomicilio,        
			DireccionCompleta,EsHomonimo,Trabaja,Tipo,UsuarioCreacion,FechaCreacion,UsuarioModificacion,FechaModificacion,IdPaisProcedencia,4,        
			IdMedioDifusion,@IdActorDestino        
			FROM Actor WITH(NOLOCK)        
			WHERE IdActor = @IdActorOrigen         
			DELETE FROM UsuarioPerfilZoom where IdActor = @IdActorOrigen --@5
			DELETE FROM PromocionBeca where IdActor = @IdActorOrigen         --@3        
			DELETE FROM Actor WHERE IdActor = @IdActorOrigen         
		END        
		--ContactoEliminado        
		BEGIN        
			--IF NOT EXISTS (SELECT * FROM ContactoEliminado WHERE IdContacto = @IdActorOrigen)        
			INSERT INTO ContactoEliminado (IdContacto,IdEmpresa,IdSede,CodigoAnterior,IdCounter,EsIndependiente,EsNegocioPropio,EsEmpresaFamiliar,EsProfesionalIndependiente,Activo,IdImportacion)            
			SELECT IdContacto,IdEmpresa,IdSede,CodigoAnterior,IdCounter,EsIndependiente,EsNegocioPropio,EsEmpresaFamiliar,EsProfesionalIndependiente,Activo,IdImportacion           
			FROM  Contacto WITH(NOLOCK)        
			WHERE IdContacto = @IdActorOrigen         
           
			DELETE FROM Contacto WHERE IdContacto = @IdActorOrigen         
		END        
          
		/**********************************************************************************************************/        
		-- SE HABILITAN TODOS LOS TRIGGERS DE ACTOR        
		/**********************************************************************************************************/        
         
		ALTER TABLE Actor        
		ENABLE TRIGGER personamast_Update ;        
          
		ALTER TABLE Actor        
		ENABLE TRIGGER Tr_Actor_del;        
          
		ALTER TABLE Actor        
		ENABLE TRIGGER Tr_Actor_ins ;        
          
		ALTER TABLE Actor        
		ENABLE TRIGGER Tr_Actor_upd;    
          
		ALTER TABLE ActorDireccion        
		ENABLE TRIGGER Tr_ActorDireccion_Del;        
          
		ALTER TABLE ActorDireccion        
		ENABLE TRIGGER Tr_ActorDireccion_Upd;        
     
		ALTER TABLE ActorEmail        
		ENABLE TRIGGER Tr_ActorEmail_Upd;        
          
		ALTER TABLE ActorEmail        
		ENABLE TRIGGER Tr_ActorEmail_Del;        
  
		ALTER TABLE ActorTelefono        
		ENABLE TRIGGER Tr_ActorTelefono_Upd;        
          
		ALTER TABLE ActorTelefono        
		ENABLE TRIGGER Tr_ActorTelefono_Del;        
          
		ALTER TABLE ActorDireccion        
		ENABLE TRIGGER TR_ActorDireccion_INS        
        
		ALTER TABLE ActorEmail        
		ENABLE TRIGGER TR_ActorEmail_INS        
        
		ALTER TABLE ActorTelefono        
		ENABLE TRIGGER TR_ActorTelefono_INS        
        
	END        
        
         
END        