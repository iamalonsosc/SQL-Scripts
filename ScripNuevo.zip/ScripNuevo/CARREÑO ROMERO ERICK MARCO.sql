--SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
--INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
--WHERE AC.IdAlumno=1255520 
----AND AC.IdCurso=9934 
----AND AC.IdCursoOriginal=9934 
----AND AC.IdMatricula=710047 
----AND AC.EsMatricula=1
--order by ac.idregistro,ac.IdAlumnoCurso desc


--SELECT SE.*FROM Seccion SE
--INNER JOIN Promocion PRO ON SE.IdPromocion=PRO.IdPromocion
--WHERE SE.IdPeriodoAnual=2025 
--AND SE.IdCurso=10047 
--AND SE.IdCurricula=5800 
--AND PRO.IdSede=40
--AND PRO.PromocionCodigo LIKE '%2025-II%' 


--CONSTITUCI�N DE EMPRESAS Y NUEVOS NEGOCIOS
INSERT INTO AlumnoCurso VALUES (1255520,7,30,5800,10047,710047,99543,1,646588,null,null,'19.00','19.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL
,PromedioFinal='19.00'
,PromedioReal= '19.00'
,IdAlumnoCurso=30
,TipoCondicion='RE'
--select*from AlumnoCurriculaCurso 
where IdAlumno=1255520 and IdCurso=10047 AND IdRegistro=7