-----------------------------------------------------------------------------                                 
--Creado por      : Luis Perales (11/09/2012)                                  
--Funcionalidad   : Proceso para generar las secciones de las actas                
--Utilizado por   : Generacion de nominas               
-------------------------------------------------------------------------------                                    
/*-----------------------------------------------------------------------------                              
Nro  FECHA     USUARIO     DESCRIPCION                              
-----------------------------------------------------------------------------      
@1 2017.11.02	jmota		se filtra para consultar solo carreras y no incluir TDP (update por error con TDP)               
@2 22.03.2018	jnavia		Se agregan los cursos equivalentes con los campos IdCurriculaOriginal y IdCursoOriginal     
@3 2018.05.10	jmota		asignacion se seccion tipo CC que superan los 80 alumnos matriculados    
@4 2019.07.31	Nicolas Huanca (Sigcomt) permite agregar mas secciones A..Z.A1....Z1.A2...Z2.A3..             
@5 2019.07.31	Nicolas Huanca (Sigcomt) Procesamiento de nominas por producto    
@6 2019.10.30	jravichagua		Se crea y agrega insert tabla Bdadmin..AlumnoCursoNomina_Log    
@7 31.10.2019	EHuillca		Se coloca isnull en caso alumnocurso tenga data en idcurso o idcurricula original.   
@8 31.10.2019	Hmora			Cambio temporal para las nominas de Escuela 8 Semestre  
@9 04.11.2019	EHuillca		Se modifica casteo a decimal de variable   
@10 5.11.2019	Hmora			Se cambia logica de matriculas de IES a EEST nuevo proceso 
@11 11.11.2019	Hmora			se modifica campos para equivalencias en matricula con la condicion RE , RP
@12 22.04.2021	RSamame			se modifica para que tome la sede de la matricula, para el cast del decimal  
@13 15.12.2021	RSamame			se agrega Logica en regulares que los grupos pasan los 80 alumnos
@14 13.01.2022	RSamame			Se mejora logica de regulares que exceden los 80 alumnos
@15 11.07.2024	fmartinez		Se agrega el procesado de las nominas JSON
@16 13.10.2025	illosad			Se agrega separacion por malla curricular
@17 15.10.2025	illosad			Se modifica codigo de la seccionNomina de acuerdo a la curricula
@18 16.12.2025	Alsanchez		Se agrega nueva tabla para excluir a los alumnos de sus nominas
*/                     
--ALTER PROCEDURE cPromocionGrupo_Upd_SeccionNomina2
DECLARE
@pIdEmpresa int,    
@pIdSede int,    
@pIdUnidadNegocio int,    
@pIdUnidadAcademica int,    
@pIdPeriodo int,    
@pIdProducto int,    
@pUsuarioCreacion int,    
@pError int          
--AS       
select @pIdEmpresa=1,@pIdSede=32,@pIdUnidadNegocio=1,@pIdUnidadAcademica=60,@pIdPeriodo=4058,@pIdProducto=11366,@pUsuarioCreacion=446639

--select @pIdEmpresa=1,@pIdSede=32,@pIdUnidadNegocio=1,@pIdUnidadAcademica=60,@pIdPeriodo=3893,@pIdProducto=11366,@pUsuarioCreacion=446639
SET NOCOUNT ON                
BEGIN      
 --declaracion de variables    
 DECLARE @ProductoNombre varchar(1000),    
		 @Idmodulo Int,    
		 @IdPromocion Int,    
		 @IdGrupo Int,    
		 @Seccion varchar(100),    
		 @Cantidad Int,    
		 --    
		 @Numero varchar(10),    
		 @SeccionAnterior varchar(100),    
		 @IdPromocionAnterior int,    
		 @InicializaLetra bit,    
		 @i int,    
		 @max int,    
		 @max2 int,    
		 @EsCierre bit,    
		 ---    
		 @IdSede INT,    
		 @IdProducto INT,    
		 @Turno VARCHAR(500),    
		 @Periodo VARCHAR(500),    
		 @prueba int,    
		 @EsNomina int,
		 @Idcurricula int    
    
DECLARE @Resultado TABLE(Id Int Identity,    
        IdSede INT,    
        IdMatricula INT,    
        IdProducto INT,    
        NombreCompleto VARCHAR(500),    
        Idmodulo Int,    
        Turno VARCHAR(500),    
        IdPeriodo Int,    
        IdCurricula Int,    
        Seccion VARCHAR(500),    
        IdActor INT,    
        IdCurso INT,    
        IdPromocion int,    
        IdGrupo int)    

DECLARE @Resultado2 TABLE(Id Int Identity,    
        IdSede INT,    
        IdProducto INT,    
        Idmodulo Int,    
        Periodo varchar(500),    
        Turno VARCHAR(500),
		idcurricula int,    
        Cantidad INT)  

--@10  
DECLARE @Resultado3 TABLE(Id Int Identity,    
        IdSede INT,    
        IdMatricula INT,    
        IdProducto INT,    
        NombreCompleto VARCHAR(500),    
        Idmodulo Int,    
        Turno VARCHAR(500),    
        IdPeriodo Int,    
        IdCurricula Int,    
        Seccion VARCHAR(500),    
	    IdActor INT,    
        IdCurso INT,    
        IdPromocion int,    
        IdGrupo int)   
     
DECLARE @Resultado4 TABLE(Id Int Identity,    
        IdSede INT,    
        IdProducto INT,    
        Idmodulo Int,  
	    IdPromocion Int,  
        IdGrupo INt,    
        Periodo varchar(500),    
        Turno VARCHAR(500),    
        idcurricula int,    --@16
        Cantidad INT)    
--@10    
    
DECLARE @Resultadox TABLE(Id Int Identity,    
        ProductoNombre varchar(1000),    
        Idmodulo Int,    
        IdPromocion Int,    
        IdGrupo Int,    
        Turno varchar(100),  
		idcurricula int,  
        Seccion varchar(100),    
        Cantidad Int)    

 --verificamos si esta cerrado el periodo    
 select @EsCierre = isnull(EsCierre,0)    
 from Periodo with(nolock)    
 where IdPeriodo = @pIdPeriodo    

 IF @EsCierre = 1    
 BEGIN    
   select @pError = 0     
   --return @pError    
 END   

 --verificamos si ya se ha ejecutado el proceso de nomina     
 SELECT @EsNomina = COUNT(1)     
 FROM Promocion P with(nolock)    
 inner join  PromocionGrupo pg with(nolock) on p.IdPromocion = pg.IdPromocion    
 WHERE IdPeriodo = @pIdPeriodo    
	AND (IdProducto = @pIdProducto OR  @pIdProducto = 0) --@5    
	and pg.EsNomina = 1    
    
 IF @EsNomina > 0    
 BEGIN    
   select @pError = 2     
   --return @pError    
 END
    
 INSERT INTO @Resultadox    
 SELECT pr.productonombre,    
		p.idmodulo,    
		p.IdPromocion,    
		pg.IdGrupo,    
		mtr.Disponible5,  
		m.idcurricula,  
		convert(varchar,c.Codigo)+'.'+pg.grupocodigo+'-'+dbo.gEnteroARomano(p.idmodulo)+'-' Seccion,    --@17
		--convert(varchar,pr.numerointerno)+'.'+pg.grupocodigo+'-'+dbo.gEnteroARomano(p.idmodulo)+'-' Seccion,    
		COUNT(distinct m.IdMatricula) CantidadMatriculados    
 FROM Matricula m  with(nolock)    
 inner join Promocion p  with(nolock) on m.IdPromocion = p.IdPromocion    
 inner join PromocionGrupo pg  with(nolock) on m.IdPromocion = pg.IdPromocion  and m.IdGrupo  = pg.IdGrupo    
 inner join Producto pr  with(nolock) on p.IdProducto = pr.IdProducto    
 INNER JOIN MaestroTablaRegistro MTR_PRO WITH(NOLOCK) ON pr.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro   -- @1     
 INNER JOIN Turno T with(nolock) ON PG.IdTurno = T.IdTurno    
 INNER JOIN MaestroTablaRegistro MTR with(nolock) ON T.IdTipoTurno = MTR.IdMaestroRegistro    
 inner join AlumnoCurso AC with(nolock) on m.idmatricula = ac.idmatricula
 inner join curricula c with(nolock) on m.IdCurricula = c.IdCurricula	--@17
  WHERE m.EsMatricula =1    
	   and m.Estado<>'X'    
	   and m.TipoCondicion <>'CC'    
	   and ac.esmatricula = 1    
	   and ac.tipocondicion <> 'CC'    
	   and p.IdEmpresa = @pIdEmpresa    
	   and p.IdSede = @pIdSede    
	   and p.IdUnidadNegocio = @pIdUnidadNegocio    
	   and p.IdUnidadAcademica = @pIdUnidadAcademica    
	   and p.IdPeriodo = @pIdPeriodo --1737    
	   --and m.IdMatricula = 1363529    
	   and (p.IdProducto = @pIdProducto or @pIdProducto = 0)    
	   AND (( MTR_PRO.Disponible1='C' AND  MTR_PRO.Disponible2='CAR' ) OR MTR_PRO.Disponible1='P' ) --@1    
	   AND P.IdUnidadNegocio IN (1) --@1        
 group by  pr.productonombre,p.idmodulo,p.IdPromocion,pg.IdGrupo,mtr.Disponible5,m.idcurricula ,   
 convert(varchar,c.Codigo)+'.'+pg.grupocodigo+'-'+dbo.gEnteroARomano(p.idmodulo)+'-'    --@17
 --convert(varchar,pr.numerointerno)+'.'+pg.grupocodigo+'-'+dbo.gEnteroARomano(p.idmodulo)+'-'    
 order by 1,p.IdModulo, idgrupo     
    
	select*from @Resultadox

 select @IdPromocionAnterior = -1     
    
 DELETE AlumnoCursoNomina    
 WHERE IdEmpresa = @pIdEmpresa    
 and IdSede = @pIdSede    
 and IdPeriodo = @pIdPeriodo    
 and (IdProducto = @pIdProducto or @pIdProducto = 0) 
 
 ---- eliminar de la tabla nomina json con los mismos campos del delete de AlumnoCursoNomina 
 --Inicio @15
 DELETE AlumnoCursoNominaJson
 WHERE IdEmpresa = @pIdEmpresa    
 and IdSede = @pIdSede    
 and IdPeriodo = @pIdPeriodo    
 and (IdProducto = @pIdProducto or @pIdProducto = 0) 
 --Fin @15    
    
 WHILE EXISTS (SELECT distinct 1 FROM @Resultadox)    
 BEGIN
   SELECT TOP 1    
   @ProductoNombre = ProductoNombre,    
   @Idmodulo = Idmodulo,    
   @IdPromocion = IdPromocion,    
   @IdGrupo = IdGrupo,    
   @Seccion =Seccion,    
   @Turno = Turno,  
   @Idcurricula = idcurricula,  --@16
   @Cantidad = Cantidad    
   FROM @Resultadox    
   ORDER BY Id    
    
   UPDATE PromocionGrupo --No se aumento ningun valor por que las promociones y el grupo es unico    
   SET EsNomina = 1, FechaModificacion = GETDATE(), UsuarioModificacion = @pUsuarioCreacion    
   WHERE IdPromocion = @IdPromocion AND IdGrupo = @IdGrupo           
    
   --verificamos si debemos hacer cambio de letra    
   IF @IdPromocionAnterior <> @IdPromocion      
   BEGIN     
     select @InicializaLetra = 1    
     select @IdPromocionAnterior = @IdPromocion    
   END    
   ELSE
   BEGIN    
     select  @InicializaLetra = 0    
   END
    
   IF @Cantidad>40 AND @Cantidad <= 80--@13     
   BEGIN    
      CREATE TABLE #Matriculados (Id Int Identity,    
             IdMatricula Int,    
             NombreCompleto varchar(1000))    
         
      INSERT INTO #Matriculados    
      SELECT DISTINCT m.IdMatricula, a.NombreCompleto    
      FROM Matricula m with(nolock)    
      inner join Actor a with(nolock) on m.IdActor = a.IdActor    
      inner join AlumnoCurso AC with(nolock) on m.idmatricula = ac.idmatricula    
      WHERE m.IdPromocion = @IdPromocion   
      and m.IdGrupo = @IdGrupo    
      and m.EsMatricula =1    
      and m.Estado<>'X'    
      and m.TipoCondicion <>'CC'    
      and ac.esmatricula = 1    
      and ac.tipocondicion <> 'CC'  
	  and m.IdCurricula = @Idcurricula  --@16
      order by 2 asc    
	  --select '#Matriculados',*from #Matriculados
      -- tenemos que separar las secciones en 2    
      select @max = @Cantidad/2     
      select @i = 1    
      select @max2 = @Cantidad    

      WHILE @i<=2    
      BEGIN    
        IF @InicializaLetra = 1 and @I = 1    
			--select @Numero = 1 --@4    
			SELECT @Numero = 'A'    
        ELSE --debemos sacar la ultima letra para la promocion y modulo que estamos procesando    
        BEGIN    
          --asignamos la letra    
          SELECT @SeccionAnterior = max(seccionnomina)    
          FROM AlumnoCursoNomina ACM  with(nolock)    
          inner join Promocion p  with(nolock) on ACM.IdPromocion = p.IdPromocion    
          WHERE p.IdPromocion = @IdPromocion    
                
          --sacamos la siguiente    
          --select @Numero = dbo.gRetornaLetraSiguiente(substring(@SeccionAnterior,len(@SeccionAnterior),1))--@4    
          SELECT @Numero = (dbo.gRetornaSeccion(@SeccionAnterior))--@4    
        END    
        --procesamiento de cada uno de los 2 grupos    
        IF @i=1    
        BEGIN              
          INSERT INTO AlumnoCursoNomina(    
					  IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,    
					  IdModulo,IdActor,IdCurso,IdPromocion,    
					  IdGrupo,IdPromocionCurso,IdGrupoCurso,    
					  IdCurricula,SeccionNomina,Turno,FechaCreacion,UsuarioCreacion)    
          SELECT m.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,    
				 m.IdMatricula,p.IdModulo,m.IdActor,isnull(ac.IdCursoOriginal,ac.Idcurso), --@11
				 m.idpromocion,m.idgrupo,ac.IdPromocion,ac.IdGrupo,    
				 isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
				 @Seccion+--dbo.gRetornaLetra(@Numero)--@4              
				 @Numero--@4    
				 ,@turno,getdate(),@pUsuarioCreacion    
          from Matricula m with(nolock)    
          inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
          inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula    
          inner join #Matriculados t on m.IdMatricula = t.IdMatricula    
          where t.Id >= 1     
				and t.Id <= @max     
				and ac.EsMatricula = 1    
				and ac.TipoCondicion = 'RE'    
		  
		  --inicio @6    
          INSERT INTO Bdadmin..AlumnoCursoNomina_Log (    
					  IdEmpresa,IdSede,IdPeriodo,IdProducto,    
					  IdMatricula,IdModulo,IdActor,IdCurso,IdPromocion,IdGrupo,    
					  IdPromocionCurso,IdGrupoCurso,IdCurricula,SeccionNomina,Turno,    
					  FechaCreacion,UsuarioCreacion)    
          SELECT m.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,m.IdMatricula,p.IdModulo,m.IdActor,isnull(ac.IdCursoOriginal,ac.Idcurso),    --@11
				 m.idpromocion,m.idgrupo,ac.IdPromocion,ac.IdGrupo,
				 isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
				 @Seccion+@Numero--@4    
				 ,@turno,getdate(),@pUsuarioCreacion    
          FROM Matricula m with(nolock)    
          inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
          inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula    
          inner join #Matriculados t on m.IdMatricula = t.IdMatricula    
          WHERE t.Id >= 1     
			    and t.Id <= @max     
			    and ac.EsMatricula = 1    
			    and ac.TipoCondicion = 'RE'     
          --fin @6    
        END     
        ELSE
		BEGIN    
		  INSERT INTO AlumnoCursoNomina(    
					  IdEmpresa,IdSede,IdPeriodo,IdProducto,    
					  IdMatricula,IdModulo,IdActor,IdCurso,IdPromocion,    
					  IdGrupo,IdPromocionCurso,IdGrupoCurso,IdCurricula,    
					  SeccionNomina,Turno,FechaCreacion,UsuarioCreacion)    
          SELECT m.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,    
				 m.IdMatricula,p.IdModulo,m.IdActor,isnull(ac.IdCursoOriginal,ac.Idcurso),    --@11
				 m.idpromocion,m.idgrupo,ac.IdPromocion,    
				 ac.IdGrupo,
				 isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
				 @Seccion+--dbo.gRetornaLetra(@Numero)--@4    
				 @Numero--@4    
				 ,@turno,getdate(),@pUsuarioCreacion    
          FROM Matricula m with(nolock)    
          inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
          inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula    
          inner join #Matriculados t on m.IdMatricula = t.IdMatricula    
          WHERE t.Id >= @max+1     
				and t.Id <= @max2    
				and ac.EsMatricula = 1    
				and ac.TipoCondicion = 'RE'    
    
          --inicio @6    
          INSERT INTO Bdadmin..AlumnoCursoNomina_Log (    
					  IdEmpresa,IdSede,IdPeriodo,IdProducto,    
					  IdMatricula,IdModulo,IdActor,IdCurso,IdPromocion,IdGrupo,    
					  IdPromocionCurso,IdGrupoCurso,IdCurricula,SeccionNomina,Turno,    
					  FechaCreacion,UsuarioCreacion)    
          SELECT m.IdEmpresa,m.IdSede,p.IdPeriodo,    
				 p.IdProducto,m.IdMatricula,p.IdModulo,m.IdActor,isnull(ac.IdCursoOriginal,ac.Idcurso), --@11   
				 m.idpromocion,m.idgrupo,ac.IdPromocion,ac.IdGrupo,
				 isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
				 @Seccion+--dbo.gRetornaLetra(@Numero)--@4              
				 @Numero--@4    
				 ,@turno,getdate(),@pUsuarioCreacion    
          FROM Matricula m with(nolock)    
          inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
          inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula    
          inner join #Matriculados t on m.IdMatricula = t.IdMatricula    
          WHERE t.Id >= 1     
				and t.Id <= @max     
				and ac.EsMatricula = 1    
				and ac.TipoCondicion = 'RE'     
          --fin @6    
		END		    
        SELECT @i = @i + 1    
      END    
      DROP TABLE #Matriculados    
   END    
   ELSE    
   IF @Cantidad>80  --@13
   BEGIN
		--DECLARE  @Matriculados AS TABLE
		CREATE TABLE #MatriculadosMAX (Id Int Identity,    
			IdMatricula Int,    
			NombreCompleto varchar(1000),
			grupo INT)   
            
		INSERT INTO #MatriculadosMAX  (IdMatricula,NombreCompleto)  
		SELECT DISTINCT m.IdMatricula, a.NombreCompleto    
		FROM Matricula m with(nolock)    
		inner join Actor a with(nolock) on m.IdActor = a.IdActor    
		inner join AlumnoCurso AC with(nolock) on m.idmatricula = ac.idmatricula    
		WHERE m.IdPromocion = @IdPromocion   
			  and m.IdGrupo = @IdGrupo    
			  and m.EsMatricula =1    
			  and m.Estado<>'X'    
			  and m.TipoCondicion <>'CC'    
			  and ac.esmatricula = 1    
			  and ac.tipocondicion <> 'CC' 
			  and m.IdCurricula = @Idcurricula   
		order by 2 asc
		--select ' #MatriculadosMAX',*from #MatriculadosMAX
		--seteo de grupo
	 	--SELECT * FROM @Matriculados 
		DECLARE @MinConsultaN INT = 0, @MaxConsultaN INT = 0 , @MinN INT = 1    
    
		SET @max = ROUND(CAST( CAST( @Cantidad  AS decimal(18,2)) /40.00 AS decimal(18,2)) + 0.5 , 0 ) --@9   --@12
        --SELECT @max GRUPOS 
		SET @MaxConsultaN = ROUND( CAST( @Cantidad  AS decimal(18,2)) /  @max , 0 )  --@9  --@12
        --SELECT  @MaxConsultaN CANTIDAPORGRUPO

		--declare @Grupo table
		CREATE TABLE #Grupo(IdGrupo int identity(1, 1), CantidadXGrupo int)
		
		DECLARE @MinIdGrupo int = 1
		WHILE @MinIdGrupo <=  @max  
		BEGIN
			insert #Grupo (CantidadXGrupo) values(@MaxConsultaN * @MinIdGrupo)
				
			set @MinIdGrupo = @MinIdGrupo + 1	
		END
		--select * from @Grupo
		DECLARE @LimGrupo int = 1
		SET @MinIdGrupo = 1
		WHILE @MinIdGrupo <=  @max 
		BEGIN
			--@14
			IF @MinIdGrupo=@max
			BEGIN
				update #MatriculadosMAX set  grupo = @MinIdGrupo where Id between @LimGrupo and @Cantidad
			END
			ELSE
			BEGIN
				update #MatriculadosMAX set  grupo = @MinIdGrupo where Id between @LimGrupo and (select CantidadXGrupo from #Grupo where IdGrupo = @MinIdGrupo)
				set @LimGrupo = (select CantidadXGrupo from #Grupo where IdGrupo = @MinIdGrupo) + 1
			END
			--update #MatriculadosMAX set  grupo = @MinIdGrupo where Id between @LimGrupo and (select CantidadXGrupo from #Grupo where IdGrupo = @MinIdGrupo)
			--set @LimGrupo = (select CantidadXGrupo from #Grupo where IdGrupo = @MinIdGrupo) + 1
			--@14
			SET @MinIdGrupo = @MinIdGrupo + 1
		END
		
		--select * from @Matriculados			
		DROP TABLE #Grupo  
		--select @MinN,@max
		WHILE @MinN <=  @max  
		BEGIN  
		  SELECT @SeccionAnterior = max(seccionnomina)    
          FROM AlumnoCursoNomina ACM  with(nolock)    
          inner join Promocion p  with(nolock) on ACM.IdPromocion = p.IdPromocion    
          WHERE p.IdPromocion = @IdPromocion 
		    
		  --select @SeccionAnterior
		  --if @InicializaLetra = 1 and @I = 1    
		  IF @SeccionAnterior is null
		  BEGIN
		    --select @Numero = 1 --@4    
			select @Numero = 'A'    
		  END
		  ELSE     
		  BEGIN    --debemos sacar la ultima letra para la promocion y modulo que estamos procesando    
		    --asignamos la letra --sacamos la siguiente    
		    --select @Numero = dbo.gRetornaLetraSiguiente(substring(@SeccionAnterior,len(@SeccionAnterior),1))--@4    
		    select @Numero = (dbo.gRetornaSeccion(@SeccionAnterior))--@4    
          END 
		   
		 --set @Numero=(SELECT dbo.gRetornaLetra(@MinN))
		 --select @Numero  Numero   
		  INSERT INTO AlumnoCursoNomina(    
					  IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,    
					  IdModulo,IdActor,IdCurso,IdPromocion,    
					  IdGrupo,IdPromocionCurso,IdGrupoCurso,    
					  IdCurricula,SeccionNomina,Turno,FechaCreacion,UsuarioCreacion)  
		  SELECT m.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto, 
				  m.IdMatricula,p.IdModulo,m.IdActor,isnull(ac.IdCursoOriginal,ac.Idcurso),    --@11
				  m.idpromocion,m.idgrupo,ac.IdPromocion,ac.IdGrupo,    
				  isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
				  @Seccion+@Numero--@4    
				  ,@turno,getdate(),@pUsuarioCreacion    
		  FROM Matricula m with(nolock)    
          inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
          inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula    
          inner join #MatriculadosMAX t on m.IdMatricula = t.IdMatricula    
          WHERE t.grupo=@MinN	--t.Id >= @MinConsultaN--1 --and t.Id <=@MaxConsultaN-- @max     
				and ac.EsMatricula = 1    
				and ac.TipoCondicion = 'RE'    
		  --select @SeccionAnterior  SeccionAnterior 

		  --inicio @6    
          INSERT INTO Bdadmin..AlumnoCursoNomina_Log (    
					  IdEmpresa,IdSede,IdPeriodo,IdProducto,    
					  IdMatricula,IdModulo,IdActor,IdCurso,IdPromocion,IdGrupo,    
					  IdPromocionCurso,IdGrupoCurso,IdCurricula,SeccionNomina,Turno,    
					  FechaCreacion,UsuarioCreacion)    
		  SELECT m.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,m.IdMatricula,p.IdModulo,m.IdActor,isnull(ac.IdCursoOriginal,ac.Idcurso),    --@11
				  m.idpromocion,m.idgrupo,ac.IdPromocion,ac.IdGrupo,
				  isnull(ac.IdCurriculaOriginal, ac.idcurricula),	--p.IdCurricula,	--@16
				  @Seccion+@Numero--@4    
				  ,@turno,getdate(),@pUsuarioCreacion    
          FROM Matricula m with(nolock)    
          inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
          inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula    
          inner join #MatriculadosMAX t on m.IdMatricula = t.IdMatricula    
          WHERE t.grupo=@MinN	--t.Id >= 1     -- and t.Id <= @max     
			    and ac.EsMatricula = 1    
			    and ac.TipoCondicion = 'RE'     
          --fin @6 

		  SET @MinConsultaN = @MaxConsultaN    
		  SET @MinConsultaN = @MaxConsultaN + ROUND( CAST( @Cantidad  AS decimal(18,2)) /  @max , 0 )  --@9  --@12
			
		  SET @MinN = @MinN + 1    
		  --PRINT @MinN
		END 
         --DELETE FROM @Matriculados  
		 DROP TABLE #MatriculadosMAX
   END
   ELSE
   BEGIN
	  BEGIN --@13   
		 --asignamos la letra     
		 IF @InicializaLetra = 1 --select @Numero = 1 --@4    
			select @Numero = 'A'    
		 ELSE    
		 BEGIN    
		   --debemos sacar la ultima letra para la promocion y modulo que estamos procesando    --asignamos la letra    
		   SELECT @SeccionAnterior = max(seccionnomina)    
		   FROM AlumnoCursoNomina ACM  with(nolock)    
		   inner join Promocion p  with(nolock) on ACM.IdPromocion = p.IdPromocion    
		   where p.IdPromocion = @IdPromocion    

		   --sacamos la siguiente          
		   --select @Numero = dbo.gRetornaLetraSiguiente(substring(@SeccionAnterior,len(@SeccionAnterior),1)) --@4    
		   SET @Numero =(SELECT dbo.gRetornaSeccion(@SeccionAnterior))--@4    
		 END    
    
		 INSERT INTO AlumnoCursoNomina(    
					 IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
					 IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
					 IdGrupoCurso,IdCurricula,SeccionNomina,Turno,FechaCreacion,UsuarioCreacion)    
		 SELECT m.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,m.IdMatricula,p.IdModulo,m.IdActor,isnull(ac.IdCursoOriginal,ac.Idcurso),   --@11 
			    m.IdPromocion,m.IdGrupo,ac.IdPromocion,ac.IdGrupo,
				isnull(ac.IdCurriculaOriginal, ac.idcurricula),	--p.IdCurricula,	--@16
				@Seccion+--dbo.gRetornaLetra(@Numero) --@4    
			    @Numero--@4    
			    ,@turno,getdate(),@pUsuarioCreacion    
		 FROM Matricula m with(nolock)    
		 inner join promocion p with(nolock)on m.idpromocion = p.idpromocion    
		 inner join Alumnocurso ac with(nolock)on m.IdMatricula = ac.IdMatricula    
		 WHERE m.IdPromocion = @IdPromocion    
			   and m.IdGrupo = @IdGrupo    
			   and m.EsMatricula = 1    
			   and m.Estado <> 'X'    
			   and m.TipoCondicion <> 'CC'    
			   and ac.EsMatricula = 1    
			   and ac.TipoCondicion = 'RE'    
			   and ac.IdCurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)  --@16

		 --inicio @6    
		 INSERT INTO Bdadmin..AlumnoCursoNomina_Log(    
					 IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
					 IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
					 IdGrupoCurso,IdCurricula,SeccionNomina,Turno,FechaCreacion,UsuarioCreacion)    
		 SELECT m.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,m.IdMatricula,p.IdModulo,m.IdActor,isnull(ac.IdCursoOriginal,ac.Idcurso),   --@11 
				m.IdPromocion,m.IdGrupo,ac.IdPromocion,ac.IdGrupo,
				isnull(ac.IdCurriculaOriginal, ac.idcurricula),	--p.IdCurricula,	--@16
				@Seccion+--dbo.gRetornaLetra(@Numero) --@4    
				@Numero--@4    
				,@turno,getdate(),@pUsuarioCreacion    
		 FROM Matricula m with(nolock)    
		 inner join promocion p with(nolock)on m.idpromocion = p.idpromocion    
		 inner join Alumnocurso ac with(nolock)on m.IdMatricula = ac.IdMatricula    
		 WHERE m.IdPromocion = @IdPromocion    
			   and m.IdGrupo = @IdGrupo    
			   and m.EsMatricula = 1    
			   and m.Estado <> 'X'    
			   and m.TipoCondicion <> 'CC'    
			   and ac.EsMatricula = 1    
			   and ac.TipoCondicion = 'RE'    
			   and ac.IdCurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)  --@16
		 --fin @6    
    
		 SELECT @prueba = COUNT(1)    
		 FROM AlumnoCursoNomina ACM  with(nolock)    
		 inner join Promocion p  with(nolock) on ACM.IdPromocion = p.IdPromocion    
		 WHERE p.IdPromocion = @IdPromocion          
	  END  --@13   
   END -->40           
    
	-- eliminamos el registro procesado                    
	DELETE N FROM @Resultadox N    
	WHERE N.Id = (SELECT TOP 1 Id FROM @Resultadox ORDER BY Id)                 
 END -- en while     
      
  -- proceso para los cursos de cargo    
  INSERT INTO @Resultado    
  SELECT m.idsede,M.IdMatricula,p.IdProducto,a.NombreCompleto,cc.IdModulo,mtr.Disponible5,    
		 p.IdPeriodo,ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula), --@2 --@7    
		 pe.Codigo Seccion,    
		 m.IdActor,ISNULL(AC.IdCursoOriginal,ac.IdCurso),m.IdPromocion,m.IdGrupo --@2 --@7    
  FROM matricula m with(nolock)    
  inner join promocion p with(nolock)on m.idpromocion = p.idpromocion     
  inner join periodo pe with(nolock)on p.idperiodo = pe.idperiodo    
  inner join Actor a with(nolock)on m.IdActor = a.IdActor     
  inner join alumnocurso ac with(nolock)on m.IdMatricula = ac.IdMatricula    
  inner join CurriculaCurso cc with(nolock) on cc.IdCurricula = ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) and cc.IdCurso = ISNULL(AC.IdCursoOriginal,ac.IdCurso) --@2 --@7    
  inner join PromocionGrupo pg with(nolock) on AC.IdPromocion = Pg.IdPromocion and ac.IdGrupo = pg.IdGrupo    
  inner join Turno t with(nolock) on pg.IdTurno = t.IdTurno    
  inner join MaestroTablaRegistro mtr with(nolock) on t.IdTipoTurno = mtr.IdMaestroRegistro    
  inner join Producto pr with(nolock) on p.IdProducto = pr.IdProducto    
  INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON pr.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro  --@1    
  WHERE m.EsMatricula = 1    
	    and m.Estado<>'X'    
	    and ac.EsMatricula = 1    
	    and p.IdEmpresa = @pIdEmpresa    
	    and p.IdSede = @pIdSede    
	    and p.IdUnidadNegocio = @pIdUnidadNegocio    
	    and p.IdUnidadAcademica = @pIdUnidadAcademica    
	    and p.IdPeriodo = @pIdPeriodo    
	    and (p.IdProducto = @pIdProducto or @pIdProducto = 0)    
	    AND (M.TipoCondicion <> 'RE') --@8  
	    AND AC.TipoCondicion = 'CC'    
	    --and m.IdMatricula = 1033424    
	    AND (( MTR_PRO.Disponible1='C' AND  MTR_PRO.Disponible2='CAR' ) OR MTR_PRO.Disponible1='P' ) --@1    
	    AND P.IdUnidadNegocio IN (1) --@1   
		AND NOT EXISTS (
        SELECT 1
        FROM AlumnoSinSeccionNominaProceso ASSNP WITH (NOLOCK)
        WHERE ASSNP.IdMatricula = M.IdMatricula
          AND ASSNP.IdCurso     = AC.IdCurso
          AND ASSNP.Estado      = 1
  )--@18
  --AND M.IdMatricula=742254
  ORDER BY 2,4,5,3    
    
	select '@Resultado',*from @Resultado

  INSERT INTO @Resultado2    
  SELECT IdSede, IdProducto,IdModulo,Seccion,Turno, IdCurricula,count(distinct IdMatricula)    --@16
  FROM @Resultado    
  GROUP BY IdSede,IdProducto,IdModulo,Seccion,Turno, IdCurricula    
  
  WHILE EXISTS (SELECT DISTINCT 1 FROM @Resultado2)    
  BEGIN    
	 SELECT TOP 1    
	 @IdSede = IdSede,    
	 @IdProducto = IdProducto,    
	 @IdModulo = IdModulo,    
	 @Periodo = Periodo,    
	 @Turno = Turno,    
	 @Idcurricula = idcurricula,    --@16
	 @Cantidad = Cantidad    
	 FROM @Resultado2   
	 ORDER BY Id     
	    
	 IF @Cantidad > 40 AND @Cantidad <= 80 -- @3    
	 BEGIN    
		  CREATE TABLE #Matriculados6 (Id Int Identity,    
				 IdMatricula Int,    
				 IdCurso Int,    
				 NombreCompleto varchar(1000))    
    
		  INSERT INTO #Matriculados6    
		  SELECT ac.IdMatricula, ISNULL(ac.IdCursoOriginal,ac.IdCurso), a.NombreCompleto    --@12
		  FROM @Resultado r    
		  inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and --@7    
													r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
		  inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
		  inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
													and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
		  inner join Actor a with(nolock) on ac.IdAlumno = a.IdActor    
		  where r.idproducto = @IdProducto    
			    and r.idsede = @IdSede    
			    and r.idmodulo = @IdModulo    
			    and r.turno = @Turno  
				and r.IdCurricula = @Idcurricula  
		  order by 3 asc     
    --select  '#Matriculados6',*from #Matriculados6
		  -- tenemos que separar las secciones en 2    
		  create TABLE #Matriculados7(Id Int Identity,    
				 IdMatricula Int,    
				 Valor Int)    
	
		  INSERT INTO #Matriculados7    
		  SELECT idmatricula,MAX(id) FROM #Matriculados6    
		  GROUP BY IdMatricula    
		  ORDER BY 2              
    
		  SELECT @max = valor    
		  FROM #Matriculados7    
		  WHERE Id = @Cantidad/2    
    
		  SELECT @max2 = valor    
		  FROM #Matriculados7    
		  WHERE Id = @Cantidad    
    
		  --select @max = @Cantidad/2    
		  SELECT @i = 1    
		  --select @max2 = @Cantidad    
		  
		  WHILE @i<=2    
		  BEGIN    
			SELECT @SeccionAnterior = max(SeccionNomina)    
			FROM AlumnoCursoNomina   with(nolock)    
			WHERE IdProducto = @IdProducto    
				  and IdSede = @IdSede    
				  and IdModulo = @IdModulo    
				  AND IDPERIODO = @pIdPeriodo 
				  and IdCurricula = @Idcurricula  --@16
			--and turno = @Turno    
    
			-- no se ha generado la promocion para el producto en el modulo y la sede    
			IF @SeccionAnterior is null          
			BEGIN	--8.VI.01.2016-II-VI-A    
				SELECT @Seccion = convert(varchar,(select codigo FROM curricula with(nolock) WHERE IdCurricula = @Idcurricula))+	--@17
				--SELECT @Seccion = convert(varchar,(select NumeroInterno FROM Producto with(nolock) WHERE IdProducto = @IdProducto))+	
								  '.'+dbo.gEnteroARomano(@Idmodulo)+'.01.'+@Periodo+'-'+dbo.gEnteroARomano(@Idmodulo)+'-'+dbo.gRetornaLetra(1)    
			END    
			ELSE
			BEGIN    
				--select @Numero = dbo.gRetornaLetraSiguiente(substring(@SeccionAnterior,len(@SeccionAnterior),1))--@4    
				--select @Seccion = r.Seccion+dbo.gRetornaLetra(@Numero)    
				--select @Seccion =  substring(@SeccionAnterior,1,len(@SeccionAnterior)-1)+dbo.gRetornaLetra(@Numero)--@4    
				IF (ISNUMERIC(substring(@SeccionAnterior,len(@SeccionAnterior),1))!=0)    
				BEGIN    
					SELECT @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-2) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
				END    
				ELSE    
				BEGIN    
					SELECT @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-1) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
				END    
			END            
    
			--procesamiento de cada uno de los 2 grupos    
			IF @i=1    
			BEGIN    
				INSERT INTO AlumnoCursoNomina(IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
							IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,IdGrupoCurso,    
							IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
				SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,cc.IdModulo,    --@12
					   r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,    
					   ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
				FROM @Resultado r    
				inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and --@7    
														  r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
				inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
				inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
														 and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
				inner join #Matriculados6 t on ac.IdMatricula = t.IdMatricula and ac.IdCurso = t.IdCurso    
				WHERE t.Id >= 1 and t.Id <= @max    
              
				--inicio @6    
				INSERT INTO Bdadmin..AlumnoCursoNomina_Log(IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
														   IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,IdGrupoCurso,    
														   IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
				SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,cc.IdModulo,     --@12
					   r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,    
					   ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
				FROM @Resultado r    
				inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ac.idcurso and r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula) and
														  r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
				inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
				inner join CurriculaCurso cc with(nolock) on ac.IdCurricula = cc.IdCurricula and ac.IdCurso = cc.IdCurso    
				inner join #Matriculados6 t on ac.IdMatricula = t.IdMatricula and ac.IdCurso = t.IdCurso    
				where t.Id >= 1 and t.Id <= @max             
				--fin @6    
			END     
			ELSE             
			BEGIN
			  INSERT INTO AlumnoCursoNomina(IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
											IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,IdGrupoCurso,    
											IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
			  SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,cc.IdModulo,     --@12
				     r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,    
				     ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
			  FROM @Resultado r    
			  inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and --@7    
														r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
			  inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
			  inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
													   and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
			  inner join #Matriculados6 t on ac.IdMatricula = t.IdMatricula and ac.IdCurso = t.IdCurso    
			  WHERE t.Id >= @max+1 and t.Id <= @max2    
              
			  --inicio @6    
			  INSERT INTO Bdadmin..AlumnoCursoNomina_Log (IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
														  IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,IdGrupoCurso,    
														  IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
			  SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,cc.IdModulo,     --@12
				     r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,    
				     ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
			  FROM @Resultado r    
			  inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and --@7   
														r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
			  inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
			  inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
													   and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
			  inner join #Matriculados6 t on ac.IdMatricula = t.IdMatricula and ac.IdCurso = t.IdCurso    
			  WHERE t.Id >= @max+1 and t.Id <= @max2    
			  --fin @6    
			END
			SELECT @i = @i + 1    
		  END    
    
		  drop table #Matriculados6    
		  drop table #Matriculados7    
	 END    
	 ELSE    
	 BEGIN    
		 -- @3 Inicio    
		 IF @Cantidad>80     
		 BEGIN    
			CREATE TABLE #Matriculados4 (Id Int Identity,    
				 IdMatricula Int,    
				 IdCurso Int,    
				 NombreCompleto varchar(1000))                 
    
			INSERT INTO #Matriculados4      
			SELECT ac.IdMatricula, ISNULL(ac.IdCursoOriginal,ac.IdCurso), a.NombreCompleto   --@12 
			FROM @Resultado r    
			inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and --@7    
													  r.idcurricula = ISNULL(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
			inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
			inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
												and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
			inner join Actor a with(nolock)on ac.IdAlumno = a.IdActor    
			where r.idproducto = @IdProducto    
				  and r.idsede = @IdSede    
				  and r.idmodulo = @IdModulo    
				  and r.turno = @Turno    
				  and r.IdCurricula = @Idcurricula  --@16
			order by 3 asc     
    --select '#Matriculados4',*from #Matriculados4
			-- tenemos que separar las secciones en 2    
			CREATE TABLE #Matriculados5(Id Int Identity,    
				 IdMatricula Int,    
				 Valor Int)    
    
			INSERT INTO #Matriculados5    
			SELECT idmatricula,MAX(id) FROM #Matriculados4    
			GROUP BY IdMatricula    
			ORDER BY 2    
	
			DECLARE @MinConsulta INT = 0, @MaxConsulta INT = 0 , @Min INT = 1    
    
			SET @max = ROUND(CAST( CAST( @Cantidad  AS decimal(18,2)) /40.00 AS decimal(18,2)) + 0.5 , 0 ) --@9   --@12
                
			SET @MaxConsulta = ROUND( CAST( @Cantidad  AS decimal(18,2)) /  @max , 0 )  --@9  --@12
             
			select @i = 1    
    
			WHILE @Min <=  @max    
			BEGIN
				SELECT @SeccionAnterior = max(SeccionNomina)    
				FROM AlumnoCursoNomina   with(nolock)    
				WHERE IdProducto = @IdProducto    
					  and IdSede = @IdSede    
					  and IdModulo = @IdModulo    
					  and IDPERIODO = @pIdPeriodo 
					  and IdCurricula = @Idcurricula	--@16
					  --and turno = @Turno    
    
				-- no se ha generado la promocion para el producto en el modulo y la sede    
				IF @SeccionAnterior is null    
				BEGIN    
					--8.VI.01.2016-II-VI-A    
					SELECT @Seccion = convert(varchar,(select codigo FROM curricula with(nolock) WHERE IdCurricula = @Idcurricula))+	--@17
					--SELECT @Seccion = convert(varchar,(select NumeroInterno FROM Producto with(nolock) WHERE IdProducto = @IdProducto))
									  +'.'+dbo.gEnteroARomano(@Idmodulo)+'.01.'+@Periodo+'-'+dbo.gEnteroARomano(@Idmodulo)+'-'+dbo.gRetornaLetra(1)    
				END    
				ELSE    
				BEGIN    
					--select @Numero = dbo.gRetornaLetraSiguiente(substring(@SeccionAnterior,len(@SeccionAnterior),1))  --@4    
					--select @Seccion = r.Seccion+dbo.gRetornaLetra(@Numero)    
					--select @Seccion =  substring(@SeccionAnterior,1,len(@SeccionAnterior)-1)+dbo.gRetornaLetra(@Numero)--@4    
					IF (ISNUMERIC(substring(@SeccionAnterior,len(@SeccionAnterior),1))!=0)    
					BEGIN    
						SELECT @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-2) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
					END    
					ELSE    
					BEGIN    
						SELECT @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-1) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
					END    
				END     
    
				IF @Min=@max    
				BEGIN              
    				INSERT INTO AlumnoCursoNomina(IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
												  IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
												  IdGrupoCurso,IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
					SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,cc.IdModulo,     --@12 
						   r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,    
						   ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
					FROM @Resultado r    
					inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and --@7    
															  r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
					inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
					inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
															 and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
					inner join #Matriculados4 t on ac.IdMatricula = t.IdMatricula and ac.IdCurso = t.IdCurso    
					inner join #Matriculados5 t2 on t.IdMatricula = t2.IdMatricula     
					where t2.Id > @MinConsulta and t2.Id <= @Cantidad      
    
					--inicio @6    
					INSERT INTO Bdadmin..AlumnoCursoNomina_Log(IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
																IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
																IdGrupoCurso,IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
					SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,cc.IdModulo,     --@12 
								r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,    
								ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
					from @Resultado r    
					inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and--@7    
															  r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
					inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
					inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
															  and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
					inner join #Matriculados4 t on ac.IdMatricula = t.IdMatricula and ac.IdCurso = t.IdCurso    
					inner join #Matriculados5 t2 on t.IdMatricula = t2.IdMatricula     
					where t2.Id > @MinConsulta and t2.Id <= @Cantidad    
					--fin @6     
				END       
				ELSE    
				BEGIN    
					INSERT INTO AlumnoCursoNomina(IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
												  IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
												  IdGrupoCurso,IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
					SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,cc.IdModulo,     --@12 
						   r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,    
						   ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
					FROM @Resultado r    
					inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and --@7    
															  r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
					inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
					inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
															 and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
					inner join #Matriculados4 t on ac.IdMatricula = t.IdMatricula and ac.IdCurso = t.IdCurso    
					inner join #Matriculados5 t2 on t.IdMatricula = t2.IdMatricula     
					WHERE t2.Id > @MinConsulta and t2.Id <= @MaxConsulta    
    
					--inicio @6    
					INSERT INTO Bdadmin..AlumnoCursoNomina_Log (IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
																IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
																IdGrupoCurso,IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
					SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,cc.IdModulo,     --@12 
					       r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,    
						   ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
					FROM @Resultado r    
					inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(ac.IdCursoOriginal,ac.idcurso) and --@7    
															  r.idcurricula = isnull(ac.idcurriculaoriginal, ac.idcurricula)	-- @16
					inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
					inner join CurriculaCurso cc with(nolock) on ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) = cc.IdCurricula --@7    
															 and ISNULL(ac.IdCursoOriginal,ac.IdCurso) = cc.IdCurso --@7    
					inner join #Matriculados4 t on ac.IdMatricula = t.IdMatricula and ac.IdCurso = t.IdCurso    
					inner join #Matriculados5 t2 on t.IdMatricula = t2.IdMatricula     
					where t2.Id > @MinConsulta and t2.Id <= @MaxConsulta    
					--fin @6    
				END    
    
				SET @MinConsulta = @MaxConsulta    
				SET @MaxConsulta = @MaxConsulta + ROUND( CAST( @Cantidad  AS decimal(18,2)) /  @max , 0 )  --@9  --@12
				SET @Min = @Min + 1    
				END          
    
				drop table #Matriculados4    
				drop table #Matriculados5    
    
			END	 -- @3 Fin     
			ELSE    
			BEGIN  --     
				SELECT @IdProducto,@IdSede,@IdModulo,@pIdPeriodo,@Idcurricula,'VARIABLES DE LA SECCION ANTERIOR'
				 SELECT @SeccionAnterior = max(SeccionNomina)    
				 FROM AlumnoCursoNomina   with(nolock)    
				 WHERE IdProducto = @IdProducto    
					   and IdSede = @IdSede    
					   and IdModulo = @IdModulo    
					   AND IDPERIODO = @pIdPeriodo
					   AND IdCurricula = @Idcurricula    --@16
					   --and turno = @Turno    
				 -- no se ha generado la promocion para el producto en el modulo y la sede    
				 IF @SeccionAnterior is null    
				 BEGIN    
					--8.VI.01.2016-II-VI-A    
					SELECT @Seccion = convert(varchar,(select codigo FROM curricula with(nolock) WHERE IdCurricula = @Idcurricula))+	--@17
					--SELECT @Seccion = convert(varchar,(select NumeroInterno FROM Producto with(nolock) where IdProducto = @IdProducto))
									  +'.'+dbo.gEnteroARomano(@Idmodulo)+'.01.'+@Periodo+'-'+dbo.gEnteroARomano(@Idmodulo)+'-'+dbo.gRetornaLetra(1)    

									  select @Seccion, '@Seccion nuleada'
				 END    
				 ELSE    
				 BEGIN    
				 --SELECT @SeccionAnterior,'@SeccionAnterior'
					--select @Numero = dbo.gRetornaLetraSiguiente(substring(@SeccionAnterior,len(@SeccionAnterior),1))  --@4    
					--select @Seccion = r.Seccion+dbo.gRetornaLetra(@Numero)    
					--select @Seccion =  substring(@SeccionAnterior,1,len(@SeccionAnterior)-1)+dbo.gRetornaLetra(@Numero) --@4          
					IF (ISNUMERIC(substring(@SeccionAnterior,len(@SeccionAnterior),1))!=0)          
					BEGIN    
						SELECT @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-2) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
					END    
					ELSE    
					BEGIN    
						SELECT @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-1) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
					END    
				 END                 
    
				 INSERT INTO AlumnoCursoNomina (IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
												 IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
												 IdGrupoCurso,IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
				 SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,r.IdModulo,     --@12 
						r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
				 FROM @Resultado r    
				 inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(AC.IdCursoOriginal,ac.IdCurso) --@2 --@7    
				 inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
				 inner join CurriculaCurso cc with(nolock) on R.IdCurricula= cc.IdCurricula and R.IdCurso = cc.IdCurso    
				
				 WHERE r.idproducto = @IdProducto    
					   and r.idsede = @IdSede    
					   and r.idmodulo = @IdModulo    
					   and r.turno = @Turno    
					   and r.IdCurricula = @Idcurricula --@16   
					--select '@Resultado mas abajo',*from 	@Resultado
					--SELECT @Seccion
				 --inicio @6    
				 INSERT INTO Bdadmin..AlumnoCursoNomina_Log (IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
															 IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
															 IdGrupoCurso,IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
				 SELECT p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,r.IdModulo,     --@12 
						r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),1    
				 FROM @Resultado r    
				 inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(AC.IdCursoOriginal,ac.IdCurso) --@2 --@7    
				 inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
				 inner join CurriculaCurso cc with(nolock) on R.IdCurricula= cc.IdCurricula and R.IdCurso = cc.IdCurso    
				 WHERE r.idproducto = @IdProducto    
					   and r.idsede = @IdSede    
					   and r.idmodulo = @IdModulo    
					   and r.turno = @Turno    
					   AND r.IdCurricula = @Idcurricula --@16
				 --fin @6    
			 END     
	END     
	    
	 -- eliminamos el registro procesado                   
	 DELETE N FROM @Resultado2 N WHERE N.Id = (SELECT TOP 1 Id FROM @Resultado2 ORDER BY Id)        
    
  END -- en while      

 --@8 --@10   
  --Cambio temporal Nominas     
  IF @pIdUnidadAcademica=57  
  BEGIN  
	  INSERT INTO @Resultado3    
	  SELECT m.idsede,M.IdMatricula,p.IdProducto,a.NombreCompleto,cc.IdModulo,mtr.Disponible5,    
			 p.IdPeriodo,ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula), --@2 --@7    
			 pe.Codigo Seccion,    
			 m.IdActor,ISNULL(AC.IdCursoOriginal,ac.IdCurso),m.IdPromocion,m.IdGrupo --@2 --@7    
	  FROM matricula m with(nolock)    
	  inner join promocion p with(nolock)on m.idpromocion = p.idpromocion     
	  inner join periodo pe with(nolock)on p.idperiodo = pe.idperiodo    
	  inner join Actor a with(nolock)on m.IdActor = a.IdActor     
	  inner join alumnocurso ac with(nolock)on m.IdMatricula = ac.IdMatricula    
	  inner join CurriculaCurso cc with(nolock) on cc.IdCurricula = ISNULL(ac.IdCurriculaOriginal,ac.IdCurricula) and cc.IdCurso = ISNULL(AC.IdCursoOriginal,ac.IdCurso) --@2 --@7    
	  inner join PromocionGrupo pg with(nolock) on AC.IdPromocion = Pg.IdPromocion and ac.IdGrupo = pg.IdGrupo    
	  inner join Turno t with(nolock) on pg.IdTurno = t.IdTurno    
	  inner join MaestroTablaRegistro mtr with(nolock) on t.IdTipoTurno = mtr.IdMaestroRegistro    
	  inner join Producto pr with(nolock) on p.IdProducto = pr.IdProducto    
	  INNER JOIN MaestroTablaRegistro MTR_PRO WITH (NOLOCK) ON pr.IdClasificacionProducto =MTR_PRO.IdMaestroRegistro  --@1    
	  WHERE m.EsMatricula = 1    
		    and m.Estado<>'X'    
		    and ac.EsMatricula = 1    
		    and p.IdEmpresa = @pIdEmpresa    
		    and p.IdSede = @pIdSede  
		    and p.IdUnidadNegocio = @pIdUnidadNegocio    
		    and p.IdUnidadAcademica = @pIdUnidadAcademica    
		    and p.IdPeriodo = @pIdPeriodo    
		    and (p.IdProducto = @pIdProducto or @pIdProducto = 0)    
		    AND (M.TipoCondicion = 'RE') --@8  
		    AND AC.TipoCondicion = 'CC'    
		    --and m.IdMatricula = 1370988    
		    AND (( MTR_PRO.Disponible1='C' AND  MTR_PRO.Disponible2='CAR' ) OR MTR_PRO.Disponible1='P' ) --@1    
		    AND P.IdUnidadNegocio IN (1) --@1
			AND NOT EXISTS (
        SELECT 1
        FROM AlumnoSinSeccionNominaProceso ASSNP WITH (NOLOCK)
        WHERE ASSNP.IdMatricula = M.IdMatricula
          AND ASSNP.IdCurso     = AC.IdCurso
          AND ASSNP.Estado      = 1
  )--@18
	  order by 2,4,5,3       
  --select '@Resultado3',* from @Resultado3
	  INSERT INTO @Resultado4    
	  SELECT IdSede, IdProducto,IdModulo,IdPromocion,IdGrupo,Seccion,Turno, IdCurricula, count(distinct IdMatricula)    --@16
	  FROM @Resultado3    
	  GROUP BY IdSede,IdProducto,IdModulo,IdPromocion,IdGrupo,Seccion,Turno, IdCurricula   
  
  --select '@Resultado4',*from @Resultado4
	  WHILE EXISTS (SELECT * FROM @Resultado4)    
	  BEGIN    
		SELECT TOP 1    
		@IdSede = IdSede,    
		@IdProducto = IdProducto,    
		@IdModulo = IdModulo,   
		@IdPromocion= IdPromocion,  
		@IdGrupo= IdGrupo,  
		@Periodo = Periodo,    
		@Turno = Turno,    
		@Idcurricula = idcurricula,    --@16
		@Cantidad = Cantidad    
		FROM @Resultado4    
		ORDER BY Id     
       
		--print 'Cantidad ' + convert(varchar,@Cantidad) + ' - Grupo ' +  convert(varchar,@Idgrupo) + ' Modulo - ' +  convert(varchar,@IdModulo) + ' ' + @turno 
		UPDATE PromocionGrupo --No se aumento ningun valor por que las promociones y el grupo es unico    
		SET EsNomina = 1,FechaModificacion = GETDATE(), UsuarioModificacion = @pUsuarioCreacion    
		WHERE IdPromocion = @IdPromocion and IdGrupo = @IdGrupo    
    
	    IF @Cantidad>40    
		BEGIN    
		  CREATE TABLE #Matriculados1 (Id Int Identity,    
									   IdMatricula Int,    
									   NombreCompleto varchar(1000))    
            
		  INSERT INTO #Matriculados1    
		  SELECT DISTINCT m.IdMatricula, a.NombreCompleto    
		  From Matricula m with(nolock)    
		  inner join Actor a with(nolock) on m.IdActor = a.IdActor    
		  inner join AlumnoCurso AC with(nolock) on m.idmatricula = ac.idmatricula    
		  WHERE m.IdPromocion = @IdPromocion    
				and m.IdGrupo = @IdGrupo    
				and m.EsMatricula =1    
				and m.Estado<>'X'    
				and m.TipoCondicion <>'CC'    
				and ac.esmatricula = 1    
				and ac.tipocondicion = 'CC' 
				and ISNULL(ac.idcurriculaoriginal, ac.idcurricula)= @idcurricula   --@16
		  order by 2 asc    
    --select '#Matriculados1',*from #Matriculados1
		  -- tenemos que separar las secciones en 2    
		  select @max = @Cantidad/2     
		  select @i = 1    
		  select @max2 = @Cantidad    
    
		  WHILE @i<=2    
		  BEGIN --     
			SELECT @SeccionAnterior = max(SeccionNomina)    
			FROM AlumnoCursoNomina   with(nolock)    
			WHERE IdProducto = @IdProducto    
				  and IdSede = @IdSede    
				  and IdModulo = @IdModulo    
				  AND IDPERIODO = @pIdPeriodo
				  AND IdCurricula = @Idcurricula	--@16

			-- no se ha generado la promocion para el producto en el modulo y la sede    
			IF @SeccionAnterior is null    
			BEGIN    
				--8.VI.01.2016-II-VI-A    
				SELECT @Seccion = convert(varchar,(select codigo FROM curricula with(nolock) WHERE IdCurricula = @Idcurricula))+	--@17
				--SELECT @Seccion = convert(varchar,(select NumeroInterno FROM Producto with(nolock) where IdProducto = @IdProducto))
								  +'.'+dbo.gEnteroARomano(@Idmodulo)+'.01.'+@Periodo+'-'+dbo.gEnteroARomano(@Idmodulo)+'-'+dbo.gRetornaLetra(1)    
			END    
			ELSE    
			BEGIN  
				IF (ISNUMERIC(substring(@SeccionAnterior,len(@SeccionAnterior),1))!=0)     
				BEGIN    
					select @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-2) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
				END    
				ELSE    
				BEGIN    
					select @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-1) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
					--select @Seccion = convert(varchar,pr.numerointerno)+'.'+pg.grupocodigo+'-'+dbo.gEnteroARomano(@Idmodulo)+'-' + dbo.gRetornaSeccion(@SeccionAnterior)
					--	from @Resultado4 m
					--	inner join Producto pr with(nolock) on pr.IdProducto=m.IdProducto
					--	inner join promocion p2 with(nolock) on p2.IdPromocion=m.IdPromocion 
					--	inner join promocion p with(nolock) on p.IdProducto=pr.IdProducto and p2.IdPeriodo=p.IdPeriodo and p.idmodulo=@idmodulo				
					--	inner join PromocionGrupo pg with(nolock) on pg.IdPromocion=p.IdPromocion and m.IdGrupo=pg.IdGrupo	
					--	where m.IdProducto=@IdProducto and m.IdGrupo=@IdGrupo and m.Idmodulo=@idmodulo
				END    
			END           

			--procesamiento de cada uno de los 2 grupos    
			IF @i=1    
			BEGIN             
				INSERT INTO AlumnoCursoNomina(IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,    
											  IdModulo,IdActor,IdCurso,IdPromocion,    
											  IdGrupo,IdPromocionCurso,IdGrupoCurso,    
											  IdCurricula,SeccionNomina,Turno,FechaCreacion,UsuarioCreacion)    
				SELECT p.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,    
					   m.IdMatricula,@Idmodulo,m.IdActor,ac.IdCurso,    
					   m.idpromocion,m.idgrupo,ac.IdPromocion,ac.IdGrupo,    
					   isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
					   @Seccion, @turno, getdate(), @pUsuarioCreacion    
				FROM @Resultado3 m   
				inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
				inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula and ac.idcurso=m.IdCurso   
				inner join #Matriculados1 t on m.IdMatricula = t.IdMatricula    
				WHERE t.Id >= 1     
					  and t.Id <= @max     
					  and ac.EsMatricula = 1    
					  and ac.TipoCondicion = 'CC'  
					  and m.Idmodulo = @Idmodulo    
					  and m.IdCurricula = @Idcurricula	--@16   
				
				--inicio @6    
				INSERT INTO Bdadmin..AlumnoCursoNomina_Log (IdEmpresa,IdSede,IdPeriodo,IdProducto,    
															IdMatricula,IdModulo,IdActor,IdCurso,IdPromocion,IdGrupo,    
															IdPromocionCurso,IdGrupoCurso,IdCurricula,SeccionNomina,Turno,    
															FechaCreacion,UsuarioCreacion)    
				SELECT p.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,m.IdMatricula,@Idmodulo,m.IdActor,ac.IdCurso,    
					   m.idpromocion,m.idgrupo,ac.IdPromocion,ac.IdGrupo,
					   isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
					   @Seccion--@4    
					   ,@turno, getdate(), @pUsuarioCreacion    
				FROM @Resultado3 m   
				inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
				inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula and ac.idcurso=m.IdCurso   
				inner join #Matriculados1 t on m.IdMatricula = t.IdMatricula    
				where t.Id >= 1     
					  and t.Id <= @max     
					  and ac.EsMatricula = 1    
					  and ac.TipoCondicion = 'CC'  
					  and m.Idmodulo = @Idmodulo      
					  and m.IdCurricula = @Idcurricula	--@16   
				--fin @6    
			END     
			ELSE
			BEGIN    
				INSERT INTO AlumnoCursoNomina(IdEmpresa,IdSede,IdPeriodo,IdProducto,    
											  IdMatricula,IdModulo,IdActor,IdCurso,IdPromocion,    
											  IdGrupo,IdPromocionCurso,IdGrupoCurso,IdCurricula,    
											  SeccionNomina,Turno,FechaCreacion,UsuarioCreacion)    
				SELECT p.IdEmpresa,m.IdSede,p.IdPeriodo,p.IdProducto,    
					   m.IdMatricula,@Idmodulo,m.IdActor,ac.IdCurso,    
					   m.idpromocion,m.idgrupo,ac.IdPromocion,    
					   ac.IdGrupo,isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
					   @Seccion
					   ,@turno,getdate(),@pUsuarioCreacion    
				FROM @Resultado3 m   
				inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
				inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula and ac.idcurso=m.IdCurso   
				inner join #Matriculados1 t on m.IdMatricula = t.IdMatricula    
				where t.Id >= @max+1     
					  and t.Id <= @max2    
					  and ac.EsMatricula = 1    
					  and ac.TipoCondicion = 'CC'
					  and m.Idmodulo = @Idmodulo    
					  and m.IdCurricula = @Idcurricula	--@16   

				--inicio @6    
				INSERT INTO Bdadmin..AlumnoCursoNomina_Log (IdEmpresa,IdSede,IdPeriodo,IdProducto,    
						IdMatricula,IdModulo,IdActor,IdCurso,IdPromocion,IdGrupo,    
						IdPromocionCurso,IdGrupoCurso,IdCurricula,SeccionNomina,Turno,    
						FechaCreacion,UsuarioCreacion)    
				SELECT p.IdEmpresa,m.IdSede,p.IdPeriodo,    
					   p.IdProducto,m.IdMatricula,@Idmodulo,m.IdActor,ac.IdCurso,    
					   m.idpromocion,m.idgrupo,ac.IdPromocion,ac.IdGrupo,
					   isnull(ac.idcurriculaoriginal, ac.idcurricula),	--p.IdCurricula,	--@16
					   @Seccion
					   ,@turno,getdate(),@pUsuarioCreacion    
				from @Resultado3 m   
				inner join promocion p with(nolock) on m.idpromocion = p.idpromocion    
				inner join Alumnocurso ac with(nolock) on m.IdMatricula = ac.IdMatricula and ac.idcurso=m.IdCurso   
				inner join #Matriculados1 t on m.IdMatricula = t.IdMatricula   
				where t.Id >= 1     
					  and t.Id <= @max     
					  and ac.EsMatricula = 1    
					  and ac.TipoCondicion = 'CC'
					  and m.Idmodulo = @Idmodulo  
					  and m.IdCurricula = @Idcurricula	--@16   
					  --fin @6    
				select @i = @i + 1  
			END  
		  END        
		   drop table #Matriculados1    
		END    
	    ELSE    
		BEGIN    
			--asignamos la letra     
			SELECT @SeccionAnterior = max(SeccionNomina)    
			FROM AlumnoCursoNomina   with(nolock)    
			WHERE IdProducto = @IdProducto    
				  AND IdSede = @IdSede    
				  AND IdModulo = @IdModulo    
				  AND IDPERIODO = @pIdPeriodo 
				  AND IdCurricula = @Idcurricula	--@16 
		
			 -- no se ha generado la promocion para el producto en el modulo y la sede    
			IF @SeccionAnterior is null    
			BEGIN    
			   --8.VI.01.2016-II-VI-A    
			   SELECT @Seccion = convert(varchar,(select codigo FROM curricula with(nolock) WHERE IdCurricula = @Idcurricula))+	--@17
			   --select @Seccion = convert(varchar,(select NumeroInterno from Producto with(nolock) where IdProducto = @IdProducto))
								 +'.'+dbo.gEnteroARomano(@Idmodulo)+'.01.'+@Periodo+'-'+dbo.gEnteroARomano(@Idmodulo)+'-'+dbo.gRetornaLetra(1)    
			END    
			ELSE    
			BEGIN 
				IF (ISNUMERIC(substring(@SeccionAnterior,len(@SeccionAnterior),1))!=0)          
				BEGIN    
					select @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-2) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
				END    
				ELSE    
				BEGIN    
					select @Seccion = substring(@SeccionAnterior,1,len(@SeccionAnterior)-1) + dbo.gRetornaSeccion(@SeccionAnterior)--@4    
				END    
			END    
  
			insert into AlumnoCursoNomina (IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
										   IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
										   IdGrupoCurso,IdCurricula,SeccionNomina,turno,FechaCreacion,UsuarioCreacion)    
			select p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,r.IdModulo,     --@12 
				   r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),@pUsuarioCreacion  
			from @Resultado3 r    
			inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(AC.IdCursoOriginal,ac.IdCurso) --@2 --@7    
			inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
			inner join CurriculaCurso cc with(nolock) on R.IdCurricula= cc.IdCurricula and R.IdCurso = cc.IdCurso    
			where r.idproducto = @IdProducto    
				  and r.idsede = @IdSede    
				  and r.idmodulo = @IdModulo  
				  and r.IdGrupo = @IdGrupo    
				  and r.turno = @Turno
				  and r.IdCurricula = @Idcurricula	--@16   
    
			 --inicio @6    
			 insert into Bdadmin..AlumnoCursoNomina_Log(IdEmpresa,IdSede,IdPeriodo,IdProducto,IdMatricula,IdModulo,    
														IdActor,IdCurso,IdPromocion,IdGrupo,IdPromocionCurso,    
														IdGrupoCurso,IdCurricula,SeccionNomina,Turno,FechaCreacion,UsuarioCreacion)    
			 select p.IdEmpresa,r.IdSede,r.IdPeriodo,r.IdProducto,r.IdMatricula,r.IdModulo,     --@12 
					r.IdActor,r.idcurso,r.idpromocion,r.idgrupo,ac.idpromocion,ac.idgrupo,r.IdCurricula,@Seccion,@Turno,GETDATE(),@pUsuarioCreacion    
			 from @Resultado3 r    
			 inner join alumnocurso ac with(nolock) on r.IdMatricula = ac.IdMatricula and r.idcurso = ISNULL(AC.IdCursoOriginal,ac.IdCurso) --@2 --@7    
			 inner join Promocion p with(nolock) on ac.IdPromocion = p.IdPromocion    
			 inner join CurriculaCurso cc with(nolock) on R.IdCurricula= cc.IdCurricula and R.IdCurso = cc.IdCurso    
			 where r.idproducto = @IdProducto    
				   and r.idsede = @IdSede    
				   and r.idmodulo = @IdModulo  
				   and r.IdGrupo = @IdGrupo    
				   and r.turno = @Turno   
				   and r.IdCurricula = @Idcurricula	--@16   
				   --fin @6           
		END -->40           
    
	   -- eliminamos el registro procesado                    
	   DELETE N FROM @Resultado4 N    
	   WHERE N.Id = (SELECT TOP 1 Id    
		   FROM @Resultado4    
		   ORDER BY Id)                 
         
	  END -- en while      
 
  END
  --@10
  ----procesar la data json con los parametros de entrada de este sp con el sp nuevo de procesado ded json
  --Inicio @15

  select @pIdPeriodo,
		@pIdEmpresa ,
		@pIdSede  ,
		@pIdUnidadAcademica ,
		@pIdUnidadNegocio ,
		@pIdProducto ,
		@pUsuarioCreacion 


  EXEC [cProcesa_Nomina_JSON_Minedu]
		@IdPeriodo = @pIdPeriodo,
		@IdEmpresa = @pIdEmpresa,
		@IdSedeNomina = @pIdSede ,
		@IdUnidadAcademicaNomina = @pIdUnidadAcademica,
		@IdUnidadNegocioNomina = @pIdUnidadNegocio,
		@IdProductoNomina = @pIdProducto,
		@IdUsuario = @pUsuarioCreacion
  --Fin @15
  SELECT @pError = 1    
  --RETURN @pError    
  set nocount off    
END    