exec cRptMatriculaAlumnosXSeccionNomina @IdUnidadNegocio=1,@IdUnidadAcademica=60,@IdSede=40,@CodigoPeriodo=N'2025-IIA',@IdProducto=11352

select
	'Sede' = s.Nombre,
	'SedeMinedu' = s.SedeNombreMinedu,--@1
	'Programa'=UA.Nombre,
	'Producto' = pro.ProductoNombreCorto,
	'Periodo'=pe.Codigo,--@2
	--'Semestre' = mtr2.Nombre,
	'Semestre' = mtr2.Codigo,	--@1
	c.NombrePlanEstudio,		--@1
	'MallaCurricular'=c.Codigo,--@1
	'Turno' = acn.Turno,
	'SeccionNomina' = acn.SeccionNomina,
	'CantidadMatriculados' = count(distinct acn.idmatricula),
	acn.idmatricula
	from Matricula m WITH (NOLOCK)
	inner join Promocion p WITH (NOLOCK)  ON m.IdPromocion = p.IdPromocion
	inner join Periodo pe  WITH (NOLOCK) ON p.IdPeriodo = pe.IdPeriodo
	inner join Sede s WITH (NOLOCK) ON m.IdSede = s.IdSede
	inner join Producto pro WITH (NOLOCK) ON p.IdProducto = pro.IdProducto
	inner join AlumnoCurso ac WITH (NOLOCK) ON m.IdMatricula = ac.IdMatricula
	inner join AlumnoCursoNomina acn WITH (NOLOCK) ON ac.IdMatricula = acn.IdMatricula and isnull(ac.IdCursoOriginal,ac.IdCurso) = acn.IdCurso
	--and ac.IdCurso = acn.IdCurso
	inner join CurriculaModulo cc WITH (NOLOCK) ON acn.IdCurricula = cc.IdCurricula and acn.IdModulo = cc.IdModulo
	inner join Curricula c WITH (NOLOCK) ON ACN.IDCURRICULA = C.IDCURRICULA
	inner join MaestroTablaRegistro mtr2 WITH (NOLOCK) ON cc.IdTipoModulo = mtr2.IdMaestroRegistro
	inner join MaestroTablaRegistro prod WITH (NOLOCK) ON pro.IdClasificacionProducto = prod.IdMaestroRegistro
	inner join UnidadAcademica UA WITH (NOLOCK) ON UA.IdUnidadAcademica=P.IdUnidadAcademica
	where pe.codigo = '2025-IIA'
	and pe.idunidadnegocio = 1
	And (pe.idunidadacademica = 60 or 60 = -1)
	and (p.idsede = 40 or 40 = -1)
	AND (PRO.IdProducto = 11352 OR 11352 = -1)
	and m.EsMatricula = 1
	and prod.Disponible1 = 'C'
	and prod.Disponible2 = 'CAR'
	AND acn.SeccionNomina='0209.74.I.02.2025-IIA-I-B'
	group by s.Nombre,s.SedeNombreMinedu, pro.ProductoNombreCorto,UA.nombre,mtr2.Codigo, --mtr2.Nombre, 
			 acn.Turno, acn.SeccionNomina,
			 C.NombrePlanEstudio, C.Codigo,pe.Codigo,acn.idmatricula--@2
	order by 1,2,3