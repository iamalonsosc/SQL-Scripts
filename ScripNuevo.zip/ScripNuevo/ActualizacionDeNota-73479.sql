--SELECT*fROM AlumnoCurriculaCurso
update AlumnoCurriculaCurso set PromedioFinal='13.60',PromedioReal='13.60',PromedioCondicion='A'
WHERE IdAlumno=1502040 and IdModulo=2 AND IdCurso=10309
--ORDER BY IdRegistro,IdModulo