Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--����������������������������������������������������������������������������                                                                    
--Creado por      :Carlos Huallpa(14/05/2009)                                      
--Funcionalidad   :Lista y realiza la busquedad por un criterio                                                                    
--Utilizado por   :Actor.BusBuscarLis                                                                    
--����������������������������������������������������������������������������            
/*    
-----------------------------------------------------------------------------    
Nro  FECHA  USUARIO  DESCRIPCION    
-----------------------------------------------------------------------------    
@1  29.09.2011 ilopeza  se carga el campo codigo de la tabla Alumno y no de Actor    
@2  22.11.2011 ilopeza  se carga el ruc   
@3  13.01.2012 rgalvez  se carga la fechaCreacion,UsuarioResponsable a la consulta.  
@4  25.07.2013 etorres  se agregaron dos columnas  Email y Telefono.
@5	2018.09.19	jmota	se agrega campo IdDocumentoTipo
@6	2018.09.21	rvera	se setea el valor null en el campo IdDocumentoTipo cuando el valor es diferente a DNI 
@7  2019.03.13  fiba�ez se agrega los campos IdRegistro , producto
@8  2019.04.12  LeandroOrdo�ez(Sigcomt) Obtener el �ltimo registo del alumno seg�n su producto
@9  2019.06.28  LeandroOrdo�ez(Sigcomt) Solo registros validos.
@10	15.10.2020	EHuillca Se agrega distinct a la consulta.
@11	28.03.2020	JCure se agrego with nolock.
*/                                                         
CREATE PROCEDURE [dbo].[cActor_Bus_Buscar]
@Codigo VARCHAR(20),              
@NombreSoloBusqueda VARCHAR(150),              
@NumeroIdentidad VARCHAR(20),     
@Ruc VARCHAR(20),          
@Tipo CHAR(1),             
@PaginaTamano INT,                                                          
@PaginaNumero INT,
@IdUsuario INT = Null
AS
BEGIN
SET NOCOUNT ON;

		SELECT  DISTINCT --@10
		ISNULL(TEMPO.IdActor, 0) AS IdActor,
		ISNULL(TEMPO.Codigo, '') AS Codigo,
		ISNULL(TEMPO.NombreCompleto, '') AS NombreCompleto,
		'IdDocumentoTipo'=ISNULL(TEMPO.IdDocumentoTipo,31), --@5 --@6
		'TipoDocumentoCodigo'=ISNULL(MTR.Codigo,'RUC'),
		'Producto' =ISNULL(P.ProductoNombre,''),--@7
		'NumeroIdentidad'=ISNULL(CASE WHEN ISNULL(TEMPO.NumeroIdentidad,'')='' THEN TEMPO.Ruc ELSE TEMPO.NumeroIdentidad END,''), --@2  
		'FechaCreacion'= ISNULL(dbo.fecha(TEMPO.FechaCreacion), GETDATE()), --@3                      
		'CounterPropietario' = ISNULL(TEMP.NombreCompleto,''), --@3   
		'Email' = ISNULL(TEMPO.Email,''), --@4  
		'Telefono' = ISNULL(TEMPO.Telefono,''), --@4
		'IdRegistro' =ISNULL( (SELECT MAX(RE.IdRegistro) FROM Registro RE WITH(NOLOCK) WHERE RE.IdActor = R.IdActor AND RE.IdProducto = P.IdProducto AND RE.Estado = 'N'),'')--@8 --@9--@11
		FROM (	SELECT
				A.IdActor,              
				''Codigo,                                                                            
				A.NombreCompleto,                          
				A.IdDocumentoTipo,                  
				A.NumeroIdentidad,             
				A.Ruc,  
				A.FechaCreacion,
				'Email' = dbo.cActorEmailStr(A.IdActor),
				'Telefono' = dbo.cActorTelefonoStrDilo(A.IdActor,@IdUsuario),
				ROW_NUMBER() OVER (ORDER BY NombreSoloBusqueda) AS NumeroFila                            
				FROM Actor A WITH(NOLOCK)
				WHERE A.NombreSoloBusqueda LIKE ISNULL(@NombreSoloBusqueda,'')+'%'                      
				--AND A.Codigo LIKE ISNULL(@Codigo,'')+'%'          
				AND ISNULL(A.NumeroIdentidad,'') LIKE ISNULL(@NumeroIdentidad,'')+'%'         
				AND ISNULL(A.Ruc,'') LIKE ISNULL(@Ruc,'')+'%' 
				--Tipo 'J' --> Persona Jur�dica        
				AND (A.Tipo in( @Tipo,'J') OR @Tipo = 'T' OR @Tipo = 'P')          
		)AS TEMPO                          
		LEFT JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON TEMPO.IdDocumentoTipo=MTR.IdMaestroRegistro
		LEFT JOIN Contacto CT WITH(NOLOCK) ON TEMPO.IdActor=CT.IdContacto
		LEFT JOIN Usuario US WITH(NOLOCK) ON CT.IdCounter=US.IdUsuario    
		LEFT JOIN Actor TEMP WITH(NOLOCK) ON TEMP.IdActor=US.IdActor 
		LEFT JOIN Registro R WITH(NOLOCK) ON r.IdActor=tempo.IdActor and R.estado='N' --@7
		LEFT JOIN PRODUCTO P WITH(NOLOCK) ON R.IdProducto=P.IdProducto --@7
		WHERE NumeroFila BETWEEN (@PaginaTamano * @PaginaNumero) + 1                                 
		AND @PaginaTamano * (@PaginaNumero + 1)

SET NOCOUNT OFF;
END


Hora de finalizaci�n: 2026-01-15T17:21:42.0420811-05:00
