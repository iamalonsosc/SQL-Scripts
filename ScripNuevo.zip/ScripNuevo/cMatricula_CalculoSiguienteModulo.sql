--����������������������������������������������������������������������������                                              
--Creado por      : Pedro Barreto (Sigcomt) 14/02/2019                              
--Funcionalidad   : Calcula el M�dulo(ciclo) y el TipoCondici�n siguiente del alumno, utilizado por la carga habil.                 
--����������������������������������������������������������������������������                    
/*                  
-----------------------------------------------------------------------------                  
Nro		FECHA			USUARIO						DESCRIPCION                  
@1		11/03/2019		PedroBarreto(Sigcomt)		Modificaci�n de validaci�n de alumnos con notas desaprobadas y que culminaron todos sus ciclos acad�micos.          
@2		21/03/2019		PedroBarreto(Sigcomt)		Se agreg� una validaci�n para reconocer a alumnos con calificaciones convalidados y calcular correctamente.          
@3		28/03/2019		PedroBarreto(Sigcomt)		Se adapta query de calificaciones convalidados y calculo correctamente en el modulo siguiente.       
@4		01/04/2019		Hmora						Se agrego la validaci�n para convalidaciones en el caso de I semestre    
@5		10/04/2019		Hmora						Se agrego validaci�n para retirados convaliddos en el caso de I semestre  
@6		28/05/2019		LeandroOrdo�ez(Sigcomt)		Se agrego IdRegistro en query  
@7		28/05/2019		LeandroOrdo�ez(Sigcomt)		Mejorar condici�n inicial con cursos convalidados  
@8		28/05/2019		LeandroOrdo�ez(Sigcomt)		Obtener cursos que hayan desaprobado por lo menos una vez y se agrego cursos pendientes que son los retirados  
@9		12/08/2019		Hmora						Se retira validaci�n inicial de alumnos que tienen mas cursos subsanables que la cantidad maxima de cursos por ciclo  
@10		30/09/2019		Hmora						Se agrega validacion en el caso de alumnos con curso a cargo del ultimo semestre  
@11		15/10/2019		Hmora						Se agrega validacion en el caso de Cambio de Carrera con numero de curso convalidados menor al minimo para promover    
@12		25/05/2019		Hmora						Se agrega validacion en el caso de Cambio de Carrera de IES A EEST  
@13		31/07/2019		Hmora						Se corrige logica de convalidaci�n   
@14		14/08/2020		JCure						Se optimizo, se puso count(1) y with(nolock)   
@15		15/08/2020		RSamame						Se agrego un parametro mas en la condicion el =  
@16		19/08/2020		RSamame						Se adecuo el calculo de siguiente modulo para la convalidacion de reingresos  
@17		24/08/2020		Jleo						Se quita validaci�n de cantidad de cursos convalidados  
@18		07/09/2020		Hmora						Se agrega logica para limitar la cantidad de cursos dependiendo del a�o en el que se matriculo  
@19		06/11/2020		RSamame						se agrega validacion para alumnos de malla antigua para obtener el bachiller de escuela  
@20		12/01/2021		Jnavia						se agrega validacion de convalidacion bachiller para nuevas carreras  
@21		17/03/2021		jmota						se bloquea logica de convalidacion solo para zegel, en idat aun no definen logica   
@22		18/03/2021		RSamame						se agrega validacion para tomar los modulos menores de los convalidados  
@23		19/03/2021		RSamame						se revierta la validacion anterior @22 se agrega validacion para tomar los modulos menores de los convalidados  
@24		07/04/2021		RSamame						se agrega validacion para tomar los modulos superiores en bachiller y obtener sus cursos  
@25		11/04/2021		RSamame						Se agrega las validaciones para los traslados externos   
@26		16/06/2021		RSamame						Complemento de la validacion del cambio @20 para bachilleres  
@27		15/08/2021		RSamame						Se agrega validaci�n de los traslados especiales, calcular su siguiente modulo y asignacion de tipo de condicion
@28		23.05.2023		EHuillca					Se unifica retirando las validaciones de IDAT
@29		31.08.2023		MBUENO						Se separa la logica del calculo entre zegel e idat y ca
@30		08.03.2024		JQuenta						Se agrega IdPeriodoTraslado en los Procesos de Traslados para que pueda generar Correctamente el Modulo y los Cursos que llevara el Alumno
													Se comento validacion por Empresa para que no siga generando un Bucle Infinito cuando viene por Traslado de Otras Instituciones, Traslado de Programa u otras casuisticas
@31		15.03.2024		Mquirfoz					Se agrega validacion para ITS
-----------------------------------------------------------------------------             
*/
--CREATE PROCEDURE [dbo].[cMatricula_CalculoSiguienteModulo]          
DECLARE
@pIdAlumno INT, --Id del Alumno.          
@pIdRegistro INT,          
@pIdCurricula INT, -- Curricula.          
@pIdMatricula INT, -- Matricula anterior.          
@pTipoCurricula INT,          
@pIdModuloDestino INT , -- Salida.              
@pTipoCondicion VARCHAR(2) -- Salida.            
--AS 
--DECLARE @pIdAlumno        INT=1303704,--Id del Alumno.          
--        @pIdRegistro      INT=6,
--        @pIdCurricula     INT=5605,-- Curricula.          
--        @pIdMatricula     INT=0,-- Matricula anterior.          
--        @pTipoCurricula   INT=0,
--        @pIdModuloDestino INT,-- OUT, -- Salida.              
--        @pTipoCondicion   VARCHAR(2)-- OUT -- Salida.         
      
BEGIN

SELECT @pIdAlumno =1320774, --Id del Alumno.          
@pIdRegistro =7 ,          
@pIdCurricula =5815, -- Curricula.          
@pIdMatricula =0, -- Matricula anterior.          
@pTipoCurricula =0
    DECLARE @ModuloMaximo                 INT, -- Modulo maximo donde el alumno tiene registrado una calificacion aprobada.          
            @ModuloCont                   INT = 1,-- Modulo de inicio.          
            @ModuloMaximoPermitido        INT, -- El el modulo maximo que tiene dicha curricula.          
            @CantCursosMinPromover        INT, -- Cantidad m�nima permitida para promover a un alumno.          
            @CantCursosAprobados          INT, -- Cantidad de cursos aprobados que tiene el alumno en el modulo actual.          
            @CantCursosDesaHistorico      INT=0, -- Cantidad de cursos desaprobados que tiene el alumno en su historial.          
            @CantCursosDesaModulo         INT, -- Cantidad de cursos desaprobados en el modulo actual.          
            @CantCursosMinAprobados       INT, -- Cantidad de cursos minimos permitos para promover a un alumno.     
            @CantMaximaCursosModulo       INT, -- Cantidad de cursos que tiene segun el modulo.          
            @EstadoMat                    VARCHAR(1),
            @pCantCursoConva              INT, --Cantidad de cursos convalidados          
            @pCantCursosXconva            INT, --cantidad de cursos por convalidar              
            @TipoCondicion                VARCHAR(10),
            @pConvalidado                 INT,
            @IdProducto                   INT, --@18 Se Obtiene el producto de la curricula  
            @AnioCursado                  INT, --@18 A�o donde curso el 1 semestre de manera regular.  
            @IdModuloInicio               INT, --@18 Modulo de Inicio para el alumno  
            @AplicaRepitencia             BIT = 1, --@18 Flag para validar repitencia  
            @CompaniaSocio                CHAR(10),--@18 Compa�ia  
            @pCantCursoConvaIDAT          INT = 0, --@18 Verificamos si es el primera vez que tiene un semestre con solo 1 curso convalidado  
            @EsConsecutivo                BIT =0, --@18 Verificamos si es consecutivo  
            @CantCursosPorModuloConvalida INT, --Suma de Cursos convalidados y subsanados que llevara el alumno por modulo          
            @CantCursosPendientes         INT,--@10 --@27  
            @CantCursosAproHistorico      INT, -- Cantidad de cursos aprobados que tiene el alumno en su historial.   
            @pCantCursoRegu               INT, -- Cantidad de cursos con notas aprobadas en el modulo  
            @pCantCursosPenXMod           INT =0, --cantidad de cursos Pendientes por modulo  
            @ModuloIni                    INT=1,--Modulo Inicial  
            @CantiCursoAproMod            INT=0,
            @pCantCursosAcumXMod          INT=0,
			@IdPeriodoTraslado			  INT=0 --@30

    --@27  
    -- Se obtiene el m�dulo m�ximo donde el alumno haya obtenido una nota (A/D).          
    -- Se determina que la nota aprobada no sea parte de un curso de convalidaci�n y/o adelanto.  
	
	SELECT @pIdRegistro,@pIdCurricula,@pIdAlumno, 'DETALLES '
    SELECT @ModuloMaximo = Max(idmodulo)
    FROM   alumnocurriculacurso WITH(nolock)
    WHERE  promediocondicion IS NOT NULL
           AND Isnull(escursoadelanto, 0) <> 1 -- 1 es curso adelanto.   
           AND idregistro = @pIdRegistro --@6       
           AND idcurricula = @pIdCurricula
           AND idalumno = @pIdAlumno
	SELECT @ModuloMaximo,'@ModuloMaximo'
    --@18 Inicio   
    --Obtenemos la compa�ia  
    SELECT @CompaniaSocio = companiasocio
    FROM   empresa
    WHERE  idempresa = 1

    SELECT @IdProducto = idproducto
    FROM   curricula
    WHERE  idcurricula = @pIdCurricula

    --Se obtiene el a�o donde curso el 1 semestre de manera regular.  
    SELECT @AnioCursado = Isnull(Min(pe.idperiodoanual), 2020),
           @IdModuloInicio = Isnull(Min(pr.idmodulo), 1)
    FROM   matricula M
           INNER JOIN alumnocurricula AC
                   ON AC.idalumno = M.idactor AND AC.idcurricula = M.idcurricula
           INNER JOIN curricula C
                   ON C.idcurricula = AC.idcurricula
           INNER JOIN registro R
                   ON R.idactor = M.idactor AND C.idproducto = R.idproducto
           INNER JOIN promocion PR
                   ON M.idpromocion = PR.idpromocion AND R.idproducto = PR.idproducto
           INNER JOIN periodo PE
                   ON PR.idperiodo = PE.idperiodo
    WHERE
      --ACC.IdRegistro = @pIdRegistro --@6           
      C.idproducto = @IdProducto
      AND M.idactor = @pIdAlumno
      AND M.estado <> 'X'

    --@18 Inicio   
    -- Si el alumno no cuenta con ningun curso aprobado se determina que tiene el modulo 1 y/o se interpreta que es un Reingresante de primer ciclo.          
    IF @ModuloMaximo IS NULL
      BEGIN
          SET @pIdModuloDestino = 1
          SET @pTipoCondicion = 'RE'
		  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 1'
          RETURN
      END

    -- Inicio, Cantidad de cursos aprobados m�nimo permitidos para que el alumno pueda ser promovido, segun el tipo de curricula.          
    IF @pTipoCurricula = 0
      BEGIN
          SELECT @CantCursosMinPromover = Cast(valor AS INT)
          FROM   parametrounidadacademica WITH (nolock)
          WHERE  nombre = 'CargaHabil'
                 AND activo = 0
      END
    ELSE
      BEGIN
          SELECT @CantCursosMinPromover = Cast(valor AS INT)
          FROM   parametrounidadacademica WITH (nolock)
          WHERE  nombre = 'CargaHabil'
                 AND activo = 1
      END

    -- Fin.    
    -- Se obtiene el modulo m�ximo permitido por la curricula.          
    SELECT @ModuloMaximoPermitido = idmodulo
    FROM   curriculamodulo WITH(nolock)
    WHERE  idcurricula = @pIdCurricula

    -- Se obtiene la cantidad de cursos que tiene el actual modulo.          
    SELECT @CantMaximaCursosModulo = Count(idcurso)
    FROM   alumnocurriculacurso WITH(nolock)
    WHERE  idalumno = @pIdAlumno
           AND idcurricula = @pIdCurricula
           AND idregistro = @pIdRegistro
           AND idmodulo = @ModuloMaximo

		   SELECT @CantMaximaCursosModulo,'@CantMaximaCursosModulo'

    -- Se Determina la cantidad minima de aprobados para el alumno en el modulo actual.          
    SET @CantCursosMinAprobados = @CantMaximaCursosModulo - @CantCursosMinPromover

    --@2 Inicio, Obtiene el numero de cursos que se tiene que convalidar          
    SELECT @pCantCursosXconva = Count(idcurso)
    FROM   alumnocurriculacurso WITH (nolock)
    WHERE  idalumno = @pIdAlumno
           AND idregistro = @pIdRegistro --@6  
           AND idcurricula = @pIdCurricula
           AND idmodulo <= @ModuloMaximo
           AND tipocondicion = 'RE'
           AND Isnull(promediocondicion, 'D') = 'D'

    -- Se verifica que al menos tenga 1 curso convalidado          
    SELECT @pCantCursoConva = Count(idcurso)
    FROM   alumnocurriculacurso WITH (nolock)
    WHERE  idalumno = @pIdAlumno
           AND idcurricula = @pIdCurricula
           AND idregistro = @pIdRegistro --@6  
           AND idmodulo = @ModuloMaximo
           AND tipocondicion = 'CO'
           AND promediocondicion = 'A'

    --@27  
    -- Se verifica que al menos tenga 1 curso convalidado   
    DECLARE @pCantCursoConval INT

    SELECT @pCantCursoConval = Count(idcurso)
    FROM   alumnocurriculacurso WITH (nolock)
    WHERE  idalumno = @pIdAlumno
           AND idcurricula = @pIdCurricula
     AND idregistro = @pIdRegistro --@6  
           AND idmodulo <= @ModuloMaximo
           AND tipocondicion = 'CO'
           AND promediocondicion = 'A'

    DECLARE @AlumnoTraslado INT=0
    DECLARE @ConvalidacionEspecial AS TABLE
      (
         idcurriculaorigen  INT,
         idcurriculadestino INT
      )

    INSERT INTO @ConvalidacionEspecial
                (idcurriculaorigen,
                 idcurriculadestino)
    SELECT disponible1,
           disponible2
    FROM   maestrotablaregistro MTR WITH(nolock)
           INNER JOIN maestrotabla MT WITH(nolock)
                   ON MTR.idmaestrotabla = MT.idmaestrotabla
    WHERE  MT.codigo = 'CurriculaConvEspTras'

    IF EXISTS (SELECT 1
               FROM   trasladosede
               WHERE  idalumno = @pIdAlumno
                      AND estado = 1
                      AND idcurriculanueva = @pIdCurricula
                      AND
          observacion = 'MIGRACION MASIVA DEL 2020-II AL 2021-I DE IES A EEST'
                      AND idcurriculaanterior IN (SELECT idcurriculaorigen
                                                  FROM   @ConvalidacionEspecial
                                                  WHERE
                          idcurriculadestino = @pIdCurricula)
                      AND (@CompaniaSocio = '00002500' or @CompaniaSocio = '00002400'))--@31
      BEGIN
          SET @AlumnoTraslado =1
          SET @CantCursosMinAprobados=0
      END

    SELECT @CantiCursoAproMod = Count(idcurso)
    FROM   alumnocurriculacurso WITH(nolock)
    WHERE  idalumno = @pIdAlumno
           AND idcurricula = @pIdCurricula
           AND idregistro = @pIdRegistro
           AND idmodulo = @ModuloIni
           AND promediocondicion = 'A'

    --@27  
    --@18 Inicio  
    IF @AnioCursado < 2020
       AND @ModuloMaximo > 1
      BEGIN
          SET @AplicaRepitencia = 0
      END

    IF @AnioCursado = 2020
       AND @IdModuloInicio <> 1
      BEGIN
          SET @AplicaRepitencia = 0
      END
    --@18 Fin  
    --@20 Inicio  
    DECLARE @Egresado BIT --@26   
    DECLARE @Convalidacion AS TABLE
      (
         idcurriculaorigen  INT,
         idcurriculadestino INT,
         modulo             INT
      )

    INSERT INTO @Convalidacion
                (idcurriculaorigen,
                 idcurriculadestino,
                 modulo)
    SELECT disponible1,
           disponible2,
           disponible3
    FROM   maestrotablaregistro MTR WITH(nolock)
           INNER JOIN maestrotabla MT WITH(nolock)
                   ON MTR.idmaestrotabla = MT.idmaestrotabla
    WHERE  MT.codigo = 'CurriculaConvBach'

    --@26 Inicio  
    IF EXISTS(SELECT 1
              FROM   egresados
              WHERE  idalumno = @pIdAlumno
                     AND idcurricula IN(SELECT idcurriculaorigen
                                        FROM   @Convalidacion
                                        WHERE
                         idcurriculadestino = @pIdCurricula))
      BEGIN
          SET @Egresado=1
      END
    ELSE
      BEGIN
          SET @Egresado=0
      END

	  --Inicio --@30
	  SELECT @IdPeriodoTraslado = PROM.IdPeriodo
	  FROM Matricula MAT WITH (NOLOCK) 
	  INNER JOIN Promocion PROM WITH (NOLOCK) ON MAT.IdPromocion = PROM.IdPromocion
	  WHERE MAT.IdMatricula = @pIdMatricula
	  --Fin --@30

    --@26 Fin   
    --@20 Fin  
    IF @pCantCursoConva > 0 AND @pCantCursosXconva > 0 AND @AlumnoTraslado = 0
      BEGIN
          IF EXISTS(SELECT 1 FROM   trasladosede WHERE  idalumno = @pIdAlumno
                           AND idcurriculaanterior IN(SELECT idcurriculaorigen FROM   @Convalidacion WHERE idcurriculadestino = @pIdCurricula)
                           AND idcurriculanueva = @pIdCurricula
						   AND IdPeriodoTraslado = @IdPeriodoTraslado) --@30
             AND @Egresado = 1 AND (@CompaniaSocio = '00002500' or @CompaniaSocio = '00002400') --@20-- @26   --@28 --@31
            BEGIN
                SET @pIdModuloDestino = (SELECT modulo
                                         FROM   @Convalidacion
                                         WHERE
                idcurriculadestino = @pIdCurricula)
                SET @pTipoCondicion = 'CC'
				SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 2'
                RETURN
            END
          ELSE
			BEGIN
				PRINT 'Logica Convalidacion' 
				SELECT @ModuloMaximo
                WHILE @pCantCursosXconva > @CantCursosMinAprobados AND @ModuloMaximo > 1 AND ( @pCantCursosXconva > @CantMaximaCursosModulo ) --@4  --@12 --@13 --@16 --@17  
                  BEGIN
                      -- @3 Obtiene el numero de cursos que se tiene que convalidar    
                      --@19 Inicio 
                      IF @ModuloMaximo = @ModuloMaximoPermitido AND @pCantCursoConva >= @CantCursosMinAprobados AND @pCantCursosxConva <= @CantMaximaCursosModulo + 2 --@23 --@24 --@25  
                        BEGIN	
						
                            SELECT @pCantCursosXconva = Count(idcurso)
                            FROM   alumnocurriculacurso WITH (nolock)
                            WHERE  idalumno = @pIdAlumno
                                   AND idregistro = @pIdRegistro --@6     
                                   AND idcurricula = @pIdCurricula
                                   AND idmodulo = @ModuloMaximo--@22    
                                   AND tipocondicion = 'RE'
                                   AND Isnull(promediocondicion, 'D') = 'D'
                        END
                      ELSE
                        BEGIN
						
                            SELECT @pCantCursosXconva = Count(idcurso)
                            FROM   alumnocurriculacurso WITH (nolock)
                            WHERE  idalumno = @pIdAlumno
                                   AND idregistro = @pIdRegistro --@6     
                                   AND idcurricula = @pIdCurricula
                                   AND idmodulo <= @ModuloMaximo
                                   AND tipocondicion = 'RE'
                                   AND Isnull(promediocondicion, 'D') = 'D'
                        END

                      --@19 Fin  
                      -- @3 Se verifica que al menos tenga 1 curso convalidado          
                      SELECT @pCantCursoConva = Count(idcurso)
                      FROM   alumnocurriculacurso WITH (nolock)
                      WHERE  idalumno = @pIdAlumno
                             AND idregistro = @pIdRegistro --@6         
                             AND idcurricula = @pIdCurricula
                             AND idmodulo = @ModuloMaximo
                             AND tipocondicion = 'CO'
                             AND promediocondicion = 'A'

                      --IF @pCantCursoConva > 0 AND @pCantCursosXconva > 0  and @pCantCursosXconva >= @CantCursosMinAprobados and @pCantCursoConva < @CantCursosMinAprobados    --@5 --@11       
                      IF @pCantCursosXconva > 0
                         AND @pCantCursosXconva >= @CantMaximaCursosModulo
                         AND ( ( @pCantCursoConva <= @CantCursosMinAprobados )
                                OR ( @pCantCursoConva > @CantCursosMinAprobados
                                     --AND ( (@CompaniaSocio = '00002500' AND @ModuloMaximo = @ModuloMaximoPermitido) OR (@CompaniaSocio != '00002500') ) --@29 --@30
                                   ) )
         --@5 --@11 --@12 --@13 --@15 --@25  
                        BEGIN
                            --select    @pCantCursosXconva as 'CursosXconva',@ModuloMaximo as 'Modulo',@pCantCursoConva as 'CursoConva' ,@CantCursosMinAprobados  as 'CursosMinimoPormodulo',@CantMaximaCursosModulo as 'CursosMaximosCiclo'   
                            SET @ModuloMaximo = @ModuloMaximo - 1
							PRINT 'AS'
                            --print 'entra aqui'    
                            -- Volvemos a calcular el maximo de cursos que tiene el modulo        
                            SELECT @CantMaximaCursosModulo = Count(idcurso)
                            FROM   alumnocurriculacurso WITH(nolock)
                            WHERE  idalumno = @pIdAlumno
                                   AND idcurricula = @pIdCurricula
                                   AND idregistro = @pIdRegistro
                                   AND idmodulo = @ModuloMaximo
        END
                  END
            END
      END
    --@27  
    ELSE
      BEGIN          
          IF @AlumnoTraslado = 1
            BEGIN
				PRINT '@AlumnoTraslado'
                WHILE @ModuloIni <= @ModuloMaximoPermitido
                      AND @pCantCursoConval > 0
                      AND @CantCursosDesaHistorico <= @CantCursosMinPromover
                      AND ( @CantiCursoAproMod + @pCantCursosAcumXMod >=
                            @CantCursosMinAprobados
                            AND @pCantCursosAcumXMod <= @CantCursosMinAprobados
                          )
                  BEGIN
                      SELECT @pCantCursosAcumXMod = Count(idcurso)
                      FROM   alumnocurriculacurso WITH (nolock)
                      WHERE  idalumno = @pIdAlumno
                             AND idregistro = @pIdRegistro --@6  
                             AND idcurricula = @pIdCurricula
                             AND idmodulo = @ModuloIni
                             AND tipocondicion = 'RE'
                             AND promediocondicion IS NULL
                             AND subsanacion = 1

                      SELECT @CantCursosDesaHistorico = Count(idcurso)
                      FROM   alumnocurriculacurso WITH(nolock) --@14  
                      WHERE  idalumno = @pIdAlumno
                             AND idregistro = @pIdRegistro
                             AND idmodulo <= @ModuloIni
                             AND idcurricula = @pIdCurricula
                             --AND ISNULL(PromedioCondicion, 'D') = 'D'      
                             AND promediocondicion = 'D'

                      SELECT @CantMaximaCursosModulo = Count(idcurso)
                      FROM   alumnocurriculacurso WITH(nolock)
                      WHERE  idalumno = @pIdAlumno
                             AND idcurricula = @pIdCurricula
                             AND idregistro = @pIdRegistro
                             AND idmodulo = @ModuloIni

                      SELECT @CantiCursoAproMod = Count(idcurso)
                      FROM   alumnocurriculacurso WITH(nolock)
                      WHERE  idalumno = @pIdAlumno
                             AND idcurricula = @pIdCurricula
                             AND idregistro = @pIdRegistro
                             AND idmodulo = @ModuloIni
                             AND promediocondicion = 'A'

                      SET @ModuloMaximo = @ModuloIni

                      SELECT @CantCursosMinAprobados =
                             @CantMaximaCursosModulo - @CantCursosMinPromover

                      SET @pCantCursosPenXMod=
                      @pCantCursosPenXMod + @pCantCursosAcumXMod
                      SET @ModuloIni=@ModuloIni + 1
                  END
                IF @ModuloIni > @ModuloMaximoPermitido
                    OR @CantiCursoAproMod > @CantCursosMinAprobados
                  BEGIN
                      SET @ModuloMaximo=@ModuloIni - 1
                  END
            END
      END

    --@2 Fin  
    --@27   
    IF @AlumnoTraslado = 1
      BEGIN
          PRINT 'LOGICA NUEVA'
          -- Cantidad de cursos desaprobados que tiene el alumno en el modulo actual.          
          SELECT @CantCursosDesaModulo = Count(1)--@14 --COUNT(*)          
          FROM   alumnocurriculacurso WITH(nolock)
          WHERE  idalumno = @pIdAlumno
                 AND idregistro = @pIdRegistro
                 AND idmodulo = @ModuloMaximo
                 AND idcurricula = @pIdCurricula
                 AND promediocondicion = 'D'
                 AND dbo.Calumnocurso_pro_numerovez(@pIdAlumno, @pIdRegistro,
                     @pIdCurricula, idcurso)
                     > 1 --@10   

          ---- Cantidad de cursos desaprobados HISTORICOS que tiene el alumno .   
          SELECT @CantCursosDesaHistorico = Count(idcurso)
          FROM   alumnocurriculacurso WITH(nolock) --@14  
          WHERE  idalumno = @pIdAlumno
                 AND idregistro = @pIdRegistro
                 AND idmodulo <= @ModuloMaximo
                 AND idcurricula = @pIdCurricula
                 --AND ISNULL(PromedioCondicion, 'D') = 'D'      
                 AND promediocondicion = 'D'
                 AND dbo.Calumnocurso_pro_numerovez(@pIdAlumno, @pIdRegistro,
                     @pIdCurricula, idcurso)
                     > 1--@10    

          --Cantidad de cursos Pendientes hasta el modulo   
          SELECT @pConvalidado = Count(1)--@14  --COUNT(*)          
          FROM   alumnocurriculacurso WITH(nolock)
          WHERE  idalumno = @pIdAlumno
                 AND idregistro = @pIdRegistro
                 AND idmodulo <= @ModuloMaximo
                 AND idcurricula = @pIdCurricula
                 AND subsanacion = 1
                 AND promediocondicion IS NULL

          IF @CantCursosDesaModulo > @CantCursosMinPromover
            BEGIN
                SET @pIdModuloDestino = @ModuloMaximo
                SET @pTipoCondicion = 'RT'
				SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 3'
                RETURN
            END

          IF ( @CantCursosDesaHistorico > @CantCursosMinPromover )
              OR ( @CantCursosDesaHistorico > @CantCursosMinPromover
                   AND @ModuloMaximo = @ModuloMaximoPermitido )
            BEGIN
                SET @pIdModuloDestino = @ModuloMaximo
                SET @pTipoCondicion = 'CC'
				SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 4'
                RETURN
            END

          IF ( @CantCursosDesaHistorico = 0
               AND @pConvalidado > 0 )
              OR ( @CantCursosDesaHistorico <= @CantCursosMinPromover )
            BEGIN
                SET @pIdModuloDestino = @ModuloMaximo
                SET @pTipoCondicion = 'RP'
				SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 5'
                RETURN
            END

          IF @CantCursosDesaHistorico = 0
             AND @pConvalidado = 0
            BEGIN
                SET @pIdModuloDestino = @ModuloMaximo
                SET @pTipoCondicion = 'RE'
				SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 6'
                RETURN
            END
      END
    --@27    
    -- Bucle que recorre desde el modulo m�ximo donde el alumno tenga una nota aprobatoria.          
    WHILE @ModuloCont <= @ModuloMaximo
      BEGIN
          -- Inicio, Se crea una tabla temporal para insertar los cursos obtenidos seg�n el nivel del alumno.          
          CREATE TABLE #tempcursos
            (
               idtempcursos      INT IDENTITY,
               idmodulo          INT,
               promediocondicion VARCHAR(1),
               idcurso           INT,
               escursoadelanto   BIT
            )

          INSERT INTO #tempcursos
                      (idmodulo,
                       promediocondicion,
                       idcurso,
                       escursoadelanto)
          SELECT idmodulo,
                 promediocondicion,
                 idcurso,
                 escursoadelanto
          FROM   alumnocurriculacurso WITH(nolock)
          WHERE  idalumno = @pIdAlumno
                 AND idregistro = @pIdRegistro --@6  
                 AND idcurricula = @pIdCurricula
                 AND idmodulo <= @ModuloMaximo
                 AND Isnull(escursoadelanto, 0) <> 1
          ORDER  BY idmodulo

          -- Fin.          
          -- Cantidad de cursos aprobados que tiene el alumno en el modulo actual.          
          SELECT @CantCursosAprobados = Count(1)--@14 --COUNT(*)          
          FROM   #tempcursos WITH(nolock)
          WHERE  idmodulo = @ModuloMaximo
                 AND Isnull(promediocondicion, 'D') = 'A'

          -- Cantidad de cursos desaprobados que tiene el alumno en el modulo actual.          
          SELECT @CantCursosDesaModulo = Count(1)--@14 --COUNT(*)          
          FROM   alumnocurriculacurso WITH(nolock)
          WHERE  idalumno = @pIdAlumno
            AND idregistro = @pIdRegistro
                 AND idmodulo = @ModuloMaximo
                 AND idcurricula = @pIdCurricula
                 AND Isnull(promediocondicion, 'D') = 'D'
                 AND dbo.Calumnocurso_pro_numerovez(@pIdAlumno, @pIdRegistro,
                     @pIdCurricula, idcurso)
                     > 1 --@10   
          -- Se obtiene la cantidad de cursos pendientes en su historial de notas hasta el momento, dependiendo si el historial pertenece a un alumno regular o a un alumno convalidado.          
          SELECT @pConvalidado = Count(1)--@14  --COUNT(*)          
          FROM   alumnocurriculacurso WITH(nolock)
          WHERE  idalumno = @pIdAlumno
                 AND idregistro = @pIdRegistro
                 AND idmodulo <= @ModuloMaximo
                 AND idcurricula = @pIdCurricula
                 AND subsanacion = 1
                 AND promediocondicion IS NULL

          SELECT @CantCursosDesaHistorico = Count(idcurso)
          FROM   alumnocurriculacurso WITH(nolock) --@14  
          WHERE  idalumno = @pIdAlumno
                 AND idregistro = @pIdRegistro
                 AND idmodulo <= @ModuloMaximo
                 AND idcurricula = @pIdCurricula
                 AND Isnull(promediocondicion, 'D') = 'D'
                 AND dbo.Calumnocurso_pro_numerovez(@pIdAlumno, @pIdRegistro,
                     @pIdCurricula, idcurso)
                     > 1--@10    
          --Inicio @9  
		  
          SELECT @CantCursosPendientes = Count(idcurso)
          FROM   alumnocurriculacurso WITH(nolock) --@14  
          WHERE  idalumno = @pIdAlumno
                 AND idregistro = @pIdRegistro
                 AND idmodulo <= @ModuloMaximo
                 AND idcurricula = @pIdCurricula
                 AND promediocondicion IS NULL
                 --AND subsanacion IS NULL
                 --AND dbo.Calumnocurso_pro_numerovez(@pIdAlumno, @pIdRegistro,
                 --    @pIdCurricula, idcurso)
                 --    <= 1
select @CantCursosPendientes,'@CantCursosPendientes'
          --Fin @9  
          --select @pConvalidado,@CantCursosDesaHistorico  
          --Inicio @7  
		  SELECT @pConvalidado,@CantMaximaCursosModulo,'@pConvalidado,@CantMaximaCursosModulo'
          IF @pConvalidado > 0 AND @CantCursosDesaHistorico = 0 --@7--@9  
            BEGIN
                IF( @pConvalidado = @CantMaximaCursosModulo) --@28
                  BEGIN
                      SET @pIdModuloDestino = @ModuloMaximo
                      SET @pTipoCondicion = 'RE'
					  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 7'
                      DROP TABLE #tempcursos
                      RETURN
                  END
                ELSE
                  BEGIN
				  SELECT @pConvalidado,@CantCursosMinPromover,@ModuloMaximoPermitido,'CONDICION'
                      IF( @pConvalidado <= @CantCursosMinPromover
                          AND ( @ModuloMaximo + 1 ) <= @ModuloMaximoPermitido )
                        BEGIN
                            SET @pIdModuloDestino = @ModuloMaximo + 1
                            SET @pTipoCondicion = 'RP'
							SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 8'
                            DROP TABLE #tempcursos
							RETURN
                        END
					  
				
                      SET @pIdModuloDestino = @ModuloMaximo
                      SET @pTipoCondicion = 'CC'
					  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 9'
                      DROP TABLE #tempcursos
                      RETURN
                  END
            END
          --Fin @7        
          ELSE
            BEGIN
			SELECT @CantCursosMinPromover,@CantCursosDesaModulo,'@CantCursosMinPromover,@CantCursosDesaModulo'
                -- Repitencia total, el alumno tiene de 3 a mas cursos desaprobados en el mismo semestre.          
                IF @CantCursosDesaModulo > @CantCursosMinPromover
                  BEGIN
                      SET @pIdModuloDestino = @ModuloMaximo
                      SET @pTipoCondicion = 'RT'
					  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 10'
                      DROP TABLE #tempcursos
                      RETURN
                  END

				  SELECT @CantCursosDesaHistorico,@CantCursosMinPromover,'@CantCursosDesaHistorico,@CantCursosMinPromover'
             -- Si el alumno excede el m�nimo permito de cursos desaprobado es un alumno con Curso a Cargo y no puede avanzar.          
                IF @CantCursosDesaHistorico > @CantCursosMinPromover --@28
                  BEGIN
                      SET @pIdModuloDestino = @ModuloMaximo
                      SET @pTipoCondicion = 'CC'
					  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 11'
                      DROP TABLE #tempcursos
                      RETURN
                  END

                -- Alumno con cursos pendientes que son menores al modulo m�ximo permitido de la carrera
				SELECT @CantCursosPendientes,@CantMaximaCursosModulo,@pConvalidado,'@CantCursosPendientes,@CantMaximaCursosModulo,@pConvalidado'
                IF @CantCursosPendientes = @CantMaximaCursosModulo
                   AND @pConvalidado = 0
                  BEGIN
                      SET @pIdModuloDestino = @ModuloMaximo
                      SET @pTipoCondicion = 'RE'
					  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 12'
                      DROP TABLE #tempcursos
                      RETURN
                  END

				SELECT @pIdModuloDestino,'ANTES'
                SET @pIdModuloDestino = @ModuloMaximo + 1
				SELECT @pIdModuloDestino,'DESPUES'
                -- Verificamos que el alumno no tenga alg�n curso desaprobado en todo su historial acad�mico y que no sobrepase el l�mite del m�dulo m�ximo permitido por su carrera, entonces es un egresado.          
                SELECT @pIdModuloDestino,@ModuloMaximoPermitido,@CantCursosDesaHistorico,@CantCursosDesaModulo,@CantCursosPendientes,'@pIdModuloDestino,@ModuloMaximoPermitido,@CantCursosDesaHistorico,@CantCursosDesaModulo,@CantCursosPendientes'
				IF @pIdModuloDestino > @ModuloMaximoPermitido
                   AND @CantCursosDesaHistorico = 0
                   AND @CantCursosDesaModulo = 0
                   AND @CantCursosPendientes = 0 --@10       
                  BEGIN
                      SET @pIdModuloDestino = -1
                      SET @pTipoCondicion = ''
					  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 13'
                      DROP TABLE #tempcursos
                      RETURN
                  END

                -- Si el alumno aprueba todos los cursos de su modulo actual y no tiene cursos desaprobados en su historial de notas, es un Promovido Invicto.  
				SELECT @CantCursosAprobados,@CantMaximaCursosModulo,@CantCursosDesaHistorico,'@CantCursosAprobados,@CantMaximaCursosModulo,@CantCursosDesaHistorico'
                IF @CantCursosAprobados = @CantMaximaCursosModulo
                   AND @CantCursosDesaHistorico = 0
                  BEGIN
                      SET @pIdModuloDestino = @pIdModuloDestino
                      SET @pTipoCondicion = 'RE'
					  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 14'
                      DROP TABLE #tempcursos
                      RETURN
                  END

                -- Si el alumno desaprueba hasta 2 cursos en el actual modulo o en su historial es un Repitente Parcial.          
                IF @CantCursosDesaHistorico <= @CantCursosMinPromover
                   AND ( @CantCursosDesaHistorico > 0
                          OR @CantCursosPendientes > 0 ) --@10  
                  BEGIN
                      --@1 Inicio          
                      IF ( @ModuloMaximo + 1 ) > @ModuloMaximoPermitido
                        BEGIN
                            -- Se obtiene el modulo maximo donde el alumno optubo un curso desaprobado.          
                            SELECT @pIdModuloDestino = Max(idmodulo)
                            FROM   alumnocurriculacurso WITH(nolock) --@14  
                            WHERE  idalumno = @pIdAlumno
                                   AND idregistro = @pIdRegistro
                                   --@10            
                                   AND Isnull(promediocondicion, 'D') = 'D'

                            SET @pTipoCondicion = 'CC'
							SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 15'
                            DROP TABLE #tempcursos
                            RETURN
                        END

  --@1 Fin          
                      SET @pIdModuloDestino = @pIdModuloDestino
                      SET @pTipoCondicion = 'RP'
					  SELECT @pIdModuloDestino,@pTipoCondicion,'PASO 16'
                      DROP TABLE #tempcursos
                      RETURN
                  END
            END
      END
END 
