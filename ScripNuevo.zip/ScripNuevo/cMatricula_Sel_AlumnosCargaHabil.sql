--����������������������������������������������������������������������������                                                                                                        
--Creado por      :Luis Perales (14/03/2012)                                                                                                        
--Funcionalidad   :Lista los alumnos de traslado, ingresantes con convalidaciones,     
--       cambio de curricula o producto, reingresos    
--Utilizado por   :cMatricula.SelAlumnosMatriculados                  
--����������������������������������������������������������������������������          
/*        
-----------------------------------------------------------------------------        
Nro		FECHA			USUARIO			DESCRIPCION        
-----------------------------------------------------------------------------        
@1		10.09.2019		Hmora			Se agrega opcion para cambios Escuela  
@2		01/08/2024		RSamame			Se agrega logica para listar solo los registros que no se encuentren anulados
*/

--CREATE PROCEDURE [dbo].[cMatricula_Sel_AlumnosCargaHabil]        
DECLARE
              @IdEmpresa INT,        
              @IdSede INT,        
              @IdPeriodo INT,        
              @ActorCodigo VARCHAR(20),        
              @ActorNombreSoloBusqueda VARCHAR(160),    
              @Tipo VARCHAR(2)    
--AS        

SELECT @IdEmpresa=1,@IdSede=43,@IdPeriodo=258,@ActorCodigo=N'',@ActorNombreSoloBusqueda=N'',@Tipo=N'CI'
BEGIN    
 IF @Tipo = 'CI'  -- convalidacion ingresante    
 BEGIN    
  SELECT PR.IdProducto,pr.ProductoCodigo, pr.ProductoNombre,a.IdActor,    
  'Codigo'=ISNULL(AL.CodigoAnterior,''),A.NombreCompleto     
  FROM Convalidacion C  WITH(NOLOCK)   
  INNER JOIN  Registro R WITH(NOLOCK)    
  ON C.IdAlumno = R.IdActor    
  AND C.IdRegistro = R.IdRegistro    
  INNER JOIN Producto PR  WITH(NOLOCK)   
  ON R.IdProducto = PR.IdProducto    
  INNER JOIN Actor A  WITH(NOLOCK)   
  ON C.IdAlumno = A.IdActor    
  LEFT JOIN Alumno AL   WITH(NOLOCK)   
  ON A.IdActor=AL.IdAlumno       
  WHERE C.IdEmpresa = @IdEmpresa    
  AND C.IdSede = @IdSede    
  AND C.IdPeriodoAnual = @IdPeriodo    
  AND C.Tipo = 'TE' 
  AND R.Estado<>'X'--@2
  AND ISNULL(AL.CodigoAnterior,'') LIKE ISNULL(@ActorCodigo,'')+'%'                
  AND A.NombreSoloBusqueda LIKE ISNULL(@ActorNombreSoloBusqueda,'')+'%'     
  AND NOT EXISTS (SELECT 1    
      FROM Matricula MA  WITH(NOLOCK)   
      WHERE MA.IdEmpresa = @IdEmpresa    
      AND MA.IdSede = @IdSede    
      AND MA.IdActor = C.IdAlumno    
      AND MA.IdRegistro = C.IdRegistro    
      AND MA.EsMatricula = 1    
      AND MA.Estado = 'N'    
      and ma.IdPeriodo = @IdPeriodo);    
 END      
   IF @Tipo = 'TS' -- traslado de sede    
    BEGIN    
  SELECT PR.IdProducto,pr.ProductoCodigo, pr.ProductoNombre,a.IdActor,    
  'Codigo'=ISNULL(AL.CodigoAnterior,''),A.NombreCompleto     
  FROM TrasladoSede TS  WITH(NOLOCK)   
  INNER JOIN  Registro R WITH(NOLOCK)    
  ON TS.IdAlumno = R.IdActor    
  AND TS.IdRegistro = R.IdRegistro    
  INNER JOIN Producto PR  WITH(NOLOCK)   
  ON R.IdProducto = PR.IdProducto    
  INNER JOIN Actor A  WITH(NOLOCK)   
  ON TS.IdAlumno = A.IdActor    
  LEFT JOIN Alumno AL   WITH(NOLOCK)   
  ON A.IdActor=AL.IdAlumno
  INNER JOIN Periodo P WITH(NOLOCK)   --@1
  ON P.IdPeriodo=TS.IdPeriodoAnterior --@1       
  --AND NOT EXISTS (SELECT 1    
  --    FROM Matricula MA  WITH(NOLOCK)   
  --    WHERE MA.IdEmpresa = @IdEmpresa    
  --    AND MA.IdSede = @IdSede    
  --    AND MA.IdActor = TS.IdAlumno    
  --    AND MA.IdRegistro = TS.IdRegistro    
  --    AND MA.EsMatricula = 1    
  --    AND MA.Estado = 'N')    
  WHERE TS.IdEmpresa = @IdEmpresa    
  AND TS.IdSede = @IdSede    
  AND TS.IdPeriodoTraslado = @IdPeriodo        
  AND ISNULL(AL.CodigoAnterior,'') LIKE ISNULL(@ActorCodigo,'')+'%'                
  AND A.NombreSoloBusqueda LIKE ISNULL(@ActorNombreSoloBusqueda,'')+'%'     
  and TS.Estado =1
  AND P.IdUnidadAcademica=TS.IdUnidadAcademica
    END    
        
   IF @Tipo = 'CC'  -- cambio curricula o producto    
    BEGIN     
  SELECT PR.IdProducto,PR.ProductoCodigo, PR.ProductoNombre,    
  'IdActor' = CPC.IdAlumno,'Codigo'=ISNULL(AL.CodigoAnterior,''),A.NombreCompleto     
  FROM CambioProductoCurricula CPC WITH(NOLOCK)    
  INNER JOIN Producto PR  WITH(NOLOCK)   
  ON CPC.IdProductoNueva = PR.IdProducto    
  INNER JOIN Actor A  WITH(NOLOCK)   
  ON CPC.IdAlumno = A.IdActor    
  LEFT JOIN Alumno AL   WITH(NOLOCK)   
  ON A.IdActor=AL.IdAlumno     
  WHERE CPC.IdEmpresa = @IdEmpresa    
  AND CPC.IdSede = @IdSede    
  AND CPC.IdPeriodo = @IdPeriodo     
  AND CPC.Estado = 1       
  AND ISNULL(AL.CodigoAnterior,'') LIKE ISNULL(@ActorCodigo,'')+'%'                
  AND A.NombreSoloBusqueda LIKE ISNULL(@ActorNombreSoloBusqueda,'')+'%'      
    END    
        
   IF @Tipo = 'RI'  -- reingresos    
    BEGIN     
  SELECT PR.IdProducto,PR.ProductoCodigo, PR.ProductoNombre,    
  'IdActor' = RE.IdAlumno,'Codigo'=ISNULL(AL.CodigoAnterior,''),A.NombreCompleto    
  FROM Reingresos RE WITH(NOLOCK)    
  INNER JOIN Producto PR  WITH(NOLOCK)   
  ON RE.IdProductoNueva = PR.IdProducto    
  INNER JOIN Actor A    
  ON RE.IdAlumno = A.IdActor    
  LEFT JOIN Alumno AL     
  ON A.IdActor=AL.IdAlumno      
  WHERE RE.IdEmpresa = @IdEmpresa      
  AND RE.IdSede = @IdSede    
  AND RE.IdPeriodoReingreso = @IdPeriodo      
  AND RE.Estado = 1    
  AND ISNULL(AL.CodigoAnterior,'') LIKE ISNULL(@ActorCodigo,'')+'%'                
  AND A.NombreSoloBusqueda LIKE ISNULL(@ActorNombreSoloBusqueda,'')+'%'      
    END
	
	--@1 
	IF @Tipo = 'TE' -- Escuela 
	 BEGIN    
		SELECT PR.IdProducto,pr.ProductoCodigo, pr.ProductoNombre,a.IdActor,    
		'Codigo'=ISNULL(AL.CodigoAnterior,''),A.NombreCompleto     
		FROM TrasladoSede TS  WITH(NOLOCK)   
		  INNER JOIN  Registro R WITH(NOLOCK)    
		  ON TS.IdAlumno = R.IdActor    
		  AND TS.IdRegistro = R.IdRegistro    
		  INNER JOIN Producto PR  WITH(NOLOCK)   
		  ON R.IdProducto = PR.IdProducto    
		  INNER JOIN Actor A  WITH(NOLOCK)   
		  ON TS.IdAlumno = A.IdActor    
		  LEFT JOIN Alumno AL   WITH(NOLOCK)   
		  ON A.IdActor=AL.IdAlumno
		  INNER JOIN Periodo P WITH(NOLOCK)   --@1
		  ON P.IdPeriodo=TS.IdPeriodoAnterior --@1
		  WHERE TS.IdEmpresa = @IdEmpresa    
		  AND TS.IdSede = @IdSede    
		  AND TS.IdPeriodoTraslado = @IdPeriodo        
		  AND ISNULL(AL.CodigoAnterior,'') LIKE ISNULL(@ActorCodigo,'')+'%'                
		  AND A.NombreSoloBusqueda LIKE ISNULL(@ActorNombreSoloBusqueda,'')+'%'     
		  AND TS.Estado =1
		  AND P.IdUnidadAcademica<>TS.IdUnidadAcademica
			END       
END    
