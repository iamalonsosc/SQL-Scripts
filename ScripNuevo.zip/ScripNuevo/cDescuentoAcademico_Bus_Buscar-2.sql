---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--����������������������������������������������������������������������������
--Creado por      : Jimy Mota(06/06/2017)
--Funcionalidad   : Lista y realiza la busquedad por un criterio descuentoacademico
--Utilizado por   : DescuentoAcademico.BusBuscarLis
--Proyecto		  : Descuento academico 
--����������������������������������������������������������������������������
/*  
 - ----------------------------------------------------------------------------
Nro     FECHA      USUARIO     DESCRIPCION 
 - ----------------------------------------------------------------------------
 @1		2018.07.01	jmota	se agrega columna EsForzado para indicar que puede ser asignado sin validacion 
 @2		2020.07.22	jmota	se agrega columna para transferencia gratuita y activacion despues de vencidos
 @3		2021.05.05	jmota	se agrega columna para cuotas gratuita
 @4		2024.03.22	alsanchez	se agrega condicion para la cantidad de registros en la pagina
 @5		2024.04.05	alsanchez	Se agrega nuevo campo OfertaAlumno
 @6		2024.10.18	alsanchez	Se setea a 0 si viene en -1
 @7		2024.10.18	alsanchez	Se setea su tama�o de pagina
*/ 
ALTER PROCEDURE [dbo].[cDescuentoAcademico_Bus_Buscar]
@IdDescuentoAcademico INT,
@Nombre VARCHAR(200),
@Activo BIT,
@IdTipo INT,
@Disponible1  VARCHAR(200),
@Esvigente BIT,
@PaginaTamano INTEGER,
@PaginaNumero INTEGER
AS
BEGIN

	SET NOCOUNT OFF

	IF @IdDescuentoAcademico IS NULL SET @IdDescuentoAcademico = -1
	IF @IdTipo IS NULL SET @IdTipo = -1
	IF @Disponible1 IS NULL SET @Disponible1=N'[TODOS]'
	IF @PaginaNumero =-1 SET @PaginaTamano=1000-- @7
	IF @PaginaNumero =-1 SET @PaginaNumero = 0 --@6	
	


	SELECT DISTINCT 
	TEMPO.IdDescuentoAcademico,
	TEMPO.Codigo,
	TEMPO.Nombre,
	TEMPO.Porcentaje,
	TEMPO.FechaInicio,
	TEMPO.FechaFin,
	TEMPO.NroPeriodo,
	TEMPO.EsAcumulativo,
	TEMPO.DiasVigentes,
	TEMPO.EsProntoPago,
	TEMPO.EsContado,
	TEMPO.IdTipo,
	TEMPO.TipoNombre, 
	TEMPO.Activo,
	TEMPO.ActivoNombre,
	TEMPO.Disponible1,
	TEMPO.Disponible2,
	TEMPO.Disponible3,
	TEMPO.Disponible4,
	TEMPO.Disponible5,
	TEMPO.CuotaNombre,
	TEMPO.Campana ,
	TEMPO.Area ,
	TEMPO.UnidadAcademicaNombre ,
	TEMPO.FechaFinOrden  ,
	TEMPO.TipoSituacionAlumnoNombre ,
	TEMPO.ExcluirCodigoNombre ,
	TEMPO.ExcluirTodo ,
	TEMPO.ExcluirCuota ,
	TEMPO.UsuarioCreacionFecha ,
	TEMPO.UsuarioModificacionFecha ,
	TEMPO.EsForzado, --@1
	TEMPO.EsSinVencimiento, --@2
	TEMPO.EsTransGratuita, --@2
	TEMPO.EsGratuita, --@2
	TEMPO.OfertaAlumno, --@5
	ROW_NUMBER() OVER (ORDER BY TEMPO.IdDescuentoAcademico DESC) AS NumeroFila --@4	
	FROM ( 
		SELECT 
		DA.IdDescuentoAcademico,
		'Codigo'=ISNULL(DA.Codigo,-1),
		'Nombre'=ISNULL(DA.Nombre,''),
		'Porcentaje' = ISNULL(DA.Porcentaje,0.00),
		'FechaInicio' = dbo.Fecha(DA.FechaInicio),
		'FechaFin' = dbo.Fecha(DA.FechaFin),
		'FechaFinOrden' = DA.FechaFin ,
		'NroPeriodo' = ISNULL(DA.NroPeriodo,0),
		'EsAcumulativo' = ISNULL(DA.EsAcumulativo,0),
		'DiasVigentes' = ISNULL(DiasVigentes,0),
		'EsProntoPago' = ISNULL(DA.EsProntoPago,0),
		'EsContado' = ISNULL(DA.EsContado,0),
		'IdTipo' = ISNULL(DA.IdTipo,-1),
		'TipoNombre'= ISNULL(MTR.Nombre,''), 
		'Activo'= ISNULL(DA.Activo,0),
		'ActivoNombre' = CASE WHEN ISNULL(DA.Activo,0) = 0 THEN 'INACTIVO' ELSE 'ACTIVO' END ,
		'Campana' = ISNULL( DA.Campana , ''),
		'Area' = ISNULL(DA.Area,''),
		'Disponible1' = ISNULL(DA.Disponible1,''),
		'Disponible2' = ISNULL(DA.Disponible2,''),
		'Disponible3' = ISNULL(DA.Disponible3,''),
		'Disponible4' = ISNULL(DA.Disponible4,''),
		'Disponible5' = ISNULL(DA.Disponible5,''),
		'CuotaNombre' = ISNULL ( STUFF((  
					SELECT ' / ' + CASE 
									WHEN DAC.Cuota = 1 THEN 'MATR�CULA'
									WHEN DAC.Cuota = 2 THEN 'PRIMERA CUOTA' 
									WHEN DAC.Cuota = 3 THEN 'SEGUNDA CUOTA' 
									WHEN DAC.Cuota = 4 THEN 'TERCERA CUOTA' 
									WHEN DAC.Cuota = 5 THEN 'CUARTA CUOTA' 
									WHEN DAC.Cuota = 6 THEN 'QUINTA CUOTA' 
									WHEN DAC.Cuota = 7 THEN 'SEXTA CUOTA' 
									WHEN DAC.Cuota = 8 THEN 'SEPTIMA CUOTA' 
									WHEN DAC.Cuota = 9 THEN 'OCTAVA CUOTA'  
									ELSE ''
									END +  
									CASE WHEN CAST(ISNULL(DAC.Codigo,-1) AS INT) > 0 THEN ' ['+ CAST(DAC.Codigo AS VARCHAR)+']' + '['+DAC.Nombre+']' + '['+ CAST(DAC.Porcentaje AS VARCHAR)+']'   
										ELSE ''
									END
					FROM DescuentoAcademicoCuota DAC WITH(NOLOCK)
					WHERE DAC.IdDescuentoAcademico = DA.IdDescuentoAcademico 
					FOR XML PATH('')
					),1,1,'') , '' ) ,
		'UnidadAcademicaNombre' =  ISNULL(  STUFF(( 
		
							SELECT  distinct ' / ' + UA.Nombre FROM DescuentoAcademicoPoblacionDestino DAPD
							INNER JOIN UnidadAcademica UA ON UA.IdUnidadAcademica = DAPD.IdUnidadAcademica
							WHERE IdDescuentoAcademico = DA.IdDescuentoAcademico  
							FOR XML PATH('') 
							),1,1,'') , '[TODOS]'),

		'TipoSituacionAlumnoNombre' =  ISNULL(  STUFF(( 
		
							SELECT  distinct ' ' + MTRT.Nombre FROM DescuentoAcademicoPoblacion DAP
							INNER JOIN MaestroTablaRegistro MTRT WITH(NOLOCK) ON MTRT.IdMaestroTabla = 1905 AND  MTRT.IdMaestroRegistro = DAP.IdTipoSituacionAlumno
							WHERE DAP.IdDescuentoAcademico = DA.IdDescuentoAcademico  
							FOR XML PATH('') 
							),1,1,'') , ''),


		'ExcluirCodigoNombre' =  ISNULL(  STUFF(( 
		
							SELECT  distinct ',' +  '[' + CAST(DA2.Codigo AS VARCHAR) + ']'  FROM DescuentoAcademicoExcluir DAE
							INNER JOIN DescuentoAcademico DA2 WITH(NOLOCK) ON DAE.IdDescuentoAcademicoExcluir = DA2.IdDescuentoAcademico
							WHERE DAE.IdDescuentoAcademico = DA.IdDescuentoAcademico  
							FOR XML PATH('') 
							),1,1,'') , ''),
		'ExcluirTodo'= ISNULL(DA.ExcluirTodo,0),
		'ExcluirCuota'= ISNULL(DA.ExcluirCuota,0),
		'UsuarioCreacionFecha'=UU.Nombre+' ('+dbo.fechahora(DA.FechaCreacion)+')'  ,                                              
		'UsuarioModificacionFecha'=UUU.Nombre+' ('+dbo.fechahora(DA.FechaModificacion)+')',
		'EsForzado'= ISNULL(DA.EsForzado,0), --@1
		'EsSinVencimiento'= ISNULL(DA.EsSinVencimiento,0), --  @2
		'EsTransGratuita'= ISNULL(DA.EsTransGratuita,0), --  @2
		'EsGratuita'= ISNULL(DA.EsGratuita,0), --  @2
		'OfertaAlumno'= ISNULL(DA.OfertaAlumno,0),--  @5
		ROW_NUMBER() OVER(ORDER BY DA.IdDescuentoAcademico DESC) AS NumeroFila 
		FROM DescuentoAcademico DA WITH (NOLOCK) 
		LEFT JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.IdMaestroTabla = 1904 AND MTR.IdMaestroRegistro =DA.IdTipo 
		INNER JOIN Usuario UU WITH(NOLOCK)                        
		ON DA.UsuarioCreacion=UU.IdUsuario                                                
		INNER JOIN Usuario UUU WITH(NOLOCK)                                                
		ON DA.UsuarioModificacion=UUU.IdUsuario  
		WHERE (DA.IdDescuentoAcademico=@IdDescuentoAcademico OR @IdDescuentoAcademico = -1)
		AND ( DA.Nombre like ( '%'+ @Nombre+ '%'  )    OR  DA.Codigo LIKE '%' + @Nombre + '%')-- OR  DA.Campana LIKE '%' + @Nombre + '%'  
		AND CASE WHEN DA.Disponible1 = '' THEN  '[TODOS]' 
					WHEN @Disponible1 = '[TODOS]' THEN  '[TODOS]'
					WHEN ISNULL(DA.Disponible1,'[TODOS]') =  '[TODOS]' THEN  '[TODOS]' 
					ELSE  DA.Disponible1  END  = @Disponible1 
		AND (DA.Activo = @Activo  OR @Activo IS NULL)
		-- AND (DA.IdTipo = @IdTipo OR @IdTipo = -1)
		AND (DA.IdTipo IN (23951,23952,23953))
		AND CONVERT(VARCHAR,DA.FechaFin,112) >= CASE WHEN @Esvigente = 1 THEN CONVERT(VARCHAR,GETDATE(),112) ELSE '19000101'  END 
		) TEMPO 
		--INNER JOIN 
		-- [dbo].[Split](@Nombre,' ') T2 ON TEMPO.Nombre LIKE '%' + T2.Data + '%' 
		--									OR TEMPO.Codigo LIKE '%' + T2.Data + '%' 
		--									OR TEMPO.Campana LIKE '%' + T2.Data + '%' 
		--									OR TEMPO.CuotaNombre LIKE '%' + T2.Data + '%' 
		--AND NumeroFila BETWEEN (@PaginaTamano * @PaginaNumero) + 1   
		--AND @PaginaTamano * (@PaginaNumero + 1)
		WHERE NumeroFila BETWEEN (@PaginaTamano * @PaginaNumero) + 1   
		AND @PaginaTamano * (@PaginaNumero + 1)--@4
		ORDER BY TEMPO.IdDescuentoAcademico DESC

END
