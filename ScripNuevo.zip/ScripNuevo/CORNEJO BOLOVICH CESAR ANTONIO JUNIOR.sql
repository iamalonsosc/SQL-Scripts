--SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
--INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
--WHERE AC.IdAlumno=1274949  AND AC.IdCurso=10213
--order by ac.idregistro,ac.IdAlumnoCurso desc


--select*from AlumnoCurriculaCurso 
update AlumnoCurriculaCurso set  IdCurricula=5805
where  IdAlumno=1274949  and IdCurso in (10213) AND IdRegistro=3



UPDATE AlumnoCurso SET IdCurriculaOriginal=5805--,IdRegistro=2
WHERE IdAlumno=1274949 AND IdMatricula=606822  and IdCurso in (10213)


--select*from curriculacurso where IdCurricula=5803


--exec cAlumnoCurso_Sel_Listar_Matricula @pIdCurricula=5805,@pIdModulo=3,@pIdMatricula=606822