
DECLARE @PERIODOPROCESAR VARCHAR(50) ='2024-I'

DECLARE @TABLE TABLE (ID INT IDENTITY(1,1), CODIGOALUMNO VARCHAR(500), PERIODO VARCHAR(500), IDMAESTROREGISTRO INT , IDACTOR INT, nombreactor VARCHAR(500),IDMATRICULA INT, RESULTADO VARCHAR(500))

-- =CONCATENAR("INSERT INTO @TABLE VALUES('";E2;"',@PERIODOPROCESAR,46582,NULL,NULL,NULL,NULL)")
 
BEGIN

INSERT INTO @TABLE VALUES('SV77079312',@PERIODOPROCESAR,46582,NULL,NULL,NULL,NULL)




END 

--  select * from MaestroTablaRegistro where IdMaestroTabla  = 1905 and Nombre like '%beca%' order by 5
	--select * from MaestroTablaregistro where idmaestroregistro = 27666
	--select * from MaestroTablaregistro where idmaestroregistro = 27667
	--select * from MaestroTablaregistro where idmaestroregistro = 24940

--46582	1905	TIP0000027	NULL	BECA AMERICA TV SECUENCIALES EXCLUIDOS POR SEDE

update t set t.IDACTOR = aL.IdAlumno , t.nombreactor = ac. NombreCompleto
FROM @TABLE T
INNER JOIN Alumno AL on AL.CodigoAnterior = t.CODIGOALUMNO
INNER JOIN ACTOR AC ON AC.IdActor=AL.IdAlumno
--where ac.IdActor is not null

--SELECT DISTINCT t.dni, AC.IdActor , M.IdMatricula , P.PromocionCodigo 
update t set t.idmatricula = m.idmatricula 
FROM @TABLE T
--INNER JOIN ACTOR ac on ac.numeroidentidad = t.CODIGOALUMNO
INNER JOIN Matricula M ON M.IdActor = T.IdActor 
INNER JOIN Promocion P ON P.IdPromocion = M.IdPromocion 
INNER JOIN PERIODO PE ON PE.IdPeriodo = P.IdPeriodo  AND PE.Codigo = T.PERIODO 
where PE.Codigo = @PERIODOPROCESAR AND M.Estado <> 'X' AND p.IdUnidadNegocio=1

--select * from @TABLE
--return 

				
insert into DescuentoAcademicoBase (NumeroIdentidad ,  IdMaestroRegistro , IdActor ,IdDocumentoTipo,IdFacultad ,IdEmpresa,IdUnidadNegocio,IdunidadAcademica,PeriodoCodigo, Activo , UsuarioCreacion , FechaCreacion  )
SELECT t.CODIGOALUMNO, T.IDMAESTROREGISTRO  , ac.idactor , ac.IdDocumentoTipo , 1 IdFacultad, 1 IdEmpresa , 1 IdUnidadNegocio , NULL IdunidadAcademica , T.PERIODO  Periodo , 1 Activo , 1 UsuarioCreacion , GETDATE() FechaCreacion  
FROM @TABLE T
INNER JOIN ACTOR ac on ac.IdActor = t.IDACTOR
where  NOT EXISTS(select 1 FROM DescuentoAcademicoBase DAB WHERE DAB.IdActor=T.IDACTOR 
and DAB.IdMaestroRegistro=T.IDMAESTROREGISTRO AND DAB.PeriodoCodigo=@PERIODOPROCESAR AND  DAB.Activo=1)




-- return 

---- ASIGNAMOS DESCUENTOS

DECLARE @MIN INT, @MAX INT, @IDMATRICULA INT , @FechaConsulta DATE = GETDATE()  , @IDMAESTROREGISTRO INT

SELECT @MIN=MIN(ID), @MAX=MAX(ID) FROM @TABLE 


WHILE @MIN <= @MAX
BEGIN

	SET @IDMATRICULA = NULL 
	SET @IDMAESTROREGISTRO = NULL

	SELECT @IDMATRICULA = IDMATRICULA ,
	@IDMAESTROREGISTRO = IDMAESTROREGISTRO
	FROM @TABLE WHERE ID = @MIN 

	IF @IDMATRICULA IS NOT NULL
	BEGIN
		EXECUTE [dbo].[cDescuentoAlumno_Upd_AutoAsignarXmatricula] @IdMatricula = @IDMATRICULA , @FechaConsulta = @FechaConsulta 

		IF EXISTS (SELECT 1 FROM DescuentoAlumno dar
		INNER JOIN MATRICULA M ON M.IDMATRICULA = DAR.IDMATRICULA 
		INNER JOIN DescuentoAcademico DA ON DA.IDDESCUENTOACADEMICO = DAR.IDDESCUENTOACADEMICO
		INNER JOIN DescuentoAcademicoPoblacion DAP ON DAP.IdDescuentoAcademico= DA.IdDescuentoAcademico 
		WHERE M.IDMATRICULA = @IDMATRICULA AND DAP.IdTipoSituacionAlumno = @IDMAESTROREGISTRO)
		BEGIN
			UPDATE  @TABLE SET RESULTADO = 'DESCUENTO ASIGNADO' WHERE ID = @MIN 
		END 

	END 

	SET @MIN = @MIN + 1 
END 

SELECT * FROM @TABLE
