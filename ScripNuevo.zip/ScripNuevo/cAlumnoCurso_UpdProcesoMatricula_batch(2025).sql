--����������������������������������������������������������������������������            
--Creado por      : Carlos Huallpa(29/10/2009)            
--Funcionalidad   : Permite actualizar un registro en la tabla facilitador            
--Utilizado por   : Facilitador.UpdActualizar            
--����������������������������������������������������������������������������            
/*                    
-----------------------------------------------------------------------------                    
Nro  FECHA   USUARIO      DESCRIPCION                    
-----------------------------------------------------------------------------                    
@1  06.10.2011  jvilla      se agrego el campo IdUsuario                 
@2  22.03.2012  rgalvez      se agrego el la ejecuci�n del sp SP_SincronizacionBiblioteca            
@3  06.08.2013  lperales     mejora en el proceso de matricula                    
@4  04.01.2019         envio correos diplomados              
@5  11.01.2019  Eloy Alva (Sigcomt)   Agregar parametro CompaniaSocio.              
@6  31.05.2019  Eloy Alva(Sigcomt)   Parametrizacion de Zegel Ipae a Corriente Alterna              
@7  03.06.2019  Eloy Alva(Sigcomt)   Se parametriza los correos de la tabla ParametroEmpresa               
@8  11.06.2019  EHuillca        En caso de que no se cree registro de alumno error.              
@9  30.09.2019  Jleo         Se modifica SP de env�o de correos a BDSMTP.dbo.cEnvioCorreo_Ins_Grabar              
@10  23.02.2020  PUchuya         Se agrega logica para cursos libres              
@11  30.01.2020  Jnavia         Se agreg� validaci�n cuando no est� configurado el proceso de matr�cula en ParametroUnidadAcademica              
@12  29.05.2020  PUchuya         Se agreg� validaci�n por companiasocio para envio de correo solo para zegel              
@13  07.07.2020  PUchuya         Se quita isnull para cursos libres              
@14  19.07.2020  JLEO         Se modifica la l�gica en env�o de correos              
@15  15.09.2020  gguillen        Se agrega l�gica para IDAT            
@16  16-02-2021  EALVA         Agrego Logica de matricula por TipoSeccion Comercial                       
@17  04.03.2021  Jnavia         Se agrega nueva variable y se modifica el mensaje del correo                     
@18  15.04.2021  EALVA         Modifico Logica de Matricula por TipoSeccion                   
@19  30.04.2021  EALVA         Agrego detalle en mensaje de Error                    
@20  11.05.2021  RSamame         Agrego parametros para correo de bienvenida cuando sea Diplomado o CursoCorto                  
@21  12.05.2021  gguillen        Se agrega ajuste para tomar plantilla diferenciada por diplomado o curso corto                  
@22  25.05.2021  Hmora         Se agrega Validacion para matricular sin necesidad de horarios                  
@23  03.06.2021  Hmora         Se agrega Validaci�n para cursos libres                   
@24  04.06.2021  Ealva         Deshabilitar validaci�n por secci�n beca con Limite de Fecha                   
@25  25.06.2021  jmota         se habilita envio de correo de Bienvenida para ccm y cgt                   
@26  02.08.2021  jleo         se valida env�o de correos para procesos incompletos                  
@27  14.08.2021  jmota         se agrega env�o de copia oculta al correo                  
@28  12.01.2021  jleo         se agrega campo correo para el envio de bienvenida en FC Zegel                  
@29  06.04.2022  puchuya         se agreg condici�n para pre matriculas por sesiones de clases                  
@30  01.08.2022  EHuillca        Se actualiza a 0 el campo existeAD si es usuario de FC.                  
@31  15.08.2022  JLEO         se agrega envio de correo por proveedor ITB                  
@32  06.08.2022  FETORRES        Se agrego el campo IdMatricula y ahora se usa el SP cEnvioCorreo_Ins_Grabar en IDAT.              
@33  30.01.2023  JVALDERRAMA (csti)   Se agreg� validaciones para realizar matricula en funci�n de la sede ITS            
@34  24.04.2023  PUCHUYA         Desactivar envio correo bienvenida alumnos de programa de Zegel virtual            
@35  29.05.2023  JQuenta         Desactivar envio correo bienvenida alumnos de los programas mapeados de ITS            
@36  13.06.2023  JQuenta         Desactivar envio correo bienvenida alumnos de todos los programas de ITS            
@37  16.06.2023  JQuenta         Activar envio correo bienvenida alumnos solo para Division "EXTENSION" Programa "PROGRAMAS FI"            
                para el Inicio del Producto "PROGRAMA DE ESPECIALIZACI�N EN DID�CTICA DE LA LECTURA Y ESCRITURA EN LA ALFABETIZACI�N INICIAL"            
             de ITS            
@38  30.06.2023  JQuenta         Activar envio correo bienvenida alumnos solo para Division "EXTENSION" Programa "PROGRAMAS FI" Y "CURSOS FI"            
                para el Inicio del Producto "PROGRAMA DE ACTUALIZACI�N EN TEACHING ENGLISH AS A FOREING LANGUAG",            
             "CURSO DE ACTUALIZACI�N EN DISE�O DE EXPERIENCIAS DE APRENDIZAJE EN EDUCACI�N SUPERIOR",            
             "PROGRAMA DE ACTUALIZACI�N EN TUTOR�A Y ACOMPA�AMIENTO AL ADOLESCENTE",            
             "PROGRAMA DE ACTUALIZACION EN R�BRICAS, INSTRUMENTOS DE EVALUACI�N Y RETROALIMENTACI�N"            
             de ITS            
@39  04.08.2023  JQuenta      Activar envio correo bienvenida alumnos para Todos los Programas de Extension "PROGRAMAS FI" Y "CURSOS FI"            
             de ITS            
@40  22.08.2023  JQuenta      Activar envio correo bienvenida alumnos para Division Carreras y Division Extension (Todos los Programas) de ITS            
@41  23.08.2023  JQuenta      Se agrega Logica de Fecha de Inicio para Division Carreras y Division Extension de ITS            
@42  28.08.2023  Rotorres     Se realiza integracion de envio de correos de bienvenida con el proveedor ITB, para envio de correo de programa VIRTUAL.            
@43  01.09.2023  Rotorres     Se obtiene fecha de inicio de clases de la seccion para programas de Extension FC            
@44  07.09.2023  Rotorres     Se agrega logica temporal para envio de correos a FC con html distinto dependiendo de la fecha de inicio del alumno            
@45  02.10.2023  rotorres     Se revierte logica temporal de envio de correos FC            
@46  07.11.2023  EHuillca     Se corrige l�gica para obtener fecha de inicio de clases de la seccion para programas de Extension FC.            
@47  20.05.2024  Lpariona     Se agrega logica para obtener la nueva contrase�a robusta            
@48  12.09.2024  Rotorres     Se validan aforos para migracion de seccion comercial a normal            
@49  06.12.2024  Fetorres     Se habilita el envio de correos en CA.           
@50  07.01.2025  mquiroz      Se agrega validacion para ITS          
@51  13.01.2025  Fetorres     Se corrige el cuerpo del correo en CA,se agrega compania socio de ZEGEL cuando unidad academica sea 64 y se agrega isnull en las variables de envio de correo.           
@52  20.01.2025  Alsanchez    Se corrige de 8000 caracteres a 3000 caracteres en el campo observacion y tabla temporal      
@53  22.01.2025  JCORRALES   Se aumenta a 4000 caracteres el campo observacion en la tabla temporal #Matricula    
@54  05.02.2025  FETORRES    Se cambia la logica de fechas para todas las marcas.  
@55  2025.02.26	 jmota		En coordinacion con flescano (Z e IDAT), zorka (CA) y vanessa uresti(its) se vio correcto que el inicio de las clases extesion debe ser se la seccion (promociongrupo)
@56  2025.02.28	 ALSANCHEZ	Traer el ultimo correo registrado y que no este en blanco
*/              
ALTER PROCEDURE [dbo].[cAlumnoCurso_UpdProcesoMatricula_batch]               
@IdEmpresa int,            
@IdSede int,            
@IdFacultad int,            
@IdUnidadNegocio int,            
@IdUnidadAcademica int,            
@IdPeriodo int,            
@IdProducto int,            
@IdPromocion int,            
@IdGrupo int,            
@IdAlumno int,            
@IdUsuario int,                  
@ValHorario int  --@22               
AS            
BEGIN             
  SET NOCOUNT ON            
  --  select @IdEmpresa =1,            
  --@IdSede =33,            
  --@IdFacultad =1,            
  --@IdUnidadNegocio =1,                    
  --@IdUnidadAcademica=60,            
  --@IdPeriodo =2625,            
  --@IdProducto =9499,            
  --@IdPromocion =80014,            
  --@IdGrupo =0,            
  --@IdAlumno =0,            
  --@IdUsuario  =1                      
  -- @5 inicio                
            
  DECLARE @CompaniaSocio char(8),            
  @NombreEmpresa varchar(50),            
  @WebPrincipal varchar(50),            
  @WebZoom varchar(50),            
  @WebSmart varchar(50),  --@6            
  @CorreoPrincipal varchar(max),--@7              
  @UrlImagenes varchar(max),            
  @Subject varchar(max), --@14            
  @pNombreCorreoUA varchar(50), --@14            
  @Usuario Varchar(50), --@14            
  @clave Varchar(50), --@14                      
  @vTipoSeccion VARCHAR(1),           
  @FechaInicio VARCHAR(10), --@17                  
  --INICIO @18                  
  @IdTipoSeccionNormal INT,                  
  @IdTipoSeccionComercial INT,                  
  @IdTipoSeccionBeca INT,                  
  @IdTipoTurno INT,           
  @ListaBecaAmerica VARCHAR(200),                  
  @TipoSeccion Varchar(20)='',                  
  @CorreoSaeDip varchar(max),--@20                  
  @CorreoSaeCur varchar(max),--@20                  
  @ProductoNombreVal VARCHAR(100),--@20                  
  @ValidaHorario INT, --@22                  
  @FechaLimiteBeca VARCHAR(20),--@24                  
  @ListaCopiaCorreo VARCHAR(500), --@27                  
  @CodigoSedeNuevo VARCHAR(20) --@33            
  ,@profile_name_empresa VARCHAR(20), --@37            
  @TipoCorreo varchar(100)            
                  
  select @ProductoNombreVal=ProductoNombre from Producto WITH(NOLOCK) where IdProducto=@IdProducto--@20                  
                
                
  SET @IdTipoSeccionNormal=(SELECT IdMaestroRegistro FROM MaestroTablaRegistro  WITH(NOLOCK) WHERE IdMaestroTabla=2060 and Codigo='Normal')                  
                
  SET @IdTipoSeccionBeca=(SELECT IdMaestroRegistro FROM MaestroTablaRegistro  WITH(NOLOCK) WHERE IdMaestroTabla=2060 and Codigo='BECA')                  
                
  SELECT @vTipoSeccion=ISNULL(Valor,'0') FROM Parametro  WITH(NOLOCK) WHERE Nombre='MatriculaTipoSeccion'                    
                    
  SELECT @ListaBecaAmerica=ISNULL(Valor,'0'),@FechaLimiteBeca=ISNULL(Valor2,'0') FROM Parametro WITH(NOLOCK) WHERE Nombre='GrupoBecaAmerica' --@24            
            
  SELECT @CodigoSedeNuevo= codigo FROM sede where IdSede =@IdSede--@33            
  --FIN @18             
                   
  SELECT            
  @CompaniaSocio = CompaniaSocio            
  FROM Empresa e WITH (NOLOCK)            
  WHERE E.IdEmpresa = @IdEmpresa            
            
  IF @CodigoSedeNuevo = 'IT'  OR @CodigoSedeNuevo = 'CD'--@33            
  BEGIN            
    SELECT                
    @NombreEmpresa = Valor,            
    @WebPrincipal = Valor2,            
    @WebZoom = Valor3,            
    @WebSmart = Valor4            
    FROM ParametroEmpresa WITH (NOLOCK)--Dominios de  Principal ,zoom , smart            
    WHERE Nombre = 'EMPRESANOMBRE2' --@33            
  END            
  ELSE            
  BEGIN            
    SELECT                
    @NombreEmpresa = Valor,            
    @WebPrincipal = Valor2,            
    @WebZoom = Valor3,            
    @WebSmart = Valor4            
    FROM ParametroEmpresa WITH (NOLOCK)--Dominios de  Principal ,zoom , smart            
    WHERE Nombre = 'EMPRESANOMBRE' --@6                
  END            
                
  --Inicio @37            
  IF @CodigoSedeNuevo = 'IT'            
  BEGIN            
    SELECT            
    @CorreoPrincipal = Valor,                      
    @CorreoSaeDip = Valor3,                    
    @CorreoSaeCur = Valor4                
    FROM ParametroEmpresa WITH (NOLOCK)                  
    WHERE Nombre = 'CORREOVRA3'             
  END            
  ELSE IF @CodigoSedeNuevo = 'CD'--@33             
  --Fin --@37            
  BEGIN            
    SELECT            
    @CorreoPrincipal = Valor,                
    @CorreoSaeDip = Valor3,--@20                       
    @CorreoSaeCur = Valor4 --@20             
    FROM ParametroEmpresa WITH (NOLOCK)--Dominios de Principal ,zoom , smart            
    WHERE Nombre = 'CORREOVRA2' --@33                
  END            
  ELSE            
  BEGIN            
    SELECT            
    @CorreoPrincipal = Valor,                      
    @CorreoSaeDip = Valor3,--@20                       
    @CorreoSaeCur = Valor4 --@20             
    FROM ParametroEmpresa WITH (NOLOCK)--Dominios de Principal ,zoom , smart            
    WHERE Nombre = 'CORREOVRA' --@7            
  -- @5 fin                     
  END                
            
  CREATE TABLE #Matricula (            
  Id int IDENTITY,            
  IdMatricula int,            
  PromocionIdEmpresa int,            
  PromocionIdSede int,            
  PromocionIdFacultad int,            
  PromocionIdUnidadNegocio int,            
  PromocionIdUnidadAcademica int,            
  PromocionIdPeriodo int,            
  PromocionIdProducto int,            
  ProductoNombre varchar(250),            
  IdPromocion int,            
  IdRegistro int,        
  PromocionNombre varchar(250),            
  IdGrupo int,            
  GrupoCodigo varchar(250),            
  CodigoAlumno varchar(20),            
  ActorIdActor int,            
  ActorNombreCompleto varchar(250),            
  IdDocumentoTipo int,            
  NumeroIdentidad varchar(20),            
  Observacion varchar(4000),--@52 --@53     
  InscritoFecha date,            
  IdProcedencia int,            
  Estado varchar(100),            
  Orden int,                  
  UsuarioCreacion INT,                 
  IdTipoTurno INT,  --@18   
  TipoServicio VARCHAR(5) --@54                       
  )                      
            
  DECLARE @nombreSp varchar(50) = 'cAlumnoCurso_UpdProcesoMatricula_batch' --@31             
                    
  --SE CARGA TODA LA POBLACI�N DE ALUMNOS MATRICULADOS SEGUN LOS CRITERIOS              
  --si el proceso no es por secci�n, se va a la cabecera de matricula             
  BEGIN            
    INSERT INTO #Matricula              
    (InscritoFecha,PromocionIdEmpresa,PromocionIdSede,PromocionIdFacultad,PromocionIdUnidadNegocio, PromocionIdUnidadAcademica,            
    PromocionIdPeriodo,PromocionIdProducto,IdPromocion,IdGrupo,ActorIdActor,IdMatricula,IdRegistro,IdProcedencia,Orden,UsuarioCreacion,IdTipoTurno,TipoServicio)   --@54             
    SELECT distinct M.InscritoFecha,P.IdEmpresa,P.IdSede,P.IdFacultad,P.IdUnidadNegocio,P.IdUnidadAcademica,P.IdPeriodo,            
    P.IdProducto,M.IdPromocion,M.IdGrupo,M.IdActor,M.IdMatricula, M.IdRegistro, ISNULL(M.IdProcedencia,0),ISNULL(CM.Orden,1),M.UsuarioCreacion,T.IdTipoTurno  --@10 --@13  --@18                   
    ,un.TipoServicio --@54   
 FROM Matricula M with(nolock)                  
    INNER JOIN AlumnoCurso AC with(nolock) --@22                  
    ON M.IdMatricula=AC.IdMatricula --@22                   
    INNER JOIN Promocion P  with(nolock)                    
    ON M.IdPromocion=P.IdPromocion                    
    LEFT JOIN PromocionGrupo PG with(nolock)                  
    ON PG.IdPromocion=P.IdPromocion And PG.IdGrupo=M.IdGrupo --@18                    
    LEFT JOIN Turno T with(nolock)                  
    ON T.IdTurno=PG.IdTurno     --@18                   
    LEFT JOIN CurriculaModulo CM with(nolock)  --@10                   
    ON M.IdCurricula = CM.IdCurricula                      
    AND M.IdModulo = CM.IdModulo           
 INNER JOIN UnidadNegocio UN ON UN.IdUnidadNegocio=P.IdUnidadNegocio             
    WHERE P.IdEmpresa=@IdEmpresa                
    AND P.IdSede=@IdSede               
    AND P.IdFacultad=@IdFacultad                
    AND P.IdUnidadNegocio=@IdUnidadNegocio               
    AND P.IdUnidadAcademica=@IdUnidadAcademica               
    AND P.IdPeriodo=@IdPeriodo              
    AND (P.IdProducto=@IdProducto OR @IdProducto=0)               
    AND (M.IdPromocion=@IdPromocion OR @IdPromocion=0)               
    AND (M.IdGrupo=@IdGrupo OR @IdGrupo=0)              
    AND (M.IdActor=@IdAlumno OR @IdAlumno=0)              
    AND M.Estado<>'X'              
    AND M.IdPeriodo is null                    
    --AND M.EsMatricula=0 --@22                  
    AND AC.EsMatricula=0  --@22                
    AND (AC.idseccion is null or (P.TipoServicio = 'L' and ac.idseccion is not null) or (AC.CantidadSesion > 0 and ac.idseccion is not null)) --@23 --@29                  
    ORDER BY M.InscritoFecha ASC              
  END            
            
    --SE CARGAN LAS DESCRIPCIONES DE CADA ALUMNO-CURSO              
  UPDATE M            
  SET M.ProductoNombre = RTRIM(P.ProductoCodigo) + '-' + RTRIM(P.ProductoNombre),            
  M.PromocionNombre = RTRIM(PR.PromocionCodigo) + '-' + RTRIM(PR.PromocionNombre),            
  M.GrupoCodigo = RTRIM(PG.GrupoCodigo), --@10 --@13            
  M.ActorNombreCompleto = RTRIM(A.NombreCompleto),            
  M.IdDocumentoTipo = ISNULL(A.IdDocumentoTipo, ''),            
  M.NumeroIdentidad = ISNULL(A.NumeroIdentidad, ''),            
  M.CodigoAlumno = ISNULL(AL.CodigoAnterior, '')            
  FROM #Matricula M            
  LEFT OUTER JOIN Producto P WITH (NOLOCK)            
  ON M.PromocionIdProducto = P.IdProducto            
  LEFT OUTER JOIN Promocion PR WITH (NOLOCK)            
  ON M.IdPromocion = PR.IdPromocion            
  LEFT OUTER JOIN PromocionGrupo PG WITH (NOLOCK)            
  ON M.IdPromocion = PG.IdPromocion            
  AND M.IdGrupo = PG.IdGrupo            
  LEFT OUTER JOIN Actor A WITH (NOLOCK)            
  ON M.ActorIdActor = A.IdActor            
  LEFT OUTER JOIN Alumno AL WITH (NOLOCK)            
  ON AL.IdAlumno = A.IdActor            
                   
  -- drop table #Matricula                      
                      
  --return                      
            
  --se carga el parametro que Define lo que se va a validar por unidad acad�mica            
  -- valor = 1 valida pago, en caso contrario no se valida pago            
  -- valor2 = 1 valida documentos, en caso contrario no se valida documentos            
  DECLARE @ValidaPago int,            
  @ValidaDocumentos int,            
  @ValidaExamen int            
            
  SELECT            
  @ValidaPago = ISNULL(PUA.Valor, 1),            
  @ValidaDocumentos = ISNULL(PUA.Valor2, 1),            
  @ValidaExamen = ISNULL(PUA.Valor3, 1)            
  FROM ParametroUnidadAcademica PUA WITH (NOLOCK)            
  WHERE PUA.IdEmpresa = @IdEmpresa            
  AND PUA.IdSede = @IdSede            
  AND PUA.IdFacultad = @IdFacultad            
  AND PUA.IdUnidadNegocio = @IdUnidadNegocio            
  AND PUA.IdUnidadAcademica = @IdUnidadAcademica            
  AND PUA.Nombre = 'ProcesoMatricula'            
            
  DECLARE @ERRORCODIGO int,            
  @DESCRIPCIONERROR varchar(3000),  --@52          
  @CurIdGrupo int,            
  @CurIdAlumno int,            
  @CurIdPromocion int,            
  @CurIdMatricula int,            
  @CurIdRegistro int,            
  @CurCodigoAlumno varchar(20),            
  @EstadoMatricula varchar(100),            
  @CurNumeroDocumento varchar(20),            
  @CurID int,            
  @MaxID int,            
  @pLogin varchar(20),            
  @CodigoAlumno varchar(20),            
  @CurIdProcedencia int,            
  @CurOrden int,            
  @IdDocumentoTipo int,            
  @CodigoSede varchar(2),            
  @Count int,            
  @Login varchar(25),  
  @CurTipoServicio varchar(5)    --@54          
            
  SELECT            
  @CurID = 1,            
  @MaxID = MAX(Id)            
  FROM #Matricula            
            
  WHILE @CurID <= @MaxID            
  BEGIN            
    SET @CodigoAlumno = ''            
    --sacamos los datos por cada alumno            
    SELECT            
    @CurIdGrupo = IdGrupo,            
    @CurIdAlumno = ActorIdActor,            
    @CurIdPromocion = IdPromocion,            
    @CurIdMatricula = IdMatricula,            
    @CurIdRegistro = idRegistro,                       
    @CurCodigoAlumno = CodigoAlumno,            
    @CurNumeroDocumento = NumeroIdentidad,            
    @CurIdProcedencia = IdProcedencia,                       
    @CurOrden = Orden,            
    @IdDocumentoTipo = IdDocumentoTipo,                   
    @IdTipoTurno=IdTipoTurno,    --@18  
    @CurTipoServicio=TipoServicio   --@54                     
 FROM #Matricula            
    WHERE Id = @CurID            
              
    --SE REINICIA LA VARIABLE ERROR               
    SET @DESCRIPCIONERROR = 'Ok'            
    SET @ERRORCODIGO = 0            
    SET @EstadoMatricula = 'Matricula Completa'            
              
    -- validamos que tenga numero de documento            
              
    IF (@IdDocumentoTipo = 25            
      AND (ISNUMERIC(@CurNumeroDocumento) = 0            
      OR LEN(@CurNumeroDocumento) <> 8))            
    BEGIN            
      SET @DESCRIPCIONERROR = 'La Persona ' + CONVERT(varchar(50), @CurIdAlumno) + ' no tiene registrado n�mero de documento v�lido o debe actualizar el documento (' + @CurNumeroDocumento + ')'            
      SET @EstadoMatricula = 'No Matriculado'            
    END            
    ELSE            
    IF (@IdDocumentoTipo = 27            
      AND (ISNULL(@CurNumeroDocumento, '') = ''            
    OR ISNUMERIC(SUBSTRING(@CurNumeroDocumento, 1, 2)) = 0))            
    BEGIN            
      SET @DESCRIPCIONERROR = 'La Persona ' + CONVERT(varchar(50), @CurIdAlumno) + ' no tiene registrado n�mero de documento o debe actualizar el documento (' + @CurNumeroDocumento + ')'            
    SET @EstadoMatricula = 'No Matriculado'            
    END            
    ELSE            
    IF (@IdDocumentoTipo = 357            
      AND (ISNULL(@CurNumeroDocumento, '') = ''            
      OR ISNUMERIC(SUBSTRING(@CurNumeroDocumento, 1, 2)) = 0))            
    BEGIN            
      SET @DESCRIPCIONERROR = 'La Persona ' + CONVERT(varchar(50), @CurIdAlumno) + ' no tiene registrado n�mero de documento o debe actualizar el documento (' + @CurNumeroDocumento + ')'            
      SET @EstadoMatricula = 'No Matriculado'            
    END            
    ELSE            
    BEGIN            
      IF @ValidaPago IS NULL   --@11 Inicio                 
      BEGIN            
      SET @ERRORCODIGO = 1            
      SET @EstadoMatricula = 'No Matriculado'            
      SET @DESCRIPCIONERROR = 'No est� configurado el proceso de matr�cula en ParametroUnidadAcademica'            
      END --@11 Fin            
      -- NO DEBE VALIDAR DEUDAS DE ESTE ALUMNO LA PROCEDENCIA = 1                      
      IF @CurIdProcedencia = 0            
      BEGIN            
      ----SE VALIDA QUE EL ALUMNO NO TENGA DEUDAS            
      IF @ValidaPago = 1            
      BEGIN            
        -- PERMISO DE MATRICULA PARA PODER MATRICULARSE CON DEUDAS                      
        IF dbo.cAutorizacionAlumno_Val_Existe(@IdEmpresa, @IdSede, @IdFacultad, @IdUnidadNegocio, @IdUnidadAcademica,            
        @IdPeriodo, @CurIdAlumno, 1035) = 0            
        BEGIN            
        -- Llamar a la funci�n que valida si el alumno tiene deudas con la instituci�n de spring                      
        IF dbo.cMatricula_Val_Pago_Cuota(@CurIdMatricula, @CompaniaSocio) = 0   --@5                     
        BEGIN            
          SET @ERRORCODIGO = 1            
          SET @EstadoMatricula = 'No Matriculado'            
          SET @DESCRIPCIONERROR = 'No ha cancelado su cuota de matr�cula'            
        END            
        ELSE            
        BEGIN            
          SET @ERRORCODIGO = 0            
        END            
        END            
      END            
      END            
                
      --SE VALIDA QUE EL ALUMNO HAYA ENTREGADO TODOS LOS DOCUMENTOS              
      IF @ERRORCODIGO = 0            
      AND @ValidaDocumentos = 1            
      BEGIN            
      -- SI ES DE PRIMER CICLO SOLO SE DEBE VALIDAR ESTO                      
      IF @CurOrden = 1            
      BEGIN            
        -- PERMISO DE MATRICULA PARA PODER MATRICULARSE CON DOCUMENTOS PENDIENTES                      
        IF dbo.cAutorizacionAlumno_Val_Existe(@IdEmpresa, @IdSede, @IdFacultad, @IdUnidadNegocio, @IdUnidadAcademica,            
      @IdPeriodo, @CurIdAlumno, 1036) = 0            
        BEGIN            
        EXEC cRegistroProductoRequisito_Val_Pendientes @CurIdAlumno,            
        @CurIdRegistro,            
        @ERRORCODIGO OUT            
              
        IF @ERRORCODIGO = 1 -- tienen documentos pendientes            
        BEGIN            
          SET @DESCRIPCIONERROR = 'Tiene documentos pendientes'            
          SET @EstadoMatricula = 'No Matriculado'            
        END            
        END            
      END            
      END            
              
      --SE VALIDA QUE EL ALUMNO HAYA asistido al examen de admision            
      IF @ERRORCODIGO = 0            
      AND @ValidaExamen = 1            
      BEGIN            
      -- SI ES DE PRIMER CICLO SOLO SE DEBE VALIDAR ESTO            
      IF @CurOrden = 1            
      BEGIN      
        EXEC cAlumnoAsistenciaAdmision_Val_Asistencia @CurIdAlumno,            
      @IdPeriodo,            
      @ERRORCODIGO OUT            
              
        IF @ERRORCODIGO = 1 -- el alumno no ha asistido al examen de admision programado              
        BEGIN            
        SET @DESCRIPCIONERROR = 'El alumno no ha asistido al examen de admisi�n programado'            
        SET @EstadoMatricula = 'No Matriculado'            
        END            
      END            
      END            
      --  validamos si existe un usuario ya registrado con otro contacto            
      IF @ERRORCODIGO = 0            
      BEGIN            
      SET @Count = 0            
              
      SELECT            
        @Count = COUNT(1)            
      FROM Usuario WITH (NOLOCK)            
      WHERE IdActor = @CurIdAlumno            
      AND IdTipoUsuario = 1  -- usuario de tipo alumno                  
              
      IF @Count = 0            
      BEGIN            
        --  validamos si existe un usuario ya registrado con otro contacto              
        SET @CodigoSede = ( SELECT            
							  CODIGO            
							FROM Sede WITH (NOLOCK)            
							WHERE IdSede = @IdSede)            
									SET @Login = @CodigoSede + @CurNumeroDocumento            
              
        SELECT            
        @Count = COUNT(1)            
        FROM Usuario WITH (NOLOCK)            
        WHERE LOGIN = @Login            
        AND IdTipoUsuario = 1  -- usuario de tipo alumno               
              
        IF @Count > 0            
        BEGIN            
 SET @DESCRIPCIONERROR = 'Ya existe un c�digo de usuario asignado a otra persona ' + @Login            
        SET @EstadoMatricula = 'No Matriculado'            
        SET @ERRORCODIGO = 1            
        END            
      END            
      END                   
      --INICIO @18                   
      IF @vTipoSeccion='1' AND @IdUnidadNegocio=1   --TipoSeccion Solo carreras                  
      BEGIN                    
      IF EXISTS (Select  1 FROM DescuentoAlumnoResultado DAR WITH(NOLOCK)                    
				WHERE IdMatricula=@CurIdMatricula                   
				AND GrupoDescuento IN ( SELECT DISTINCT txt_value FROM dbo.uf_Parse(@ListaBecaAmerica,',') ))                    
				AND EXISTS (Select  1 FROM Periodo P WITH(NOLOCK)         
				WHERE IdPeriodo=@IdPeriodo AND convert(varchar,inicio,112)< @FechaLimiteBeca) --@24            
            
      BEGIN                     
      --Seccion BECA                      
            
      SET @CurIdGrupo= (SELECT  Top 1 IdGrupo From PromocionGrupo PG WITH(NOLOCK)                  
      INNER JOIN Turno T WITH(NOLOCK) ON T.IdTurno=PG.IdTurno                  
      WHERE PG.IdPromocion=@CurIdPromocion                   
      AND ISNULL(PG.IdTipoSeccion,@IdTipoSeccionNormal)=@IdTipoSeccionBeca                  
      AND T.IdTipoTurno=@IdTipoTurno )                  
                    
      SET @TipoSeccion='BECA' --@19                  
            
      END                  
      ELSE                  
      BEGIN                  
                      
    --@48 INICIO            
            
    ----Seccion Normal                       
    --SET @CurIdGrupo= (SELECT  Top 1 IdGrupo From PromocionGrupo PG WITH(NOLOCK)                    
    --INNER JOIN Turno T WITH(NOLOCK) ON T.IdTurno=PG.IdTurno                    
    --WHERE PG.IdPromocion=@CurIdPromocion                     
    --AND ISNULL(PG.IdTipoSeccion,@IdTipoSeccionNormal)=@IdTipoSeccionNormal                    
    --AND T.IdTipoTurno=@IdTipoTurno )                    
               
   SET @CurIdGrupo = (            
					SELECT TOP 1            
					 TEMP.IdGrupo            
					FROM (            
						SELECT             
						PG.IdPromocion,            
						PG.IdGrupo,            
						SC.IdSeccion,            
						SC.IdCurso,            
						dbo.cMatricula_Val_VacantePromocionGrupoSeccion(PG.IdPromocion,PG.IdGrupo,SC.IdSeccion,SC.IdCurso) AS VacanteDisponible            
						FROM PromocionGrupo PG WITH (NOLOCK)            
						INNER JOIN Seccion SC WITH (NOLOCK) ON PG.IdPromocion = SC.IdPromocion AND PG.IdGrupo = SC.IdGrupo         
						INNER JOIN Turno TR WITH (NOLOCK) ON TR.IdTurno = PG.IdTurno            
						WHERE             
						PG.IdPromocion = @CurIdPromocion            
						AND ISNULL(PG.IdTipoSeccion, @IdTipoSeccionNormal) = @IdTipoSeccionNormal            
						AND TR.IdTipoTurno = @IdTipoTurno            
					) AS TEMP            
					WHERE             
					 TEMP.VacanteDisponible = 1            
					GROUP BY             
					 TEMP.IdGrupo            
				   )            
            
   --@48 FIN             
                    
    SET @TipoSeccion='NORMAL' --@19              
                
      END                    
                    
      IF ISNULL(@CurIdGrupo,0)=0                  
      BEGIN                  
        SET @DESCRIPCIONERROR = 'No se encuentra el tipo de Seccion '+ @TipoSeccion+' del Alumno'      --@19                  
        SET @EstadoMatricula = 'No Matriculado'                   
        SET @ERRORCODIGO=1                  
      END                  
    END                    
    --FIN @18                  
                    
      --@22                  
      IF @ValHorario = 1                  
      BEGIN                  
      SET @ValidaHorario = 1                  
      END                  
      ELSE                  
      BEGIN                  
      SET @ValidaHorario = 0                  
      END                  
    --@22                  
           
      IF @ERRORCODIGO = 0                   
                
    BEGIN            
      DECLARE @mjs varchar(MAX),      --@21                  
        @uEmail varchar(200),            
        @pieMensaje VARCHAR(5000), --@14            
        @uNombres varchar(200), --@14                       
      @EsMatricula INT, --@26                  
      @Dominio VARCHAR(200) --@31                  
                    
      --@26                  
      SELECT                   
    @EsMatricula = EsMatricula                   
      FROM Matricula WITH(NOLOCK)                   
      WHERE idmatricula = @CurIdMatricula                   
      --@26                  
      -- procesa cada alumno            
      EXEC  cMatricula_ProcesoxAlumno_batch @CurIdMatricula,            
    @CurIdPromocion,            
    @CurIdGrupo,            
    @IdUsuario,                  
        @ValidaHorario,  --@22                  
    @ERRORCODIGO OUT,            
    @DESCRIPCIONERROR OUT            
              
      IF @ERRORCODIGO = 0            
        SET @EstadoMatricula = 'No Matriculado'            
      IF @ERRORCODIGO = 1            
        SET @EstadoMatricula = 'Matricula Completa'            
      IF @ERRORCODIGO = 5            
		SET @EstadoMatricula = 'Matricula Completa'            
      IF @ERRORCODIGO = 2            
        SET @EstadoMatricula = 'Matricula Incompleta'            
              
      IF @ERRORCODIGO <> 0              OR @ERRORCODIGO <> 5 --and ISNULL(@CurCodigoAlumno,'') = ''            
      BEGIN            
        -- creamos al alumno, usuario               
        EXEC cUsuario_Alumno_Ins_Grabar @CurIdAlumno,            
			@IdSede,            
			@IdUsuario,            
			@CodigoAlumno OUT                       
        IF @IdUnidadNegocio = 2 --Inicio @30                    
        BEGIN                    
        UPDATE Usuario SET                    
          EsUsuarioAD =0                    
        WHERE IdActor = @CurIdAlumno AND IdTipoUsuario = 1                    
        END --Fin @30                    
              
        --@4            
        --SELECT            
        --@uEmail = AE.Descripcion            
        --FROM ActorEmail AE WITH(NOLOCK)            
        --INNER JOIN MATRICULA MAT WITH(NOLOCK)            
        --ON AE.IdActor = MAT.IdActor            
        --WHERE MAT.IdMatricula = @CurIdMatricula            
        --AND AE.principal = 1

		--@56 Inicio
		SELECT  @uEmail = T.Descripcion  FROM (
		SELECT TOP 1 AE.Descripcion,ae.IdActor,ISNULL(AE.Principal,0) as principal ,AE.FechaModificacion
		FROM ActorEmail AE WITH(NOLOCK)
		INNER JOIN MATRICULA MAT WITH(NOLOCK)
		ON AE.IdActor = MAT.IdActor
		WHERE MAT.IdMatricula = @CurIdMatricula
		AND AE.Descripcion <> ''
		ORDER BY principal DESC,AE.FechaModificacion desc) T 
		--@56 Fin
              
        --Inicio @14            
        Select @uNombres = Nombres From Usuario With(Nolock) where Login = @CodigoAlumno            
        Select @Dominio = Valor from parametro where nombre = 'CorreoIpae2' and valor2 = @CodigoSedeNuevo --@33            
            
      IF @Dominio IS NULL --@33            
      BEGIN            
		Select @Dominio = Valor from parametro where nombre = 'CorreoIpae'--@14            
      END              
                  
                  
      --@21                  
        Set  @pNombreCorreoUA = ISNULL(Case @IdUnidadAcademica            
										When 2 Then 'cEnvioBienvenidaDIP'            
										When 48 Then 'cEnvioBienvenidaVIR'            
										When 1 Then 'cEnvioBienvenidaCAR'            
										When 57 Then 'cEnvioBienvenidaCAR'                   
										When 59 Then 'cEnvioBienvenidaCAR'  --@25  CGT IDAT                   
										When 60 Then 'cEnvioBienvenidaCAR'  --@25  CCM IDAT               
										Else ''            
										End,'')                 
    --  IF @IdUnidadNegocio = 2 AND (CHARINDEX('CUR', @ProductoNombreVal)=1 OR CHARINDEX('PROG', @ProductoNombreVal)=1 ) AND @CompaniaSocio = '00002500'                  
    --  BEGIN                  
   --SET @pNombreCorreoUA = 'cEnvioBienvenidaCUR'              
    --  END               
      IF (@IdUnidadAcademica = 64 AND @CompaniaSocio='00002500')--@51        
		BEGIN        
			SET @pNombreCorreoUA = NULL --@34            
		END        
                  
      --Inicio --@36            
      --IF (@IdUnidadAcademica = 65 OR @IdUnidadAcademica = 66 OR @IdUnidadAcademica = 67) AND @CodigoSedeNuevo = 'IT' --@33 ITS            
      --BEGIN            
      ----SET @pNombreCorreoUA = 'cEnvioBienvenidaCAR2' --@35            
      --SET @pNombreCorreoUA = NULL --@35            
      --END            
      --ELSE            
      --BEGIN            
  --IF (@IdUnidadAcademica = 68 AND @CodigoSedeNuevo = 'IT')            
      --BEGIN            
     ----SET @pNombreCorreoUA = 'cEnvioBienvenidaDIP2' --@35            
      --SET @pNombreCorreoUA = NULL --@35            
      --END            
      --END --@33 ITS            
      --Fin --@36            
            
    --IF @CodigoSedeNuevo = 'IT' SET @pNombreCorreoUA = NULL --@36 --@37            
            
    --Inicio --@37            
 IF @CodigoSedeNuevo = 'IT'            
 BEGIN            
  --IF ( --@38            
  -- --Programa: PROGRAMAS FI >> PROGRAMA DE ACTUALIZACION EN DID�CTICA PARA LA INICIACI�N EN LA LECTURA Y ESCRITURA            
  -- (@IdUnidadAcademica = 69 AND @IdProducto = 14540)            
  -- --Inicio --@38            
  -- --Programa: PROGRAMAS FI >> PROGRAMA DE ACTUALIZACI�N EN TEACHING ENGLISH AS A FOREING LANGUAGE            
  -- --Programa: CURSOS FI >> CURSO DE ACTUALIZACI�N EN DISE�O DE EXPERIENCIAS DE APRENDIZAJE EN EDUCACI�N SUPERIOR            
  -- --Programa: PROGRAMAS FI >> PROGRAMA DE ACTUALIZACI�N EN TUTOR�A Y ACOMPA�AMIENTO AL ADOLESCENTE            
  -- --Programa: PROGRAMAS FI >> PROGRAMA DE ACTUALIZACION EN R�BRICAS, INSTRUMENTOS DE EVALUACI�N Y RETROALIMENTACI�            
  -- --Fin --@38            
  -- OR (@IdUnidadAcademica IN (69,70) AND @IdProducto IN (14598,14596,14594,14538)) --@38            
  --) --@38            
  --Inicio --@40            
  --IF @IdUnidadAcademica IN (69,70) --@39            
  IF @IdUnidadNegocio = 1 --Division: Carrera Profesional            
  BEGIN            
    SET @pNombreCorreoUA = 'cEnvioBienvenidaCAR2'            
  END            
  ELSE IF @IdUnidadNegocio = 2 --Division: Extension            
  BEGIN          
    SET @pNombreCorreoUA = 'cEnvioBienvenidaDIP2'            
  END            
  --Fin --@40            
  ELSE            
  BEGIN            
    SET @pNombreCorreoUA = NULL            
  END            
 END            
    --Fin --@37            
  IF @CompaniaSocio='00002600' --LOGICA CORRIENTE ALTERNA--@49 --@51         
 BEGIN          
            
  IF @IdUnidadNegocio = 1 --Division: Carrera Profesional          
  BEGIN          
    SET @pNombreCorreoUA = 'cEnvioBienvenidaCAR'          
  END          
  ELSE IF @IdUnidadNegocio in (2,26) --Division: Extension,talleres          
  BEGIN          
    SET @pNombreCorreoUA = 'cEnvioBienvenidaCUR'          
  END          
  --Fin --@40          
  ELSE          
  BEGIN          
    SET @pNombreCorreoUA = 'cEnvioBienvenidaCAR'          
  END          
          
 END             
    --@21                  
        If LEN(@pNombreCorreoUA) > 0   AND @ValHorario = 0    --@22                    
    AND @EsMatricula = 0 --@26                  
        Begin            
        Select             
          @Subject = AsuntoMensaje,            
          @UrlImagenes = IsNull(CabeceraMensaje,''),            
          @mjs = CuerpoMensaje,            
          @pieMensaje = IsNull(PieMensaje,''),                  
      @ListaCopiaCorreo = IsNull(ListaCorreoUno,'')   --@27                    
        From Correo With(Nolock)            
        Where IdTipo = 6 And Nombre = @pNombreCorreoUA            
    
  --Inicio --@37            
  --IF ( --@38            
  -- --Programa: PROGRAMAS FI >> PROGRAMA DE ESPECIALIZACI�N EN DID�CTICA DE LA LECTURA Y ESCRITURA EN LA ALFABETIZACI�N INICIAL            
  -- (@IdUnidadAcademica = 69 AND @IdProducto = 14540)            
  -- --Inicio --@38            
  -- --Programa: PROGRAMAS FI >> PROGRAMA DE ACTUALIZACI�N EN TEACHING ENGLISH AS A FOREING LANGUAGE            
  -- --Programa: CURSOS FI >> CURSO DE ACTUALIZACI�N EN DISE�O DE EXPERIENCIAS DE APRENDIZAJE EN EDUCACI�N SUPERIOR            
  -- --Programa: PROGRAMAS FI >> PROGRAMA DE ACTUALIZACI�N EN TUTOR�A Y ACOMPA�AMIENTO AL ADOLESCENTE            
  -- --Programa: PROGRAMAS FI >> PROGRAMA DE ACTUALIZACION EN R�BRICAS, INSTRUMENTOS DE EVALUACI�N Y RETROALIMENTACI�            
  -- --Fin --@38            
  -- OR (@IdUnidadAcademica IN (69,70) AND @IdProducto IN (14598,14596,14594,14538)) --@38            
  --) --@38            
            
  --Inicio --@41            
  ----Inicio --@40            
  ----IF @IdUnidadAcademica IN (69,70) --@39            
  ----AND @CodigoSedeNuevo = 'IT'            
 --IF (@CodigoSedeNuevo = 'IT'             
  --  AND (@IdUnidadNegocio = 1 --Division: Carrera Profesional            
  --    OR @IdUnidadNegocio = 2)) --Division: Extension          ----Fin --@40            
  --BEGIN            
  --  SELECT @FechaInicio=CONVERT(VARCHAR(10),SEC.FechaInicio,103)            
  --  FROM Matricula MAT WITH (NOLOCK)            
  --  INNER JOIN Promocion PRM WITH (NOLOCK) ON MAT.IdPromocion = PRM.IdPromocion            
  --  INNER JOIN Producto PRD WITH (NOLOCK) ON PRM.IdProducto = PRD.IdProducto            
  --  INNER JOIN Seccion SEC WITH (NOLOCK) ON PRM.IdPromocion = SEC.IdPromocion            
  --  WHERE MAT.IdMatricula = @CurIdMatricula     
  --  AND PRM.IdProducto = @IdProducto            
  --END            
  --Fin --@41            
            
  --Inicio --@41            
         
   --Division: Carrera Profesional            
   IF @CurTipoServicio = 'C'          --INICIO @54  
   BEGIN            
    --Fecha de Inicio del Periodo            
    SELECT @FechaInicio=CONVERT(VARCHAR(10),Inicio,103) FROM Periodo WITH (NOLOCK) WHERE IdPeriodo=@IdPeriodo --@17             
   END                      
   ELSE  --Inicio @46            
   BEGIN            
  --Division: Extension    
     --Fecha de Inicio de la Seccion            
     SELECT @FechaInicio= CONVERT(VARCHAR(10),PG.FechaInicio,103)    -- @55  
     FROM Matricula MAT WITH (NOLOCK)            
	 INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON PG.IdPromocion = MAT.IdPromocion AND PG.IdGrupo = MAT.IdGrupo     --   @55        
     WHERE MAT.IdMatricula = @CurIdMatricula --Fin @46                         
   END --FIN @54  
  --Fin --@41                 
  --Fin --@37            
          
        
                    
        SET @Usuario = ISNULL(@CodigoAlumno, 'No encontrado')            
        --SET @clave ='inicio12'--@47            
  --inicio @47            
  --SELECT @clave = Clave from Usuario WITH (NOLOCK) WHERE IdActor = @CurIdAlumno AND IdTipoUsuario = 1            
  --select @passwdGenericas=Valor from Parametro WITH (NOLOCK) where Nombre='PASSWORDGENERICAS'            
  IF EXISTS(select 1 from Usuario WITH (NOLOCK) where IdActor = @CurIdAlumno and ISNULL(ClaveRobusta,'') = '' AND IdTipoUsuario = 1)            
  BEGIN            
   IF @CompaniaSocio = '00002700'            
   BEGIN            
    DECLARE @ApePaterno CHAR(1)                        
    SELECT @ApePaterno = SUBSTRING(ApellidoPaterno, 1, 1) From Usuario With(Nolock) where Login = @CodigoAlumno AND IdTipoUsuario = 1                    
    SET @clave = @CurNumeroDocumento + @ApePaterno            
   END            
   ELSE            
   BEGIN            
    SET @clave ='inicio12'            
   END            
  END            
  ELSE            
  BEGIN            
  SELECT @clave = dbo.cDesencriptaCadenaNumericaPwdAlumno(ClaveRobusta) from Usuario WITH (NOLOCK) WHERE IdActor = @CurIdAlumno AND IdTipoUsuario = 1            
  END            
  --fin @47            
            
        SET @Subject = REPLACE(@Subject, '[NombreEmpresa]', ISNULL(@NombreEmpresa, ''))    --@51         
                    
        SET @mjs = REPLACE(@mjs, '[NombreAlumno]', ISNULL(@uNombres, ''))    --@51         
        SET @mjs = REPLACE(@mjs, '[CorreoPrincipal]', ISNULL(@CorreoPrincipal, ''))--@6  --@51           
        SET @mjs = REPLACE(@mjs, '[NombreEmpresa]', ISNULL(@NombreEmpresa, '')) --@6     --@51              
  SET @mjs = REPLACE(@mjs, '[FechaInicio]', ISNULL(@FechaInicio, '')) --@17      --@51             
        SET @mjs = REPLACE(@mjs, '[WebPrincipal]',ISNULL( @WebPrincipal, '')) --@6    --@51         
        SET @mjs = REPLACE(@mjs, '[URLIMAGENES]',ISNULL( @UrlImagenes, '')) --@6    --@51         
        SET @mjs = REPLACE(@mjs, '[ZoomUrlWeb]', ISNULL(@WebZoom, ''))     --@51         
  SET @mjs = REPLACE(@mjs, '[Usuario]', ISNULL(@Usuario, ''))    --@51         
              
  SET @pieMensaje = REPLACE(@pieMensaje, '[WebPrincipal]', ISNULL(@WebPrincipal, ''))--@51                      
      --@20                  
    --  IF @IdUnidadAcademica IN (2,48) AND CHARINDEX('DIP', @ProductoNombreVal)=1 AND @CompaniaSocio = '00002500'                  
    --  BEGIN                    
    --SET @mjs = REPLACE(@mjs, '[CorreoSAE]', @CorreoSaeDip)--@6                    
            
    --  END                  
    --  IF @IdUnidadAcademica IN (2,48) AND (CHARINDEX('CUR', @ProductoNombreVal)=1 OR CHARINDEX('PROG', @ProductoNombreVal)=1 ) AND @CompaniaSocio = '00002500'                  
    --  BEGIN                  
    --SET @mjs = REPLACE(@mjs, '[CorreoSAE]', @CorreoSaeCur)--@6                   
    --  END                  
--@20                  
                    
        SeT @mjs = @mjs + @pieMensaje            
              
        IF @CompaniaSocio = '00002500' or @CompaniaSocio = '00002400'  --@12  --@50          
        BEGIN            
   SET @mjs = REPLACE(@mjs, '[Clave]', @clave)            
   SET @mjs = REPLACE(@mjs, '[CorreoCorporativoAlumno]', @Usuario + @Dominio)--@28               
              
   --Inicio --@37            
   IF @CodigoSedeNuevo = 'IT'            
   BEGIN            
    SET @profile_name_empresa = 'Avisos Smart ITS'            
   END            
   ELSE            
   BEGIN            
    SET @profile_name_empresa = 'Avisos Smart'            
   END            
   --Fin --@37            
   --INICIO --@42            
  IF @pNombreCorreoUA = 'cEnvioBienvenidaVIR' and   @IdUnidadAcademica=48            
   BEGIN            
     DECLARE                   
      @IdCorreo INT = NULL                  
      ,@jsonReturn VARCHAR(250) = ''                  
      ,@retorno VARCHAR(250) = ''                  
      ,@Url VARCHAR(5000) = ''                  
                    
      ,@IdCorreoEnvio INT = NULL                  
      ,@CodigoEnvio INT = NULL                  
      ,@NumeroEnvio BIGINT = NULL                  
      ,@MensajeRespuesta VARCHAR(5000) = ''                  
      ,@Excepcion VARCHAR(5000) = ''            
            
     EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar              
    @profile_name  ='Avisos Smart',              
    @recipients =@uEmail,                       
    @subject = @Subject,                       
    @body = @mjs,            
    @body_format = 'HTML',              
    @Estado=0,              
    @Usuario='1'     ,              
    @Disponible1 = @nombreSp,                   
    @Disponible3 = 'Bienvenida Diplomados',                
    @CodigoRemitente =   'PROVEEDOR_ITB',              
    @IdMatricula=  @CurIdMatricula;              
             
                      
      SELECT @IdCorreo = @@IDENTITY             
                    
      IF @IdCorreo IS NULL                    
BEGIN                   
      SET @Excepcion = @CodigoAlumno + ': No se gener� registro de correo'                  
            
      EXEC [dbo].[cSistemaSuceso_Ins_Grabar]                  
      @IdSistema = 57,                  
      @Login = 'EnvioCorreoITB',                  
      @Formulario = 'EnvioCorreoBienvenida',                  
      @Mensaje = @Excepcion                  
      END                  
      ELSE                  
      BEGIN                  
                    
      SELECT @Url = Valor FROM Parametro WITH(NOLOCK) WHERE Nombre = 'EnvioCorreosProveedor_DIPLOMADOS_ITB'               
             
            
      SET @Url = REPLACE(@Url, '[IdCorreo]', CONVERT(VARCHAR(20),@IdCorreo))                   
      SET @Url = REPLACE(@Url, '[mailDestination]',@uEmail)                   
      SET @Url = REPLACE(@Url, '[nombre]', @uNombres)                  
      SET @Url = REPLACE(@Url, '[fechaInicio]', @FechaInicio)                   
      SET @Url = REPLACE(@Url, '[usuarioAlumno]', @CodigoAlumno)                   
      SET @Url = REPLACE(@Url, '[passwordAlumno]', @clave)                   
      SET @Url = REPLACE(@Url, '[emailAlumno]', @Usuario + @Dominio)                   
   --   select @Url                
                    
      SELECT @retorno = dbo.GetHttp(@Url)                   
                    
      SET @jsonReturn = LEFT(@retorno, LEN(@retorno)-1);                  
      SET @jsonReturn = RIGHT(@jsonReturn, LEN(@jsonReturn)-1)                   
      SET @jsonReturn = REPLACE(@jsonReturn,'\','')                  
                    
      SELECT                  
        @IdCorreoEnvio  = idCorreo                  
        ,@CodigoEnvio  = code                  
        ,@NumeroEnvio = requestId                  
        ,@MensajeRespuesta = [message]                  
      FROM                  
        OPENJSON(@jsonReturn)                  
        WITH(                  
        idCorreo INT 'strict $.idCorreo',                  
        code INT 'strict $.code',                  
        requestId BIGINT 'strict $.requestId',                
        [message] NVARCHAR(250) 'strict $.message'                  
        )                  
                    
      IF @CodigoEnvio = 0                  
      BEGIN                  
        UPDATE BDSMTP.dbo.EnvioCorreo                  
        SET Estado = 1,                  
        Disponible2 = CONVERT(varchar,@NumeroEnvio),               
  Disponible5 = @Url,            
        UsuarioModificacion = '1',                  
        FechaModificacion = GETDATE()                  
        WHERE IdCorreo = @IdCorreoEnvio                  
      END                  
      ELSE                  
      BEGIN                   
              
        SET @Excepcion = 'IdCorreo: ' + CONVERT(VARCHAR(20),@IdCorreoEnvio) + '. ' + @MensajeRespuesta                  
                    
        EXEC [dbo].[cSistemaSuceso_Ins_Grabar]                  
        @IdSistema = 57,                  
        @Login = 'EnvioCorreoITB',                  
        @Formulario = 'EnvioCorreoBienvenida',                  
        @Mensaje = @Excepcion                  
                    
        UPDATE BDSMTP.dbo.EnvioCorreo                  
        SET Estado = -1,                  
        Disponible2 = @Excepcion,              
  Disponible5 = @Url,            
        UsuarioModificacion = '1',                  
        FechaModificacion = GETDATE()                  
        WHERE IdCorreo = @IdCorreoEnvio                  
            
      END                  
   END            
   END            
   ELSE            
   BEGIN            
   EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar --@9                  
   @recipients = @uEmail,            
   @blind_copy_recipients = @CorreoPrincipal,  --@6                
   @profile_name = @profile_name_empresa, --@37                       
   @subject = @Subject,  --@6            
   @body = @mjs,            
   @body_format = 'HTML',                   
   @Disponible1 = @nombreSp, --@31                  
   @Disponible3 = @CurIdMatricula, --@31                      
   @IdMatricula=  @CurIdMatricula; --@32              
   END            
        END            
              
          
  IF @CompaniaSocio = '00002600' AND --@49        
   NOT EXISTS(select 1 from Matricula WITH(NOLOCK)         
   where IdActor=@CurIdAlumno AND IdMatricula<>@CurIdMatricula AND EsMatricula=1 )--CORRIENTE ALTERNA @51           
   BEGIN          
   SET @mjs = REPLACE(@mjs, '[Clave]', @clave)          
   SET @mjs = REPLACE(@mjs, '[CorreoCorporativoAlumno]', @Usuario + @Dominio)             
            
             
   SET @profile_name_empresa = 'Avisos Smart'          
          
          
   EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar                 
   @recipients = @uEmail,                        
   @blind_copy_recipients = @CorreoPrincipal,                            
   @profile_name = @profile_name_empresa,                       
   @subject = @Subject,                        
   @body = @mjs,                        
   @body_format = 'HTML',                   
   @Disponible1 = @nombreSp,                 
   @Disponible3 = @CurIdMatricula,                       
   @IdMatricula=  @CurIdMatricula          
  END          
        --@15            
        IF @CompaniaSocio = '00002700'            
        BEGIN            
    --DECLARE @ApePaterno CHAR(1)--@47            
    --SELECT @ApePaterno = SUBSTRING(ApellidoPaterno, 1, 1) From Usuario With(Nolock) where Login = @CodigoAlumno--@47            
    --SET @clave = @CurNumeroDocumento + @ApePaterno--@47            
    SET @mjs = REPLACE(@mjs, '[Clave]', @clave)            
    SET @mjs = REPLACE(@mjs, '[CorreoCorporativoAlumno]', @Usuario + @Dominio)--@15                   
    DECLARE @CopiaOculta VARCHAR(500) =  @ListaCopiaCorreo  + ';' + @CorreoPrincipal             
                    
    --@31                  
    IF @pNombreCorreoUA in ('cEnvioBienvenidaCAR','cEnvioBienvenidaVIR')                 
    BEGIN                  
          
      set @IdCorreo  = NULL                  
      set @jsonReturn  = ''                  
      set @retorno = ''                  
      set @Url  = ''                  
      set @IdCorreoEnvio = NULL                  
      set @CodigoEnvio  = NULL                  
      set @NumeroEnvio  = NULL                  
      set @MensajeRespuesta  = ''                  
      set @Excepcion  = ''                 
   set @TipoCorreo =  CASE @IdUnidadAcademica WHEN 48 THEN 'Bienvenida Diplomados' ELSE 'Bienvenida' END            
            
    EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar --@9               
    @profile_name  ='Avisos Smart',              
    @recipients =@uEmail,                       
@blind_copy_recipients = @CopiaOculta,  --@6              
@subject = @Subject,  --@6            
@body = @mjs,            
@body_format = 'HTML',              
      @Estado=0,              
      @Usuario='1'     ,              
      @Disponible1 = @nombreSp, --@31                  
      @Disponible3 = @TipoCorreo,  --@31               
      @CodigoRemitente =   'PROVEEDOR_ITB',              
      @IdMatricula=  @CurIdMatricula;              
                      
                      
      SELECT @IdCorreo = @@IDENTITY                   
                    
      IF @IdCorreo IS NULL                    
      BEGIN                   
      SET @Excepcion = @CodigoAlumno + ': No se gener� registro de correo'                  
            
      EXEC [dbo].[cSistemaSuceso_Ins_Grabar]                  
      @IdSistema = 57,                  
      @Login = 'EnvioCorreoITB',                  
      @Formulario = 'EnvioCorreoBienvenida',                  
      @Mensaje = @Excepcion                  
      END                  
      ELSE                  
      BEGIN                  
        IF @IdUnidadAcademica=48             
   BEGIN            
   SELECT @Url = Valor FROM Parametro WITH(NOLOCK) WHERE Nombre = 'EnvioCorreosProveedor_DIPLOMADOS_ITB'             
            
      SET @Url = REPLACE(@Url, '[IdCorreo]', CONVERT(VARCHAR(20),@IdCorreo))                   
      SET @Url = REPLACE(@Url, '[mailDestination]', @uEmail)                   
      SET @Url = REPLACE(@Url, '[nombre]', @uNombres)                  
      SET @Url = REPLACE(@Url, '[fechaInicio]', @FechaInicio)                   
      SET @Url = REPLACE(@Url, '[usuarioAlumno]', @CodigoAlumno)                   
      SET @Url = REPLACE(@Url, '[passwordAlumno]', @clave)                
      SET @Url = REPLACE(@Url, '[emailAlumno]', @Usuario + @Dominio)                
   END            
   ELSE            
      BEGIN                  
      SELECT @Url = Valor FROM Parametro WITH(NOLOCK) WHERE Nombre = 'EnvioCorreoProveedor_ITB'                  
                    
      SET @Url = REPLACE(@Url, '[IdCorreo]', CONVERT(VARCHAR(20),@IdCorreo))                   
      SET @Url = REPLACE(@Url, '[CorreoDestinatario]', @uEmail)                   
      SET @Url = REPLACE(@Url, '[Asunto]', @Subject)                   
      SET @Url = REPLACE(@Url, '[Nombre]', @uNombres)                  
      SET @Url = REPLACE(@Url, '[FechaInicio]', @FechaInicio)                   
      SET @Url = REPLACE(@Url, '[UsuarioAlumno]', @CodigoAlumno)                   
      SET @Url = REPLACE(@Url, '[ClaveAlumno]', @clave)                   
      SET @Url = REPLACE(@Url, '[EmailAlumno]', @Usuario + @Dominio)                   
      END            
                    
      SELECT @retorno = dbo.GetHttp(@Url)                   
      --select @Url            
                    
      SET @jsonReturn = LEFT(@retorno, LEN(@retorno)-1);                  
      SET @jsonReturn = RIGHT(@jsonReturn, LEN(@jsonReturn)-1)                   
      SET @jsonReturn = REPLACE(@jsonReturn,'\','')                  
                    
      SELECT                  
        @IdCorreoEnvio  = idCorreo                  
        ,@CodigoEnvio  = code                  
        ,@NumeroEnvio  = requestId                  
        ,@MensajeRespuesta = [message]                  
      FROM                  
        OPENJSON(@jsonReturn)                  
        WITH(                  
        idCorreo INT 'strict $.idCorreo',                  
        code INT 'strict $.code',                  
        requestId BIGINT 'strict $.requestId',                
        [message] NVARCHAR(250) 'strict $.message'                  
        )                  
                    
      IF @CodigoEnvio = 0           
      BEGIN                  
        UPDATE BDSMTP.dbo.EnvioCorreo                 
        SET Estado = 1,                  
        Disponible2 = CONVERT(varchar,@NumeroEnvio),                
  Disponible5=@Url,            
        UsuarioModificacion = '1',                  
        FechaModificacion = GETDATE()                  
        WHERE IdCorreo = @IdCorreoEnvio                  
      END                  
      ELSE                  
      BEGIN                   
              
        SET @Excepcion = 'IdCorreo: ' + CONVERT(VARCHAR(20),@IdCorreoEnvio) + '. ' + @MensajeRespuesta                  
            
        EXEC [dbo].[cSistemaSuceso_Ins_Grabar]                  
        @IdSistema = 57,                  
        @Login = 'EnvioCorreoITB',                  
        @Formulario = 'EnvioCorreoBienvenida',                  
        @Mensaje = @Excepcion                  
                    
        UPDATE BDSMTP.dbo.EnvioCorreo                  
        SET Estado = -1,                  
        Disponible2 = @Excepcion,              
  Disponible5=@Url,            
        UsuarioModificacion = '1',                  
        FechaModificacion = GETDATE()                  
        WHERE IdCorreo = @IdCorreoEnvio              
            
      END                  
      END                  
                    
      END                  
      ELSE                  
      BEGIN                  
        EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar            
      @recipients = @uEmail,            
      @blind_copy_recipients = @CopiaOculta,            
      @profile_name = 'Avisos Smart',            
      @subject = @Subject,            
      @body = @mjs,            
      @body_format = 'HTML',                  
      @Disponible1 = @nombreSp, --@31                  
      @Disponible3 =  'Bienvenida' ,              
      @IdMatricula= @CurIdMatricula;                       
      END                  
      --@31                  
                    
        END            
        END            
        --Fin @14            
      END            
      END            
    END            
            
    UPDATE #Matricula            
    SET Observacion = @DESCRIPCIONERROR,            
    Estado = @EstadoMatricula,            
    CodigoAlumno = @CodigoAlumno            
    WHERE Id = @CurID            
            
    SET @CurID = @CurID + 1            
  END -- while               
             
  INSERT INTO ResultadoMatricula (IdMatricula, IdSede, IdUnidadNegocio, IdUnidadAcademica, IdPeriodo, IdProducto, ProductoNombre,            
  IdPromocion, PromocionNombre, IdGrupo, GrupoCodigo, IdActor, NombreCompleto, Observacion, Estado)            
  SELECT --Id,                      
  IdMatricula,            
  PromocionIdSede,            
  PromocionIdUnidadNegocio,            
  PromocionIdUnidadAcademica,            
  PromocionIdPeriodo,            
  PromocionIdProducto,            
  ProductoNombre,            
  IdPromocion,            
  PromocionNombre,            
  IdGrupo,            
  GrupoCodigo,            
  ActorIdActor,            
  ISNULL(CodigoAlumno, '') + '-' + ActorNombreCompleto,            
  Observacion,            
  Estado--,  IdRegistro             
  FROM #Matricula            
                      
  --select * from ResultadoMatricula  order by idmatricula desc                   
                      
  DROP TABLE #Matricula            
            
  SET NOCOUNT OFF            
END  -- FIN DEL PROCEDIMIENTO       