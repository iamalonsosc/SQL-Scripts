--SELECT*FROM AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET Subsanacion=1
WHERE IdRegistro=11 AND IdAlumno=886647 AND IdModulo=5 AND IdCurso IN (
13753
,13754
,14383
,14386
,14394)
--(5 rows affected)