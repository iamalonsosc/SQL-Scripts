--SELECT Es360, *FROM Seccion
--WHERE Codigo='03601.23.00003'

UPDATE Seccion SET Es360=1
WHERE Codigo='03601.23.00003'
--(1 row affected)