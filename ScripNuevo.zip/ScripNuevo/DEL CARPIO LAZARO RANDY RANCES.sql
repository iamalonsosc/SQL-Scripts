SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=640337


SELECT TipoCondicion,*FROM AlumnoCurso 
--UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=640337 AND EsMatricula=1

----RP(PROMOVIDO + CURSO)
----CC(CURSO REPITENCIA)
----RT(REPITENCIA)
----RE(PROMOVIDO)
