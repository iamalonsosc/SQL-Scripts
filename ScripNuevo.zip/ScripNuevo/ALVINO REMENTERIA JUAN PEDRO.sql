--SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
--INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
--WHERE AC.IdAlumno=1234974 
----AND AC.IdCurso=9934 
----AND AC.IdCursoOriginal=9934 
--AND AC.IdMatricula=673593 
----AND AC.EsMatricula=1
--order by ac.idregistro,ac.IdAlumnoCurso desc


--SELECT SE.*FROM Seccion SE
--INNER JOIN Promocion PRO ON SE.IdPromocion=PRO.IdPromocion
--WHERE SE.IdPeriodoAnual=2025 
--AND SE.IdCurso=9934 
--AND SE.IdCurricula=5604 
--AND PRO.IdSede=36
--AND PRO.PromocionCodigo LIKE '%2025-I%' 


--CONSTITUCI�N DE EMPRESAS Y NUEVOS NEGOCIOS
INSERT INTO AlumnoCurso VALUES (1234974,2,21,5604,9934,673593,97324,5,640393,null,null,'16.00','16.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'CC',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL
,PromedioFinal='16.00'
,PromedioReal= '16.00'
,IdAlumnoCurso=21
,TipoCondicion='RE'
--select*from AlumnoCurriculaCurso 
where IdAlumno=1234974 and IdCurso=9934 AND IdRegistro=2