SET NOCOUNT ON;

DECLARE @IdUsuario INT = 1; 
DECLARE @Alumnos TABLE
(
    IdMatricula INT PRIMARY KEY,
    IdPromocion INT,
    IdGrupo INT,
    IdAlumno INT
);

INSERT INTO @Alumnos
(
    IdMatricula,
    IdPromocion,
    IdGrupo,
    IdAlumno
)
SELECT DISTINCT
    M.IdMatricula,
    M.IdPromocion,
    M.IdGrupo,
    M.IdActor
FROM Matricula M WITH (NOLOCK)
INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON PG.IdPromocion = M.IdPromocion AND PG.IdGrupo = M.IdGrupo
INNER JOIN Actor AC WITH (NOLOCK)ON M.IdActor = AC.IdActor
INNER JOIN SEDE SED WITH (NOLOCK)ON SED.IdSede = M.IdSede
LEFT JOIN Alumno AL WITH (NOLOCK)ON AL.IdAlumno = M.IdActor
INNER JOIN Promocion P WITH (NOLOCK)ON P.IdPromocion = M.IdPromocion
INNER JOIN Producto PR WITH (NOLOCK)ON P.IdProducto = PR.IdProducto
LEFT JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK)ON MTR2.IdMaestroRegistro = PG.IdTipoSeccion
INNER JOIN Periodo PE WITH (NOLOCK)ON P.IdPeriodo = PE.IdPeriodo
WHERE AC.NombreCompleto IN
(
    'AGUILAR TARICUARIMA MIRNA DOLORES'
)
AND PE.Codigo IN ('2026-IIIA', '2026-III')
AND MTR2.Nombre <> 'Normal'
AND M.Estado = 'N';


SELECT
    COUNT(*) AS TotalAlumnos
FROM @Alumnos;

SELECT
    A.IdMatricula,
    A.IdPromocion,
    A.IdGrupo,
    A.IdAlumno,
    AC.NombreCompleto
FROM @Alumnos A
INNER JOIN Actor AC WITH (NOLOCK)
    ON AC.IdActor = A.IdAlumno
ORDER BY AC.NombreCompleto;

--return

DECLARE
    @IdMatricula INT,
    @IdPromocion INT,
    @IdGrupo INT,
    @IdAlumno INT,
    @IdTipoTurno INT,
    @IdTipoSeccionNormal INT,
    @IdGrupoDestino INT,
    @GrupoOrigen VARCHAR(250),
    @GrupoDestino VARCHAR(250),
    @Vacantes INT,
    @Inscritos INT,
    @VacantesDisponibles INT,
    @ErrorCodigo INT,
    @DescripcionError VARCHAR(8000),
    @NombreAlumno VARCHAR(250),
    @Estado VARCHAR(100),
    @IdSeccion INT,
    @IdCurso INT;

DECLARE @Resultado TABLE
(
    IdMatricula INT,
    IdPromocion INT,
    IdGrupoOrigen INT,
    IdGrupoDestino INT NULL,
    GrupoOrigen VARCHAR(250) NULL,
    GrupoDestino VARCHAR(250) NULL,
    NombreAlumno VARCHAR(250) NULL,
    Estado VARCHAR(100),
    Observacion VARCHAR(8000),
    VacantesDisponibles INT
);

DECLARE CursorAlumnos CURSOR LOCAL FAST_FORWARD FOR

SELECT
    IdMatricula,
    IdPromocion,
    IdGrupo,
    IdAlumno
FROM @Alumnos
ORDER BY IdMatricula;

OPEN CursorAlumnos;

FETCH NEXT FROM CursorAlumnos
INTO
    @IdMatricula,
    @IdPromocion,
    @IdGrupo,
    @IdAlumno;

WHILE @@FETCH_STATUS = 0
BEGIN

    BEGIN TRY

        SELECT
            @IdTipoTurno = NULL,
            @IdTipoSeccionNormal = NULL,
            @IdGrupoDestino = NULL,

            @GrupoOrigen = NULL,
            @GrupoDestino = NULL,

            @Vacantes = 0,
            @Inscritos = 0,
            @VacantesDisponibles = 0,

            @ErrorCodigo = 0,
            @DescripcionError = '',

            @NombreAlumno = NULL,
            @Estado = NULL,

            @IdSeccion = NULL,
            @IdCurso = NULL;

        SELECT
            @NombreAlumno = AC.NombreCompleto,
            @GrupoOrigen = PG.GrupoCodigo,
            @IdTipoTurno = T.IdTipoTurno

        FROM PromocionGrupo PG WITH (NOLOCK)

        INNER JOIN Turno T WITH (NOLOCK)
            ON T.IdTurno = PG.IdTurno

        INNER JOIN Actor AC WITH (NOLOCK)
            ON AC.IdActor = @IdAlumno

        WHERE PG.IdPromocion = @IdPromocion
        AND PG.IdGrupo = @IdGrupo;

        SELECT
            @IdTipoSeccionNormal = IdMaestroRegistro
        FROM MaestroTablaRegistro WITH (NOLOCK)
        WHERE IdMaestroTabla = 2060
        AND Codigo = 'Normal';

        IF ISNULL(@IdTipoTurno, 0) = 0
        BEGIN

            INSERT INTO @Resultado
            (
                IdMatricula,
                IdPromocion,
                IdGrupoOrigen,
                IdGrupoDestino,
                GrupoOrigen,
                GrupoDestino,
                NombreAlumno,
                Estado,
                Observacion,
                VacantesDisponibles
            )
            VALUES
            (
                @IdMatricula,
                @IdPromocion,
                @IdGrupo,
                NULL,
                @GrupoOrigen,
                NULL,
                @NombreAlumno,
                'KO',
                'No se pudo determinar el turno del grupo actual del alumno.',
                0
            );

            GOTO SIGUIENTE;

        END;

        IF ISNULL(@IdTipoSeccionNormal, 0) = 0
        BEGIN

            INSERT INTO @Resultado
            (
                IdMatricula,
                IdPromocion,
                IdGrupoOrigen,
                IdGrupoDestino,
                GrupoOrigen,
                GrupoDestino,
                NombreAlumno,
                Estado,
                Observacion,
                VacantesDisponibles
            )
            VALUES
            (
                @IdMatricula,
                @IdPromocion,
                @IdGrupo,
                NULL,
                @GrupoOrigen,
                NULL,
                @NombreAlumno,
                'KO',
                'No se encontr� configurado el tipo de secci�n Normal.',
                0
            );

            GOTO SIGUIENTE;

        END;

        ;WITH GruposDisponibles AS
        (
            SELECT
                PG.IdGrupo,
                PG.GrupoCodigo,
                PG.Vacantes,

                COUNT(DISTINCT M.IdActor) AS Inscritos,

                PG.Vacantes
                    - COUNT(DISTINCT M.IdActor)
                    AS VacantesDisponibles,

                MIN(S.IdSeccion) AS IdSeccion,
                MIN(S.IdCurso) AS IdCurso

            FROM PromocionGrupo PG WITH (NOLOCK)

            INNER JOIN Turno T WITH (NOLOCK)
                ON T.IdTurno = PG.IdTurno

            INNER JOIN Seccion S WITH (NOLOCK)
                ON S.IdPromocion = PG.IdPromocion
                AND S.IdGrupo = PG.IdGrupo

            LEFT JOIN Matricula M WITH (NOLOCK)
                ON M.IdPromocion = PG.IdPromocion
                AND M.IdGrupo = PG.IdGrupo
                AND M.Estado <> 'X'
                AND M.EsMatricula = 1

            WHERE PG.IdPromocion = @IdPromocion

            AND ISNULL
            (
                PG.IdTipoSeccion,
                @IdTipoSeccionNormal
            ) = @IdTipoSeccionNormal

            AND T.IdTipoTurno = @IdTipoTurno

            GROUP BY
                PG.IdGrupo,
                PG.GrupoCodigo,
                PG.Vacantes
        )

        SELECT TOP 1

            @IdGrupoDestino = IdGrupo,
            @GrupoDestino = GrupoCodigo,

            @Vacantes = Vacantes,
            @Inscritos = Inscritos,

            @VacantesDisponibles = VacantesDisponibles,

            @IdSeccion = IdSeccion,
            @IdCurso = IdCurso

        FROM GruposDisponibles

        WHERE VacantesDisponibles > 0

        ORDER BY
            VacantesDisponibles DESC,
            IdGrupo;

        IF ISNULL(@IdGrupoDestino, 0) = 0
        BEGIN

            INSERT INTO @Resultado
            (
                IdMatricula,
                IdPromocion,
                IdGrupoOrigen,
                IdGrupoDestino,
                GrupoOrigen,
                GrupoDestino,
                NombreAlumno,
                Estado,
                Observacion,
                VacantesDisponibles
            )
            VALUES
            (
                @IdMatricula,
                @IdPromocion,
                @IdGrupo,
                NULL,
                @GrupoOrigen,
                NULL,
                @NombreAlumno,
                'KO',
                'No se encontr� una secci�n Normal con vacantes disponibles para el mismo turno del alumno.',
                0
            );

            GOTO SIGUIENTE;

        END;

        IF dbo.cMatricula_Val_VacantePromocionGrupoSeccion
        (
            @IdPromocion,
            @IdGrupoDestino,
            @IdSeccion,
            @IdCurso
        ) = 0
        BEGIN

            INSERT INTO @Resultado
            (
                IdMatricula,
                IdPromocion,
                IdGrupoOrigen,
                IdGrupoDestino,
                GrupoOrigen,
                GrupoDestino,
                NombreAlumno,
                Estado,
                Observacion,
                VacantesDisponibles
            )
            VALUES
            (
                @IdMatricula,
                @IdPromocion,
                @IdGrupo,
                @IdGrupoDestino,
                @GrupoOrigen,
                @GrupoDestino,
                @NombreAlumno,
                'KO',
                'El grupo Normal encontrado ya no cuenta con vacantes disponibles. Vacantes disponibles: '
                    + CONVERT(VARCHAR(10), @VacantesDisponibles),
                @VacantesDisponibles
            );

            GOTO SIGUIENTE;

        END;


        --select @IdMatricula,@IdPromocion,@IdGrupoDestino,@IdUsuario,@ErrorCodigo,@DescripcionError
        UPDATE AlumnoCurso SET EsMatricula=0
        WHERE IdMatricula=@IdMatricula

        EXEC cMatricula_ProcesoxAlumno
            @IdMatricula,
            @IdPromocion,
            @IdGrupoDestino,
            @IdUsuario,
            @ErrorCodigo OUT,
            @DescripcionError OUT;

        IF @ErrorCodigo IN (1, 5)
        BEGIN

            UPDATE Matricula
            SET IdGrupo = @IdGrupoDestino
            WHERE IdMatricula = @IdMatricula;


            SET @Estado = 'OK';


            SET @DescripcionError =
                'El alumno fue trasladado correctamente del grupo Comercial '
                + ISNULL(@GrupoOrigen, '')
                + ' al grupo Normal '
                + ISNULL(@GrupoDestino, '')
                + '. Vacantes disponibles al momento del proceso: '
                + CONVERT(VARCHAR(10), @VacantesDisponibles)
                + '.';

        END;

        ELSE
        BEGIN

            SET @Estado = 'KO';


            IF ISNULL(@DescripcionError, '') = ''
            BEGIN

                SET @DescripcionError =
                    'No fue posible realizar el traslado del alumno al grupo Normal '
                    + ISNULL(@GrupoDestino, '')
                    + '. Vacantes disponibles: '
                    + CONVERT(VARCHAR(10), @VacantesDisponibles)
                    + '.';

            END;

        END;

        INSERT INTO @Resultado
        (
            IdMatricula,
            IdPromocion,
            IdGrupoOrigen,
            IdGrupoDestino,
            GrupoOrigen,
            GrupoDestino,
            NombreAlumno,
            Estado,
            Observacion,
            VacantesDisponibles
        )
        VALUES
        (
            @IdMatricula,
            @IdPromocion,
            @IdGrupo,
            @IdGrupoDestino,
            @GrupoOrigen,
            @GrupoDestino,
            @NombreAlumno,
            @Estado,
            @DescripcionError,
            @VacantesDisponibles
        );

    END TRY

    BEGIN CATCH

        INSERT INTO @Resultado
        (
            IdMatricula,
            IdPromocion,
            IdGrupoOrigen,
            IdGrupoDestino,
            GrupoOrigen,
            GrupoDestino,
            NombreAlumno,
            Estado,
            Observacion,
            VacantesDisponibles
        )
        VALUES
        (
            @IdMatricula,
            @IdPromocion,
            @IdGrupo,
            @IdGrupoDestino,
            @GrupoOrigen,
            @GrupoDestino,
            @NombreAlumno,
            'KO',
            ERROR_MESSAGE(),
            ISNULL(@VacantesDisponibles, 0)
        );

    END CATCH;

    SIGUIENTE:

    FETCH NEXT FROM CursorAlumnos
    INTO
        @IdMatricula,
        @IdPromocion,
        @IdGrupo,
        @IdAlumno;

END;

CLOSE CursorAlumnos;
DEALLOCATE CursorAlumnos;

SELECT
    IdMatricula,
    IdPromocion,
    IdGrupoOrigen,
    IdGrupoDestino,
    GrupoOrigen,
    GrupoDestino,
    NombreAlumno,
    Estado,
    Observacion,
    VacantesDisponibles
FROM @Resultado
ORDER BY
    CASE WHEN Estado = 'KO' THEN 0 ELSE 1 END,
    NombreAlumno;

SELECT
    COUNT(*) AS Total,

    SUM
    (
        CASE
            WHEN Estado = 'OK' THEN 1
            ELSE 0
        END
    ) AS Correctos,

    SUM
    (
        CASE
            WHEN Estado = 'KO' THEN 1
            ELSE 0
        END
    ) AS Errados

FROM @Resultado;


SET NOCOUNT OFF;