--DECLARE @IdMatriculaAntigua INT=611220,@IdAlumno INT=1262154,@IdMatriculaNueva INT

UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (648022,611220)


--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=1 AND IdCurso=9801 AND IdCurricula=36

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=1 AND IdCurso=10560 AND IdCurricula=36

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=1 AND IdCurso=10561 AND IdCurricula=36

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=1 AND IdCurso=10563 AND IdCurricula=36

UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=1 AND IdCurso=10577 AND IdCurricula=36



SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1262154  --AND AC.IdCurso=13514
order by ac.idregistro,ac.IdAlumnoCurso desc


--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=83
WHERE IdMatricula=782244 AND IdCurso=9801
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=84
WHERE IdMatricula=782244 AND IdCurso=10560

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=85
WHERE IdMatricula=782244 AND IdCurso=10561

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=86
WHERE IdMatricula=782244 AND IdCurso=10563

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=87
WHERE IdMatricula=782244 AND IdCurso=10577



--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=1,IdcurriculaOriginal=5614
WHERE IdMatricula=611220 AND IdCurso=9801

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=2,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=611220 AND IdCurso=10560

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=3,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=611220 AND IdCurso=10561

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=4,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=611220 AND IdCurso=10563

UPDATE AlumnoCurso SET IdRegistro=4,IdAlumnoCurso=5,IdcurriculaOriginal=5614--,IdCursoOriginal=NULL
WHERE IdMatricula=611220 AND IdCurso=10577



--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='20.00',PromedioReal='20.00',IdAlumnoCurso=1,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=9801 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='18.00',PromedioReal='17.64',IdAlumnoCurso=2,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10560 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='17.00',PromedioReal='16.68',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10561 AND IdCurricula=5614

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='14.00',PromedioReal='13.68',IdAlumnoCurso=4,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10563 AND IdCurricula=5614


UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='17.00',PromedioReal='16.72',IdAlumnoCurso=5,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1262154 AND IdRegistro=4 AND IdCurso=10577 AND IdCurricula=5614



--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=4,IdCurricula=5614
WHERE IdMatricula=611220

UPDATE Matricula SET Estado='N'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (648022)

-- Y TAMBIEN ANULAMOS LA MATRICULA ULTIMA QUE HEMOS CREADO
UPDATE Matricula SET Estado='X'
WHERE IdMatricula=782244