UPDATE Registro SET IdSede=34
WHERE IdActor=1328573 AND IdRegistro IN (1)