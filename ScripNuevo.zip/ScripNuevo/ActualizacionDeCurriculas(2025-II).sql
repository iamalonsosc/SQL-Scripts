UPDATE AC SET IdCurricula = S.IdCurricula, IdCurriculaOriginal = M.IdCurricula
--SELECT m.IdMatricula,SE.NOMBRE 'Sede'
--, un.nombre 'Division'
--, ua.nombre 'Programa'
--,pr.codigo 'Periodo'
--,CM.NombrePlanEstudio 'Plan De Estudio'
--, cm.codigo 'Curricula_Matricula'
--, p.promocionnombre 'Carrera'
--, a.NombreCompleto 'Alumno'
--,M.IdModulo 'Ciclo Matricula'
--, p.promocioncodigo 'PromocionMatricula'
--, pg.GrupoCodigo 'SeccionMatricula'
--,'HorarioNombre'=isnull(ISNULL(dbo.gFrecuenciaSeccionHorario(s.IdSeccion),''),'')  
--,ISNULL(T.Nombre,'') 'Turno'
--, case m.Estado WHEN 'N' THEN 'NORMAL'
--					 WHEN 'R' THEN 'RETIRADO'
--					 WHEN 'X' THEN 'ANULADO'
--					 ELSE M.ESTADO
--					 END 'EstadoMatricula'

--,CASE m.TipoCondicion WHEN 'RE' THEN 'PROMOVIDO' 
--							WHEN 'RT' THEN 'REPITENCIA' 
--							WHEN 'CC' THEN 'CURSO REPITENCIA' 
--							WHEN 'RP' THEN 'PROMOVIDO+CURSO' 
--							ELSE M.TipoCondicion END 'CondicionMatricula'
--, cs.CursoNombre 'CursoNombre'
--, ACC.IdModulo 'Ciclo Curso'
--, case ac.Estado WHEN 'NO' THEN 'NORMAL'
--					  WHEN 'RC' THEN 'RETIRO CICLO'
--					  WHEN 'RA' THEN 'RETIRO ASIGNATURA'
--					  ELSE ac.estado
--					  END 'EstadoCurso'
--,CASE ac.TipoCondicion WHEN 'RE' THEN 'REGULAR' 
--							 WHEN 'CC' THEN 'CURSO REPITENCIA' 
--							 WHEN 'RA' THEN 'RETIRO ASIGNATURA'  
--							 WHEN 'RC' THEN 'RETIRO CICLO' 
--							 ELSE AC.TipoCondicion
--							 END 'CondicionCurso'
--,'TipoCondicion' = CASE WHEN ACC.Subsanacion = 1 AND AC.NumVezCurso <= 1 AND P.IdPeriodoAnual >= 2019 THEN 'SUBSANA' --@9 --@16
--WHEN ACC.TipoCondicion = 'CO' THEN 'CONVALIDADO'  
--WHEN AC.TipoCondicion = 'RE' AND ISNULL(ACC.Subsanacion,0)=0  THEN 'REGULAR'
--WHEN AC.TipoCondicion = 'CC' THEN 'CURSO REPITENCIA'  
--WHEN AC.TipoCondicion = 'RP' THEN 'REGULAR + CR'  
--WHEN AC.TipoCondicion = 'EC' THEN 'EXAMEN CARGO' 
--ELSE '' --@18
--END --@7
--,AC.NumVezCurso 'Numero de vez curso'
--, isnull(acn.seccionnomina,'') 'SeccionNomina'
--,isnull(acn.Turno,'') 'HorarioNomina'
--, CASE 
--    WHEN acn.SeccionNomina IS NOT NULL 
--         AND LTRIM(RTRIM(acn.SeccionNomina)) <> '' 
--      THEN 'SI CUENTA CON SECCION NOMINA'
--    ELSE 'NO CUENTA CON SECCION DE NOMINA'
--  END AS EstadoSeccionNomina
--  ,MTR.Nombre 'Tipo Seccion'
FROM Matricula M
	INNER JOIN  Actor A ON M.IdActor = A.IdActor
	LEFT JOIN Alumno AL ON M.IdActor = AL.IdAlumno
	LEFT JOIN Promocion P ON M.IdPromocion = P.IdPromocion
	LEFT JOIN PromocionGrupo PG ON P.IdPromocion = PG.IdPromocion AND M.IdGrupo = PG.IdGrupo
	LEFT JOIN Periodo PR ON P.IdPeriodo = PR.IdPeriodo
	LEFT JOIN UnidadNegocio UN ON P.IdUnidadNegocio = UN.IdUnidadNegocio
	LEFT JOIN UnidadAcademica UA ON P.IdUnidadAcademica= UA.IdUnidadAcademica
	LEFT JOIN Curricula CM ON M.IdCurricula = CM.IdCurricula
	LEFT JOIN Curricula CP ON P.IdCurricula = CP.IdCurricula
	LEFT JOIN AlumnoCurso AC ON M.IdMatricula = AC.IdMatricula
	LEFT JOIN Promocion PAC ON AC.IdPromocion = PAC.IdPromocion
	LEFT JOIN PromocionGrupo PGAC ON AC.IdPromocion = PGAC.IdPromocion AND AC.IdGrupo = PGAC.IdGrupo
	LEFT JOIN MaestroTablaRegistro MTR ON PGAC.IdTipoSeccion=MTR.IdMaestroRegistro
	LEFT JOIN Periodo PRAC ON PAC.IdPeriodo = PRAC.IdPeriodo
	LEFT JOIN Seccion S ON AC.IdSeccion = S.Idseccion
	LEFT JOIN Curricula CAC ON AC.IdCurricula = CAC.IdCurricula
	LEFT JOIN Curricula COAC ON AC.IdCurriculaOriginal = COAC.IdCurricula
	LEFT JOIN Curricula CPAC ON PAC.IdCurricula = CPAC.IdCurricula
	LEFT JOIN Curso CS ON S.IdCurso = CS.IdCurso
	LEFT JOIN CURRICULA CSEC ON S.IdCurricula = CSEC.IdCurricula
	LEFT JOIN AlumnoCurriculaCurso ACC ON ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) = ACC.IdCurricula 
				AND AC.IdAlumno = ACC.IdAlumno AND ISNULL(AC.IdCursoOriginal, AC.IdCurso) = ACC.IdCurso 
				AND AC.IdRegistro = ACC.IdRegistro
	LEFT JOIN SEDE SE ON M.IdSede = SE.IDSEDE
	LEFT JOIN AlumnoCursoNomina ACN ON M.IdMatricula = ACN.IdMatricula AND ISNULL(AC.IDCURSOORIGINAL,AC.IdCurso) = ACN.IdCurso AND M.IdSede = SE.IDSEDE
	LEFT JOIN Ambiente AM with (nolock) ON S.idambiente=AM.idambiente
	LEFT JOIN Turno T with (nolock) ON S.IdTurno=T.IdTurno
	LEFT JOIN SeccionProfesor SP  with (nolock) ON S.IdSeccion = SP.IdSeccion and SP.EsResponsable = 1  
	LEFT JOIN Actor ACt with (nolock) ON SP.IdActor = ACt.IdActor
WHERE M.EsMatricula = 1 
	  AND AC.EsMatricula = 1 
	  AND (PR.CodigoMinedu LIKE '2025-2%' OR PRAC.CodigoMinedu LIKE '2025-2%') 
	  AND S.Idseccion IS NOT NULL  
	  AND ( ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) != M.IdCurricula OR M.IdCurricula != P.IdCurricula)
	  --AND (AC.IdCurricula != S.IdCurricula OR ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) != M.IdCurricula OR M.IdCurricula != P.IdCurricula)
	  AND PR.IdUnidadAcademica = 57
	  AND m.Estado <>'X'
	  --(4 filas afectadas)