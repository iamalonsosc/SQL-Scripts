DECLARE @Nombre VARCHAR(100)='El modulo generado es incorrecto.'
SELECT Name
FROM sys.objects
WHERE  OBJECT_DEFINITION(OBJECT_ID) LIKE '%'+@Nombre+'%'
ORDER BY type,name
go
--------
DECLARE @Nombre1 VARCHAR(100)='EXEC cProcesa_Acta_JSON_Minedu%'
SELECT Name
FROM sys.objects
WHERE  OBJECT_DEFINITION(OBJECT_ID) LIKE '%'+@Nombre1+'%'
ORDER BY type,name

/*
cAlumnoSeguimientoDetalle_Ins_Grabar
cAlumnoSeguimientoProcesa
cFER_AlumnoSeguimientoDetalleAtencionInsert
cFER_AlumnoSeguimientoDetalleAtencionSaeInsert
cUnificarActores
cActaConsolidada_Sel
*/
