--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='CC'
where IdMatricula=746807


--SELECT TipoCondicion,*FROM AlumnoCurso 
----UPDATE AlumnoCurso SET TipoCondicion='RE'
--where IdMatricula=746807 AND EsMatricula=1 


------RP(PROMOVIDO + CURSO)
------CC(CURSO REPITENCIA)
------RT(REPITENCIA)
------RE(PROMOVIDO)
--SELECT*FROM AlumnoCursoNomina WHERE IdMatricula=713661


--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET PromedioFinal='DPI',PromedioReal='DPI',PromedioCondicion='D',estado='NO'
WHERE  IdCurso in (9870,10183,10231,11602) AND IdAlumno=1736893 AND IdMatricula=746807 


UPDATE AlumnoCurriculaCurso SET PromedioFinal='00.00',PromedioReal='00.00',PromedioCondicion='D',IdAlumnoCurso=8
WHERE IdAlumno=1736893 AND IdRegistro=1 AND IdCurso in (9870)

UPDATE AlumnoCurriculaCurso SET PromedioFinal='00.00',PromedioReal='00.00',PromedioCondicion='D',IdAlumnoCurso=9
WHERE IdAlumno=1736893 AND IdRegistro=1 AND IdCurso in (10183)

UPDATE AlumnoCurriculaCurso SET PromedioFinal='00.00',PromedioReal='00.00',PromedioCondicion='D',IdAlumnoCurso=11
WHERE IdAlumno=1736893 AND IdRegistro=1 AND IdCurso in (10231)

UPDATE AlumnoCurriculaCurso SET PromedioFinal='00.00',PromedioReal='00.00',PromedioCondicion='D',IdAlumnoCurso=12
WHERE IdAlumno=1736893 AND IdRegistro=1 AND IdCurso in (11602)