DECLARE @PERIODOPROCESAR VARCHAR(50) ='2025-I'

DECLARE @TABLE TABLE 
(ID INT IDENTITY(1,1), NumeroDocumento VARCHAR(500), PERIODO VARCHAR(500), 
IDMAESTROREGISTRO INT , IDACTOR INT, nombreactor VARCHAR(500),IDMATRICULA INT, RESULTADO VARCHAR(500),IDPRODUCTO INT,CodigoSede VARCHAR(5),IdSede int,IdUnidadAcademica INT)

DECLARE @IdMaestroRegistro INT
SELECT @IdMaestroRegistro=IdMaestroRegistro FROM MaestroTablaRegistro WHERE Codigo='TIP0000043'

--=CONCATENAR("INSERT INTO @TABLE VALUES('";A2;"','";E2;"',47096,NULL,NULL,NULL,NULL,NULL,'";"LV";"',NULL,NULL)")
BEGIN 

INSERT INTO @TABLE VALUES('60797991','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('61016892','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('74022496','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('74982993','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('71982547','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('70357834','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('71292344','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('73886468','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('74073522','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)
INSERT INTO @TABLE VALUES('76223501','2024-II',@IdMaestroRegistro,NULL,NULL,NULL,NULL,NULL,'LV',NULL,NULL)

END 

--select * from MaestroTablaRegistro where  Nombre like '%BECA AMERICA TV%' AND CODIGO IN (
--'TIP0000013'
--,'TIP0000014'
--,'TIP0000017'
--,'TIP0000019')

update t set t.IDACTOR = AC.IdActor , t.nombreactor = ac. NombreCompleto
FROM @TABLE T
--INNER JOIN Alumno AL on AL.CodigoAnterior = t.CODIGOALUMNO
INNER JOIN ACTOR AC ON AC.NumeroIdentidad=t.NumeroDocumento

update t set t.idmatricula = m.idmatricula , t.IDPRODUCTO=p.IdProducto,T.IdUnidadAcademica=P.IdUnidadAcademica
FROM @TABLE T
--INNER JOIN ACTOR ac on ac.numeroidentidad = t.CODIGOALUMNO
INNER JOIN Matricula M ON M.IdActor = T.IdActor 
INNER JOIN Promocion P ON P.IdPromocion = M.IdPromocion 
INNER JOIN PERIODO PE ON PE.IdPeriodo = P.IdPeriodo  AND PE.Codigo = T.PERIODO 
WHERE PE.Codigo IN ('2024-II') 
AND M.Estado <> 'X' 
AND p.IdUnidadNegocio=1

UPDATE T SET  T.IdSede=SE.IdSede
FROM @TABLE T
INNER JOIN Sede SE ON SE.Codigo=T.CodigoSede

--SELECT*FROM @TABLE
--RETURN

--UPDATE DAB set DAB.Motivo ='Beca Contigo 2024-2 - Idat - CAMBIO A PEDIDO DE ERIKA CONTRERAS'
--,DAB.IdMaestroRegistro=T.IDMAESTROREGISTRO
--,FechaModificacion=GETDATE()
--FROM DescuentoAcademicoBase DAB
--INNER JOIN @TABLE T ON DAB.IdActor = T.IdActor  
--WHERE DAB.IdMaestroRegistro IN (29317) 
--AND DAB.PeriodoCodigo IN ('2024-IIIA','2024-III','2024-IIIB') 
--AND Activo=1


--SI EN TODO CASO ES UN NUEVO PERIODO AL QUE SE LE INSERTA EL REGISTRO, SERIA ESTE BLOQUE INCLUIRLO				
INSERT INTO DescuentoAcademicoBase 
(NumeroIdentidad,IdMaestroRegistro,IdSede,IdActor,IdDocumentoTipo,IdFacultad,IdEmpresa,IdUnidadNegocio,IdunidadAcademica,PeriodoCodigo,Activo,Motivo,UsuarioCreacion
,FechaCreacion,IdProducto  )
SELECT AC.NumeroIdentidad
,T.IDMAESTROREGISTRO
,T.IdSede
,ac.idactor
,ac.IdDocumentoTipo
,1 IdFacultad
,1 IdEmpresa
,1 IdUnidadNegocio
,T.IdunidadAcademica
,T.PERIODO  Periodo
,1 Activo
,'NUEVO DESCUENTO CA'
,1 UsuarioCreacion
,GETDATE() FechaCreacion
,IDPRODUCTO
FROM @TABLE T
INNER JOIN ACTOR ac ON ac.IdActor = t.IDACTOR
WHERE  NOT EXISTS(SELECT 1 FROM DescuentoAcademicoBase DAB WHERE DAB.IdActor=T.IDACTOR 
AND DAB.IdMaestroRegistro=T.IDMAESTROREGISTRO 
AND DAB.PeriodoCodigo IN ('2024-II')
AND  DAB.Activo=1)


--SELECT*FROM DescuentoAcademicoBase WHERE Motivo='NUEVO DESCUENTO CA'