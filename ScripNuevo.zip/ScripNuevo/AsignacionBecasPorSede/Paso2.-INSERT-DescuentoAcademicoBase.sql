declare @table table (id int identity(1,1) , idmatricula int )

 
insert  into @table
select m.IdMatricula 
FROM DescuentoAcademicoBase B
INNER JOIN MAESTROTABLAREGISTRO MTR ON MTR.IdMaestroRegistro = B.IdMaestroRegistro
inner join Actor ac on ac.IdActor = B.IdActor 
inner join MATRICULA  m on m.IdActor = ac.IdActor 
inner join Promocion p on p.IdPromocion = m.IdPromocion 
inner join Periodo pe on pe.IdPeriodo = p.IdPeriodo
left join Alumno al on al.IdAlumno = ac.IdActor  
WHERE MTR.codigo  IN ('TIP0000020','TIP0000027') and PeriodoCodigo = '2024-I'  
and pe.Codigo = '2024-I'  and m.Estado <> 'X'

declare @min int, @max int, @idmatricula int , @FechaConsulta DATE = GETDATE()

select @min = MIN (id) , @max =  MAX (id) from @table

while  @min <= @max
begin

set @idmatricula= null 

select  @idmatricula = idmatricula from @table where id = @min 

EXECUTE [dbo].[cDescuentoAlumno_Upd_AutoAsignarXmatricula] @IdMatricula = @idmatricula , @FechaConsulta = @FechaConsulta

set @min= @min + 1 
end