
-- REPORTE BECA ACTIVATE SEGUN PERIODO SI CUMPLEN REQUERIMIENTOS

CREATE TABLE #Matricula ( Id INT IDENTITY(1,1) PRIMARY KEY , IdActor INT, IdMatricula INT, IdMaestroRegistro INT, IdPromocion int, IdGrupo INT , IdModulo INT , PromocionCodigo varchar(500) ,  promocionNombre varchar(500) ,
 IdPeriodo int, PeriodoCodigo VARCHAR(100) , BaseComercial varchar(500) , BasePertence VARCHAR(500), BecaActivateActual VARCHAR(500) ,resultado varchar(500))

insert into #Matricula
select distinct m.IdActor, idmatricula , mtr.IdMaestroRegistro , p.IdPromocion , M.IdGrupo , P.IdModulo , p.PromocionCodigo , p.PromocionNombre , PE.IdPeriodo , PE.Codigo ,  
'[' + s.Codigo + '] [' + b.PeriodoCodigo + '] [' + pr.ProductoNombre + ']' , mtr.Nombre ,'NO', '' FROM MATRICULA M
INNER JOIN Promocion P ON M.IdPromocion = P.IdPromocion
INNER JOIN Periodo PE ON P.IdPeriodo = PE.IdPeriodo 
INNER JOIN DescuentoAcademicoBase B ON B.IDACTOR = M.IDACTOR 
Inner join sede s on s.IdSede = b.IdSede 
inner join Producto pr on pr.IdProducto = b.IdProducto 
INNER JOIN MAESTROTABLAREGISTRO MTR ON MTR.IdMaestroRegistro = B.IdMaestroRegistro
WHERE PE.CODIGO IN ('2024-I') AND m.Estado <> 'X' AND MTR.codigo  IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019') and B.Activo = 1 

BEGIN -- VARIABLES

	DECLARE @MIN INT , @MAX INT, @idactor int, @IdTipoConsulta int , @CompaniaSocio varchar(200) = '00002700', @Retorno int , @IdMatricula int, @PeriodoCodigo varchar(200), @NumeroIdentidad varchar(200)


	CREATE TABLE #TB_TotalMatriculas (Id INT IDENTITY(1,1),IdMatricula INT, IdRegistro INT,MatriculaEstado VARCHAR(2), 
	EsMatricula BIT, MatriculaFecha DATETIME,inscritofecha DATETIME,PromocionCodigo VARCHAR(50), PromocionNombre VARCHAR(200), 
	IdUnidadNegocio INT, IdUnidadAcademica INT,IdSede INT, IdPeriodo INT, PeriodoCodigo VARCHAR(50),IdProducto INT, ProductoSubtipo VARCHAR(100) , IdCurricula INT, 
	IdModulo INT,GrupoCodigo VARCHAR(50), IdGrupo INT,IdTurno INT, IdTipoTurno INT, TipoTurnoDispo5 VARCHAR(500) , MatriculaTipo VARCHAR(5), 
	MatriculaTipoCondicion VARCHAR(5), PromedioReal REAL, PeriodoAnterior VARCHAR(500) )

			
	DECLARE @min_mat INT, @max_mat INT , @IdMatricula_Pago  INT, @IdModulo_Pago  INT,@ConsultaCuota  INT, @IdProductoBeca INT ,@IdSedeBeca INT ,@IdperiodoBeca INT,
	@IdMatriculaBase INT, @IdCurriculaBase INT,@IdCurriculaNueva INT, @IdProductoNueva INT, @ProductoSubtipoBase VARCHAR(100), @PeriodoCodigoBase VARCHAR(50),
	@ExcluidoPorPromedio BIT = 0 , @ExcluidoPorTurno BIT = 0 ,@ExcluidoPorCondicion BIT = 0 , @ExcluidoPorRetiro BIT = 0 , @ExcluidoPorCambioSede BIT = 0 , 
	@ExcluidoPorCambioCarrera BIT = 0 , @ExcluidoPorPagoPuntual INT = 0 , @ExcluidoPorReingresante INT = 0 
	--Variables para la validaciones BecaActivate
	DECLARE @PromedioBeca REAl ,@CambioCarreraBeca INT,@ModuloBeca INT,@ValidaTipoTurno BIT = 1 , @ValidaTipoCondicion BIT = 1 , @ValidaRetiro BIT= 1  ,
	@ValidaCambioSede BIT= 1 , @ValidaPagoPuntualBeca BIT= 1 , @ValidaReingreso BIT= 1  

	DECLARE @MatSecuencial TABLE (Id INT IDENTITY(1,1) , IdMatricula INT,IdPeriodo INT, Equivalencias VARCHAR(500))
	DECLARE @MIN_SECU INT , @MAX_SECU INT, @PeriodoAnterior int, @Equivalencias varchar(200) 


	--@75 Inicio
	DECLARE @IdMaestroRegistroCT INT �
���	SELECT @IdMaestroRegistroCT = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000020' --AND @CompaniaSocio = '00002700' @80
	--@75 Fin

	--Inicio @81
	DECLARE @IdMaestroRegistroCS INT �
���	SELECT @IdMaestroRegistroCS = IdMaestroRegistro� FROM MaestroTablaRegistro WITH(NOLOCK) WHERE Codigo = 'TIP0000027'
	--Fin @81

	declare @BecaActivateAcctual varchar(500)

END


SELECT @MIN = MIN(ID), @MAX = MAX(ID) from #Matricula

Print 'Maximo: ' + convert(varchar,@MAX)

WHILE @MIN <= @MAX
BEGIN

	SET @idactor = NULL
	SET @IdTipoConsulta = NULL
	SET @IdMatricula = NULL

	SET @PeriodoCodigo = NULL
	SET @NumeroIdentidad = NULL

	TRUNCATE TABLE #TB_TotalMatriculas

	SET @min_mat  = NULL 
	SET @max_mat  = NULL
	SET @IdMatricula_Pago   = NULL 
	SET @IdModulo_Pago   = NULL SET @ConsultaCuota  = NULL 
	
	SET @IdProductoBeca = NULL 
	SET @IdSedeBeca = NULL 
	SET @IdperiodoBeca = NULL 
	SET @IdMatriculaBase = NULL 
	SET @IdCurriculaBase = NULL 
	SET @IdCurriculaNueva = NULL 
	SET @IdProductoNueva = NULL 
	SET @ProductoSubtipoBase = NULL 
	SET @PeriodoCodigoBase = NULL 
	SET @ExcluidoPorPromedio = 0 
	SET @ExcluidoPorTurno  = 0 
	SET @ExcluidoPorCondicion  = 0 
	SET @ExcluidoPorRetiro  = 0 
	SET @ExcluidoPorCambioSede  = 0 
	SET @ExcluidoPorCambioCarrera  = 0 
	SET @ExcluidoPorPagoPuntual  = 0 
	SET @ExcluidoPorReingresante  = 0  

	SET @PromedioBeca = NULL
	SET @CambioCarreraBeca=NULL
	SET @ModuloBeca=NULL
	SET @ValidaRetiro=NULL
	SET @ValidaCambioSede=NULL
	SET @ValidaTipoCondicion=NULL
	SET @ValidaPagoPuntualBeca=NULL
	SET @ValidaTipoTurno= NULL
	SET @ValidaReingreso = NULL

	SET @BecaActivateAcctual = NULL 

	select @idactor = IdActor , @IdTipoConsulta = IdMaestroRegistro , @IdMatricula = IdMatricula  
	from #Matricula where Id = @MIN 

	SET @BecaActivateAcctual = (SELECT distinct mtr.Nombre FROM DescuentoAlumnoResultado R 
		INNER JOIN DescuentoAcademicoPoblacion P ON P.IdDescuentoAcademico = R.IdDescuentoAcademico 
		INNER JOIN MaestroTablaRegistro MTR ON MTR.IdMaestroRegistro = P.IdTipoSituacionAlumno
		INNER JOIN CO_Interfase_P09_Header H ON H.IdMatricula = R.IdMatricula AND R.Cuota = H.CuotaNumero AND H.Estado NOT IN ('NC','CO')
		WHERE R.IdMatricula = @IdMatricula AND MTR.codigo  IN ('TIP0000013','TIP0000014','TIP0000017','TIP0000019'))
		

	-- VALIDAMOS SI TIENE EL DESCUENTO ACTUALMENTE
	IF ISNULL(@BecaActivateAcctual,'') <> ''
	BEGIN
		UPDATE #Matricula SET BecaActivateActual  = @BecaActivateAcctual  WHERE Id = @MIN 
	END

	-- INICIA VALIDACION 
	BEGIN 

			SELECT @PromedioBeca = Disponible1,
			@CambioCarreraBeca=Disponible3,
			@ModuloBeca=Disponible5,
			@ValidaRetiro=Disponible2,
			@ValidaCambioSede=Disponible4,
			@ValidaTipoCondicion=Disponible6,
			@ValidaPagoPuntualBeca=Disponible7,
			@ValidaTipoTurno= Disponible8, 
			@ValidaReingreso = Disponible9
			FROM MaestroTablaRegistro WITH(NOLOCK) WHERE  IdmaestroRegistro = @IdTipoConsulta
			
			--Periodos Pago puntual	
			SELECT @PeriodoCodigo = Valor FROM Parametro WITH(NOLOCK) WHERE NOMBRE = 'PERVALBECAACTIVA' 	

			--Recuperamos el NumeroIdentidad para validar si esta en la base y esta activo el descuento 
			SELECT @NumeroIdentidad = NumeroIdentidad  FROM Actor WITH(NOLOCK) WHERE IdActor = @IdActor and Tipo = 'P' 
			--Recuperamos Variables de la Base de la Beca Activate, obtenemos el ultimo si tiene mas de 1 por reingreso
			SELECT TOP 1 @IdProductoBeca =IdProducto ,@IdSedeBeca= IdSede ,@IdperiodoBeca=IdPeriodo 
			FROM DescuentoAcademicoBase WITH(NOLOCK) 
			WHERE IdMaestroRegistro = @IdTipoConsulta  AND Activo = 1 AND NumeroIdentidad = @NumeroIdentidad--@53
			ORDER BY IdDescuentoAcademicoBase DESC 

			--Validamos que Exista en la base, todos deben tener el idperiodo de su captacion  
			IF ISNULL(@IdperiodoBeca,0) > 1 AND ISNULL(@IdProductoBeca,0) > 1
			BEGIN
		
				INSERT INTO #TB_TotalMatriculas
				SELECT MA.Idmatricula, MA.IdRegistro, MA.Estado MatriculaEstado, MA.EsMatricula ,MA.MatriculaFecha,MA.inscritofecha, P.PromocionCodigo, 
				P.PromocionNombre , P.IdUnidadNegocio , P.IdUnidadAcademica , P.IdSede ,P.IdPeriodo ,PE.Codigo , RE.IdProducto , PRS.Nombre ProductoSubtipo , 
				P.IdCurricula , P.IdModulo , PG.GrupoCodigo, PG.IdGrupo , TU.IdTurno , TU.IdTipoTurno ,MTR.Disponible5 TipoTurnoDispo5, 
				MA.Tipo MatriculaTipo ,CASE WHEN MA.TipoCondicion IN ('CC','RT') THEN 'RT' ELSE 'RE' END MatriculaTipoCondicion,PGC.PromedioReal,
				ISNULL ( STUFF((  SELECT ',' + CONVERT(VARCHAR,PEEQ.IdPeriodoEquivalencia)  FROM PeriodoEquivalencia PEEQ 
								  INNER JOIN Periodo PH ON PEEQ.IdPeriodoEquivalencia = PH.IdPeriodo  
								   WHERE PEEQ.IdPeriodoPadre = P.IdPeriodo AND PEEQ.EsSiguiente = 0
								   FOR XML PATH('')
										),1,1,'') , '' ) PeriodoAnterior  
				FROM Matricula MA WITH(NOLOCK)
				INNER JOIN Registro RE WITH(NOLOCK) ON RE.IdActor=MA.IdActor AND RE.IdRegistro=MA.IdRegistro
				INNER JOIN producto PR WITH(NOLOCK) ON  RE.idproducto = PR.idproducto
				INNER JOIN subtipo PRS WITH(NOLOCK) ON  PR.idsubtipo = PRS.idsubtipo 
				INNER JOIN Promocion P WITH(NOLOCK) ON MA.IdPromocion = P.IdPromocion
				INNER JOIN Periodo PE WITH(NOLOCK) ON  P.IdPeriodo = PE.IdPeriodo 
				INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion AND MA.IdGrupo = PG.IdGrupo 
				INNER JOIN Turno TU WITH(NOLOCK) ON PG.idturno = TU.idturno 
				INNER JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.idmaestroregistro=tu.idtipoturno
				LEFT JOIN PromocionGrupoCierre PGC WITH(NOLOCK) ON MA.IdMatricula = PGC.IdMatricula 
				WHERE MA.IdActor=@IdActor  AND MA.Estado <> 'X' AND P.IdUnidadNegocio = 1 -- solo carreras

				-- Validamos si la matricula actual existe 
				IF EXISTS(SELECT 1 FROM #TB_TotalMatriculas WHERE IdMatricula = @IdMatricula)
				BEGIN

					-- validamos que exista su matricula su captacion (o segun la base entregada)
					SELECT @IdMatriculaBase = IdMatricula , @IdCurriculaBase = IdCurricula , @ProductoSubtipoBase = ProductoSubtipo , @PeriodoCodigoBase = PeriodoCodigo  
					FROM #TB_TotalMatriculas where IdPeriodo = @IdperiodoBeca AND IdProducto = @IdProductoBeca 

					IF (ISNULL(@IdMatriculaBase,0)>0)
					BEGIN
						-- Eliminamos matriculas atras de la matricula base por ser matriculas pasadas de carreras
						DELETE FROM #TB_TotalMatriculas WHERE IdMatricula < @IdMatriculaBase 

						DELETE FROM #TB_TotalMatriculas WHERE PromocionNombre LIKE '%AS400%' AND @CompaniaSocio = '00002700' -- eliminamos todas las matriculas antiguas de migracion as400

						-- si la base es CCM es una malla paralela(antigua) y tiene un cambio de malla a la oficial CPT
						IF (@ProductoSubtipoBase = 'CCM' AND @CompaniaSocio = '00002700' )
						BEGIN
							SELECT  @IdCurriculaNueva = IdCurriculaNueva , @IdProductoNueva = IdProductoNueva 
							FROM CambioProductoCurricula WITH(NOLOCK)
							WHERE IdAlumno=@IdActor and Estado=1 AND IdProductoAnterior = @IdProductoBeca AND IdCurriculaAnterior = @IdCurriculaBase
						END
						
						-- Solo dejamos las matriculas con el producto(carrera) que tienen beca 
						DELETE FROM #TB_TotalMatriculas WHERE IdProducto <> @IdProductoBeca AND IdProducto <> ISNULL(@IdProductoNueva,-1)  

						-- validamos si la matricula de consulta existe en las matriculas con becas 
						IF EXISTS(SELECT 1 FROM #TB_TotalMatriculas WHERE IdMatricula = @IdMatricula)
						BEGIN

							-- Validamos que no tenga cambio de turno en su carrera
							IF(SELECT COUNT(1) FROM (SELECT DISTINCT IdTipoTurno� FROM #TB_TotalMatriculas WHERE PeriodoCodigo NOT IN 
								(SELECT PeriodoCodigo FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor� 
									AND IdMaestroRegistro = @IdMaestroRegistroCT AND B.Activo = 1) ) T ) > 1 --@75
							BEGIN

								update #Matricula set resultado = 'Excluido Por Turno'
								where id = @MIN 

							
								SET @ExcluidoPorTurno=1
							END 

							-- Validamos que siempre sea un alumno regular en su carrera
							IF EXISTS(SELECT 1 FROM #TB_TotalMatriculas WHERE MatriculaTipoCondicion <> 'RE')
							BEGIN
								update #Matricula set resultado =  'Excluido Por Condicion Matricula'
								where id = @MIN 
							
								SET @ExcluidoPorCondicion=1
							END 
							
							-- Validamos que no tenga retiro de ciclo en su carrera
							IF EXISTS(SELECT 1 FROM MatriculaRetiro WITH(NOLOCK) WHERE IdActor=@IdActor AND Estado='R' AND Tipo='RC' 
										AND IdMatricula IN (SELECT IdMatricula FROM #TB_TotalMatriculas))
							BEGIN

							update #Matricula set resultado =  'Excluido Por Retiro de Ciclo'
								where id = @MIN 

								--PRINT 
								SET @ExcluidoPorRetiro=1
							END

							-- Si es 0, valida reingreso --@67
							IF @ValidaReingreso = 0  -- @66 
							BEGIN
								-- validamos si dejo de estudiar un ciclo 
								DELETE FROM @MatSecuencial
								SET @MIN_SECU = NULL 
								SET @MAX_SECU = NULL 

								INSERT INTO @MatSecuencial
								SELECT  IdMatricula,IdPeriodo , PeriodoAnterior  FROM #TB_TotalMatriculas ORDER BY IdMatricula desc

								SELECT @MIN_SECU = MIN(Id) ,@MAX_SECU = MAX(Id)  FROM @MatSecuencial

								WHILE @MIN_SECU <= @MAX_SECU
								BEGIN

									set @PeriodoAnterior = null
									set @Equivalencias = null

									SELECT @Equivalencias =  Equivalencias FROM @MatSecuencial WHERE ID = @MIN_SECU
									SELECT @PeriodoAnterior = idperiodo FROM @MatSecuencial WHERE ID = @MIN_SECU + 1

									IF @PeriodoAnterior is not null -- si es null significa que no tiene matricula anterior 
									BEGIN
										IF @Equivalencias not like '%'+convert(varchar(100),@PeriodoAnterior)+'%'
										BEGIN

										update #Matricula set resultado =  'Excluido Por Reingresantes'
										where id = @MIN 

										--PRINT 'BUCLE....  REINGRESO'
											
											SET @ExcluidoPorReingresante =1
										END
									END

									SET @MIN_SECU = @MIN_SECU + 1 
								END 
							END
							ELSE
							-- Si es distinto a 0, no valida reingreso y se setea variable para excluir validacion por reingreso
							BEGIN
								SET @ExcluidoPorReingresante = @ValidaReingreso
							END
							-- Validamos que su promedio sea mayor a 18 en su carrera
							IF EXISTS(SELECT 1  from #TB_TotalMatriculas WHERE IdMatricula <> @IdMatricula AND PromedioReal<@PromedioBeca)
							BEGIN
							
								update #Matricula set resultado =  'Excluido Por Promedio'
										where id = @MIN 

								SET @ExcluidoPorPromedio = 1
							END

							-- Validamos que no tenga cambio de sede en su carrera
							IF EXISTS(SELECT 1 FROM TrasladoSede WITH(NOLOCK) WHERE IdAlumno=@IdActor AND Estado=1 AND IdSede<>IdSedeOrigen AND IDRegistro NOT IN  --Inicio @81
							(SELECT IdRegistro FROM #TB_TotalMatriculas WHERE PeriodoCodigo IN(SELECT PeriodoCodigo FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor� 
							AND IdMaestroRegistro = @IdMaestroRegistroCS AND B.Activo = 1)))
							OR ((SELECT COUNT(1) FROM (SELECT DISTINCT IdSede� FROM #TB_TotalMatriculas WHERE PeriodoCodigo NOT IN 
								(SELECT PeriodoCodigo FROM DescuentoAcademicoBase B WITH(NOLOCK) WHERE IdActor� = @IdActor� 
									AND IdMaestroRegistro = @IdMaestroRegistroCS AND B.Activo = 1) ) T ) > 1) --Fin @81
							BEGIN

							update #Matricula set resultado = 'Excluido Por Cambio de Sede'
										where id = @MIN 

								
								SET @ExcluidoPorCambioSede=1
							END

							--Validamos Pago puntual en su carrera
							SET @ExcluidoPorPagoPuntual = 0 
							IF @PeriodoCodigoBase NOT IN  (select Data from [dbo].[Split] (@PeriodoCodigo,',')) -- Para algunos periodos Base No se valida Pago Puntual
							BEGIN
					
								SET @min_mat = NULL 
								SET @max_mat = NULL

								SELECT @min_mat = MIN(Id), @max_mat = MAX(Id) FROM #TB_TotalMatriculas

								WHILE @min_mat <= @max_mat 
								BEGIN

									SET @IdMatricula_Pago = null SET @IdModulo_Pago = NULL SET @ConsultaCuota = NULL  
									SELECT @IdMatricula_Pago = IdMatricula , @IdModulo_Pago = IdModulo FROM #TB_TotalMatriculas WHERE ID = @min_mat

									
									-- Cuando es primer ciclo validamos de la 2da cuota si no de la 1ra
									SET @ConsultaCuota = CASE WHEN @IdModulo_Pago = 1 THEN 2 ELSE 1 END 

									
									select  @ExcluidoPorPagoPuntual = COUNT(1) from (
									SELECT DISTINCT   CO.CompaniaSocio,    
									CO.TipoDocumento,                                   
									CO.NumeroDocumento,    
									'FechaDocumento'=CASE 
									WHEN CO.Estado = 'PR' THEN  CONVERT(VARCHAR(10),GETDATE(),112)
									WHEN @CompaniaSocio='00002600'	AND CONVERT(VARCHAR(10),CO.FechaDocumento,112) > CONVERT(VARCHAR(10),CO.FechaVencimiento,112)	--@3
									THEN CONVERT(VARCHAR(10),isnull(CoDet.fechadeposito,cobranza.FechaCobranza),112) 
									WHEN CONVERT(VARCHAR(10),Cobranza.FechaCobranza,112) < CONVERT(VARCHAR(10),CO.FechaDocumento,112) THEN CONVERT(VARCHAR(10),Cobranza.FechaCobranza,112)
									ELSE CONVERT(VARCHAR(10),CO.FechaDocumento,112)
									END,--@6
									'FechaVencimiento'=CONVERT(VARCHAR(10),CO.FechaVencimiento,112),  --@1  
									'FechaCobranza'=CONVERT(VARCHAR(10),Cobranza.FechaCobranza,112),  --@1   
									co.interfase_matricula,  
									co.interfase_cuota,  
									'NumeroInterno'=ISNULL(CO.NumeroInterno,''),    
									'IdActor'=pe.PersonaAnt  
									FROM dbo.vw_CO_Documento AS CO WITH (NOLOCK)    
									INNER JOIN dbo.vw_CO_DocumentoDetalle AS Cdd WITH(NOLOCK) ON CO.TipoDocumento = Cdd.TipoDocumento  AND CO.NumeroDocumento = Cdd.NumeroDocumento and cdd.CompaniaSocio=@CompaniaSocio   
									INNER JOIN dbo.vw_personamast AS pe WITH (NOLOCK) ON CO.ClienteNumero=pe.persona  
									LEFT JOIN dbo.vw_CO_DocumentoCobranza AS Dc WITH(NOLOCK) ON  CO.TipoDocumento = Dc.TipoDocumento AND CO.NumeroDocumento = Dc.NumeroDocumento and Dc.CompaniaSocio=@CompaniaSocio    
									LEFT JOIN dbo.vw_CO_Cobranza AS Cobranza WITH(NOLOCK) 	ON Dc.CobranzaNumero = Cobranza.CobranzaNumero and Cobranza.CompaniaSocio=@CompaniaSocio   
									LEFT JOIN dbo.vw_Co_CobranzaDetalle AS CoDet WITH(NOLOCK) ON CoDet.CobranzaNumero = Cobranza.CobranzaNumero and CoDet.TipoPago <> '21'--@3    
									WHERE pe.PersonaAnt=CONVERT(VARCHAR,@IdActor)     
									and co.CompaniaSocio=@CompaniaSocio            
									AND CO.Estado IN ('CO','PR')   --@5      
									and co.interfase_matricula= @IdMatricula_Pago      
									and co.TipoFacturacion  in ('NOR')    
									and co.Interfase_Cuota >= @ConsultaCuota  ) T
									WHERE FechaDocumento>FechaVencimiento 
									
									IF ISNULL(@ExcluidoPorPagoPuntual,0) = 0
									BEGIN
										SET @ExcluidoPorPagoPuntual = 0
									END
									ELSE
									BEGIN
										SET @ExcluidoPorPagoPuntual = 1
									END 

									

									--SET @ExcluidoPorPagoPuntual=ISNULL((SELECT dbo.cPagoPuntual (@IdActor,@CompaniaSocio,@IdMatricula_Pago, @ConsultaCuota)),0)

									IF @ExcluidoPorPagoPuntual = 1 
									BEGIN

										update #Matricula set resultado = 'Excluido Por Pago Puntual'
										where id = @MIN 

										SET @min_mat = @max_mat + 1000
									END

									--PRINT 'BUCLE....  PAGO .. MIN: ' + CONVERT(VARCHAR,@min_mat) 
									SET @min_mat = @min_mat + 1
								END 
							END

							--  Validamos si le corresponde la beca
							IF @ExcluidoPorTurno = CASE WHEN @ValidaTipoTurno=1 THEN @ExcluidoPorTurno ELSE @ValidaTipoTurno END	---@69
								AND @ExcluidoPorCondicion = @ValidaTipoCondicion 
								AND @ExcluidoPorRetiro = CASE WHEN @ValidaRetiro=1 THEN @ExcluidoPorRetiro ELSE @ValidaRetiro END	---@69
								AND @ExcluidoPorCambioSede = CASE WHEN @ValidaCambioSede=1 THEN @ExcluidoPorCambioSede ELSE @ValidaCambioSede END ---@69
								AND @ExcluidoPorReingresante = @ValidaReingreso
							BEGIN

								IF NOT EXISTS (SELECT 1 FROM #TB_TotalMatriculas WHERE IdMatricula = @IdMatricula AND IdModulo > @ModuloBeca)
								BEGIN
								
										update #Matricula set resultado = 'SI LE CORRESPONDE EL DESCUENTO, X2 CICLOS'
										where id = @MIN 
										SET @Retorno = 1
									 
								END
								ELSE
								BEGIN
									IF ISNULL(@ExcluidoPorPagoPuntual,0) = @ValidaPagoPuntualBeca AND @ExcluidoPorPromedio = 0
									BEGIN
										
										update #Matricula set resultado = 'SI LE CORRESPONDE EL DESCUENTO'
										where id = @MIN 


										SET @Retorno = 1
										 		
									END
									ELSE
									BEGIN

										-- solo se valida algunas variables
										update #Matricula set resultado = 'Perdio la beca por: ' + ISNULL(resultado,'') where id = @MIN 
										--PRINT 'NO LE CORRESPONDE LA BECA, por pago o promedio'
										SET @Retorno = 0
										 
									END
								END
							END
							ELSE
							BEGIN

								update #Matricula set resultado = 'Perdio la beca por: ' + ISNULL(resultado,'') where id = @MIN 
								--PRINT 'No le corresponde la beca, No cumple algunas de las condiciones'
								SET @Retorno = 0
								 
							END 
						END
						ELSE
						BEGIN
								update #Matricula set resultado = 
							 'No existe Matricula en la carrera (producto) indicada en la Base comercial'
							where id = @MIN 
							 
						END
					END
					ELSE
					BEGIN
						update #Matricula set resultado = 
						 'No existe Matricula en la Base comercial'
						where id = @MIN 
						  
					END 
				END
				ELSE
				BEGIN
					update #Matricula set resultado = 
					 'No existe Matricula o Pre matricula completa para consultar'
					where id = @MIN 
					  
				END
			END
			ELSE
			BEGIN

				update #Matricula set resultado = 
				'No existe en la Base o registros no estan correctos, campos obligatorios(Idperiodo,IdProducto,Activo y NumeroIdentidad )'
				where id = @MIN 
				      
			END


	END 

	print 'conteo.. ' + convert(varchar,@MIN)
SET @MIN = @MIN + 1 
END 


SELECT m.IdMatricula , m.IdMaestroRegistro , m.IdActor , AL.CodigoAnterior , AC.NombreCompleto , ac.NumeroIdentidad  ,
'BaseInicioComercial' = m.BaseComercial , 'BecaInicialComercial' = m.BasePertence , m.BecaActivateActual 
, m.PeriodoCodigo , M.IdModulo 'Modulo' , m.PromocionCodigo ,m.promocionNombre ,  PG.GrupoCodigo , 
CASE WHEN MA.EsMatricula = 1 THEN 'MATRICULADO' ELSE 'PRE' END Estado , 
 CASE WHEN MA.CondicionPago  = 'Q' THEN 'CUOTAS' ELSE 'CONTADO' END CondicionPago , 
'Observacion' = resultado  FROM #Matricula M
INNER JOIN MATRICULA MA ON MA.IdMatricula = M.IdMatricula 
INNER JOIN ACTOR AC ON AC.IdActor = M.IdActor 
INNER JOIN ALUMNO AL ON AL.IdAlumno = AC.IdActor 
LEFT JOIN PromocionGrupo PG ON PG.IdPromocion = M.IdPromocion AND PG.IdGrupo = M.IdGrupo 
LEFT JOIN Turno T ON T.IdTurno = PG.IdTurno 
LEFT JOIN MaestroTablaRegistro TT ON TT.IdMaestroRegistro = T.IdTipoTurno 

DROP TABLE #Matricula
DROP TABLE #TB_TotalMatriculas



