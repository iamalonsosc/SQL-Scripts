exec cAlumnoCursoNota_Sel_Listar @IdSeccion=654325,@IdAlumno=1670777		
	
exec cAlumnoCursoNota_Sel_Listar @IdSeccion=653317,@IdAlumno=1703844	
	


SELECT*FROM AlumnoCursoNota WHERE IdAlumno=1670777 and IdSeccion=654325

SELECT*FROM AlumnoCursoNota WHERE IdAlumno=1703844 and IdSeccion=653317