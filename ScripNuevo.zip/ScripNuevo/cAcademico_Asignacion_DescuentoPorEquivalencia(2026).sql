﻿
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 --=============================================        
 --Author:  ALSANCHEZ        
 --Create date: 05/05/2025        
 --Description: Actualizaremos el grupo descuento del header del alumno en spring
 --=============================================        
/*        
---------------------------------------------------------------------------                  
Nro  FECHA   USUARIO   DESCRIPCION                  
---------------------------------------------------------------------------        
@1	21.05.2025	ALSANCHEZ	Se retira validacion por fecha actual, y se vuelve masivo
@2	22.05.2025	ALSANCHEZ	Se eliminan los documentos que ya se encuentran en cobrado
@3	22.05.2025	ALSANCHEZ	Se agrega ISNULL ya que hay null en el header
@4	22.05.2025	ALSANCHEZ	Se agrega case con las validaciones que puede tener el alumno durante el envio de correo
@5	23.05.2025	ALSANCHEZ	Se agrega campo nombre descuento para el envio de correo
@6	23.06.2025	ALSANCHEZ	Se agrega unidad academica para Zegel
@7	25.07.2025	ALSANCHEZ	Se agrega un nuevo campo ESTADO para solo traer los ACTIVOS
@8	04.08.2025	ALSANCHEZ	Se agrega nueva condicion para solo VALIDAR a los alumnos que estan dentro de las EQUIVALENCIAS
@9	12.08.2025	ALSANCHEZ	Se maneja de forma automatica el desactivo de los periodos a iniciar
*/ 
--CREATE PROCEDURE [dbo].[cAcademico_Asignacion_DescuentoPorEquivalencia]

--AS        
BEGIN
SET NOCOUNT ON
	DECLARE 
		@CuotaNumero INT
		,@GrupoOrigen varchar(100)
		,@CompaniaSocio VARCHAR(8)
		,@IdMatricula INT
		,@GrupoCombinacion INT
		,@MIN INT
		,@MAX INT
		,@p6 nvarchar(max)
		,@IdActor INT
		,@IdTipo INT
		,@NombreCorto varchar(100)
		,@PeriodosValidar VARCHAR(50)

	DECLARE @AlumnosMatriculados TABLE  (
		ID INT IDENTITY(1,1)
		,CuotaNumero INT
		,IdMatricula INT
		,IdActor INT
		,NombreCompleto VARCHAR(250)
		,PromocionNombre VARCHAR(250)
		,PromocionCodigo VARCHAR(250)
		,Periodo VARCHAR(10)
		,IdUnidadAcademica INT
		,GrupoDescuento INT
	);

	DECLARE @AlumnosCumplenRequisitos TABLE  (
		ID INT IDENTITY(1,1)
		,CuotaNumero INT
		,Monto DECIMAL(18,2)
		,GrupoDescuento INT
		,GrupoCombinacion VARCHAR(50)
		,IdMatricula INT
		,IdActor INT
	);

	DECLARE @AlumnosSinDescuento AS TABLE 
		(id int IDENTITY (1,1)
		,IdActor VARCHAR (50)
		,IdMatricula VARCHAR (50)
		,NombreCompleto VARCHAR (250)
		,PromocionNombre VARCHAR(255)
		,PromoCionCodigo VARCHAR(255)
		,Periodo VARCHAR (50)
		,CuotaNumero INT
		,GrupoDescuento INT
		,NombreDescuento VARCHAR(255)
		,Observacion VARCHAR(255)
	);

	DECLARE @TempPeriodo TABLE
		(Periodo VARCHAR(20),
		FechaInicio DATE,
		IdUnidadAcademica INT,
		Estado BIT)

	SELECT @CompaniaSocio=CompaniaSocio FROM  Empresa WITH (NOLOCK)-- SACAMOS LA COMPAÑIA
	SELECT @IdTipo = IdMaestroRegistro FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo='DESVALENCIA'-- BUSCAMOS EL TIPO DEL DESCUENTO COMBINACION
	SELECT @NombreCorto  = NombreCorto FROM Empresa WITH (NOLOCK) WHERE IdEmpresa = 1-- BUSCAMOS EL NOMBRE CORTO
	SET @PeriodosValidar = ISNULL((Select Valor from Parametro WITH(NOLOCK) where Nombre='PeriodosValidarDescuento' AND Valor2=@CompaniaSocio AND Activo=1),'')--BUSCAMOS LOS PERIODOS QUE VALIDAREMOS EN IDAT O ZEGEL

	--INSERTAMOS LOS PERIODOS A VALIDAR POR MARCA
	--@9
	INSERT INTO @TempPeriodo
		SELECT DISTINCT
			P.txt_value AS Periodo,
			PE.Inicio,
			PE.IdUnidadAcademica,
			CASE 
				WHEN PE.Inicio <= CAST(GETDATE() AS DATE) THEN 0  -- Ya inició → inactivo
				ELSE 1  -- Todavía no inicia → activo
			END AS Estado
		FROM dbo.uf_Parse(@PeriodosValidar, ',') P
		LEFT JOIN Periodo PE ON P.txt_value = PE.Codigo
		WHERE PE.IdUnidadAcademica IN (60, 57, 1)
		----@9
		select*From @TempPeriodo
		return
-- PRIMERO ESTAMOS SACANDO LOS DATOS NECESARIOS DE LA MATRICULA ACTUAL DEL ALUMNO, PARA PODER TENER LAS CUOTAS
	INSERT INTO @AlumnosMatriculados
		SELECT DISTINCT  
		'CuotaNumero' = 3-- COLOCAMOS EN DURO LA CUOTA QUE TENEMOS QUE VALIDARLE EN ESTE CASO LA SEGUNDA CUOTA
		,MA.IdMatricula
		,MA.IdActor
		,AC.NombreCompleto
		,PRO.PromocionNombre
		,PRO.PromocionCodigo
		,PE.Codigo
		,PRO.IdUnidadAcademica
		,DAR.GrupoDescuento
		FROM Matricula MA WITH(NOLOCK)
		INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK)ON MA.IdMatricula=DAR.IdMatricula 
		INNER JOIN Promocion PRO WITH(NOLOCK)ON MA.IdPromocion = PRO.IdPromocion 
		INNER JOIN Periodo PE WITH(NOLOCK)ON PRO.IdPeriodo = PE.IdPeriodo
		INNER JOIN Actor AC WITH(NOLOCK)ON MA.IdActor=AC.IdActor
		INNER JOIN @TempPeriodo TP ON TP.Periodo = PE.Codigo AND TP.IdUnidadAcademica = PRO.IdUnidadAcademica AND TP.Estado = 1--@9
		
WHERE DAR.GrupoDescuento = 1905 --VALIDAMOS QUE SEAN CUOTAS 100% GRATIS
		AND DAR.Cuota = 2 
		AND MA.Estado ='N'
		AND MA.EsMatricula=1
		--AND PRO.IdUnidadAcademica IN (60,57,1)--@6 SE COMENTA PORQUE SE REEMPLAZA POR EL PUNTO 9
		AND PRO.IdUnidadNegocio
 =1
		--AND PE.Codigo IN ((Select isnull(Periodo,'') FROM @TempPeriodo))--CONSULTAMOS LOS PERIODOS QUE PARAMETRIZAMOS (SE COMENTA PORQUE SE REEMPLAZA POR EL PUNTO 9)
		AND MA.IdModulo=1
		AND MA.TipoCondicion='RE'
		AND MA.TipoServicio='P'
		--AND MA.MatriculaFecha=GETDATE() @1
	
	INSERT INTO @AlumnosMatriculados
		SELECT DISTINCT  
		DAR.Cuota -- COLOCAMOS LA CUOTA QUE SE LE VA A VALIDAR AL ALUMNO
		,MA.IdMatricula
		,MA.IdActor
		,AC.NombreCompleto
		,PRO.PromocionNombre
		,PRO.PromocionCodigo
		,PE.Codigo
		,PRO.IdUnidadAcademica
		,DAR.GrupoDescuento
		FROM Matricula  MA WITH(NOLOCK)
		INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON MA.IdMatricula=DAR.IdMatricula
		INNER JOIN Promocion PRO WITH(NOLOCK) ON MA.IdPromocion = PRO.IdPromocion
		INNER JOIN Periodo PE WITH(NOLOCK) ON PRO.IdPeriodo = PE.IdPeriodo 
		INNER JOIN Actor AC WITH(NOLOCK)ON MA.IdActor=AC.IdActor
		INNER JOIN @TempPeriodo TP ON TP.Periodo = PE.Codigo AND TP.IdUnidadAcademica = PRO.IdUnidadAcademica AND TP.Estado = 1--@9
		WHERE  DAR.GrupoDescuento <> 1905 --VALIDAMOS QUE SEAN CUOTAS DIFERENTES DE GRATIS
		AND  DAR.Cuota = 2
		AND MA.Estado ='N'
		AND MA.EsMatricula = 1
		--AND PRO.IdUnidadAcademica IN(60,57,1)--@6 SE COMENTA PORQUE SE REEMPLAZA POR EL PUNTO 9
		AND PRO.IdUnidadNegocio = 1
		--AND PE.Codigo IN ((Select isnull(CodigoPeriodo,'') FROM @TempPeriodo)) SE COMENTA PORQUE SE REEMPLAZA POR EL PUNTO 9
		AND MA.IdModulo=1
		AND MA.TipoCondicion='RE'
		AND MA.TipoServicio='P'
		
		----CREAMOS LA VALIDACIONEXCLUSIVA SOLAMENTE PARA ZEGEL DEPENDIENDO EN CADA DESCUENTO
		/*
		IF @CompaniaSocio='00002500'
		BEGIN
			INSERT INTO @AlumnosMatriculados
				SELECT DISTINCT  
				'CuotaNumero' = 3-- COLOCAMOS EN DURO LA CUOTA QUE TENEMOS QUE VALIDARLE EN ESTE CASO LA SEGUNDA CUOTA
				,MA.IdMatricula
				,MA.IdActor
				,AC.NombreCompleto
				,PRO.PromocionNombre
				,PRO.PromocionCodigo
				,PE.Codigo
				,PRO.IdUnidadAcademica
				,DAR.GrupoDescuento
				FROM Matricula MA WITH(NOLOCK)
				INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK)ON MA.IdMatricula=DAR.IdMatricula 
				INNER JOIN Promocion PRO WITH(NOLOCK)ON MA.IdPromocion = PRO.IdPromocion 
				INNER JOIN Periodo PE WITH(NOLOCK)ON PRO.IdPeriodo = PE.IdPeriodo
				INNER JOIN Actor AC WITH(NOLOCK)ON MA.IdActor=AC.IdActor
				WHERE DAR.GrupoDescuento IN(6135,6142,6143) --VALIDAMOS QUE SEAN LAS CUOTAS ENVIADAS PARA ESTE TIPO DE ALUMNOS
				AND D

AR.Cuota = 2 
				AND MA.Estado ='N'
				AND MA.EsMatricula=1
				AND PRO.IdUnidadAcademica IN (60,57,1)--@6
				AND PRO.IdUnidadNegocio =1
				AND PE.Codigo IN ((Select isnull(CodigoPeriodo,'') FROM @TempPeriodo))--CONSULTAMOS LOS PERIODOS QUE PARAMETRIZ

AMOS
				AND MA.IdModulo=1
				AND MA.TipoCondicion='RE'
				AND MA.TipoServicio='P'
		END		*/ 

 
	--AHORA CON TODA ESA INFORMACION NOS VAMOS A VALIDAR SU DOCUMENTO, SU HEADER, SU MONTO, Y SI SE MERECE O NO EL DESCUENTO 
	INSERT  INTO @AlumnosCumplenRequisitos
		SELECT 
		DA.CuotaNumero,
		CO.MontoTotal,
		ISNULL(CH.GrupoDescuento,-1),
		DAC.GrupoCombinacion,
		DA.IdMatricula,
		DA.IdActor
		FROM @AlumnosMatriculados DA 
		INNER JOIN vw_CO_Interfase_P09_Header CH WITH(NOLOCK) ON DA.IdMatricula = CH.IdMatricula 
		AND DA.CuotaNumero = CH.CuotaNumero
		INNER JOIN vw_CO_Documento CO WITH(NOLOCK) ON DA.IdMatricula = CO.Interfase_Matricula 
		AND DA.CuotaNumero = CO.Interfase_Cuota
		AND SUBSTRING(CH.NumeroDocumento, 4, LEN(CH.NumeroDocumento)) = CO.NumeroDocumento
		AND CH.Estado=CO.Estado
		AND CH.CompaniaSocio=CO.CompaniaSocio
		INNER JOIN DescuentoAcademicoCombinacion DAC WITH(NOLOCK)ON ISNULL(CH.GrupoDescuento,-1) = DAC.GrupoDescuento--@3
		AND CO.MontoTotal = DAC.Monto
		AND CH.CuotaNumero = DAC.CuotaNumero
		AND DA.IdUnidadAcademica=DAC.Area
		AND DA.Periodo=DAC.Campana
		AND DAC.IdTipo=@IdTipo
		WHERE CH.Estado IN ('PR')
		AND CO.TipoDocumento = ('PC')
		AND CO.Estado='PR'
		AND CH.CompaniaSocio = @CompaniaSocio
		AND DAC.Estado=1--@7
		
	--ELIMINAMOS A LOS ALUMNOS QUE YA TENGAN PAGADO SU DESCUENTO

	--INICIO @2
	DELETE AM FROM @AlumnosMatriculados AM
		INNER JOIN vw_CO_Interfase_P09_Header CH WITH(NOLOCK) ON CH.IdMatricula = AM.IdMatricula AND CH.CuotaNumero = AM.CuotaNumero
		INNER JOIN vw_CO_Documento CO WITH(NOLOCK) ON AM.IdMatricula = CO.Interfase_Matricula 
		AND AM.CuotaNumero = CO.Interfase_Cuota
		AND SUBSTRING(CH.NumeroDocumento, 4, LEN(CH.NumeroDocumento)) = CO.NumeroDocumento
		AND CH.CompaniaSocio=CO.CompaniaSocio
		WHERE CH.Estado = ('CO')		
		AND CH.CompaniaSocio = @CompaniaSocio
	--FIN @2

	--AHORA VALIDAMOS LOS ALUMNOS QUE NO SE LES OTORGARA EL DESCUENTO Y SE LES ENVIA EL CORREO
	INSERT INTO @AlumnosSinDescuento
	SELECT
	AM.IdActor,
	AM.IdMatricula,
	AM.NombreCompleto,
	AM.PromocionNombre,
	AM.PromocionCodigo,
	AM.Periodo,
	AM.CuotaNumero,
	DAR.GrupoDescuento,
	DAR.DescuentoNombre,
	--INICIO @4
		CASE--@4
			-- VALIDAMOS QUE EL ALUMNO NO CUENTA CON UN DOCUMENTO GENERADO AUN POR ESO NO SE LE OTORGA EL DESCUENTO
			WHEN NOT EXISTS (
				SELECT 1
				FROM vw_CO_Documento CO WITH(NOLOCK)
				WHERE CO.Interfase_Matricula = AM.IdMatricula
					AND CO.Interfase_Cuota = AM.CuotaNumero
					AND CO.TipoDocumento = 'PC'
					AND CO.Estado = 'PR'
			) THEN 'Alumno no tiene documento generado'

			--	VALIDAMOS QUE EL DESCUENTO DEL ALUMNO NO SE ENCUENTRA REGISTRADO EN NUESTRA BASE
			WHEN NOT EXISTS (
				SELECT 1
				FROM DescuentoAcademicoCombinacion DAC(NOLOCK)
				WHERE DAC.GrupoDescuento = DAR.GrupoDescuento
					AND DAC.Campana = AM.Periodo
					AND DAC.CuotaNumero = AM.CuotaNumero
					AND DAC.Area = AM.IdUnidadAcademica
					AND DAC.IdTipo = @IdTipo
					AND DAC.Estado=1--@7
			) THEN 'Descuento no está registrado en las equivalencias'
			-- POR ULTIMO SI NO CUMPLE NINGUNA, ENTONCES EL ALUMNO TIENE UN MONTO DIFERENTE
			ELSE 'Alumno su monto es diferente al descuento'
		END AS Motivo
		--FIN @4
	FROM @AlumnosMatriculados AM
	INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON AM.IdMatricula = DAR.IdMatricula AND AM.CuotaNumero = DAR.Cuota
	-- VALIDAMOS A TODOS LOS ALUMNOS QUE YA SE LE HA OTORGADO EL DESCUENTO
	WHERE NOT EXISTS (
		SELECT 1
		FROM vw_CO_Interfase_P09_Header CH WITH(NOLOCK)
		INNER JOIN vw_CO_Documento CO WITH(NOLOCK) 
			ON AM.IdMatricula = CO.Interfase_Matricula
			AND AM.CuotaNumero = CO.Interfase_Cuota
			AND SUBSTRING(CH.NumeroDocumento, 4, LEN(CH.NumeroDocumento)) = CO.NumeroDocumento
			AND CH.Estado = CO.Estado
			AND CH.CompaniaSocio = CO.CompaniaSocio
		INNER JOIN DescuentoAcademicoCombinacion DAC WITH(NOLOCK)
			ON DAR.GrupoDescuento = DAC.GrupoCombinacion
			AND CO.MontoTotal = DAC.Monto
			AND CH.CuotaNumero = DAC.CuotaNumero
			AND AM.IdUnidadAcademica = DAC.Area
			AND AM.Periodo = DAC.Campana
			AND DAC.IdTipo = @IdTipo
			AND DAC.Estado=1--@7
		WHERE CH.IdMatricula = AM.IdMatricula
			AND CH.CuotaNumero = AM.CuotaNumero
			AND CH.Estado IN ('PR')
			AND CO.TipoDocumento = 'PC'
			AND CO.Estado = 'PR'
			AND CH.CompaniaSocio = @CompaniaSocio)
		--EXCLUIMOS A LOS ALUMNOS QUE SI CUMPLEN CON LOS REQUISITOS
		AND NOT EXISTS (SELECT 1 FROM @AlumnosCumplenRequisitos ACR WHERE ACR.IdMatricula = AM.IdMatricula AND ACR.CuotaNumero = AM.CuotaNumero)
		--AHORA VALIDAMOS SOLO LOS ALUMNOS QUE SE ENCUENTRAN DENTRO DE LAS EQUIVALENCIAS (REDUCIENDO CONSIDERABLEMENTE LOS ALUMNOS A ENVIAR)
		-- INICIO @8
		AND EXISTS (SELECT 1 FROM DescuentoAcademicoCombinacion DAC WITH(NOLOCK)
		WHERE DAC.GrupoDescuento = DAR.GrupoDescuento
		AND DAC.Campana = AM.Periodo
		AND DAC.CuotaNumero = AM.CuotaNumero
		AND DAC.Area = AM.IdUnidadAcademica
		AND DAC.IdTipo = @IdTipo
		AND DAC.Estado = 1)--@7
		-- FIN @8

	SELECT @MIN = MIN(ID), @MAX = MAX(ID) from @AlumnosCumplenRequisitos
	--CREAMOS EL WHILE EN DONDE SE VAN A PROCESAR EL NUEVO DESCUENTO ASIGNADO PARA EL ALUMNO
	WHILE @MIN <= @MAX
	BEGIN

		SET @IdMatricula = NULL 
		SET @CuotaNumero=NULL
		SET @GrupoCombinacion=NULL
		SET @GrupoOrigen=NULL
		SET @IdActor=NULL
		SELECT @CuotaNumero=CuotaNumero,@IdMatricula=IdMatricula,@GrupoCombinacion=GrupoCombinacion,@GrupoOrigen=GrupoDescuento,@IdActor=IdActor FROM @AlumnosCumplenRequisitos WHERE ID = @Min

		--ACTUALIZAMOS EL DESCUENTO EN DESCUENTOALUMNO Y DESCUENTOALUMNORESULTADO ADICIONAL TAMBIEN SE ACTUALIZA SU HEADER Y SU CO DOCUMENTO
		exec cDescuentoAlumno_Upd_ProcesoForzado 
		@IdMatricula=@IdMatricula
		,@Cuota=@CuotaNumero
		,@GrupoDescuento=@GrupoCombinacion
		,@UsuarioCreacion=446639
		,@EsVencimiento=0
		,@RetVal=@p6 output
		,@CompaniaSocio=@CompaniaSocio
		print @p6

		SET @Min=@Min+1
	END
	--AHORA VALIDAMOS EL ENVIO DE LOS ALUMNOS QUE NO CUMPLEN LOS REQUISITOS PARA ASIGNARLE UN DESCUENTO (NO CUENTAN CON EQUIVALENCIAS)
	IF EXISTS (SELECT 1 FROM @AlumnosSinDescuento)
	BEGIN
	
		DECLARE   @SinDescuentoMin int
				  ,@SinDescuentoMax int
				  ,@SinDescuentoIdActor VARCHAR(50)
				  ,@SinDescuentoIdMatricula VARCHAR(50)
				  ,@SinDescuentoNombreCompleto VARCHAR (255)
				  ,@SinDescuentoPromocionNombre VARCHAR (255)
				  ,@SinDescuentoPromocionCodigo VARCHAR (255)
				  ,@SinDescuentoPeriodo VARCHAR (255)
				  ,@SinDescuentoCuotaNumero VARCHAR (255)
				  ,@SinDescuentoGrupoDescuento VARCHAR (255)
				  ,@SinDescuentoNombreGrupoDescuento VARCHAR (255)--@5
				  ,@SinDescuentoObservacion VARCHAR (255)
				  ,@tableHTML  NVARCHAR(MAX)

		SELECT @SinDescuentoMin = min(id), @SinDescuentoMax = max(id) from @AlumnosSinDescuento 

		SET @tableHTML = '<H2>Envío de Alumnos sin equivalencias: <br></H2><table border = "1">' 

		SET @tableHTML = @tableHTML + '<table style="width:100%">
									  <tr>
										<th style="border: 1px solid black;">IdActor</th>
										<th style="border: 1px solid black;">IdMatricula</th>
										<th style="border: 1px solid black;">NombreCompleto</th> 
										<th style="border: 1px solid black;">PromocionNombre</th> 
										<th style="border: 1px solid black;">PromocionCodigo</th> 
										<th style="border: 1px solid black;">Perido</th>
										<th style="border: 1px solid black;">CuotaNumero</th>
										<th style="border: 1px solid black;">GrupoDescuento</th>
										<th style="border: 1px solid black;">NombreDescuento</th>
										<th style="border: 1px solid black;">Observacion</th>
									  </tr>'--@5

		WHILE @SinDescuentoMin <= @SinDescuentoMax  
		BEGIN

			SET @SinDescuentoIdActor = NULL
			SET @SinDescuentoIdMatricula = NULL
			SET @SinDescuentoNombreCompleto = NULL
			SET @SinDescuentoPromocionNombre = NULL
			SET @SinDescuentoPromocionCodigo = NULL
			SET @SinDescuentoPeriodo = NULL
			SET @SinDescuentoCuotaNumero=NULL
			SET @SinDescuentoGrupoDescuento=NULL
			SET @SinDescuentoNombreGrupoDescuento=NULL--@5
			SET @SinDescuentoObservacion=NULL

			SELECT @SinDescuentoIdActor=IdActor
			,@SinDescuentoIdMatricula=IdMatricula
			,@SinDescuentoNombreCompleto=NombreCompleto
			,@SinDescuentoPromocionNombre=PromocionNombre
			,@SinDescuentoPromocionCodigo=PromoCionCodigo
			,@SinDescuentoPeriodo=Periodo
			,@SinDescuentoCuotaNumero=CuotaNumero
			,@SinDescuentoGrupoDescuento=GrupoDescuento
			,@SinDescuentoNombreGrupoDescuento=NombreDescuento--@5
			,@SinDescuentoObservacion=Observacion
			FROM @AlumnosSinDescuento 
			WHERE ID = @SinDescuentoMin  
			
				SET @tableHTML  = @tableHTML  +  '<tr>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoIdActor +'</td>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoIdMatricula +'</td>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoNombreCompleto +'</td>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoPromocionNombre +'</td>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoPromocionCodigo +'</td>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoPeriodo +'</td>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoCuotaNumero +'</td>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoGrupoDescuento +'</td>'
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoNombreGrupoDescuento +'</td>'--@5
				SET @tableHTML  = @tableHTML  +  '<td style="border: 1px solid black;">'+ @SinDescuentoObservacion +'</td>'
				SET @tableHTML  = @tableHTML  +  '</tr>'
				
		SET @SinDescuentoMin = @SinDescuentoMin + 1  
		END 
		
		SET @tableHTML = @tableHTML + '</table>' 

		DECLARE @CorreosDestinatarios varchar(500), @body varchar(max), @subject varchar(150)

		SELECT @CorreosDestinatarios =  ListaCorreoUno  , 
		@body = REPLACE(CabeceraMensaje ,'[Tabla]',@tableHTML)  , 
		@subject = REPLACE(AsuntoMensaje , '[Empresa]' , @NombreCorto )   
		FROM Correo WITH(NOLOCK) WHERE Nombre = 'AlertaAlumnosSinDescuento' 
		
		EXEC BDSMTP.dbo.cEnvioCorreo_Ins_Grabar 
		@recipients = @CorreosDestinatarios, 
		@profile_name = 'Smart',             
		@subject = @subject,                
		@body =  @body,     
		@body_format = 'HTML' ;

	END 

END


