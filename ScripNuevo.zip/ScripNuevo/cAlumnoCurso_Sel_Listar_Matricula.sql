--�������������������������������������������������������������������������������������
--Creado por:Rosita Zacar�as (09/12/2011)  
--Modificado por:Rosita Zacar�as (16/05/2011)
--Funcionalidad:Recupera los cursos de la metricula ingresada e indica si esmatricula=1
--Utilizado por:AlumnoCurso.Sel_Listar_Matricul 
--�������������������������������������������������������������������������������������  
/*  
-----------------------------------------------------------------------------  
Nro  FECHA		USUARIO  DESCRIPCION  
-----------------------------------------------------------------------------  
@1  13/10/2017	jleo	se a�ade columna Ac.Estado
@2  29.01.2018	jnavia	Se agrega en la condicion de IdCurricula el IdCurriculaOriginal para cursos equivalentes
@3	22.03.2018	jnavia	Se agrega campos para cursos equivalentes
@4  16.04.2018	jmota	se agrega campo esmatricula para identificar los cursos matriculados (FrmPreMatriculaAcademico) 
@5	21.03.2019	hmora	se agrega campo productoc y grupocodigo  correspondiente a los cursos matriculados del alumno
@6  10/01/2019  Emilio Lescano se agrego el campo IdPromocion y PromocionNombre
@7  22/02/2019  PedroBarreto(Sigcomt) Se agrego una nueva validacion al momento de mostrar el TipoCondicion y un Inner Join para obtener los cursos subsanables
@8	21.03.2019	hmora	se agrega campo productoc y grupocodigo  correspondiente a los cursos matriculados del alumno
@9	03.06.2019	LeandroOrdo�ez (Sigcomt) Validar con curricula original y Subsana debe aparecer desde el a�o 2019
@10 20.06.2019	hmora	Se modifica criterios para cursos equivalentes
@11	09.01.2020	YFlores	Se a�ade parametro @TipoServicio para listar cursos libres
@12	10.01.2020	YFlores	Se cambia a left join para listar cursos libres
@13	29.04.2020	jcure	Se agrego validacion isnull
@14	11.08.2020	Jleo	Se adiciona validaci�n 
@15 19.02.2021  RSamame Se revierte el cambio @14
@16	23.02.2021	EHuillca Se revierte el cambio @15, y se agregan dos joins con promocion, uno para cabecera y otro para detalle.
@17	16.07.2022	EHuillca Se modifica estado de AlumnoCurso.
@18	11.09.2024	Alsanchez Se agrega validacion de la subsanacion en 1, para que no aparezca NULL si no ''
*/
ALTER PROCEDURE [dbo].[cAlumnoCurso_Sel_Listar_Matricula](
@pIdCurricula INT, 
@pIdModulo INT, 
@pIdMatricula INT)
AS
BEGIN
	SET NOCOUNT ON

	-- @11 INICIO
	DECLARE @TIPOSERVICIO CHAR (1)

	SELECT @TIPOSERVICIO = UN.TIPOSERVICIO 
	FROM UNIDADNEGOCIO UN WITH(NOLOCK)
		INNER JOIN PROMOCION P WITH(NOLOCK) ON P.IDUNIDADNEGOCIO = UN.IDUNIDADNEGOCIO
		INNER JOIN MATRICULA M WITH(NOLOCK) ON M.IDPROMOCION = P.IDPROMOCION
	WHERE M.IDMATRICULA = @PIDMATRICULA

	IF @TIPOSERVICIO = 'L'
		BEGIN
		-- @11 FIN
			SELECT
				'Sel'= CONVERT(int,ac.EsMatricula) 
				,'IdCurricula'=ISNULL(CC.IdCurricula , '') --@11 
				,'IdModulo'=ISNULL(CC.IdModulo  ,'')  --@11 
				,'CurriculaModuloNombre'=ISNULL(CM.Nombre,'') --@11  
				,AC.IdCurso--@11
				,'CursoCodigo'=ISNULL(C.CursoCodigo,'')--@12
				,'CursoNombre'=ISNULL(C.CursoNombre,'')  --@12
				,'CursoNombreOficial'=ISNULL(C.CursoNombreOficial,'') --@12
				,'HorarioNombre'=isnull(S.Codigo  + ' - Facilitador: ' +  ISNULL(ACt.NombreCompleto,'')  + ' - Ambiente: ' + ISNULL(A.Nombre,'') + ' - Horario: ' + ISNULL(dbo.gFrecuenciaSeccionHorario(s.IdSeccion),'') + ' - Turno: ' + ISNULL(T.Nombre,'') ,'')  
				,'IdGrupo'=ISNULL(m.IdGrupo,'') --@8
				,'GrupoCodigo'=ISNULL((	SELECT grupocodigo 
										FROM promociongrupo WITH(NOLOCK) 
										WHERE idpromocion=s.idpromocion 
										and idgrupo=s.IdGrupo),'')--@8
				,'IdProducto'=ISNULL((	SELECT pdt.IdProducto 
										FROM alumnocurso alc WITH(NOLOCK) 
											inner join Promocion pro1 WITH(NOLOCK) on pro1.IdPromocion=alc.IdPromocion
											inner join periodo p WITH(NOLOCK) on p.IdPeriodo=pro1.IdPeriodo
											inner join producto pdt WITH(NOLOCK) on pdt.IdProducto=pro1.IdProducto 
										WHERE alc.IdMatricula=ac.IdMatricula 
											and alc.IdCurso=ac.IdCurso 
											and alc.IdAlumnoCurso=ac.IdAlumnoCurso),'')--@8
				,'ProductoNombre'=ISNULL((	SELECT pdt.productoNombre 
											FROM alumnocurso alc WITH(NOLOCK)
												inner join Promocion pro1 WITH(NOLOCK) on pro1.IdPromocion=alc.IdPromocion
												inner join periodo p WITH(NOLOCK) on p.IdPeriodo=pro1.IdPeriodo
												inner join producto pdt WITH(NOLOCK) on pdt.IdProducto=pro1.IdProducto 
											WHERE alc.IdMatricula=ac.IdMatricula 
												and alc.IdCurso=ac.IdCurso 
												and alc.IdAlumnoCurso=ac.IdAlumnoCurso),'')  --@8
				,'IdSeccion'=ISNULL(ac.idseccion,-1)
				,'IdTipoAutorizacion'=ISNULL(AC.IdTipoAutorizacion,0)
				,'NumVezCurso'=ISNULL(ac.NumVezCurso,'0')  
				,'TipoCondicion' = CASE 
										WHEN AC.TipoCondicion = 'RE' THEN 'REGULAR' --@12
										WHEN AC.TipoCondicion = 'CC' THEN 'CURSO REPITENCIA'
										WHEN AC.TipoCondicion = 'RP' THEN 'REGULAR + CR'
										WHEN AC.TipoCondicion = 'EC' THEN 'EXAMEN CARGO'
										ELSE '' --@18
									END
				,'EstadoNombre'  = CASE --@17
										WHEN AC.estado = 'RA' THEN 'RETIRO ASIGNATURA'
										WHEN AC.estado = 'RC' THEN 'RETIRO CICLO'
										WHEN AC.estado = 'NO' THEN 'REGULAR'
									END --@17
				--ISNULL(AC.Estado,'') --@1 
				,'IdCurriculaOriginal' = ISNULL(AC.IdCurriculaOriginal,'') --@3
				,'IdCursoOriginal' = ISNULL(AC.IdCursoOriginal,'') --@3
				,'CursoNombreOriginal' = ISNULL((	SELECT CursoNombre 
													FROM Curso with(nolock) 
													WHERE IdCurso = AC.IdCursoOriginal),'') --@3
				,AC.EsMatricula  --@4
				,'IdPromocion'=ISNULL(AC.IdPromocion,0)--@5  
				,'PromocionNombre'=pro.PromocionCodigo --@5  
			FROM  Matricula M with (nolock)  
				LEFT join AlumnoCurso AC  with (nolock) ON M.IdMatricula=AC.IdMatricula --@11 
				LEFT JOIN  curriculacurso CC  with (nolock) ON ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) =CC.IdCurricula --@9 --@11 
				LEFT JOIN curriculamodulo CM  with (nolock) ON CC.idcurricula=CM.idcurricula AND CC.idmodulo=CM.idmodulo --@11  
				LEFT JOIN Promocion pro with (nolock) ON AC.IdPromocion=pro.IdPromocion --@5 @14 JLEO
				LEFT JOIN Seccion S with (nolock) on ac.IdSeccion = s.IdSeccion and ac.IdCurso = s.IdCurso
				INNER JOIN Curso C with (nolock)  ON C.IdCurso = S.IdCurso --@12
				LEFT JOIN Ambiente A with (nolock) ON S.idambiente=A.idambiente
				LEFT JOIN Turno T with (nolock) ON S.IdTurno=T.IdTurno
				LEFT JOIN SeccionProfesor SP  with (nolock) ON S.IdSeccion = SP.IdSeccion and SP.EsResponsable = 1  
				LEFT JOIN Actor ACt with (nolock) ON SP.IdActor = ACt.IdActor
			WHERE 
				@TipoServicio = 'L' and M.IDMATRICULA= @pIdMatricula --@12  
			ORDER BY CM.Orden,CC.Orden ASC 
		END
	ELSE 
		BEGIN
			SELECT  
				'Sel'= CONVERT(int,ac.EsMatricula) 
				,CC.IdCurricula 
				,CC.IdModulo
				,'CurriculaModuloNombre'=CM.Nombre  
				,CC.IdCurso
				,c.CursoCodigo 
				,'CursoNombre'=ISNULL(CC.cursonombreoficial,'') 
				,'CursoNombreOficial'=ISNULL(CC.cursonombreoficial,'') 
				,'HorarioNombre'=isnull(S.Codigo  + ' - Facilitador: ' +  ISNULL(ACt.NombreCompleto,'')  + ' - Ambiente: ' + ISNULL(A.Nombre,'') + ' - Horario: ' + ISNULL(dbo.gFrecuenciaSeccionHorario(s.IdSeccion),'') + ' - Turno: ' + ISNULL(T.Nombre,'') ,'')  
				,'IdGrupo'=ISNULL(m.IdGrupo,'') --@8  
				,'GrupoCodigo'=isnull((	SELECT grupocodigo 
										FROM promociongrupo WITH(NOLOCK)
										WHERE idpromocion=s.idpromocion 
										and idgrupo=s.IdGrupo),'')--@8  
				,'IdProducto'=ISNULL((SELECT pdt.IdProducto FROM alumnocurso alc WITH(NOLOCK)  
											INNER JOIN Promocion pro1 WITH(NOLOCK) on pro1.IdPromocion=alc.IdPromocion  
											INNER JOIN periodo p WITH(NOLOCK) on p.IdPeriodo=pro1.IdPeriodo  
											INNER JOIN producto pdt WITH(NOLOCK) on pdt.IdProducto=pro1.IdProducto 
										WHERE alc.IdMatricula=ac.IdMatricula 
											and alc.IdCurso=ac.IdCurso 
											and alc.IdAlumnoCurso=ac.IdAlumnoCurso),'')--@8  
				,'ProductoNombre'=ISNULL((SELECT pdt.productoNombre FROM alumnocurso alc  
												INNER JOIN Promocion pro1 on pro1.IdPromocion=alc.IdPromocion  
												INNER JOIN periodo p on p.IdPeriodo=pro1.IdPeriodo  
												INNER JOIN producto pdt on pdt.IdProducto=pro1.IdProducto 
											WHERE alc.IdMatricula=ac.IdMatricula 
												and alc.IdCurso=ac.IdCurso 
												and alc.IdAlumnoCurso=ac.IdAlumnoCurso),'')  --@8  
				,'IdSeccion'=ISNULL(ac.idseccion,-1) 
				,'IdTipoAutorizacion'=isnull(AC.IdTipoAutorizacion,0)  
				,'NumVezCurso'=ISNULL(ac.NumVezCurso,'0') 
				,'TipoCondicion' = CASE WHEN ACC.Subsanacion = 1 AND AC.NumVezCurso <= 1 AND prom1.IdPeriodoAnual >= 2019 THEN 'SUBSANA' --@9 --@16
										WHEN ACC.TipoCondicion = 'CO' THEN 'CONVALIDADO'  
										WHEN AC.TipoCondicion = 'RE' AND ISNULL(ACC.Subsanacion,0)=0  THEN 'REGULAR'
										WHEN AC.TipoCondicion = 'CC' THEN 'CURSO REPITENCIA'  
										WHEN AC.TipoCondicion = 'RP' THEN 'REGULAR + CR'  
										WHEN AC.TipoCondicion = 'EC' THEN 'EXAMEN CARGO' 
										ELSE '' --@18
									END --@7 
				,'EstadoNombre'  = CASE --@17
										WHEN AC.estado = 'RA' THEN 'RETIRO ASIGNATURA'
										WHEN AC.estado = 'RC' THEN 'RETIRO CICLO'
										WHEN AC.estado = 'NO' THEN 'REGULAR'
									END --@17
				--ISNULL(AC.Estado,'') --@1
				,'IdCurriculaOriginal' = ISNULL(AC.IdCurriculaOriginal,'') --@3  
				,'IdCursoOriginal' = ISNULL(AC.IdCursoOriginal,'') --@3  
				,'CursoNombreOriginal' = ISNULL((	SELECT CursoNombre 
												FROM Curso with (nolock) 
												WHERE IdCurso = AC.IdCursoOriginal),'') --@3  
				,AC.EsMatricula  --@4  
				,'IdPromocion'=ISNULL(AC.IdPromocion,0)--@5 
				,'PromocionNombre'=ISNULL(prom.PromocionCodigo,'') --@5 --@16
			FROM  Matricula M with (nolock) 
				INNER join AlumnoCurso AC  with (nolock) ON M.IdMatricula=AC.IdMatricula  
				INNER JOIN  curriculacurso CC  with (nolock) ON ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) =CC.IdCurricula --@9  
				--@7 Inicio  
				INNER JOIN AlumnoCurriculaCurso ACC WITH (NOLOCK) ON CC.IdCurricula = ACC.IdCurricula
					AND CC.IdCurso = ACC.IdCurso
					AND ACC.IdAlumno = M.IdActor
					AND ACC.IdRegistro = M.IdRegistro 
					AND ISNULL(AC.IdCursoOriginal,AC.IdCurso)=CC.IdCurso--@10  
				--@7 Fin  
				INNER JOIN curriculamodulo CM  with (nolock) ON CC.idcurricula=CM.idcurricula AND CC.idmodulo=CM.idmodulo
				INNER JOIN curso C  with (nolock)  ON CC.idcurso=C.idcurso 
				LEFT JOIN Promocion prom with (nolock) ON AC.IdPromocion=prom.IdPromocion --@5 @14--JLEO  --@16
				INNER JOIN Promocion prom1 with (nolock) ON M.IdPromocion=prom1.IdPromocion --@5 @14--JLEO  @15 --@16
				LEFT JOIN Seccion S with (nolock) on ac.IdSeccion = s.IdSeccion and ac.IdCurso = s.IdCurso  
				LEFT JOIN Ambiente A with (nolock) ON S.idambiente=A.idambiente  
				LEFT JOIN Turno T with (nolock) ON S.IdTurno=T.IdTurno  
				LEFT JOIN SeccionProfesor SP  with (nolock) ON S.IdSeccion = SP.IdSeccion and SP.EsResponsable = 1 
				LEFT JOIN Actor ACt with (nolock) ON SP.IdActor = ACt.IdActor  
			--  
			WHERE 
				ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula)= ISNULL(@pIdCurricula, '') --@2  
				AND M.IDMATRICULA= @pIdMatricula  
			ORDER BY CM.Orden,CC.Orden ASC  
		END
	SET NOCOUNT OFF  
END
