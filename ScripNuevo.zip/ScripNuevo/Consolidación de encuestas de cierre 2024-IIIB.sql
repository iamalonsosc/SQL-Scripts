----Consolidaci�n de encuestas de cierre 2024-IIIB IDAT
declare @p22 int
set @p22=0
EXEC cFichaProgramacionResumen_Ins_Grabar @IdProgramacion=30156 ,@UsuarioCreacion=1,@RetVal=@p22 output
select�@p22