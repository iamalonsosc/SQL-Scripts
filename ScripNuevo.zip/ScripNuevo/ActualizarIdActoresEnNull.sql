UPDATE actor SET UsuarioCreacion=1
WHERE UsuarioCreacion IS NULL
--(1739 rows affected)