DELETE FROM DescuentoAcademicoBase WHERE IdMaestroRegistro=47096
--(2362 rows affected)