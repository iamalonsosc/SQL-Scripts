UPDATE Registro SET Estado='N'
WHERE IdEmpresa = 1            
AND IdSede = 50            
AND IdActor = 1667847            
AND IdProducto = 11884
--(1 row affected)