--Select PE.Codigo,CPC.* from CambioProductoCurricula CPC
--INNER JOIN Periodo PE ON CPC.IdPeriodo = PE.IdPeriodo 
--where IdAlumno=1382539


UPDATE CambioProductoCurricula SET IdUnidadAcademica=60 WHERE IdAlumno=1382539
--(1 row affected)


SELECT TOP 10 *FROM AlumnoCurriculaConvalida WHERE IdAlumno=1382539
SELECT TOP 10*FROM TrasladoSede WHERE IdAlumno=1382539
SELECT*FROM Reingresos WHERE IdAlumno=1382539
SELECT*fROM CambioProductoCurricula WHERE IdAlumno=1382539


Select PE.Codigo,CPC.* from CambioProductoCurricula CPC
INNER JOIN Periodo PE ON CPC.IdPeriodo = PE.IdPeriodo 
where IdAlumno=1382539


UPDATE CambioProductoCurricula SET IdUnidadAcademica=60 WHERE IdAlumno=1382539