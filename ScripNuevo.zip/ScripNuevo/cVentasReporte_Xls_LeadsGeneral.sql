
---------------------------------------------------------------------------------------
-- Creado por      : Maximo Bueno
-- Funcionalidad   : Permite consultar los leads general enviados y no enviandos
-- Utilizado por   : Smart - Reporte de Ventas 34  - Leads general
---------------------------------------------------------------------------------------  
/*        
-----------------------------------------------------------------------------        
Nro		FECHA			USUARIO		DESCRIPCION        
-----------------------------------------------------------------------------
@1		12.07.2023		FETORRES	Se restructura el select para CA
@2		09.11.2023		MBUENO		Se agrega campo Disponible26(TipoDeContacto)	
@3		06.06.2024		JQuenta		Se agregan los siguientes campos: OrigenLead, TipoAtencionLead y UsuarioResponsableLead
									Se agrega validacion para mostrar la Fecha Real el cual se Carga el Lead desde Smart
@4		25.06.2024		MBUENO		Se agrega columna EstadoLead
@5		25.06.2024		IBENEL		Se cambio el nombre del campo fechaCreacion a FechaEventoLead y se agrego otro campo FechaCreacion
*/
ALTER PROCEDURE [dbo].[cVentasReporte_Xls_LeadsGeneral]
@FechaInicio VARCHAR(50),
@FechaFin VARCHAR(50),  
@IdUnidadNegocio INT = NULL  
AS  
BEGIN
	
	SET NOCOUNT ON;          
	SET DATEFORMAT DMY;  

	IF ISNULL(@IdUnidadNegocio,'') = ''  
	BEGIN  
		SET @IdUnidadNegocio = -1  
	END

	--@1 Inicio
	SELECT  
		myZapier.IdInteresado,
		myZapier.IdAtencion,
		myZapier.Apellidos, 
		myZapier.Nombres, 
		myZapier.NumeroDocumento,
		myZapier.Correo,
		myZapier.Celular, 
		myZapier.IdProducto,
		myZapier.Producto,
		myZapier.IdSede,
		myZapier.Sede,
		myZapier.IdTipoMedioDifusion,
		'TipoMedioDifusion' = ISNULL(MTR2.Nombre,''),
		myZapier.IdMedioDifusion,
		'MedioDifusion' = ISNULL(MTR.Nombre,''),
		myZapier.IdCampana,
		'Campana' = ISNULL(CV.NombreCampana,''),
		myZapier.FechaCreacion,
		myZapier.FechaEventoLead,--@5
		myZapier.TipoOrigen,
		myZapier.EnvioFive9,
		myZapier.Estado,
		'TipoDeContacto' = '', --@2
		--Inicio --@3
		myZapier.OrigenLead,
		myZapier.TipoAtencionLead,
		myZapier.UsuarioResponsableLead,
		--Fin --@3
		myZapier.EstadoLead --@4
	FROM(
	SELECT
		'IdInteresado' = CASE WHEN II.IdInteresado > 0 THEN CONVERT(VARCHAR,II.IdInteresado) ELSE 'Sin Interesado' END, 
		'IdAtencion' = CASE WHEN II.IdAtencion > 0 THEN CONVERT(VARCHAR,II.IdAtencion) ELSE 'Sin Atencion' END,
		'Apellidos' = TRIM(ISNULL(II.ApellidoPaterno, '') + ' ' + ISNULL(II.ApellidoMaterno,' ')), 
		'Nombres' = ISNULL(II.Nombres, ''), 
		'NumeroDocumento'= ISNULL(II.NumeroDocumento, ''), 
		'Correo' = ISNULL(II.EmailPersonal,''),
		'Celular' = ISNULL(II.Celular,''), 
		'IdProducto' = ISNULL(II.ProductoInteres,'0'),
		'Producto' = ISNULL(P.ProductoNombre,''),
		'IdSede' = Sede,
		'Sede' = ISNULL(S.Nombre,''),
		'IdTipoMedioDifusion' = ISNULL(II.Disponible7,'0'),
		'IdMedioDifusion' = ISNULL(II.Disponible8,'0'),
		'IdCampana' = ISNULL(II.Disponible9,'0'),
		'FechaCreacion' = CONVERT(VARCHAR,II.FechaCreacion,120),--@5
		--Inicio --@3
		'FechaEventoLead' = CASE
							WHEN (II.Disponible14 = 'CML' AND (TipoAtencionCargaLead = 'CMLM' OR TipoAtencionCargaLead = 'CMLW')) THEN ISNULL(CONVERT(VARCHAR,II.FechaRealCargaLead,120),'')
							ELSE CONVERT(VARCHAR,II.FechaCreacion,120) END,--@5
		--Fin --@3
		'TipoOrigen' = CASE II.Disponible14 WHEN 'CML' THEN 'Carga Manual Leads' ELSE 'ZAPIER' END,
		'EnvioFive9' = CASE II.Disponible14 WHEN 'CML' THEN II.Disponible3 ELSE 'SI' END,
		'Estado' =  CASE ISNULL(ICA.FlagCall,0)	
			WHEN 1 THEN 'Reg. CRM'  
			WHEN 2 THEN 'Envio de CRM a five9'  
			WHEN 3 THEN 'Envio de five9 a CRM'  
			WHEN 4 THEN 'Regestion'   
			ELSE 'No ingreso' END,
		'EsCampana' = CASE ISNUMERIC(II.Disponible9) WHEN 1 THEN II.Disponible9 ELSE '0' END,
		'EsMedioDifusion' = CASE WHEN TRIM(II.Disponible8) IN (',', '.', '-') THEN '0'
					WHEN ISNUMERIC(TRIM(II.Disponible8)) = 1  THEN II.Disponible8
					ELSE '0' END,
		--Inicio --@3
		'OrigenLead' = CASE
						WHEN (II.Disponible14 = 'CML' AND (TipoAtencionCargaLead = 'CMLM' OR TipoAtencionCargaLead = 'CMLW')) THEN ISNULL(II.Disponible2,'')
						ELSE '' END,
		'TipoAtencionLead' = CASE
							WHEN (II.Disponible14 = 'CML' AND TipoAtencionCargaLead = 'CMLM') THEN 'Carga Masiva de Lead Manual'
							WHEN (II.Disponible14 = 'CML' AND TipoAtencionCargaLead = 'CMLW') THEN 'Carga Masiva de Lead Web'
							ELSE '' END,
		'UsuarioResponsableLead' = CASE
						WHEN (II.Disponible14 = 'CML' AND (TipoAtencionCargaLead = 'CMLM' OR TipoAtencionCargaLead = 'CMLW')) THEN ISNULL(ACTII.NombreCompleto,'')
						ELSE '' END,
		--Fin --@3
		'EstadoLead' =	CASE
						WHEN ISNULL(II.IdInteresado,0) != 0 AND ISNULL(ICA.FlagCall,0) = 1 THEN 'Se registro en el CRM'
						WHEN ISNULL(II.IdInteresado,0) != 0 AND ISNULL(ICA.FlagCall,0) = 2 THEN 'Se envio al Five9'
						WHEN ISNULL(II.IdInteresado,0) != 0 AND ISNULL(ICA.FlagCall,0) > 2 THEN 'Se recidio del Five9'
						WHEN ISNULL(II.Disponible13,'N') = 'N' THEN 'En Proceso'
						ELSE 'Error del ingreso y registro del lead' END --@4
		FROM InteresadoIntermedia II WITH(NOLOCK)
		LEFT JOIN Sede S WITH(NOLOCK) ON S.IdSede = II.Sede  
		LEFT JOIN Producto P WITH(NOLOCK) ON P.IdProducto = II.ProductoInteres  
		LEFT JOIN ProductoTipo PT ON PT.IdTipo = P.IdTipo
		LEFT JOIN SubTipo ST WITH(NOLOCK) ON p.IdSubTipo = st.IdSubTipo
		LEFT JOIN InteresadoContactoAtencion ICA WITH(NOLOCK) ON II.IdInteresado = ICA.IdInteresado AND II.IdAtencion = ICA.IdAtencion
		--Inicio --@3
		LEFT JOIN Usuario UII WITH (NOLOCK) ON II.UsuarioCreacionCargaLead = UII.IdUsuario
		LEFT JOIN Actor ACTII WITH (NOLOCK) ON UII.IdActor = ACTII.IdActor
		--Fin --@3
		WHERE CONVERT(VARCHAR,II.FechaCreacion,112) BETWEEN CONVERT(VARCHAR,@FechaInicio,112) AND CONVERT(VARCHAR,@FechaFin,112)  
		AND (PT.IdTipo=@IdUnidadNegocio OR @IdUnidadNegocio=-1)
	) AS myZapier
	LEFT JOIN CampanaVenta CV WITH(NOLOCK) ON myZapier.EsCampana = cv.idcampana  
	LEFT JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.IdMaestroRegistro = myZapier.EsMedioDifusion
	LEFT JOIN MaestroTablaRegistro MTR2 WITH(NOLOCK) ON MTR.IdMaestroRegistroTipo = MTR2.IdMaestroRegistro

	UNION
	
	SELECT
		myWeb.IdInteresado,
		myWeb.IdAtencion,
		myWeb.Apellidos,
		myWeb.Nombres, 
		myWeb.NumeroDocumento, 
		myWeb.Correo, 
		myWeb.Celular,
		myWeb.IdProducto,
		myWeb.Producto,
		myWeb.IdSede,
		myWeb.Sede,
		myWeb.IdTipoMedioDifusion,
		'TipoMedioDifusion' = ISNULL(MTR2.Nombre,''),
		myWeb.IdMedioDifusion,
		'MedioDifusion' = ISNULL(MTR.Nombre,''),
		myWeb.IdCampana,
		'Campana' = ISNULL(CV.NombreCampana,''),
		myWeb.FechaCreacion,
		myWeb.FechaEventoLead,--@5
		myWeb.TipoOrigen,
		myWeb.EnvioFive9,
		myWeb.Estado,
		myWeb.TipoDeContacto, --@2
		--Inicio --@3
		'OrigenLead' = '',
		'TipoAtencionLead' = '',
		'UsuarioResponsableLead' = '',
		--Fin --@3
		myWeb.EstadoLead --@4
	FROM(
	SELECT
		'IdInteresado' =  CASE WHEN ISNULL(II.Disponible17, '') != '' THEN II.Disponible17 ELSE 'Sin Interesado' END,
		'IdAtencion' =  CASE WHEN ISNULL(II.Disponible23, '') != '' THEN II.Disponible23 ELSE 'Sin Atencion' END,
		'Apellidos' = ISNULL(II.Apellidos,''),
		'Nombres' = ISNULL(II.Nombres,''), 
		'NumeroDocumento' = ISNULL(II.NroDocumento,''), 
		'Correo' = ISNULL(II.Email,''), 
		'Celular' = ISNULL(II.Telefono,''),
		'IdProducto'= ISNULL(II.IdProductoInteres,'0'),
		'Producto' = ISNULL(P.ProductoNombre,''),
		'IdSede' = II.IdSede,
		'Sede' = ISNULL(S.Nombre,''),
		'IdTipoMedioDifusion' = ISNULL(II.Disponible7,'0'),
		'IdMedioDifusion' = ISNULL(II.Disponible8,'0'),
		'IdCampana' = ISNULL(II.Disponible9,'0'),
		'FechaCreacion' = CONVERT(VARCHAR,II.FechaCreacion,120),
		'FechaEventoLead' = '',--@5
		'TipoOrigen' = 'WEB',
		'EnvioFive9' = 'SI',
		'Estado' =  CASE ISNULL(ICA.FlagCall,0)	
			WHEN 1 THEN 'Reg. CRM'  
			WHEN 2 THEN 'Envio de CRM a five9'  
			WHEN 3 THEN 'Envio de five9 a CRM'  
			WHEN 4 THEN 'Regestion'   
			ELSE 'No ingreso' END,
		'EsCampana' = CASE ISNUMERIC(II.Disponible9) WHEN 1 THEN II.Disponible9 ELSE '0' END,
		'EsMedioDifusion' = CASE WHEN TRIM(II.Disponible8) IN (',', '.', '-') THEN '0'
						WHEN ISNUMERIC(TRIM(II.Disponible8)) = 1  THEN II.Disponible8
						ELSE '0' END,
		'TipoDeContacto' = ISNULL(II.Disponible26, ''), --@2
		'EstadoLead' =	CASE 
						WHEN ISNULL(II.Disponible17,'0') != '0' AND ISNULL(ICA.FlagCall,0) = 1 THEN 'Se registro en el CRM'
						WHEN ISNULL(II.Disponible17,'0') != '0' AND ISNULL(ICA.FlagCall,0) = 2 THEN 'Se envio al Five9'
						WHEN ISNULL(II.Disponible17,'0') != '0' AND ISNULL(ICA.FlagCall,0) > 2 THEN 'Se recidio del Five9'
						WHEN ISNULL(II.Disponible13,'N') = 'N' THEN 'En Proceso'
						ELSE 'Error del ingreso y registro del lead' END --@4
		FROM Log_Lead_Web_Origen II WITH(NOLOCK)
		LEFT JOIN Sede S WITH(NOLOCK) ON S.IdSede = II.IdSede  
		LEFT JOIN Producto P WITH(NOLOCK) ON P.IdProducto = II.IdProductoInteres  
		LEFT JOIN ProductoTipo PT ON PT.IdTipo = P.IdTipo   
		LEFT JOIN SubTipo ST WITH(NOLOCK) ON p.IdSubTipo = st.IdSubTipo 
		LEFT JOIN InteresadoContactoAtencion ICA WITH(NOLOCK) ON II.Disponible17 = ICA.IdInteresado AND II.Disponible23 = ICA.IdAtencion
		WHERE CONVERT(VARCHAR,II.FechaCreacion,112) BETWEEN CONVERT(VARCHAR,@FechaInicio,112) AND CONVERT(VARCHAR,@FechaFin,112)  
		AND (PT.IdTipo=@IdUnidadNegocio OR @IdUnidadNegocio=-1)
	) AS myWeb
	LEFT JOIN CampanaVenta CV WITH(NOLOCK) ON myWeb.EsCampana = cv.idcampana  
	LEFT JOIN MaestroTablaRegistro MTR WITH(NOLOCK) ON MTR.IdMaestroRegistro = myWeb.EsMedioDifusion
	LEFT JOIN MaestroTablaRegistro MTR2 WITH(NOLOCK) ON MTR.IdMaestroRegistroTipo = MTR2.IdMaestroRegistro
	--@1 Fin

END
