use BDSMTP
GO

update e set e.estado=1 ,e.enviado='MAURICIA_KO@YAHOO.ES' from  EnvioCorreo e where e.IdCorreo in (2209581)

