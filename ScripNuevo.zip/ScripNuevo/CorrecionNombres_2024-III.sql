
USE AcademicoIDAT;
GO 
--- NOMINAS

-- MÁQUINAS ELECTROMECÁNICAS Y MANTENIMIENTO INDUSTRIAL

UPDATE Curso SET CursoNombre= UPPER('Maquinas Electromecánicas y Mantenimiento Industrial')
WHERE IdCurso=10227

UPDATE CurriculaCurso SET CursoNombreOficial=UPPER('Maquinas Electromecánicas y Mantenimiento Industrial')
WHERE IdCurso=10227

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial=UPPER('Maquinas Electromecánicas y Mantenimiento Industrial')
WHERE IdCurso=10227

UPDATE AlumnoCursoActaJson SET CursoNombre=UPPER('Maquinas Electromecánicas y Mantenimiento Industrial')
WHERE IdCurso=10227

UPDATE ActaConsolidada SET cursoNombreOficial=UPPER('Maquinas Electromecánicas y Mantenimiento Industrial')
WHERE IdCurso=10227


-- PRODUCCIÓN DE SISTEMAS DE POTENCIA

UPDATE Curso SET CursoNombre = UPPER('Protección de Sistemas de Potencia')
WHERE IdCurso=11384

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('Protección de Sistemas de Potencia')
WHERE IdCurso=11384

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('Protección de Sistemas de Potencia')
WHERE IdCurso=11384

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('Protección de Sistemas de Potencia')
WHERE IdCurso=11384

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('Protección de Sistemas de Potencia')
WHERE IdCurso=11384 


--  LABORATORIO DE INTEGRACIÓN 3 - TALLER: TALLER DE IMPORTACIÓN Y EXPORTACIÓN

UPDATE Curso SET CursoNombre = UPPER('Taller de Importación y Exportación')
WHERE IdCurso=13427

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('Taller de Importación y Exportación')
WHERE IdCurso=13427

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('Taller de Importación y Exportación')
WHERE IdCurso=13427

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('Taller de Importación y Exportación')
WHERE IdCurso=13427

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('Taller de Importación y Exportación')
WHERE IdCurso=13427 


--   PROYECTO GRAFICO

UPDATE Curso SET CursoNombre = UPPER('Proyecto Integrador 1: Proyecto Gráfico')
WHERE IdCurso=10539

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('Proyecto Integrador 1: Proyecto Gráfico')
WHERE IdCurso=10539

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('Proyecto Integrador 1: Proyecto Gráfico')
WHERE IdCurso=10539

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('Proyecto Integrador 1: Proyecto Gráfico')
WHERE IdCurso=10539

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('Proyecto Integrador 1: Proyecto Gráfico')
WHERE IdCurso=10539 




--   ANALISIS FORENSE


UPDATE Curso SET CursoNombre = UPPER('ANÁLISIS FORENSE')
WHERE IdCurso=11405

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('ANÁLISIS FORENSE')
WHERE IdCurso=11405

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('ANÁLISIS FORENSE')
WHERE IdCurso=11405

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('ANÁLISIS FORENSE')
WHERE IdCurso=11405

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('ANÁLISIS FORENSE')
WHERE IdCurso=11405 

 
--   FUNDAMENTOS DE SEGURIDAD INFORMATICA 

UPDATE Curso SET CursoNombre = UPPER('FUNDAMENTOS DE SEGURIDAD INFORMÁTICA')
WHERE IdCurso=11402

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('FUNDAMENTOS DE SEGURIDAD INFORMÁTICA')
WHERE IdCurso=11402

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('FUNDAMENTOS DE SEGURIDAD INFORMÁTICA')
WHERE IdCurso=11402

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('FUNDAMENTOS DE SEGURIDAD INFORMÁTICA')
WHERE IdCurso=11402

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('FUNDAMENTOS DE SEGURIDAD INFORMÁTICA')
WHERE IdCurso=11402 


--   HACKING ETICO
UPDATE Curso SET CursoNombre = UPPER('HACKING ÉTICO')
WHERE IdCurso=11404

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('HACKING ÉTICO')
WHERE IdCurso=11404

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('HACKING ÉTICO')
WHERE IdCurso=11404

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('HACKING ÉTICO')
WHERE IdCurso=11404

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('HACKING ÉTICO')
WHERE IdCurso=11404 


--   PENSAMIENTO CREATIVO PARA LA INNOVACION
UPDATE Curso SET CursoNombre = UPPER('PENSAMIENTO CREATIVO PARA LA INNOVACIÓN')
WHERE IdCurso=9876

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('PENSAMIENTO CREATIVO PARA LA INNOVACIÓN')
WHERE IdCurso=9876

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('PENSAMIENTO CREATIVO PARA LA INNOVACIÓN')
WHERE IdCurso=9876

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('PENSAMIENTO CREATIVO PARA LA INNOVACIÓN')
WHERE IdCurso=9876

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('PENSAMIENTO CREATIVO PARA LA INNOVACIÓN')
WHERE IdCurso=9876 
 


--   RELACIONES PUBLICAS

UPDATE Curso SET CursoNombre = UPPER('Relaciones Públicas')
WHERE IdCurso=10094

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('Relaciones Públicas')
WHERE IdCurso=10094

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('Relaciones Públicas')
WHERE IdCurso=10094

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('Relaciones Públicas')
WHERE IdCurso=10094

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('Relaciones Públicas')
WHERE IdCurso=10094 



--   PROYECTO MECATRÓNICA AUTOMOTRIZ

UPDATE Curso SET CursoNombre = UPPER('Proyecto de Mecatrónica Automotriz')
WHERE IdCurso=10263

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('Proyecto de Mecatrónica Automotriz')
WHERE IdCurso=10263

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('Proyecto de Mecatrónica Automotriz')
WHERE IdCurso=10263

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('Proyecto de Mecatrónica Automotriz')
WHERE IdCurso=10263

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('Proyecto de Mecatrónica Automotriz')
WHERE IdCurso=10263 




-- ACTAS


--   GESTIÓN DE PROYECTOS

UPDATE Curso SET CursoNombre = UPPER('GESTIÓN DE PROYECTOS DE TIC')
WHERE IdCurso=9928

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('GESTIÓN DE PROYECTOS DE TIC')
WHERE IdCurso=9928

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('GESTIÓN DE PROYECTOS DE TIC')
WHERE IdCurso=9928

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('GESTIÓN DE PROYECTOS DE TIC')
WHERE IdCurso=9928

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('GESTIÓN DE PROYECTOS DE TIC')
WHERE IdCurso=9928 


--   PROYECTO CERTIFICADOR DE MECATRÓNICA I 

UPDATE Curso SET CursoNombre = UPPER('Proyecto Certificador de Mecatrónica 1')
WHERE IdCurso=11018

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('Proyecto Certificador de Mecatrónica 1')
WHERE IdCurso=11018

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('Proyecto Certificador de Mecatrónica 1')
WHERE IdCurso=11018

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('Proyecto Certificador de Mecatrónica 1')
WHERE IdCurso=11018

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('Proyecto Certificador de Mecatrónica 1')
WHERE IdCurso=11018 



 

--   PROYECTO DE SISTEMAS ELECTRÓNICOS I

UPDATE Curso SET CursoNombre = UPPER('Proyecto de Sistemas Electrónicos 1')
WHERE IdCurso=10266

UPDATE CurriculaCurso SET CursoNombreOficial = UPPER('Proyecto de Sistemas Electrónicos 1')
WHERE IdCurso=10266

UPDATE AlumnoCursoNominaJson SET cursoNombreOficial = UPPER('Proyecto de Sistemas Electrónicos 1')
WHERE IdCurso=10266

UPDATE AlumnoCursoActaJson SET CursoNombre = UPPER('Proyecto de Sistemas Electrónicos 1')
WHERE IdCurso=10266

UPDATE ActaConsolidada SET cursoNombreOficial = UPPER('Proyecto de Sistemas Electrónicos 1')
WHERE IdCurso=10266 

