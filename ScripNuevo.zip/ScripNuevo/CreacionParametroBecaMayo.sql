DECLARE @MAX INT 

SELECT @MAX= MAX(IdParametro) FROM Parametro

INSERT INTO Parametro VALUES (@MAX+1
,'PeriodosBecaActivateMayo'
,'PeriodosBecaActivateMayo'
,'Periodos a validar en cAsignacion_BecaActivate, la asignacion de descuentos'
,'2024-IIA,2024-IIC,2024-IIB,2024-II'
,''
,''
,1)

SELECT TOP 1*FROM Parametro
ORDER BY IdParametro DESC


--declare @CodigoPeriodo varchar(max)
--SELECT @CodigoPeriodo= Valor FROM Parametro WHERE Nombre='PeriodosBecaActivateMayo' --@2

--SELECT*FROM Periodo WHERE Codigo IN (Select data from dbo.Split(@CodigoPeriodo,','))