DECLARE @IdPromocion INT = 101874;
DECLARE @IdGrupo INT = 4;

SELECT PG.IdTipoSeccion,
    PG.IdPromocion,
    PG.IdGrupo,
    PG.Vacantes,

    S.IdSeccion,
    S.IdCurso,

    C.CursoCodigo,
    C.CursoNombre,

    Inscritos = COUNT(AC.IdMatricula),

    Diferencia = PG.Vacantes - COUNT(AC.IdMatricula),

    EstadoVacante =
        CASE
            WHEN COUNT(AC.IdMatricula) <= PG.Vacantes
                THEN 'TIENE VACANTES'
            ELSE 'NO TIENE VACANTES'
        END

FROM PromocionGrupo PG WITH (NOLOCK)

INNER JOIN Seccion S WITH (NOLOCK)
    ON S.IdPromocion = PG.IdPromocion
    AND S.IdGrupo = PG.IdGrupo
    AND ISNULL(S.Disponible5, '') NOT IN ('CL')

LEFT JOIN Curso C WITH (NOLOCK)
    ON C.IdCurso = S.IdCurso

LEFT JOIN AlumnoCurso AC WITH (NOLOCK)
    ON AC.IdPromocion = S.IdPromocion
    AND AC.IdSeccion = S.IdSeccion
    AND AC.IdGrupo = S.IdGrupo
    AND AC.IdCurso = S.IdCurso
    AND AC.Estado = 'NO'
    AND AC.EsMatricula = 1
    AND AC.TipoCondicion IN ('RE')

WHERE PG.IdPromocion = @IdPromocion
AND PG.IdGrupo = @IdGrupo

GROUP BY
    PG.IdPromocion,
    PG.IdGrupo,
    PG.Vacantes,
    S.IdSeccion,
    S.IdCurso,
    C.CursoCodigo,
    C.CursoNombre,
    PG.IdTipoSeccion

ORDER BY
    S.IdCurso,
    S.IdSeccion;