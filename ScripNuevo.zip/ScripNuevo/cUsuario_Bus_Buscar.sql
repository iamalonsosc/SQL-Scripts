Select TEMPO.IdUsuario        
	,TEMPO.[Login]        
	,TEMPO.Nombre            
	,TEMPO.Email            
	FROM (SELECT U.IdUsuario        
	,U.Login      
	,'Nombre'=A.NombreCompleto --@1
	,U.Email       
	,ROW_NUMBER() OVER (ORDER BY U.Nombre) AS NumeroFila        
	FROM Usuario U WITH(NOLOCK) INNER JOIN Actor A ON U.IdActor=A.IdActor--@1
	WHERE A.NombreCompleto LIKE ISNULL('','')+'%'        
	AND U.Login LIKE ISNULL('FPAMENDOZA','')+'%'        
	AND isnull(U.LoginDeshabilitado,0)=1
	And U.IdTipoUsuario = IsNull(0, U.IdTipoUsuario)
	)AS TEMPO      
	--WHERE NumeroFila BETWEEN (20 * -1) + 1             
	--AND 20 * (-1 + 1)

	SELECT LoginDeshabilitado,IdTipoUsuario,*FROM Usuario WHERE Login='FPAMENDOZA'