﻿DECLARE 
		@CuotaNumero INT
		,@GrupoOrigen varchar(100)
		,@CompaniaSocio VARCHAR(8)
		,@IdMatricula INT
		,@GrupoCombinacion INT
		,@MIN INT
		,@MAX INT
		,@p6 nvarchar(max)
		,@IdActor INT
		,@IdTipo INT
		,@NombreCorto varchar(100)
		,@PeriodosValidar VARCHAR(50)

	DECLARE @AlumnosMatriculados TABLE  (
		ID INT IDENTITY(1,1)
		,CuotaNumero INT
		,IdMatricula INT
		,IdActor INT
		,NombreCompleto VARCHAR(250)
		,PromocionNombre VARCHAR(250)
		,PromocionCodigo VARCHAR(250)
		,Periodo VARCHAR(10)
		,IdUnidadAcademica INT
		,GrupoDescuento INT
	);

	DECLARE @AlumnosCumplenRequisitos TABLE  (
		ID INT IDENTITY(1,1)
		,CuotaNumero INT
		,Monto DECIMAL(18,2)
		,GrupoDescuento INT
		,GrupoCombinacion VARCHAR(50)
		,IdMatricula INT
		,IdActor INT
	);

	DECLARE @AlumnosSinDescuento AS TABLE 
		(id int IDENTITY (1,1)
		,IdActor VARCHAR (50)
		,IdMatricula VARCHAR (50)
		,NombreCompleto VARCHAR (250)
		,PromocionNombre VARCHAR(255)
		,PromoCionCodigo VARCHAR(255)
		,Periodo VARCHAR (50)
		,CuotaNumero INT
		,GrupoDescuento INT
		,NombreDescuento VARCHAR(255)
		,Observacion VARCHAR(255)
	);

	DECLARE @TempPeriodo TABLE
		(IdPeriodo INT 
		,Periodo VARCHAR(20)
		,FechaInicio DATE
		,FechaFinExtem DATE
		,IdUnidadAcademica INT
		,EsExtemporaneo BIT
		,Estado BIT)

	SELECT @CompaniaSocio=CompaniaSocio FROM  Empresa WITH (NOLOCK)
	SELECT @IdTipo = IdMaestroRegistro FROM MaestroTablaRegistro WITH (NOLOCK) WHERE Codigo='DESVALENCIA'
	SELECT @NombreCorto  = NombreCorto FROM Empresa WITH (NOLOCK) WHERE IdEmpresa = 1
	SET @PeriodosValidar = ISNULL((Select Valor from Parametro WITH(NOLOCK) where Nombre='PeriodosValidarDescuento' AND Valor2=@CompaniaSocio AND Activo=1),'')

	--INSERTAMOS LOS PERIODOS A VALIDAR POR MARCA
	--@9
	INSERT INTO @TempPeriodo
		SELECT DISTINCT PE.IdPeriodo --@13
		,P.txt_value AS Periodo
		,PE.Inicio--@12
		,pe.FechaFinExtMat--@14
		--DATEADD(DAY, 2, PE.Inicio) AS Inicio,--@11
		,PE.IdUnidadAcademica
		,--@14 INICIO
		CASE 
			WHEN CAST(GETDATE() AS DATE) > PE.Inicio
			AND CAST(GETDATE() AS DATE) <=  PE.FechaFinExtMat
			THEN 1 ELSE 0
		END AS EsExtemporaneo
		--@14 FIN
		,CASE 
			WHEN PE.Inicio <= CAST(GETDATE() AS DATE) THEN 0  -- Ya inició → inactivo
			ELSE 1  -- Todavía no inicia → activo
		END AS Estado
		FROM dbo.uf_Parse(@PeriodosValidar, ',') P
		LEFT JOIN Periodo PE ON P.txt_value = PE.Codigo
		WHERE PE.IdUnidadAcademica IN (60, 57, 1)
		----@9
		--
		--return 

		UPDATE @TempPeriodo SET EsExtemporaneo=1
		WHERE Periodo='2026-IIA'

		--select*from @TempPeriodo

		INSERT INTO @AlumnosMatriculados
		SELECT DISTINCT  
		'CuotaNumero' = 3
		,MA.IdMatricula
		,MA.IdActor
		,AC.NombreCompleto
		,PRO.PromocionNombre
		,PRO.PromocionCodigo
		,PE.Codigo
		,PRO.IdUnidadAcademica
		,DAR.GrupoDescuento
		FROM Matricula MA WITH(NOLOCK)
		INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK)ON MA.IdMatricula=DAR.IdMatricula 
		INNER JOIN Promocion PRO WITH(NOLOCK)ON MA.IdPromocion = PRO.IdPromocion 
		INNER JOIN Periodo PE WITH(NOLOCK)ON PRO.IdPeriodo = PE.IdPeriodo
		INNER JOIN Actor AC WITH(NOLOCK)ON MA.IdActor=AC.IdActor
		INNER JOIN @TempPeriodo TP ON TP.Periodo = PE.Codigo 
		AND TP.IdUnidadAcademica = PRO.IdUnidadAcademica 
		--AND TP.Estado = 1--@9
		AND TP.IdPeriodo=PE.IdPeriodo
		AND TP.EsExtemporaneo=1
		WHERE DAR.GrupoDescuento = 1905
		AND DAR.Cuota = 2 
		AND MA.Estado ='N'
		AND MA.EsMatricula=1
		AND PRO.IdUnidadNegocio=1
		AND MA.IdModulo=1
		AND MA.TipoCondicion='RE'
		AND MA.TipoServicio='P'
		AND CAST(MA.MatriculaFecha AS DATE) BETWEEN CAST(PE.Inicio AS DATE) AND CAST(TP.FechaFinExtem AS DATE)

		
		INSERT  INTO @AlumnosCumplenRequisitos
		SELECT 
		DA.CuotaNumero,
		CO.MontoTotal,
		ISNULL(CH.GrupoDescuento,-1),
		DAC.GrupoCombinacion,
		DA.IdMatricula,
		DA.IdActor
		FROM @AlumnosMatriculados DA 
		INNER JOIN vw_CO_Interfase_P09_Header CH WITH(NOLOCK) ON DA.IdMatricula = CH.IdMatricula 
		AND DA.CuotaNumero = CH.CuotaNumero
		INNER JOIN vw_CO_Documento CO WITH(NOLOCK) ON DA.IdMatricula = CO.Interfase_Matricula 
		AND DA.CuotaNumero = CO.Interfase_Cuota
		AND SUBSTRING(CH.NumeroDocumento, 4, LEN(CH.NumeroDocumento)) = CO.NumeroDocumento
		AND CH.Estado=CO.Estado
		AND CH.CompaniaSocio=CO.CompaniaSocio
		INNER JOIN DescuentoAcademicoCombinacion DAC WITH(NOLOCK)ON ISNULL(CH.GrupoDescuento,-1) = DAC.GrupoDescuento--@3
		AND CO.MontoTotal = DAC.Monto
		AND CH.CuotaNumero = DAC.CuotaNumero
		AND DA.IdUnidadAcademica=DAC.Area
		AND DA.Periodo=DAC.Campana
		AND DAC.IdTipo=@IdTipo
		WHERE CH.Estado IN ('PR')
		AND CO.TipoDocumento = ('PC')
		AND CO.Estado='PR'
		AND CH.CompaniaSocio = @CompaniaSocio
		AND DAC.Estado=1--@7

	--ELIMINAMOS A LOS ALUMNOS QUE YA TENGAN PAGADO SU DESCUENTO

	--INICIO @2
	DELETE AM FROM @AlumnosMatriculados AM
		INNER JOIN vw_CO_Interfase_P09_Header CH WITH(NOLOCK) ON CH.IdMatricula = AM.IdMatricula AND CH.CuotaNumero = AM.CuotaNumero
		INNER JOIN vw_CO_Documento CO WITH(NOLOCK) ON AM.IdMatricula = CO.Interfase_Matricula 
		AND AM.CuotaNumero = CO.Interfase_Cuota
		AND SUBSTRING(CH.NumeroDocumento, 4, LEN(CH.NumeroDocumento)) = CO.NumeroDocumento
		AND CH.CompaniaSocio=CO.CompaniaSocio
		WHERE CH.Estado = ('CO')		
		AND CH.CompaniaSocio = @CompaniaSocio
	--FIN @2

	--AHORA VALIDAMOS LOS ALUMNOS QUE NO SE LES OTORGARA EL DESCUENTO Y SE LES ENVIA EL CORREO
	INSERT INTO @AlumnosSinDescuento
	SELECT
	AM.IdActor,
	AM.IdMatricula,
	AM.NombreCompleto,
	AM.PromocionNombre,
	AM.PromocionCodigo,
	AM.Periodo,
	AM.CuotaNumero,
	DAR.GrupoDescuento,
	DAR.DescuentoNombre,
	--INICIO @4
		CASE--@4
			-- VALIDAMOS QUE EL ALUMNO NO CUENTA CON UN DOCUMENTO GENERADO AUN POR ESO NO SE LE OTORGA EL DESCUENTO
			WHEN NOT EXISTS (
				SELECT 1
				FROM vw_CO_Documento CO WITH(NOLOCK)
				WHERE CO.Interfase_Matricula = AM.IdMatricula
					AND CO.Interfase_Cuota = AM.CuotaNumero
					AND CO.TipoDocumento = 'PC'
					AND CO.Estado = 'PR'
			) THEN 'Alumno no tiene documento generado'

			--	VALIDAMOS QUE EL DESCUENTO DEL ALUMNO NO SE ENCUENTRA REGISTRADO EN NUESTRA BASE
			WHEN NOT EXISTS (
				SELECT 1
				FROM DescuentoAcademicoCombinacion DAC(NOLOCK)
				WHERE DAC.GrupoDescuento = DAR.GrupoDescuento
					AND DAC.Campana = AM.Periodo
					AND DAC.CuotaNumero = AM.CuotaNumero
					AND DAC.Area = AM.IdUnidadAcademica
					AND DAC.IdTipo = @IdTipo
					AND DAC.Estado=1--@7
			) THEN 'Descuento no está registrado en las equivalencias'
			-- POR ULTIMO SI NO CUMPLE NINGUNA, ENTONCES EL ALUMNO TIENE UN MONTO DIFERENTE
			ELSE 'Alumno su monto es diferente al descuento'
		END AS Motivo
		--FIN @4
	FROM @AlumnosMatriculados AM
	INNER JOIN DescuentoAlumnoResultado DAR WITH(NOLOCK) ON AM.IdMatricula = DAR.IdMatricula AND AM.CuotaNumero = DAR.Cuota
	-- VALIDAMOS A TODOS LOS ALUMNOS QUE YA SE LE HA OTORGADO EL DESCUENTO
	WHERE NOT EXISTS (
		SELECT 1
		FROM vw_CO_Interfase_P09_Header CH WITH(NOLOCK)
		INNER JOIN vw_CO_Documento CO WITH(NOLOCK) 
			ON AM.IdMatricula = CO.Interfase_Matricula
			AND AM.CuotaNumero = CO.Interfase_Cuota
			AND SUBSTRING(CH.NumeroDocumento, 4, LEN(CH.NumeroDocumento)) = CO.NumeroDocumento
			AND CH.Estado = CO.Estado
			AND CH.CompaniaSocio = CO.CompaniaSocio
		INNER JOIN DescuentoAcademicoCombinacion DAC WITH(NOLOCK)
			ON DAR.GrupoDescuento = DAC.GrupoCombinacion
			AND CO.MontoTotal = DAC.Monto
			AND CH.CuotaNumero = DAC.CuotaNumero
			AND AM.IdUnidadAcademica = DAC.Area
			AND AM.Periodo = DAC.Campana
			AND DAC.IdTipo = @IdTipo
			AND DAC.Estado=1--@7
		WHERE CH.IdMatricula = AM.IdMatricula
			AND CH.CuotaNumero = AM.CuotaNumero
			AND CH.Estado IN ('PR')
			AND CO.TipoDocumento = 'PC'
			AND CO.Estado = 'PR'
			AND CH.CompaniaSocio = @CompaniaSocio)
		--EXCLUIMOS A LOS ALUMNOS QUE SI CUMPLEN CON LOS REQUISITOS
		AND NOT EXISTS (SELECT 1 FROM @AlumnosCumplenRequisitos ACR WHERE ACR.IdMatricula = AM.IdMatricula AND ACR.CuotaNumero = AM.CuotaNumero)
		--AHORA VALIDAMOS SOLO LOS ALUMNOS QUE SE ENCUENTRAN DENTRO DE LAS EQUIVALENCIAS (REDUCIENDO CONSIDERABLEMENTE LOS ALUMNOS A ENVIAR)
		-- INICIO @8
		AND EXISTS (SELECT 1 FROM DescuentoAcademicoCombinacion DAC WITH(NOLOCK)
		WHERE DAC.GrupoDescuento = DAR.GrupoDescuento
		AND DAC.Campana = AM.Periodo
		AND DAC.CuotaNumero = AM.CuotaNumero
		AND DAC.Area = AM.IdUnidadAcademica
		AND DAC.IdTipo = @IdTipo
		AND DAC.Estado = 1)--@7
		-- FIN @8


		--REPORTE DE LOS ALUMNNOS AFECTADOS, QUE DESCUENTO REGRESARAN Y CUOTA SE VERA AFECTADA
			--SELECT m.idmatricula,S.Nombre,A.NombreCompleto,PE.CODIGO,PRO.PROMOCIONNOMBRE,aro.grupodescuento 'DescuentoActual',aro.GrupoCombinacion 'Descuento a Asignar',aro.cuotanumero FROM @AlumnosCumplenRequisitos ARO
			--INNER JOIN ACTOR A WITH(NOLOCK) ON ARO.idactor=a.idactor
			--INNER JOIN MATRICULA M WITH(NOLOCK) ON ARO.IDMATRICULA = M.IDMATRICULA
			--INNER JOIN PROMOCION PRO WITH(NOLOCK) ON M.IDPROMOCION = PRO.IDPROMOCION
			--INNER JOIN PERIODO PE WITH(NOLOCK) ON PRO.IDPERIODO= PE.IDPERIODO
			--INNER JOIN SEDE S WITH(NOLOCK) ON PRO.IDSEDE=S.IDSEDE
			--RETURN


		--select*from @AlumnosMatriculados
		--select*from @AlumnosCumplenRequisitos
		--return


	SELECT @MIN = MIN(ID), @MAX = MAX(ID) from @AlumnosCumplenRequisitos
	--CREAMOS EL WHILE EN DONDE SE VAN A PROCESAR EL NUEVO DESCUENTO ASIGNADO PARA EL ALUMNO
	WHILE @MIN <= @MAX
	BEGIN

		SET @IdMatricula = NULL 
		SET @CuotaNumero=NULL
		SET @GrupoCombinacion=NULL
		SET @GrupoOrigen=NULL
		SET @IdActor=NULL
		SELECT @CuotaNumero=CuotaNumero,@IdMatricula=IdMatricula,@GrupoCombinacion=GrupoCombinacion,@GrupoOrigen=GrupoDescuento,@IdActor=IdActor FROM @AlumnosCumplenRequisitos WHERE ID = @Min

		--ACTUALIZAMOS EL DESCUENTO EN DESCUENTOALUMNO Y DESCUENTOALUMNORESULTADO ADICIONAL TAMBIEN SE ACTUALIZA SU HEADER Y SU CO DOCUMENTO
		exec cDescuentoAlumno_Upd_ProcesoForzado 
		@IdMatricula=@IdMatricula
		,@Cuota=@CuotaNumero
		,@GrupoDescuento=@GrupoCombinacion
		,@UsuarioCreacion=446639
		,@EsVencimiento=0
		,@RetVal=@p6 output
		,@CompaniaSocio=@CompaniaSocio
		print @p6

		SET @Min=@Min+1
	END