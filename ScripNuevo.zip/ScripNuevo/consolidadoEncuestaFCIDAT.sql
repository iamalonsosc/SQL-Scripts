DECLARE @idSede INT = 38
update EmpresaSedeParametro set Valor = '0.01' WHERE Nombre= 'PcjeRptaEncAca' and IdSede = @idSede

--select * from sede
 
--- PROCESAR ENCUESTAS IDAT 
declare @table table (id int identity(1,1), Idprograma int)

insert into @table values(5832)
insert into @table values(5833)
insert into @table values(5860)
insert into @table values(5861)
insert into @table values(5862)
insert into @table values(5864)
insert into @table values(5865)
insert into @table values(5879)
insert into @table values(5880)
insert into @table values(5885)
insert into @table values(5887)
insert into @table values(5888)
insert into @table values(5889)
insert into @table values(5890)
insert into @table values(5891)
insert into @table values(5892)
insert into @table values(5893)
insert into @table values(5894)
insert into @table values(5895)
insert into @table values(5931)
insert into @table values(5955)
insert into @table values(5983)
insert into @table values(5996)
insert into @table values(6020)
insert into @table values(6039)
insert into @table values(6053)






declare @min int, @max int , 	@IdProgramacion INT,  @UsuarioCreacion INT, @RetVal INT

select @min = min(id), @max=max(id) from @table

while @min <= @max 
begin

	set @IdProgramacion = null 
	set @UsuarioCreacion = 1
	set @RetVal = null

	select @IdProgramacion = Idprograma from @table where id = @min 

	execute [dbo].[cFichaProgramacionResumen_Ins_Grabar]  
	@IdProgramacion,  
	@UsuarioCreacion ,  
	@RetVal OUTPUT

	select @RetVal

	set @min = @min + 1
end 

update EmpresaSedeParametro set Valor = '0.15' WHERE Nombre= 'PcjeRptaEncAca' and IdSede = @idSede