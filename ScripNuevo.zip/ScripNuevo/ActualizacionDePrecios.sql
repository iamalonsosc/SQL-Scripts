UPDATE ListaValor
SET Valor='S/.0 a S/.1024', DescripcionValor='S/.0 a S/.1024' WHERE Valor='Menos o igual a 930' and IdLista=19
UPDATE ListaValor
SET Valor='S/.1025 a S/.1200', DescripcionValor='S/.1025 a S/.1200' WHERE Valor='De s/ 931 a s/ 1200' and IdLista=19
UPDATE ListaValor
SET Valor='S/.1201 a S/.1600', DescripcionValor='S/.1201 a S/.1600' WHERE Valor='De s/ 1201 a s/ 1600' and IdLista=19
UPDATE ListaValor
SET Valor='S/.1601 a S/.2000', DescripcionValor='S/.1601 a S/.2000' WHERE Valor='De s/ 1601 a s/ 2000' and IdLista=19
UPDATE ListaValor
SET Valor='S/.2001 a m�s', DescripcionValor='S/.2001 a m�s' WHERE Valor='De s/ 2000 a m�s.' and IdLista=19