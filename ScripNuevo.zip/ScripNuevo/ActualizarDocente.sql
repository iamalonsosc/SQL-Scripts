 ------------------
 ---- DOCENTES ----
 ------------------
UPDATE FA SET EmailInstitucion=replace(EmailInstitucion,'idat.edu','idat')
FROM Seccion SE WITH (NOLOCK)   
INNER JOIN Ambiente AM WITH(NOLOCK) ON SE.IdAmbiente=AM.IdAmbiente
LEFT JOIN SeccionHorario SH WITH (NOLOCK) ON SE.IdSeccion = SH.IdSeccion  
LEFT JOIN SeccionProfesor SP WITH (NOLOCK) ON SE.IdSeccion = SP.IdSeccion  
LEFT JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroTabla = 2004 AND SP.EsResponsable = MTR.Codigo AND (SP.EsResponsable = 1 OR CAST(MTR.Disponible1 AS INT) = 4) --@1  
LEFT JOIN Facilitador FA WITH (NOLOCK) ON SP.IdActor = FA.IdFacilitador  
LEFT JOIN Actor AR WITH (NOLOCK) ON FA.IdFacilitador = AR.IdActor  
INNER JOIN Promocion PR WITH (NOLOCK) ON SE.IdPromocion = PR.IdPromocion  
INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON SE.IdPromocion = PG.IdPromocion AND SE.IdGrupo = PG.IdGrupo  
LEFT JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON MTR2.IdMaestroRegistro = pg.idtiposeccion --@2  
INNER JOIN Turno T with(nolock) on T.IdTurno = PG.IdTurno  
LEFT JOIN Curricula CR WITH (NOLOCK) ON PR.IdCurricula = CR.IdCurricula --@1  
INNER JOIN Curso CU WITH (NOLOCK) ON SE.IdCurso = CU.IdCurso  
INNER JOIN Sede SD WITH (NOLOCK) ON PR.IdSede = SD.IdSede  
INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON PR.IdUnidadNegocio = UN.IdUnidadNegocio  
INNER JOIN UnidadAcademica UA WITH (NOLOCK) ON PR.IdUnidadAcademica = UA.IdUnidadAcademica  
INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo  
INNER JOIN Producto PO WITH (NOLOCK) ON PR.IdProducto = PO.IdProducto  
WHERE PR.IdEmpresa = 1  
AND PR.IdFacultad = 1  
--AND (PR.IdUnidadNegocio = 1 OR 1 = -1)  
AND PE.IdPeriodoAnual IN (2023,2024)
--(1629 rows affected)


 --------------------------
 ---- USUARIO DOCENTES ----
 --------------------------

DECLARE @Docente TABLE
(Idactor INT,
FacilitadorCodigo VARCHAR(200),
FacilitadorNombre VARCHAR(200),
EmailInstitucion VARCHAR(100),
FechaCreacion DATETIME)
INSERT INTO @Docente
SELECT DISTINCT AR.IdActor  ,'FacilitadorCodigo' = ISNULL(FA.CodigoAnterior, '')  
,'FacilitadorNombre' = ISNULL(AR.NombreCompleto, '')  
,FA.EmailInstitucion
,'FechaCreacion' =CONVERT(VARCHAR,fa.FechaCreacion,103)
FROM Seccion SE WITH (NOLOCK)   
INNER JOIN Ambiente AM WITH(NOLOCK) ON SE.IdAmbiente=AM.IdAmbiente
LEFT JOIN SeccionHorario SH WITH (NOLOCK) ON SE.IdSeccion = SH.IdSeccion  
LEFT JOIN SeccionProfesor SP WITH (NOLOCK) ON SE.IdSeccion = SP.IdSeccion  
LEFT JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroTabla = 2004 AND SP.EsResponsable = MTR.Codigo AND (SP.EsResponsable = 1 OR CAST(MTR.Disponible1 AS INT) = 4) --@1  
LEFT JOIN Facilitador FA WITH (NOLOCK) ON SP.IdActor = FA.IdFacilitador  
LEFT JOIN Actor AR WITH (NOLOCK) ON FA.IdFacilitador = AR.IdActor  
INNER JOIN Promocion PR WITH (NOLOCK) ON SE.IdPromocion = PR.IdPromocion  
INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON SE.IdPromocion = PG.IdPromocion AND SE.IdGrupo = PG.IdGrupo  
LEFT JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON MTR2.IdMaestroRegistro = pg.idtiposeccion --@2  
INNER JOIN Turno T with(nolock) on T.IdTurno = PG.IdTurno  
LEFT JOIN Curricula CR WITH (NOLOCK) ON PR.IdCurricula = CR.IdCurricula --@1  
INNER JOIN Curso CU WITH (NOLOCK) ON SE.IdCurso = CU.IdCurso  
INNER JOIN Sede SD WITH (NOLOCK) ON PR.IdSede = SD.IdSede  
INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON PR.IdUnidadNegocio = UN.IdUnidadNegocio  
INNER JOIN UnidadAcademica UA WITH (NOLOCK) ON PR.IdUnidadAcademica = UA.IdUnidadAcademica  
INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo  
INNER JOIN Producto PO WITH (NOLOCK) ON PR.IdProducto = PO.IdProducto  
WHERE PR.IdEmpresa = 1  
AND PR.IdFacultad = 1  
--AND (PR.IdUnidadNegocio = 1 OR 1 = -1)  
AND PE.IdPeriodoAnual IN (2023,2024)

--SELECT*
UPDATE us SET us.EMAIL=replace(us.EMAIL,'idat.edu','idat')
FROM Usuario us
INNER JOIN @Docente do on do.Idactor = us.IdActor 
where us.IdTipoUsuario=2 
--(1629 rows affected)