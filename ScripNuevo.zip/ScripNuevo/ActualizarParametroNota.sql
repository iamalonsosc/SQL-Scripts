UPDATE MaestroTablaRegistro SET Disponible1='13.00'
WHERE IdMaestroRegistro=47096
--(1 row affected)