------------------------CAMBIO DE GRUPO ALUMNOS RETIRADOS--------------------------------------------------
update matricula set idgrupo = 2 where IdMatricula=621207	--0454.01.I.01.2024-IIIA-I-A
--(1 row affected)
update matricula set idgrupo = 4 where IdMatricula=622056	--0454.01.I.03.2024-IIIA-I-C
--(1 row affected)
update Matricula set IdGrupo = 2 where IdMatricula in(624468, 625149, 627279, 620835) --'0457.01.I.01.2024-IIIA-I-A' / 0457.01.I.06.2024-IIIA-I-C
--(4 rows affected)
update matricula set idgrupo = 2 where IdMatricula=627374	--0463.01.I.01.2024-IIIA-I-A
--(1 row affected)
update matricula set idgrupo = 4 where IdMatricula=624066	--0464.01.I.03.2024-IIIA-I-B
--(1 row affected)
update matricula set idgrupo = 4 where IdMatricula=619621	--0464.01.I.03.2024-IIIA-I-B
--(1 row affected)
update matricula set idgrupo = 4 where IdMatricula=621882	--0473.01.I.03.2024-IIIA-I-A
--(1 row affected)
update Matricula set IdGrupo = 2 where IdMatricula in(614667, 627745) --0474.01.I.01.2024-IIIA-I-A
--(2 rows affected)
update matricula set idgrupo = 4 where IdMatricula=615441	--0465.01.I.03.2024-III-I-B
--(1 row affected)
update matricula set idgrupo = 4 where IdMatricula=646904	--0466.01.I.03.2024-III-I-B
--(1 row affected)
update Matricula set IdGrupo = 2 where IdMatricula in(623866, 626501) --0468.01.I.01.2024-III-I-A
--(2 rows affected)
update Matricula set IdGrupo = 4 where IdMatricula in(629217, 634123) --0468.01.I.03.2024-III-I-C
--(2 rows affected)
update matricula set idgrupo = 2 where IdMatricula=623304	--0469.01.I.01.2024-III-I-A
--(1 row affected)