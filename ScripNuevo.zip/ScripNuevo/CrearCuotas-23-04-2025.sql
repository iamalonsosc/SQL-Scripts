--PRIMER CASO
INSERT INTO CO_Interfase_P09_Detalle VALUES ('BV',12519841,2,'S','Z60C113556','1.00','','GE','500.00','500.00',1,NULL,'00002700','DESIDAT',GETDATE(),'')

--SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno IN (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=678630 AND CompaniaSocio='00002700')