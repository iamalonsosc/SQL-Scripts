--PASO1
--UPDATE AlumnoCurriculaCurso set PromedioFinal='19.00',PromedioReal='19',PromedioCondicion='A',IdAlumnoCurso=35,IdRegistro=1
--WHERE  IDALUMNO=1239552 and IdCurso=9929
--PASO 2
--INSERT INTO AlumnoCurso VALUES (1239552,1,35,116,9929,11272,66289,1,456029,null,null,'19.00','19.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'RE',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)


--PASO 3
UPDATE Matricula SET Estado='N',IdRegistro=3,IdCurricula=5604
WHERE IdMatricula IN (611209)
--PASO 4
--select*from Matricula
UPDATE Matricula SET Estado='N',IdRegistro=3,IdCurricula=5604
WHERE IdMatricula IN (647135)



--select*from AlumnoCurriculaCurso
--UPDATE AlumnoCurriculaCurso SET PromedioFinal='12.00',PromedioReal='12',PromedioCondicion='D',IdAlumnoCurso=NULL
--WHERE IdAlumno=1239552 AND IdRegistro=2 AND IdCurso=9857

--SELECT DISTINCT estado FROM AlumnoCurso
----update AlumnoCurso set estado='NO'
--where IdMatricula=611209 and IdCurso=9857

--select*from AlumnoCurriculaCurso
--UPDATE AlumnoCurriculaCurso SET PromedioFinal='12.00',PromedioReal='12',PromedioCondicion='D',IdAlumnoCurso=NULL
--WHERE IdAlumno=1239552 AND IdRegistro=2 AND IdCurso=9932

--update AlumnoCurso set estado='X'
--where IdMatricula=647135 AND IdCurso=9932

--UPDATE AlumnoCurriculaCurso SET PromedioFinal='10.00',PromedioReal='10',PromedioCondicion='D',IdAlumnoCurso=NULL
--WHERE IdAlumno=1239552 AND IdRegistro=2 AND IdCurso=9920


--UPDATE AlumnoCurriculaCurso SET PromedioFinal='11.00',PromedioReal='11',PromedioCondicion='D',IdAlumnoCurso=NULL
--WHERE IdAlumno=1239552 AND IdRegistro=2 AND IdCurso=9839

--update AlumnoCurso set estado='X'
--where IdMatricula=11274 AND IdCurso=9839

--select*from Registro 

--update Registro set Estado='X'
--where IdActor=1239552 AND IdRegistro=1


--UPDATE AlumnoCurriculaCurso SET PromedioFinal=null,PromedioReal=null,PromedioCondicion=null,IdConvalidacion=NULL
--WHERE IdAlumno=1239552 AND IdRegistro=3 AND IdCurso=9839


select*from Curso where IdCurso=9801
SELECT*fROM ALUMNOCURSO





SELECT*FROM ALUMNOCURSO  WHERE IdMatricula=611209


--UPDATE ALUMNOCURSO SET IdAlumnoCurso=6
--WHERE IdMatricula=765198 AND IdCurso=9801

--UPDATE ALUMNOCURSO SET IdAlumnoCurso=7
--WHERE IdMatricula=765198 AND IdCurso=9839

--UPDATE ALUMNOCURSO SET IdAlumnoCurso=8
--WHERE IdMatricula=765198 AND IdCurso=9857

SELECT*FROM ALUMNOCURSO
--UPDATE ALUMNOCURSO SET IdAlumnoCurso=9
WHERE IdAlumno=1239552 AND IdCurso=9932

--UPDATE ALUMNOCURSO SET IdAlumnoCurso=10
--WHERE IdMatricula=765198 AND IdCurso=9932



SELECT*FROM ALUMNOCURSO


--UPDATE ALUMNOCURSO SET idregistro=3,IDCURRICULAORIGINAL=5604,IdAlumnoCurso=1
--WHERE IDMATRICULA=611209 AND IdCurso=9857

--UPDATE ALUMNOCURSO SET idregistro=3,IDCURRICULAORIGINAL=5604,IdAlumnoCurso=2
--WHERE IDMATRICULA=611209 AND IdCurso=9920

--UPDATE ALUMNOCURSO SET idregistro=3,IDCURRICULAORIGINAL=5604,IdAlumnoCurso=3
--WHERE IDMATRICULA=611209 AND IdCurso=9932

--UPDATE ALUMNOCURSO SET idregistro=3,IDCURRICULAORIGINAL=5604,IdAlumnoCurso=4
--WHERE IDMATRICULA=611209 AND IdCurso=9839

--UPDATE ALUMNOCURSO SET IdAlumnoCurso=7
--WHERE IdAlumno=1239552 AND IdRegistro=3 AND IdMatricula=611209 AND IdCurso=9801





--UPDATE AlumnoCurriculaCurso SET PromedioFinal='19.00',PromedioReal='18.76',PromedioCondicion='A',IdAlumnoCurso=1,Observacion='CONVALIDACION MALLA INTERNA',FECHACREACION='20240513'
--WHERE IdAlumno=1239552 AND IdRegistro=3 AND IdCurso=9857

UPDATE AlumnoCurriculaCurso SET PromedioFinal='18',PromedioReal='17.76',PromedioCondicion='A',IdAlumnoCurso=2,Observacion='CONVALIDACION MALLA INTERNA',FECHACREACION='20240513'
WHERE IdAlumno=1239552 AND IdRegistro=3 AND IdCurso=9920

--UPDATE AlumnoCurriculaCurso SET PromedioFinal='14',PromedioReal='14',PromedioCondicion='A',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA',FECHACREACION='20240513',IdConvalidacion=51037
--WHERE IdAlumno=1239552 AND IdRegistro=3 AND IdCurso=9801

--UPDATE AlumnoCurriculaCurso SET PromedioFinal='14.00',PromedioReal='14.12',PromedioCondicion='A',IdAlumnoCurso=4,Observacion='CONVALIDACION MALLA INTERNA',FECHACREACION='20240513'
--WHERE IdAlumno=1239552 AND IdRegistro=3 AND IdCurso=9839

select*from Matricula 
--update Matricula set Estado='N', IdRegistro=3, IdCurricula=5604
where IdMatricula=647135
select*from AlumnoCurso 

UPDATE AlumnoCurso SET IdRegistro=3, IdAlumnoCurso=8,estado='NO'
select*from AlumnoCurso 
where IdAlumno=1239552 AND IdRegistro=3

UPDATE AlumnoCurso SET IdRegistro=3, IdAlumnoCurso=11--,estado='NO',IdCurriculaOriginal=NULL,IdCursoOriginal=NULL
--select*from AlumnoCurso 
where IdAlumno=1239552 AND IdRegistro=2 AND IdMatricula=647135 AND IdCurso=9932


select*from AlumnoCurriculaCurso 
--UPDATE AlumnoCurriculaCurso SET  IdRegistro=3--,PromedioFinal='16.00',PromedioReal='15.56',PromedioCondicion='A'
where IdAlumno=1239552 and IdCurso=9932  AND IdRegistro=3 --and IdCurricula=5604



select*from AlumnoCurso 
--UPDATE AlumnoCurso SET IdCurriculaOriginal=5604
where IdAlumno=1239552  AND IdCurso=9932  AND IdRegistro=3 and IdMatricula=647135--AND IdCurso=9932


--  AND IdCurricula IN (2,116) AND IdCurso=9932

SELECT  PE.Codigo
				,AC.NumVezCurso
				
				, PG.FechaInicio --@9  
				, PG.FechaFin --@9 
				, PG.GrupoCodigo --@9      
				, AC.IdSeccion --@16    
				, M.IdMatricula --@16  
			FROM AlumnoCurso AC WITH (NOLOCK)
			INNER JOIN Promocion P WITH (NOLOCK) ON AC.IdPromocion = P.IdPromocion
			INNER JOIN Periodo PE WITH (NOLOCK) ON P.IdPeriodo = PE.IdPeriodo
			INNER JOIN Matricula M WITH (NOLOCK) ON AC.IdMatricula = M.IdMatricula
			INNER JOIN PromocionGrupo pg WITH (NOLOCK) ON pg.IdPromocion = AC.IdPromocion AND pg.IdGrupo = Ac.IdGrupo
			WHERE AC.IdAlumno = 1239552
				AND AC.IdRegistro = 3
				AND ISNULL(AC.IdCurriculaOriginal, AC.IdCurricula) = 5604 --@13      
				AND ISNULL(AC.IdCursoOriginal, AC.IdCurso) = 9932 --@13      
				AND AC.EsMatricula = 1
				AND M.Estado != 'X' --@12 --HUILLCA
				AND AC.estado = 'NO' --@12      
				--ORDER BY PE.IdPeriodo DESC      
			ORDER BY ISNULL(M.MatriculaFecha, M.InscritoFecha) DESC --@1      