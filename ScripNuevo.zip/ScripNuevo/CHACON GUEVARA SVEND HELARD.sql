--DECLARE @IdMatriculaAntigua INT=611219,@IdAlumno INT=1260368,@IdMatriculaNueva INT

UPDATE Matricula SET Estado='X'--,IdRegistro=8,IdCurricula=5612
WHERE IdMatricula IN (611219)

--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1260368 AND IdRegistro=1 AND IdCurso=10437 AND IdCurricula=123

--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1260368 AND IdRegistro=1 AND IdCurso=9945 AND IdCurricula=123

--select*from AlumnoCurriculaCurso
UPDATE AlumnoCurriculaCurso SET PromedioCondicion =NULL,PromedioFinal=NULL,PromedioReal=NULL,IdAlumnoCurso=NULL,Subsanacion=NULL
WHERE IdAlumno=1260368 AND IdRegistro=1 AND IdCurso=10442 AND IdCurricula=123

SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1260368  --AND AC.IdCurso=13514
order by ac.idregistro,ac.IdAlumnoCurso desc


--PRIMERO CAMBIAMOS EL IDALUMNOCURSO Y EL IDREGISTRO DE LA NUEVA MATRICULA, CONVIRITIENDOLA CON LOS DATOS DE LA MATRICULA ANTIGUA
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=52
WHERE IdMatricula=783460 AND IdCurso=10442
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=53
WHERE IdMatricula=783460 AND IdCurso=10213
--(1 fila afectada)

UPDATE AlumnoCurso SET IdRegistro=1,IdAlumnoCurso=54
WHERE IdMatricula=783460 AND IdCurso=10229
--(1 fila afectada)



--AHORA LA MATRICULA ANTIGUA, LO CONVERTIMOS A LOS DATOS ACTUALES
--SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdRegistro=2,IdAlumnoCurso=1,IdcurriculaOriginal=5612,IdCursoOriginal=NULL
WHERE IdMatricula=611219 AND IdCurso=10213

UPDATE AlumnoCurso SET IdRegistro=2,IdAlumnoCurso=2,IdcurriculaOriginal=5612,IdCursoOriginal=10229
WHERE IdMatricula=611219 AND IdCurso=13521

UPDATE AlumnoCurso SET IdRegistro=2,IdAlumnoCurso=3,IdcurriculaOriginal=5612
WHERE IdMatricula=611219 AND IdCurso=10442


--AHORA COLOCAMOS LAS CALIFICACIONES DE LOS CURSOS QUE LE HACIAN FALTA AL ALUMNO
UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='18.00',PromedioReal='17.96',IdAlumnoCurso=1,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1260368 AND IdRegistro=2 AND IdCurso=10213 AND IdCurricula=5612

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='18.00',PromedioReal='17.56',IdAlumnoCurso=2,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1260368 AND IdRegistro=2 AND IdCurso=10229 AND IdCurricula=5612

UPDATE AlumnoCurriculaCurso SET PromedioCondicion ='A',PromedioFinal='16.00',PromedioReal='15.84',IdAlumnoCurso=3,Observacion='CONVALIDACION MALLA INTERNA'--,Subsanacion=NULL
WHERE IdAlumno=1260368 AND IdRegistro=2 AND IdCurso=10442 AND IdCurricula=5612

--LUEGO DE ACTUALIZAR SUS NOTAS, TENEMOS QUE ACTUALIZAR SU MATRICULA Y ACTIVARLA NUEVAMENTE 

UPDATE Matricula SET Estado='N',IdRegistro=2,IdCurricula=5612
WHERE IdMatricula=611219

UPDATE Matricula SET Estado='X'
WHERE IdMatricula=783460