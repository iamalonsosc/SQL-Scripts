select m.idmatricula , m.idperiodo , m.IdActor , r.idregistro, r.estado RegistroEstado, --m.IdSede  , m.IdCurricula , p.idpromocion , 
 al.codigoAnterior , ac.NumeroIdentidad , ac.nombrecompleto , c.idcurricula , c.Codigo CodigoCurricula , p.PromocionCodigo, PG.GrupoCodigo , 
 TT.Nombre ,  p.PromocionNombre  , m.estado , m.esmatricula , m.MatriculaFecha , m.InscritoFecha  , m.FechaCreacion , 
 ui.Login MatriculaIdUsuario , u.login  UsuarioCreacion , um.Login UsuarioModificacion , m.FechaModificacion  , m.Tipo ,  m.TipoCondicion  , p.ServicioCodigo , SE.Sucursal , pe.Inicio, pe.Fin ,
 (SELECT COUNT(1) FROM MatriculaPagante MP WHERE MP.IdMatricula = M.IDMATRICULA)  Mat_Pagante , case when m.EsMatricula = 1 then 'MATRICULADO' ELSE 'PRE' END  EsMatricula , 
 (SELECT COUNT(1) FROM CO_Interfase_P09_Header H WHERE H.IDMATRICULA = M.IDMATRICULA AND H.COMPANIASOCIO = '00002700' AND H.Estado = 'CO') Interfase_Cobrado,
 (select COUNT(1) from AlumnoCurso ac where ac.idmatricula = m.idmatricula and ac.esmatricula = 1) Cursos_Mat , m.Observacion,
 (select pgc.PromedioReal from PromocionGrupoCierre  pgc where pgc.IdMatricula = m.idmatricula  )PromedioRealCiclo, p.IdUnidadAcademica , p.IdUnidadNegocio, m.TipoServicio , m.CondicionPago , NumeroCuota 
from Matricula m
inner join registro r on r.IdActor = m.idactor and  r.IdRegistro = m.idregistro
INNER JOIN promocion p on p.idpromocion = m.idpromocion
INNER JOIN SEDE SE ON SE.IDSEDE = P.IDSEDE 
INNER JOIN CURRICULA C ON C.IDCURRiCULA = P.IDCURRICULA 
INNER JOIN periodo pe on pe.idperiodo = p.idperiodo 
LEFT JOIN actor ac on ac.idactor = m.idactor 
LEFT JOIN Alumno AL on al.idalumno = ac.idactor
LEFT JOIN Usuario u on u.IdUsuario = m.UsuarioCreacion 
LEFT JOIN Usuario um on um.IdUsuario = m.UsuarioModificacion  
LEFT JOIN Usuario ui on ui.IdUsuario = m.MatriculaIdUsuario 
LEFT JOIN PromocionGrupo PG ON PG.IdPromocion = P.IdPromocion AND PG.IdGrupo = M.IdGrupo 
LEFT JOIN Turno T ON PG.IdTurno = T.IdTurno 
LEFT JOIN MaestroTablaRegistro TT ON TT.IdMaestroRegistro = T.IdTipoTurno  
 where --pe.codigo = '2024-III' and 
 --pe.idunidadacademica = 60 
-- and m.esmatricula = 1 
 -- and m.estado = 'R'
  AC.IdActor=1393889
--AND  ac.NombreCompleto = 'GUTIERREZ QUISPE WILFREDO ANTONIO'