--SELECT*FROM Curricula 
UPDATE Curricula SET NombrePlanEstudio='PLAN 2023'
WHERE IdProducto=13481
--(1 row affected)
	
--SELECT Valor10, *FROM ParametroUnidadAcademica 
UPDATE ParametroUnidadAcademica SET Valor10='0702704'
WHERE IdProducto=13481 AND Nombre='ParametroNomina1' 
--(9 rows affected)