--SELECT Estado, *FROM Promocion WHERE IdProducto IN (11874
--,11876
--,11878
--,11885) AND Estado='A'

UPDATE Promocion SET Estado='X'
 WHERE IdProducto IN (11874,11876,11878,11885) AND Estado='A'
 --(10 rows affected)