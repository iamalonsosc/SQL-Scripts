UPDATE Registro SET IdSede=48
WHERE IdRegistro=1
AND IdActor=1709718
--(1 row affected)