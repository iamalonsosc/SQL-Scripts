UPDATE S SET
Estado = 'A'
from Seccion S 
INNER JOIN Promocion P ON P.IdPromocion = S.IdPromocion
INNER JOIN Periodo PE ON PE.IdPeriodo = P.IdPeriodo
WHERE PE.Codigo IN ('2024-I','2024-IC') AND S.Estado <>'A'--(21 rows affected)

--Select * from Seccion S 
--INNER JOIN Promocion P ON P.IdPromocion = S.IdPromocion
--INNER JOIN Periodo PE ON PE.IdPeriodo = P.IdPeriodo
--WHERE PE.Codigo IN ('2024-I','2024-IC') AND S.Estado <>'A'

--(21 rows affected)