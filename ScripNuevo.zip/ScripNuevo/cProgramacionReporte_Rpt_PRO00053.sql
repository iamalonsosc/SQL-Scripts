--��������������������������������������������������������������������������������������������������     
--Creado por      :Heber Cachi(04/11/2020)                                                                         
--Funcionalidad   :Reporte Programacion Detalle Curso                                                                      
--Utilizado por   :ProgramacionReporte.RptPRO00053Str                                                              
--��������������������������������������������������������������������������������������������������     
/*                          
-----------------------------------------------------------------------------                          
Nro  FECHA  USUARIO  DESCRIPCION                          
-----------------------------------------------------------------------------    
@1   11.06.2021 PUchuya   Se agrega join para facilitador tipo Asistente y cambia lef join para listar cursos sin curricula   
@2   12.05.2023 Illosad   Se agrega join para mostrar tipo de seccion   
@3	 28.08.2024 Fmartinezc Se agrega parametro para excluir promociones fictisias
*/  
ALTER PROCEDURE cProgramacionReporte_Rpt_PRO00053  
@IdEmpresa INT  
,@IdSede INT  
,@IdFacultad INT  
,@IdUnidadNegocio INT  
,@IdUnidadAcademica INT  
,@Codigo VARCHAR(10)   
,@IdProducto INT  
,@IdPromocion INT  
AS                                                                                                                                 
BEGIN  
SET DATEFORMAT DMY    
SET DATEFIRST 1    

DECLARE @IdSeccionNormal INT,@IdMaestroTabla INT         
SET @IdMaestroTabla= (Select IdMaestroTabla FROM MaestroTabla WITH(NOLOCK) WHERE Codigo='TipoSeccion')   --@11
SET @IdSeccionNormal= (SELECT  IdMaestroRegistro FROM MaestroTablaRegistro WITH(NOLOCK)  WHERE CODIGO='NORMAL' AND IdMaestroTabla=@IdMaestroTabla)  --@11
SELECT    
 'Sede' = SD.Nombre  
 ,'Division' = UN.Nombre  
 ,'Programa' = UA.Nombre  
 ,'Periodo' = PE.Codigo  
 ,'Producto' = PO.ProductoNombre  
 ,'Curriculo' = ISNULL(CR.Codigo,'') --@1  
 ,PR.PromocionCodigo  
 ,'Seccion'  = PG.GrupoCodigo  
 ,'TipoSeccion'  = ISNULL(MTR3.Codigo,'Sin Tipo de SecQcion') --@2  
 ,'Turno' = T.Nombre  
 ,'CursoCodigo' = SE.Codigo  
 ,'CursoNombre' = cu.CursoNombre  
 ,'Inicio' = CONVERT(VARCHAR, pg.FechaInicio, 104)  
 ,'Fin' = CONVERT(VARCHAR, pg.FechaFin, 104)  
 ,'Frecuencia' = dbo.gFrecuenciaSeccionHorario(SE.IdSeccion)  
 ,'Dia' = ISNULL(CASE IdDia WHEN 1 THEN 'LUN'  
        WHEN 2 THEN 'MAR'  
        WHEN 3 THEN 'MIE'  
        WHEN 4 THEN 'JUE'  
        WHEN 5 THEN 'VIE'  
        WHEN 6 THEN 'SAB'  
        WHEN 7 THEN 'DOM' END, '')  
 ,'Inicio' = DBO.gHhMmStr(SH.HoraInicio)  
 ,'Fin' = DBO.gHhMmStr(SH.HoraFin)  
 ,'FacilitadorCodigo' = ISNULL(FA.CodigoAnterior, '')  
 ,'FacilitadorNombre' = ISNULL(AR.NombreCompleto, '')  
 ,'URLTeams' = ISNULL(SH.UrlClaseVirtual, '')  
 ,'DiaTeams' = ISNULL(CASE SH.IdDiaRuta WHEN 1 THEN 'LUN'  
           WHEN 2 THEN 'MAR'  
           WHEN 3 THEN 'MIE'  
           WHEN 4 THEN 'JUE'  
           WHEN 5 THEN 'VIE'  
           WHEN 6 THEN 'SAB'  
           WHEN 7 THEN 'DOM' END, '')  
 ,'InicioTeams' = ISNULL(DBO.gHhMmStr(SH.HoraInicioReal), '')  
 ,'FinTeams' = ISNULL(DBO.gHhMmStr(SH.HoraFinReal), '')   
FROM Seccion SE WITH (NOLOCK)   
 LEFT JOIN SeccionHorario SH WITH (NOLOCK) ON SE.IdSeccion = SH.IdSeccion  
 LEFT JOIN SeccionProfesor SP WITH (NOLOCK) ON SE.IdSeccion = SP.IdSeccion  
    LEFT JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON MTR.IdMaestroTabla = 2004 AND SP.EsResponsable = MTR.Codigo AND (SP.EsResponsable = 1 OR CAST(MTR.Disponible1 AS INT) = 4) --@1  
 LEFT JOIN Facilitador FA WITH (NOLOCK) ON SP.IdActor = FA.IdFacilitador  
 LEFT JOIN Actor AR WITH (NOLOCK) ON FA.IdFacilitador = AR.IdActor  
 INNER JOIN Promocion PR WITH (NOLOCK) ON SE.IdPromocion = PR.IdPromocion  
 INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON SE.IdPromocion = PG.IdPromocion AND SE.IdGrupo = PG.IdGrupo  
    LEFT JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON MTR2.IdMaestroRegistro = pg.idtiposeccion --@2  
 INNER JOIN Turno T with(nolock) on T.IdTurno = PG.IdTurno  
 LEFT JOIN Curricula CR WITH (NOLOCK) ON PR.IdCurricula = CR.IdCurricula --@1  
 INNER JOIN Curso CU WITH (NOLOCK) ON SE.IdCurso = CU.IdCurso  
 INNER JOIN Sede SD WITH (NOLOCK) ON PR.IdSede = SD.IdSede  
 INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON PR.IdUnidadNegocio = UN.IdUnidadNegocio  
 INNER JOIN UnidadAcademica UA WITH (NOLOCK) ON PR.IdUnidadAcademica = UA.IdUnidadAcademica  
 INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo 
   
		 
 INNER JOIN Producto PO WITH (NOLOCK) ON PR.IdProducto = PO.IdProducto 
 INNER JOIN MaestroTablaRegistro MTR3  WITH(NOLOCK)
					ON ISNULL(PG.IdTipoSeccion,@IdSeccionNormal)=MTR3.IdMaestroRegistro--@9  --@11     
WHERE PR.IdEmpresa = @IdEmpresa  
 AND (SD.IdSede = @IdSede or @IdSede = -1)  
 AND PR.IdFacultad = @IdFacultad  
 AND (PR.IdUnidadNegocio = @IdUnidadNegocio OR @IdUnidadNegocio = -1)  
 AND (PR.IdUnidadAcademica = @IdUnidadAcademica OR @IdUnidadAcademica = -1)  
 AND (PE.Codigo = @Codigo OR @Codigo = '')  
 AND (PO.IdProducto = @IdProducto OR @IdProducto = -1)  
 AND (PR.IdPromocion = @IdPromocion OR @IdPromocion = -1)  
 AND SE.IdPromocion NOT IN (SELECT CONVERT (INT ,DATA) FROM dbo.Split((SELECT valor FROM parametro WITH(NOLOCK)WHERE Nombre ='PromocionesFicticiasVitalicias'),',')) --@3
END 
