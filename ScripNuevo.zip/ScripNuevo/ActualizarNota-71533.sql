---- MAMANI MAMANI GISELA
---- PROYECCI�N DIGITAL 3D Y REALIDAD VIRTUAL
UPDATE AlumnoCurriculaCurso SET Idalumnocurso=null, IdConvalidacion=26108, PromedioFinal='15',PromedioReal='15', PromedioCondicion='A', TipoCondicion='CO',
								Glosa ='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula',UsuarioModificacion=1,FechaModificacion=GETDATE(),
								Subsanacion = 0, Observacion='Aprobado por SG - TKT #71533'
WHERE IdAlumno = 1230215 and IdCurricula=5608 and IdCurso in (10072)
--(1 row affected)	