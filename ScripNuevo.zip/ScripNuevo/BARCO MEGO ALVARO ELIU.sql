--SELECT TipoCondicion,*FROM Matricula 
UPDATE Matricula SET TipoCondicion='RP'
where IdMatricula=643511


--SELECT TipoCondicion,*FROM AlumnoCurso 
--UPDATE Matricula SET TipoCondicion='CC'
--where IdMatricula=643511 AND EsMatricula=1

----RP(PROMOVIDO + CURSO)
----CC(CURSO REPITENCIA)
----RT(REPITENCIA)
----RE(PROMOVIDO)
