SELECT*FROM Registro
--UPDATE Registro SET Estado='N'
WHERE IdActor=1029866 AND IdRegistro=7