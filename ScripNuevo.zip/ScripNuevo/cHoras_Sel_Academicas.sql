--����������������������������������������������������������������������������                              
--Creado por      : Renan Galvez  (16/02/2012)                      
--Modificado por  : Rosa Zacar�as (27/09/2012)                            
--Funcionalidad   : Permite Consultar las horas academicas, en base a parametros                              
--Utilizado por   : Actividad.cHoras_Sel_Academicas                              
--����������������������������������������������������������������������������           
/*                  
-----------------------------------------------------------------------------                  
Nro  FECHA  USUARIO  DESCRIPCION                  
-----------------------------------------------------------------------------                  
@1  19.06.2013 etorres Se quito condici�n para que pueda tener todo los retirados.          
@3  22.05.2015 lperales   Se corrigio para extension saque las fechas inicio y fin de la promocion no de la promociongrupo          
@4  03.07.2015 ilopez se muestran solo las promociones y secciones activas          
@5  21.09.2016 ilopez  Se agrega la sede para filtrar los CCs y Proyectos por sede  
@6  05.06.2019 jravichagua Se agrega el seteo de unidades de negocio y academica para que pueda lista las sedes virtuales  
@7 07.08.2019 EHuillca Se agrega nueva columna. Periodo.  
@8  05.09.2019 JRAVICHAGUA Cambios en where de remplaza funcion fecha por convert en fecha inicio y fin      
@9  22.02.2021	EALVA		Se agrega campo TipoSeccion. 
@10 23.02.2021  EALVA		Se modifica error de escritura innecesaria.
@11 24.02.2021 EALVA		Se cambia l�gica de busqueda del tipo de seccion para optimizar la busqueda general 
@12 11.06.2021  puchuya     Se cambia condicion para programas  libres
@13 22.11.2022 jcure		Se agrega columna aforo
@14 29.08.2023 jcure		Se validacion isnull para el aforo
*/          
ALTER PROCEDURE [dbo].[cHoras_Sel_Academicas]          
@IdEmpresa INT,          
@IdSede INT,          
@IdFacultad INT,          
@Anno INT,          
@Mes INT,          
@FechaInscripcion VARCHAR(10),          
@IdUnidadAcademica INT,          
@IdUnidadNegocio INT,          
@IdPeriodo INT,          
@IdProducto INT,          
@IdTipoModulo INT,          
@FechaInicio VARCHAR(10),          
@FechaFin VARCHAR(10)          
AS          
BEGIN          
	 DECLARE @TipoServicio CHAR(1) 
	 DECLARE @IdSeccionNormal INT
	 DECLARE @IdMaestroTabla INT         
	 SET NOCOUNT ON          
	 SET DATEFORMAT DMY       
 
	 SET @IdMaestroTabla= (Select IdMaestroTabla FROM MaestroTabla WITH(NOLOCK) WHERE Codigo='TipoSeccion')   --@11

	 SET @IdSeccionNormal= (SELECT  IdMaestroRegistro FROM MaestroTablaRegistro WITH(NOLOCK)  WHERE CODIGO='NORMAL' AND IdMaestroTabla=@IdMaestroTabla)  --@11
           
	 SET @TipoServicio = (SELECT TipoServicio FROM UnidadNegocio with(nolock) WHERE IdUnidadNegocio = @IdUnidadNegocio)        
   
	 IF @IdUnidadAcademica=-1 SET @IdUnidadAcademica=0 --@6  
	 IF @IdUnidadNegocio=-1 SET @IdUnidadNegocio=0  --@6   
    
	 IF @TipoServicio <> 'C' --@12
	 BEGIN          
		  SELECT          
		  'CodigoSede'=ISNULL(s.Codigo,''),           
		  'PromocionNombre'=ISNULL(CM.Nombre,P.PromocionNombre),          
		  P.PromocionCodigo,  
		  'Periodo' = ISNULL(PE.Codigo,''),  --@7          
		  'ProductoNombre'=PR.ProductoNombre,          
		  PG.GrupoCodigo,            
		  'HorarioNombre'=PG.DiaClaseTexto+' '+dbo.gHhMmStr(PG.HoraInicio)+' - '+dbo.gHhMmStr(PG.HoraFin),          
		  'TipoTurnoCodigo'=TT.Codigo,--se cambio a turno cod          
		  'TipoTurnoNombre'=T.Nombre,--se cambio a turno nombre           
		  'FechaInicio'=dbo.gFechaStr(P.FechaInicioPeriodo),          
		  'FechaFin'=dbo.gFechaStr(P.FechaFinPeriodo),          
		  'Matriculados'=(SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			  WHERE M.IdPromocion=PG.IdPromocion          
			  AND M.IdGrupo=PG.IdGrupo          
			  AND M.EsMatricula=1          
			  AND Estado <> 'X'          
			  AND M.TipoCondicion <> 'CC'),          
		  'MatriculadosCC'=(SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			   WHERE M.IdPromocion=PG.IdPromocion          
			   AND M.IdGrupo=PG.IdGrupo          
			   AND M.EsMatricula=1          
			   AND Estado <> 'X'          
			   AND M.TipoCondicion = 'CC'),          
		  'Retirados'=(SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			  WHERE M.IdPromocion=PG.IdPromocion          
			  AND M.IdGrupo=PG.IdGrupo          
			  AND M.EsMatricula=1          
			  AND Estado = 'R'          
			  AND M.TipoCondicion <> 'CC'          
			  ),          
		  'RetiradosCurso'=(SELECT COUNT(DISTINCT IDALUMNO) FROM AlumnoCurso ALUC WITH (NOLOCK)          
			  WHERE ALUC.IdPromocion=PG.IdPromocion          
			  AND ALUC.IdGrupo=PG.IdGrupo     
			  AND ALUC.EsMatricula=1          
			  AND ALUC.Estado='RA'          
			  AND ALUC.TipoCondicion <> 'CC'),          
		  'Neto'=(SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			WHERE M.IdPromocion=PG.IdPromocion          
			AND M.IdGrupo=PG.IdGrupo          
			AND M.EsMatricula=1             
			AND Estado <> 'X'          
			AND M.TipoCondicion <> 'CC')-          
			(SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			WHERE M.IdPromocion=PG.IdPromocion          
			AND M.IdGrupo=PG.IdGrupo          
			AND M.EsMatricula=1          
			AND Estado = 'R'          
			AND M.TipoCondicion <> 'CC'          
			),           
		  'NombreAmbiente'=ISNULL(AB.Nombre  ,''),          
		  'HorasAcademicas'= ISNULL(CONVERT(VARCHAR(10),dbo.cHorasAcademicas(@IdEmpresa,p.IdPromocion,pg.IdGrupo,CONVERT(VARCHAR,CONVERT(DATE,@FechaInicio),112),
							CONVERT(VARCHAR,CONVERT(DATE,@FechaFin),112),p.IdSede,@IdFacultad,@IdUnidadNegocio,p.IdUnidadAcademica)),'0'),  --@8   --@10      
		  'Cordinador'= ISNULL(A.NombreCompleto,''),          
		  'CodigoProyecto'=ISNULL(IC.CodigoProyecto,''),          
		  'CodigoCentroCosto'=ISNULL(IC.CodigoCentroCosto,''),          
		  'IdSede'= ISNULL(p.IdSede,-1),          
		  'IdPromocion'= ISNULL(pg.IdPromocion,-1),          
		  'IdGrupo'= ISNULL(pg.IdGrupo,-1),          
		  'IdCoordinador'=ISNULL(PG.IdCoordinador,-1),           
		  'IdProyecto'=ISNULL(P.IdProyecto,-1),          
		  'IdCentroCosto'=ISNULL(P.IdCentroCosto,-1),          
		  'PorcRetiros' =  convert(varchar,round(CASE WHEN (SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
					   WHERE M.IdPromocion=PG.IdPromocion          
					   AND M.IdGrupo=PG.IdGrupo          
					   AND M.EsMatricula=1             
					   AND m.Estado <> 'X'          
					   AND M.TipoCondicion <> 'CC')=0 THEN 0          
			   ELSE          
			   (CAST((SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			   WHERE M.IdPromocion=PG.IdPromocion          
			   AND M.IdGrupo=PG.IdGrupo          
			   AND M.EsMatricula=1          
			   AND m.Estado = 'R'          
			   AND M.TipoCondicion <> 'CC' ) as real)/          
			   CAST((SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			   WHERE M.IdPromocion=PG.IdPromocion          
			   AND M.IdGrupo=PG.IdGrupo          
			   AND M.EsMatricula=1             
			   AND m.Estado <> 'X'          
			   AND M.TipoCondicion <> 'CC') as real)*100) END,2)) 
			   ,'TIPOSECCION'=MTR.Codigo    --@9  
			   ,'AFORO'=isnull(AB.Capacidad,-1)--@13--@14
		  FROM   Promocion P WITH(NOLOCK)          
		  INNER JOIN Producto PR WITH(NOLOCK) ON P.IdProducto=PR.IdProducto          
		  INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON PG.IdPromocion=P.IdPromocion          
		  LEFT JOIN Ambiente AB WITH(NOLOCK) ON  PG.idambiente=AB.idambiente          
		  LEFT JOIN CurriculaModulo CM WITH(NOLOCK) ON CM.IdCurricula=P.IdCurricula AND CM.IdModulo=P.IdModulo          
		  LEFT JOIN Turno T WITH(NOLOCK) ON PG.IdTurno=T.IdTurno          
		  INNER JOIN MaestroTablaRegistro TT WITH(NOLOCK) ON T.IdTipoTurno=TT.IdMaestroRegistro          
		  LEFT JOIN Actor A WITH(NOLOCK) ON A.IdActor=PG.IdCoordinador          
		  INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede=P.IdSede          
		  LEFT JOIN InterfazCentroCosto IC WITH(NOLOCK) ON IC.IdCentroCosto=P.IdCentroCosto AND IC.IdProyecto=P.IdProyecto AND IC.IdSede=P.IdSede  
		  INNER JOIN Periodo PE WITH(NOLOCK)ON PE.IdPeriodo = P.IdPeriodo--@7  
		  INNER JOIN MaestroTablaRegistro MTR  WITH(NOLOCK)
					ON ISNULL(PG.IdTipoSeccion,@IdSeccionNormal)=MTR.IdMaestroRegistro--@9  --@11     
		  WHERE P.IdEmpresa=@IdEmpresa          
		  AND (P.IdSede=@IdSede OR @IdSede=-1)          
		  --AND P.IdUnidadAcademica=@IdUnidadAcademica          
		  AND (P.IdUnidadAcademica=@IdUnidadAcademica OR @IdUnidadAcademica=0)  
		  AND (P.IdUnidadNegocio = @IdUnidadNegocio OR @IdUnidadNegocio=0 )  --@6         
		  AND P.IdFacultad = @IdFacultad          
		  --AND P.IdPeriodo =  @IdPeriodo          
		  AND(P.IdProducto = @IdProducto OR  @IdProducto = -1)          
		  AND (CM.IdTipoModulo=@IdTipoModulo OR @IdTipoModulo=-1)          
		  AND (NOT( P.FechaInicioPeriodo>= @FechaFin  OR P.FechaFinPeriodo <= @FechaInicio ) ) --@3          
		  --  NOT (@InicioMat >=@FinSel OR @FinMat <= @InicioSel)          
		  AND P.Estado='A'--@4          
		  AND PG.Estado='A'--@4          
	 END          
	 ELSE          
	  BEGIN     
	   SELECT           
	   'CodigoSede'=ISNULL(s.Codigo,''),           
	   'PromocionNombre'=ISNULL(CM.Nombre,P.PromocionNombre),          
	   P.PromocionCodigo,            
	   'ProductoNombre'=PR.ProductoNombre,          
	   PG.GrupoCodigo,  
	   'Periodo'  = ISNULL(PE.Codigo,''),--@7  
	   'HorarioNombre'=PG.DiaClaseTexto+' '+dbo.gHhMmStr(PG.HoraInicio)+' - '+dbo.gHhMmStr(PG.HoraFin),          
	   'TipoTurnoCodigo'=TT.Codigo,--se cambio a turno cod          
	   'TipoTurnoNombre'=T.Nombre,--se cambio a turno nombre           
	   'FechaInicio'=dbo.gFechaStr(PG.FechaInicio),          
	   'FechaFin'=dbo.gFechaStr(PG.FechaFin),          
	   'Matriculados'=(SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
		   WHERE M.IdPromocion=PG.IdPromocion          
		   AND M.IdGrupo=PG.IdGrupo          
		   AND M.EsMatricula=1          
		   AND Estado <> 'X'          
		   AND M.TipoCondicion <> 'CC'          
		   --AND dbo.cRegistroProductoRequisito_Valida_Pendientes(M.IdActor,M.IdRegistro) = 0          
		   --AND (dbo.cMatricula_Val_Pago_Cuota(M.IdMatricula) = 1 or m.IdProcedencia = 1)          
		   ),                    
	   'MatriculadosCC'=(SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
		   WHERE M.IdPromocion=PG.IdPromocion          
		   AND M.IdGrupo=PG.IdGrupo          
		   AND M.EsMatricula=1          
		   AND Estado <> 'X'          
		  AND M.TipoCondicion = 'CC'),          
	   'Retirados'=( SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
		   WHERE M.IdPromocion=PG.IdPromocion          
		   AND M.IdGrupo=PG.IdGrupo          
		   AND M.EsMatricula=1          
		   AND Estado = 'R'          
		   AND M.TipoCondicion <> 'CC' --@1          
		   ),          
	   'RetiradosCurso'=0,          
	   'Neto'=(SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
		 WHERE M.IdPromocion=PG.IdPromocion          
		 AND M.IdGrupo=PG.IdGrupo          
		 AND M.EsMatricula=1             
		 AND m.Estado <> 'X'          
		 AND M.TipoCondicion <> 'CC' --@1          
		 --AND dbo.cMatricula_Val_Pago_Cuota(M.IdMatricula) = 1          
		 )          
		 -          
		 (SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
		 WHERE M.IdPromocion=PG.IdPromocion          
		 AND M.IdGrupo=PG.IdGrupo          
		 AND M.EsMatricula=1          
		 AND m.Estado = 'R'          
		 AND M.TipoCondicion <> 'CC' --@1          
		 ),             
	   'NombreAmbiente'=ISNULL(AB.Nombre  ,''),          
	   'HorasAcademicas'= ISNULL(CONVERT(VARCHAR(10),dbo.cHorasAcademicas(@IdEmpresa,p.IdPromocion,pg.IdGrupo,CONVERT(VARCHAR,CONVERT(DATE,@FechaInicio),112),
						CONVERT(VARCHAR,CONVERT(DATE,@FechaFin),112),p.IdSede,@IdFacultad,@IdUnidadNegocio,p.IdUnidadAcademica)),'0'), --@8          
	   'Cordinador'= ISNULL(A.NombreCompleto,''),          
	   'CodigoProyecto'=ISNULL(IC.CodigoProyecto,''),          
	   'CodigoCentroCosto'=ISNULL(IC.CodigoCentroCosto,''),          
	   'IdSede'= ISNULL(p.IdSede,-1),          
	   'IdPromocion'= ISNULL(pg.IdPromocion,-1),          
	   'IdGrupo'= ISNULL(pg.IdGrupo,-1),          
	   'IdCoordinador'=ISNULL(PG.IdCoordinador,-1),           
	   'IdProyecto'=ISNULL(P.IdProyecto,-1),          
	   'IdCentroCosto'=ISNULL(P.IdCentroCosto,-1),          
	   'PorcRetiros' = convert(varchar,round(CASE WHEN (SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			WHERE M.IdPromocion=PG.IdPromocion          
			AND M.IdGrupo=PG.IdGrupo          
			AND M.EsMatricula=1             
			AND m.Estado <> 'X'          
			AND M.TipoCondicion <> 'CC')=0 THEN 0          
			  ELSE          
			(CAST((SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			WHERE M.IdPromocion=PG.IdPromocion          
			AND M.IdGrupo=PG.IdGrupo          
			AND M.EsMatricula=1          
			AND m.Estado = 'R'          
			AND M.TipoCondicion <> 'CC' ) as real)/          
			CAST((SELECT COUNT(1) FROM Matricula M WITH (NOLOCK)          
			WHERE M.IdPromocion=PG.IdPromocion          
			AND M.IdGrupo=PG.IdGrupo        
			AND M.EsMatricula=1             
			AND m.Estado <> 'X'          
			AND M.TipoCondicion <> 'CC')as real)*100) END,2))
			,'TIPOSECCION'=MTR.Codigo  --@9  
			,'AFORO'=isnull(AB.Capacidad,-1)--@13--@14
	   FROM   Promocion P WITH (NOLOCK)          
	   INNER JOIN Producto PR WITH (NOLOCK) ON P.IdProducto=PR.IdProducto          
	   INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON PG.IdPromocion=P.IdPromocion          
	   LEFT JOIN Ambiente AB WITH (NOLOCK) ON  PG.idambiente=AB.idambiente          
	   LEFT JOIN CurriculaModulo CM WITH (NOLOCK) ON CM.IdCurricula=P.IdCurricula AND CM.IdModulo=P.IdModulo          
	   LEFT JOIN Turno T WITH (NOLOCK) ON PG.IdTurno=T.IdTurno          
	   INNER JOIN MaestroTablaRegistro TT WITH (NOLOCK) ON T.IdTipoTurno=TT.IdMaestroRegistro          
	   LEFT JOIN Actor A WITH (NOLOCK) ON A.IdActor=PG.IdCoordinador          
	   INNER JOIN Sede S WITH (NOLOCK) ON S.IdSede=P.IdSede          
	   LEFT JOIN InterfazCentroCosto IC WITH (NOLOCK) ON IC.IdCentroCosto=P.IdCentroCosto AND IC.IdProyecto=P.IdProyecto AND IC.IdSede=P.IdSede  
	   INNER JOIN Periodo PE WITH(NOLOCK)ON PE.IdPeriodo = P.IdPeriodo--@7      
	   INNER JOIN MaestroTablaRegistro MTR  WITH(NOLOCK)
				ON ISNULL(PG.IdTipoSeccion,@IdSeccionNormal)=MTR.IdMaestroRegistro--@9  --@11
	   WHERE          
	   P.IdEmpresa=@IdEmpresa          
	   AND (P.IdSede=@IdSede OR @IdSede=-1)          
	   --AND P.IdUnidadAcademica=@IdUnidadAcademica          
	   AND (P.IdUnidadAcademica=@IdUnidadAcademica OR @IdUnidadAcademica=0)          
	   AND (P.IdUnidadNegocio = @IdUnidadNegocio OR @IdUnidadNegocio=0 ) --@6         
	   AND P.IdFacultad = @IdFacultad          
	  --AND P.IdPeriodo =  @IdPeriodo       
	   AND(P.IdProducto = @IdProducto OR  @IdProducto = -1)          
	   AND (CM.IdTipoModulo=@IdTipoModulo OR @IdTipoModulo=-1)          
	   AND (NOT( PG.FechaInicio>= @FechaFin  OR PG.FechaFin <= @FechaInicio ) )          
	   --AND ((@FechaInicio >= PG.FechaInicio   AND @FechaInicio <= PG.FechaFin) or          
	   --     (@FechaFin>= PG.FechaInicio AND @FechaFin<=PG.FechaFin)  )          
	   AND P.Estado='A'--@4          
	   AND PG.Estado='A'--@4          
	 END          
          
	 SET NOCOUNT OFF          
END
