----------------------------------------------------------------------------      
--Creado por      :Carlos Huallpa (10/06/2010)      
--Modificado por  :Rosa Zacarcas (28/09/2012)      
--Funcionalidad   :Permite anular una matricula      
--Utilizado por   :Matricula.ProAnularInt      
--------------------------------------------------------------      
--Modificado por  :Alan Aurora(10/08/2015)      
--Funcionalidad   :anular registro MatriculaRetiro      
--------------------------------------------------------------      
/*      
-----------------------------------------------------------------------------      
Nro		FECHA			USUARIO					DESCRIPCION      
-----------------------------------------------------------------------------      
@1		22.03.2012		plozada					Se incluye validacion para no anuluar una matricula si esta posee uno o mas documentos YA GENERADOS    
@2		29.08.2018		Hmora					Se incluye validacion de nominas para que no se anule una matricula que ya tiene generada su nomina      
@3		29.09.2018		rvera					Se incluye actualizacion del campo tipoanulacion    
@4		23.10.2018		EHuillca				Se incluye @IdRegistro como parametro declarado y ya no como parametro de entrada    
@5		23.11.2018		gguillen				Se modifica par�metro de entrada    
@5		25.04.2019		rvera					se retira store cPersonaInter_Pro_Eliminar   
@7		15.05.2019		Hmora					Se retira validaci�n de n�minas y se agrega eliminaci�n de las n�minas.
@8		21.10.2020		Jnavia					Se cambia el valor de la variable @ObservacionX
@9		21.03.2022		Puchuya					Se agrega eliminar de alumnocursosesion
@10		25.05.2023		EHuillca				Se agrega nuevo tipo de Condici�n
@11		16.11.2023		JQuenta					Se anulan los procesos generados en el Flujo de la Aceptacion de Ficha de Matricula y Entrega de Fotocopia del DNI
@12		25.01.2024		JQuenta					Se agrega Logica para Educacion Ejecutiva y Formacion Continua para la Division Extension de los Programas Virtuales       
@13		01/08/2024		RSamame					Se eliminan los permisos de los curso vinculados a la matricula
*/      
--CREATE PROCEDURE [dbo].[cMatricula_Pro_Anular]      
DECLARE
@IdActor INT,  --37934    
@IdMatricula INT,  --1493699    
@Observacion VARCHAR(500),  --..    
@UsuarioCreacion INT,  --74286    
@TipoAnulacion INT = null, --@3 --25245    
@IdRegistro INT = NULL, --@5 --23    
@EsMasivo INT = NULL, --mandar 1 validacion m�dulo 1  
@RetVal INT --OUTPUT    
--AS      
SELECT @IdActor=1403992,@IdMatricula=680457,@Observacion=N'sasa',@UsuarioCreacion=446639,@TipoAnulacion=25245,@IdRegistro=NULL,@EsMasivo=NULL--,@RetVal=@p8 

	DECLARE      
	@NoMatricula INT,      
	@IdPromocion INT,      
	@IdGrupo INT,      
	@VALOR INT,      
	@NoRegistro INT,      
	@EsCarrera INT,      
	@ObservacionX VARCHAR(100),      
	@IdPeriodo INT,      
	@IdCurricula INT,      
	@IdEmpresa INT,      
	@IdSede INT,      
	@Esmatricula INT ,      
	@IdTipoBeca INT,    
    @IdAsignacionFichaMatriculaXMatricula INT --@6  
      
	SET @RetVal=0      
	SET @NoMatricula = 0      
	set @NoRegistro = 0      
	--@4    

	if @IdActor = 0
	begin
		set @IdActor = (Select top 1 IdActor From Matricula Where IdMatricula = @IdMatricula)
	end

    
	Select @IdRegistro =  IdRegistro From Matricula Where IdMatricula = @IdMatricula And IdActor = @IdActor     
	--SET @IdRegistro = (SELECT TOP 1 * FROM Registro WHERE IdActor = @IdActor ORDER BY FechaCreacion DESC)    
	-- fin @4      
	
	IF EXISTS(SELECT 1 FROM Matricula WITH (NOLOCK)      
	WHERE IdMatricula = @IdMatricula      
	AND Estado='X')      
	BEGIN      
      
		SET @RetVal=1--la matricula no se puede anular, porque ya ha sido anulada.      
		SELECT @RetVal,'1'      
	END  
	
	IF @EsMasivo = 1
	BEGIN
			
		DECLARE @MODULOVAL INT
		SET @MODULOVAL = (SELECT IdModulo FROM Matricula WHERE IdMatricula = @IdMatricula)     
		IF NOT(1 = @MODULOVAL)
		BEGIN      
			SET @RetVal=7--la matricula no se puede anular, porque no es matricula del m�dulo 1.      
			SELECT @RetVal   
		END  
	END
    
	--@2    
	--IF EXISTS(SELECT 1 FROM AlumnoCursoNomina WITH (NOLOCK)      
	-- WHERE IdMatricula = @IdMatricula)      
	--BEGIN      
      
	-- SET @RetVal=6--la matricula no se puede anular, porque ya se genero  las nominas.      
	-- SELECT @RetVal      
	--END      
	--@2      
	--Cuenta el numero de matricula      
	--select 'paso 2'      
	SET @NoMatricula=(SELECT COUNT(idmatricula)      
	FROM Matricula  WITH (NOLOCK)      
	WHERE idactor=@IdActor      
	AND idregistro=@idregistro)      
	-- select    '@NoMatricula'=@NoMatricula      
      
	-- verificamos si viene de un reingreso, cambio de carrera o traslado se dede      
	SELECT @ObservacionX=Tipo,--@8  
	@IdPeriodo = IdPeriodo,      
	@IdCurricula = IdCurricula,      
	@IdEmpresa = IdEmpresa,      
	@IdSede = IdSede,      
	@Esmatricula = EsMatricula      
	FROM Matricula WITH (NOLOCK)      
	WHERE IdMatricula=@IdMatricula      
      
	IF @ObservacionX = 'CI'          
	BEGIN          
		-- verificamos si el reingreso esta vigente          
		IF EXISTS(SELECT 1 FROM Convalidacion WITH (NOLOCK)      
		WHERE IdAlumno=@IdActor      
		and IdPeriodoAnual =  @IdPeriodo      
		and Tipo NOT IN('TE','AM')--@10
		and IdRegistro = @idregistro      
		)            
		BEGIN      
			SET @RetVal=2--la matricula no se puede anular, porque ya VIENE DE UN CI.      
			SELECT @RetVal      
		END
	END      
	IF @ObservacionX = 'RI'      
	BEGIN
		-- verificamos si el reingreso esta vigente           
		IF EXISTS(SELECT 1      
		FROM Reingresos WITH (NOLOCK)      
		WHERE IdAlumno=@IdActor      
		AND IdPeriodoReingreso = @IdPeriodo      
      
		AND Estado=1)      
		BEGIN      
			IF @Esmatricula = 1      
			BEGIN       
           
				DECLARE @RetornoReingreso VARCHAR(150)      
				EXEC cMatricula_AnularReingresoMatriculado @IdActor,@IdPeriodo,@IdCurricula,@IdEmpresa,@IdSede,'Anulaci�n de Matricula',@UsuarioCreacion,@RetornoReingreso OUTPUT          
      
				IF @RetornoReingreso <> '1'          
				BEGIN          
					SET @RetVal=3--la matricula no se puede anular, porque ya ha sido anulada.      
					SELECT @RetVal      
				END      
			END      
			ELSE      
			BEGIN      
				SET @RetVal=3--la matricula no se puede anular, porque ya ha sido anulada.      
				SELECT @RetVal      
			END      
		END      
	END      
      
      
	IF @ObservacionX = 'CC'      
	BEGIN      
		IF EXISTS( SELECT 1      
		FROM CambioProductoCurricula WITH (NOLOCK)      
		WHERE IdAlumno=@IdActor      
		AND IdPeriodo =  @IdPeriodo      
		AND Estado=1)      
		BEGIN          
			IF @Esmatricula = 1          
			BEGIN          
				DECLARE @RetornoCambioCurricula VARCHAR(150)          
				EXEC cMatricula_AnularCambioCurriculaMatriculado @IdActor,@IdPeriodo,@IdCurricula,@IdEmpresa,@IdSede,'Anulaci�n de Matricula',@UsuarioCreacion,@RetornoCambioCurricula OUTPUT          
         
				IF @RetornoCambioCurricula <> '1'          
				BEGIN          
					SET @RetVal=4--la matricula no se puede anular, porque ya ha sido anulada.      
					SELECT @RetVal,'4'      
				END      
			END      
			ELSE      
			BEGIN          
				SET @RetVal=4--la matricula no se puede anular, porque ya ha sido anulada.      
				SELECT @RetVal    ,'4'            
			END					   
		END          
	END          
      
	IF @ObservacionX = 'TS'           
	BEGIN           
		IF EXISTS( SELECT 1 FROM TrasladoSede WITH (NOLOCK)      
		WHERE IdAlumno=@IdActor      
		AND IdPeriodoTraslado =  @IdPeriodo      
		AND Estado=1)      
		BEGIN            
			IF @Esmatricula = 1      
			BEGIN      
				DECLARE @RetornoTrasladoSede VARCHAR(150)          
				EXEC cTrasladoSedeAnula_Upd_ActualizarMatriculado  @IdActor,@IdPeriodo,@IdCurricula,@IdEmpresa,@IdSede,'Anulaci�n de Matricula',@UsuarioCreacion,@RetornoTrasladoSede OUTPUT          
         
				IF @RetornoTrasladoSede <> '1'          
				BEGIN          
					SET @RetVal=5--la matricula no se puede anular, porque ya ha sido anulada.          
				SELECT @RetVal      
				END            
			END          
			ELSE      
			BEGIN      
				SET @RetVal=5--la matricula no se puede anular, porque ya ha sido anulada.          
				SELECT @RetVal      
			END      
		END        
	END      
      
      
	IF @NoMatricula=1--Tiene solo una matricula, limpio todo      
	BEGIN      
		-- debemos verificar si el alumno tiene mas de un registro      
		DELETE FROM AlumnoCurso      
		WHERE IdAlumno=@IdActor      
		AND IdRegistro=@IdRegistro
	 
		DELETE FROM AlumnoCursoSesion --@9     
		WHERE IdAlumno=@IdActor      
		AND IdRegistro=@IdRegistro      
      
		-- si el producto no es carrera      
		SELECT @EsCarrera = IdTipo      
		FROM Producto p   WITH (NOLOCK)      
		inner JOIN Registro R    WITH (NOLOCK)      
		ON P.IdProducto = R.IdProducto      
		WHERE R.IdActor = @IdActor      
		AND R.IdRegistro = @idregistro      
		AND R.Estado <> 'X'      
                    
		 --caso de retiro y tiene cambio de carrera o reingreso      
		--a otra carrera no debe eliminar sus convalidaciones      
		IF @EsCarrera = 1      
		BEGIN      
			SET @NoRegistro=(SELECT COUNT(1)      
			FROM Convalidacion  WITH (NOLOCK)      
			where IdAlumno = @IdActor      
			and IdRegistro = @idregistro      
			)      
		END      
		ELSE      
			SET @NoRegistro=0                           
			IF @NoRegistro=0      
		BEGIN            
			if not EXISTS(SELECT 1      
			FROM alumnocurriculaconvalida   WITH (NOLOCK)      
			WHERE IdAlumno=@IdActor      
			AND IdRegistro=@IdRegistro)      
			begin      
				DELETE FROM AlumnoCurriculaCurso      
				WHERE IdAlumno=@IdActor      
				AND IdRegistro=@IdRegistro      
      
				DELETE FROM AlumnoCurriculaModulo      
				WHERE IdAlumno=@IdActor      
				AND IdRegistro=@IdRegistro      
      
				DELETE FROM Convalidacion      
				WHERE IdAlumno=@IdActor      
				AND IdRegistro=@IdRegistro      
      
				delete FROM AlumnoCurriculaCertificado      
				WHERE IdAlumno=@IdActor      
				AND IdRegistro=@IdRegistro      
      
				DELETE FROM AlumnoCurricula      
				WHERE IdAlumno=@IdActor      
				AND IdRegistro=@IdRegistro      
			end      
		END      
	END    --Tiene solo una matricula, limpio todo      
	ELSE--Tiene mas de una matricula, no limpio todo      
	BEGIN      
		DELETE FROM AlumnoCurso      
		WHERE IdMatricula=@IdMatricula

		DELETE FROM AlumnoCursoPermiso      
		WHERE IdMatricula=@IdMatricula--@13

		DELETE FROM AlumnoCursoSesion  --@9    
		WHERE IdMatricula=@IdMatricula 
		--@7
		IF EXISTS(SELECT 1 FROM AlumnoCursoNomina WITH (NOLOCK)      
		WHERE IdMatricula = @IdMatricula)      
		BEGIN            
			DELETE FROM AlumnoCursoNomina      
			WHERE IdMatricula=@IdMatricula
		END      
		--@7
       
		if exists (select 1       
		from AlumnoAsistenciaAdmision with(nolock)       
		where IdMatricula=@IdMatricula)      
		begin      
			delete AlumnoAsistenciaAdmision       
			where IdMatricula=@IdMatricula      
		end
	END                     
	--    select 'paso 3'      
	UPDATE Matricula	SET
		Observacion=@Observacion,      
		Estado='X',      
		UsuarioModificacion = @UsuarioCreacion,      
		FechaModificacion = GETDATE(),      
		TipoAnulacion=@TipoAnulacion --@3    
	WHERE IdMatricula=@IdMatricula     

	--Inicio --@11
	SET @IdAsignacionFichaMatriculaXMatricula = ( 
		SELECT
			IdAsignacionFichaMatricula
		FROM Matricula WITH (NOLOCK)
		WHERE IdMatricula = @IdMatricula 
	)

	UPDATE RPR SET RPR.Entregado = 0
	,RPR.FechaEntrega = NULL
	,RPR.UsuarioModificacion = @UsuarioCreacion
	,RPR.FechaModificacion = GETDATE()
	,RPR.DocumentoNombre = NULL
	,RPR.DocumentoNombreOrigen = NULL
	FROM Matricula M WITH (NOLOCK)
	INNER JOIN Promocion PR WITH (NOLOCK) ON M.IdPromocion = PR.IdPromocion
	INNER JOIN RegistroProductoRequisito RPR WITH (NOLOCK) ON M.IdActor = RPR.IdActor AND PR.IdProducto = RPR.IdProducto AND M.IdRegistro = RPR.IdRegistro
	INNER JOIN MaestroTablaRegistro MTR WITH (NOLOCK) ON RPR.IdRequisito = MTR.IdMaestroRegistro
	WHERE M.IdMatricula = @IdMatricula
	AND RPR.IdPlantilla = 1
	AND MTR.Codigo IN ('FICHA','DNI','F_MATRICUL') --@12

	UPDATE LogAsignacionFichaMatriculaGenerarMail SET Estado = 0
	,UsuarioModificacion = @UsuarioCreacion
	,FechaModificacion = GETDATE()
	WHERE IdAsignacionFichaMatricula = @IdAsignacionFichaMatriculaXMatricula

	UPDATE AsignacionFichaMatricula SET Estado = 0
	,UsuarioModificacion = @UsuarioCreacion
	,FechaModificacion = GETDATE()
	WHERE IdMatricula = @IdMatricula
	AND IdAsignacionFichaMatricula = @IdAsignacionFichaMatriculaXMatricula

	UPDATE Matricula SET IdAsignacionFichaMatricula = NULL
	WHERE IdMatricula = @IdMatricula
	AND IdAsignacionFichaMatricula = @IdAsignacionFichaMatriculaXMatricula
	--Fin --@11

	-- ANULAR TODOS LOS RETIROS      
	IF EXISTS(SELECT TOP 1 * FROM MatriculaRetiro WITH (NOLOCK) WHERE IdMatricula=@IdMatricula and Estado <> 'X')      
	BEGIN      
		UPDATE MatriculaRetiro      
			SET Estado='X'      
			,UsuarioModificacion = @UsuarioCreacion      
			,FechaModificacion = GETDATE()      
		WHERE IdMatricula=@IdMatricula      
	END      
	SET @RetVal=0      
	--SELECT @RetVal      
	--   select 's'=@NoMatricula      
	--se modifico 01/02/2013      
	--Emitimos la nota de credito por lo cobrado    
  
	exec cInterfaseDocumento_Update_NC @IdMatricula, @valor      
	--print 'sp1 ok'    
	--Borramos la interface      
	exec cInterfaseDocumento_Ins_Borrar_General @IdMatricula, @valor      
	--print 'sp2 ok'        
      
	--exec cPersonaInter_Pro_Eliminar @IdMatricula      
	--    print 'sp3 ok'    
      
	--Proceso de beca      
	select @IdTipoBeca=D.IdTipo      
	from Matricula M WITH (NOLOCK)      
	inner join Descuento D WITH (NOLOCK)      
	on M.IdDescuento=d.IdDescuento      
	where IdMatricula=@IdMatricula   
	
	IF @EsMasivo = 1 and @RetVal=0
	BEGIN
	INSERT INTO [bdadmin].[dbo].[Matricula_Log]
           ([IdMatricula]
           ,[IdEmpresa]
           ,[IdSede]
           ,[IdCampana]
           ,[IdActor]
           ,[IdRegistro]
           ,[IdCurricula]
           ,[IdModulo]
           ,[IdPromocion]
           ,[IdGrupo]
           ,[IdSeccion]
           ,[IdAutorizacion]
           ,[Numero]
           ,[InscritoFecha]
           ,[InscritoIdUsuario]
           ,[InscritoIdEquipo]
           ,[InscritoNo]
           ,[MatriculaFecha]
           ,[MatriculaIdUsuario]
           ,[EsMatricula]
           ,[EsComision]
           ,[EsCerrado]
           ,[IdDescuento]
           ,[IdTipoMedio]
           ,[IdMedio]
           ,[IdProcedencia]
           ,[IdSocio]
           ,[IdConvenio]
           ,[IdEntidad]
           ,[IdBeca]
           ,[IdPlanPago]
           ,[IdMoneda]
           ,[MontoMoneda]
           ,[TipoInscripcion]
           ,[TipoCondicion]
           ,[TipoServicio]
           ,[Tipo]
           ,[Observacion]
           ,[Estado]
           ,[UsuarioCreacion]
           ,[FechaCreacion]
           ,[UsuarioModificacion]
           ,[FechaModificacion]
           ,[CondicionPago]
           ,[IdPeriodo]
           ,[seccion]
           ,[ObservacionPrePago]
           ,[NumeroCuota]
           ,[IndicadorAcademico]
           ,[IndicadorAsistencias]
           ,[IndicadorMorosidad]
           ,[TipoCondicionFinal]
           ,[IdTipoPromocionBeca]
           ,[IdGrupoDescuento]
           ,[c_tipo_oper]
           ,[f_fech_regi]
           ,[d_usua_modi])

    SELECT TOP 1 [IdMatricula]
           ,[IdEmpresa]
           ,[IdSede]
           ,[IdCampana]
           ,[IdActor]
           ,[IdRegistro]
           ,[IdCurricula]
           ,[IdModulo]
           ,[IdPromocion]
           ,[IdGrupo]
           ,[IdSeccion]
           ,[IdAutorizacion]
           ,[Numero]
           ,[InscritoFecha]
           ,[InscritoIdUsuario]
           ,[InscritoIdEquipo]
           ,[InscritoNo]
           ,[MatriculaFecha]
        ,[MatriculaIdUsuario]
           ,[EsMatricula]
           ,[EsComision]
           ,[EsCerrado]
           ,[IdDescuento]
           ,[IdTipoMedio]
           ,[IdMedio]
           ,[IdProcedencia]
           ,[IdSocio]
           ,[IdConvenio]
           ,[IdEntidad]
           ,[IdBeca]
           ,[IdPlanPago]
           ,[IdMoneda]
           ,[MontoMoneda]
           ,[TipoInscripcion]
           ,[TipoCondicion]
           ,[TipoServicio]
           ,[Tipo]
           ,[Observacion]
           ,[Estado]
           ,[UsuarioCreacion]
           ,[FechaCreacion]
           ,[UsuarioModificacion]
           ,[FechaModificacion]
           ,[CondicionPago]
           ,[IdPeriodo]
           ,[seccion]
           ,[ObservacionPrePago]
           ,[NumeroCuota]
           ,[IndicadorAcademico]
           ,[IndicadorAsistencias]
           ,[IndicadorMorosidad]
           ,[TipoCondicionFinal]
           ,[IdTipoPromocionBeca]
           ,[IdGrupoDescuento]
		   ,'A'
		   ,GETDATE()
		   ,@UsuarioCreacion
		   FROM Matricula where IdMatricula = @IdMatricula;


	END

      
      
	IF EXISTS(SELECT TOP 1 * FROM BecaActor WITH (NOLOCK) WHERE IdMatricula=@IdMatricula)      
	BEGIN      
		IF @IdTipoBeca=931      
		BEGIN      
			DELETE BecaActor  where IdMatricula=@IdMatricula      
		END      
	END
		
	SET @RetVal=0      
      
      
	IF @NoMatricula=1 and @NoRegistro=0  --Tiene solo una matricula      
	BEGIN      
		--select 'entro'      
		UPDATE Registro       
		SET Estado ='X'      
		WHERE IdActor=@IdActor      
		AND IdRegistro=@IdRegistro      
        
		delete AlumnoAsistenciaAdmision      
		where idmatricula = @IdMatricula      
      
		SELECT @RetVal      
	END

