--exec cTramiteReporte_Xls_TRA00001 @IdEmpresa=1,@IdSede=-1,@IdTramite=3,@IdTipoTramite=1,@FechaInicio=N'20240608',@FechaFin=N'20240608'
--sp_helptext cTramiteReporte_Xls_TRA00001
--����������������������������������������������������������������������������      
--Creado por      : Jimy Mota(20/06/2016)      
--Funcionalidad   :       
--Utilizado por   : TramiteReporte.XlsTRA00001      
--Proyecto        : Tr�mites virtuales            
--����������������������������������������������������������������������������            
/*          
-----------------------------------------------------------------------------          
Nro		FECHA			USUARIO						DESCRIPCION          
-----------------------------------------------------------------------------         
@1		24/08/2018		Jnavia						Se agrega al reporte otro tr�mite      
@2		11.01.2019		Eloy Alva (Sigcomt)			Agregar parametro CompaniaSocio.    
@3		13.03.2019		Leandro Ordo�ez (Sigcomt)	Modificio LinkServer a tabla replicada    
@4		23.04.2019		Giancarlos Cuba(Sigcomt)	Se retira la sede de ica y chincha de la validaci�n ASOC.    
@5		20.06.2019		JLEO						Se a�ade reporte de justificaci�n de inasistencias.    
@6		26/06/2019		CSANCHEZL					Se a�ade la columna de EstadoMatricula.  
@7		12/09/2019		JRAVICHAGUA					Se remplaza las funciones fecha112 por convert  
@8		29/07/2020		Hmora						Tramite generico reporte 
@9		16/02/2022		Jmota						Tramite generico reporte se modifica consulta
@10		01/03/2022		JCURE						Se agrega columna para Tramites EE,FC (generico)
@11		03/03/2022		Illosa						Se agrega el login del encargado del tramite generado 
@12		08/03/2022		Illosa						Generaci�n de reporte general de Tr�mites de Formaci�n Continua
@13		20.05.05		jmota						se agregan campos en tramites de notas e inasistencias 
@14		20/07/2022		joarce						Generaci�n de reporte general de Tr�mites Gen�ricos (Orden 22)
@15		2022.08.17		jmota						se agregan campos de promocion y seccion del examen de recuperacion 
@16		09/11/2022		jcure						se agregan campos nuevos al tramite SOLEXSUF
@17		30/11/2022		Illosa						Se agrega reporte de Reprogramacion de Facilitadores  
@18		28/04/2023		Illosa						Se agrega campo de nota de examen de recuperacion -- SOLEXREC  
@19		15/05/2024		JQuenta						Se agrega INNER JOIN Periodo para mostrar Columna del Periodo en el Reporte de Tramites por Tramite "Examen de Suficiencia"
*/      
--EXEC [cTramiteReporte_Xls_TRA00001] 1,-1,9000,2,'20211101','20220720'
--CREATE PROCEDURE [dbo].[cTramiteReporte_Xls_TRA00001]   
declare
@IdEmpresa  INT,      
@IdSede   INT,      
@IdTramite  INT,      
@IdTipoTramite  INT,      
@FechaInicio    VARCHAR(15),      
@FechaFin  VARCHAR(15)        
--AS      
BEGIN      
      select @IdEmpresa=1,@IdSede=-1,@IdTramite=3,@IdTipoTramite=1,@FechaInicio=N'20240606',@FechaFin=N'20240608'
 SET NOCOUNT ON         
       
 DECLARE @CompaniaSocio CHAR(8)      
 SELECT @CompaniaSocio = CompaniaSocio  FROM Empresa e WITH(NOLOCK) WHERE E.IdEmpresa=@IdEmpresa --@2       
       
 DECLARE  @Codigo VARCHAR(50)      
 
	IF @IdTramite <> 9000  --@12 
	 BEGIN
	 	SELECT @Codigo = Codigo FROM WFTramite WITH(NOLOCK) WHERE IdTramite = @IdTramite  
	 END
  
	IF @Codigo = 'SOLCORNOTA'      
	BEGIN 
		SELECT       
		'Sede'=S.Nombre       
		,'Nro_Solicitud'=WTSO.IdTramiteSolicitud       
		--,'Tipo_Tr�mite' = WFTT.CodigoTipoTramite         
		,'Tr�mite'=WT.Nombre      
		,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
		,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.Fecha)      
		,'Estado_Solicitud'= WFN.TituloNodoProceso      
		,'Alumno'= ISNULL(A.NombreCompleto,'')      
		,'Alumno_Email'= ISNULL(AL.EmailInstitucion,'')      
		,'Facilitador'= AFA.NombreCompleto      
		,'Facilitador_Email'= ISNULL(FA.EmailInstitucion,'')      
		,'Descripcion_Alumno'=WTSO.Observacion       
		,'Descripcion_Docente'=WTSO.Observacion2 
		,'Division' =  ISNULL(UN.Nombre,'') -- @13
		,'Programa' =  ISNULL(UA.Nombre,'')   -- @13     
		,'PromocionNombre' = ISNULL(P.PromocionNombre,'') -- @13
		,'PromocionCodigo' = ISNULL(P.PromocionCodigo,'')   -- @13     
		,'Curso'= WTSO.Disponible1       
		,'Seccion_Curso_Ambiente'= '['+PG.GrupoCodigo+'] '+C.CursoNombre+' ('+AMB.Codigo +')'       
		,'Evaluacion'=NOTA.Nombre        
		,'Nota_Anterior' =  ISNULL(nd.NotaActual,'')      
		,'Nota_Registrada' = ISNULL(nd.NotaRegistrada,'')      
		,'Nota_Actual'=ACN.Valor      
		,'Alumno_Nota'= ISNULL(AALDET.NombreCompleto,'')      
		,'Alumno_Email_Nota'= ISNULL(ADET.EmailInstitucion,'')  
		FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
		INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
		INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
		INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
		INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
		INNER JOIN Sede S  WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
		LEFT JOIN Alumno AL  WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor   
		LEFT JOIN Actor A  WITH(NOLOCK) ON A.IdActor = AL.IdAlumno     
		LEFT JOIN Usuario UF  WITH(NOLOCK) ON UF.IdUsuario = WTSO.IdUsuarioResponsable        
		LEFT JOIN Facilitador FA  WITH(NOLOCK) ON FA.IdFacilitador = UF.IdActor        
		LEFT JOIN Actor AFA  WITH(NOLOCK) ON AFA.IdActor = FA.IdFacilitador      
		LEFT JOIN WFTramiteSolicitudNotaDetalle ND  WITH(NOLOCK) ON ND.IdTramiteSolicitud =  WTSO.IdTramiteSolicitud 
		LEFT JOIN Alumno ADET  WITH(NOLOCK) ON ADET.IdAlumno = ND.IdAlumno      
		LEFT JOIN Actor AALDET  WITH(NOLOCK) ON AALDET.IdActor = ADET.IdAlumno      
		LEFT JOIN Seccion SEC WITH(NOLOCK) ON SEC.IdSeccion=ND.IdSeccion        
		LEFT JOIN PromocionGrupo  PG WITH(NOLOCK) ON PG.IdPromocion = SEC.IdPromocion AND PG.IdGrupo = SEC.IdGrupo
		LEFT JOIN Promocion P WITH(NOLOCK) ON PG.IdPromocion = P.IdPromocion 
		LEFT JOIN UnidadNegocio UN  WITH(NOLOCK) ON  P.IdUnidadNegocio = UN.IdUnidadNegocio 
		LEFT JOIN UnidadAcademica UA  WITH(NOLOCK) ON  P.IdUnidadAcademica = UA.IdUnidadAcademica      
		LEFT JOIN Ambiente AMB WITH(NOLOCK) ON AMB.IdAmbiente = SEC.IdAmbiente         
		LEFT JOIN Curso C WITH(NOLOCK) on C.IdCurso=SEC.IdCurso          
		LEFT join AlumnoCursoNota ACN  WITH(NOLOCK)on ACN.IdSeccion=SEC.IdSeccion AND ACN.IdAlumno=ND.IdAlumno --AND ACN.IdCalificacion=ND.IdCalificacion          
		LEFT JOIN Nota N  WITH (NOLOCK) ON ACN.IdSeccion=N.IdSeccion and ACN.IdCalificacion=N.IdCalificacion AND N.IdCalificacion=ND.IdCalificacion       
		LEFT JOIN MaestroTablaRegistro NOTA WITH (NOLOCK) ON N.IdTipoPromedioNota = NOTA.IdMaestroRegistro            
		WHERE WT.Codigo = 'SOLCORNOTA' AND NOTA.IdMaestroRegistro  not in(780,1093,1095,1104)      
		AND (S.IdSede = @IdSede OR @IdSede = -1 )      
		AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7         
		ORDER BY S.IdSede , WFN.IdWFNodoProceso      
	END       
      
	IF @Codigo = 'SOLRECIN'      
	BEGIN      
		SELECT       
		'Sede'=S.Nombre       
		,'Nro_Solicitud'=WTSO.IdTramiteSolicitud       
		--,'Tipo_Tr�mite' = WFTT.CodigoTipoTramite         
		,'Tr�mite'=WT.Nombre      
		,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
		,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.Fecha)      
		,'Estado_Solicitud'= WFN.TituloNodoProceso      
		,'Facilitador'= A.NombreCompleto      
		,'Facilitador_Email'= ISNULL(FA.EmailInstitucion,'')      
		,'Alumno'= ISNULL(AAL.NombreCompleto,'')      
		,'Alumno_Email'= ISNULL(AL.EmailInstitucion,'')      
		,'Descripcion'=WTSO.Observacion
		,'Division' =  ISNULL(UN.Nombre,'') -- @13
		,'Programa' =  ISNULL(UA.Nombre,'')   -- @13     
		,'PromocionNombre' = ISNULL(P.PromocionNombre,'')  -- @13
		,'PromocionCodigo' = ISNULL(P.PromocionCodigo,'')    -- @13     
		,'Seccion_Curso_Ambiente'= '['+PG.GrupoCodigo+'] '+C.CursoNombre+' ('+AMB.Codigo +')'       
		,'Sessiones'=COUNT(ND.IdTramiteSolicitudAsistenciaDetalle)          
		,'Alumno_Nota'= ISNULL(AALDET.NombreCompleto,'')      
		,'Alumno_Email_Nota'= ISNULL(ADET.EmailInstitucion,'')      
		FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
		INNER JOIN WFNodo WFN  WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
		INNER JOIN WFTramiteSede WTS  WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
		INNER JOIN WFTramite WT  WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
		INNER JOIN WFTipoTramite WFTT  WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
		INNER JOIN Sede S  WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
		LEFT JOIN Facilitador FA  WITH(NOLOCK) ON FA.IdFacilitador = WTSO.IdActor        
		LEFT JOIN Actor A  WITH(NOLOCK) ON A.IdActor = FA.IdFacilitador      
		LEFT JOIN Usuario UINF  WITH(NOLOCK) ON UINF.IdUsuario = WTSO.IdUsuarioInfo         
		LEFT JOIN Alumno AL  WITH(NOLOCK) ON AL.IdAlumno = UINF.IdActor        
		LEFT JOIN Actor AAL  WITH(NOLOCK) ON AAL.IdActor = AL.IdAlumno      
		LEFT JOIN WFTramiteSolicitudAsistenciaDetalle ND  WITH(NOLOCK) ON ND.IdTramiteSolicitud =  WTSO.IdTramiteSolicitud      
		LEFT JOIN Alumno ADET  WITH(NOLOCK) ON ADET.IdAlumno = ND.IdAlumno      
		LEFT JOIN Actor AALDET  WITH(NOLOCK) ON AALDET.IdActor = ADET.IdAlumno      
		LEFT JOIN Seccion SEC WITH(NOLOCK) ON SEC.IdSeccion=ND.IdSeccion        
		LEFT JOIN PromocionGrupo  PG WITH(NOLOCK) ON PG.IdPromocion = SEC.IdPromocion AND PG.IdGrupo = SEC.IdGrupo
		LEFT JOIN Promocion P WITH(NOLOCK) ON PG.IdPromocion = P.IdPromocion 
		LEFT JOIN UnidadNegocio UN  WITH(NOLOCK) ON  P.IdUnidadNegocio = UN.IdUnidadNegocio 
		LEFT JOIN UnidadAcademica UA  WITH(NOLOCK) ON  P.IdUnidadAcademica = UA.IdUnidadAcademica            
		LEFT JOIN Ambiente AMB WITH(NOLOCK) ON AMB.IdAmbiente = SEC.IdAmbiente         
		LEFT JOIN Curso C WITH(NOLOCK) on C.IdCurso=SEC.IdCurso               
		WHERE WT.Codigo = 'SOLRECIN'      
		AND (S.IdSede = @IdSede    OR @IdSede = -1 )      
		AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7        
		GROUP BY S.Nombre,WTSO.IdTramiteSolicitud ,WT.Nombre,WTSO.Fecha,WFN.TituloNodoProceso,A.NombreCompleto,FA.EmailInstitucion,      
		AAL.NombreCompleto,AL.EmailInstitucion,WTSO.Observacion,PG.GrupoCodigo,C.CursoNombre,AMB.Codigo ,AALDET.NombreCompleto,ADET.EmailInstitucion,      
		S.IdSede , WFN.IdWFNodoProceso , P.PromocionNombre,P.PromocionCodigo,UN.Nombre,UA.Nombre            
		ORDER BY S.IdSede , WFN.IdWFNodoProceso        
	END       
       
	IF @Codigo = 'SOLDIPAE'      
	BEGIN      
	  /*CONSULTA IPAE*/      
	  SELECT     
	  'Sede'=S.Nombre       
	  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
	  ,'Tr�mite'=WT.Nombre      
	  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
	  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.Fecha)      
	  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
	  ,'Alumno'= ISNULL(A.NombreCompleto,'')      
	  ,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')      
	  ,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
	  ,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
			  WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
			  WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
			  ELSE '' END      
	  ,'Vencimiento_Pago'=DBO.Fecha(COH.FechaVencimiento)      
	  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
	  INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
	  INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
	  INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
	  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
	  INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
	  LEFT JOIN Alumno AL WITH(NOLOCK)ON AL.IdAlumno = WTSO.IdActor        
	  LEFT JOIN Actor A WITH(NOLOCK)ON A.IdActor = AL.IdAlumno      
	  LEFT JOIN CO_Interfase_P09_Header COH WITH(NOLOCK) /*@3*/ ON COH.NumeroInterno = WTSO.NroPedido      
	  and COH.CompaniaSocio=@CompaniaSocio --@2      
	  --LEFT JOIN P L D B 0 1.S p r i n g U n i d o.dbo.CO_Interfase_P09_Header COH ON COH.NumeroInterno = WTSO.NroPedido      
	  WHERE WTS.IdSede NOT IN (4) and WT.Codigo = 'SOLDIPAE' --AND NroPedido IS NOT NULL --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
	  AND (S.IdSede = @IdSede    OR @IdSede = -1 )      
	  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7         
       
	  UNION ALL       
      
	  /*CONSULTA ASOC*/      
	  SELECT       
	  'Sede'=S.Nombre       
	  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
	  ,'Tr�mite'=WT.Nombre      
	  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
	  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.Fecha)      
	  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
	  ,'Alumno'= ISNULL(A.NombreCompleto,'')      
	  ,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')      
	  ,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
	  ,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
			  WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
			  WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
			  ELSE '' END      
	  ,'Vencimiento_Pago'=DBO.Fecha(COH.FechaVencimiento)      
	  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
	  INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
	  INNER JOIN WFTramiteSede WTS WITH(NOLOCK)  ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
	  INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
	  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
	  INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
	  LEFT JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
	  LEFT JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno       
	  LEFT JOIN CO_Interfase_P09_Header_ASOC COH WITH(NOLOCK) /*@3*/ ON COH.NumeroInterno = WTSO.NroPedido      
	  and COH.CompaniaSocio=@CompaniaSocio --@2      
	  --LEFT JOIN S I D B 0 1.S p r i n g U n i d o.dbo.CO_Interfase_P09_Header COH ON COH.NumeroInterno = WTSO.NroPedido      
	  WHERE WTS.IdSede IN (4) and WT.Codigo = 'SOLDIPAE' --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
	  AND (S.IdSede = @IdSede    OR @IdSede = -1 )      
	  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7         
	END      
       
	IF @Codigo = 'SOLMEDIO'      
	 BEGIN      
	  SELECT       
	  'Sede'=S.Nombre       
	  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
	  ,'Tr�mite'=WT.Nombre      
	  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
	  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.Fecha)      
	  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
	  ,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
	  ,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
			  WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
			  WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
			  ELSE '' END      
	  ,'Vencimiento_Pago'=DBO.Fecha(COH.FechaVencimiento)      
	  ,'COD_TIPO_DOCUMENTO'= ISNULL(TDOC.Disponible2,'')      
	  ,'TIPO_DOCUMENTO'= ISNULL(TDOC.Nombre,'')      
	  ,'NUMERO_DOCUMENTO'= ISNULL(A.NumeroIdentidad,'')      
	  ,'APELLIDO_PATERNO'=ISNULL(A.Paterno,'')       
	  ,'APELLIDO_MATERNO'=ISNULL(A.Materno,'')       
	  ,'NOMBRES'=ISNULL(A.Nombres,'')      
	  ,'COD_CARRERA'=''      
	  ,'CARRERA'= (SELECT TOP 1 P.PromocionNombre                   
		   FROM Matricula M  with(nolock)                            
		   INNER JOIN Promocion P with(nolock) ON M.IdPromocion=P.IdPromocion                      
		   WHERE M.IdActor=WTSO.IdActor                             
		   AND P.IdUnidadNegocio=1            
		   And M.EStado<>'X'                    
		   ORDER BY isnull(m.MatriculaFecha,m.InscritoFecha)DESC )         
	  ,'FECHA_DE_NACIMIENTO'=cast(CM.FechaNacimiento as varchar)       
	  ,'COD_GENERO'= CASE WHEN A.Genero = 1 THEN '1' WHEN A.Genero = 0 THEN '2' ELSE '' END       
	  ,'GENERO'= CASE WHEN A.Genero = 1 THEN 'MASCULINO' WHEN A.Genero = 0 THEN 'FEMENINO' ELSE '' END       
	  ,'COD_ESTADO_CIVIL'= ISNULL(TEC.Disponible2 ,'')      
	  ,'ESTADO_CIVIL'= ISNULL(TEC.Nombre ,'')      
	  ,'COD_NACIONALIDAD' = CASE WHEN ISNULL(TNC.Disponible2,'') = '' THEN '2' ELSE TNC.Disponible2 END        
	  ,'NACIONALIDAD' = CASE WHEN ISNULL(TNC.Disponible2,'') = '' THEN 'EXTRANJERO' ELSE TNC.Nombre  END        
	  ,'COD_UBIGEO'=CM.IdUbigeo --UB.Codigo       
	  ,'COD_UBIGEO'=UB.NombreUnido       
	  ,'DIRECCION'=CM.Direccion       
	  ,'EMAIL'=AL.EmailInstitucion        
	  ,'TELEFONO'=CM.TlfFijo       
	  ,'TELEFONO_CELULAR'=CM.Celular      
	  ,'TELEFONO_DE_EMERGENCIA'=CM.TlfOpciona       
	  ,'COD_TIPO_DE_SANGRE'=TTSAN.Disponible2       
	  ,'TIPO_DE_SANGRE'=TTSAN.Nombre      
	  ,'COD_TIPO_DE_SEGURO'=TTS.Disponible2      
	  ,'NOMBRE_SEGURO'=CM.NombreSeguro        
	  ,'CONTRAINDICACIONES_MEDICAS_1'=CM.Disponible1       
	  ,'CONTRAINDICACIONES_MEDICAS_2'=''      
	  ,'CONTRAINDICACIONES_MEDICAS_3'=''      
	  ,'CONTRAINDICACIONES_MEDICAS_4'=''      
	  ,'CONTRAINDICACIONES_MEDICAS_5'=''      
	  ,'ENFERMEDADES_PRE-EXISTENTES_1'=CM.Disponible2       
	  ,'ENFERMEDADES_PRE-EXISTENTES_2'=''      
	  ,'ENFERMEDADES_PRE-EXISTENTES_3'=''       
	  ,'ENFERMEDADES_PRE-EXISTENTES_4'=''       
	  ,'ENFERMEDADES_PRE-EXISTENTES_5'=''       
	  ,'CAMPO_GENERICO_1'=''       
	  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
	  INNER JOIN WFNodo WFN WITH(NOLOCK)ON WFN.IdWFNodoProceso = WTSO.IdEstado        
	  INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
	  INNER JOIN WFTramite WT WITH(NOLOCK)ON WT.IdTramite =   WTS.IdTramite       
	  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK)ON WFTT.IdTipoTramite = WT.IdTipoTramite        
	  INNER JOIN Sede S WITH(NOLOCK)ON S.IdSede = WTS.IdSede       
	  INNER JOIN WFTramiteSolicitudCarneMedio CM WITH(NOLOCK) ON CM.IdTramiteSolicitud = WTSO.IdTramiteSolicitud       
	  INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
	  INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno      
	  LEFT JOIN MaestroTablaRegistro TDOC WITH(NOLOCK) ON TDOC.IdMaestroRegistro = A.IdDocumentoTipo       
	  INNER JOIN MaestroTablaRegistro TEC WITH(NOLOCK) ON TEC.IdMaestroRegistro = CM.IdEstadoCivil      
	  LEFT JOIN MaestroTablaRegistro TECA WITH(NOLOCK) ON TECA.IdMaestroRegistro = A.IdEstadoCivil        
	  INNER JOIN MaestroTablaRegistro TNC WITH(NOLOCK) ON TNC.IdMaestroRegistro = CM.IdNacionalidad       
	  LEFT JOIN MaestroTablaRegistro TNCA WITH(NOLOCK) ON TNCA.IdMaestroRegistro = A.IdNacionalidad       
	  INNER JOIN Ubigeo UB WITH(NOLOCK) ON UB.IdUbigeo = CM.IdUbigeo       
	  INNER JOIN MaestroTablaRegistro TTS WITH(NOLOCK) ON TTS.IdMaestroRegistro = CM.IdTipoSeguro       
	  INNER JOIN MaestroTablaRegistro TTSAN WITH(NOLOCK) ON TTSAN.IdMaestroRegistro = CM.IdTipoSangre      
	  LEFT JOIN CO_Interfase_P09_Header COH WITH(NOLOCK) /*@3*/ ON COH.NumeroInterno = WTSO.NroPedido      
	  and COH.CompaniaSocio=@CompaniaSocio --@2      
	  WHERE WTS.IdSede NOT IN (4) and WT.Codigo = 'SOLMEDIO' --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
	  AND (S.IdSede = @IdSede OR @IdSede = -1 )      
	  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
  --AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin      
        
  UNION ALL       
        
  SELECT       
  'Sede'=S.Nombre       
  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
  ,'Tr�mite'=WT.Nombre      
  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.Fecha)      
  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
 ,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
  ,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
          WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
          WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
          ELSE '' END      
  ,'Vencimiento_Pago'=DBO.Fecha(COH.FechaVencimiento)      
  ,'COD_TIPO_DOCUMENTO'= ISNULL(TDOC.Disponible2,'')      
  ,'TIPO_DOCUMENTO'= ISNULL(TDOC.Nombre,'')      
  ,'NUMERO_DOCUMENTO'= ISNULL(A.NumeroIdentidad,'')      
  ,'APELLIDO_PATERNO'=ISNULL(A.Paterno,'')       
  ,'APELLIDO_MATERNO'=ISNULL(A.Materno,'')       
  ,'NOMBRES'=ISNULL(A.Nombres,'')      
  ,'COD_CARRERA'=''      
  ,'CARRERA'= (SELECT TOP 1 P.PromocionNombre                   
       FROM Matricula M  with(nolock)                            
       INNER JOIN Promocion P with(nolock) ON M.IdPromocion=P.IdPromocion                      
       WHERE M.IdActor=WTSO.IdActor                             
       AND P.IdUnidadNegocio=1            
       And M.EStado<>'X'                    
       ORDER BY isnull(m.MatriculaFecha,m.InscritoFecha)DESC )         
  ,'FECHA_DE_NACIMIENTO'=cast(CM.FechaNacimiento as varchar)      
  ,'COD_GENERO'= CASE WHEN A.Genero = 1 THEN '1' WHEN A.Genero = 0 THEN '2' ELSE '' END       
  ,'GENERO'= CASE WHEN A.Genero = 1 THEN 'MASCULINO' WHEN A.Genero = 0 THEN 'FEMENINO' ELSE '' END       
  ,'COD_ESTADO_CIVIL'= ISNULL(TEC.Disponible2 ,'')      
  ,'ESTADO_CIVIL'= ISNULL(TEC.Nombre ,'')      
  ,'COD_NACIONALIDAD' = CASE WHEN ISNULL(TNC.Disponible2,'') = '' THEN '2' ELSE TNC.Disponible2 END        
  ,'NACIONALIDAD' = CASE WHEN ISNULL(TNC.Disponible2,'') = '' THEN 'EXTRANJERO' ELSE TNC.Nombre  END        
  ,'COD_UBIGEO'=CM.IdUbigeo --UB.Codigo       
  ,'COD_UBIGEO'=UB.NombreUnido       
  ,'DIRECCION'=CM.Direccion       
  ,'EMAIL'=AL.EmailInstitucion        
  ,'TELEFONO'=CM.TlfFijo       
  ,'TELEFONO_CELULAR'=CM.Celular      
  ,'TELEFONO_DE_EMERGENCIA'=CM.TlfOpciona       
  ,'COD_TIPO_DE_SANGRE'=TTSAN.Disponible2       
  ,'TIPO_DE_SANGRE'=TTSAN.Nombre      
  ,'COD_TIPO_DE_SEGURO'=TTS.Disponible2      
  ,'NOMBRE_SEGURO'=CM.NombreSeguro        
  ,'CONTRAINDICACIONES_MEDICAS_1'=CM.Disponible1       
  ,'CONTRAINDICACIONES_MEDICAS_2'=''      
  ,'CONTRAINDICACIONES_MEDICAS_3'=''      
  ,'CONTRAINDICACIONES_MEDICAS_4'=''      
  ,'CONTRAINDICACIONES_MEDICAS_5'=''      
  ,'ENFERMEDADES_PRE-EXISTENTES_1'=CM.Disponible2       
  ,'ENFERMEDADES_PRE-EXISTENTES_2'=''      
  ,'ENFERMEDADES_PRE-EXISTENTES_3'=''       
  ,'ENFERMEDADES_PRE-EXISTENTES_4'=''       
  ,'ENFERMEDADES_PRE-EXISTENTES_5'=''       
  ,'CAMPO_GENERICO_1'=''       
  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
  INNER JOIN WFNodo WFN WITH(NOLOCK)ON WFN.IdWFNodoProceso = WTSO.IdEstado        
  INNER JOIN WFTramiteSede WTS WITH(NOLOCK)ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
  INNER JOIN WFTramite WT WITH(NOLOCK)ON WT.IdTramite =   WTS.IdTramite       
  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK)ON WFTT.IdTipoTramite = WT.IdTipoTramite        
  INNER JOIN Sede S WITH(NOLOCK)ON S.IdSede = WTS.IdSede       
  INNER JOIN WFTramiteSolicitudCarneMedio CM WITH(NOLOCK) ON CM.IdTramiteSolicitud = WTSO.IdTramiteSolicitud       
  INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
  INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno      
  INNER JOIN MaestroTablaRegistro TDOC WITH(NOLOCK) ON TDOC.IdMaestroRegistro = A.IdDocumentoTipo       
  INNER JOIN MaestroTablaRegistro TEC WITH(NOLOCK) ON TEC.IdMaestroRegistro = CM.IdEstadoCivil      
  INNER JOIN MaestroTablaRegistro TECA WITH(NOLOCK) ON TECA.IdMaestroRegistro = A.IdEstadoCivil        
  INNER JOIN MaestroTablaRegistro TNC WITH(NOLOCK) ON TNC.IdMaestroRegistro = CM.IdNacionalidad       
  INNER JOIN MaestroTablaRegistro TNCA WITH(NOLOCK) ON TNCA.IdMaestroRegistro = A.IdNacionalidad       
  INNER JOIN Ubigeo UB WITH(NOLOCK) ON UB.IdUbigeo = CM.IdUbigeo       
  INNER JOIN MaestroTablaRegistro TTS WITH(NOLOCK) ON TTS.IdMaestroRegistro = CM.IdTipoSeguro       
  INNER JOIN MaestroTablaRegistro TTSAN WITH(NOLOCK) ON TTSAN.IdMaestroRegistro = CM.IdTipoSangre       
  LEFT JOIN CO_Interfase_P09_Header_ASOC COH WITH(NOLOCK) /*@3*/ ON COH.NumeroInterno = WTSO.NroPedido 
  and COH.CompaniaSocio=@CompaniaSocio --@2      
  WHERE WTS.IdSede IN (4) and WT.Codigo = 'SOLMEDIO' --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
  AND (S.IdSede = @IdSede    OR @IdSede = -1 )      
  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
	 --AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin      
	 END       
	      
	IF @Codigo = 'CARPASAISE'      
	 BEGIN      
	  SELECT      
	  'Id' = IDENTITY (INT, 1, 1)      
	  ,'Sede'=S.Nombre       
	  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
	  ,'Tr�mite'=WT.Nombre      
	  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
	  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.Fecha)      
	  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END       
	  ,'COD_TIPO_DOCUMENTO'= ISNULL(TDOC.Disponible2,'')      
	  ,'TIPO_DOCUMENTO'= ISNULL(TDOC.Nombre,'')      
	  ,'NUMERO_DOCUMENTO'= ISNULL(A.NumeroIdentidad,'')      
	  ,'APELLIDO_PATERNO'=ISNULL(A.Paterno,'')       
	  ,'APELLIDO_MATERNO'=ISNULL(A.Materno,'')       
	  ,'NOMBRES'=ISNULL(A.Nombres,'')      
	  ,'COD_ALUMNO' = AL.CodigoAnterior       
	  ,'COD_CARRERA'=''      
	  ,'CARRERA'= (SELECT TOP 1 P.PromocionNombre                   
		   FROM Matricula M  with(nolock)                            
		   INNER JOIN Promocion P with(nolock) ON M.IdPromocion=P.IdPromocion                      
		   WHERE M.IdActor=WTSO.IdActor                             
		   AND P.IdUnidadNegocio=1            
		   And M.EStado<>'X'                    
		   ORDER BY isnull(m.MatriculaFecha,m.InscritoFecha)DESC )         
	  ,'FECHA_DE_NACIMIENTO'=cast(CM.FechaNacimiento as varchar)      
	  ,'COD_GENERO'= CASE WHEN A.Genero = 1 THEN '1' WHEN A.Genero = 0 THEN '2' ELSE '' END       
	  ,'GENERO'= CASE WHEN A.Genero = 1 THEN 'MASCULINO' WHEN A.Genero = 0 THEN 'FEMENINO' ELSE '' END       
	  ,'COD_ESTADO_CIVIL'= ISNULL(TEC.Disponible2 ,'')      
	  ,'ESTADO_CIVIL'= ISNULL(TEC.Nombre ,'')      
	  ,'COD_NACIONALIDAD' = CASE WHEN ISNULL(TNC.Disponible2,'') = '' THEN '2' ELSE TNC.Disponible2 END        
	  ,'NACIONALIDAD' = CASE WHEN ISNULL(TNC.Disponible2,'') = '' THEN 'EXTRANJERO' ELSE TNC.Nombre  END        
	  ,'COD_UBIGEO'=CM.IdUbigeo --UB.Codigo       
	  ,'UBIGEO'=UB.NombreUnido       
	  ,'DIRECCION'=CM.Direccion       
	  ,'EMAIL'=AL.EmailInstitucion        
	  ,'TELEFONO'=CM.TlfFijo       
	  ,'TELEFONO_CELULAR'=CM.Celular      
	  ,'TELEFONO_DE_EMERGENCIA'=CM.TlfOpciona       
	  ,'COD_TIPO_DE_SANGRE'=TTSAN.Disponible2       
	  ,'TIPO_DE_SANGRE'=TTSAN.Nombre      
	,'COD_TIPO_DE_SEGURO'=TTS.Disponible2      
	  ,'NOMBRE_SEGURO'=CM.NombreSeguro        
	  ,'CONTRAINDICACIONES_MEDICAS_1'=CM.Disponible1       
	  ,'CONTRAINDICACIONES_MEDICAS_2'=''      
	  ,'CONTRAINDICACIONES_MEDICAS_3'=''      
	  ,'CONTRAINDICACIONES_MEDICAS_4'=''      
	  ,'CONTRAINDICACIONES_MEDICAS_5'=''      
	  ,'ENFERMEDADES_PRE-EXISTENTES_1'=CM.Disponible2       
	  ,'ENFERMEDADES_PRE-EXISTENTES_2'=''      
	  ,'ENFERMEDADES_PRE-EXISTENTES_3'=''       
	  ,'ENFERMEDADES_PRE-EXISTENTES_4'=''       
	  ,'ENFERMEDADES_PRE-EXISTENTES_5'=''       
	  ,'CAMPO_GENERICO_1'=''      
	  ,'SECCION_NOMINA' = '                                                                                                                                                '               
	  ,'SEMESTRE_NOMINA'= '                                                                                                                                                 '      
	  into #WFTramiteSolicitud         
	  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
	  INNER JOIN WFNodo WFN WITH(NOLOCK)ON WFN.IdWFNodoProceso = WTSO.IdEstado        
	  INNER JOIN WFTramiteSede WTS WITH(NOLOCK)ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
	  INNER JOIN WFTramite WT WITH(NOLOCK)ON WT.IdTramite =   WTS.IdTramite       
	  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK)ON WFTT.IdTipoTramite = WT.IdTipoTramite       
	  INNER JOIN Sede S WITH(NOLOCK)ON S.IdSede = WTS.IdSede       
	  INNER JOIN WFTramiteSolicitudCarneMedio CM WITH(NOLOCK) ON CM.IdTramiteSolicitud = WTSO.IdTramiteSolicitud       
	  INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
	  INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno      
	  LEFT JOIN MaestroTablaRegistro TDOC WITH(NOLOCK) ON TDOC.IdMaestroRegistro = A.IdDocumentoTipo       
	  INNER JOIN MaestroTablaRegistro TEC WITH(NOLOCK) ON TEC.IdMaestroRegistro = CM.IdEstadoCivil      
	  LEFT JOIN MaestroTablaRegistro TECA WITH(NOLOCK) ON TECA.IdMaestroRegistro = A.IdEstadoCivil        
	  INNER JOIN MaestroTablaRegistro TNC WITH(NOLOCK) ON TNC.IdMaestroRegistro = CM.IdNacionalidad       
	  LEFT JOIN MaestroTablaRegistro TNCA WITH(NOLOCK) ON TNCA.IdMaestroRegistro = A.IdNacionalidad       
	  INNER JOIN Ubigeo UB WITH(NOLOCK) ON UB.IdUbigeo = CM.IdUbigeo       
	  INNER JOIN MaestroTablaRegistro TTS WITH(NOLOCK) ON TTS.IdMaestroRegistro = CM.IdTipoSeguro       
	  INNER JOIN MaestroTablaRegistro TTSAN WITH(NOLOCK) ON TTSAN.IdMaestroRegistro = CM.IdTipoSangre       
	  WHERE WT.Codigo = 'CARPASAISE'        
	  AND (S.IdSede = @IdSede OR @IdSede = -1 )      
	  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
	  --AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin      
      
	  declare @min int , @max int       
      
	  select @min = min(Id)  , @max = max(Id) from #WFTramiteSolicitud      
      
	  while @min <= @max      
	  begin      
         
	   DECLARE @COD_ALUMNO VARCHAR(300) , @IdAlumno INT , @IdMatricula INT        
      
	   SELECT  @COD_ALUMNO = COD_ALUMNO FROM #WFTramiteSolicitud      
	   WHERE Id = @min       
      
	   select @IdAlumno = IdAlumno from Alumno       
	   where CodigoAnterior  =  @COD_ALUMNO      
      
      
	   SELECT TOP 1 @IdMatricula = m.IdMatricula                    
		   FROM Matricula M  with(nolock)                            
		   INNER JOIN Promocion P with(nolock) ON M.IdPromocion=P.IdPromocion                      
		   WHERE M.IdActor=@IdAlumno                             
		   AND P.IdUnidadNegocio=1            
		   And M.EStado<>'X'                    
		   ORDER BY isnull(m.MatriculaFecha,m.InscritoFecha)DESC       
      
      
	   declare @SeccionNomina nvarchar(4000) = ''      
	   SELECT DISTINCT      
	   @SeccionNomina = coalesce(@SeccionNomina + '  ', '') +       
			 (isnull(ISNULL((select seccionnomina      
			 from alumnocursonomina (NOLOCK)       
			 where idmatricula = ac.idmatricula      
			 and idcurso = ac.idcurso),M.seccion),''))      
	   FROM      
	   AlumnoCurso AC      
	   INNER JOIN Matricula M WITH (NOLOCK) ON M.IdMatricula = AC.IdMatricula      
	   WHERE       
	   AC.IdAlumno=@IdAlumno       
	   AND M.IdMatricula = @IdMatricula       
	   AND AC.EsMatricula=1       
      
      
	   declare @semestre nvarchar(4000) = ''      
	   SELECT DISTINCT      
	   @semestre = coalesce(@semestre + '  ', '') + CM.Nombre       
	   FROM      
	   CurriculaModulo CM WITH (NOLOCK)      
	   INNER JOIN CurriculaCurso CC WITH (NOLOCK) ON CC.IdModulo=CM.IdModulo AND CC.IdCurricula=CM.IdCurricula       
	   INNER JOIN AlumnoCurso AC WITH (NOLOCK) ON AC.IdCurricula=CC.IdCurricula AND AC.IdCurso=CC.IdCurso       
	   WHERE AC.IdMatricula=@IdMatricula  AND AC.EsMatricula=1      
         
	   update #WFTramiteSolicitud set      
	   SECCION_NOMINA = @SeccionNomina      
	   ,SEMESTRE_NOMINA=@semestre      
	   where Id = @min        
      
      
	   set @min = @min +1       
	  end       
	
	   drop table #WFTramiteSolicitud      
      
	 END      
	      
	IF @Codigo = 'SOLEXREC'      
	BEGIN      
		SELECT       
		'Sede'=S.Nombre       
		,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
		,'Tr�mite'=WT.Nombre      
		,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
		,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.FechaCreacion)      
		,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
		,'Alumno'= ISNULL(A.NombreCompleto,'')      
		,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')      
		,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
		,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
								WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
								WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
						ELSE '' END      
		,'Vencimiento_Pago_Spring'=DBO.Fecha(COH.FechaVencimiento)      
		,'Vencimiento_Pago_Smart'=DBO.Fecha(WTSO.FechaVencimiento)      
		,'Fecha_Examen' = dbo.Fecha(SUS.Fecha)      
		,'HoraInicio'=dbo.gHhMmStr(SUS.HoraInicio)       
		,'HoraFin'=dbo.gHhMmStr(SUS.HoraFin) 
		,'PromocionNombre' = ISNULL(P.PromocionNombre,'') --@15
		,'PromocionCodigo' = ISNULL(P.PromocionCodigo,'') --@15
		,'Seccion'= ISNULL(PG.GrupoCodigo,'') --@15
		,'HorarioCodigo' = ISNULL(SEC.Codigo,'')   --@15 
		,'Curso'=CUR.CursoNombre      
		,'Aula'=AMB.Nombre      
		,'Facilitador_Curso'= ASPR.NombreCompleto       
		,'Responsable_Examen'=ISNULL(USU.Nombre,'')      
		,'NombreCalificacion'= LOWER(MTR2.Nombre)      
		,'Valor'=CASE WHEN ACN.Valor='NSP' THEN '0' ELSE ACN.Valor END      
		,NT.Peso      
		,'Nota_Examen'= ISNULL(SA.Nota,'')  ---@18
		FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
		INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
		INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
		INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
		INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
		INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
		INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
		INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno      
		INNER JOIN WFTramiteSolicitudDetalleSustitutorioAlumno WFTSD WITH(NOLOCK) ON WFTSD.IdTramiteSolicitud = WTSO.IdTramiteSolicitud        
		INNER JOIN SustitutorioAlumno SA WITH(NOLOCK) ON WFTSD.IdSustitutorio = SA.IdSustitutorio and al.IdAlumno=sa.IdAlumno and  WFTSD.IdSeccion=sa.IdSeccion  --@18
		INNER JOIN Seccion SEC WITH (NOLOCK) ON SEC.IdSeccion  = WFTSD.IdSeccion
		INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON SEC.IdPromocion = PG.IdPromocion AND SEC.IdGrupo = PG.IdGrupo --@15  
		INNER JOIN Promocion P WITH (NOLOCK) ON SEC.IdPromocion = P.IdPromocion --@15        
		INNER JOIN AlumnoCursoNota ACN WITH(NOLOCK) ON ACN.IdSeccion = SEC.IdSeccion AND ACN.IdCalificacion = WFTSD.IdCalificacion AND ACN.IdAlumno = AL.IdAlumno      
		INNER JOIN Nota NT WITH (NOLOCK) ON NT.IdSeccion = SEC.IdSeccion AND NT.IdCalificacion = ACN.IdCalificacion      
		INNER JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON MTR2.IdMaestroRegistro = NT.IdTipoPromedioNota      
		INNER JOIN SeccionProfesor SPR WITH(NOLOCK) ON SPR.IdSeccion = SEC.IdSeccion AND SPR.EsResponsable = 1  AND SPR.Activo = 1       
		INNER JOIN Actor ASPR WITH(NOLOCK) ON ASPR.IdActor = SPR.IdActor       
		INNER JOIN Curso CUR WITH (NOLOCK) ON CUR.IdCurso = SEC.IdCurso       
		INNER JOIN Sustitutorio SUS  WITH (NOLOCK) ON SUS.IdSustitutorio = WFTSD.IdSustitutorio       
		INNER JOIN Usuario USU WITH (NOLOCK) ON SUS.IdUsuario=USU.IdUsuario          
		INNER JOIN Ambiente AMB WITH (NOLOCK) ON SUS.IdAmbiente=AMB.IdAmbiente       
		LEFT JOIN CO_Interfase_P09_Header COH WITH(NOLOCK) /*@3*/ ON COH.NumeroInterno = WTSO.NroPedido      
		and COH.CompaniaSocio=@CompaniaSocio --@2      
		--LEFT JOIN P L D B 0 1.S p r i n g U n i d o.dbo.CO_Interfase_P09_Header COH ON COH.NumeroInterno = WTSO.NroPedido      
		WHERE WTS.IdSede NOT IN (4) and WT.Codigo = 'SOLEXREC' --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
		AND (S.IdSede = @IdSede OR @IdSede = -1 )      
		AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
		--AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin      
        
		UNION ALL       
        
		SELECT       
		'Sede'=S.Nombre       
		,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
		,'Tr�mite'=WT.Nombre      
		,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
		,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.FechaCreacion)      
		,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
		,'Alumno'= ISNULL(A.NombreCompleto,'')      
		,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')      
		,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
		,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
								WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
								WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
						ELSE '' END      
		,'Vencimiento_Pago_Spring'=DBO.Fecha(COH.FechaVencimiento)      
		,'Vencimiento_Pago_Smart'=DBO.Fecha(WTSO.FechaVencimiento)      
		,'Fecha_Examen' = dbo.Fecha(SUS.Fecha)      
		,'HoraInicio'=dbo.gHhMmStr(SUS.HoraInicio)       
		,'HoraFin'=dbo.gHhMmStr(SUS.HoraFin) 
		,'PromocionNombre' = ISNULL(P.PromocionNombre,'') --@15
		,'PromocionCodigo' = ISNULL(P.PromocionCodigo,'') --@15
		,'Seccion'= ISNULL(PG.GrupoCodigo,'') --@15
		,'HorarioCodigo' = ISNULL(SEC.Codigo,'')   --@15      
		,'Curso'=CUR.CursoNombre      
		,'Aula'=AMB.Nombre     
		,'Facilitador_Curso'= ASPR.NombreCompleto       
		,'Responsable_Examen'=ISNULL(USU.Nombre,'')      
		,'NombreCalificacion'= LOWER(MTR2.Nombre)      
		,'Valor'=CASE WHEN ACN.Valor='NSP' THEN '0' ELSE ACN.Valor END      
		,NT.Peso       
		,'Nota_Examen'= ISNULL(SA.Nota,'')  ---@18
		FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
		INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
		INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
		INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
		INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
		INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
		INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
		INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno 
		INNER JOIN WFTramiteSolicitudDetalleSustitutorioAlumno WFTSD WITH(NOLOCK) ON WFTSD.IdTramiteSolicitud = WTSO.IdTramiteSolicitud        
		INNER JOIN SustitutorioAlumno SA WITH(NOLOCK) ON WFTSD.IdSustitutorio = SA.IdSustitutorio and al.IdAlumno=sa.IdAlumno and  WFTSD.IdSeccion=sa.IdSeccion  --@18
		INNER JOIN Seccion SEC WITH (NOLOCK) ON SEC.IdSeccion  = WFTSD.IdSeccion
		INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON SEC.IdPromocion = PG.IdPromocion AND SEC.IdGrupo = PG.IdGrupo --@15  
		INNER JOIN Promocion P WITH (NOLOCK) ON SEC.IdPromocion = P.IdPromocion --@15        
		INNER JOIN AlumnoCursoNota ACN WITH(NOLOCK) ON ACN.IdSeccion = SEC.IdSeccion AND ACN.IdCalificacion = WFTSD.IdCalificacion AND ACN.IdAlumno = AL.IdAlumno      
		INNER JOIN Nota NT WITH (NOLOCK) ON NT.IdSeccion = SEC.IdSeccion AND NT.IdCalificacion = ACN.IdCalificacion      
		INNER JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON MTR2.IdMaestroRegistro = NT.IdTipoPromedioNota      
		INNER JOIN SeccionProfesor SPR WITH(NOLOCK) ON SPR.IdSeccion = SEC.IdSeccion AND SPR.EsResponsable = 1  AND SPR.Activo = 1       
		INNER JOIN Actor ASPR WITH(NOLOCK) ON ASPR.IdActor = SPR.IdActor       
		INNER JOIN Curso CUR WITH (NOLOCK) ON CUR.IdCurso = SEC.IdCurso       
		INNER JOIN Sustitutorio SUS  WITH (NOLOCK) ON SUS.IdSustitutorio = WFTSD.IdSustitutorio       
		INNER JOIN Usuario USU WITH (NOLOCK) ON SUS.IdUsuario=USU.IdUsuario          
		INNER JOIN Ambiente AMB WITH (NOLOCK) ON SUS.IdAmbiente=AMB.IdAmbiente        
		LEFT JOIN CO_Interfase_P09_Header_ASOC COH WITH(NOLOCK) /*@3*/ ON COH.NumeroInterno = WTSO.NroPedido      
		and COH.CompaniaSocio=@CompaniaSocio --@2      
		--LEFT JOIN S I D B 0 1.S p r i n g U n i d o.dbo.CO_Interfase_P09_Header COH ON COH.NumeroInterno = WTSO.NroPedido      
		WHERE WTS.IdSede IN (4) and WT.Codigo = 'SOLEXREC' --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
		AND (S.IdSede = @IdSede    OR @IdSede = -1 )      
		AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
		--AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin      
	END      
      
	IF @Codigo = 'EXACARGO'      
	 BEGIN      
	  SELECT       
	  'Sede'=S.Nombre       
	  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
	  ,'Tr�mite'=WT.Nombre      
	  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
	  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.FechaCreacion)      
	  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
	  ,'Alumno'= ISNULL(A.NombreCompleto,'')      
	  ,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')      
	  ,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
	  ,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
			  WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
			  WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
			  ELSE '' END      
	  ,'Vencimiento_Pago_Spring'=DBO.Fecha(COH.FechaVencimiento)      
	  ,'Vencimiento_Pago_Smart'=DBO.Fecha(WTSO.FechaVencimiento)      
	  ,'Fecha_Examen' = dbo.Fecha(SUS.Fecha)      
	  ,'HoraInicio'=dbo.gHhMmStr(SUS.HoraInicio)       
	  ,'HoraFin'=dbo.gHhMmStr(SUS.HoraFin)       
	  ,'Curso'=CUR.CursoNombre      
	  ,'Aula'=AMB.Nombre      
	  --,'Facilitador_Curso'= ASPR.NombreCompleto       
	  ,'Responsable_Examen'=ISNULL(USU.Nombre,'')      
	  --,'NombreCalificacion'= LOWER(MTR2.Nombre)      
	  --,'Valor'=CASE WHEN ACN.Valor='NSP' THEN '0' ELSE ACN.Valor END      
	  --,NT.Peso      
	  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
	  INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
	  INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
	  INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
	  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
	  INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
	  INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
	  INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno      
	  INNER JOIN WFTramiteSolicitudDetalleCargoAlumno WFTSD WITH(NOLOCK) ON WFTSD.IdTramiteSolicitud = WTSO.IdTramiteSolicitud        
        
	  --INNER JOIN Seccion SEC WITH (NOLOCK) ON SEC.IdSeccion  = WFTSD.IdSeccion      
        
	  --INNER JOIN AlumnoCursoNota ACN WITH(NOLOCK) ON ACN.IdSeccion = SEC.IdSeccion AND ACN.IdCalificacion = WFTSD.IdCalificacion AND ACN.IdAlumno = AL.IdAlumno      
	  --INNER JOIN Nota NT WITH (NOLOCK) ON NT.IdSeccion = SEC.IdSeccion AND NT.IdCalificacion = ACN.IdCalificacion      
	  --INNER JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON MTR2.IdMaestroRegistro = NT.IdTipoPromedioNota      
        
	  --INNER JOIN SeccionProfesor SPR WITH(NOLOCK) ON SPR.IdSeccion = SEC.IdSeccion AND SPR.EsResponsable = 1  AND SPR.Activo = 1       
	  --INNER JOIN Actor ASPR WITH(NOLOCK) ON ASPR.IdActor = SPR.IdActor       
	  INNER JOIN Curso CUR WITH (NOLOCK) ON CUR.IdCurso = WFTSD.IdCurso       
	  INNER JOIN Cargo SUS  WITH (NOLOCK) ON SUS.IdCargo = WFTSD.IdCargo       
	  INNER JOIN Usuario USU WITH (NOLOCK) ON SUS.IdUsuario=USU.IdUsuario          
	  INNER JOIN Ambiente AMB WITH (NOLOCK) ON SUS.IdAmbiente=AMB.IdAmbiente       
	  LEFT JOIN CO_Interfase_P09_Header COH WITH(NOLOCK) /*@3*/ ON COH.NumeroInterno = WTSO.NroPedido      
	  and COH.CompaniaSocio=@CompaniaSocio --@2      
	  --LEFT JOIN P L D B 0 1.S p r i n g U n i d o.dbo.CO_Interfase_P09_Header COH ON COH.NumeroInterno = WTSO.NroPedido      
	  WHERE WTS.IdSede NOT IN (4) and WT.Codigo = 'EXACARGO' --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
	  AND (S.IdSede = @IdSede OR @IdSede = -1 )      
	  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
	  --AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin    
        
	  UNION ALL       
        
	  SELECT       
	  'Sede'=S.Nombre       
	  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
	  ,'Tr�mite'=WT.Nombre      
	  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
	  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.FechaCreacion)      
	  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
	  ,'Alumno'= ISNULL(A.NombreCompleto,'')      
	  ,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')      
	  ,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
	  ,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
			  WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
			  WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
			  ELSE '' END      
	  ,'Vencimiento_Pago_Spring'=DBO.Fecha(COH.FechaVencimiento)      
	  ,'Vencimiento_Pago_Smart'=DBO.Fecha(WTSO.FechaVencimiento) 
	  ,'Fecha_Examen' = dbo.Fecha(SUS.Fecha)      
	  ,'HoraInicio'=dbo.gHhMmStr(SUS.HoraInicio)       
	  ,'HoraFin'=dbo.gHhMmStr(SUS.HoraFin)       
	  ,'Curso'=CUR.CursoNombre      
	  ,'Aula'=AMB.Nombre      
	  --,'Facilitador_Curso'= ASPR.NombreCompleto       
	  ,'Responsable_Examen'=ISNULL(USU.Nombre,'')      
        
	  --,'NombreCalificacion'= LOWER(MTR2.Nombre)      
	  --,'Valor'=CASE WHEN ACN.Valor='NSP' THEN '0' ELSE ACN.Valor END      
	  --,NT.Peso      
        
        
	  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
	  INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
	  INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
	  INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
	  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
	  INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
	  INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
	  INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno      
	  INNER JOIN WFTramiteSolicitudDetalleCargoAlumno WFTSD WITH(NOLOCK) ON WFTSD.IdTramiteSolicitud = WTSO.IdTramiteSolicitud        
	  --INNER JOIN Seccion SEC WITH (NOLOCK) ON SEC.IdSeccion  = WFTSD.IdSeccion      
      
	  --INNER JOIN AlumnoCursoNota ACN WITH(NOLOCK) ON ACN.IdSeccion = SEC.IdSeccion AND ACN.IdCalificacion = WFTSD.IdCalificacion AND ACN.IdAlumno = AL.IdAlumno      
	  --INNER JOIN Nota NT WITH (NOLOCK) ON NT.IdSeccion = SEC.IdSeccion AND NT.IdCalificacion = ACN.IdCalificacion      
	  --INNER JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON MTR2.IdMaestroRegistro = NT.IdTipoPromedioNota      
      
	  --INNER JOIN SeccionProfesor SPR WITH(NOLOCK) ON SPR.IdSeccion = SEC.IdSeccion AND SPR.EsResponsable = 1  AND SPR.Activo = 1       
	  --INNER JOIN Actor ASPR WITH(NOLOCK) ON ASPR.IdActor = SPR.IdActor       
	  INNER JOIN Curso CUR WITH (NOLOCK) ON CUR.IdCurso = WFTSD.IdCurso       
	  INNER JOIN Cargo SUS  WITH (NOLOCK) ON SUS.IdCargo = WFTSD.IdCargo       
	  INNER JOIN Usuario USU WITH (NOLOCK) ON SUS.IdUsuario=USU.IdUsuario          
	  INNER JOIN Ambiente AMB WITH (NOLOCK) ON SUS.IdAmbiente=AMB.IdAmbiente        
	  LEFT JOIN CO_Interfase_P09_Header_ASOC COH WITH(NOLOCK) /*@3*/ ON COH.NumeroInterno = WTSO.NroPedido      
	  and COH.CompaniaSocio=@CompaniaSocio  --@2      
	  --LEFT JOIN S I B D 0 1.S p r i n g U n i d o.dbo.CO_Interfase_P09_Header COH ON COH.NumeroInterno = WTSO.NroPedido      
	  WHERE WTS.IdSede IN (4) and WT.Codigo = 'EXACARGO' --@4 SEDE ICA = 3 Y CHINCHA = 22 Retirada    
	  AND (S.IdSede = @IdSede    OR @IdSede = -1 )      
	  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
	  --AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin      
	 END      
	     
	IF @Codigo = 'SOLEXSUF'      
	 BEGIN      
	  SELECT       
	  'Sede'=S.Nombre       
	  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
	  ,'Tr�mite'=WT.Nombre      
	  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
	  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.FechaCreacion)      
	  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
	  ,'CodAlumno'= ISNULL(AL.CodigoAnterior,'')     --@16 
	  ,'Alumno'= ISNULL(A.NombreCompleto,'')      
	  ,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')      
      
	  ,'Fecha_Examen' = dbo.Fecha(SUS.Fecha)      
	  ,'HoraInicio'=dbo.gHhMmStr(SUS.HoraInicio)       
	  ,'HoraFin'=dbo.gHhMmStr(SUS.HoraFin)       
	  ,'Promocion' = PRO.PromocionNombre 
	  ,'Periodo' = PER.Codigo --@19
	  ,'Semestre' = cm.Nombre       
	  ,'Curso'=CUR.CursoNombre      
	  ,'Aula'=AMB.Nombre      
	  ,'Facilitador_Curso'= ASPR.NombreCompleto       
	  ,'Responsable_Examen'=ISNULL(USU.Nombre,'') 
	  ,'NumVezCurso'=CAST(ISNULL(AC.NumVezCurso,1) AS VARCHAR)
	  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
	  INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
	  INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
	  INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
	  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
	  INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
	  INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
	  INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno      
	  INNER JOIN WFTramiteSolicitudDetalleDecreto WFTSD WITH(NOLOCK) ON WFTSD.IdTramiteSolicitud = WTSO.IdTramiteSolicitud        
	  INNER JOIN Seccion SEC WITH (NOLOCK) ON SEC.IdSeccion  = WFTSD.IdSeccion      
	  INNER JOIN PromocionGrupo PG WITH (NOLOCK) ON PG.IdPromocion  = SEC.IdPromocion AND PG.IdGrupo = SEC.IdGrupo       
	  INNER JOIN Promocion PRO WITH (NOLOCK) ON PRO.IdPromocion  = SEC.IdPromocion       
	  INNER JOIN Periodo PER WITH (NOLOCK) ON PRO.IdPeriodo = PER.IdPeriodo --@19
	  INNER JOIN CurriculaModulo CM  WITH (NOLOCK) ON CM.IdCurricula = SEC.IdCurricula  AND CM.IdModulo = SEC.IdModulo      
        
	  --INNER JOIN AlumnoCursoNota ACN WITH(NOLOCK) ON ACN.IdSeccion = SEC.IdSeccion AND ACN.IdCalificacion = WFTSD.IdCalificacion AND ACN.IdAlumno = AL.IdAlumno      
	  --INNER JOIN Nota NT WITH (NOLOCK) ON NT.IdSeccion = SEC.IdSeccion AND NT.IdCalificacion = ACN.IdCalificacion      
	  --INNER JOIN MaestroTablaRegistro MTR2 WITH (NOLOCK) ON MTR2.IdMaestroRegistro = NT.IdTipoPromedioNota      
        
        
	  INNER JOIN SeccionProfesor SPR WITH(NOLOCK) ON SPR.IdSeccion = SEC.IdSeccion AND SPR.EsResponsable = 1  AND SPR.Activo = 1       
	  INNER JOIN Actor ASPR WITH(NOLOCK) ON ASPR.IdActor = SPR.IdActor       
	  INNER JOIN Curso CUR WITH (NOLOCK) ON CUR.IdCurso = SEC.IdCurso       
	  INNER JOIN DecretoCabecera SUS  WITH (NOLOCK) ON SUS.IdDecretoCabecera = WFTSD.IdDecretoCabecera       
	  INNER JOIN Usuario USU WITH (NOLOCK) ON SUS.IdUsuario=USU.IdUsuario          
	  INNER JOIN Ambiente AMB WITH (NOLOCK) ON SUS.IdAmbiente=AMB.IdAmbiente   
	  LEFT JOIN AlumnoCurso AC WITH (NOLOCK) ON  --inicio @16
	  AC.IdAlumno=AL.IdAlumno AND AC.IdCurso=CUR.IdCurso AND AC.IdSeccion=SEC.IdSeccion AND AC.IdPromocion=SEC.IdPromocion AND AC.IdGrupo=PG.IdGrupo
	  AND AC.EsMatricula=1 AND AC.estado='NO'    --fin @16

	  WHERE WT.Codigo = 'SOLEXSUF'        
	  AND (S.IdSede = @IdSede OR @IdSede = -1 )      
	  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
	  --AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin      
	 END      
	        
	IF @Codigo = 'SOLCAMHO'      
	 BEGIN      
	  SELECT       
	  'Sede'=S.Nombre       
	  ,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
	  ,'Tr�mite'=WT.Nombre      
	  ,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
	  ,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.FechaCreacion)      
	  ,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END      
	  ,'Alumno'= ISNULL(A.NombreCompleto,'')      
	  ,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')      
	  ,'Curso_Nombre' = CC.cursonombreoficial        
	  ,'Horario_Actual'  = ISNULL(dbo.gFrecuenciaSeccionHorario(WFTSD.IdSeccionActual), '-')      
	  ,'Grupo_Codigo_Actual' = ISNULL(pg.GrupoCodigo,'')       
	  ,'Promocion_Codigo_Actual' =  ISNULL(p.PromocionCodigo,'')       
	  ,'Promocion_Actual' =  ISNULL(p.PromocionNombre,'')       
	  ,'Ambiente_Actual' = ISNULL(AM.Nombre, '')      
	  ,'Facilitador_Actual' = ISNULL(ACt2.NombreCompleto, '-')        
	  ,'Horario_Nuevo'   = ISNULL(dbo.gFrecuenciaSeccionHorario(WFTSD.IdSeccionNueva), '-')      
	  ,'Grupo_Codigo_Nuevo' = ISNULL(pgN.GrupoCodigo,'')       
	  ,'Promocion_Codigo_Nuevo' =  ISNULL(pN.PromocionCodigo,'')       
	  ,'Promocion_Nuevo' =  ISNULL(pN.PromocionNombre,'')       
	  ,'AmbienteNombreNuevo' = ISNULL(A2.Nombre, '')      
	  ,'FacilitadorNombreNuevo' = ISNULL(ACt.NombreCompleto, '-')   
	   --@6  
	  ,'ESTADO' = case   
	 when MA.Estado = 'N' then ltrim(rtrim('MATRICULADO'))  
	 when MA.Estado = 'R' then ltrim(rtrim('RETIRADO'))  
	 when MA.Estado = 'X' then ltrim(rtrim('ANULADO'))  
	 else ltrim(rtrim('SIN DATO')) end     
	 --@6  
	  FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
	  INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
	  INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
	  INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
	  INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
	  INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
	  INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
	  INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno   
	  INNER JOIN WFTramiteSolicitudCambioHorario WFTSD WITH(NOLOCK) ON WFTSD.IdTramiteSolicitud = WTSO.IdTramiteSolicitud   
	  INNER JOIN Matricula MA ON WFTSD.IdMatricula = MA.IdMatricula --@6  
  
	  INNER JOIN Seccion SAC WITH(NOLOCK) ON SAC.IdSeccion=WFTSD.IdSeccionActual       
	  INNER JOIN PromocionGrupo PG WITH(NOLOCK) ON  PG.IdPromocion = SAC.IdPromocion AND PG.IdGrupo = SAC.IdGrupo       
	  INNER JOIN Promocion P WITH(NOLOCK) ON P.IdPromocion = PG.IdPromocion        
	  INNER JOIN curriculacurso CC with(nolock)ON CC.IdCurricula = SAC.IdCurricula AND CC.IdCurso = SAC.IdCurso AND CC.IdModulo = SAC.IdModulo      
	  INNER JOIN Ambiente AM  WITH(NOLOCK) ON SAC.idambiente = AM.idambiente       
	  LEFT  JOIN SeccionProfesor SP WITH(NOLOCK)ON SP.IdSeccion=WFTSD.IdSeccionNueva      
	  LEFT  JOIN Actor Act WITH(NOLOCK) ON Act.IdActor=SP.IdActor      
         
	  INNER JOIN Seccion SNW WITH(NOLOCK) ON SNW.IdSeccion=WFTSD.IdSeccionNueva      
	  INNER JOIN PromocionGrupo PGN WITH(NOLOCK) ON  PGN.IdPromocion = SNW.IdPromocion AND PGN.IdGrupo = SNW.IdGrupo       
	  INNER JOIN Promocion PN WITH(NOLOCK) ON PN.IdPromocion = SNW.IdPromocion        
	  INNER JOIN curriculacurso CCN with(nolock)ON CCN.IdCurricula = SNW.IdCurricula AND CCN.IdCurso = SNW.IdCurso AND CCN.IdModulo = SNW.IdModulo      
	  INNER JOIN Ambiente A2 WITH(NOLOCK) ON SNW.idambiente = A2.idambiente       
	  LEFT  JOIN SeccionProfesor SP2 WITH(NOLOCK)ON SP2.IdSeccion=WFTSD.IdSeccionActual AND SP2.EsResponsable = 1      
	  LEFT  JOIN Actor Act2 WITH(NOLOCK) ON Act2.IdActor=SP2.IdActor      
      
      
	  WHERE WT.Codigo = 'SOLCAMHO'        
	  AND (S.IdSede = @IdSede OR @IdSede = -1 )      
	  AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7  
	  --AND dbo.Fecha112(WTSO.Fecha) between @FechaInicio and @FechaFin      
	 END      
      
	IF @Codigo = 'SOLRECNOTA' --@1      
	BEGIN
		SELECT       
		'Sede'=S.Nombre       
		,'Nro_Solicitud'=WTSO.IdTramiteSolicitud                
		,'Tr�mite'=WT.Nombre      
		,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
		,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.Fecha)      
		,'Estado_Solicitud'= WFN.TituloNodoProceso      
		,'Alumno'= ISNULL(A.NombreCompleto,'')      
		,'Alumno_Email'= ISNULL(AL.EmailInstitucion,'')      
		,'Facilitador'= AFA.NombreCompleto      
		,'Facilitador_Email'= ISNULL(FA.EmailInstitucion,'')      
		,'Descripcion_Alumno'=WTSO.Observacion       
		,'Descripcion_Docente'=WTSO.Observacion2
		,'Division' =  ISNULL(UN.Nombre,'') -- @13
		,'Programa' =  ISNULL(UA.Nombre,'')   -- @13     
		,'PromocionNombre' = ISNULL(P.PromocionNombre,'')  -- @13
		,'PromocionCodigo' = ISNULL(P.PromocionCodigo,'')   -- @13     
		,'Seccion_Curso_Ambiente'= '['+PG.GrupoCodigo+'] '+C.CursoNombre+' ('+AMB.Codigo +')'           
		,'Evaluacion'=NOTA.Nombre        
		,'Nota_Anterior' =  ISNULL(nd.NotaActual,'')      
		,'Nota_Registrada' = ISNULL(nd.NotaRegistrada,'')      
		,'Nota_Actual'=ACN.Valor      
		,'Alumno_Nota'= ISNULL(AALDET.NombreCompleto,'')      
		,'Alumno_Email_Nota'= ISNULL(ADET.EmailInstitucion,'')      
		FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
		INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
		INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
		INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
		INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
		INNER JOIN Sede S  WITH(NOLOCK) ON S.IdSede = WTS.IdSede      
		LEFT JOIN Facilitador FA  WITH(NOLOCK) ON FA.IdFacilitador = WTSO.IdActor      
		LEFT JOIN Actor AFA  WITH(NOLOCK) ON AFA.IdActor = FA.IdFacilitador      
		LEFT JOIN WFTramiteSolicitudNotaDetalle ND  WITH(NOLOCK) ON ND.IdTramiteSolicitud =  WTSO.IdTramiteSolicitud      
		LEFT JOIN Alumno AL  WITH(NOLOCK) ON AL.IdAlumno = ND.IdAlumno      
		LEFT JOIN Actor A  WITH(NOLOCK) ON A.IdActor = AL.IdAlumno      
		LEFT JOIN Alumno ADET  WITH(NOLOCK) ON ADET.IdAlumno = ND.IdAlumno      
		LEFT JOIN Actor AALDET  WITH(NOLOCK) ON AALDET.IdActor = ADET.IdAlumno      
		LEFT JOIN Seccion SEC WITH(NOLOCK) ON SEC.IdSeccion=ND.IdSeccion        
		LEFT JOIN PromocionGrupo  PG WITH(NOLOCK) ON PG.IdPromocion = SEC.IdPromocion AND PG.IdGrupo = SEC.IdGrupo 
		LEFT JOIN Promocion P WITH(NOLOCK) ON PG.IdPromocion = P.IdPromocion 
		LEFT JOIN UnidadNegocio UN  WITH(NOLOCK) ON  P.IdUnidadNegocio = UN.IdUnidadNegocio 
		LEFT JOIN UnidadAcademica UA  WITH(NOLOCK) ON  P.IdUnidadAcademica = UA.IdUnidadAcademica           
		LEFT JOIN Ambiente AMB WITH(NOLOCK) ON AMB.IdAmbiente = SEC.IdAmbiente         
		LEFT JOIN Curso C WITH(NOLOCK) on C.IdCurso=SEC.IdCurso          
		LEFT join AlumnoCursoNota ACN  WITH(NOLOCK)on ACN.IdSeccion=SEC.IdSeccion AND ACN.IdAlumno=ND.IdAlumno --AND ACN.IdCalificacion=ND.IdCalificacion          
		LEFT JOIN Nota N  WITH (NOLOCK) ON ACN.IdSeccion=N.IdSeccion and ACN.IdCalificacion=N.IdCalificacion AND N.IdCalificacion=ND.IdCalificacion     
		LEFT JOIN MaestroTablaRegistro NOTA WITH (NOLOCK) ON N.IdTipoPromedioNota = NOTA.IdMaestroRegistro     
		WHERE WT.Codigo = 'SOLRECNOTA' AND NOTA.IdMaestroRegistro  not in(780,1093,1095,1104)      
		AND (S.IdSede = @IdSede OR @IdSede = -1 )     
		AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7        
		ORDER BY S.IdSede , WFN.IdWFNodoProceso      
	END      
          
	--@5 Inicio  
	IF @Codigo = 'SOLJUSINA'      
	BEGIN      
		SELECT       
		'Sede'=S.Nombre       
		,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
		,'Tr�mite'=WT.Nombre      
		,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
		,'Tiempo_Transcurrido'= dbo.DifFechaEnTexto(WTSO.Fecha)     
		,'Estado_Solicitud'= WFN.TituloNodoProceso     
		,'Alumno'= ISNULL(A.NombreCompleto,'')      
		,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')
		,'Division' =  ISNULL(UN.Nombre,'') -- @13
		,'Programa' =  ISNULL(UA.Nombre,'')   -- @13   
		,'PromocionNombre' = ISNULL(P.PromocionNombre,'')  -- @13
		,'PromocionCodigo' = ISNULL(P.PromocionCodigo,'')   -- @13   
		,'Seccion_Curso_Ambiente'= '['+PG.GrupoCodigo+'] '+C.CursoNombre+' ('+AMB.Codigo +')'     
		,'Nro_Sessiones'=COUNT(WFTSD.IdTramiteSolicitudAsistenciaDetalle)  
		--@6  
		,'ESTADO' = case   
				when MA.Estado = 'N' then ltrim(rtrim('MATRICULADO'))  
				when MA.Estado = 'R' then ltrim(rtrim('RETIRADO'))  
				when MA.Estado = 'X' then ltrim(rtrim('ANULADO'))  
				else ltrim(rtrim('SIN DATO')) end  
		--@6     
		FROM WFTramiteSolicitud WTSO WITH(NOLOCK)    
		INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor     
		INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno     
		INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado        
		INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
		INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
		INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
		INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede    
		INNER JOIN WFTramiteSolicitudAsistenciaDetalle WFTSD WITH(NOLOCK) ON WFTSD.IdTramiteSolicitud = WTSO.IdTramiteSolicitud     
		LEFT join AlumnoCurso AC on wftsd.IdSeccion = AC.IdSeccion AND AL.IdAlumno=AC.IdAlumno --@6  
		LEFT join Matricula MA on MA.IdMatricula = AC.IdMatricula--@6  
		LEFT JOIN Seccion SEC WITH(NOLOCK) ON SEC.IdSeccion=WFTSD.IdSeccion        
		LEFT JOIN PromocionGrupo  PG WITH(NOLOCK) ON PG.IdPromocion = SEC.IdPromocion AND PG.IdGrupo = SEC.IdGrupo
		LEFT JOIN Promocion P WITH(NOLOCK) ON PG.IdPromocion = P.IdPromocion 
		LEFT JOIN UnidadNegocio UN  WITH(NOLOCK) ON  P.IdUnidadNegocio = UN.IdUnidadNegocio 
		LEFT JOIN UnidadAcademica UA  WITH(NOLOCK) ON  P.IdUnidadAcademica = UA.IdUnidadAcademica        
		LEFT JOIN Curso C WITH(NOLOCK) on C.IdCurso=SEC.IdCurso   
		LEFT JOIN Ambiente AMB WITH(NOLOCK) ON AMB.IdAmbiente = SEC.IdAmbiente            
		WHERE WT.Codigo = 'SOLJUSINA'        
		AND (S.IdSede = @IdSede OR @IdSede = -1 )      
		AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin--@7    
		GROUP BY S.Nombre,WTSO.IdTramiteSolicitud ,WT.Nombre,WTSO.Fecha,WFN.TituloNodoProceso,A.NombreCompleto,      
		AL.EmailInstitucion,WTSO.Observacion,PG.GrupoCodigo,C.CursoNombre,AMB.Codigo,MA.IdMatricula,ma.Estado ,
		P.PromocionNombre,P.PromocionCodigo,UN.Nombre,UA.Nombre
		Order by WTSO.IdTramiteSolicitud asc  
	END      
	--@5 Fin
	--@17 Inicio    
	 IF @Codigo = 'SOLRECLASE'        
	 BEGIN        
		SELECT         
		'Sede'=S.Nombre         
		,'Nro_Solicitud'=WTSO.IdTramiteSolicitud          
		,'Tr�mite'=WT.Nombre        
		,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)        
		,'Tiempo_Transcurrido'= dbo.DifFechaEnTexto(WTSO.Fecha)       
		,'Estado_Solicitud'= WFN.TituloNodoProceso       
		,'Facilitador'= ISNULL(A.NombreCompleto,'')        
		,'Email_Facilitador'= ISNULL(F.EmailInstitucion,'')  
		,'Division' =  ISNULL(UN.Nombre,'') 
		,'Programa' =  ISNULL(UA.Nombre,'') 
		,'PromocionNombre' = ISNULL(P.PromocionNombre,'')  
		,'PromocionCodigo' = ISNULL(P.PromocionCodigo,'')   
		,'Seccion_Curso_Ambiente'= '['+PG.GrupoCodigo+'] '+C.CursoNombre+' ('+AMB.Codigo +')'       
		,'Fecha_Programada'=WFTSD.FechaProgramada
		,'Hora_Programada'=dbo.gHhMmStr(WFTSD.HoraInicioProgramada)+' - '+dbo.gHhMmStr(WFTSD.HoraFinProgramada)
		,'Nro_Sesion'= WFTSD.IdHorario
		FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
		INNER JOIN Facilitador F WITH(NOLOCK) ON F.IdFacilitador = WTSO.IdActor       
		INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = F.IdFacilitador       
		INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado          
		INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede         
		INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite         
		INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite          
		INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede      
		INNER JOIN WFTramiteSolicitudDetalleRecuperacionClase WFTSD WITH(NOLOCK) ON WFTSD.IdTramiteSolicitud = WTSO.IdTramiteSolicitud       
		LEFT JOIN Seccion SEC WITH(NOLOCK) ON SEC.IdSeccion=WFTSD.IdSeccion          
		LEFT JOIN PromocionGrupo  PG WITH(NOLOCK) ON PG.IdPromocion = SEC.IdPromocion AND PG.IdGrupo = SEC.IdGrupo  
		LEFT JOIN Promocion P WITH(NOLOCK) ON PG.IdPromocion = P.IdPromocion   
		LEFT JOIN UnidadNegocio UN  WITH(NOLOCK) ON  P.IdUnidadNegocio = UN.IdUnidadNegocio   
		LEFT JOIN UnidadAcademica UA  WITH(NOLOCK) ON  P.IdUnidadAcademica = UA.IdUnidadAcademica          
		LEFT JOIN Curso C WITH(NOLOCK) on C.IdCurso=SEC.IdCurso     
		LEFT JOIN Ambiente AMB WITH(NOLOCK) ON AMB.IdAmbiente = SEC.IdAmbiente              
		WHERE WT.Codigo = 'SOLRECLASE'          
		AND (S.IdSede = @IdSede OR @IdSede = -1 )        
		AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin
		GROUP BY S.Nombre,WTSO.IdTramiteSolicitud ,WT.Nombre,WTSO.Fecha,WFN.TituloNodoProceso,A.NombreCompleto,        
		F.EmailInstitucion,WTSO.Observacion,PG.GrupoCodigo,C.CursoNombre,AMB.Codigo,WFTSD.FechaProgramada, WFTSD.HoraInicioProgramada,WFTSD.HoraFinProgramada,
		P.PromocionNombre,P.PromocionCodigo,UN.Nombre,UA.Nombre,WFTSD.IdHorario
		Order by WTSO.IdTramiteSolicitud asc  
		
	 END
	 
	--@17 Fin  
     
	 --@8 Inicio @9
	IF @Codigo in (select codigo from wftramite with(nolock) where nombrepagina='Servicios/Servicio2')
	 BEGIN
		SELECT       
		'Sede'=S.Nombre       
		,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
		,'Tr�mite'=WT.Nombre      
		,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha)      
		,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.FechaCreacion)      
		,'Estado_Solicitud'= WFN.TituloNodoProceso --+ CASE WHEN WFN.Disponible3 = 'Fin' THEN ' (ATENDIDO)' ELSE ' (EN ESPERA)' END  
		,'Estado_Solicitud_Fecha'=DBO.Fecha(WTSF.FechaCreacion)--@10
		,'Alumno'= ISNULL(A.NombreCompleto,'')      
		,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')
		,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
		,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
				WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
				WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
				ELSE '' END      
		,'Vencimiento_Pago'=DBO.Fecha(COH.FechaVencimiento)   
		--,'Usuario_Creacion'=U.NOMBRE
		,'login'=U.Login				--@11
		FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
		INNER JOIN USUARIO U ON WTSO.IdUsuarioResponsable= U.IDUSUARIO		--@11
		INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado   
		INNER JOIN WFTramiteSolicitudFlujo WTSF ON WTSF.IdTramiteSolicitud=WTSO.IdTramiteSolicitud--@10
		INNER JOIN WFTramiteFlujo WTF ON WTSF.IdTramiteFlujo=WTF.IdTramiteFlujo AND WTF.IdWFNodoProceso=WFN.IdWFNodoProceso  --@10
		INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
		INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
		INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
		INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
		INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
		INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno 
		LEFT JOIN vw_CO_Interfase_P09_Header COH WITH(NOLOCK) ON COH.NumeroInterno = WTSO.NroPedido and COH.CompaniaSocio=@CompaniaSocio  
		WHERE WT.Codigo = @Codigo
		AND (S.IdSede = @IdSede OR @IdSede = -1 )      
		AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin      
	END
	 --@8 Fin @9
	IF @IdTramite=9000 --@12 Inicio
	BEGIN 
		SELECT       
			'Sede'=S.Nombre       
			,'Nro_Solicitud'=WTSO.IdTramiteSolicitud        
			,'Tr�mite'=WT.Nombre      
			,'Fecha_Registro'=DBO.Fecha(WTSO.Fecha) 
			,'Tiempo_Transcurrido'=  dbo.DifFechaEnTexto(WTSO.FechaCreacion)      
			,'Estado_Solicitud'= WFN.TituloNodoProceso 
			,'Estado_Solicitud_Fecha'=DBO.Fecha(WTSF.FechaCreacion)--@10
			,'Alumno'= ISNULL(A.NombreCompleto,'')      
			,'Email_Alumno'= ISNULL(AL.EmailInstitucion,'')
			,'Documento_Pago'= ISNULL(COH.NumeroDocumento,'')      
			,'Estado_Pago'= CASE WHEN COH.ESTADO = 'PF' THEN 'POR FACTURAR'       
					WHEN COH.ESTADO = 'CO' THEN 'COBRADO'      
					WHEN COH.ESTADO = 'AN' THEN 'ANULADO'      
					ELSE '' END      
			,'Vencimiento_Pago'=DBO.Fecha(COH.FechaVencimiento)   
			--,'Usuario_Creacion'=U.NOMBRE
			,'login'=U.Login				--@11
			FROM WFTramiteSolicitud WTSO WITH(NOLOCK)      
			INNER JOIN USUARIO U WITH(NOLOCK) ON WTSO.IdUsuarioResponsable= U.IDUSUARIO		--@11
			INNER JOIN WFNodo WFN WITH(NOLOCK) ON WFN.IdWFNodoProceso = WTSO.IdEstado   
			INNER JOIN WFTramiteSolicitudFlujo WTSF WITH(NOLOCK) ON WTSF.IdTramiteSolicitud=WTSO.IdTramiteSolicitud--@10
			INNER JOIN WFTramiteFlujo WTF WITH(NOLOCK) ON WTSF.IdTramiteFlujo=WTF.IdTramiteFlujo AND WTF.IdWFNodoProceso=WFN.IdWFNodoProceso  --@10
			INNER JOIN WFTramiteSede WTS WITH(NOLOCK) ON WTS.IdTramiteSede = WTSO.IdTramiteSede       
			INNER JOIN WFTramite WT WITH(NOLOCK) ON WT.IdTramite =   WTS.IdTramite       
			INNER JOIN WFTipoTramite WFTT WITH(NOLOCK) ON WFTT.IdTipoTramite = WT.IdTipoTramite        
			INNER JOIN Sede S WITH(NOLOCK) ON S.IdSede = WTS.IdSede       
			INNER JOIN Alumno AL WITH(NOLOCK) ON AL.IdAlumno = WTSO.IdActor        
			INNER JOIN Actor A WITH(NOLOCK) ON A.IdActor = AL.IdAlumno 
			LEFT JOIN vw_CO_Interfase_P09_Header COH WITH(NOLOCK) ON COH.NumeroInterno = WTSO.NroPedido and COH.CompaniaSocio=@CompaniaSocio  
			WHERE WT.Codigo IN (SELECT MTR.Codigo FROM MaestroTablaRegistro MTR WITH(NOLOCK) inner join Maestrotabla MT 
								WITH(NOLOCK) ON MTR.IdMaestroTabla= MT.IdMaestroTabla WHERE
								IdMaestroRegistroTipo=(SELECT IdMaestroRegistro FROM MaestroTablaRegistro WITH(NOLOCK) WHERE codigo='Formacion Continua'))
			AND (S.IdSede = @IdSede OR @IdSede = -1 )      
			AND CONVERT(VARCHAR,WTSO.Fecha,112) between @FechaInicio and @FechaFin   
	END
	--@12 Fin
	
	IF @IdTramite=9001 --@14 Inicio
	BEGIN 
		EXEC cTramiteReporte_Xls_TRA_GEN_Orden22 @FechaInicio,@FechaFin,@IdSede
	END
	--@14 Fin
END
