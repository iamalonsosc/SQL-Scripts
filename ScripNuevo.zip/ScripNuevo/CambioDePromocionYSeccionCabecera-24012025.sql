DECLARE @TABLE TABLE (ID INT IDENTITY(1,1)
,AlumnoCodigo VARCHAR(500)
,IdActor INT
,NombreActor VARCHAR(500)
,ProOrigen VARCHAR(100)
,SeccOrigen VARCHAR(100)
,IdMatriculaEscuela INT
,IdProductoEscuela INT
,IdCurriculaEscuela INT
,IdGrupoEscuela INT
,IdPromoDestino INT
,IdCicloDestino INT
,IdCurriculaDestino INT
,IdProductoDestino INT
,IdGrupoDestino INT
,ProDestino VARCHAR(500)
,SeccDestino VARCHAR(100)
,Observacion VARCHAR(100))

	DECLARE  @tempcursos TABLE(
	IdTempCursos INT IDENTITY
	,IdActor	INT
	,IdModulo   INT
	,IdCurso    INT
	,NumVezCurso INT)

DECLARE
@MAX					INT
,@MIN					INT
,@MAXCURSO				INT
,@MINCURSO				INT
,@IdMatricula			INT
,@IdActor				INT
,@IdRegistro			INT
,@IdCurricula			INT
,@IdCurso				INT
,@IdPromocionDestino	INT
,@IdGrupo				INT
,@IdProductoEscuela		INT
,@IdCurriculaEscuela	INT
,@IdProductoDestino		INT
,@IdCurriculaDestino	INT
,@SeccDestino			VARCHAR(100)
,@IdCicloDestino		INT
,@ERROR					BIT

--=CONCATENAR("INSERT INTO @TABLE VALUES('";A2;"','','','";D2;"','";E2;"','','','','','','','','','','";H2;"','";I2;"','')")

BEGIN
INSERT INTO @TABLE VALUES('VV74580190','','','IV.0288.II.2025-I','II.01.2025-I','','','','','','','','','','IV.0288.III.2025-I','III.01.2025-I','')

END


UPDATE T SET T.IdActor = AL.IdAlumno ,T.nombreactor = AC. NombreCompleto
FROM @TABLE T
INNER JOIN Alumno AL on AL.CodigoAnterior = T.AlumnoCodigo
INNER JOIN Actor AC ON AC.IdActor=AL.IdAlumno

UPDATE T SET 
T.IdMatriculaEscuela=M.IdMatricula
,T.IdCurriculaEscuela=M.IdCurricula
,T.IdProductoEscuela=P.IdProducto
,t.IdGrupoEscuela=m.IdGrupo
FROM @TABLE T
INNER JOIN Matricula M ON M.IdActor = T.IdActor
INNER JOIN Promocion P ON P.IdPromocion = M.IdPromocion
INNER JOIN Periodo PE ON PE.IdPeriodo = P.IdPeriodo
WHERE PE.Codigo IN ('2025-I')
AND M.Estado <> 'X'
--AND M.EsMatricula = 1
AND M.IdSede=50
AND P.IdUnidadAcademica=57

UPDATE T SET 
T.IdPromoDestino=P.IdPromocion
,T.IdCicloDestino=P.IdModulo
,T.IdCurriculaDestino=P.IdCurricula
,T.IdProductoDestino=P.IdProducto
,T.IdGrupoDestino=ISNULL(PG.IdGrupo,1)
FROM @TABLE T
INNER JOIN Promocion P ON P.PromocionCodigo = T.ProDestino
LEFT JOIN PromocionGrupo PG ON P.IdPromocion=PG.IdPromocion 
AND PG.GrupoCodigo = T.SeccDestino
WHERE P.IdUnidadAcademica=57
AND PromocionCodigo LIKE '%2025-I%'
AND P.IdSede=50

--SELECT*FROM @TABLE
--RETURN


SELECT @MIN = MIN(ID), @MAX = MAX(ID) from @TABLE

WHILE @MIN <= @MAX
BEGIN

	SET @IdMatricula = NULL 
	SET @IdActor=NULL
	SET @IdGrupo=NULL
	SET @IdPromocionDestino=NULL
	SET @IdRegistro = NULL
	SET @ERROR= NULL

	SELECT @IdMatricula = IdMatriculaEscuela
	,@IdActor=IdActor
	,@IdPromocionDestino=IdPromoDestino
	,@IdGrupo=IdGrupoDestino
	,@IdProductoEscuela=IdProductoEscuela
	,@IdCurriculaEscuela=IdCurriculaEscuela
	,@IdProductoDestino=IdProductoDestino
	,@IdCurriculaDestino=IdCurriculaDestino
	,@SeccDestino=SeccDestino
	,@IdCicloDestino=IdCicloDestino
	FROM @TABLE WHERE ID = @Min
	
	-- Validaci�n de la matr�cula
	IF @IdMatricula = 0
	BEGIN
		UPDATE @TABLE SET Observacion='Alumno no tiene matricula en el periodo 2024-III'
		WHERE ID = @Min
		SET @ERROR=1
	END
	ELSE IF @IdPromocionDestino = 0
	BEGIN
		UPDATE @TABLE SET Observacion='NO EXISTE PROMOCION'
		WHERE ID = @Min
		SET @ERROR=1
	END
	ELSE IF @IdProductoEscuela <> @IdProductoDestino
	BEGIN
		UPDATE @TABLE SET Observacion='Producto diferente de la matricula'
		WHERE ID = @Min
		SET @ERROR=1
	END
	ELSE IF @IdCurriculaEscuela <> @IdCurriculaDestino
	BEGIN
		UPDATE @TABLE SET Observacion='Curricula diferente de la matricula'
		WHERE ID = @Min
		SET @ERROR=1
	END
	ELSE
	BEGIN
		UPDATE @TABLE SET Observacion='Todo est� correcto'
		WHERE ID = @Min
		SET @ERROR=0
	END

	IF @ERROR =  0
	BEGIN
	
		UPDATE M SET 
		M.IdPromocion=@IdPromocionDestino
		,M.IdModulo=@IdCicloDestino 
		,M.IdGrupo=@IdGrupo 
		FROM Matricula M
		WHERE IdMatricula = @IdMatricula

		--Sacamos todos los datos que necesitamos en la matricula de escuela
		SELECT @IdRegistro=IdRegistro FROM Matricula WHERE IdMatricula=@IdMatricula
		PRINT @IdRegistro
		DELETE @tempcursos
		INSERT INTO @tempcursos(IdActor,IdModulo,IdCurso)
		SELECT IdAlumno
		,IdModulo
		,IdCurso
		FROM  AlumnoCurriculaCurso WITH(nolock)
		WHERE  idalumno = @IdActor
		AND idregistro = @IdRegistro
		AND idcurricula = @IdCurriculaDestino
		AND idmodulo <= @IdCicloDestino
		AND ISNULL(PromedioCondicion,'') IN ('','D')

		--SELECT*FROM @tempcursos
		
		--RETURN
	
		SELECT @MAXCURSO = MAX(IdTempCursos),@MINCURSO= MIN(IdTempCursos) FROM @tempcursos
		PRINT @IdActor
		PRINT @IdPromocionDestino
		print @IdGrupo
		print @IdCicloDestino
		WHILE @MINCURSO <= @MAXCURSO
		BEGIN     

		  SELECT @IdCurso = IdCurso,@IdCicloDestino = IdModulo 
		  FROM @tempcursos        
		  WHERE IdTempCursos = @MINCURSO
       
		  IF NOT EXISTS(SELECT DISTINCT 1 FROM AlumnoCurso WITH(NOLOCK) WHERE IdMatricula=@IdMatricula AND IdCurso=@IdCurso)
		  BEGIN
			EXEC cAlumnoCurso_Ins_Grabar 
			@IdActor
			,@IdRegistro
			,-1
			,@IdCurriculaDestino
			,@IdCurso
			,@IdMatricula
			,-1
			,-1
			,-1
			,-1
			,NULL
			,''
			,''
			,-1
			,''
			,''
			,-1
			,-1
			,-1
			,-1
			,0
			,'CC'
			,1
			,1   
		
			UPDATE ACC SET
			ACC.IdAlumnoCurso=AC.IdAlumnoCurso
			FROM AlumnoCurriculaCurso ACC WITH(NOLOCK)
			INNER JOIN AlumnoCurso AC  WITH(NOLOCK) ON ACC.IdAlumno=AC.IdAlumno AND ACC.IdCurricula=AC.IdCurricula AND ACC.IdCurso=AC.IdCurso AND ACC.IdRegistro = AC.IdRegistro 
			WHERE AC.IdMatricula=@IdMatricula AND AC.IdCurso=@IdCurso

			PRINT @IdActor
			PRINT @IdPromocionDestino
			print @IdGrupo
			print @IdCicloDestino
			END
			PRINT @IdActor
			PRINT @IdPromocionDestino
			print @IdGrupo
			print @IdCicloDestino
			SET @MINCURSO  = @MINCURSO+1
		END
	
	END 
	SET @Min=@Min+1
END


SELECT*FROM @TABLE
--WHERE Observacion <>'Todo est� correcto'
