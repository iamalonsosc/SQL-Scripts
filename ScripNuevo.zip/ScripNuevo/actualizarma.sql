SELECT estado,*FROM CO_Interfase_P09_Header 
UPDATE CO_Interfase_P09_Header SET Estado='MA'
WHERE IdMatricula=825324 AND Estado IN ('GE','PR')


--SELECT * FROM CO_Interfase_P09_Header WHERE ESTADO='MA'

SELECT*FROM CO_Interfase_P09_Detalle WHERE NumeroInterno in (SELECT NumeroInterno FROM CO_Interfase_P09_Header WHERE IdMatricula=823983)