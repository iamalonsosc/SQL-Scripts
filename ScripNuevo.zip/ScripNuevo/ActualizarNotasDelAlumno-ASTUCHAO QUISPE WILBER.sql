--ASTUCHAO QUISPE WILBER

--FUNDAMENTOS DE ADMINISTRACION
UPDATE AlumnoCurriculaCurso SET IdConvalidacion=37081,Promediofinal=13, PromedioReal=13, PromedioCondicion='A',TipoCondicion='CO', 
Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 52017', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1243190 and  idcurricula=5608 and idcurso in (9849)
--(1 row affected)


--HERRAMIENTAS INFORMATICAS
UPDATE AlumnoCurriculaCurso SET IdConvalidacion=37081,Promediofinal=10, PromedioReal=10, PromedioCondicion='A',TipoCondicion='CO', 
Glosa='Desde cAlumnoCurso_Pro_CargaHabil_CambioCurricula - tkt 52017', UsuarioModificacion=1,FechaModificacion=getdate(), Subsanacion=0
WHERE idalumno=1243190 and  idcurricula=5608 and idcurso in (9801)