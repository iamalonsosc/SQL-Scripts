SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1244708 
--AND AC.IdCurso=10160 
AND AC.IdMatricula=647763 
order by ac.idregistro,ac.IdAlumnoCurso desc



INSERT INTO AlumnoCurso VALUES (1244708,2,104,5617,10160,647763,96927,1,629345,null,null,'14.00','14.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'CC',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL,PromedioFinal='14.00',PromedioReal= '14.00',IdAlumnoCurso=104,TipoCondicion='RE'
--select*from AlumnoCurriculaCurso 
where IdAlumno=1244708 and IdCurso=10160 AND IdRegistro=2