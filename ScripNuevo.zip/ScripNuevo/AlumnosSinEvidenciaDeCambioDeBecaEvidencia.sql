SELECT MA.IdMatricula,AC.NombreCompleto,PRO.PromocionNombre,PE.Codigo,
'Estado' = case when MA.EsMatricula  = 1 then 'MATRICULADO' ELSE 'PRE' END,
DE.Motivo
--(SELECT 'MOTIVO'= Motivo FROM DescuentoAlumnoEvidencia WHERE IdMatricula= MA.IdMatricula AND Motivo IS NOT NULL) 
FROM Matricula MA
INNER JOIN Promocion PRO ON MA.IdPromocion=PRO.IdPromocion
INNER JOIN Periodo PE ON PE.IdPeriodo=PRO.IdPeriodo
INNER JOIN Actor AC ON AC.IdActor=MA.IdActor
LEFT JOIN DescuentoAlumnoEvidencia DE ON DE.IdMatricula = MA.IdMatricula
WHERE PE.Codigo in ('2025-I' )
AND MA.Estado <> 'X'
AND DE.Motivo IS  NULL 
--AND AC.NombreCompleto='Tuesta Panduro Donny Anthony'
AND AC.NumeroIdentidad IN ('70979395',
'74842741'
,'75606902'
,'61612719'
,'72881587'
,'72572857'
,'74941799'
,'45639794'
,'60549017'
,'76186342'
,'60778720'
,'76875858'
,'47327083'
,'71260416'
,'74135077'
,'73246913'
,'77905548'
,'75984812'
,'61013609'
,'70901385'
,'76131469'
,'73975843','73738636',
'60797991'
,'61016892'
,'74022496'
,'74982993'
,'71982547'
,'70357834'
,'71292344'
,'73886468'
,'74073522'
,'76223501'


)
order by 2