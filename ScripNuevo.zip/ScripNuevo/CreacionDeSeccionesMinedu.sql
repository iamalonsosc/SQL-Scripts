--PASO 1 ELIMINAR TODO

delete AlumnoCursoNominaJson
where IdEmpresa = 1    
and IdSede = 48    
and IdPeriodo = 3682    
and (IdProducto = 0 or 0 = 0) 

--(12730 rows affected)

--PASO 2 PROCESAR TODA LA INFORMACION
EXECUTE cProcesa_Nomina_JSON_Minedu 3682,1,48,60,1,0,1

--PASO 3 REPORTE PRE JSON
EXEC [AlumnoCursoNomina_List] @IdSede=48 , @IdUnidadNegocio= 1, @IdPeriodo= 3682,�@IdProducto=�0