---����������������������������������������������������������
--Creado por	: Miguel Gargurevich (07/12/2011)
--Funcionalidad	: Lista todos los cursos de todos los periodos por alumno
--Utilizado por	: AlumnoCurso.CursosPeriodos
--����������������������������������������������������������������������������
/*
-----------------------------------------------------------------------------
Nro		FECHA			USUARIO			DESCRIPCION
-----------------------------------------------------------------------------
@1		09/01/2012		mgargurevich	se agregaron mas campos a la consulta
@2		24/01/2012		mgargurevich	se agregaron mas campos a la consulta
@3		27/03/2012		mgargurevich	SE AGREGO EL JOIN CON  Evaluacion Y EvaluacionCondicion para traer la condicion de la nota A o D
@4		12/09/2012		ilopez			se muestra el PromedioReal en lugar de PromedioFinal
@5		17.01.2014		ilopez			se muestra la informaci�n del cargo correctamente
@6		29.01.2014		ilopez			se selecciona el producto de la cabecera y no del detalle
@7		04.06.2014		ilopez			se muestra solo el ultimo cargo registrado
@8		10.03.2015		ilopez			se muestra el producto de la secci�n matriculada del curso 
@9		11.05.2015		lciudad			se muestra el nombre Curso Oficial de curricula Curso
@10		09/09/2015		aaurora			Nuevo Reglamento de Extensi�n
@11		16.03.2016		gguillen		se agrega columna para solo nombres y para nombre corto
@12		15.09.2016		ilopez			se muestran todas las notas incluyendo las desaprobatorias por cargo
@16		16.11.2016		ilopez			se corrige cuando el curso est� en diferentes programas
@17		06.04.2017		gguillen		se agreg� columna de IdDocente
@18		06.04.2018		jnavia			Se agrego columna CursoNombreOriginal  
@19		12.06.2019						Mejoras del tipo de condici�n apartir del a�o 2019 y relaci�n con AlumnoCurriculaCurso.  
@20		23.01.2020		yflores			Cambios para Cursos Libres  
@21		27.01.2020		PUchuya			Se realiza cambios para Cursos Libres  
@22		2020.02.13		hcachi			Se cambia tabla Seccion por AlumnoCurriculaCurso para el campo IdCurso  
@23		2020.03.02		hcachi			Se agrega or en el join (Seccion o AlumnoCurriculaCurso)  
@24		2020.04.22		Jmota			Se modifico Join Con Curso y se agrego un case
@25		07.07.2020		PUchuya			Se agregar y quita case para Cursos Libres  
@26		14.08.2020		Jcure			Se agrego with (nolock)  
@27		10.08.2020		gguillen		Se agrega nuevo campo al retorno  
@27		27.08.2020		gguillen		Se agrega condici�n ISNULL  
@28		09.09.2020		gguillen		Se agrega condici�n para NumeroClase IDAT  
@29		18.09.2020		puchuya			Se agrega case validar estado y condicion del curso  
@30		23.11.2020		ilopez			Se pasa todo de tabla temporal a tabla Variable  
@31		2021.03.17		hcachi			Se re-dimensiona campo CursoNivel de tabla temporal @AlumnoCurso con el campo Nombre de la tabla CurriculaModulo  
@32		13.04.2021		rpineda			add WITH (NOLOCK)
@33		19.07.2022		JQuenta			Se agrego condicion ISNULL
@34		23.01.2023		rotorres		Se ordena con curriculaCursoOrden y CurriculaModuloOrden
@35		10.11.2023		JQuenta			Se agrego condicion ISNULL
@36		04.06.2025		Illosad			Se CASE para identificar el tipo de examen realizado
@37		26/09/2025		JQuenta			Se agregan mejoras como parte del Proyecto de la Optimizacion de la Carga Habil
										Se agregan Nuevos Campos y Nueva Validacion por Parametro de Periodo de Cabecera para la Visualizacion por Periodo Academico:
										- PromedioPonderadoAcademico
										- PromedioHistoricoPonderado
										- CoeficienteAcademicoEstandarizado
@38		16.12.2025		Alsanchez		Se agrega nueva tabla para excluir a los alumnos de sus nominas
@39		17.12.2025		Alsanchez		Se cambia mensaje de los alumnos sin seccion de nomina
*/

ALTER PROCEDURE [dbo].[cAlumnoCurso_Con_CursosPeriodos]  
@IdAlumno INT,
@IdMatricula INT
AS
BEGIN

	--Inicio --@37
	SET NOCOUNT ON
  
	DECLARE
	@CompaniaSocio VARCHAR(20),
	@PeriodoVisualizacionNuevosPromediosPonderados VARCHAR(MAX) --@37
  
	DECLARE @AlumnoCurso AS TABLE --@37
	(  
		IdCurricula INT,
		IdCurso INT,
		IdModulo INT,
		CurriculaModuloCodigo VARCHAR(30),
		CurriculaModuloNombre VARCHAR(200),
		CursoCodigo VARCHAR(30),
		CursoNombreOficial VARCHAR(200),
		IdSeccion INT,
		SeccionCodigo VARCHAR(30),
		FechaInicio VARCHAR(30),
		IdMoneda INT,
		MonedaCodigo VARCHAR(30),
		MontoMoneda REAL,
		IdGrupo INT,
		GrupoCodigo VARCHAR(30),
		TipoCondicion VARCHAR(200),
		TipoCondicionNombre VARCHAR(200),
		EstadoNombre VARCHAR(200),
		NumVezCurso INT,
		PromedioFinal VARCHAR(30),
		PromedioReal VARCHAR(30),
		PromedioCondicion VARCHAR(30),
		SesionAsiste INT,
		SesionJustifica INT,
		SesionTarde INT,
		SesionFalta INT,
		ProductoNombre VARCHAR(200),
		PromocionCodigo VARCHAR(30),
		CursoNivel VARCHAR(100), --@31  
		CursoCredito DECIMAL(5,2),
		Ciclo INT,
		PonderadoActual REAL,
		PonderadoAcumulado REAL,
		OrdenMeritoSeccion INT,
		OrdenMeritoPromocion INT,
		OrdenMeritoProducto INT,
		CurriculaNombre VARCHAR(200),
		CurriculaCodigo VARCHAR(30),
		PeriodoCodigo VARCHAR(30),
		NroPeriodos INT,
		CurriculaModuloCodigoMatricula VARCHAR(30),
		CurriculaModuloNombreMatricula VARCHAR(200),
		FacultadIdFacultad INT,
		UnidadNegocioIdUnidadNegocio INT,
		UnidadAcademicaIdUnidadAcademica INT,
		ProductoIdProducto INT,
		IdTipoCurso INT,
		TipoCursoNombre VARCHAR(200),
		IdPromocion INT,
		CondicionDisponible1 VARCHAR(200),
		IdAlumno INT,
		CargoNota VARCHAR(250),
		Cargo VARCHAR(250),
		IdRegistro INT,
		IdDecreto INT,
		IdDocente INT,
		Nombres VARCHAR(250),
		NombreCorto VARCHAR(250),
		TipoServicio VARCHAR(250),
		SeccionNomina VARCHAR(250),
		CursoNombreOriginal VARCHAR(250),
		NumeroClase VARCHAR(250),
		NumeroMatricula VARCHAR(200),
		PromocionGrupoNumeroClase VARCHAR(200),
		SeccionNumeroClase VARCHAR(200),
		CurriculaModuloOrden INT,
		CurriculaCursoOrden INT,
		--Inicio --@37
		PromedioPonderadoAcademico REAL,
		PromedioHistoricoPonderado REAL,
		CoeficienteAcademicoEstandarizado REAL
		--Fin --@37
	)  
  
	SELECT
		@CompaniaSocio = CompaniaSocio  
	FROM Empresa WITH (NOLOCK) --@37
	WHERE IdEmpresa = 1

	--Inicio  --@37
	SELECT
		@PeriodoVisualizacionNuevosPromediosPonderados = ISNULL(Valor,'0')
	FROM Parametro WITH (NOLOCK)
	WHERE Nombre = 'VisualizacionNuevosPromediosPonderados'
	--Fin  --@37

	INSERT INTO @AlumnoCurso --@7
	--Inicio --@37
	(  
		IdCurricula,
		IdCurso,
		IdModulo,
		CurriculaModuloCodigo,
		CurriculaModuloNombre,
		CursoCodigo,
		CursoNombreOficial,
		IdSeccion,
		SeccionCodigo,
		FechaInicio,
		IdMoneda,
		MonedaCodigo,
		MontoMoneda,
		IdGrupo,
		GrupoCodigo,
		TipoCondicion,
		TipoCondicionNombre,
		EstadoNombre,
		NumVezCurso,
		PromedioFinal,
		PromedioReal,
		PromedioCondicion,
		SesionAsiste,
		SesionJustifica,
		SesionTarde,
		SesionFalta,
		ProductoNombre,
		PromocionCodigo,
		CursoNivel,
		CursoCredito,
		Ciclo,
		PonderadoActual,
		PonderadoAcumulado,
		OrdenMeritoSeccion,
		OrdenMeritoPromocion,
		OrdenMeritoProducto,
		CurriculaNombre,
		CurriculaCodigo,
		PeriodoCodigo,
		NroPeriodos,
		CurriculaModuloCodigoMatricula,
		CurriculaModuloNombreMatricula,
		FacultadIdFacultad,
		UnidadNegocioIdUnidadNegocio,
		UnidadAcademicaIdUnidadAcademica,
		ProductoIdProducto,
		IdTipoCurso,
		TipoCursoNombre,
		IdPromocion,
		CondicionDisponible1,
		IdAlumno,
		CargoNota,
		Cargo,
		IdRegistro,
		IdDecreto,
		IdDocente,
		Nombres,
		NombreCorto,
		TipoServicio,
		SeccionNomina,
		CursoNombreOriginal,
		NumeroClase,
		NumeroMatricula,
		PromocionGrupoNumeroClase,
		SeccionNumeroClase,
		CurriculaModuloOrden,
		CurriculaCursoOrden,
		PromedioPonderadoAcademico,
		PromedioHistoricoPonderado,
		CoeficienteAcademicoEstandarizado
	)
	--Fin --@37
	SELECT
		ISNULL(CC.IdCurricula,-1), --@20  
		ISNULL(AC.IdCursoOriginal,AC.IdCurso), --@20 --@33
		ISNULL(CC.IdModulo,-1), --@20
		--@28
		ISNULL
		(
			CASE
				WHEN PR2.TipoServicio = 'L' THEN 'MODULOUNIC'
				ELSE CM.Codigo
			END
		, ''),
		ISNULL
		(
			CASE
				WHEN PR2.TipoServicio = 'L' THEN 'MODULO UNICO'
				ELSE CM.Nombre
			END
		, ''),
		--@28
		C.CursoCodigo,
		ISNULL
		(
			CASE
				WHEN PR.TipoServicio = 'P' OR PR.TipoServicio = 'C' THEN CC.CursoNombreOficial --@9 --@20
			END
		,C.CursoNombre), 
		ISNULL(S.IdSeccion,-1),
		ISNULL(S.Codigo,''),
		ISNULL(CONVERT(VARCHAR(10),S.FechaInicio,103),''),
		ISNULL(AC.IdMoneda,0),
		ISNULL(MONEDA.Codigo,''),
		ISNULL(AC.MontoMoneda,0),
		ISNULL(PG.IdGrupo,-1), --@1
		ISNULL(PG.GrupoCodigo,''), --@1 --@8 --@20 --@25  
		'', --@2
		--@1
		CASE
			WHEN AC.Estado = 'RA' OR AC.Estado = 'RC' THEN 'RETIRADO'  --@29  
			ELSE
				ISNULL
				(
					CASE
						WHEN ACC.Subsanacion = 1 AND AC.NumVezCurso <= 1 AND PR2.IdPeriodoAnual >= 2019 THEN 'SUBSANA' --@19
						WHEN AC.TipoCondicion = 'RE' AND ACC.Subsanacion IS NULL THEN 'REGULAR'
						WHEN AC.TipoCondicion = 'CC' THEN 'CURSO REPITENCIA'  
						WHEN AC.TipoCondicion = 'EC' THEN 'EXAMEN CARGO'  
						WHEN AC.TipoCondicion = 'EX' THEN NULL
					END
				,'')
		END,
		--dbo.cMatriculaTipoCondicionStr(AC.TipoCondicion)
		--@1
		ISNULL(AC.Estado,''), --@1
		ISNULL(AC.NumVezCurso,0), --@1
		ISNULL(AC.PromedioReal,''), --@1 --@4
		ISNULL(AC.PromedioReal,''), --@1
		ISNULL(AC.PromedioCondicion,''), --@1
		ISNULL(AC.SesionAsiste,0), --@1
		ISNULL(AC.SesionJustifica,0), --@1
		ISNULL(AC.SesionTarde,0), --@1
		ISNULL(AC.SesionFalta,0), --@1
		ISNULL(P2.ProductoNombre,''), --@2 
		ISNULL(PR2.PromocionCodigo,0), --@2
		ISNULL(CM.Nombre,''), --@2
		ISNULL(CC.CursoCredito,0), --@2
		1, --@2
		ROUND(ISNULL(PGC.PromedioReal,0),2), --@2
		ROUND(ISNULL(PGC.PromedioRealAcumulado,0),2), --@2  
		CONVERT(INT,ISNULL(PGC.OrdenMerito,-1)), --@2  
		CONVERT(INT,ISNULL(PGC.OrdenMeritoPromocion,-1)), --@2  
		CONVERT(INT,ISNULL(PGC.OrdenMeritoProducto,-1)), --@2
		--@2
		CASE
			WHEN PR2.TipoServicio = 'L' THEN P2.ProductoNombre --@21 --@25
			ELSE CRR.Nombre
		END,
		--@2
		--@2
		CASE
			WHEN PR2.TipoServicio = 'L' THEN P2.ProductoCodigo --@21 --@25
			ELSE CRR.Codigo
		END,
		--@2   
		PE.Codigo, --@2
		(
			SELECT
				COUNT(DISTINCT PE.Codigo)
			FROM AlumnoCurso ACWITH WITH (NOLOCK)
			INNER JOIN Promocion PR WITH (NOLOCK) ON AC.IdPromocion = PR.IdPromocion
			INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo
			WHERE AC.IdMatricula = @IdMatricula
			AND AC.EsMatricula = 1
		),
		--@2
		CASE
			WHEN PR2.TipoServicio = 'L' THEN 'MODULOUNIC' --@20 --@25
			ELSE ISNULL(CM2.Codigo,'') --@35
		END,
		--@2
		--@2
		CASE
			WHEN PR2.TipoServicio = 'L' THEN 'MODULO UNICO' --@20 --@25
			ELSE ISNULL(CM2.NOMBRE,'') --@35
		END,
		--@2
		PR.IdFacultad, --@2
		PR.IdUnidadNegocio, --@2
		PR.IdUnidadAcademica, --@2
		PR.IdProducto, --@2
		C.IdTipoCurso, --@2
		TipoCurso.Nombre, --@2
		AC.IdPromocion, --@2
		ISNULL(CONDICION.Disponible1,''), --@3
		AC.IdAlumno,  
		SPACE(25), --@5 --@7 
		SPACE(250), --@5 --@7 
		AC.IdRegistro,
		AC.IdDecreto,
		AP.IdActor, --@17
		AP.Nombres, --@11
		(AP.Nombres + ' ' + AP.Paterno), --@11
		ISNULL(UN.TipoServicio,''), 
		--ISNULL(ISNULL(ACM.SeccionNomina,M.seccion),''),
		CASE
			WHEN EXISTS (
				SELECT 1
				FROM AlumnoSinSeccionNominaProceso ASSNP WITH (NOLOCK)
				WHERE ASSNP.IdMatricula = AC.IdMatricula
				  AND ASSNP.IdCurso     = ISNULL(AC.IdCursoOriginal, AC.IdCurso)
				  AND ASSNP.Estado = 1
			)
			THEN 'No corresponde'--@39	
			ELSE ISNULL(ISNULL(ACM.SeccionNomina, M.seccion), '')
		END,--@38
		ISNULL(C2.CursoNombre,''), --@18  
		'-1',
		M.NumeroMatricula,
		PG.NumeroClase,
		S.NumeroClase,
		CM.Orden, --@34
		CC.Orden, --@34
		--Inicio --@37
		CASE
			WHEN CONVERT(INT,@PeriodoVisualizacionNuevosPromediosPonderados) > 0 AND PE.IdPeriodoAnual >= CONVERT(INT,@PeriodoVisualizacionNuevosPromediosPonderados) THEN ROUND(ISNULL(ALUCURRMOD.PromedioPonderadoAcademico,0),2)
			ELSE ROUND(0,2)
		END,
		CASE
			WHEN CONVERT(INT,@PeriodoVisualizacionNuevosPromediosPonderados) > 0 AND PE.IdPeriodoAnual >= CONVERT(INT,@PeriodoVisualizacionNuevosPromediosPonderados) THEN ROUND(ISNULL(ALUCURRMOD.PromedioHistoricoPonderado,0),2)
			ELSE ROUND(0,2)
		END,
		CASE
			WHEN CONVERT(INT,@PeriodoVisualizacionNuevosPromediosPonderados) > 0 AND PE.IdPeriodoAnual >= CONVERT(INT,@PeriodoVisualizacionNuevosPromediosPonderados) THEN ROUND(ISNULL(ALUCURRMOD.CoeficienteAcademicoEstandarizado,0),2)
			ELSE ROUND(0,2)
		END
		--Fin --@37
	FROM AlumnoCurso AC WITH (NOLOCK)  
	LEFT JOIN AlumnoCurriculaCurso ACC WITH (NOLOCK) ON AC.IdAlumno = ACC.IdAlumno --@26  
	AND ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) = ACC.IdCurricula 
	AND AC.IdRegistro = ACC.IdRegistro
	AND ISNULL(AC.IdCursoOriginal,AC.IdCurso) = ACC.IdCurso --@19 --@20 
	LEFT JOIN CurriculaCurso CC WITH (NOLOCK) ON ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) = CC.IdCurricula
	AND ISNULL(AC.IdCursoOriginal,AC.IdCurso) = CC.IdCurso --@20 --@33 
	LEFT JOIN CurriculaModulo CM WITH (NOLOCK) ON CC.IdModulo = CM.IdModulo
	AND CC.IdCurricula = CM.IdCurricula --@20 
	LEFT JOIN MaestroTablaRegistro MONEDA WITH (NOLOCK) ON AC.IdMoneda = MONEDA.IdMaestroRegistro  
	LEFT JOIN Seccion S WITH (NOLOCK) ON AC.IdSeccion = S.IdSeccion
	INNER JOIN Curso C WITH (NOLOCK) ON CASE WHEN AC.IdSeccion IS NULL THEN ISNULL(AC.IdCursoOriginal,AC.IdCurso) ELSE S.IdCurso END = C.IdCurso --@20 --@22 --@23 --@24 --@33 
	LEFT JOIN PromocionGrupo PG WITH (NOLOCK) ON AC.IdPromocion = PG.IdPromocion
	ANd AC.IdGrupo = PG.IdGrupo --@1  
	LEFT JOIN Curricula CRR WITH (NOLOCK) ON ISNULL(AC.IdCurriculaOriginal,AC.IdCurricula) = CRR.IdCurricula --@20 --@33
	LEFT JOIN Producto P WITH (NOLOCK) ON CRR.IdProducto = P.IdProducto --@20 
	INNER JOIN Promocion PR2 WITH (NOLOCK) ON AC.IdPromocion = PR2.IdPromocion --@6 --@8
	INNER JOIN Producto P2 WITH (NOLOCK) ON PR2.IdProducto = P2.IdProducto --@8
	INNER JOIN Matricula M WITH (NOLOCK) ON M.IdMatricula = AC.IdMatricula
	INNER JOIN Promocion PR WITH (NOLOCK) ON M.IdPromocion = PR.IdPromocion --@6
	LEFT JOIN PromocionGrupoCierre PGC WITH (NOLOCK) ON PR.IdPromocion = PGC.IdPromocion
	AND AC.IdGrupo = PGC.IdGrupo
	AND AC.IdMatricula = PGC.IdMatricula
	--Inicio --@37
	LEFT JOIN AlumnoCurriculaModulo ALUCURRMOD WITH (NOLOCK) ON M.IdCurricula = ALUCURRMOD.IdCurricula
	AND M.IdRegistro = ALUCURRMOD.IdRegistro
	AND M.IdModulo = ALUCURRMOD.IdModulo
	AND M.IdActor = ALUCURRMOD.IdAlumno
	--Fin --@37
	INNER JOIN Periodo PE WITH (NOLOCK) ON PR.IdPeriodo = PE.IdPeriodo
	LEFT JOIN CurriculaModulo CM2 WITH (NOLOCK) ON M.IdModulo = CM2.IdModulo
	AND M.IdCurricula = CM2.IdCurricula --@20
	LEFT JOIN MaestroTablaRegistro TipoCurso WITH (NOLOCK) ON C.IdTipoCurso = TIPOCURSO.IdMaestroRegistro
	LEFT JOIN Evaluacion E WITH (NOLOCK) ON E.IdEvaluacion = S.IdEvaluacion
	LEFT JOIN EvaluacionCondicion EC WITH (NOLOCK) ON EC.IdSistema = E.IdSistema
	AND CAST(CASE WHEN AC.PromedioReal = 'DPI' THEN '0' ELSE AC.PromedioReal END AS REAL) BETWEEN CAST(EC.CondicionUno AS REAL) AND CAST(EC.CondicionDos AS REAL)
	LEFT JOIN MaestroTablaRegistro CONDICION WITH (NOLOCK) ON CONDICION.IdMaestroRegistro = EC.IdTipoCondicion
	LEFT JOIN SeccionProfesor SP WITH (NOLOCK) ON SP.IdSeccion = S.IdSeccion
	AND SP.EsResponsable = 1 --@10
	LEFT JOIN Actor AP WITH (NOLOCK) ON SP.IdActor = AP.IdActor --@10
	LEFT JOIN Facilitador F WITH (NOLOCK) ON AP.IdActor = F.IdFacilitador --@10
	INNER JOIN UnidadNegocio UN WITH (NOLOCK) ON PR.IdUnidadNegocio = UN.IdUnidadNegocio --@11
	LEFT JOIN AlumnoCursoNomina ACM WITH (NOLOCK) ON AC.IdMatricula = ACM.IdMatricula
	AND ISNULL(AC.IdCursoOriginal,AC.idcurso) = ACM.IdCurso
	LEFT JOIN Curso C2 WITH (NOLOCK) ON AC.IdCursoOriginal = C2.IdCurso
	--LEFT JOIN AlumnoSinSeccionNominaProceso ASSNP WITH (NOLOCK) ON AC.IdMatricula = ASSNP.IdMatricula AND AC.IdCurso=ASSNP.IdCurso
	WHERE AC.IdMatricula = @IdMatricula
	AND AC.EsMatricula = 1
  
	UPDATE AC SET
		--@5
		AC.CargoNota =
		ISNULL
		(
			CASE
				WHEN CA.Nota = 'NSP' THEN ''
				ELSE CA.Nota
			END
		,''),
		AC.Cargo =
		CASE
			WHEN ISNULL(CA.IdCargo,-1) = -1 THEN ''
			ELSE
				' N�mero: ' + ISNULL(CAST(CAR.IdCargo AS VARCHAR),'') +
				--@36 Inicio
				CASE CAR.Criterio
					WHEN 'E' THEN + '<br>' + ' Tipo: Evaluacion Extraordinaria' 
					WHEN 'C' THEN + '<br>' + ' Tipo: Examen de Cargo' 
					ELSE + '<br>' + ' Tipo: Examen'
				END + 
				--@36 Fin
				'<br>' + ' Observaci�n: Periodo: ' + ISNULL(PER.Codigo,'') +
				'<br>' + ' Fecha: ' + ISNULL(CONVERT(VARCHAR,ISNULL(CA.FechaModificacion,CA.FechaCreacion),104),'') +
				'<br>' + ' Usuario: ' + ISNULL(U.Login,'')
		END
		--@5
	FROM @AlumnoCurso AC
	LEFT JOIN AlumnoCurriculaCurso ACC WITH (NOLOCK) ON ACC.IdAlumno = AC.IdAlumno
	AND ACC.IdRegistro = AC.IdRegistro
	AND ACC.IdCurricula = AC.IdCurricula
	AND ACC.IdCurso = AC.IdCurso --@12 --@5 --@20
	LEFT JOIN CargoAlumno CA WITH (NOLOCK) ON ACC.IdAlumno = CA.IdAlumno
	AND ACC.IdCurso = CA.IdCurso --@5
	LEFT JOIN Registro RE WITH (NOLOCK) ON ACC.IdAlumno = RE.IdActor
	AND ACC.IdRegistro = RE.IdRegistro
	LEFT JOIN Cargo CAR WITH (NOLOCK) ON CA.IdCargo = CAR.IdCargo
	AND RE.IdUnidadNegocio = CAR.IdUnidadNegocio --@5
	LEFT JOIN Periodo PER WITH (NOLOCK) ON CAR.IdPeriodo = PER.IdPeriodo --@5
	LEFT JOIN Usuario U WITH (NOLOCK) ON ISNULL(CA.UsuarioModificacion,CA.UsuarioCreacion) = U.IdUsuario --@5 --@32
	WHERE CA.IdCargo =
	(
		SELECT
			MAX(CA2.IdCargo)
		FROM CargoAlumno CA2 WITH (NOLOCK)
		WHERE CA.IdAlumno = CA2.IdAlumno 
		AND CA.IdCurso = CA2.IdCurso
	)

	UPDATE AC SET
		--@5 
		AC.CargoNota =
		CASE
			WHEN ISNULL(AC.IdDecreto,-1) = -1 THEN ''
		ELSE
			ISNULL
			(
				CASE
					WHEN AC.PromedioReal = 'DPI' THEN ''
					ELSE AC.PromedioReal
				END
			,'')
		END,
		AC.Cargo =
		CASE
			WHEN ISNULL(AC.IdDecreto,-1) = -1 THEN ''
			ELSE ' N�mero: ' + ISNULL(CAST(DA.Codigo AS VARCHAR),'') +
				CASE AC.TipoServicio 
					WHEN 'C' THEN + '<br>' + ' Tipo: Examen de Suficiencia' 
					WHEN 'P' THEN + '<br>' + ' Tipo: Examen de Cargo' 
					ELSE + '<br>' + ' Tipo: Examen'
				END +
				'<br>' + ' Observaci�n: ' + ISNULL(DE.Descripcion,'') +
				'<br>' + ' Periodo: ' + ISNULL(PE.Codigo,'') +
				'<br>' + ' Fecha: ' + ISNULL(CONVERT(VARCHAR,ISNULL(DE.FechaModificacion,DE.FechaCreacion),104),'') +
				'<br>' + ' Usuario: ' + ISNULL(U.Login,'')
		END
		--@5
	FROM @AlumnoCurso AC
	INNER JOIN Registro RE WITH (NOLOCK) ON AC.IdAlumno = RE.IdActor
	AND AC.IdRegistro = RE.IdRegistro
	INNER JOIN Decreto DE WITH (NOLOCK) ON AC.IdDecreto = DE.IdDecreto 
	INNER JOIN DecretoCabecera DA WITH (NOLOCK) ON DE.IdDecretoCabecera = DA.IdDecretoCabecera
	AND RE.IdUnidadNegocio = DA.IdUnidadNegocio
	INNER JOIN Periodo PE WITH (NOLOCK) ON DA.IdPeriodo = PE.IdPeriodo
	LEFT JOIN Usuario U WITH (NOLOCK) ON ISNULL(DE.UsuarioModificacion,DE.UsuarioCreacion) = U.IdUsuario --@32
	WHERE ISNULL(AC.CargoNota,'') = ''
	AND ISNULL(AC.Cargo,'') = ''
  
	UPDATE AC SET
		AC.TipoCondicion = dbo.cAlumnoCursoEstadoStr(EstadoNombre)  
	FROM @AlumnoCurso AC
  
	IF @CompaniaSocio = '00002700'  
	BEGIN

		UPDATE AC SET
			AC.NumeroClase =
			ISNULL
			(
				(
					SELECT TOP 1
						IdCurso
					FROM [MoodleMdlLocalIsmCursos_Idat] MM WITH (NOLOCK)
					WHERE MM.IdGrupo = AC.PromocionGrupoNumeroClase
					AND MM.ShortNameCurso Like '%' +
					ISNULL
					(
						(
							SELECT TOP 1
								Anexo
							FROM Sede S WITH (NOLOCK)
							WHERE S.Codigo =
							(
								SELECT
									SUBSTRING
								FROM dbo.fnSeparadorCaracteres(AC.NumeroMatricula,'|')
								WHERE ID = 1
							)
						) + AC.SeccionNumeroClase
					,'-1')
				)
			,'-1')  
		FROM @AlumnoCurso AC
		
	END  
  
	SELECT
		IdCurricula,
		IdCurso,
		IdModulo,
		CurriculaModuloCodigo,
		CurriculaModuloNombre,
		CursoCodigo,
		CursoNombreOficial,
		IdSeccion,
		SeccionCodigo,
		FechaInicio,
		IdMoneda ,
		MonedaCodigo,
		MontoMoneda,
		IdGrupo,
		GrupoCodigo,
		TipoCondicion,
		TipoCondicionNombre,
		EstadoNombre,
		NumVezCurso,
		PromedioFinal,
		PromedioReal,
		PromedioCondicion,
		SesionAsiste,
		SesionJustifica,
		SesionTarde,
		SesionFalta,
		ProductoNombre,
		PromocionCodigo,
		CursoNivel,
		CursoCredito,
		Ciclo,
		PonderadoActual,
		PonderadoAcumulado,
		OrdenMeritoSeccion,
		OrdenMeritoPromocion,
		OrdenMeritoProducto,
		CurriculaNombre,
		CurriculaCodigo,
		PeriodoCodigo,
		NroPeriodos,
		CurriculaModuloCodigoMatricula,
		CurriculaModuloNombreMatricula,
		FacultadIdFacultad,
		UnidadNegocioIdUnidadNegocio,
		UnidadAcademicaIdUnidadAcademica,
		ProductoIdProducto,
		IdTipoCurso,
		TipoCursoNombre,
		IdPromocion,
		CondicionDisponible1,
		IdAlumno,
		CargoNota,
		Cargo,
		SeccionNomina,
		'Nombres' = ISNULL(Nombres,''), --@11
		'NombreCorto' = ISNULL(NombreCorto,''), --@11
		'IdDocente' = ISNULL(IdDocente,0), --@17
		CursoNombreOriginal, --@18
		ISNULL(NumeroClase, '-1') AS NumeroClase, --@27
		--Inicio --@37
		PromedioPonderadoAcademico,
		PromedioHistoricoPonderado,
		CoeficienteAcademicoEstandarizado
		--Fin --@37
	FROM @AlumnoCurso
	--@34
	ORDER BY CurriculaModuloOrden ASC,
	CurriculaCursoOrden ASC
	--@34
	--Fin --@37

END
