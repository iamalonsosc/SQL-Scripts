SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1229558 AND AC.IdCurso=9790-- AND AC.IdMatricula=606856
order by ac.idregistro,ac.IdAlumnoCurso desc


SELECT*FROM AlumnoCurso 
UPDATE AlumnoCurso SET IdSeccion=617600,PromedioFinal='0.00',PromedioReal='0.00',PromedioCondicion='D'
WHERE IdAlumno=1229558 AND IdCurso=9790 AND IdMatricula=606856



SELECT*FROM Seccion WHERE IdPromocion=95274 AND IdCurso=9790

exec cAlumnoCurso_Sel_Listar_Matricula @pIdCurricula=5604,@pIdModulo=5,@pIdMatricula=606856