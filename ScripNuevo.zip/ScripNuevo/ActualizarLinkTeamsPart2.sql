
--select*from SeccionHorario 
--CACERES CARHUACUSMA CARLOS ANTHONY
--https://outlook.office365.com/owa/?itemid=AAMkADA0NDIwMjJkLWIyZGEtNDE1NC1iMzZiLTZjN2IxMzQ2YjBlMwBGAAAAAAAS%2BZcxyGUCTLgFZBjl8nG5BwBC7udd1mqwRY3KnGXNf3LBAAAAAAENAABC7udd1mqwRY3KnGXNf3LBAAAAwhOHAAA%3D&exvsurl=1&path=/calendar/item
UPDATE SeccionHorario SET UrlClaseVirtual='https://teams.microsoft.com/meet/27267785485137?p=SmPK3Fh5V0Qk4lPXM8'
WHERE IdSeccion=414345



--select*from SeccionHorario 
--VIERA SANTTI LUIS ENRIQUE
--https://teams.microsoft.com/l/meetup-join/19%3ameeting_MWRjMjY4MTEtMmE4Mi00MTY4LTgwNDktZmZlMjQyMDQ2OThh%40thread.v2/0?context=%7b%22Tid%22%3a%2281e701d5-0d70-4fdd-9388-c8ba9d7a9975%22%2c%22Oid%22%3a%22bdb5c04d-b7c4-4535-836f-182b5c448ac5%22%7d
UPDATE SeccionHorario SET UrlClaseVirtual='https://teams.microsoft.com/meet/249845053125090?p=suX732KG6BfSwJEmJb'
WHERE IdSeccion=413312