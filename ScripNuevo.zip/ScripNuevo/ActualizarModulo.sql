--SELECT estado,*fROM MATRICULA 
update Matricula set IdModulo=3
WHERE IDMATRICULA=680158
--select*from Promocion where IdPromocion=99128