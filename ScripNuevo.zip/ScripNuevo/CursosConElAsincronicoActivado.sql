SELECT DISTINCT ACT.NombreCompleto,ACN.Valor,SE.Nombre, UA.Nombre,PRO.IdPromocion,PRO.PromocionCodigo,PRO.PromocionNombre
,prod.IdProducto,prod.ProductoNombre,CU.CursoNombre,acn.IdAlumno,sec.Idseccion,SEC.Codigo,PE.Codigo,pe.Inicio,pe.Fin,sec.EsAsincronico FROM SECCION SEC
INNER JOIN Promocion PRO ON PRO.IdPromocion=SEC.IdPromocion
INNER JOIN Sede SE ON SE.IdSede=PRO.IdSede
INNER JOIN UnidadAcademica UA ON UA.IdUnidadAcademica=PRO.IdUnidadAcademica
INNER JOIN Producto PROD ON PROD.IdProducto=pro.IdProducto
INNER JOIN Periodo PE ON PE.IdPeriodo=PRO.IdPeriodo
INNER JOIN AlumnoCursoNota ACN ON  SEC.IdSeccion=ACN.Idseccion
INNER JOIN Curso CU ON  CU.IdCurso=sec.IdCurso
--INNER JOIN AlumnoCursoAsistencia ACA ON  ACA.IdSeccion=ACN.Idseccion AND ACA.IdAlumno=ACN.IdAlumno
INNER JOIN Actor ACT ON ACT.IdActor=ACN.IdAlumno
INNER JOIN Usuario US ON US.IdActor=ACT.IdActor
WHERE SEC.EsAsincronico=1
--AND sec.IdPromocion=97221
--AND act.NombreCompleto='ACEVEDO CANALES MONICA MARIA'
AND US.Login='SV73013259'
--AND ACN.Valor <> 'NSP'
order by 1


--select*from Usuario where Login='IV72448747'
--select  *from AlumnoCursoNota
--SELECT *FROM AlumnoCursoNota
--where IdSeccion=637820 --and idalumno=1704780 and 
--SELECT*FROM Promocion WHERE IdPromocion=97221
--select*from Seccion where IdPromocion=97221