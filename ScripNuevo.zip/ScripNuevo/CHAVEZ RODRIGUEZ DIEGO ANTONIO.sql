SELECT CU.CursoNombre, AC.*FROM AlumnoCurso AC 
INNER JOIN Curso CU ON AC.IdCurso=CU.IdCurso
WHERE AC.IdAlumno=1259197 
--AND AC.IdCurso=9934 
--AND AC.IdCursoOriginal=9934 
AND AC.IdMatricula=634968 
order by ac.idregistro,ac.IdAlumnoCurso desc



INSERT INTO AlumnoCurso VALUES (1259197,2,21,5604,9934,634968,96872,3,616224,null,null,'16.00','16.00',NULL,NULL,NULL,'A',NULL,NULL,NULL,NULL,1,'CC',1,GETDATE(),1,GETDATE(),'NO',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

UPDATE AlumnoCurriculaCurso SET IdConvalidacion=NULL,PromedioFinal='16.00',PromedioReal= '16.00',IdAlumnoCurso=21,TipoCondicion='RE'
--select*from AlumnoCurriculaCurso 
where IdAlumno=1259197 and IdCurso=9934 AND IdRegistro=2