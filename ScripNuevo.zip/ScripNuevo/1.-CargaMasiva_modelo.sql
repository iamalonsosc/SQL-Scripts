------ =CONCATENAR("('";A2;"','";B2;"','";C2;"','";D2;"','";E2;"','";F2;"','";G2;"',0,@idgrupo,'OK','Ticket #";H2;"','Ninguna',1,GETDATE())")
declare @idgrupo int = (select max(grupo)+1 from CargaConvalidacionMigra)
INSERT INTO CargaConvalidacionMigra(Dnialumno,CodigoCurriculaAnterior,CodigoCursoAnterior,CodigoCurriculaNueva,CodigoCursoNuevo,PromocionCodigo,Promedio,flagcarga,grupo,resultado,observacion,tablainfo,usuariocreacion,fechacreacion)
VALUES 
('75820956','0208.01','0362','0208.01','0362','CH.0208.V.2021-IIIO','19',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('75820956','0208.01','0656','0208.01','0656','CH.0208.V.2021-IIIO','18',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('75820956','0208.01','0585','0208.01','0585','CH.0208.V.2021-IIIO','15',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('75820956','0208.01','0153','0208.01','0153','CH.0208.V.2021-IIIO','15',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('75820956','0208.01','0013','0208.01','0013','CH.0208.V.2021-IIIO','15',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('78879001','0209.01','01581','0209.01','01581','PT.0209.IV.2021-II','18',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('78879001','0209.01','0427','0209.01','0427','PT.0209.IV.2021-II','16',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('72979370','0212.01','0427','0212.01','0427','LN.0212.II.2022-IIIE','19',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('72696796','0210.01','0990','0210.01','0990','LN.0210.IV.2021-IIIE','14',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('72696796','0210.01','0369','0210.01','0369','LN.0210.IV.2021-IIIE','19',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('72696796','0210.01','0371','0210.01','0371','LN.0210.IV.2021-IIIE','17',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('72696796','0210.01','0636','0210.01','0636','LN.0210.IV.2021-IIIE','18',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('74928397','0219.01','0316','0219.01','0316','SM.0219.IV.2021-II','15',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('74928397','0219.01','0530','0219.01','0530','SM.0219.IV.2021-II','14',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('77706649','0208.01','0432','0208.01','0432','PT.0208.II.2022-IIIE','15',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())
,('77706649','0208.01','0488','0208.01','0488','PT.0208.II.2022-IIIE','15',0,@idgrupo,'OK','Ticket #73521','Ninguna',1,GETDATE())

SELECT * FROM CargaConvalidacionMigra WHERE convert(varchar,FechaCreacion,112)=convert(varchar,getdate(),112) 
--UPDATE CargaConvalidacionMigra
--SET FlagCarga=1 
--WHERE convert(varchar,FechaCreacion,112)=convert(varchar,getdate(),112) 
and FlagCarga=0
order by grupo desc
------------------