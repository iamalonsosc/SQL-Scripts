SELECT*FROM Actor WHERE IDACTOR=586407

SELECT*FROM Actor WHERE NombreCompleto='DE LA CRUZ ROIRO ALICIA FANNY'
--586405

declare @p62 int
set @p62=586407
exec cAlumnoMigra_Ins_Carga @Paterno=N'DE LA CRUZ',@Materno=N'ROIRO',@Nombres=N'ALICIA FANNY',
@Tenor=N'SE�ORITA',@Genero=N'F',@TipoDocumento=N'D.N.I.',@NumeroDocumento=N'71038164',@EstadoCivil=N'SOLTERA',@Nacionalidad=N'PERUANA',@FechaNacimiento=N'-',@PaisNacimiento=N'PERU',@Departamento=N'-',@Provincia=N'-',@Distrito=N'-',@Trabaja=N'-',@NivelEstudio=N'-',@GradoAcademico=N'-',@GradoAcademico2=NULL,@Colegio=N'-',@Colegio2=NULL,@AnoEgreso=N'-',@AnoEgreso2=NULL,@NivelEstudio2=NULL,@Carrera=N'-',@Carrera2=NULL,@PromedioGeneral=N'-',@PromedioGeneral2=NULL,@Via=N'-',@NombreVia=N'NULL',@NumeroVia=N'-',@DepartamentoDireccion=N'LIMA',@ProvinciaDireccion=N'LIMA',@DistritoDireccion=N'LIMA',@Referencia=N'-',@Via2=N'-',@NombreVia2=N'-',@NumeroVia2=N'-',@DepartamentoDireccion2=N'-',@ProvinciaDireccion2=N'-',@DistritoDireccion2=N'-',@Referencia2=N'-',@TipoEmail=N'PERSONAL',@DescripcionEmail=N'-',@TipoEmail2=N'LABORAL',@DescripcionEmail2=N'-',@TipoTelefono=N'-',@DescripcionTelefono=N'-',@TipoTelefono2=N'-',@DescripcionTelefono2=N'-',@TipoTelefono3=N'-',@DescripcionTelefono3=N'-',@CargoNombre=N'-',@PeriodoMesInicio=N'-',@PeriodoAnoInicio=N'-',@PeriodoMesFin=N'-',@PeriodoAnoFin=N'-',@TelefonoTrabajo=N'-',@NombreEmpresa=N'-',@Login=N'-',@EmailInstitucional=N'-',@Grupo=218,@IdIdentity=@p62 output
select @p62

SP_HELPTEXT cAlumnoMigra_Ins_Carga




Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----����������������������������������������������������������������������������                            
----Creado por      : Giancarlos Cuba(Sigcomt) (19/11/2018)        
----Funcionalidad   : Permite insertar datos a la tabla CargaAlumnoMigra      
----Utilizado por   : InsGrabarAlumnoMigra()                       
----����������������������������������������������������������������������������   
/*
-----------------------------------------------------------------------------      
Nro		FECHA		USUARIO						DESCRIPCION              
-----------------------------------------------------------------------------
@1		19/11/2018	Giancarlos Cuba(Sigcomt)	      
*/
CREATE PROCEDURE cAlumnoMigra_Ins_Carga
	@Paterno					VarChar(200),
	@Materno					VarChar(200),
	@Nombres					VarChar(200),
	@Tenor						VarChar(200),
	@Genero						VarChar(200),
	@TipoDocumento				VarChar(200),
	@NumeroDocumento			VarChar(200),
	@EstadoCivil				VarChar(200),
	@Nacionalidad				VarChar(200),
	@FechaNacimiento			VarChar(200),
	@PaisNacimiento				VarChar(200),
	@Departamento				VarChar(200),
	@Provincia					VarChar(200),
	@Distrito					VarChar(200),
	@Trabaja					VarChar(200),
	@NivelEstudio				VarChar(200),
	@GradoAcademico				VarChar(200),
	@Colegio					VarChar(200),
	@AnoEgreso					VarChar(200),
	@Carrera					VarChar(200),
	@PromedioGeneral			VarChar(200),
	@NivelEstudio2				VarChar(200),
	@GradoAcademico2			VarChar(200),
	@Colegio2					VarChar(200),
	@AnoEgreso2					VarChar(200),
	@Carrera2					VarChar(200),
	@PromedioGeneral2			VarChar(200),
	@Via						VarChar(200),
	@NombreVia					VarChar(200),
	@NumeroVia					VarChar(200),
	@DepartamentoDireccion		VarChar(200),
	@ProvinciaDireccion			VarChar(200),
	@DistritoDireccion			VarChar(200),
	@Referencia					VarChar(200),
	@Via2						VarChar(200),
	@NombreVia2					VarChar(200),
	@NumeroVia2					VarChar(200),
	@DepartamentoDireccion2		VarChar(200),
	@ProvinciaDireccion2		VarChar(200),
	@DistritoDireccion2			VarChar(200),
	@Referencia2				VarChar(200),
	@TipoEmail					VarChar(200),
	@DescripcionEmail			VarChar(200),
	@TipoEmail2					VarChar(200),
	@DescripcionEmail2			VarChar(200),
	@TipoTelefono				VarChar(200),
	@DescripcionTelefono		VarChar(200),
	@TipoTelefono2				VarChar(200),
	@DescripcionTelefono2		VarChar(200),
	@TipoTelefono3				VarChar(200),
	@DescripcionTelefono3		VarChar(200),
	@CargoNombre				VarChar(200),
	@PeriodoMesInicio			VarChar(200),
	@PeriodoAnoInicio			VarChar(200),
	@PeriodoMesFin				VarChar(200),
	@PeriodoAnoFin				VarChar(200),
	@TelefonoTrabajo			VarChar(200),
	@NombreEmpresa				VarChar(200),
	@Login						VarChar(200),
	@EmailInstitucional			VarChar(200),
	@Grupo						Int,
	@IdIdentity					Int OUTPUT
AS
BEGIN

	IF @Paterno = '' SET @Paterno = NULL
	IF @Materno = '' SET @Materno	= NULL
	IF @Nombres = '' SET @Nombres	= NULL
	IF @Tenor = '' SET @Tenor = NULL
	IF @Genero = '' SET @Genero = NULL
	IF @TipoDocumento = '' SET @TipoDocumento = NULL
	IF @NumeroDocumento = '' SET @NumeroDocumento = NULL
	IF @EstadoCivil = '' SET @EstadoCivil = NULL
	IF @Nacionalidad = '' SET @Nacionalidad = NULL
	IF @FechaNacimiento = '' SET @FechaNacimiento	= NULL
	IF @PaisNacimiento = '' SET @PaisNacimiento = NULL
	IF @Departamento = '' SET @Departamento = NULL
	IF @Provincia = '' SET @Provincia = NULL
	IF @Distrito = '' SET @Distrito = NULL
	IF @Trabaja = '' SET @Trabaja = NULL
	IF @NivelEstudio = '' SET @NivelEstudio = NULL
	IF @GradoAcademico = '' SET @GradoAcademico = NULL
	IF @Colegio = '' SET @Colegio = NULL
	IF @AnoEgreso = '' SET @AnoEgreso = NULL
	IF @Carrera = '' SET @Carrera = NULL
	IF @PromedioGeneral = '' SET @PromedioGeneral2 = NULL
	IF @NivelEstudio2 = '' SET @NivelEstudio = NULL
	IF @GradoAcademico2 = '' SET @GradoAcademico2 = NULL
	IF @Colegio2 = '' SET @Colegio2 = NULL
	IF @AnoEgreso2 = '' SET @AnoEgreso2 = NULL
	IF @Carrera2 = '' SET @Carrera2 = NULL
	IF @PromedioGeneral2 = '' SET @PromedioGeneral2 = NULL
	IF @Via = '' SET @Via = NULL
	IF @NombreVia = '' SET @NombreVia = NULL
	IF @NumeroVia = '' SET @NumeroVia = NULL
	IF @DepartamentoDireccion = '' SET @DepartamentoDireccion = NULL
	IF @ProvinciaDireccion = '' SET @ProvinciaDireccion = NULL
	IF @DistritoDireccion = '' SET @DistritoDireccion = NULL
	IF @Referencia = '' SET @Referencia = NULL
	IF @Via2 = '' SET @Via2 = NULL
	IF @NombreVia2 = '' SET @NombreVia2 = NULL
	IF @NumeroVia2 = '' SET @NumeroVia2 = NULL
	IF @DepartamentoDireccion2 = '' SET @DepartamentoDireccion2 = NULL
	IF @ProvinciaDireccion2 = '' SET @ProvinciaDireccion2 = NULL
	IF @DistritoDireccion2 = '' SET @DistritoDireccion2 = NULL
	IF @Referencia2 = '' SET @Referencia2 = NULL
	IF @TipoEmail = '' SET @TipoEmail = NULL
	IF @DescripcionEmail = '' SET @DescripcionEmail2 = NULL
	IF @TipoEmail2 = '' SET @TipoEmail = NULL
	IF @DescripcionEmail2 = '' SET @DescripcionEmail2 = NULL
	IF @TipoTelefono = '' SET @TipoTelefono = NULL
	IF @DescripcionTelefono = '' SET @DescripcionTelefono = NULL
	IF @TipoTelefono2 = '' SET @TipoTelefono2 = NULL
	IF @DescripcionTelefono2 = '' SET @DescripcionTelefono2 = NULL
	IF @TipoTelefono3 = '' SET @TipoTelefono3 = NULL
	IF @DescripcionTelefono3 = '' SET @DescripcionTelefono3 = NULL
	IF @CargoNombre = '' SET @CargoNombre = NULL
	IF @PeriodoMesInicio = '' SET @PeriodoMesInicio = NULL
	IF @PeriodoAnoInicio = '' SET @PeriodoAnoInicio = NULL
	IF @PeriodoMesFin = '' SET @PeriodoMesFin = NULL
	IF @PeriodoAnoFin = '' SET @PeriodoAnoFin = NULL
	IF @TelefonoTrabajo = '' SET @TelefonoTrabajo = NULL
	IF @NombreEmpresa = '' SET @NombreEmpresa = NULL
	IF @Grupo = '' SET @Grupo = NULL

	/*CONVERTIR CAMPOS A MAYUSCULA*/
	SET @Paterno = UPPER(@Paterno)
	SET @Materno = UPPER(@Materno)
	SET @Nombres = UPPER(@Nombres)
	SET @NombreVia = UPPER(@NombreVia)
	SET @NumeroVia = UPPER(@NumeroVia)
	SET @Referencia = UPPER(@Referencia)
	SET @NombreVia2 = UPPER(@NombreVia2)
	SET @NumeroVia2 = UPPER(@NumeroVia2)
	SET @Referencia2 = UPPER(@Referencia2)

INSERT INTO CargaAlumnoMigra
	(
		Paterno, Materno, Nombres, Tenor, Genero, TipoDocumento, NumeroDocumento, EstadoCivil, Nacionalidad,
		FechaNacimiento, PaisNacimiento, Departamento, Provincia, Distrito, Trabaja, NivelEstudio, GradoAcademico,
		Colegio, A�oEgreso, Carrera, PromedioGeneral, NivelEstudio2, GradoAcademico2, Colegio2, A�oEgreso2,
		Carrera2, PromedioGeneral2, Via, NombreVia, NumeroVia, DepartamentoDireccion, ProvinciaDireccion,
		DistritoDireccion, Referencia, Via2, NombreVia2, NumeroVia2, DepartamentoDireccion2, ProvinciaDireccion2,
		DistritoDireccion2, Referencia2, TipoEmail, DescripcionEmail, TipoEmail2, DescripcionEmail2, TipoTelefono,
		DescripcionTelefono, TipoTelefono2, DescripcionTelefono2, TipoTelefono3,
		DescripcionTelefono3, CargoNombre, PeriodoMesInicio, PeriodoA�oInicio, PeriodoMesFin, PeriodoA�oFin,
		TelefonoTrabajo,Login,EmailInstitucional, NombreEmpresa, Grupo
	)
VALUES
	(
		@Paterno, @Materno, @Nombres, @Tenor, @Genero, @TipoDocumento, @NumeroDocumento, @EstadoCivil, @Nacionalidad,
		@FechaNacimiento, @PaisNacimiento, @Departamento, @Provincia, @Distrito, @Trabaja, @NivelEstudio, @GradoAcademico,
		@Colegio, @AnoEgreso, @Carrera, @PromedioGeneral, @NivelEstudio2, @GradoAcademico2, @Colegio2, @AnoEgreso2,
		@Carrera2, @PromedioGeneral2, @Via, @NombreVia, @NumeroVia, @DepartamentoDireccion, @ProvinciaDireccion,
		@DistritoDireccion, @Referencia, @Via2, @NombreVia2, @NumeroVia2, @DepartamentoDireccion2, @ProvinciaDireccion2,
		@DistritoDireccion2, @Referencia2, @TipoEmail, @DescripcionEmail, @TipoEmail2, @DescripcionEmail2, @TipoTelefono,
		@DescripcionTelefono, @TipoTelefono2, @DescripcionTelefono2, @TipoTelefono3,
		@DescripcionTelefono3, @CargoNombre, @PeriodoMesInicio, @PeriodoAnoInicio, @PeriodoMesFin, @PeriodoAnoFin,
		@TelefonoTrabajo,@Login,@EmailInstitucional, @NombreEmpresa, @Grupo
	)
SELECT @IdIdentity = SCOPE_IDENTITY()
END



